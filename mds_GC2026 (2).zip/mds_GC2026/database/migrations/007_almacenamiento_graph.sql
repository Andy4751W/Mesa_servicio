-- Metadatos de objetos binarios almacenados fuera del servidor web.
-- La aplicación crea esta tabla automáticamente al efectuar la primera carga
-- Graph; este archivo permite auditar o aplicar la misma operación manualmente.

CREATE TABLE IF NOT EXISTS storage_objetos (
    id_storage_objeto BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    tipo_entidad VARCHAR(32) NOT NULL,
    id_entidad BIGINT UNSIGNED NOT NULL,
    id_pais_operacion SMALLINT UNSIGNED NULL,
    proveedor VARCHAR(16) NOT NULL,
    estado VARCHAR(16) NOT NULL,
    drive_id VARCHAR(255) NULL,
    item_id VARCHAR(255) NULL,
    parent_item_id VARCHAR(255) NULL,
    ruta_logica VARCHAR(700) NOT NULL,
    nombre_remoto VARCHAR(255) NOT NULL,
    nombre_original VARCHAR(255) NULL,
    tipo_mime VARCHAR(150) NOT NULL,
    tamano BIGINT UNSIGNED NOT NULL,
    sha256 CHAR(64) NULL,
    etag VARCHAR(255) NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_storage_objeto),
    UNIQUE KEY uq_storage_proveedor_item (proveedor, drive_id, item_id),
    KEY idx_storage_entidad (tipo_entidad, id_entidad, estado),
    KEY idx_storage_pais_estado (id_pais_operacion, estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
