# Contexto técnico para IA — Mesa de Servicio Conectar

> **Propósito:** este archivo es la memoria técnica operativa del software. Está diseñado para que una IA pueda localizar, modificar, renovar o retirar funcionalidades sin volver a inspeccionar todo el proyecto y sin romper reglas de negocio, seguridad o trazabilidad.
>
> **No es un manual de usuario.** No debe contener contraseñas, secretos, direcciones privadas ni datos personales.

| Campo | Valor |
|---|---|
| Versión inspeccionada | `mds_GC2026(20260911-131248).zip` |
| Fecha de inspección | 2026-09-11 |
| Aplicación | Mesa de Servicio Conectar |
| Tecnología principal | PHP 7.4+, MySQL/MariaDB, JavaScript, HTML y CSS |
| Contexto operativo | Colombia y Perú, separado mediante `id_pais_operacion` |
| Archivo que debe actualizarse después de un cambio estructural | `docs/CONTEXTO_IA_MESA_SERVICIO.md` |

---

## 1. Instrucciones obligatorias para una IA futura

Antes de modificar el sistema:

1. Lea este archivo completo.
2. Considere como fuente de verdad, en este orden: **código actual**, este archivo, documentos recientes y, por último, README, capturas o registros antiguos.
3. Localice únicamente el módulo afectado usando `app/routes.php` y búsquedas por tabla, función o parámetro. No analice ni reescriba todo el proyecto si el cambio es localizado.
4. Preserve siempre: país, permisos por rol, CSRF, trazabilidad, historial, instantáneas del flujo y acceso privado a adjuntos.
5. Antes de eliminar algo, consulte la matriz de eliminación de la sección 13.
6. No cambie la asignación predeterminada del servicio cuando la solicitud sea reasignar solamente un caso, una etapa o una derivación existente.
7. Mantenga compatibilidad con PHP 7.4. No introduzca características de versiones posteriores sin actualizar explícitamente el requisito de plataforma.
8. Ejecute validación de sintaxis y pruebas del flujo afectado por cada rol y país.
9. Entregue únicamente los archivos modificados, con su ruta relativa y una explicación breve. No entregue toda la mesa de servicio para un cambio de uno o dos archivos.
10. Al terminar, actualice el registro de cambios de este documento si se alteraron rutas, tablas, estados, permisos, integraciones o reglas de eliminación.

### Restricciones absolutas

- No copie secretos del archivo de configuración a documentación, mensajes, registros ni código cliente.
- No quite filtros por `id_pais_operacion`.
- No exponga rutas físicas de adjuntos ni permita descargarlos directamente por URL.
- No elimine físicamente tickets ni su evidencia desde la operación normal.
- No modifique retrospectivamente las etapas o listas de chequeo ya copiadas a un ticket.
- No confunda el proceso informativo del usuario con los servicios que puede gestionar: un gestor puede ser multiproceso.

---

## 2. Modelo mental del sistema

La raíz pública estable es `index.php`. Después de autenticar, esta página conserva la estructura visual principal y carga los módulos dentro de un `iframe`. Las URL internas se mantienen ocultas y la última pantalla se conserva en la sesión.

```mermaid
flowchart TD
    B["Navegador"] --> R["index.php · shell estable"]
    R --> P["public/*.php · entrada pública"]
    P --> E["public/_entry.php · control común"]
    E --> M["app/modules/*.php · lógica de módulo"]
    M --> D["MySQL principal"]
    M --> S["Almacenamiento privado"]
    M --> X["Uniclass / n8n"]
```

Recorrido normal de un módulo:

`URL pública` → `public/<archivo>.php` → `public/_entry.php` → mapa de `app/routes.php` → implementación en `app/modules/`.

Consecuencia: una funcionalidad visual puede involucrar el módulo, su ruta, el shim público y las listas de navegación o auditoría del shell. No renombre archivos sin buscar todas sus referencias.

---

## 3. Estructura y responsabilidad de carpetas

| Ruta | Responsabilidad | Regla de modificación |
|---|---|---|
| `index.php` | Inicio de sesión, shell autenticado, navegación e historial interno | Cambiar con cautela; afecta todos los roles |
| `.htaccess` | Redirección desde la raíz hacia `public/` | Requiere Apache `mod_rewrite` y `AllowOverride` |
| `app/bootstrap.php` | Constantes de rutas, zona horaria y dependencias base | Debe cargarse antes de módulos |
| `app/routes.php` | Mapa canónico de archivos públicos a implementaciones | Actualizar al añadir, mover o retirar módulos |
| `app/config/` | Conexiones y configuración | Usar variables de entorno; nunca publicar secretos |
| `app/modules/` | Interfaces y controladores de cada módulo | Principal lugar de cambios funcionales |
| `app/services/` | Reglas transversales de negocio e integraciones | Reutilizar; no duplicar lógica en vistas |
| `app/security/` | Sesión, CSRF, permisos, cabeceras y límites | No reducir controles para resolver errores visuales |
| `app/helpers/` | Compatibilidad y utilidades compartidas | Verificar consumidores antes de cambiar firmas |
| `public/` | Única superficie web pública y recursos estáticos | Los PHP deben ser entradas controladas, no lógica duplicada |
| `public/_entry.php` | Despacho, auditoría POST, shell visual e inyección común | Evitar cargar dos veces scripts de sesión |
| `mds_storage/` | Archivos privados de áreas, perfiles y solicitudes | Debe estar fuera de acceso web directo y respaldarse |
| `scripts/` | Tareas CLI, migraciones auxiliares y verificaciones | No exponer por web; revisar vigencia antes de ejecutar |
| `n8n/` | Material relacionado con automatización de correo | Administrar secretos fuera del repositorio |
| `docs/` | Contexto técnico y decisiones | Este archivo es la referencia principal para IA |

Los archivos `.htaccess` de `app/`, `mds_storage/` y `docs/` bloquean el acceso directo o el listado de directorios. No deben retirarse en producción.

---

## 4. Arranque, navegación y sesión visual

### `index.php`

- Es la URL visible y estable.
- Procesa el inicio de sesión mediante POST.
- En una sesión autenticada renderiza el menú, la cabecera y el `iframe` de módulos.
- Conserva la pantalla anterior con `mesa_ultima_pantalla` y almacenamiento del navegador.
- Intercepta navegación interna para evitar mostrar rutas técnicas.
- Permite excepciones necesarias, como descargas y enlaces específicos del flujo.

### `public/_entry.php`

- Carga `app/bootstrap.php` y `app/routes.php`.
- Resuelve la implementación correspondiente al archivo público solicitado.
- Audita operaciones POST exitosas.
- Aplica clases visuales y controles de cuenta comunes.
- Retira inclusiones repetidas de `controlSesion.js` dentro de módulos.

### Regla de inactividad

El control de inactividad debe existir **una sola vez en el shell padre**. Si aparece tanto en el shell como en el contenido del `iframe`, se muestran dos alertas y se ejecutan dos temporizadores. Una corrección válida debe conservar una única instancia, reiniciar el tiempo en servidor al pulsar “Sigo en línea”, cerrar el modal y reiniciar el contador cliente.

Valores actuales encontrados:

| Parámetro | Valor |
|---|---:|
| Tiempo para advertencia | 300 segundos |
| Duración de cuenta regresiva | 15 segundos |
| Expiración total | 315 segundos |
| Regeneración periódica del ID de sesión | 900 segundos |

---

## 5. Conexiones e integraciones

### 5.1 Base de datos principal

- Motor: MySQL/MariaDB mediante `mysqli`.
- Base lógica de la versión inspeccionada: `mds_GC2026`.
- Configuración central: `app/config/conexion.php`.
- Codificación esperada: `utf8mb4`.
- Zona horaria de negocio: `America/Bogota`; la conexión ajusta la zona a UTC-05.

Variables de entorno admitidas:

```text
MESA_DB_HOST
MESA_DB_PORT
MESA_DB_USER
MESA_DB_PASSWORD
MESA_DB_NAME
MESA_STORAGE_PATH
MESA_ENV
MESA_FORCE_HTTPS
MESA_ENABLE_DIAGNOSTICS
```

### 5.2 Fuente externa de personal — Uniclass

Servicio responsable: `app/core/fuentePersonal.php`.

Tablas externas consultadas:

- `mae_data_uniclass`
- `mae_ciudades`

Variables:

```text
MESA_FUENTE_DB_HOST
MESA_FUENTE_DB_PORT
MESA_FUENTE_DB_NAME
MESA_FUENTE_DB_USER
MESA_FUENTE_DB_PASSWORD
```

Regla vigente: Uniclass ayuda a completar y validar datos. La columna de cédula es `identificacion` y el estado laboral es `EST`, normalizado como `UPPER(TRIM(EST))`. La consulta obtiene todos los registros de la cédula: si existe al menos un registro `A`, solo se usa una fila activa para autocompletar; si todos son `R`, no se arrastran datos y la creación se bloquea con el mensaje de persona retirada. Los registros activos se priorizan por la fecha de actualización o creación disponible y, si no existe una fecha utilizable, por el ID disponible más alto. Si una persona no se encuentra o la fuente no está disponible, el administrador puede completar los datos manualmente; no se convierte la existencia en Uniclass en requisito absoluto.

### 5.3 Correo mediante n8n y Microsoft 365

Adaptador: `app/services/correoN8n.php`.

Variables:

```text
MESA_N8N_WEBHOOK_URL
MESA_N8N_WEBHOOK_SECRET
```

La aplicación envía solicitudes HTTPS firmadas al webhook. n8n realiza el envío final con Microsoft 365; la aplicación no debe almacenar la contraseña del buzón. En notificaciones informativas, un fallo de correo no debe deshacer una transacción de ticket ya confirmada. Los flujos que dependen de confirmación, como recuperación de contraseña, deben validar la respuesta correspondiente.

### 5.4 Almacenamiento privado

- Ruta configurable mediante `MESA_STORAGE_PATH`.
- Valor local habitual: `mds_storage/`.
- Contiene subdirectorios para imágenes de catálogos, perfiles y adjuntos de solicitudes.
- Los adjuntos se descargan por `descargarAdjunto.php`, después de validar sesión, rol, pertenencia y nodo del ticket.
- Nunca devuelva al navegador la ruta física del archivo.

---

## 6. Roles, alcance y país

| ID | Rol | Alcance principal |
|---:|---|---|
| 1 | Administrador | Configuración, trazabilidad, usuarios, tickets y reasignación manual |
| 2 | Gestor | Gestión de etapas asignadas, conversación, adjuntos y seguimiento |
| 3 | Solicitante | Creación, consulta, conversación, cierre, reapertura y calificación de sus casos |

### País como frontera de datos

El sistema opera con `paises_operacion` y guarda el país activo en la sesión. El administrador puede cambiar el contexto; los demás usuarios permanecen en su país asignado. Las entidades operativas incluyen normalmente `id_pais_operacion`.

Toda consulta, inserción, actualización, exportación, restauración o eliminación debe respetar el país. Una consulta que funciona pero omite este filtro constituye una fuga de datos entre operaciones.

### Regla de sesiones concurrentes encontrada en el código

`app/services/sesionUnica.php` aplica sesión única al rol Solicitante y permite varias sesiones registradas a Administrador y Gestor. Esto debe confirmarse como decisión de negocio antes de producción si se esperaba sesión única también para Gestor. No cambie esta regla silenciosamente.

---

## 7. Mapa de módulos y archivos responsables

### Administrador

| Módulo | Entrada / implementación principal | Finalidad |
|---|---|---|
| Centro de control | `panelAdmin.php` | Acceso operativo y estado de sesiones |
| Tickets | `solicitudes.php` | Consulta, árbol, historial y reasignación manual |
| Usuarios | `crearUsuarios.php`, `editarUsuario.php` | Alta, edición y habilitación |
| Indicadores | `indicadores.php` | Métricas administrativas |
| Áreas | `catalogos.php`, `editarcatalogos.php` | Configuración de áreas |
| Servicios | `servicios.php` | Oferta, gestor predeterminado, SLA y parámetros |
| Soluciones | `soluciones.php` | Opciones de solución por área y servicio |
| Flujos | `procesos.php` | Etapas, responsables y listas de chequeo |
| SLA | `sla.php` | Tiempos de respuesta |
| Festivos | `feriados.php` | Calendario no laboral |
| Clasificación / niveles | `configuraciones.php?tipo=...` | Listas configurables |
| Papelera | `papelera.php` | Restauración o eliminación definitiva controlada |

### Gestor

| Módulo | Entrada principal | Finalidad |
|---|---|---|
| Mis indicadores | `panelGestor.php` | Métricas del gestor |
| Centro de control | `sesiones.php` | Sesiones y accesos permitidos |
| Casos asignados | `flujoTicket.php?modo=mis_tickets` | Gestión de las etapas asignadas |
| Mensajes | `mensajes.php` | Conversaciones de tickets autorizados |

### Solicitante

| Módulo | Entrada principal | Finalidad |
|---|---|---|
| Crear solicitud | `panelSolicitante.php?vista=nueva` | Selección de área/servicio y creación |
| Estado de solicitudes | `panelSolicitante.php?vista=tickets` | Seguimiento de casos propios |
| Mensajes | `mensajes.php` | Conversación de casos propios |

### Servicios transversales decisivos

| Archivo | Responsabilidad |
|---|---|
| `app/services/motorFlujos.php` | Ciclo de tickets, etapas, derivaciones, permisos, checklist, conversación, adjuntos, cierre y avisos |
| `app/services/calendarioLaboral.php` | Cálculo de vencimientos y días laborales |
| `app/services/matrizPrioridad.php` | Conversión de urgencia e impacto en prioridad |
| `app/services/pais.php` | Resolución y validación del país operativo |
| `app/services/sesionUnica.php` | Registro y concurrencia de sesiones |
| `app/services/chatEstado.php` | Presencia, entrega y lectura de mensajes |
| `app/services/correoN8n.php` | Integración de correo |
| `app/services/fuentePersonal.php` | Consulta de personal en Uniclass |
| `app/services/papelera.php` | Serialización para recuperación de configuraciones eliminadas |
| `app/services/auditoriaSesiones.php` | Auditoría de POST exitosos |
| `app/services/temasInterfaz.php` | Paletas y preferencias visuales |
| `app/services/perfil.php` | Imagen y datos visibles del perfil |
| `app/services/automatizacionTickets.php` | Cierre automático de tickets antiguos sin flujo |

---

## 8. Modelo de datos funcional

```mermaid
erDiagram
    PAISES_OPERACION ||--o{ CATALOGOS : contiene
    CATALOGOS ||--o{ SERVICIOS : ofrece
    SERVICIOS ||--o{ PROCESOS : configura
    PROCESOS ||--o{ PROCESO_ETAPAS : plantilla
    TICKETS ||--o{ TICKET_ETAPAS : instancia
    TICKET_ETAPAS ||--o{ TICKET_ETAPAS : deriva
    TICKET_ETAPAS ||--o{ SOLICITUD_COMUNICACIONES : conversa
    TICKET_ETAPAS ||--o{ SOLICITUD_ADJUNTOS : adjunta
```

### Tablas principales identificadas

| Grupo | Tablas |
|---|---|
| Identidad y alcance | `usuarios`, `roles`, `paises_operacion` |
| Catálogo de servicio | `catalogos`, `servicios`, `sla`, `feriados`, `configuraciones_servicio`, `soluciones_servicio` |
| Plantillas de flujo | `procesos`, `proceso_etapas`, `proceso_etapa_checklist` |
| Ejecución de tickets | `tickets`, `ticket_etapas`, `ticket_etapa_checklist` |
| Evidencia | `solicitud_comunicaciones`, `solicitud_adjuntos`, `solicitud_historial`, `solicitud_calificaciones` |
| Avisos y chat | `notificaciones`, `ticket_notificaciones_email_preferencias`, `chat_usuario_presencia`, `chat_conversacion_estado` |
| Seguridad | `sesiones_usuario`, `sesiones_usuario_paises`, `auditoria_sesiones`, `seguridad_intentos_login`, `recuperaciones_password` |
| Recuperación y apariencia | `papelera`, `usuario_preferencias_interfaz` |

El código consulta `information_schema` para detectar capacidades o columnas disponibles. Si se crea una migración, no dependa únicamente de esta detección: documente la versión de esquema y haga el cambio repetible.

---

## 9. Reglas que mantienen coherente el negocio

### Áreas, servicios y gestores

- `catalogos` representa las áreas.
- Un servicio pertenece a un área y puede tener SLA, gestor predeterminado, clasificación, urgencia, impacto, prioridad, nivel y estado.
- El campo `proceso` del usuario gestor es informativo. **No se debe filtrar la lista de gestores por ese proceso al asignarlos a servicios.** Un gestor puede gestionar servicios de distintos procesos.
- El gestor definido en un servicio es el responsable predeterminado para casos futuros; no controla permanentemente los casos ya creados.

### Plantilla frente a instancia

- `proceso_etapas` y `proceso_etapa_checklist` son plantillas configurables.
- Al crear el caso, el flujo vigente se copia a `ticket_etapas` y `ticket_etapa_checklist`.
- Esa copia es una instantánea histórica. Cambiar el servicio, flujo, gestor o checklist posteriormente no debe reescribir tickets existentes.

### Etapas y derivaciones

- `tickets.id_etapa_actual` identifica el nodo vigente.
- `ticket_etapas.id_ticket_etapa_padre` identifica una derivación; las etapas oficiales raíz no tienen padre.
- `ticket_etapas.id_gestor` es el gestor responsable del nodo.
- `tickets.id_tecnico` refleja al gestor del nodo actual para compatibilidad y consultas generales.
- Conversaciones y adjuntos se vinculan al ticket **y** a `id_ticket_etapa`; no se deben mezclar mensajes entre nodos.

### Reasignación manual por administrador

La reasignación en `solicitudes.php` debe:

1. Estar autorizada solamente para Administrador.
2. Operar sobre el nodo seleccionado: caso, etapa o derivación.
3. Cambiar `ticket_etapas.id_gestor` para ese nodo.
4. Cambiar también `tickets.id_tecnico` únicamente si el nodo reasignado es el actual.
5. Registrar el cambio en `solicitud_historial`.
6. Notificar al nuevo gestor.
7. No cambiar `servicios.id_gestor`; la asignación predeterminada del servicio permanece intacta.

---

## 10. Ciclo de vida de un ticket

```mermaid
stateDiagram-v2
    [*] --> EnProceso: solicitud creada
    EnProceso --> EnEspera: gestor solicita información
    EnEspera --> EnProceso: solicitante responde
    EnProceso --> Pausada: se crea derivación
    Pausada --> EnProceso: finaliza derivación
    EnProceso --> ListoCierre: gestor completa etapa
    ListoCierre --> EnProceso: solicitante reabre
    ListoCierre --> PendienteCalificacion: termina el flujo
    PendienteCalificacion --> Cerrado: solicitante califica
```

Estados de nodos encontrados: `bloqueada`, `pendiente`, `en_proceso`, `en_espera_solicitante`, `pausada`, `listo_cierre`, `completada`, `cancelada`.

Estados generales relevantes: `en_proceso`, `pendiente_calificacion`, `cerrado`.

Reglas:

- El gestor administra solamente nodos asignados o en los que participa; el Administrador posee lectura amplia y el Solicitante ve sus propios tickets.
- Una derivación pausa el nodo padre mientras se atiende el hijo, de acuerdo con el flujo implementado.
- El checklist, la conversación y los adjuntos pertenecen al nodo que se está gestionando.
- Un ticket cerrado debe seguir siendo consultable en modo histórico. “Gestionar etapa” en un nodo cerrado puede abrir una vista de solo lectura; no debe limitarse a recargar la lista.
- El cierre, reapertura, calificación y avance de etapa deben conservar historial.

### Automatización de inactividad de tickets

`app/services/automatizacionTickets.php` cierra después de 48 horas hábiles solamente tickets antiguos sin el flujo nuevo y sin respuesta. Excluye tickets gestionados por etapas. El ejecutable `scripts/cerrarTicketsInactivos.php` es solo CLI. No programe este script sin confirmar que la política de cierre automático continúa vigente.

---

## 11. Seguridad y controles técnicos

- Cookie de sesión: `MESA_SID`, `HttpOnly`, `SameSite=Lax` y `Secure` bajo HTTPS.
- Las operaciones autenticadas por POST usan token CSRF y validación de mismo origen.
- El inicio de sesión limita intentos mediante `seguridad_intentos_login`: cinco intentos en quince minutos generan bloqueo temporal de quince minutos.
- Se aplican CSP, `X-Frame-Options: SAMEORIGIN`, políticas sin caché y HSTS cuando se usa HTTPS.
- La descarga de adjuntos valida autorización en servidor.
- Los mensajes de error en producción no deben imprimir consultas, rutas, trazas ni credenciales.
- `display_errors` está desactivado en `public/.user.ini`; los errores se registran en servidor.
- La auditoría de sesiones registra operaciones POST exitosas; no registre secretos, contraseñas ni contenido sensible completo.

### Compatibilidad PHP

La base declarada es PHP 7.4. `app/helpers/compatibilidadPhp74.php` aporta compatibilidad para funciones concretas. Evite `enum`, tipos unión, argumentos nombrados, propiedades promovidas y demás sintaxis de PHP 8+, salvo que se eleve formalmente la plataforma y se pruebe todo el despliegue.

---

## 12. Apariencia y comportamiento compartido

- Las paletas se gestionan en `app/services/temasInterfaz.php` y preferencias en `usuario_preferencias_interfaz`.
- Botones de editar, eliminar e inhabilitar deben conservar significado en todas las paletas:
  - editar: lápiz visible y con contraste suficiente;
  - eliminar: caneca roja, con confirmación;
  - habilitar/inhabilitar: interruptor verde `ON` y rojo `OFF`.
- No use color como única señal: conserve texto `ON/OFF`, etiqueta accesible y título de acción.
- Las tablas anchas deben permitir desplazamiento horizontal accesible y visible sin depender de recargar con F5.
- Cualquier inicialización JavaScript de scroll, selectores dependientes o eventos debe ejecutarse también cuando el módulo se carga dentro del `iframe`, no solo en una carga directa.
- Evite “recuadros sobre recuadros” sin jerarquía; conserve tarjetas solamente cuando separen una decisión o grupo funcional real.

---

## 13. Matriz de modificación y eliminación

Antes de retirar datos, determine si se trata de desactivación, envío a papelera o eliminación definitiva.

| Entidad | Acción ordinaria | Acción definitiva | Condiciones y efecto histórico |
|---|---|---|---|
| Usuario | Habilitar/inhabilitar | No disponible en módulo normal | Conservar autoría, historial y tickets |
| Servicio | Habilitar/inhabilitar | No debe eliminarse desde operación normal | Los tickets históricos conservan su instantánea |
| Solución | Marcar activa/inactiva | Evitar borrado físico ordinario | Casos cerrados conservan la solución histórica |
| Área | Serializar en `papelera` y desactivar | Permitida desde papelera con confirmación | Puede retirar configuraciones futuras relacionadas; nunca borrar instantáneas de tickets |
| SLA | Serializar en `papelera` y desactivar | Bloquear si sigue asignado a servicios | Preservar vencimientos ya calculados |
| Festivo | Serializar en `papelera` y desactivar | Permitida con confirmación | No recalcular silenciosamente tickets históricos |
| Clasificación / nivel | Serializar y desactivar | Al borrar, anular referencias configurables según código | Preservar datos históricos ya copiados |
| Etapa de plantilla | La etapa base está protegida; posteriores pueden retirarse | Borrado físico solo en plantilla | No borrar `ticket_etapas` existentes |
| Checklist de plantilla | Editar o retirar de la plantilla | Borrado físico de plantilla | No borrar respuestas de tickets existentes |
| Ticket y evidencia | Cambiar estado conforme al flujo | No ofrecer eliminación física ordinaria | Conservar etapas, historial, mensajes, adjuntos y calificación |

### Procedimiento seguro para una eliminación nueva

1. Buscar claves foráneas, consultas, exportaciones y contadores relacionados.
2. Determinar si existen datos históricos o auditoría que dependan del registro.
3. Preferir estado inactivo o papelera recuperable.
4. Limitar por país y verificar el rol Administrador.
5. Ejecutar en transacción cuando intervengan varias tablas.
6. Registrar historial o auditoría antes de confirmar.
7. Eliminar archivos físicos únicamente después de confirmar la operación de base de datos y validar que no sean compartidos.
8. Probar restauración si existe papelera.

---

## 14. Recetas de cambio localizado

### Añadir un módulo

1. Crear la implementación en `app/modules/`.
2. Añadir la ruta a `app/routes.php`.
3. Crear el shim correspondiente en `public/` usando `_entry.php`.
4. Añadirlo al menú de los roles autorizados en el shell.
5. Revisar listas de rutas permitidas, auditoría, navegación y retorno al panel.
6. Probar acceso directo, acceso por `iframe`, volver/avanzar y cierre de sesión.

### Cambiar un formulario o una acción POST

1. Identificar el nombre exacto de los campos usados por HTML y PHP.
2. Mantener CSRF, validación de rol, país y autorización sobre el registro.
3. Usar transacción si cambia más de una tabla.
4. Conservar el valor de texto correcto; no convertir nombres a entero por una vinculación `bind_param` equivocada.
5. Mostrar un mensaje útil al usuario y registrar detalles técnicos solamente en el log.

### Cambiar la base de datos

1. Crear una migración SQL repetible y versionada antes del despliegue.
2. Incluir índice para claves de país, ticket, etapa, estado y fechas consultadas con frecuencia.
3. Actualizar consultas, exportaciones, papelera y restauración.
4. Mantener compatibilidad temporal si producción puede ejecutar código y esquema de versiones distintas durante el despliegue.
5. Actualizar este archivo con la nueva tabla, columna o relación.

### Retirar una funcionalidad

1. Buscar referencias en `index.php`, `app/routes.php`, `public/`, `app/modules/`, servicios y JavaScript.
2. Retirar primero enlaces y permisos, luego la ruta y finalmente la implementación.
3. No borrar tablas ni datos en el mismo despliegue salvo migración aprobada y respaldo comprobado.
4. Conservar una ruta controlada o mensaje claro si existen marcadores antiguos.

### Modificar tickets o flujos

1. Revisar primero `app/services/motorFlujos.php`.
2. Diferenciar plantilla (`proceso_*`) de instancia (`ticket_*`).
3. Probar caso principal, derivación, reapertura y caso cerrado.
4. Verificar conversación, adjuntos, historial, notificaciones y vencimiento SLA.

---

## 15. Producción: requisitos y verificaciones

### Plataforma

- Apache con `mod_rewrite` y `AllowOverride` habilitados.
- PHP 7.4 o versión explícitamente validada.
- Extensiones: `mysqli`, `fileinfo`, `curl` y `ZipArchive`; `mbstring` recomendada.
- MySQL/MariaDB con `utf8mb4`.
- HTTPS obligatorio.
- Permisos de escritura únicamente sobre almacenamiento privado, sesiones y registros necesarios.
- Salida HTTPS hacia n8n y conexión TCP autorizada hacia las bases principal y de personal.

### Respaldo

Respaldar conjuntamente:

- base de datos principal;
- `mds_storage/`;
- configuración o flujo de n8n por separado.

Un ZIP del código no es respaldo de los tickets ni de sus adjuntos.

### Prueba de humo mínima

- Inicio y cierre de sesión en los tres roles.
- Una sola alerta de inactividad; “Sigo en línea” detiene el cierre y reinicia el tiempo.
- Cambio de país como Administrador y aislamiento de datos.
- Creación de usuario con coincidencia, sin coincidencia y con persona inactiva en Uniclass.
- Creación/edición/inactivación de área, servicio, solución, flujo, SLA, festivo y opciones.
- Creación de caso por Solicitante.
- Gestión de etapa, checklist, derivación, mensaje y adjunto por Gestor.
- Consulta, descarga, exportación y reasignación manual por Administrador.
- Cierre, calificación y reapertura por Solicitante.
- Consulta en solo lectura de un caso cerrado por Gestor.
- Restauración desde papelera.
- Paletas clara, oscura y blanco/negro con iconos legibles.
- Navegación entre módulos sin F5, con URL pública estable.

---

## 16. Hallazgos pendientes antes de producción

### P0 — Secretos integrados en el código

La versión inspeccionada contiene valores de conexión y secretos configurados directamente en `app/config/conexion.php`. Antes de producción:

1. mover todos los valores sensibles a variables de entorno o al almacén de secretos del servidor;
2. dejar en el código únicamente lectura de variables y valores seguros no sensibles;
3. rotar las credenciales y secretos que hayan sido incluidos en archivos ZIP o compartidos;
4. confirmar que errores y diagnósticos no los impriman.

### P1 — Archivos de ejecución o desarrollo dentro del paquete

Se encontraron artefactos locales como base/eventos de `.n8n`, registros de error y configuración de editor o transferencia. Deben excluirse del paquete de producción salvo necesidad documentada. No se deben publicar bases SQLite, logs ni archivos con configuración de despliegue.

### P1 — README y verificador desactualizados

El `README.md` y `scripts/verificarEstructura.php` hacen referencia a archivos de instalación, migraciones y ejemplo de configuración que no están incluidos en esta versión. Hasta corregirlos:

- no considere que el verificador representa fielmente la estructura actual;
- no ejecute instrucciones de instalación inexistentes;
- genere y versione las migraciones reales antes de depender de un despliegue desde cero.

### P1 — Decisión de concurrencia de sesión

El código permite varias sesiones a Administrador y Gestor, y aplica sesión única a Solicitante. Confirmar formalmente si esa es la política deseada. Una modificación debe incluir pruebas con dos navegadores y verificar que no reaparezcan alertas duplicadas.

### P1 — Esquema reproducible

El paquete no presenta una fuente completa y vigente para reconstruir la base desde cero. Antes de considerar el software mantenible, debe existir un esquema base y migraciones numeradas, sin datos ni secretos de producción.

---

## 17. Definición de terminado para cualquier cambio

Un cambio no está terminado hasta cumplir lo aplicable:

- sintaxis PHP válida en los archivos afectados;
- consultas parametrizadas y sin secretos expuestos;
- validación de rol, país, CSRF y pertenencia del recurso;
- transacción y reversión en operaciones múltiples;
- historial/auditoría conservados;
- plantillas no alteran instantáneas históricas;
- adjuntos permanecen privados;
- interfaz funciona dentro del `iframe` sin F5;
- prueba en paletas clara, oscura y blanco/negro;
- prueba de caso activo, derivado y cerrado cuando se toca el flujo;
- no se entregan archivos ajenos al cambio;
- este documento se actualiza si cambió el modelo mental del sistema.

---

## 18. Registro de cambios técnicos

Mantenga entradas breves. No registre contraseñas, tokens, datos personales ni información de casos.

| Fecha | Cambio | Archivos / tablas afectados | Invariantes verificadas |
|---|---|---|---|
| 2026-09-11 | Creación de la memoria técnica para IA a partir del código entregado | `docs/CONTEXTO_IA_MESA_SERVICIO.md` | Arquitectura, conexiones, roles, país, flujo, eliminación y producción |
| 2026-09-11 | Endurecimiento previo a producción: secretos fuera del código, reglas Apache, archivos privados, cargas de imagen y descarga de adjuntos | `app/config/conexion.php`, `.htaccess`, `public/.htaccess`, `public/.user.ini`, módulos de archivos | País, roles, CSRF, almacenamiento privado y funciones existentes |

Formato para futuras entradas:

```text
AAAA-MM-DD | Qué cambió y por qué | Rutas/tablas | País, permisos, historial, instantáneas y pruebas verificadas
```
