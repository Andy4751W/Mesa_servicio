# Seguridad y despliegue de producción

Este archivo contiene las acciones externas al código que deben completarse antes de publicar la Mesa de Servicio. No incluya aquí valores reales.

## 1. Acción obligatoria: rotar secretos

La versión recibida para revisión contenía credenciales integradas. Aunque fueron retiradas del código corregido, deben considerarse expuestas por haber circulado en un archivo comprimido.

Rote antes del despliegue:

- contraseña de la base principal;
- contraseña de la fuente Uniclass;
- secreto del webhook de n8n;
- secreto o *pepper* de recuperación de contraseña;
- cualquier credencial almacenada en herramientas de transferencia o automatización incluidas anteriormente.

## 2. Configurar el servidor

Use variables de entorno del servidor:

```text
MESA_ENV=production
MESA_FORCE_HTTPS=1
MESA_ENABLE_DIAGNOSTICS=0
MESA_DB_HOST
MESA_DB_PORT
MESA_DB_NAME
MESA_DB_USER
MESA_DB_PASSWORD
MESA_STORAGE_PATH
MESA_N8N_WEBHOOK_URL
MESA_N8N_WEBHOOK_SECRET
MESA_RECOVERY_PEPPER
MESA_FUENTE_DB_HOST
MESA_FUENTE_DB_PORT
MESA_FUENTE_DB_NAME
MESA_FUENTE_DB_USER
MESA_FUENTE_DB_PASSWORD
```

Alternativa: copie `app/config/configuracion.ejemplo.php` fuera de `public/` y del repositorio, restrinja sus permisos al usuario de PHP y defina `MESA_CONFIG_FILE` con su ruta absoluta.

## 3. No reemplazar datos con el ZIP del código

- Conserve el `mds_storage` real del servidor.
- Despliegue el código sin adjuntos, imágenes de perfiles ni archivos temporales del paquete de desarrollo.
- Respalde base de datos y almacenamiento privado antes del cambio.
- No publique `.n8n`, `.vscode`, archivos SQLite, logs, cachés ni configuraciones de transferencia.

## 4. Verificación después del despliegue

1. Confirme HTTPS y que la cookie `MESA_SID` tenga `Secure`, `HttpOnly` y `SameSite=Lax`.
2. Verifique que `/.user.ini`, `/error_log`, archivos `.log`, `.sqlite` y de configuración respondan 403 o 404.
3. Compruebe que `app/`, `docs/`, `scripts/` y `mds_storage/` no sean navegables.
4. Pruebe inicio de sesión, recuperación, inactividad y cierre para los tres roles.
5. Pruebe aislamiento Colombia/Perú.
6. Cargue JPG, PNG y WebP válidos; rechace extensiones y dimensiones no permitidas.
7. Descargue adjuntos autorizados y confirme 403 con otro usuario o país.
8. Mantenga diagnósticos deshabilitados en producción.

## 5. Limitación de esta revisión

La revisión estática reduce riesgos identificables en el código entregado, pero no certifica ausencia absoluta de vulnerabilidades. Antes de publicar se requieren pruebas con PHP 7.4, Apache y una copia anonimizada de la base, además de revisión de permisos y configuración del servidor.
