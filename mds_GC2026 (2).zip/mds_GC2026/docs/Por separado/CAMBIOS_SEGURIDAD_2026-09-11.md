# Cambios de seguridad — 2026-09-11

## Archivos modificados

| Archivo | Cambio |
|---|---|
| `app/config/conexion.php` | Eliminación de credenciales integradas; carga desde entorno o archivo privado; rechazo de configuración dentro de `public/` |
| `app/config/configuracion.ejemplo.php` | Plantilla segura sin valores reales |
| `.htaccess` | Bloqueo de archivos sensibles y métodos TRACE/TRACK |
| `public/.htaccess` | Bloqueo de archivos ocultos, logs, respaldos, configuraciones y datos locales |
| `public/.user.ini` | Sesiones solo por cookie y mayor entropía del identificador |
| `.gitignore` | Exclusión de archivos locales, registros, bases SQLite y configuraciones de desarrollo |
| `app/modules/catalogos/editarcatalogos.php` | Validación de dimensiones y formatos de imágenes de áreas |
| `app/modules/tickets/descargarAdjunto.php` | Verificación del MIME físico y política de contenido aislado |
| `app/modules/auth/logout.php` | Protección contra cierre de sesión iniciado desde otro sitio |
| `docs/CONTEXTO_IA_MESA_SERVICIO.md` | Registro del endurecimiento realizado |
| `docs/SEGURIDAD_DESPLIEGUE_PRODUCCION.md` | Requisitos externos indispensables para publicar |

## Contenido retirado del paquete de entrega

El ZIP de entrega no contiene `.n8n/`, `.vscode/`, registros de errores, cachés, bases SQLite ni datos existentes de `mds_storage/`. La carpeta `mds_storage/` conserva solamente su protección `.htaccess`; los datos reales deben permanecer en el servidor y respaldarse por separado.

## Validación realizada

- Correspondencia completa entre las entradas PHP de `public/` y `app/routes.php`.
- Búsqueda de secretos conocidos sin coincidencias en el código entregable.
- Revisión estática de roles, CSRF, país, consultas SQL y acceso a adjuntos en los módulos críticos.
- Comprobación de integridad del ZIP después de generarlo.

## Validación todavía obligatoria en servidor

El entorno de revisión no incluye el binario PHP. Antes de producción ejecute:

```bash
find . -type f -name '*.php' -print0 | xargs -0 -n1 php -l
```

Después realice la prueba de humo definida en `docs/SEGURIDAD_DESPLIEGUE_PRODUCCION.md` con PHP 7.4, Apache y una copia anonimizada de la base.
