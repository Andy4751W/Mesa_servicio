# Ajuste de sincronización FTP — 2026-09-16

## Alcance
Este paquete conserva la aplicación sin modificaciones. Únicamente ajusta
.vscode/sftp.json y añade este documento. No es una reparación confirmada del
servidor ni de la extensión SFTP instalada en Windows.

## Evidencia
El registro del 16 de septiembre confirma autenticación (230) y diez listados
de la raíz completados (226). Después de PASV se anuncia el puerto 50332
(196*256+156). No aparece el siguiente LIST y diez segundos después se envía
ABOR. No aparece STOR en ese intento. No se puede atribuir la causa únicamente
al servidor, a la red o a la extensión con ese registro.

## Cambios aplicados
- concurrency: 1, para reducir operaciones simultáneas.
- connectTimeout: 30000, para ampliar la espera de conexión.
- ignore: excluye configuración del editor, control de versiones, datos internos
  de n8n, herramientas locales, cuota FTP y registros/cachés de ejecución.
- syncOption.delete: false, para no borrar archivos remotos ajenos a la copia.
- Se conservan host, usuario, contraseña, puerto, protocolo, ruta remota y
  uploadOnSave del ZIP original. No se incorpora watcher.
- Se conserva la elección FTP original, sin introducir excepciones de certificado.
  Esta conexión original no cifra las credenciales. Para FTPS, el hosting debe
  proporcionar un nombre compatible con su certificado; no desactive la validación.
- No se excluyen app, public, n8n (sin punto), docs, scripts, database ni
  mds_storage. Los archivos locales con rutas coincidentes pueden sobrescribir
  archivos remotos: use una copia actualizada antes de sincronizar.

## Uso en el computador
1. Conserve una copia de su carpeta de trabajo actual.
2. Extraiga el ZIP en una carpeta nueva y abra mds_GC2026 en VS Code.
   Alternativamente, copie solamente .vscode/sftp.json sobre la configuración
   del proyecto original si contiene cambios posteriores a este ZIP.
3. Deje habilitada una sola extensión que proporcione los comandos SFTP.
4. Cancele transferencias pendientes y ejecute Developer: Reload Window.
5. Ejecute SFTP: Sync Local To Remote. Se conserva ese flujo de trabajo.
6. Verifique que Salida muestre la configuración nueva (concurrency 1,
   connectTimeout 30000 y la lista ignore).

## Límite y siguiente diagnóstico
Estos mismos límites de concurrencia/tiempo ya se habían probado antes sin
resolver de forma concluyente el bloqueo. Las exclusiones reducen el trabajo,
pero no reparan conexiones pasivas fallidas. Si vuelve a detenerse después de
PASV, no aumente tiempos indefinidamente ni cambie PHP. Compare el mismo listado
de carpetas con FileZilla y solicite al hosting correlacionar la sesión con sus
registros, puertos pasivos y límites por usuario/IP. Que un archivo se transfiera
no demuestra que toda la sincronización funcione.

## Validación realizada
JSON analizado, integridad ZIP comprobada y comparación byte a byte de todos
los archivos originales: sólo cambia .vscode/sftp.json. No se hicieron accesos
al servidor ni pruebas de producción. La sincronización completa sigue pendiente
de validación desde el computador afectado.
