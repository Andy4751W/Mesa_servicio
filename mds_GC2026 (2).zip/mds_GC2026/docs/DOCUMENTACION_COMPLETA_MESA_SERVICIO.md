# Documentación completa — Mesa de Servicio Conectar

> Documento maestro para dirección, TIC y mantenimiento. Explica cómo se conecta, navega y opera la Mesa de Servicio, qué componentes intervienen y dónde se conserva la información. No contiene credenciales, secretos ni datos personales.

| Control | Valor |
|---|---|
| Sistema | Mesa de Servicio Conectar |
| Versión inspeccionada | `mds_GC2026_corregido.zip` |
| Esquema contrastado | `mds_GC2026(1).sql` |
| Fecha documental | 2026-09-15 |
| Plataforma | PHP 7.4+, Apache, MySQL/MariaDB, JavaScript, HTML y CSS |
| Base principal | `mds_GC2026` |
| Fuente externa de personal | `SRCGC.mae_data_uniclass` y `SRCGC.mae_ciudades` |
| Automatización de correo | n8n + Microsoft 365 |
| Tipo de documento | Fuente única de arquitectura, operación, rutas, tablas, integraciones, seguridad y mantenimiento |

## 1. Finalidad y alcance

La Mesa de Servicio permite:

- administrar usuarios, países de operación, áreas, servicios, soluciones, flujos, SLA, festivos y listas configurables;
- crear solicitudes y convertir la configuración vigente del servicio en un flujo ejecutable;
- asignar etapas y derivaciones a gestores;
- conservar conversaciones, adjuntos, listas de chequeo, historial, notificaciones y calificaciones;
- consultar indicadores administrativos y exportar la trazabilidad;
- controlar sesiones, permisos, país operativo y preferencias de interfaz;
- enviar recuperación de contraseña y avisos de tickets mediante n8n y Microsoft 365.

Este documento describe el software observado. El código actual y el esquema SQL actual son la fuente de verdad si existiera una diferencia con documentación histórica.

## 2. Arquitectura general

```mermaid
flowchart TD
    U["Usuario"] --> I["index.php · acceso y shell"]
    I --> P["public/*.php · entradas"]
    P --> E["public/_entry.php"]
    E --> R["app/routes.php"]
    R --> M["app/modules/*"]
    M --> C["app/core/*"]
    C --> DB["MySQL · mds_GC2026"]
    C --> UX["Uniclass · SRCGC"]
    C --> N8["n8n · Microsoft 365"]
    C --> ST["Microsoft Graph · Mds_Storage"]
    C -. lectura histórica .-> LS["mds_storage"]
```

### Recorrido de una petición

1. `index.php` procesa el acceso y mantiene la estructura visual general.
2. El usuario selecciona un módulo; el shell carga una entrada de `public/`.
3. La entrada pública carga `public/_entry.php`.
4. `_entry.php` consulta el mapa canónico de `app/routes.php`.
5. Se ejecuta el archivo funcional ubicado en `app/modules/` o `app/security/`.
6. El módulo reutiliza reglas compartidas de `app/core/`.
7. La información se consulta o modifica en la base principal, Uniclass, n8n o Microsoft Graph. `mds_storage` queda únicamente como lectura compatible de archivos históricos.

Las páginas internas se muestran dentro del shell estable. Por eso una función puede depender simultáneamente de `index.php`, una entrada pública, `app/routes.php`, un módulo, uno o varios componentes de `app/core/` y sus tablas.

## 3. Estructura del proyecto

La versión inspeccionada tiene dos lecturas diferentes: la **estructura física del ZIP**, que incluye todo lo encontrado, y la **estructura funcional desplegable**, que contiene lo necesario para ejecutar la aplicación. La tabla anterior confundía ambas; el inventario corregido es el siguiente.

### 3.1 Estructura física encontrada en la raíz

| Ruta o archivo | Existe en el ZIP | Clasificación | Responsabilidad o decisión |
|---|---:|---|---|
| `index.php` | Sí | Aplicación | Acceso, shell, menú por rol, campana, historial visual y contenedor de módulos |
| `.htaccess` | Sí | Producción | Reescritura y protección de rutas |
| `.gitignore` | Sí | Desarrollo | Exclusiones para control de versiones; no interviene en ejecución |
| `README.md` | Sí | Documentación | Índice corto hacia este documento maestro |
| `app/` | Sí | Aplicación privada | Arranque, rutas, configuración, seguridad, módulos y núcleo de negocio |
| `public/` | Sí | Superficie web | 47 PHP en el primer nivel, recursos estáticos y protecciones de cargas heredadas |
| `mds_storage/` | Sí | Datos históricos | Archivos anteriores a Graph; se conserva para lectura y no recibe nuevas cargas con el driver remoto activo |
| `database/` | Sí | Esquema | Migración auditable `007_almacenamiento_graph.sql`; la aplicación también crea la tabla al efectuar la primera carga |
| `n8n/` | Sí | Integración/desarrollo | Dos flujos exportables y seis archivos para ambiente local |
| `scripts/` | Sí | Mantenimiento | Tres scripts PHP y un `.htaccess` de protección |
| `docs/` | Sí | Documentación privada | `.htaccess` y `DOCUMENTACION_COMPLETA_MESA_SERVICIO.md` |
| `.n8n/` | Sí | Artefacto local sensible | Estado local, base SQLite y registros de n8n; no debe publicarse ni incluirse en una entrega de producción |
| `.vscode/` | Sí | Configuración local sensible | Configuración del editor/transferencia; debe excluirse de producción |
| `.qodo/` | Sí | Desarrollo | Carpetas de herramienta sin función en producción |
| `.ftpquota` | Sí | Hosting/runtime | Archivo del entorno de alojamiento; no pertenece al código fuente desplegable |
| `.phpunit.result.cache` | Sí | Caché de pruebas | No pertenece a producción |
| `error_log` | Sí | Registro runtime | Puede contener rutas o errores; no debe distribuirse ni publicarse |

### 3.2 Desglose funcional de `app/`

| Ruta | Contenido confirmado | Responsabilidad |
|---|---:|---|
| `app/bootstrap.php` | 1 archivo | Constantes `PROJECT_ROOT`, `APP_ROOT`, `PUBLIC_ROOT`, zona horaria y compatibilidad PHP 7.4 |
| `app/routes.php` | 1 archivo | Mapa canónico de las 46 entradas públicas |
| `app/.htaccess` | 1 archivo | Bloqueo de acceso web directo a la aplicación privada |
| `app/config/` | 1 archivo | Conexión principal y configuración consumida por Uniclass y n8n |
| `app/components/` | 1 archivo | Controles de cuenta, navegación y notificaciones compartidas |
| `app/core/` | 17 archivos | Reglas transversales: almacenamiento Graph, flujos, SLA, país, chat, correo, Uniclass, sesiones, papelera, perfil, temas y ubicación |
| `app/security/` | 3 archivos | Cabeceras, CSRF, roles, sesión autenticada e inactividad |
| `app/modules/admin/` | Módulos PHP | Usuarios, centro de control, sesiones, configuración y papelera |
| `app/modules/auth/` | Módulos PHP | Login, logout y recuperación de contraseña |
| `app/modules/catalogos/` | Módulos PHP | Áreas, servicios, soluciones e imágenes de áreas |
| `app/modules/notificaciones/` | Módulo PHP | Apertura y marcado de notificaciones |
| `app/modules/perfil/` | Módulos PHP | Perfil, fotografía y apariencia |
| `app/modules/reportes/` | Módulo PHP | Indicadores administrativos |
| `app/modules/sistema/` | Módulos PHP | Verificaciones técnicas condicionadas por diagnóstico |
| `app/modules/sla/` | Módulos PHP | SLA, festivos y verificación de calendario |
| `app/modules/tickets/` | Módulos PHP | Creación, consulta, flujo, mensajería, adjuntos, exportación y asignación |

### 3.3 Desglose funcional de `public/`

| Ruta | Contenido confirmado | Responsabilidad |
|---|---:|---|
| `public/_entry.php` | 1 despachador | Carga bootstrap, resuelve `app/routes.php` y ejecuta la implementación |
| `public/*.php` | 46 entradas mapeadas | Puentes mínimos hacia los módulos; el inventario individual está en el capítulo 13 |
| `public/assets/images/` | 1 SVG | Imagen predeterminada de área |
| `public/assets/img/` | 2 imágenes | Logos de interfaz |
| `public/assets/js/` | 2 scripts | `controlSesion.js` y `estadoToggle.js` |
| `public/uploads/` | 2 archivos `.htaccess` | Protección de rutas de carga heredadas; los archivos vigentes se sirven desde almacenamiento privado |

### 3.4 Carpetas de soporte

| Ruta | Contenido confirmado | Uso |
|---|---:|---|
| `mds_storage/catalogos/` | Archivos históricos | Imágenes de áreas anteriores a Graph |
| `mds_storage/perfiles/` | Archivos históricos | Imágenes de usuarios anteriores a Graph |
| `mds_storage/solicitudes/` | Archivos históricos | Adjuntos anteriores a Graph |
| `database/migrations/007_almacenamiento_graph.sql` | 1 migración | Definición auditable de `storage_objetos` |
| `n8n/*.json` | 2 flujos | Recuperación y notificaciones por correo |
| `n8n/local/` | 6 archivos | Ambiente local con scripts, Docker y plantilla de variables |
| `scripts/cerrarTicketsInactivos.php` | 1 script | Automatización CLI de casos antiguos compatibles |
| `scripts/migrarArchivosPrivados.php` | 1 script | Migración controlada de archivos |
| `scripts/verificarEstructura.php` | 1 script | Verificación estática de estructura |
| `docs/DOCUMENTACION_COMPLETA_MESA_SERVICIO.md` | 1 documento | Fuente documental única |

### 3.5 Estructura que debe llegar a producción

La publicación debe incluir únicamente el código necesario (`index.php`, `.htaccess`, `app/`, `public/`, `database/`, `n8n/` cuando se administren allí los flujos, `scripts/` solo para tareas autorizadas y `docs/` protegido). `mds_storage/` se conserva mientras existan referencias históricas locales y no se reemplaza al actualizar código. Deben excluirse `.n8n/`, `.qodo/`, `.vscode/`, `.ftpquota`, `.phpunit.result.cache`, logs y cualquier caché. `app/config/graph-client-secret.local` es configuración privada de despliegue: nunca debe quedar accesible por HTTP ni incorporarse al control de versiones.

## 4. Conexiones e integraciones

### 4.1 Base de datos principal

| Elemento | Implementación |
|---|---|
| Motor | MySQL/MariaDB mediante `mysqli` |
| Archivo central | `app/config/conexion.php` |
| Base lógica | `mds_GC2026` |
| Codificación | `utf8mb4` |
| Tiempo máximo inicial | 5 segundos para conexión |
| Zona horaria de PHP | `America/Bogota` |
| Zona de la conexión | UTC-05:00 |
| Objeto compartido | `$conn` |

Los módulos cargan `app/security/validarSesion.php`; este componente termina cargando la conexión principal. Las operaciones sensibles utilizan sesión, rol, país y, para formularios POST, token CSRF.

**Hallazgo de producción:** la versión inspeccionada incluye valores sensibles integrados dentro de `app/config/conexion.php`. Aunque se omiten de esta documentación, deben considerarse secretos expuestos y trasladarse a variables de entorno o a un archivo privado no versionado. Se deben rotar antes de producción. Este hallazgo es P0 porque compromete las dos bases y la integración de correo.

### 4.2 Fuente externa de personal Uniclass

| Elemento | Implementación |
|---|---|
| Servicio | `app/core/fuentePersonal.php` |
| Base | `SRCGC` |
| Tabla de personal | `mae_data_uniclass` |
| Llave de búsqueda | `identificacion` |
| Estado laboral | `EST` |
| Normalización de ciudad | `mae_ciudades` |
| Consumidor principal | `app/modules/admin/crearUsuarios.php` |

Mapeo confirmado:

| Campo de la Mesa | Columna Uniclass |
|---|---|
| `usuarios.cedula` | `mae_data_uniclass.identificacion` |
| `usuarios.nombre` | `apellidos_y_nombres` |
| `usuarios.email` | `correo_electronico` |
| `usuarios.empresa` | `emp` |
| `usuarios.proceso` | `CU_Proceso` |
| `usuarios.cu1` | `UNIDAD_1_COD` |
| `usuarios.descripcion_cu1` | `UNIDAD_1_DESCRIP` |
| `usuarios.cu3` | `UNIDAD_3_COD` |
| Departamento inicial | `CU_Regional`, ajustado con `mae_ciudades` |
| Ciudad | `CIUDAD` o `ciudad`, ajustada con `mae_ciudades` |

Regla laboral confirmada:

- se consultan todos los registros con la misma `identificacion`;
- `EST` se evalúa como `UPPER(TRIM(EST))`;
- si existe al menos una fila `A`, la persona es activa y solo una fila activa puede autocompletar;
- si hay varias filas activas, se prioriza la fecha disponible y luego el ID más alto;
- si todas las filas son `R`, la persona se considera retirada, no se arrastran datos y se bloquea su creación;
- si la persona no existe o la fuente no responde, el administrador conserva el diligenciamiento manual.

La validación se ejecuta al consultar la cédula y vuelve a ejecutarse antes de insertar el usuario. Esto evita depender únicamente del JavaScript.

### 4.3 n8n y Microsoft 365

| Elemento | Implementación |
|---|---|
| Adaptador | `app/core/correoN8n.php` |
| Transporte | HTTPS POST con JSON |
| Autenticación | Encabezado privado `X-Mesa-Secret` |
| Eventos principales | Recuperación de contraseña y actualización de ticket |
| Flujos | `n8n/recuperacion_password_local_mailpit.json` y `n8n/recuperacion_password_microsoft365.json` |

La aplicación prepara el destinatario, asunto y HTML. n8n se autentica con Microsoft 365 y realiza el envío. Las notificaciones informativas no revierten una operación del ticket si falla el correo. La recuperación de contraseña sí espera confirmación porque el envío forma parte del proceso de seguridad.

### 4.4 Almacenamiento Microsoft Graph

El driver activo es `graph`. `app/core/almacenamiento.php` obtiene un token de aplicación, opera únicamente sobre la raíz corporativa `Mds_Storage` y conserva en MySQL el `driveItem.id` y los metadatos de cada objeto. El token y las URLs temporales nunca se envían al navegador.

| Contenido nuevo | Ruta remota lógica | Acceso desde MDS |
|---|---|---|
| Imágenes de áreas | `catalogos/{CO|PE}/` | `imagenCatalogo.php`, después de validar sesión y país |
| Imágenes de perfil | `perfiles/{CO|PE}/{usuario-id}/` | `imagenPerfil.php`, después de validar usuario, rol y país |
| Adjuntos de solicitudes | `adjuntos/{CO|PE}/{ticket-id}/{etapa-id}/` | `descargarAdjunto.php`, después de validar ticket, etapa, participante, rol y país |

`storage_objetos` conserva proveedor, entidad, país, `drive_id`, `item_id`, ruta lógica, nombre opaco, MIME, tamaño, SHA-256 y estado. `solicitud_adjuntos.ruta` y `catalogos.imagen` guardan una referencia estable `graph:<item-id>`. La aplicación crea `storage_objetos` automáticamente en la primera carga Graph; la definición equivalente está en `database/migrations/007_almacenamiento_graph.sql`.

`MESA_STORAGE_PATH` y `mds_storage/` continúan disponibles únicamente para leer imágenes y adjuntos históricos. Las nuevas cargas no se duplican localmente ni utilizan fallback silencioso al servidor si Graph falla: la operación muestra error y no confirma una referencia inexistente.

## 5. Identidad, roles, país y sesiones

| Rol | ID | Alcance funcional |
|---|---:|---|
| Administrador | 1 | Configuración, usuarios, tickets, trazabilidad, indicadores, sesiones y reasignación |
| Gestor | 2 | Indicadores propios, etapas asignadas, derivaciones, checklist, conversación y adjuntos |
| Solicitante | 3 | Creación y consulta de casos propios, conversación, reapertura y calificación |

`paises_operacion` separa Colombia y Perú. `id_pais_operacion` aparece en usuarios, áreas, servicios, procesos, SLA, festivos y tickets. Toda operación administrativa debe limitarse al país activo. El administrador puede seleccionar el contexto; los demás usuarios permanecen asociados a su país.

La sesión combina:

- sesión PHP y cookie `MESA_SID`;
- identidad y rol en `usuarios`;
- registro operativo en `sesiones_usuario`;
- países visitados en `sesiones_usuario_paises`;
- presencia de chat en `chat_usuario_presencia`;
- auditoría POST en `auditoria_sesiones`.

La advertencia de inactividad debe ejecutarse una sola vez en el shell principal. Duplicarla dentro del módulo cargado produce dos ventanas y dos contadores.

## 6. Módulos funcionales

### Administración

| Módulo | Ruta visible | Tablas principales |
|---|---|---|
| Centro de control | `panelAdmin.php` / `sesiones.php` | `sesiones_usuario`, `sesiones_usuario_paises`, `auditoria_sesiones`, `usuarios`, `roles` |
| Tickets | `solicitudes.php` | `tickets`, `ticket_etapas`, `usuarios`, `solicitud_historial` y evidencia relacionada |
| Usuarios | `crearUsuarios.php`, `editarUsuario.php` | `usuarios`, `roles`, `paises_operacion`, `configuraciones_servicio`; consulta externa a Uniclass |
| Indicadores | `indicadores.php` | `tickets`, `ticket_etapas`, `usuarios`, `servicios`, `catalogos`, `procesos`, `solicitud_calificaciones` |
| Áreas | `catalogos.php`, `editarcatalogos.php` | `catalogos`, `papelera` |
| Servicios | `servicios.php` | `servicios`, `catalogos`, `sla`, `usuarios`, `configuraciones_servicio` |
| Soluciones | `soluciones.php` | `soluciones_servicio`, `servicios`, `catalogos`, `ticket_etapas` |
| Flujos | `procesos.php` | `procesos`, `proceso_etapas`, `proceso_etapa_checklist`, `servicios`, `usuarios`, `sla` |
| SLA | `sla.php` | `sla`, `servicios`, `papelera` |
| Festivos | `feriados.php` | `feriados`, `usuarios`, `papelera` |
| Listas configurables | `configuraciones.php` | `configuraciones_servicio`, `servicios`, `papelera` |
| Papelera | `papelera.php` | `papelera` y las tablas restauradas |

### Gestor

| Módulo | Ruta | Tablas principales |
|---|---|---|
| Mis indicadores | `panelGestor.php` | `ticket_etapas`, `tickets`, `solicitud_calificaciones` |
| Casos asignados | `flujoTicket.php?modo=mis_tickets` | `tickets`, `ticket_etapas`, checklist, comunicaciones, adjuntos e historial |
| Mensajes | `mensajes.php` + `mensajesApi.php` | `solicitud_comunicaciones`, `solicitud_adjuntos`, `chat_conversacion_estado`, `notificaciones` |

### Solicitante

| Módulo | Ruta | Tablas principales |
|---|---|---|
| Crear solicitud | `panelSolicitante.php?vista=nueva` | `catalogos`, `servicios`, `procesos`, `proceso_etapas`, `tickets`, `ticket_etapas` |
| Estado de solicitudes | `panelSolicitante.php?vista=tickets` | `tickets`, `ticket_etapas`, `solicitud_calificaciones` |
| Conversación | `mensajes.php`, `mensajesApi.php` | `solicitud_comunicaciones`, `solicitud_adjuntos`, `chat_conversacion_estado` |

## 7. Ciclo completo de un ticket

```mermaid
stateDiagram-v2
    [*] --> EnProceso: crear solicitud
    EnProceso --> EnEspera: solicitar información
    EnEspera --> EnProceso: responder
    EnProceso --> Pausada: crear derivación
    Pausada --> EnProceso: cerrar derivación
    EnProceso --> ListoCierre: completar gestión
    ListoCierre --> EnProceso: reabrir
    ListoCierre --> PendienteCalificacion: finalizar flujo
    PendienteCalificacion --> Cerrado: calificar
```

### 7.1 Configuración previa

1. El administrador crea el área en `catalogos`.
2. Configura SLA en `sla` y parámetros en `configuraciones_servicio`.
3. Crea el servicio en `servicios`, incluyendo gestor predeterminado.
4. Define el flujo en `procesos`.
5. Agrega etapas en `proceso_etapas` y checklist en `proceso_etapa_checklist`.
6. Opcionalmente crea soluciones futuras en `soluciones_servicio`.

El proceso informado en `usuarios.proceso` no limita al gestor. Un gestor puede asignarse a servicios de diferentes procesos.

### 7.2 Creación

1. El solicitante selecciona un área activa y un servicio activo de su país.
2. `panelSolicitante.php` delega en `flujoCrearTicket()` de `app/core/motorFlujos.php`.
3. Se inserta la cabecera en `tickets`.
4. La plantilla de `proceso_etapas` se copia a `ticket_etapas`.
5. El checklist de plantilla se copia a `ticket_etapa_checklist`.
6. Se activa el primer nodo y se calculan sus fechas con `calendarioLaboral.php`, `sla` y `feriados`.
7. Se registra historial y se notifica al responsable.

La copia de plantilla a instancia es una fotografía histórica: modificar después un servicio o flujo no debe cambiar tickets existentes.

### 7.3 Gestión

- `tickets.id_etapa_actual` apunta al nodo vigente.
- `ticket_etapas.id_gestor` identifica al gestor responsable de cada nodo.
- `tickets.id_tecnico` refleja al gestor del nodo actual para consultas generales.
- una derivación usa `ticket_etapas.id_ticket_etapa_padre` y pausa el nodo padre;
- checklist, mensajes y adjuntos se asocian a `id_ticket_etapa` para no mezclar nodos;
- el historial se registra en `solicitud_historial`;
- las notificaciones internas se guardan en `notificaciones` y las preferencias de correo en `ticket_notificaciones_email_preferencias`.

### 7.4 Reasignación administrativa

El administrador puede reasignar el caso, una etapa o una derivación específica. La operación cambia `ticket_etapas.id_gestor`; también cambia `tickets.id_tecnico` solo cuando se reasigna el nodo actual. Debe registrar `solicitud_historial` y notificar al nuevo gestor. Nunca modifica `servicios.id_gestor`, porque ese campo sigue siendo la asignación predeterminada de solicitudes futuras.

### 7.5 Cierre y calificación

El gestor completa checklist y solución, marca la etapa lista y avanza el flujo. Al terminar, el caso pasa a pendiente de calificación. El solicitante puede reabrir cuando la regla lo permite o calificar; `solicitud_calificaciones` conserva el resultado y `tickets` pasa a cerrado. Los casos cerrados siguen disponibles como historial de solo lectura.

## 8. Reglas de datos que no deben romperse

1. Mantener `id_pais_operacion` en toda consulta operativa.
2. Verificar permisos en el servidor, no únicamente en botones o JavaScript.
3. Usar CSRF en acciones POST autenticadas.
4. No reescribir instancias históricas al cambiar plantillas.
5. No confundir el proceso del usuario con los servicios que puede gestionar.
6. No cambiar el gestor predeterminado al reasignar un ticket existente.
7. No mezclar conversación ni archivos entre etapas o derivaciones.
8. No exponer rutas físicas de archivos.
9. No eliminar definitivamente tickets ni evidencia desde la operación normal.
10. Registrar historial en cambios de estado, responsable, cierre y reapertura.

## 9. Seguridad y producción

Controles existentes:

- validación central de sesión;
- roles 1, 2 y 3;
- token CSRF y control de origen;
- cookie de sesión con atributos seguros bajo HTTPS;
- límite de intentos de acceso en `seguridad_intentos_login`;
- códigos de recuperación guardados como HMAC;
- adjuntos servidos mediante controlador autorizado;
- separación por país;
- auditoría de acciones POST;
- validación de extensiones, MIME y tamaño de archivos.

Acciones obligatorias antes de producción:

1. Rotar las credenciales y secretos presentes en la versión recibida.
2. Retirarlos de `app/config/conexion.php` y usar configuración privada.
3. No publicar `.n8n/`, `.vscode/`, logs, cachés ni bases SQLite locales.
4. Conservar `mds_storage` mientras existan referencias históricas y respaldar conjuntamente MySQL, Graph y esos archivos.
5. Validar sintaxis con PHP 7.4.
6. Verificar aislamiento Colombia/Perú, roles, descargas y recuperación.
7. Respaldar base principal y almacenamiento antes del despliegue.

## 10. Operación, respaldo y recuperación

| Activo | Respaldo requerido | Motivo |
|---|---|---|
| Base `mds_GC2026` | Dump consistente y verificable | Contiene usuarios, configuración, tickets y trazabilidad |
| Microsoft Graph `Mds_Storage` | Respaldo y política de retención corporativa | Contiene todas las cargas nuevas y debe conciliarse con `storage_objetos` |
| `mds_storage` histórico | Copia sincronizada con la base | Contiene evidencia anterior a la activación de Graph |
| Configuración privada | Copia cifrada con acceso restringido | Permite reconstruir conexiones sin divulgar secretos |
| Flujos n8n | Exportación sin credenciales | Permite reconstruir automatizaciones |
| Código y `docs` | Control de versiones o paquete fechado | Permite identificar exactamente qué versión opera |

Una recuperación válida requiere restaurar la base y ambos almacenamientos del mismo corte. Restaurar solamente SQL puede dejar referencias Graph o locales inexistentes; restaurar únicamente los binarios puede dejar evidencia huérfana.

## 11. Mantenimiento y control de cambios

Para todo cambio futuro:

1. localizar la ruta en `app/routes.php`;
2. revisar su módulo y los componentes `app/core/` que carga;
3. identificar las tablas y columnas en el inventario incluido en este mismo documento;
4. preservar país, rol, CSRF, historial, instantáneas y archivos privados;
5. actualizar ambos documentos si cambian rutas, tablas, campos o reglas;
6. registrar la fecha, el alcance y las decisiones en el capítulo final de este documento maestro;
7. validar estáticamente y luego ejecutar pruebas controladas fuera de producción.

## 12. Estado documental

Esta documentación fue obtenida mediante inspección estática del proyecto y contraste con el dump SQL suministrado. No se abrió la página, no se inició sesión, no se usaron credenciales y no se ejecutaron consultas sobre las bases reales. Los capítulos siguientes reúnen el inventario detallado de rutas, tablas, campos, integraciones y procedimientos que antes se encontraban en documentos separados.

## 13. Inventario completo de rutas públicas

Convenciones: **R** lectura, **C** creación, **U** actualización y **L** eliminación lógica o papelera. El acceso final también depende del país, propiedad del ticket y asignación del nodo.

| Entrada | Implementación | Rol | Función y datos principales |
|---|---|---|---|
| `abrirNotificacion.php` | `app/modules/notificaciones/abrirNotificacion.php` | 1, 2, 3 | R/U `notificaciones`; R `tickets`, `ticket_etapas` |
| `actualizarTicket.php` | `app/modules/tickets/actualizarTicket.php` | 2 | U compatible de `tickets` mediante motor de flujos |
| `adminAcciones.php` | `app/modules/tickets/adminAcciones.php` | 1 | Ruta retirada; responde HTTP 410 |
| `apariencia.php` | `app/modules/perfil/apariencia.php` | 1, 2, 3 | R/U `usuario_preferencias_interfaz` |
| `asignarTicket.php` | `app/modules/tickets/asignarTicket.php` | 1 | U `ticket_etapas`/`tickets`; C historial/notificaciones |
| `catalogos.php` | `app/modules/catalogos/catalogos.php` | 1 | R/U de orden en `catalogos` |
| `chat.php` | `app/modules/tickets/chat.php` | Sesión autorizada | Puente a `mensajes.php` |
| `configuraciones.php` | `app/modules/admin/configuraciones.php` | 1 | C/R/U/L `configuraciones_servicio`; relaciones con `servicios` y `papelera` |
| `consultarEncuesta.php` | `app/modules/tickets/consultarEncuesta.php` | 3 | R `solicitud_calificaciones`, `tickets`, `usuarios` |
| `crearUsuarios.php` | `app/modules/admin/crearUsuarios.php` | 1 | C/R/U `usuarios`; R roles, países, ubicación y Uniclass |
| `crearticket.php` | `app/modules/tickets/crearticket.php` | 3 | Redirección a creación en `panelSolicitante.php` |
| `descargarAdjunto.php` | `app/modules/tickets/descargarAdjunto.php` | 1, 2, 3 autorizados | R `solicitud_adjuntos`, ticket/nodo, `storage_objetos` y binario Graph o histórico local |
| `descargarSolicitudesExcel.php` | `app/modules/tickets/descargarSolicitudesExcel.php` | 1 | R y exportación de ticket, etapas, evidencia, usuarios y catálogos |
| `diagnostico_relaciones.php` | `app/modules/admin/diagnostico_relaciones.php` | 1 + diagnóstico | R `information_schema` |
| `editarUsuario.php` | `app/modules/admin/editarUsuario.php` | 1 | R/U `usuarios`; R ubicación |
| `editarcatalogos.php` | `app/modules/catalogos/editarcatalogos.php` | 1 | C/R/U/L `catalogos`, `papelera`, `storage_objetos` e imágenes Graph |
| `enviarMensaje.php` | `app/modules/tickets/enviarMensaje.php` | Sesión | Ruta retirada; responde HTTP 410 |
| `feriados.php` | `app/modules/sla/feriados.php` | 1 | C/R/U/L `feriados`, `papelera` |
| `flujoTicket.php` | `app/modules/tickets/flujoTicket.php` | 1, 2 | Gestión integral mediante `motorFlujos.php` |
| `imagenCatalogo.php` | `app/modules/catalogos/imagenCatalogo.php` | Sesión | R `catalogos`, `storage_objetos` y Graph, con fallback histórico local |
| `imagenPerfil.php` | `app/modules/perfil/imagenPerfil.php` | 1, 2, 3 según permiso | R `usuarios`, `storage_objetos` y Graph, con fallback histórico local |
| `indicadores.php` | `app/modules/reportes/indicadores.php` | 1 | R tickets, etapas, usuarios, servicios, áreas, procesos y calificaciones |
| `login.php` | `app/modules/auth/login.php` | Público | R `usuarios`; C/U intentos, sesión y presencia |
| `logout.php` | `app/modules/auth/logout.php` | Sesión | U sesión, presencia y huella de usuario |
| `mensajes.php` | `app/modules/tickets/mensajes.php` | 2, 3 | Interfaz de conversaciones |
| `mensajesApi.php` | `app/modules/tickets/mensajesApi.php` | 1, 2, 3 autorizados | C/R/U comunicaciones, adjuntos, lectura y notificaciones |
| `panelAdmin.php` | `app/modules/admin/panelAdmin.php` | 1 | Centro de control e integración del monitor |
| `panelGestor.php` | `app/modules/tickets/panelGestor.php` | 2 | R etapas, tickets y calificaciones del gestor |
| `panelSolicitante.php` | `app/modules/tickets/panelSolicitante.php` | 3 | C/R/U tickets propios, conversación, reapertura y calificación |
| `papelera.php` | `app/modules/admin/papelera.php` | 1 | R/U/restauración/eliminación definitiva autorizada |
| `perfil.php` | `app/modules/perfil/perfil.php` | 1, 2, 3 | R/U perfil, contraseña, ubicación e imagen |
| `prioridades.php` | `app/modules/admin/prioridades.php` | 1 | Compatibilidad hacia `configuraciones.php` |
| `procesos.php` | `app/modules/tickets/procesos.php` | 1 | C/R/U/L procesos, etapas de plantilla y checklist |
| `recuperarPassword.php` | `app/modules/auth/recuperarPassword.php` | Público | C/R/U recuperaciones, contraseña y envío n8n |
| `Registro.php` | `app/modules/admin/Registro.php` | 1 | Compatibilidad hacia `crearUsuarios.php` |
| `seleccionarPais.php` | `app/modules/admin/seleccionarPais.php` | 1 | R país y U contexto de sesión |
| `servicios.php` | `app/modules/catalogos/servicios.php` | 1 | C/R/U/L servicios y relaciones configurables |
| `sesionActividad.php` | `app/security/sesionActividad.php` | 1, 2, 3 | R/U usuario, sesión y presencia |
| `sesiones.php` | `app/modules/admin/sesiones.php` | 1, 2 | Interfaz del monitor |
| `sesionesApi.php` | `app/modules/admin/sesionesApi.php` | 1, 2 | R sesiones, países, auditoría, usuarios y roles |
| `sla.php` | `app/modules/sla/sla.php` | 1 | C/R/U/L `sla`, relaciones con servicios y papelera |
| `solicitudes.php` | `app/modules/tickets/solicitudes.php` | 1 | R trazabilidad y U reasignación administrativa |
| `soluciones.php` | `app/modules/catalogos/soluciones.php` | 1 | C/R/U/L soluciones por servicio |
| `verificarActualizacionSolicitudes.php` | `app/modules/sistema/verificarActualizacionSolicitudes.php` | 1 + diagnóstico | R `tickets` e `information_schema` |
| `verificarCalendarioSla.php` | `app/modules/sla/verificarCalendarioSla.php` | 1 + diagnóstico | R feriados, SLA, tickets y etapas |
| `verificarFlujos.php` | `app/modules/sistema/verificarFlujos.php` | 1 + diagnóstico | R esquema y componentes del flujo |

`public/_entry.php` es el despachador común y no integra las 46 entradas del mapa. Con este archivo existen 47 PHP en el primer nivel de `public/`.

## 14. Diccionario completo de datos

El dump suministrado contiene 36 tablas y 94 restricciones de llave foránea. La integración agrega de forma aditiva `storage_objetos`, para un total operativo esperado de 37 tablas después de la primera carga Graph.

### 14.1 Identidad, alcance y seguridad

| Tabla | Propósito | Columnas |
|---|---|---|
| `usuarios` | Identidad local, datos laborales, rol, ubicación y estado | `id_usuario`, `cedula`, `nombre`, `proceso`, `cu1`, `cu3`, `email`, `descripcion_cu1`, `ciudad`, `empresa`, `password`, `id_rol`, `id_pais_operacion`, `id_pais`, `id_departamento`, `id_ciudad`, `estado`, `sesion_activa_hash`, `sesion_activa_en`, `creado_en`, `actualizado_en` |
| `roles` | Catálogo de roles | `id_rol`, `nombre_rol`, `descripcion`, `estado`, `creado_en` |
| `paises_operacion` | Operación Colombia/Perú y colores base | `id_pais_operacion`, `codigo`, `nombre`, `zona_horaria`, `color_primario`, `color_secundario`, `estado`, `orden`, `creado_en` |
| `perfiles_gestor` | Perfiles secundarios protegidos por PIN | `id_perfil_gestor`, `id_usuario`, `nombre`, `pin_hash`, `es_propietario`, `estado`, `creado_en`, `actualizado_en` |
| `sesiones_usuario` | Sesión, IP, dispositivo y cierre | `id_sesion`, `id_usuario`, `id_perfil_gestor`, `token_hash`, `php_session_id`, `direccion_ip`, `agente_usuario`, `tipo_dispositivo`, `sistema_operativo`, `navegador`, `inicio_en`, `ultima_actividad_en`, `cerrada_en`, `motivo_cierre` |
| `sesiones_usuario_paises` | Países visitados por sesión | `id_sesion`, `id_pais_operacion`, `primera_visita_en`, `ultima_visita_en` |
| `auditoria_sesiones` | Auditoría de operaciones | `id_auditoria`, `id_sesion`, `id_usuario`, `id_perfil_gestor`, `modulo`, `accion`, `detalle`, `direccion_ip`, `estado_http`, `fecha_hora` |
| `seguridad_intentos_login` | Intentos y bloqueos de acceso | `clave`, `intentos`, `ultimo_intento`, `bloqueado_hasta` |
| `recuperaciones_password` | Recuperación protegida de contraseña | `id_recuperacion`, `id_usuario`, `codigo_hash`, `intentos`, `solicitado_ip_hash`, `expira_en`, `usado_en`, `creado_en` |
| `usuario_preferencias_interfaz` | Paleta elegida | `id_usuario`, `tema`, `actualizado_en` |

### 14.2 Configuración del servicio

| Tabla | Propósito | Columnas |
|---|---|---|
| `catalogos` | Áreas | `id_catalogo`, `id_pais_operacion`, `nombre`, `descripcion`, `imagen`, `estado`, `orden`, `creado_en`, `actualizado_en` |
| `configuraciones_servicio` | Geografía y listas configurables | `id_opcion`, `id_pais_operacion`, `tipo`, `id_padre`, `nombre`, `descripcion`, `color`, `estado_registro`, `orden`, `creado_en`, `actualizado_en` |
| `servicios` | Oferta y valores predeterminados | `id_servicio`, `id_pais_operacion`, `id_catalogo`, `id_proceso`, `id_sla`, `id_gestor`, `nombre`, `descripcion`, `tipo_solicitud`, `estado`, `id_pais`, `id_ciudad`, `id_departamento`, `id_prioridad`, `prioridad_valor`, `id_urgencia`, `urgencia_valor`, `id_nivel`, `id_impacto`, `impacto_valor`, `id_estado`, `creado_en`, `actualizado_en`, `proceso` |
| `sla` | Tiempos de respuesta | `id_sla`, `id_pais_operacion`, `nombre`, `tiempo_respuesta`, `unidad`, `estado`, `creado_en`, `actualizado_en` |
| `feriados` | Días y periodos no laborables | `id_feriado`, `id_pais_operacion`, `nombre`, `tipo`, `fecha_inicio`, `fecha_fin`, `descripcion`, `estado`, `id_creado_por`, `creado_en`, `actualizado_en` |
| `soluciones_servicio` | Soluciones por servicio | `id_solucion`, `id_servicio`, `nombre`, `descripcion`, `estado`, `orden`, `creado_por`, `actualizado_por`, `creado_en`, `actualizado_en` |
| `papelera` | Recuperación serializada de configuraciones | `id_papelera`, `tipo`, `id_registro`, `id_pais_operacion`, `nombre`, `datos`, `eliminado_por`, `eliminado_en` |

### 14.3 Plantillas de flujo

| Tabla | Propósito | Columnas |
|---|---|---|
| `procesos` | Cabecera de plantilla | `id_proceso`, `id_pais_operacion`, `nombre`, `descripcion`, `estado`, `creado_por`, `actualizado_por`, `creado_en`, `actualizado_en` |
| `proceso_etapas` | Etapas configurables | `id_proceso_etapa`, `id_proceso`, `id_servicio`, `id_gestor`, `id_sla`, `orden`, `nombre_etapa`, `instrucciones`, `requiere_comentario_cierre`, `estado`, `creado_en`, `actualizado_en` |
| `proceso_etapa_checklist` | Checklist de plantilla | `id_checklist`, `id_proceso_etapa`, `nombre`, `descripcion`, `obligatorio`, `requiere_evidencia`, `orden`, `estado`, `creado_en`, `actualizado_en` |

### 14.4 Ejecución de tickets

| Tabla | Propósito | Columnas |
|---|---|---|
| `tickets` | Cabecera y estado general | `id_ticket`, `id_pais_operacion`, `titulo`, `descripcion`, `tipo_solicitud`, `estado`, `urgencia`, `urgencia_valor`, `impacto`, `impacto_valor`, `prioridad`, `prioridad_valor`, `id_usuario`, `id_tecnico`, `id_servicio`, `id_proceso`, `estado_flujo`, `id_etapa_actual`, `fecha_creacion`, `fecha_finalizacion`, `esperando_solicitante_desde`, `cierre_tipo`, `motivo_cierre`, `actualizado_en` |
| `ticket_etapas` | Instancias de etapas y derivaciones | `id_ticket_etapa`, `id_ticket_etapa_padre`, `id_ticket`, `id_proceso_etapa`, `nivel`, `orden`, `id_catalogo`, `catalogo_nombre`, `id_servicio`, `servicio_nombre`, `id_gestor`, `gestor_nombre`, `id_sla`, `sla_nombre`, `sla_tiempo`, `sla_unidad`, `sla_minutos_total`, `sla_minutos_consumidos`, `estado`, `fecha_activacion`, `fecha_vencimiento`, `fecha_ultima_reanudacion`, `fecha_pausa`, `fecha_marcado_listo`, `minutos_hasta_listo`, `resultado_sla_listo`, `marcado_listo_por`, `fecha_ultima_reapertura`, `cantidad_reaperturas`, `cantidad_pausas`, `fecha_finalizacion`, `minutos_atencion`, `resultado_sla`, `id_solucion`, `solucion_nombre`, `comentario_cierre`, `solicita_cierre_definitivo`, `motivo_derivacion`, `completado_por`, `creado_por`, `creado_en`, `actualizado_en` |
| `ticket_etapa_checklist` | Checklist ejecutado | `id_ticket_checklist`, `id_ticket_etapa`, `id_checklist_plantilla`, `nombre`, `descripcion`, `obligatorio`, `requiere_evidencia`, `orden`, `completado`, `observacion`, `evidencia_ruta`, `completado_por`, `completado_en`, `creado_en`, `actualizado_en` |

### 14.5 Evidencia, conversación y avisos

| Tabla | Propósito | Columnas |
|---|---|---|
| `solicitud_comunicaciones` | Mensajes por ticket y nodo | `id_comunicacion`, `id_ticket`, `id_ticket_etapa`, `id_emisor`, `tipo`, `mensaje`, `creado_en` |
| `solicitud_adjuntos` | Metadatos de archivos | `id_adjunto`, `id_ticket`, `id_ticket_etapa`, `id_usuario`, `nombre_original`, `nombre_guardado`, `ruta`, `tipo_mime`, `tamano`, `creado_en` |
| `storage_objetos` | Referencias e integridad de binarios externos | `id_storage_objeto`, `tipo_entidad`, `id_entidad`, `id_pais_operacion`, `proveedor`, `estado`, `drive_id`, `item_id`, `parent_item_id`, `ruta_logica`, `nombre_remoto`, `nombre_original`, `tipo_mime`, `tamano`, `sha256`, `etag`, `creado_en`, `actualizado_en` |
| `solicitud_historial` | Trazabilidad del caso | `id_historial`, `id_ticket`, `id_ticket_etapa`, `id_usuario`, `accion`, `detalle`, `creado_en` |
| `solicitud_calificaciones` | Encuesta general o por etapa | `id_calificacion`, `id_ticket`, `id_ticket_etapa`, `id_solicitante`, `id_gestor`, `calificacion`, `calificacion_area`, `calificacion_tiempo`, `tipo_calificacion`, `comentario`, `creado_en` |
| `notificaciones` | Campana interna | `id_notificacion`, `id_usuario`, `id_ticket`, `id_ticket_etapa`, `titulo`, `mensaje`, `leida`, `creada_en`, `leida_en` |
| `ticket_notificaciones_email_preferencias` | Preferencia de correo | `id_preferencia`, `id_ticket`, `id_usuario`, `habilitada`, `creada_en`, `actualizada_en` |
| `chat_conversacion_estado` | Entrega y lectura del chat | `id_ticket`, `id_ticket_etapa`, `id_usuario`, `entregado_hasta`, `leido_hasta`, `actualizado_en` |
| `chat_usuario_presencia` | Presencia global | `id_usuario`, `en_linea`, `inicio_sesion_en`, `ultima_actividad_en` |

### 14.6 Estructuras legadas o sin interfaz principal identificada

| Tabla | Columnas | Estado documental |
|---|---|---|
| `historial_acciones` | `id_historial`, `id_ticket`, `id_usuario`, `accion`, `detalle`, `fecha_accion` | Historial anterior; el motor usa principalmente `solicitud_historial` |
| `mensajes` | `id_mensaje`, `id_ticket`, `id_emisor`, `mensaje`, `fecha_envio` | Mensajería anterior; el motor usa `solicitud_comunicaciones` |
| `solicitud_actividades` | `id_actividad`, `id_ticket`, `titulo`, `descripcion`, `fecha_programada`, `estado`, `id_responsable`, `creado_por`, `creado_en`, `completado_en` | Sin interfaz principal identificada |
| `solicitud_resoluciones` | `id_ticket`, `resolucion`, `causa_raiz`, `id_resuelto_por`, `resuelto_en`, `actualizado_en` | Estructura disponible; cierre actual en ticket/etapas |
| `solicitud_vinculos` | `id_vinculo`, `id_ticket`, `id_ticket_vinculado`, `tipo_vinculo`, `creado_por`, `creado_en` | Relación disponible sin interfaz principal identificada |

No se deben eliminar estas tablas sin revisar datos existentes, reportes externos y dependencias históricas.

## 15. Procedimientos n8n y Microsoft 365

### 15.1 Recuperación de contraseña

1. El usuario selecciona “¿Olvidó su contraseña?” e ingresa el correo.
2. La respuesta pública permanece genérica para no confirmar si la cuenta existe.
3. Si la cuenta está activa, `recuperacionPassword.php` genera un código de seis dígitos.
4. `recuperaciones_password` guarda únicamente su HMAC, fecha de expiración e intentos.
5. `correoN8n.php` envía un JSON firmado al webhook.
6. n8n entrega el correo mediante Microsoft 365.
7. El código vence en 10 minutos, admite cinco intentos y se invalida después de usarse.

El flujo de producción debe utilizar URL HTTPS, Header Auth y credenciales OAuth2 de Microsoft 365 administradas en n8n. El webhook y los secretos no deben estar escritos en los JSON exportados.

### 15.2 Notificaciones de casos

- Solicitante y gestor reciben correo de forma predeterminada.
- Cada persona controla su preferencia sin modificar la del otro.
- El gestor recibe avisos mientras el nodo continúe asignado a su usuario.
- Acciones internas de derivaciones no se envían al solicitante.
- Al reasignar, el gestor anterior deja de ser destinatario y el nuevo se habilita por defecto.
- Una falla del correo no revierte una acción de ticket confirmada.
- Campana interna y correo operan en paralelo.

### 15.3 Prueba local opcional

El entorno local puede usar n8n Community Edition y Mailpit/MailDev. Este procedimiento es exclusivamente de desarrollo y no se debe copiar al servidor productivo. Antes de usarlo, se debe confirmar que los archivos locales referenciados realmente estén incluidos y que no contengan datos o secretos. Para cambios pequeños solicitados a una IA, las pruebas en navegador o con credenciales no deben ejecutarse salvo autorización expresa.

## 16. Auditoría SQL y seguridad

Se identifican múltiples llamadas a `$conn->query()`. No todas son vulnerables: consultas estáticas, `SHOW` e inspecciones de esquema pueden usar llamadas directas. Toda consulta que concatene datos provenientes de GET, POST, sesión manipulable o parámetros de ruta debe convertirse a `prepare()` con `bind_param()`.

Prioridad de revisión:

1. tickets, adjuntos, mensajería y reasignación;
2. creación y edición de usuarios;
3. servicios, soluciones, flujos y configuraciones;
4. login, recuperación y sesiones;
5. exportaciones, indicadores y diagnósticos.

Controles de producción:

- rotar secretos que hayan circulado en ZIP, código o herramientas;
- no publicar `.n8n`, `.vscode`, logs, cachés, bases SQLite ni configuraciones de transferencia;
- bloquear navegación directa de `app/`, `docs/`, `scripts/` y `mds_storage/`;
- conservar `app/config/graph-client-secret.local` con acceso restringido y fuera del control de versiones;
- mantener el permiso Graph limitado a la carpeta `Mds_Storage` y rotar la credencial antes de su vencimiento;
- usar HTTPS y cookies `Secure`, `HttpOnly`, `SameSite=Lax`;
- mantener diagnósticos desactivados;
- probar aislamiento Colombia/Perú y descarga autorizada de adjuntos;
- respaldar base y almacenamiento antes de cada cambio.

## 17. Cambios de seguridad registrados

La revisión anterior documentó endurecimiento de conexión, reglas Apache, sesiones, cargas de imágenes, descarga de adjuntos y cierre de sesión. La integración Graph mantiene el secreto en `app/config/graph-client-secret.local`, protegido por `app/.htaccess` e ignorado por Git; las nuevas imágenes y adjuntos no se guardan en el hosting. Las credenciales históricas que todavía permanezcan integradas en `app/config/conexion.php` deben extraerse y rotarse antes de producción.

## 18. Validación y mantenimiento de este documento

Validación estática realizada:

- 46 rutas confirmadas en `app/routes.php`;
- 47 archivos PHP públicos contando `_entry.php`;
- proveedor Graph aplicado a adjuntos, perfiles e imágenes de catálogo, con lectura histórica local;
- tabla `storage_objetos` autocreable y migración `007_almacenamiento_graph.sql` incluida;
- 36 tablas y 94 relaciones foráneas en el dump;
- cruce entre pantallas, módulos, núcleo, SQL y esquema;
- confirmación de `mae_data_uniclass.identificacion` y `mae_data_uniclass.EST`;
- ausencia de credenciales copiadas en este documento;
- integridad del paquete comprimido.

No se abrió el sitio, no se inició sesión y no se consultaron bases reales.

Este archivo es la única fuente documental Markdown dentro de `docs`. Toda modificación futura de rutas, tablas, campos, roles, conexiones, integraciones o reglas de negocio debe actualizar aquí el capítulo correspondiente y añadir una entrada breve con fecha, cambio e invariantes preservadas.
