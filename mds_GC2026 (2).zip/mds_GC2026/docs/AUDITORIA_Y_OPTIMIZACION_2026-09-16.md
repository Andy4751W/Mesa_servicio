# Auditoría y optimización — 16/09/2026

## Alcance revisado

- 186 archivos del proyecto, incluidos 122 controladores y vistas PHP.
- Enrutamiento público, permisos por rol, formularios sensibles y protección CSRF.
- Navegación interna, carga de imágenes/adjuntos y consultas del tablero de Indicadores.
- Ocho archivos `.htaccess`, manteniendo intactas las reglas funcionales existentes.
- Sintaxis de los dos archivos JavaScript externos y estructura balanceada de los 122 archivos PHP.

## Correcciones aplicadas

1. **Indicadores por área y servicio**
   - Se agregó el filtro de área.
   - El selector de servicios ahora carga todo el catálogo de la operación, incluso servicios sin historial.
   - Al elegir un área, el navegador muestra únicamente sus servicios; al seleccionar “Todas las áreas”, vuelven a aparecer todos.
   - Área y servicio se aplican al mismo caso/etapa para evitar cruces incorrectos de información.
   - El resumen de procesos también respeta ambos filtros.

2. **Navegación más rápida**
   - Se agregó precarga segura de las pantallas de consulta al apuntar o enfocar un enlace.
   - La respuesta se reutiliza durante 15 segundos para acelerar cambios inmediatos entre módulos.
   - Las operaciones, descargas, notificaciones y rutas con acciones quedan excluidas de la precarga.
   - Después de un formulario POST se invalida la caché para no mostrar información anterior.

3. **Carga de imágenes y archivos remotos**
   - Se añadió una caché privada de cinco minutos para objetos de Microsoft Graph de hasta 15 MB.
   - Esto evita descargar varias veces la misma imagen cuando se usa simultáneamente en cabecera, tarjetas o conversación.
   - La caché es prescindible: si el servidor no puede escribirla, la descarga continúa normalmente.

4. **Seguridad de formularios**
   - Se activó la validación CSRF que faltaba en selección de operación, actualización de perfil/contraseña y apariencia.
   - El token del perfil ahora se genera mediante el helper central para evitar estados de sesión incompletos.

5. **Protección de scripts**
   - `scripts/.htaccess` contenía `Require all aproved`, una directiva inválida.
   - Se sustituyó por bloqueo compatible con Apache 2.4 y con la sintaxis heredada de Apache 2.2.
   - Los otros siete `.htaccess` se conservaron sin cambios.

## Archivos modificados

- `index.php`
- `app/core/almacenamiento.php`
- `app/modules/reportes/indicadores.php`
- `app/modules/admin/seleccionarPais.php`
- `app/modules/perfil/perfil.php`
- `app/modules/perfil/apariencia.php`
- `scripts/.htaccess`

## Verificaciones realizadas

- Todas las rutas declaradas en `app/routes.php` tienen controlador y entrada pública.
- No quedaron marcadores de conflicto de combinación.
- Los JavaScript externos superaron la comprobación de sintaxis de Node.js.
- Los scripts incrustados de `index.php` e `indicadores.php` superaron la comprobación de sintaxis después de sustituir las expresiones PHP de plantilla.
- Los 122 archivos PHP tienen etiquetas y delimitadores estructurales balanceados.
- El ZIP final conserva la carpeta raíz `mds_GC2026/` y los ocho `.htaccess`.

## Publicación recomendada

Subir el contenido completo manteniendo archivos ocultos y sin eliminar datos operativos existentes. Para una actualización selectiva, reemplazar únicamente los siete archivos indicados arriba; el documento de auditoría es informativo.

