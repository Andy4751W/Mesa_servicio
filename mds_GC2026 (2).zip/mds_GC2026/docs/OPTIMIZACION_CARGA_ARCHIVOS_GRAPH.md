# Optimización de imágenes y archivos en Microsoft Graph

## Objetivo

Reducir el tiempo de creación de casos y de actualización de imágenes sin volver a guardar archivos en el hosting de la Mesa de Servicio.

## Cambios implementados

1. El token OAuth de Microsoft Graph se conserva en una caché privada hasta poco antes de su vencimiento. Ya no se solicita un token en cada petición PHP.
2. Los identificadores de las carpetas remotas se conservan en caché. La aplicación deja de consultar uno por uno los segmentos de una ruta conocida antes de cada carga.
3. Los adjuntos nuevos se organizan por país, año y mes: `adjuntos/PAIS/AAAA/MM`. La relación con caso y etapa permanece en la base de datos y en el nombre remoto.
4. Las imágenes de perfil nuevas se guardan en `perfiles/PAIS`; el identificador del usuario forma parte del nombre. Ya no se crea una carpeta remota por usuario.
5. Si Microsoft informa que una carpeta almacenada en caché ya no existe, la caché se invalida y la operación se reintenta una vez reconstruyendo la ruta.

## Archivos modificados

| Archivo | Responsabilidad del cambio |
|---|---|
| `app/core/almacenamiento.php` | Caché de token y carpetas; reintento seguro ante rutas remotas modificadas |
| `app/core/motorFlujos.php` | Ruta compartida mensual para adjuntos nuevos |
| `app/core/perfil.php` | Ruta compartida por país para imágenes de perfil nuevas |

## Persistencia y seguridad

La caché contiene únicamente metadatos operativos y el token temporal. Se crea en `mds_storage/cache_graph`, dentro del almacenamiento privado protegido por las reglas existentes. Los adjuntos y las imágenes continúan almacenándose en Microsoft Graph; no se duplican en el servidor web.

La caché es prescindible: si no puede escribirse, la aplicación sigue funcionando mediante consultas normales a Graph, aunque con mayor latencia.

## Compatibilidad

- Los archivos existentes conservan su referencia `graph:item_id` y siguen descargándose sin migración.
- Los registros de `storage_objetos` continúan siendo la fuente de relación entre el archivo, la entidad y su país.
- La asignación de gestores, el flujo de casos y las validaciones de tipos y tamaños no cambian.
- La primera carga de un mes puede crear las carpetas de año y mes; las cargas siguientes reutilizan sus identificadores.

## Verificación recomendada después del despliegue

1. Crear un caso con uno y con varios adjuntos permitidos.
2. Descargar cada adjunto desde solicitante, gestor y administrador según sus permisos.
3. Cambiar una imagen de perfil y una imagen de área.
4. Confirmar que `mds_storage/cache_graph` contiene archivos JSON privados y que los binarios permanecen en Microsoft Graph.
5. Revisar `error_log` únicamente si aparece un mensaje funcional; no es necesario ejecutar pruebas de navegación automatizadas.

El tiempo total todavía depende del tamaño de los archivos, la velocidad de subida del usuario y la latencia hacia Microsoft. Esta optimización elimina llamadas repetitivas de autenticación y búsqueda de carpetas, pero no puede eliminar el tiempo necesario para transferir los bytes.
