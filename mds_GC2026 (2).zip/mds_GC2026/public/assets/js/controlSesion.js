(function () {
  'use strict';

  if (window.__MESA_SESSION_MONITOR_ACTIVE__) return;

  /*
   * La mesa puede renderizar módulos dentro de un marco y algunos controles
   * abren marcos auxiliares. Solo la vista principal de la pestaña debe ser
   * propietaria del aviso de inactividad.
   */
  try {
    var previousOwner = window.top.__MESA_SESSION_MONITOR_OWNER__;
    var previousOwnerIsAlive = previousOwner
      && previousOwner !== window
      && (
        previousOwner === window.top
        || (previousOwner.frameElement && previousOwner.frameElement.isConnected)
      );

    if (previousOwnerIsAlive) return;
    window.top.__MESA_SESSION_MONITOR_OWNER__ = window;
  } catch (error) {
    // El indicador local sigue evitando cargas duplicadas en este documento.
  }

  window.__MESA_SESSION_MONITOR_ACTIVE__ = true;
  window.__MESA_CONTROL_SESION_VERSION__ = '2026-09-08.10-shell-owner';

  var ENDPOINT = 'sesionActividad.php';
  var IDLE_DURATION = 300;
  var warningDuration = 15;
  var idleEndsAt = Date.now() + IDLE_DURATION * 1000;
  var logoutEndsAt = idleEndsAt + warningDuration * 1000;
  var lastActivitySent = 0;
  var requestInProgress = false;
  var requestPromise = null;
  var queuedActivityPromise = null;
  var sessionWarning = null;
  var sessionCountdown = null;
  var sessionContinueButton = null;
  var sessionContinueStatus = null;
  var TAB_KEY = 'MESA_PESTANA_SESION';
  var VALID_TAB_KEY = 'MESA_PESTANA_VALIDADA';
  var WARNING_OWNER_KEY = 'MESA_AVISO_INACTIVIDAD_PROPIETARIO';
  var ACTIVITY_SYNC_KEY = 'MESA_ACTIVIDAD_COMPARTIDA';
  var SYNC_CHANNEL_NAME = 'mesa-control-sesion-v1';
  var syncChannel = null;
  var tabId = '';
  var monitorId = '';

  function revealPage() {
    try {
      window.sessionStorage.setItem(VALID_TAB_KEY, currentTabId());
    } catch (error) {
      // La sesión sigue funcionando aunque el navegador bloquee sessionStorage.
    }
    document.documentElement.classList.remove('mesa-session-pending');
  }

  function randomHex(bytes) {
    var values = new Uint8Array(bytes);
    if (window.crypto && window.crypto.getRandomValues) {
      window.crypto.getRandomValues(values);
    } else {
      for (var i = 0; i < values.length; i += 1) {
        values[i] = Math.floor(Math.random() * 256);
      }
    }
    return Array.prototype.map.call(values, function (value) {
      return value.toString(16).padStart(2, '0');
    }).join('');
  }

  function currentTabId() {
    if (tabId) return tabId;
    try {
      tabId = window.sessionStorage.getItem(TAB_KEY) || '';
      if (!/^[a-f0-9]{64}$/.test(tabId)) {
        tabId = randomHex(32);
        window.sessionStorage.setItem(TAB_KEY, tabId);
      }
    } catch (error) {
      tabId = randomHex(32);
    }
    return tabId;
  }

  function currentMonitorId() {
    if (!monitorId) monitorId = currentTabId() + ':' + randomHex(12);
    return monitorId;
  }

  function readWarningOwner() {
    try {
      var value = window.localStorage.getItem(WARNING_OWNER_KEY);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      return null;
    }
  }

  function releaseWarningOwnership(force) {
    try {
      var owner = readWarningOwner();
      if (force || !owner || owner.monitor === currentMonitorId()) {
        window.localStorage.removeItem(WARNING_OWNER_KEY);
      }
    } catch (error) {
      // La alerta local continúa funcionando si localStorage no está disponible.
    }
  }

  function claimWarningOwnership() {
    if (document.hidden) {
      releaseWarningOwnership(false);
      return false;
    }

    try {
      var now = Date.now();
      var owner = readWarningOwner();
      if (owner && owner.monitor !== currentMonitorId() && Number(owner.expires) > now) {
        return false;
      }

      var claim = {
        monitor: currentMonitorId(),
        tab: currentTabId(),
        expires: Math.max(logoutEndsAt + 3000, now + 5000)
      };
      window.localStorage.setItem(WARNING_OWNER_KEY, JSON.stringify(claim));
      owner = readWarningOwner();
      return Boolean(owner && owner.monitor === currentMonitorId());
    } catch (error) {
      return true;
    }
  }

  function applySharedActivity(activityAt) {
    var at = Number(activityAt) || 0;
    if (at <= 0) return;

    var nextIdleEnd = at + IDLE_DURATION * 1000;
    if (nextIdleEnd <= idleEndsAt) return;

    idleEndsAt = nextIdleEnd;
    logoutEndsAt = idleEndsAt + warningDuration * 1000;
    releaseWarningOwnership(true);
    hideWarning();
  }

  function publishSharedActivity(activityAt) {
    var message = {
      type: 'activity',
      at: Number(activityAt) || Date.now(),
      sender: currentMonitorId()
    };

    try {
      window.localStorage.setItem(ACTIVITY_SYNC_KEY, JSON.stringify(message));
    } catch (error) {
      // BroadcastChannel puede encargarse de la sincronización.
    }
    if (syncChannel) {
      try { syncChannel.postMessage(message); } catch (error) {}
    }
  }

  function receiveSharedMessage(message) {
    if (!message || message.sender === currentMonitorId()) return;
    if (message.type === 'activity') applySharedActivity(message.at);
  }

  function startSessionSync() {
    if ('BroadcastChannel' in window) {
      try {
        syncChannel = new BroadcastChannel(SYNC_CHANNEL_NAME);
        syncChannel.addEventListener('message', function (event) {
          receiveSharedMessage(event.data);
        });
      } catch (error) {
        syncChannel = null;
      }
    }

    window.addEventListener('storage', function (event) {
      if (event.key === ACTIVITY_SYNC_KEY && event.newValue) {
        try { receiveSharedMessage(JSON.parse(event.newValue)); } catch (error) {}
        return;
      }
      if (event.key === WARNING_OWNER_KEY && event.newValue) {
        var owner = readWarningOwner();
        if (owner && owner.monitor !== currentMonitorId()) hideWarning();
      }
    });
  }

  function logout(reason) {
    try {
      window.sessionStorage.removeItem(VALID_TAB_KEY);
    } catch (error) {
      // Continuar con la salida aunque el almacenamiento no esté disponible.
    }
    if (reason === 'pestana_cerrada') {
      window.location.replace('logout.php?motivo=pestana_cerrada');
      return;
    }
    window.location.replace('logout.php?motivo=' + encodeURIComponent(reason));
  }

  function addWarningStyles() {
    if (document.getElementById('mesa-session-warning-style')) return;
    var style = document.createElement('style');
    style.id = 'mesa-session-warning-style';
    style.textContent =
      '#mesa-session-warning{position:fixed;inset:0;z-index:2147483647;display:grid;place-items:center;padding:20px;background:rgba(16,42,67,.58);backdrop-filter:blur(3px)}' +
      '#mesa-session-warning[hidden]{display:none!important}.mesa-session-card{width:min(410px,100%);padding:28px;border:1px solid #dce6f1;border-radius:18px;background:#fff;box-shadow:0 24px 70px rgba(16,42,67,.28);color:#243b53;text-align:center;font-family:Inter,"Segoe UI",Arial,sans-serif}' +
      '.mesa-session-icon{display:grid;width:50px;height:50px;margin:0 auto 14px;place-items:center;border-radius:14px;background:#fff4e5;color:#b54708;font-size:24px;font-weight:800}.mesa-session-card h2{margin:0 0 8px;color:#102a43;font-size:21px}.mesa-session-card p{margin:0;color:#526d82;font-size:14px;line-height:1.5}' +
      '#mesa-session-countdown{display:block;margin:14px 0;color:#b42318;font-size:28px}#mesa-session-continue{min-height:42px;padding:10px 17px;border:0;border-radius:10px;background:#0f6fec;color:#fff;cursor:pointer;font-weight:750}#mesa-session-continue:disabled{cursor:wait;opacity:.72}#mesa-session-continue-status{display:block;min-height:18px;margin:10px 0 0;color:#b42318;font-size:12px;font-weight:700}';
    document.head.appendChild(style);
  }

  function createWarning() {
    if (sessionWarning) return;
    addWarningStyles();
    sessionWarning = document.createElement('div');
    sessionWarning.id = 'mesa-session-warning';
    sessionWarning.hidden = true;
    sessionWarning.setAttribute('role', 'dialog');
    sessionWarning.setAttribute('aria-modal', 'true');
    sessionWarning.setAttribute('aria-labelledby', 'mesa-session-title');
    sessionWarning.innerHTML =
      '<div class="mesa-session-card">' +
        '<div class="mesa-session-icon" aria-hidden="true">!</div>' +
        '<h2 id="mesa-session-title">Su sesión está próxima a finalizar</h2>' +
        '<p>Han pasado 5 minutos sin actividad. Seleccione “Sigo en línea” para mantener la sesión activa.</p>' +
        '<strong id="mesa-session-countdown"></strong>' +
        '<button type="button" id="mesa-session-continue">Sigo en línea</button>' +
        '<span id="mesa-session-continue-status" role="status" aria-live="polite"></span>' +
      '</div>';
    document.body.appendChild(sessionWarning);
    sessionCountdown = sessionWarning.querySelector('#mesa-session-countdown');
    sessionContinueButton = sessionWarning.querySelector('#mesa-session-continue');
    sessionContinueStatus = sessionWarning.querySelector('#mesa-session-continue-status');
    sessionContinueButton.addEventListener('click', continueSession);
  }

  function warningIsOpen() {
    return Boolean(sessionWarning && !sessionWarning.hidden);
  }

  function hideWarning() {
    if (sessionWarning) sessionWarning.hidden = true;
    if (sessionContinueStatus) sessionContinueStatus.textContent = '';
  }

  function showWarning(seconds) {
    if (!claimWarningOwnership()) {
      hideWarning();
      return;
    }
    createWarning();
    sessionWarning.hidden = false;
    sessionCountdown.textContent = Math.max(0, seconds) + ' s';
  }

  function refreshIdleWarning() {
    var now = Date.now();
    var idleRemaining = Math.ceil((idleEndsAt - now) / 1000);
    var confirmationRemaining = Math.ceil((logoutEndsAt - now) / 1000);

    if (idleRemaining > 0) return false;

    showWarning(confirmationRemaining);
    return true;
  }

  function applyState(data) {
    if (!data || !data.ok || !data.tiempos) return false;
    var now = Date.now();
    var idleRemaining = Math.max(0, Number(data.tiempos.inactividad) || 0);
    var graceRemaining = Math.max(0, Number(data.tiempos.gracia) || 0);
    warningDuration = Math.max(1, Number(data.tiempos.aviso) || 15);
    idleEndsAt = now + idleRemaining * 1000;
    logoutEndsAt = now + graceRemaining * 1000;
    if (idleRemaining > 0) {
      releaseWarningOwnership(true);
      hideWarning();
    }
    return true;
  }

  function requestSession(action) {
    /*
     * Una comprobación de estado puede coincidir con una actividad real. La
     * versión anterior descartaba la actividad cuando ya existía una petición
     * en curso; el contador del navegador se reiniciaba, pero PHP conservaba
     * la hora antigua y cerraba la sesión. Las actividades ahora esperan su
     * turno y nunca se pierden.
     */
    if (requestPromise) {
      if (action === 'actividad') {
        if (!queuedActivityPromise) {
          queuedActivityPromise = requestPromise.then(function () {
            return requestSession('actividad');
          }).finally(function () {
            queuedActivityPromise = null;
          });
        }
        return queuedActivityPromise;
      }

      // Ya existe una validación equivalente; no debe interpretarse como una
      // sesión inválida por el solo hecho de omitir una petición duplicada.
      return Promise.resolve(true);
    }

    requestInProgress = true;
    var body = new URLSearchParams();
    body.set('accion', action);
    body.set('pestana_id', currentTabId());

    requestPromise = fetch(ENDPOINT, {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
      body: body.toString()
    }).then(function (response) {
      return response.json().then(function (data) {
        if (response.status === 401) {
          logout(data.motivo || 'inactividad');
          return false;
        }
        var valid = response.ok && applyState(data);
        if (valid && action === 'actividad') {
          publishSharedActivity(Date.now());
        }
        return valid;
      });
    }).catch(function () {
      // Una interrupción de red no demuestra que la sesión haya vencido.
      return null;
    }).finally(function () {
      requestInProgress = false;
      requestPromise = null;
    });

    return requestPromise;
  }

  function continueSession() {
    if (sessionContinueButton && sessionContinueButton.disabled) return;

    if (sessionContinueButton) {
      sessionContinueButton.disabled = true;
      sessionContinueButton.textContent = 'Renovando sesión…';
    }
    if (sessionContinueStatus) sessionContinueStatus.textContent = '';

    requestSession('actividad').then(function (valid) {
      if (valid === true) {
        lastActivitySent = Date.now();
        hideWarning();
        return;
      }

      if (sessionContinueStatus) {
        sessionContinueStatus.textContent = 'No fue posible renovar. Inténtelo nuevamente.';
      }
    }).finally(function () {
      if (sessionContinueButton) {
        sessionContinueButton.disabled = false;
        sessionContinueButton.textContent = 'Sigo en línea';
      }
    });
  }

  function registerActivity(force) {
    if (force) {
      continueSession();
      return;
    }

    var now = Date.now();

    // Cuando el aviso está visible, solo el botón “Sigo en línea” renueva.
    if (!force && warningIsOpen()) return;

    /*
     * Los navegadores reducen los intervalos de pestañas en segundo plano. Si
     * el usuario regresaba después de cinco minutos, su primer clic podía
     * renovar la sesión antes de que el intervalo dibujara el aviso. Una vez
     * alcanzado el límite, toda interacción debe abrir la confirmación y solo
     * su botón puede renovar.
     */
    if (refreshIdleWarning()) return;

    idleEndsAt = now + IDLE_DURATION * 1000;
    logoutEndsAt = idleEndsAt + warningDuration * 1000;
    releaseWarningOwnership(true);
    hideWarning();
    publishSharedActivity(now);

    if (!force && now - lastActivitySent < 30000) return;
    lastActivitySent = now;
    requestSession('actividad').then(function (valid) {
      if (valid !== true) lastActivitySent = 0;
    });
  }

  function bindActivityFrame(frame) {
    if (!frame || frame.__MESA_SESSION_ACTIVITY_FRAME_BOUND__) return;
    frame.__MESA_SESSION_ACTIVITY_FRAME_BOUND__ = true;
    frame.addEventListener('load', function () {
      try { bindActivityWindow(frame.contentWindow); } catch (error) {}
    });
    try { bindActivityWindow(frame.contentWindow); } catch (error) {}
  }

  function bindActivityWindow(targetWindow) {
    if (!targetWindow || targetWindow.__MESA_SESSION_ACTIVITY_BOUND__) return;

    var targetDocument;
    try {
      targetDocument = targetWindow.document;
      if (!targetDocument || !targetDocument.documentElement) return;
    } catch (error) {
      return;
    }

    targetWindow.__MESA_SESSION_ACTIVITY_BOUND__ = true;
    [
      'pointerdown',
      'keydown',
      'input',
      'change',
      'focusin',
      'paste',
      'cut',
      'scroll',
      'touchstart'
    ].forEach(function (eventName) {
      targetWindow.addEventListener(eventName, function () {
        registerActivity(false);
      }, {passive: true, capture: eventName === 'scroll'});
    });

    Array.prototype.forEach.call(
      targetDocument.querySelectorAll('iframe'),
      bindActivityFrame
    );

    if ('MutationObserver' in window) {
      var observer = new MutationObserver(function (mutations) {
        mutations.forEach(function (mutation) {
          Array.prototype.forEach.call(mutation.addedNodes || [], function (node) {
            if (!node || node.nodeType !== 1) return;
            if (String(node.tagName).toLowerCase() === 'iframe') {
              bindActivityFrame(node);
            }
            if (node.querySelectorAll) {
              Array.prototype.forEach.call(
                node.querySelectorAll('iframe'),
                bindActivityFrame
              );
            }
          });
        });
      });
      observer.observe(targetDocument.documentElement, {
        childList: true,
        subtree: true
      });
    }
  }

  function start() {
    startSessionSync();
    requestSession('vincular_pestana').then(function (valid) {
      if (!valid) return;
      revealPage();

    bindActivityWindow(window);

    window.addEventListener('message', function (event) {
      if (
        event.origin === window.location.origin &&
        event.data &&
        event.data.type === 'mesa-profile-activity'
      ) {
        registerActivity(false);
      }
    });

    document.addEventListener('visibilitychange', function () {
      if (document.hidden) {
        releaseWarningOwnership(false);
        hideWarning();
      } else {
        refreshIdleWarning();
      }
    });

    window.addEventListener('focus', function () {
      refreshIdleWarning();
    });

    window.setInterval(function () {
      if (!refreshIdleWarning()) return;
      var confirmationRemaining = Math.ceil((logoutEndsAt - Date.now()) / 1000);
      if (confirmationRemaining > 0 || requestInProgress) return;

      requestSession('estado').then(function (valid) {
        if (valid === false) logout('inactividad');
      });
    }, 1000);

    // Comprueba periódicamente si esta sesión fue reemplazada desde otro
    // navegador o dispositivo, sin saturar PHP ni bloquear la sesión.
    window.setInterval(function () {
      if (!requestInProgress) {
        requestSession('estado');
      }
    }, 30000);

    });
  }

  window.addEventListener('pagehide', function () {
    releaseWarningOwnership(false);
    if (syncChannel) {
      try { syncChannel.close(); } catch (error) {}
    }
    try {
      if (window.top.__MESA_SESSION_MONITOR_OWNER__ === window) {
        window.top.__MESA_SESSION_MONITOR_OWNER__ = null;
      }
    } catch (error) {
      // No se requiere limpieza entre contextos con acceso restringido.
    }
  }, {once: true});

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, {once: true});
  } else {
    start();
  }
}());
