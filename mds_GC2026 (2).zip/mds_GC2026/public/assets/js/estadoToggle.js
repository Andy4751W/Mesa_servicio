(() => {
    'use strict';

    const ACTIVE = 'activo';
    const INACTIVE = 'inhabilitado';
    const identityNames = [
        'id_usuario',
        'id_catalogo',
        'id_servicio',
        'id_opcion',
        'id_feriado',
        'id_sla',
        'id_solucion',
        'id_proceso'
    ];
    const stateNodeSelector = [
        '.estado-catalogo',
        '.estado-servicio',
        '.estado',
        '.status.activo',
        '.status.active',
        '.status.inactive',
        '.status.inhabilitado',
        '.badge.active',
        '.badge.off'
    ].join(',');
    let toastTimer = 0;

    const opposite = (state) => state === ACTIVE ? INACTIVE : ACTIVE;

    function identity(form) {
        const solutionId = form.elements.namedItem('id_solucion');
        const solutionValue = solutionId && 'value' in solutionId
            ? String(solutionId.value || '')
            : '';

        if (solutionValue !== '') {
            return { name: 'id_solucion', value: solutionValue };
        }

        for (const name of identityNames) {
            const field = form.elements.namedItem(name);
            const value = field && 'value' in field ? String(field.value || '') : '';

            if (value !== '') {
                return { name, value };
            }
        }

        return null;
    }

    function descriptor(form) {
        const identityField = identity(form);

        if (!identityField) {
            return null;
        }

        const nextState = form.querySelector(
            'input[type="hidden"][name="nuevo_estado"], input[type="hidden"][name="estado"]'
        );

        if (nextState && [ACTIVE, INACTIVE].includes(nextState.value)) {
            return {
                current: opposite(nextState.value),
                identity: identityField,
                kind: 'next-input',
                control: nextState
            };
        }

        const action = form.querySelector('input[type="hidden"][name="accion"]');
        const solutionId = form.elements.namedItem('id_solucion');

        if (action && solutionId && ['eliminar', 'reactivar'].includes(action.value)) {
            return {
                current: action.value === 'eliminar' ? ACTIVE : INACTIVE,
                identity: identityField,
                kind: 'solution-action',
                control: action
            };
        }

        const flowState = form.matches('.flow-state')
            ? form.querySelector('select[name="estado"]')
            : null;

        if (flowState && [ACTIVE, INACTIVE].includes(flowState.value)) {
            return {
                current: flowState.value,
                identity: identityField,
                kind: 'flow-select',
                control: flowState
            };
        }

        return null;
    }

    function buttonMarkup(state) {
        return '<span class="mesa-state-toggle-text">'
            + (state === ACTIVE ? 'ON' : 'OFF')
            + '</span>';
    }

    function setButton(button, state) {
        const active = state === ACTIVE;
        button.dataset.state = state;
        button.setAttribute('aria-checked', active ? 'true' : 'false');
        button.setAttribute('aria-label', active ? 'Inhabilitar' : 'Habilitar');
        button.title = active ? 'Habilitado: pulse para inhabilitar' : 'Inhabilitado: pulse para habilitar';
        button.innerHTML = buttonMarkup(state);
    }

    function prepareForm(form) {
        if (form.dataset.mesaStatePrepared === '1') {
            return;
        }

        const state = descriptor(form);
        const button = form.querySelector('button[type="submit"], input[type="submit"]');

        if (!state || !(button instanceof HTMLButtonElement)) {
            return;
        }

        form.dataset.mesaStatePrepared = '1';
        form.dataset.mesaStateCurrent = state.current;
        form.dataset.mesaStateKind = state.kind;
        form.classList.add('mesa-state-toggle-form');
        form.removeAttribute('onsubmit');

        if (state.kind === 'flow-select') {
            state.control.closest('div')?.classList.add('mesa-state-original-control');
        }

        button.className = 'mesa-state-toggle';
        button.setAttribute('role', 'switch');
        setButton(button, state.current);
    }

    function findReturnedForm(documentResult, state) {
        return Array.from(documentResult.forms).find((candidate) => {
            const candidateState = descriptor(candidate);

            return candidateState
                && candidateState.identity.name === state.identity.name
                && candidateState.identity.value === state.identity.value;
        }) || null;
    }

    function stateScope(form) {
        return form.closest('tr, article, .service-title, .servicio-item, .catalogo-item, .sla-item, .card');
    }

    function copyStateNode(form, returnedForm, state) {
        const localNode = stateScope(form)?.querySelector(stateNodeSelector);
        const returnedNode = returnedForm
            ? stateScope(returnedForm)?.querySelector(stateNodeSelector)
            : null;

        if (localNode && returnedNode) {
            localNode.className = returnedNode.className;
            localNode.textContent = returnedNode.textContent;
        } else if (localNode) {
            const text = localNode.textContent.trim();
            const feminine = /activa|retirada|inhabilitada/i.test(text);
            const lowerCase = text !== '' && text === text.toLocaleLowerCase('es');
            let label = state === ACTIVE
                ? (feminine ? 'Activa' : 'Activo')
                : (feminine ? 'Inhabilitada' : 'Inhabilitado');

            if (lowerCase) {
                label = label.toLocaleLowerCase('es');
            }

            localNode.textContent = label;
            localNode.classList.remove('active', 'inactive', 'off', 'ok', ACTIVE, INACTIVE);
            localNode.classList.add(
                localNode.classList.contains('badge')
                    ? (state === ACTIVE ? 'active' : 'off')
                    : (state === ACTIVE ? 'active' : INACTIVE)
            );
        }

        const row = form.closest('[data-status]');
        if (row) {
            row.dataset.status = state;
            document.getElementById('statusFilter')?.dispatchEvent(new Event('change'));
        }
    }

    function copyFlowSidebar(state, returnedDocument, identityField) {
        if (identityField.name !== 'id_proceso') {
            return;
        }

        const matchLink = (root) => Array.from(root.querySelectorAll('.service-link')).find((link) => {
            try {
                return new URL(link.href, window.location.href).searchParams.get('id_proceso') === identityField.value;
            } catch (error) {
                return false;
            }
        });
        const localBadge = matchLink(document)?.querySelector('.badge');
        const returnedBadge = returnedDocument ? matchLink(returnedDocument)?.querySelector('.badge') : null;

        if (localBadge && returnedBadge) {
            localBadge.className = returnedBadge.className;
            localBadge.textContent = returnedBadge.textContent;
        } else if (localBadge) {
            localBadge.classList.toggle('ok', state === ACTIVE);
            localBadge.classList.toggle('off', state !== ACTIVE);
            localBadge.textContent = state;
        }
    }

    function persistCurrentState(form, state) {
        const currentDescriptor = descriptor(form);

        form.dataset.mesaStateCurrent = state;

        if (!currentDescriptor) {
            return;
        }

        if (currentDescriptor.kind === 'next-input') {
            currentDescriptor.control.value = opposite(state);
        } else if (currentDescriptor.kind === 'solution-action') {
            currentDescriptor.control.value = state === ACTIVE ? 'eliminar' : 'reactivar';
        } else if (currentDescriptor.kind === 'flow-select') {
            currentDescriptor.control.value = state;
        }
    }

    function showToast(message, type = 'success') {
        let toast = document.getElementById('mesa-state-toast');

        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'mesa-state-toast';
            toast.className = 'mesa-state-toast';
            toast.setAttribute('role', 'status');
            toast.setAttribute('aria-live', 'polite');
            document.body.append(toast);
        }

        window.clearTimeout(toastTimer);
        toast.className = `mesa-state-toast ${type}`;
        toast.textContent = message;
        toast.hidden = false;
        requestAnimationFrame(() => toast.classList.add('visible'));
        toastTimer = window.setTimeout(() => {
            toast.classList.remove('visible');
            window.setTimeout(() => { toast.hidden = true; }, 180);
        }, 3200);
    }

    async function submitState(form) {
        if (form.dataset.mesaStateBusy === '1') {
            return;
        }

        const initial = descriptor(form);
        const button = form.querySelector('.mesa-state-toggle');

        if (!initial || !button) {
            return;
        }

        const current = form.dataset.mesaStateCurrent || initial.current;
        const next = opposite(current);
        const formData = new FormData(form);

        if (initial.kind === 'flow-select') {
            formData.set('estado', next);
        }

        form.dataset.mesaStateBusy = '1';
        form.setAttribute('aria-busy', 'true');
        button.disabled = true;
        button.classList.add('is-loading');

        try {
            const response = await fetch(form.action || window.location.href, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin',
                cache: 'no-store',
                headers: {
                    'Accept': 'text/html,application/xhtml+xml',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });
            if (!response.ok) {
                throw new Error('No fue posible actualizar el estado.');
            }

            const contentType = response.headers.get('content-type') || '';
            let returnedDocument = null;
            let returnedState = null;
            let errorMessage = '';

            if (contentType.includes('application/json')) {
                const result = await response.json();
                returnedState = result.estado || null;
                errorMessage = result.error || '';
            } else {
                const html = await response.text();
                returnedDocument = new DOMParser().parseFromString(html, 'text/html');
                const returnedForm = findReturnedForm(returnedDocument, initial);
                returnedState = returnedForm ? descriptor(returnedForm)?.current : null;
                const errorNode = returnedDocument.querySelector(
                    '.alert.error, .alerta.error, .mensaje.error, .flash.error'
                );
                errorMessage = errorNode?.textContent.trim() || '';
            }

            if ((returnedState && returnedState !== next) || (!returnedState && errorMessage)) {
                throw new Error(errorMessage || 'El servidor no confirmó el cambio de estado.');
            }

            persistCurrentState(form, next);
            setButton(button, next);
            copyStateNode(form, returnedForm, next);
            copyFlowSidebar(next, returnedDocument, initial.identity);
            document.dispatchEvent(new CustomEvent('mesa:state-changed', {
                detail: {
                    state: next,
                    identity: initial.identity,
                    form
                }
            }));
            showToast(next === ACTIVE ? 'Registro habilitado correctamente.' : 'Registro inhabilitado correctamente.');
        } catch (error) {
            setButton(button, current);
            showToast(
                error instanceof Error ? error.message : 'No fue posible actualizar el estado.',
                'error'
            );
        } finally {
            form.dataset.mesaStateBusy = '0';
            form.removeAttribute('aria-busy');
            button.disabled = false;
            button.classList.remove('is-loading');
        }
    }

    document.querySelectorAll('form').forEach(prepareForm);
    document.addEventListener('submit', (event) => {
        const form = event.target.closest('form[data-mesa-state-prepared="1"]');

        if (!form) {
            return;
        }

        event.preventDefault();
        event.stopImmediatePropagation();
        submitState(form);
    }, true);
})();
