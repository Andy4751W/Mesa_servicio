<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/app/bootstrap.php';

/** @var array<string, string> $entradas */
$entradas = require APP_ROOT . '/routes.php';
$entrada = basename((string) ($_SERVER['SCRIPT_FILENAME'] ?? ''));
$archivo = $entradas[$entrada] ?? null;

if ($archivo === null || !is_file($archivo)) {
    http_response_code(404);
    exit('Recurso no encontrado.');
}

/*
 * Registra de forma central las modificaciones confirmadas. El registro se
 * ejecuta al terminar la solicitud y solo se conserva si la respuesta fue
 * satisfactoria o una redirección normal.
 */
$auditoriaEntradas = [
    'abrirNotificacion.php', 'actualizarTicket.php', 'adminAcciones.php',
    'apariencia.php', 'asignarTicket.php', 'catalogos.php',
    'configuraciones.php', 'crearUsuarios.php', 'crearticket.php',
    'editarUsuario.php', 'editarcatalogos.php', 'enviarMensaje.php',
    'feriados.php', 'flujoTicket.php', 'imagenCatalogo.php',
    'imagenPerfil.php', 'mensajesApi.php', 'perfil.php', 'prioridades.php',
    'papelera.php', 'procesos.php', 'Registro.php', 'servicios.php', 'sla.php',
    'soluciones.php', 'verificarCalendarioSla.php', 'verificarFlujos.php',
];
if (
    ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'
    && in_array($entrada, $auditoriaEntradas, true)
) {
    require_once APP_ROOT . '/security/seguridad.php';
    seguridadIniciarSesion();
    $auditoriaIdUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
    $auditoriaToken = (string) ($_SESSION['sesion_unica_token'] ?? '');
    if ($auditoriaIdUsuario > 0 && strlen($auditoriaToken) === 64) {
        require_once APP_ROOT . '/core/auditoriaSesiones.php';
        auditoriaProgramarRegistro(
            $entrada,
            $_POST,
            $auditoriaIdUsuario,
            $auditoriaToken,
            (string) ($_SERVER['REMOTE_ADDR'] ?? '')
        );
    }
}

$pantallasEnmarcadas = [
    'apariencia.php', 'catalogos.php', 'checklists.php', 'chat.php',
    'configuraciones.php',
    'crearUsuarios.php', 'crearticket.php', 'diagnostico_relaciones.php',
    'editarUsuario.php', 'editarcatalogos.php', 'feriados.php',
    'flujoTicket.php', 'indicadores.php', 'mensajes.php', 'panelAdmin.php', 'papelera.php',
    'panelGestor.php', 'panelSolicitante.php', 'perfil.php', 'prioridades.php',
    'procesos.php', 'Registro.php',
    'seleccionarPais.php', 'servicios.php', 'sesiones.php', 'sla.php', 'solicitudes.php',
    'soluciones.php', 'verificarActualizacionSolicitudes.php',
    'verificarCalendarioSla.php', 'verificarFlujos.php',
];
$esPantallaEnmarcada = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET'
    && in_array($entrada, $pantallasEnmarcadas, true);
$esRecuperacion = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET'
    && strcasecmp($entrada, 'recuperarPassword.php') === 0;

if ($esPantallaEnmarcada || $esRecuperacion) {
    require_once APP_ROOT . '/security/seguridad.php';
    seguridadIniciarSesion();
    $destinoNavegacion = strtolower((string) (
        $_SERVER['HTTP_SEC_FETCH_DEST'] ?? ''
    ));
    $esPrecargaNavegacion = $destinoNavegacion === 'iframe'
        && (string) ($_GET['_mesa_prefetch'] ?? '') === '1';

    $esPantallaAuxiliar = in_array(
        $entrada,
        ['apariencia.php', 'perfil.php'],
        true
    );

    if (
        $esPantallaEnmarcada
        && !$esPrecargaNavegacion
        && !empty($_SESSION['usuario_id'])
        && (!$esPantallaAuxiliar || $destinoNavegacion === 'document')
    ) {
        $_SESSION['mesa_ultima_pantalla'] = $entrada;
    } elseif ($esRecuperacion && $destinoNavegacion === 'document') {
        $_SESSION['mesa_pantalla_publica'] = 'recuperarPassword.php';
    }

    /* Una pantalla abierta directamente vuelve a la URL unica del portal. */
    if ($destinoNavegacion === 'document') {
        header('Location: ' . mesaUrlInicio(), true, 302);
        exit;
    }
}

// El selector de país es una pantalla de transición. Debe renderizarse sin
// navegación, encabezado ni controles del panel administrativo.
if (strcasecmp($entrada, 'seleccionarPais.php') === 0) {
    require $archivo;
    return;
}

$paginasVisuales = [
    'catalogos.php', 'checklists.php', 'chat.php', 'configuraciones.php',
    'crearUsuarios.php', 'crearticket.php', 'diagnostico_relaciones.php',
    'editarUsuario.php', 'editarcatalogos.php', 'feriados.php', 'flujoTicket.php',
    'indicadores.php', 'mensajes.php', 'panelAdmin.php', 'papelera.php', 'panelGestor.php', 'panelSolicitante.php',
    'procesos.php', 'Registro.php', 'servicios.php', 'sesiones.php', 'sla.php', 'solicitudes.php',
    'soluciones.php', 'verificarActualizacionSolicitudes.php',
    'verificarCalendarioSla.php', 'verificarFlujos.php',
];

$esPaginaVisual = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET'
    && in_array($entrada, $paginasVisuales, true);

if (!$esPaginaVisual) {
    require $archivo;
    return;
}

ob_start();
require $archivo;
$salida = (string) ob_get_clean();

// Evita que una vista antigua cargue otra interfaz o un controlador visual.
$salida = (string) preg_replace(
    '~<script\b[^>]*\bsrc=["\'][^"\']*assets/js/controlSesion\.js[^"\']*["\'][^>]*>\s*</script>~i',
    '',
    $salida
);

if (stripos($salida, 'data-mesa-php-shell') === false && stripos($salida, '</body>') !== false) {
    ob_start();
    require APP_ROOT . '/components/controlesCuenta.php';
    $controles = (string) ob_get_clean();
    $salida = (string) preg_replace('/<\/body>/i', $controles . '</body>', $salida, 1);
}

/*
 * El monitor vive exclusivamente en la ventana principal (index.php). Los
 * módulos se muestran dentro de su iframe y no deben crear temporizadores ni
 * avisos propios al navegar entre pantallas.
 */
$salida = (string) preg_replace(
    '~<script\b[^>]*\bsrc=["\'][^"\']*assets/js/controlSesion\.js[^"\']*["\'][^>]*>\s*</script>~i',
    '',
    $salida
);

// La hoja corporativa se mueve al final del <head> y la clase del tema se
// agrega desde el servidor. Así el navegador aplica la apariencia elegida
// antes de mostrar el primer fotograma y no aparece un destello blanco.
$patronEstiloCorporativo = '~<style\b[^>]*\bid=["\']mesa-php-shell-style["\'][^>]*>[\s\S]*?<\/style>~i';
if (
    preg_match($patronEstiloCorporativo, $salida, $coincidenciaEstilo) === 1
    && stripos($salida, '</head>') !== false
) {
    $estiloCorporativo = (string) ($coincidenciaEstilo[0] ?? '');
    $salida = (string) preg_replace($patronEstiloCorporativo, '', $salida, 1);
    $salida = (string) preg_replace(
        '/<\/head>/i',
        $estiloCorporativo . '</head>',
        $salida,
        1
    );

    $salida = (string) preg_replace_callback(
        '/<body\b[^>]*>/i',
        static function (array $coincidencia): string {
            $etiquetaBody = (string) ($coincidencia[0] ?? '<body>');

            if (preg_match(
                '/\bclass\s*=\s*(["\'])(.*?)\1/i',
                $etiquetaBody,
                $coincidenciaClase
            ) === 1) {
                $clases = preg_split(
                    '/\s+/',
                    trim((string) ($coincidenciaClase[2] ?? ''))
                ) ?: [];

                if (!in_array('mesa-php-shell', $clases, true)) {
                    $clases[] = 'mesa-php-shell';
                }

                $atributoClase = 'class=' . $coincidenciaClase[1]
                    . implode(' ', array_filter($clases))
                    . $coincidenciaClase[1];

                return (string) preg_replace(
                    '/\bclass\s*=\s*(["\'])(.*?)\1/i',
                    $atributoClase,
                    $etiquetaBody,
                    1
                );
            }

            return substr($etiquetaBody, 0, -1)
                . ' class="mesa-php-shell">';
        },
        $salida,
        1
    );
}

echo $salida;
