# Mesa de Servicio Conectar

Aplicación web para administrar la oferta de servicios, crear solicitudes y gestionar tickets mediante etapas, derivaciones, checklist, conversaciones, adjuntos, SLA, notificaciones y calificaciones.

## Plataforma

- PHP 7.4 o superior.
- Apache con reescritura habilitada.
- MySQL/MariaDB.
- Extensiones PHP `mysqli`, `fileinfo` y `curl`.
- n8n y Microsoft 365 para correo, cuando la integración esté habilitada.
- Microsoft Graph con permiso limitado a `Mds_Storage` para adjuntos e imágenes.

## Documentación principal

Toda la documentación técnica y operativa está consolidada en un único archivo:

`docs/DOCUMENTACION_COMPLETA_MESA_SERVICIO.md`

Incluye arquitectura, conexiones, rutas, módulos, tablas, columnas, reglas de negocio, Uniclass, n8n, Microsoft 365, almacenamiento, seguridad, despliegue, auditoría y pautas para futuras modificaciones asistidas por IA.

## Arquitectura de entrada

El recorrido normal es:

`index.php` → `public/<ruta>.php` → `public/_entry.php` → `app/routes.php` → `app/modules/<módulo>.php` → `app/core/*` → datos o integración.

La base principal es `mds_GC2026`. La consulta externa de personal utiliza `SRCGC.mae_data_uniclass` y `SRCGC.mae_ciudades`. Las nuevas imágenes y adjuntos se guardan en Microsoft Graph; `mds_storage` permanece como lectura histórica.

## Advertencia de despliegue

La definición aditiva de `storage_objetos` está en `database/migrations/007_almacenamiento_graph.sql`. La aplicación también crea esa tabla al efectuar la primera carga remota, por lo que no se debe reimportar un dump completo sobre una instalación en uso.

Antes de producción:

1. respalde la base, la carpeta Graph y el almacenamiento histórico;
2. retire y rote cualquier secreto que haya circulado dentro del código o de archivos comprimidos;
3. use variables de entorno o un archivo privado no publicado;
4. excluya bases SQLite locales, logs, cachés y configuraciones de transferencia;
5. valide sintaxis con PHP 7.4 y ejecute pruebas controladas fuera de producción;
6. conserve el `mds_storage` existente hasta migrar y conciliar todos los históricos.

Consulte el capítulo **Seguridad y producción** de `docs/DOCUMENTACION_COMPLETA_MESA_SERVICIO.md` antes de publicar.
