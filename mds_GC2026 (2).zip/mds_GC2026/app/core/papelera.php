<?php
declare(strict_types=1);

function papeleraDisponible(mysqli $conn): bool
{
    static $disponible = null;

    if ($disponible === null) {
        $resultado = $conn->query("SHOW TABLES LIKE 'papelera'");
        $disponible = $resultado !== false && $resultado->num_rows > 0;
    }

    return $disponible;
}

/** @param array<string,mixed> $datos */
function papeleraArchivar(
    mysqli $conn,
    string $tipo,
    int $idRegistro,
    int $idPaisOperacion,
    string $nombre,
    array $datos,
    int $idUsuario
): void {
    if (!papeleraDisponible($conn)) {
        throw new RuntimeException('La papelera todavía no está instalada.');
    }

    $json = json_encode(
        $datos,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR
    );
    $stmt = $conn->prepare(
        "INSERT INTO papelera
            (tipo, id_registro, id_pais_operacion, nombre, datos, eliminado_por)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
            nombre = VALUES(nombre),
            datos = VALUES(datos),
            eliminado_por = VALUES(eliminado_por),
            eliminado_en = NOW()"
    );
    $stmt->bind_param(
        'siissi',
        $tipo,
        $idRegistro,
        $idPaisOperacion,
        $nombre,
        $json,
        $idUsuario
    );
    $stmt->execute();
    $stmt->close();
}

/** @return array<string,mixed> */
function papeleraDecodificar(string $json): array
{
    $datos = json_decode($json, true);
    return is_array($datos) ? $datos : [];
}

