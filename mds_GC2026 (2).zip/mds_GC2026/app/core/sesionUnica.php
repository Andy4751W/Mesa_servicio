<?php
declare(strict_types=1);

/**
 * Control de sesiones por dispositivo.
 * Administradores y gestores pueden abrir varias; los solicitantes conservan
 * una sola sesión activa.
 */

function sesionUnicaHuella(string $token): string
{
    return hash('sha256', $token);
}

/** @return array{ip:string,agente:string,dispositivo:string,sistema:string,navegador:string} */
function sesionClienteActual(): array
{
    $ip = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
    if (!filter_var($ip, FILTER_VALIDATE_IP)) {
        $ip = '0.0.0.0';
    }

    $agente = substr(trim((string) ($_SERVER['HTTP_USER_AGENT'] ?? '')), 0, 500);
    $agenteMinuscula = strtolower($agente);

    if (strpos($agenteMinuscula, 'ipad') !== false || strpos($agenteMinuscula, 'tablet') !== false) {
        $dispositivo = 'Tableta';
    } elseif (strpos($agenteMinuscula, 'mobile') !== false || strpos($agenteMinuscula, 'android') !== false) {
        $dispositivo = 'Celular';
    } else {
        $dispositivo = 'Computador';
    }

    if (strpos($agente, 'Windows NT') !== false) {
        $sistema = 'Windows';
    } elseif (strpos($agente, 'Android') !== false) {
        $sistema = 'Android';
    } elseif (strpos($agente, 'iPhone') !== false || strpos($agente, 'iPad') !== false) {
        $sistema = 'iOS/iPadOS';
    } elseif (strpos($agente, 'Mac OS X') !== false || strpos($agente, 'Macintosh') !== false) {
        $sistema = 'macOS';
    } elseif (strpos($agenteMinuscula, 'linux') !== false) {
        $sistema = 'Linux';
    } else {
        $sistema = 'No identificado';
    }

    if (preg_match('/Edg(?:A|iOS)?\/([0-9.]+)/', $agente, $coincidencia)) {
        $navegador = 'Microsoft Edge ' . $coincidencia[1];
    } elseif (preg_match('/OPR\/([0-9.]+)/', $agente, $coincidencia)) {
        $navegador = 'Opera ' . $coincidencia[1];
    } elseif (preg_match('/Firefox\/([0-9.]+)/', $agente, $coincidencia)) {
        $navegador = 'Firefox ' . $coincidencia[1];
    } elseif (preg_match('/Chrome\/([0-9.]+)/', $agente, $coincidencia)) {
        $navegador = 'Chrome ' . $coincidencia[1];
    } elseif (preg_match('/Version\/([0-9.]+).*Safari/', $agente, $coincidencia)) {
        $navegador = 'Safari ' . $coincidencia[1];
    } else {
        $navegador = 'No identificado';
    }

    return [
        'ip' => $ip,
        'agente' => $agente,
        'dispositivo' => $dispositivo,
        'sistema' => $sistema,
        'navegador' => $navegador,
    ];
}

function sesionRegistrarAcceso(
    mysqli $conn,
    int $idUsuario,
    string $token
): void
{
    $cliente = sesionClienteActual();
    $huella = sesionUnicaHuella($token);
    $idSesionPhp = substr(session_id(), 0, 128);
    $stmt = $conn->prepare(
        "INSERT INTO sesiones_usuario
            (id_usuario, token_hash, php_session_id, direccion_ip,
             agente_usuario, tipo_dispositivo, sistema_operativo, navegador,
             inicio_en, ultima_actividad_en)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())"
    );
    $stmt->bind_param(
        'isssssss',
        $idUsuario,
        $huella,
        $idSesionPhp,
        $cliente['ip'],
        $cliente['agente'],
        $cliente['dispositivo'],
        $cliente['sistema'],
        $cliente['navegador']
    );
    $stmt->execute();
    $stmt->close();
}

function sesionUnicaCrear(
    mysqli $conn,
    int $idUsuario,
    int $rol = 0
): string
{
    if ($idUsuario < 1) {
        throw new InvalidArgumentException('El usuario de la sesión no es válido.');
    }

    if ($rol < 1) {
        $stmtRol = $conn->prepare('SELECT id_rol FROM usuarios WHERE id_usuario = ? LIMIT 1');
        $stmtRol->bind_param('i', $idUsuario);
        $stmtRol->execute();
        $filaRol = $stmtRol->get_result()->fetch_assoc();
        $stmtRol->close();
        $rol = (int) ($filaRol['id_rol'] ?? 0);
    }

    $token = bin2hex(random_bytes(32));
    $huella = sesionUnicaHuella($token);

    $conn->begin_transaction();
    try {
        if ($rol === 3) {
            $stmtAnteriores = $conn->prepare(
                "UPDATE sesiones_usuario
                 SET cerrada_en = NOW(), motivo_cierre = 'reemplazada'
                 WHERE id_usuario = ? AND cerrada_en IS NULL"
            );
            $stmtAnteriores->bind_param('i', $idUsuario);
            $stmtAnteriores->execute();
            $stmtAnteriores->close();

            $stmtUsuario = $conn->prepare(
                'UPDATE usuarios SET sesion_activa_hash = ?, sesion_activa_en = NOW() WHERE id_usuario = ?'
            );
            $stmtUsuario->bind_param('si', $huella, $idUsuario);
        } else {
            $stmtUsuario = $conn->prepare(
                'UPDATE usuarios SET sesion_activa_hash = NULL, sesion_activa_en = NULL WHERE id_usuario = ?'
            );
            $stmtUsuario->bind_param('i', $idUsuario);
        }

        $stmtUsuario->execute();
        $stmtUsuario->close();
        sesionRegistrarAcceso($conn, $idUsuario, $token);
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }

    return $token;
}

function sesionUnicaVigente(int $idUsuario, string $token, ?string $huellaGuardada): bool
{
    $huellaGuardada = trim((string) $huellaGuardada);
    return $idUsuario > 0
        && strlen($token) === 64
        && strlen($huellaGuardada) === 64
        && hash_equals($huellaGuardada, sesionUnicaHuella($token));
}

function sesionAccesoVigente(
    mysqli $conn,
    int $idUsuario,
    int $rol,
    string $token,
    ?string $huellaGuardada
): bool {
    if ($idUsuario < 1 || strlen($token) !== 64) {
        return false;
    }
    if ($rol === 3 && !sesionUnicaVigente($idUsuario, $token, $huellaGuardada)) {
        return false;
    }

    $huella = sesionUnicaHuella($token);
    $stmt = $conn->prepare(
        'SELECT id_sesion FROM sesiones_usuario
         WHERE id_usuario = ? AND token_hash = ? AND cerrada_en IS NULL LIMIT 1'
    );
    $stmt->bind_param('is', $idUsuario, $huella);
    $stmt->execute();
    $stmt->store_result();
    $vigente = $stmt->num_rows === 1;
    $stmt->close();
    return $vigente;
}

function sesionRegistrarActividad(mysqli $conn, int $idUsuario, string $token): void
{
    if ($idUsuario < 1 || strlen($token) !== 64) {
        return;
    }
    $huella = sesionUnicaHuella($token);
    $stmt = $conn->prepare(
        'UPDATE sesiones_usuario SET ultima_actividad_en = NOW()
         WHERE id_usuario = ? AND token_hash = ? AND cerrada_en IS NULL'
    );
    $stmt->bind_param('is', $idUsuario, $huella);
    $stmt->execute();
    $stmt->close();
}

function sesionRegistrarPais(
    mysqli $conn,
    int $idUsuario,
    string $token,
    int $idPaisOperacion
): void {
    if ($idUsuario < 1 || strlen($token) !== 64 || $idPaisOperacion < 1) {
        return;
    }

    $huella = sesionUnicaHuella($token);
    $stmt = $conn->prepare(
        "INSERT INTO sesiones_usuario_paises
            (id_sesion, id_pais_operacion, primera_visita_en, ultima_visita_en)
         SELECT id_sesion, ?, NOW(), NOW()
         FROM sesiones_usuario
         WHERE id_usuario = ? AND token_hash = ?
         ON DUPLICATE KEY UPDATE ultima_visita_en = NOW()"
    );
    $stmt->bind_param('iis', $idPaisOperacion, $idUsuario, $huella);
    $stmt->execute();
    $stmt->close();
}

function sesionUnicaCerrar(
    mysqli $conn,
    int $idUsuario,
    string $token,
    string $motivo = 'cerrada'
): bool {
    if ($idUsuario < 1 || strlen($token) !== 64) {
        return false;
    }
    $motivos = [
        'cerrada', 'inactividad', 'tiempo_maximo', 'sesion_expirada',
        'sesion_reemplazada', 'reemplazada', 'pestana_cerrada',
        'sesion_inhabilitada', 'credenciales', 'rol', 'sistema',
    ];
    if (!in_array($motivo, $motivos, true)) {
        $motivo = 'cerrada';
    }

    $huella = sesionUnicaHuella($token);
    $stmtRegistro = $conn->prepare(
        'UPDATE sesiones_usuario SET cerrada_en = NOW(), motivo_cierre = ?
         WHERE id_usuario = ? AND token_hash = ? AND cerrada_en IS NULL'
    );
    $stmtRegistro->bind_param('sis', $motivo, $idUsuario, $huella);
    $stmtRegistro->execute();
    $registroCerrado = $stmtRegistro->affected_rows > 0;
    $stmtRegistro->close();

    $stmtUsuario = $conn->prepare(
        'UPDATE usuarios SET sesion_activa_hash = NULL, sesion_activa_en = NULL
         WHERE id_usuario = ? AND sesion_activa_hash = ?'
    );
    $stmtUsuario->bind_param('is', $idUsuario, $huella);
    $stmtUsuario->execute();
    $usuarioCerrado = $stmtUsuario->affected_rows > 0;
    $stmtUsuario->close();
    return $registroCerrado || $usuarioCerrado;
}

function sesionUsuarioTieneAccesoActivo(mysqli $conn, int $idUsuario): bool
{
    if ($idUsuario < 1) {
        return false;
    }
    $stmt = $conn->prepare(
        'SELECT id_sesion FROM sesiones_usuario
         WHERE id_usuario = ? AND cerrada_en IS NULL
           AND ultima_actividad_en >= DATE_SUB(NOW(), INTERVAL 90 SECOND)
         LIMIT 1'
    );
    $stmt->bind_param('i', $idUsuario);
    $stmt->execute();
    $stmt->store_result();
    $activa = $stmt->num_rows > 0;
    $stmt->close();
    return $activa;
}
