<?php
declare(strict_types=1);


/*
 * Compatibilidad PHP 7.4: valores por defecto para constantes opcionales
 * del almacenamiento Graph. Pueden ser reemplazadas por la configuración real.
 */
defined('MDS_GRAPH_TENANT_ID') || define('MDS_GRAPH_TENANT_ID', '');
defined('MDS_GRAPH_CLIENT_ID') || define('MDS_GRAPH_CLIENT_ID', '');
defined('MDS_GRAPH_DRIVE_ID') || define('MDS_GRAPH_DRIVE_ID', '');
defined('MDS_GRAPH_ROOT_ITEM_ID') || define('MDS_GRAPH_ROOT_ITEM_ID', '');
defined('MDS_GRAPH_SECRET_FILE') || define('MDS_GRAPH_SECRET_FILE', '');
defined('MDS_GRAPH_CONNECT_TIMEOUT_SECONDS') || define('MDS_GRAPH_CONNECT_TIMEOUT_SECONDS', 10);
defined('MDS_GRAPH_TIMEOUT_SECONDS') || define('MDS_GRAPH_TIMEOUT_SECONDS', 60);
defined('MDS_GRAPH_MAX_RETRIES') || define('MDS_GRAPH_MAX_RETRIES', 2);


/**
 * Proveedor de almacenamiento de la Mesa de Servicio.
 *
 * Los módulos conservan las validaciones de negocio y delegan aquí únicamente
 * la persistencia del binario. Las referencias Graph tienen el formato
 * graph:<driveItem.id>; los registros históricos continúan usando rutas locales.
 */

final class AlmacenamientoHttpException extends RuntimeException
{
    /** @var int */
    private $estadoHttp;

    public function __construct(string $mensaje, int $estadoHttp)
    {
        parent::__construct($mensaje, $estadoHttp);
        $this->estadoHttp = $estadoHttp;
    }

    public function estadoHttp(): int
    {
        return $this->estadoHttp;
    }
}

function almacenamientoDriver(): string
{
    $driver = strtolower(trim((string) (
        defined('MDS_STORAGE_DRIVER') ? MDS_STORAGE_DRIVER : 'local'
    )));

    return $driver === 'graph' ? 'graph' : 'local';
}

function almacenamientoUsaGraph(): bool
{
    return almacenamientoDriver() === 'graph';
}

function almacenamientoEsReferenciaGraph(string $referencia): bool
{
    return strpos(trim($referencia), 'graph:') === 0
        && strlen(trim($referencia)) > 6;
}

function almacenamientoItemId(string $referencia): string
{
    if (!almacenamientoEsReferenciaGraph($referencia)) {
        throw new InvalidArgumentException('La referencia remota no es válida.');
    }

    return substr(trim($referencia), 6);
}

function almacenamientoExigirGraph(): void
{
    if (!extension_loaded('curl')) {
        throw new RuntimeException('El servidor no tiene habilitada la extensión cURL.');
    }

    foreach (
        [
            'MDS_GRAPH_TENANT_ID',
            'MDS_GRAPH_CLIENT_ID',
            'MDS_GRAPH_DRIVE_ID',
            'MDS_GRAPH_ROOT_ITEM_ID',
        ] as $constante
    ) {
        if (!defined($constante) || trim((string) constant($constante)) === '') {
            throw new RuntimeException('La configuración del almacenamiento remoto está incompleta.');
        }
    }

    $secretoEntorno = trim((string) (getenv('MDS_GRAPH_CLIENT_SECRET') ?: ''));
    $archivoSecreto = defined('MDS_GRAPH_SECRET_FILE')
        ? (string) MDS_GRAPH_SECRET_FILE
        : '';
    if (
        $secretoEntorno === ''
        && ($archivoSecreto === '' || !is_file($archivoSecreto) || !is_readable($archivoSecreto))
    ) {
        throw new RuntimeException('La credencial del almacenamiento remoto no está disponible.');
    }
}

/**
 * Caché privada y prescindible para evitar autenticar y recorrer las mismas
 * carpetas de Graph en cada petición PHP. Si el servidor no permite escribir
 * la caché, el almacenamiento continúa funcionando con el flujo normal.
 */
function almacenamientoCacheRuta(string $nombre): string
{
    $base = function_exists('seguridadDirectorioPrivado')
        ? seguridadDirectorioPrivado('cache_graph')
        : rtrim((string) MESA_STORAGE_PATH, '/\\') . DIRECTORY_SEPARATOR . 'cache_graph';

    if (!is_dir($base)) {
        @mkdir($base, 0750, true);
    }

    return $base . DIRECTORY_SEPARATOR . $nombre;
}

/** @return array<string,mixed> */
function almacenamientoCacheLeer(string $nombre): array
{
    try {
        $ruta = almacenamientoCacheRuta($nombre);
        if (!is_file($ruta) || !is_readable($ruta)) {
            return [];
        }
        $contenido = @file_get_contents($ruta);
        $datos = is_string($contenido) ? json_decode($contenido, true) : null;
        return is_array($datos) ? $datos : [];
    } catch (Throwable $e) {
        return [];
    }
}

/** @param array<string,mixed> $datos */
function almacenamientoCacheEscribir(string $nombre, array $datos): void
{
    try {
        $ruta = almacenamientoCacheRuta($nombre);
        $json = json_encode($datos, JSON_UNESCAPED_SLASHES);
        if (!is_string($json) || !is_dir(dirname($ruta))) {
            return;
        }
        $temporal = $ruta . '.' . bin2hex(random_bytes(6)) . '.tmp';
        if (@file_put_contents($temporal, $json, LOCK_EX) === false) {
            return;
        }
        @chmod($temporal, 0640);
        if (!@rename($temporal, $ruta)) {
            /* Windows no reemplaza siempre un archivo existente con rename(). */
            if (@file_put_contents($ruta, $json, LOCK_EX) !== false) {
                @chmod($ruta, 0640);
            }
            @unlink($temporal);
        }
    } catch (Throwable $e) {
        /* La caché acelera la operación, pero nunca debe impedir una carga. */
    }
}

function almacenamientoGraphAmbito(string $tipo): string
{
    $componentes = $tipo === 'token'
        ? [(string) MDS_GRAPH_TENANT_ID, (string) MDS_GRAPH_CLIENT_ID]
        : [(string) MDS_GRAPH_DRIVE_ID, (string) MDS_GRAPH_ROOT_ITEM_ID];

    return hash('sha256', implode('|', $componentes));
}

function almacenamientoGraphToken(bool $forzar = false): string
{
    static $token = '';
    static $venceEn = 0;

    almacenamientoExigirGraph();

    if (!$forzar && $token !== '' && $venceEn > time() + 120) {
        return $token;
    }

    $ambitoToken = almacenamientoGraphAmbito('token');
    if (!$forzar) {
        $cacheToken = almacenamientoCacheLeer('token-' . $ambitoToken . '.json');
        $tokenCache = trim((string) ($cacheToken['token'] ?? ''));
        $venceCache = (int) ($cacheToken['vence_en'] ?? 0);
        if ($tokenCache !== '' && $venceCache > time() + 120) {
            $token = $tokenCache;
            $venceEn = $venceCache;
            return $token;
        }
    }

    $secretoEntorno = trim((string) (getenv('MDS_GRAPH_CLIENT_SECRET') ?: ''));
    $secreto = $secretoEntorno !== ''
        ? $secretoEntorno
        : trim((string) file_get_contents((string) MDS_GRAPH_SECRET_FILE));
    if ($secreto === '') {
        throw new RuntimeException('La credencial del almacenamiento remoto está vacía.');
    }

    $url = 'https://login.microsoftonline.com/'
        . rawurlencode((string) MDS_GRAPH_TENANT_ID)
        . '/oauth2/v2.0/token';
    $cuerpo = http_build_query(
        [
            'client_id' => (string) MDS_GRAPH_CLIENT_ID,
            'client_secret' => $secreto,
            'scope' => 'https://graph.microsoft.com/.default',
            'grant_type' => 'client_credentials',
        ],
        '',
        '&',
        PHP_QUERY_RFC3986
    );

    $curl = curl_init($url);
    if ($curl === false) {
        throw new RuntimeException('No fue posible iniciar la conexión con Microsoft.');
    }

    curl_setopt_array(
        $curl,
        [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $cuerpo,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => (int) MDS_GRAPH_CONNECT_TIMEOUT_SECONDS,
            CURLOPT_TIMEOUT => (int) MDS_GRAPH_TIMEOUT_SECONDS,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]
    );
    $respuesta = curl_exec($curl);
    $estado = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    $error = curl_error($curl);
    curl_close($curl);

    if (!is_string($respuesta) || $estado < 200 || $estado >= 300) {
        error_log('Storage token: HTTP ' . $estado . ($error !== '' ? ' cURL.' : '.'));
        throw new RuntimeException('No fue posible autenticar el almacenamiento remoto.');
    }

    $datos = json_decode($respuesta, true);
    $tokenNuevo = is_array($datos) ? (string) ($datos['access_token'] ?? '') : '';
    $expira = is_array($datos) ? (int) ($datos['expires_in'] ?? 0) : 0;

    if ($tokenNuevo === '' || $expira < 60) {
        throw new RuntimeException('Microsoft no entregó una sesión de almacenamiento válida.');
    }

    $token = $tokenNuevo;
    $venceEn = time() + $expira;
    almacenamientoCacheEscribir(
        'token-' . $ambitoToken . '.json',
        ['token' => $token, 'vence_en' => $venceEn]
    );
    return $token;
}

/**
 * @param array<int,string> $cabeceras
 * @return array{estado:int,cuerpo:string,cabeceras:array<string,string>}
 */
function almacenamientoGraphSolicitud(
    string $metodo,
    string $ruta,
    ?string $cuerpo = null,
    array $cabeceras = [],
    bool $seguirRedireccion = false
): array {
    $url = 'https://graph.microsoft.com/v1.0/' . ltrim($ruta, '/');
    $maximos = max(0, (int) MDS_GRAPH_MAX_RETRIES);
    $renovoToken = false;

    for ($intento = 0; $intento <= $maximos; $intento++) {
        $headersRespuesta = [];
        $token = almacenamientoGraphToken($renovoToken);
        $curl = curl_init($url);
        if ($curl === false) {
            throw new RuntimeException('No fue posible iniciar la operación de almacenamiento.');
        }

        $opciones = [
            CURLOPT_CUSTOMREQUEST => strtoupper($metodo),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => (int) MDS_GRAPH_CONNECT_TIMEOUT_SECONDS,
            CURLOPT_TIMEOUT => (int) MDS_GRAPH_TIMEOUT_SECONDS,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => $seguirRedireccion,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_UNRESTRICTED_AUTH => false,
            CURLOPT_HTTPHEADER => array_merge(
                ['Authorization: Bearer ' . $token, 'Accept: application/json'],
                $cabeceras
            ),
            CURLOPT_HEADERFUNCTION => static function ($recurso, string $linea) use (&$headersRespuesta): int {
                $longitud = strlen($linea);
                $partes = explode(':', $linea, 2);
                if (count($partes) === 2) {
                    $headersRespuesta[strtolower(trim($partes[0]))] = trim($partes[1]);
                }
                return $longitud;
            },
        ];
        if ($cuerpo !== null) {
            $opciones[CURLOPT_POSTFIELDS] = $cuerpo;
        }
        curl_setopt_array($curl, $opciones);
        $respuesta = curl_exec($curl);
        $estado = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $error = curl_error($curl);
        curl_close($curl);

        if (is_string($respuesta) && $estado >= 200 && $estado < 300) {
            return ['estado' => $estado, 'cuerpo' => $respuesta, 'cabeceras' => $headersRespuesta];
        }

        if ($estado === 401 && !$renovoToken) {
            $renovoToken = true;
            continue;
        }

        if (($estado === 429 || $estado === 503) && $intento < $maximos) {
            $espera = isset($headersRespuesta['retry-after'])
                ? (int) $headersRespuesta['retry-after']
                : (1 << $intento);
            sleep(max(1, min($espera, 5)));
            continue;
        }

        error_log(
            'Storage Graph: ' . strtoupper($metodo) . ' HTTP ' . $estado
            . ($error !== '' ? ' cURL.' : '.')
            . (isset($headersRespuesta['request-id'])
                ? ' Request ' . $headersRespuesta['request-id'] . '.'
                : '')
        );
        throw new AlmacenamientoHttpException(
            'El almacenamiento remoto no pudo completar la operación.',
            $estado
        );
    }

    throw new RuntimeException('El almacenamiento remoto agotó los reintentos.');
}

/** @return array<string,mixed> */
function almacenamientoGraphJson(
    string $metodo,
    string $ruta,
    ?array $datos = null
): array {
    $cuerpo = $datos === null
        ? null
        : json_encode($datos, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($datos !== null && !is_string($cuerpo)) {
        throw new RuntimeException('No fue posible preparar la operación de almacenamiento.');
    }
    $respuesta = almacenamientoGraphSolicitud(
        $metodo,
        $ruta,
        $cuerpo,
        $datos === null ? [] : ['Content-Type: application/json']
    );
    if ($respuesta['cuerpo'] === '') {
        return [];
    }
    $json = json_decode($respuesta['cuerpo'], true);
    if (!is_array($json)) {
        throw new RuntimeException('Microsoft entregó una respuesta no válida.');
    }
    return $json;
}

function almacenamientoSegmento(string $valor): string
{
    $valor = trim($valor);
    if ($valor === '' || $valor === '.' || $valor === '..') {
        throw new InvalidArgumentException('La ruta remota contiene un segmento no válido.');
    }
    return rawurlencode($valor);
}

/** @return array<string,string> */
function almacenamientoGraphDirectoriosCache(): array
{
    $claveGlobal = '__mesa_graph_directorios';
    if (isset($GLOBALS[$claveGlobal]) && is_array($GLOBALS[$claveGlobal])) {
        return $GLOBALS[$claveGlobal];
    }

    $ambito = almacenamientoGraphAmbito('directorios');
    $datos = almacenamientoCacheLeer('directorios-' . $ambito . '.json');
    $directorios = [];
    foreach ((array) ($datos['directorios'] ?? []) as $ruta => $id) {
        if (is_string($ruta) && is_string($id) && $ruta !== '' && $id !== '') {
            $directorios[$ruta] = $id;
        }
    }
    $GLOBALS[$claveGlobal] = $directorios;
    return $directorios;
}

/** @param array<string,string> $directorios */
function almacenamientoGraphGuardarDirectoriosCache(array $directorios): void
{
    $GLOBALS['__mesa_graph_directorios'] = $directorios;
    $ambito = almacenamientoGraphAmbito('directorios');
    almacenamientoCacheEscribir(
        'directorios-' . $ambito . '.json',
        ['actualizado_en' => time(), 'directorios' => $directorios]
    );
}

function almacenamientoGraphInvalidarDirectorio(string $rutaLogica): void
{
    /*
     * Un 404 puede significar que cambió cualquier padre de la ruta. Vaciar esta
     * caché es poco frecuente y garantiza que toda la jerarquía se reconstruya.
     */
    almacenamientoGraphGuardarDirectoriosCache([]);
}

function almacenamientoGraphDirectorio(string $rutaLogica): string
{
    $rutaLogica = trim(str_replace('\\', '/', $rutaLogica), '/');
    if ($rutaLogica === '') {
        return (string) MDS_GRAPH_ROOT_ITEM_ID;
    }
    $cache = almacenamientoGraphDirectoriosCache();
    if (isset($cache[$rutaLogica])) {
        return $cache[$rutaLogica];
    }

    $drive = rawurlencode((string) MDS_GRAPH_DRIVE_ID);
    $padre = (string) MDS_GRAPH_ROOT_ITEM_ID;
    $acumulada = '';

    foreach (explode('/', $rutaLogica) as $segmento) {
        $acumulada = $acumulada === '' ? $segmento : $acumulada . '/' . $segmento;
        if (isset($cache[$acumulada])) {
            $padre = $cache[$acumulada];
            continue;
        }
        try {
            $item = almacenamientoGraphJson(
                'GET',
                'drives/' . $drive . '/items/' . rawurlencode($padre)
                . ':/' . almacenamientoSegmento($segmento)
                . '?$select=id,name,folder'
            );
        } catch (AlmacenamientoHttpException $e) {
            if ($e->estadoHttp() !== 404) {
                throw $e;
            }
            try {
                $item = almacenamientoGraphJson(
                    'POST',
                    'drives/' . $drive . '/items/' . rawurlencode($padre) . '/children',
                    [
                        'name' => $segmento,
                        'folder' => new stdClass(),
                        '@microsoft.graph.conflictBehavior' => 'fail',
                    ]
                );
            } catch (AlmacenamientoHttpException $creacionError) {
                if ($creacionError->estadoHttp() !== 409) {
                    throw $creacionError;
                }
                /* Otra petición creó la carpeta entre el GET y el POST. */
                $item = almacenamientoGraphJson(
                    'GET',
                    'drives/' . $drive . '/items/' . rawurlencode($padre)
                    . ':/' . almacenamientoSegmento($segmento)
                    . '?$select=id,name,folder'
                );
            }
        }
        $id = trim((string) ($item['id'] ?? ''));
        if ($id === '' || !isset($item['folder'])) {
            throw new RuntimeException('La ruta remota no corresponde a una carpeta.');
        }
        $padre = $id;
        $cache[$acumulada] = $id;
        almacenamientoGraphGuardarDirectoriosCache($cache);
    }

    return $padre;
}

/** @return array<string,mixed> */
function almacenamientoGuardarGraph(
    string $rutaLogica,
    string $archivoTemporal,
    string $nombreRemoto,
    string $mime
): array {
    almacenamientoExigirGraph();
    if (!is_file($archivoTemporal) || !is_readable($archivoTemporal)) {
        throw new RuntimeException('El archivo temporal no está disponible.');
    }
    $bytes = file_get_contents($archivoTemporal);
    if (!is_string($bytes)) {
        throw new RuntimeException('No fue posible leer el archivo recibido.');
    }
    $drive = rawurlencode((string) MDS_GRAPH_DRIVE_ID);
    $padre = '';
    $respuesta = null;
    for ($intentoDirectorio = 0; $intentoDirectorio < 2; $intentoDirectorio++) {
        $padre = almacenamientoGraphDirectorio($rutaLogica);
        try {
            $respuesta = almacenamientoGraphSolicitud(
                'PUT',
                'drives/' . $drive . '/items/' . rawurlencode($padre)
                . ':/' . almacenamientoSegmento($nombreRemoto) . ':/content',
                $bytes,
                ['Content-Type: ' . $mime]
            );
            break;
        } catch (AlmacenamientoHttpException $e) {
            if ($e->estadoHttp() !== 404 || $intentoDirectorio > 0) {
                throw $e;
            }
            almacenamientoGraphInvalidarDirectorio($rutaLogica);
        }
    }
    if (!is_array($respuesta)) {
        throw new RuntimeException('No fue posible completar la carga remota.');
    }
    $item = json_decode($respuesta['cuerpo'], true);
    $itemId = is_array($item) ? trim((string) ($item['id'] ?? '')) : '';
    $tamano = is_array($item) ? (int) ($item['size'] ?? -1) : -1;
    if ($itemId === '' || $tamano !== strlen($bytes)) {
        throw new RuntimeException('Microsoft no confirmó la integridad del archivo cargado.');
    }

    return [
        'proveedor' => 'graph',
        'referencia' => 'graph:' . $itemId,
        'drive_id' => (string) MDS_GRAPH_DRIVE_ID,
        'item_id' => $itemId,
        'parent_item_id' => $padre,
        'ruta_logica' => trim($rutaLogica, '/') . '/' . $nombreRemoto,
        'nombre_remoto' => $nombreRemoto,
        'tipo_mime' => $mime,
        'tamano' => $tamano,
        'sha256' => hash('sha256', $bytes),
        'etag' => is_array($item) ? (string) ($item['eTag'] ?? '') : '',
    ];
}

/** @return array{bytes:string,tamano:int} */
function almacenamientoLeerGraph(string $referencia): array
{
    $itemId = almacenamientoItemId($referencia);
    $cacheNombre = 'binario-' . hash('sha256', $itemId) . '.cache';
    $cacheRuta = almacenamientoCacheRuta($cacheNombre);
    $cacheVigencia = 300;

    if (
        is_file($cacheRuta)
        && is_readable($cacheRuta)
        && (int) filemtime($cacheRuta) >= time() - $cacheVigencia
    ) {
        $bytesCache = @file_get_contents($cacheRuta);
        if (is_string($bytesCache)) {
            return ['bytes' => $bytesCache, 'tamano' => strlen($bytesCache)];
        }
    }

    $drive = rawurlencode((string) MDS_GRAPH_DRIVE_ID);
    $respuesta = almacenamientoGraphSolicitud(
        'GET',
        'drives/' . $drive . '/items/' . rawurlencode($itemId) . '/content',
        null,
        [],
        true
    );

    $bytes = $respuesta['cuerpo'];
    /*
     * Una caché corta evita pedir varias veces la misma imagen a Graph cuando
     * cabecera, tarjetas y conversación la muestran simultáneamente. Se limita
     * a 15 MB para no convertir las descargas grandes en consumo permanente.
     */
    if (strlen($bytes) <= 15 * 1024 * 1024) {
        try {
            $temporal = $cacheRuta . '.' . bin2hex(random_bytes(5)) . '.tmp';
            if (@file_put_contents($temporal, $bytes, LOCK_EX) !== false) {
                @chmod($temporal, 0640);
                if (!@rename($temporal, $cacheRuta)) {
                    if (@file_put_contents($cacheRuta, $bytes, LOCK_EX) !== false) {
                        @chmod($cacheRuta, 0640);
                    }
                    @unlink($temporal);
                }
            }
        } catch (Throwable $e) {
            /* La descarga debe continuar aunque la caché local no esté disponible. */
        }
    }

    return ['bytes' => $bytes, 'tamano' => strlen($bytes)];
}

function almacenamientoEliminarGraph(string $referencia): void
{
    if (!almacenamientoEsReferenciaGraph($referencia)) {
        return;
    }
    $drive = rawurlencode((string) MDS_GRAPH_DRIVE_ID);
    almacenamientoGraphSolicitud(
        'DELETE',
        'drives/' . $drive . '/items/' . rawurlencode(almacenamientoItemId($referencia))
    );
}

function almacenamientoPrepararEsquema(mysqli $conn): void
{
    static $preparado = false;
    if ($preparado) {
        return;
    }
    try {
        $conn->query('SELECT 1 FROM storage_objetos LIMIT 0');
    } catch (Throwable $e) {
        $conn->query(
            "CREATE TABLE IF NOT EXISTS storage_objetos (
                id_storage_objeto BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                tipo_entidad VARCHAR(32) NOT NULL,
                id_entidad BIGINT UNSIGNED NOT NULL,
                id_pais_operacion SMALLINT UNSIGNED NULL,
                proveedor VARCHAR(16) NOT NULL,
                estado VARCHAR(16) NOT NULL,
                drive_id VARCHAR(255) NULL,
                item_id VARCHAR(255) NULL,
                parent_item_id VARCHAR(255) NULL,
                ruta_logica VARCHAR(700) NOT NULL,
                nombre_remoto VARCHAR(255) NOT NULL,
                nombre_original VARCHAR(255) NULL,
                tipo_mime VARCHAR(150) NOT NULL,
                tamano BIGINT UNSIGNED NOT NULL,
                sha256 CHAR(64) NULL,
                etag VARCHAR(255) NULL,
                creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id_storage_objeto),
                UNIQUE KEY uq_storage_proveedor_item (proveedor, drive_id, item_id),
                KEY idx_storage_entidad (tipo_entidad, id_entidad, estado),
                KEY idx_storage_pais_estado (id_pais_operacion, estado)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );
    }
    $preparado = true;
}

/** @param array<string,mixed> $objeto */
function almacenamientoRegistrarObjeto(
    mysqli $conn,
    string $tipoEntidad,
    int $idEntidad,
    int $idPais,
    array $objeto,
    string $nombreOriginal = ''
): void {
    almacenamientoPrepararEsquema($conn);
    $tipoEntidad = substr($tipoEntidad, 0, 32);

    if (in_array($tipoEntidad, ['perfil_usuario', 'imagen_catalogo'], true)) {
        $stmt = $conn->prepare(
            "UPDATE storage_objetos SET estado = 'retirado'
             WHERE tipo_entidad = ? AND id_entidad = ? AND estado = 'disponible'"
        );
        $stmt->bind_param('si', $tipoEntidad, $idEntidad);
        $stmt->execute();
        $stmt->close();
    }

    $proveedor = (string) ($objeto['proveedor'] ?? 'graph');
    $estado = 'disponible';
    $driveId = (string) ($objeto['drive_id'] ?? '');
    $itemId = (string) ($objeto['item_id'] ?? '');
    $parentId = (string) ($objeto['parent_item_id'] ?? '');
    $ruta = (string) ($objeto['ruta_logica'] ?? '');
    $nombre = (string) ($objeto['nombre_remoto'] ?? '');
    $mime = (string) ($objeto['tipo_mime'] ?? 'application/octet-stream');
    $tamano = (int) ($objeto['tamano'] ?? 0);
    $sha = (string) ($objeto['sha256'] ?? '');
    $etag = (string) ($objeto['etag'] ?? '');
    $stmt = $conn->prepare(
        "INSERT INTO storage_objetos
            (tipo_entidad, id_entidad, id_pais_operacion, proveedor, estado,
             drive_id, item_id, parent_item_id, ruta_logica, nombre_remoto,
             nombre_original, tipo_mime, tamano, sha256, etag)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param(
        'siisssssssssiss',
        $tipoEntidad,
        $idEntidad,
        $idPais,
        $proveedor,
        $estado,
        $driveId,
        $itemId,
        $parentId,
        $ruta,
        $nombre,
        $nombreOriginal,
        $mime,
        $tamano,
        $sha,
        $etag
    );
    $stmt->execute();
    $stmt->close();
}

/** @return array<string,mixed>|null */
function almacenamientoBuscarObjeto(
    mysqli $conn,
    string $tipoEntidad,
    int $idEntidad
): ?array {
    try {
        almacenamientoPrepararEsquema($conn);
        $stmt = $conn->prepare(
            "SELECT * FROM storage_objetos
             WHERE tipo_entidad = ? AND id_entidad = ? AND estado = 'disponible'
             ORDER BY id_storage_objeto DESC LIMIT 1"
        );
        $stmt->bind_param('si', $tipoEntidad, $idEntidad);
        $stmt->execute();
        $fila = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $fila ?: null;
    } catch (Throwable $e) {
        error_log('Storage metadata: consulta no disponible.');
        return null;
    }
}

function almacenamientoCodigoPais(mysqli $conn, int $idPais): string
{
    $pais = function_exists('paisBuscarOperacion')
        ? paisBuscarOperacion($conn, $idPais)
        : null;
    $codigo = strtoupper(trim((string) ($pais['codigo'] ?? '')));
    return preg_match('/^[A-Z]{2,3}$/', $codigo) === 1
        ? $codigo
        : 'PAIS' . max(0, $idPais);
}

function almacenamientoEliminarReferencia(string $referencia): void
{
    try {
        if (almacenamientoEsReferenciaGraph($referencia)) {
            almacenamientoEliminarGraph($referencia);
        } elseif (is_file($referencia)) {
            @unlink($referencia);
        }
    } catch (Throwable $e) {
        error_log('Storage: no fue posible retirar un objeto huérfano.');
    }
}
