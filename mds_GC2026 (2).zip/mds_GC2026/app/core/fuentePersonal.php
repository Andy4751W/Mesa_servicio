<?php
declare(strict_types=1);

function fuentePersonalConfiguracion(): array
{
    static $configuracion = null;

    if (is_array($configuracion)) {
        return $configuracion;
    }

    $ruta = (string) (getenv('MESA_CONFIG_FILE') ?: '');
    if ($ruta === '') {
        $ruta = APP_ROOT . '/config/configuracion.local.php';
    }

    $local = is_file($ruta) ? require $ruta : [];

    if (!is_array($local)) {
        $local = [];
    }

    $valor = static function (string $variable, string $clave) use ($local): string {
        $entorno = getenv($variable);

        if ($entorno !== false && trim((string) $entorno) !== '') {
            return trim((string) $entorno);
        }

        return trim((string) ($local[$clave] ?? ''));
    };

    $configuracion = [
        'host' => $valor('MESA_FUENTE_DB_HOST', 'fuente_db_host'),
        'port' => (int) $valor('MESA_FUENTE_DB_PORT', 'fuente_db_port'),
        'name' => $valor('MESA_FUENTE_DB_NAME', 'fuente_db_name'),
        'user' => $valor('MESA_FUENTE_DB_USER', 'fuente_db_user'),
        'password' => $valor('MESA_FUENTE_DB_PASSWORD', 'fuente_db_password'),
    ];

    return $configuracion;
}

function fuentePersonalNormalizarUbicacion(string $valor): string
{
    $valor = strtoupper(trim($valor));

    $valor = strtr($valor, [
        'Á'=>'A','É'=>'E','Í'=>'I','Ó'=>'O','Ú'=>'U','Ü'=>'U'
    ]);

    $valor = preg_replace('/\bD\.?\s*C\.?\b/', '', $valor) ?? $valor;
    $valor = preg_replace('/[^A-Z0-9]+/', ' ', $valor) ?? $valor;

    return trim(preg_replace('/\s+/', ' ', $valor) ?? $valor);
}

function fuentePersonalBuscar(string $cedula, ?string &$estado = null): ?array
{
    $estado = null;
    $cedula = trim($cedula);

    if ($cedula === '') {
        return null;
    }

    $configuracion = fuentePersonalConfiguracion();

    $conexion = new mysqli(
        $configuracion['host'],
        $configuracion['user'],
        $configuracion['password'],
        $configuracion['name'],
        $configuracion['port']
    );

    if ($conexion->connect_errno) {
        throw new RuntimeException('No fue posible consultar la fuente externa de personal.');
    }

    try {
        $conexion->set_charset('utf8mb4');

        $stmt = $conexion->prepare(
            "SELECT *,
                    UPPER(TRIM(EST)) AS estado_normalizado
             FROM mae_data_uniclass
             WHERE IDENTIFICACION = ?
             ORDER BY
                CASE
                    WHEN UPPER(TRIM(EST)) = 'A' THEN 1
                    ELSE 0
                END DESC,
                TIMESTAMP DESC"
        );

        $stmt->bind_param('s', $cedula);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $filaSeleccionada = null;

        while ($fila = $resultado->fetch_assoc()) {
            if (
                $filaSeleccionada === null ||
                (
                    strtoupper(trim((string)$fila['estado_normalizado'])) === 'A'
                    &&
                    strtoupper(trim((string)$filaSeleccionada['estado_normalizado'])) !== 'A'
                )
            ) {
                $filaSeleccionada = $fila;
            }
        }

        $stmt->close();

        if (!is_array($filaSeleccionada)) {
            return null;
        }

        $estado = strtoupper(trim((string)($filaSeleccionada['EST'] ?? '')));

        $departamento = trim((string)($filaSeleccionada['CU_Regional'] ?? ''));
        $ciudad = trim((string)($filaSeleccionada['CIUDAD'] ?? ''));

        if (
            fuentePersonalNormalizarUbicacion($departamento) === 'BOGOTA'
            &&
            fuentePersonalNormalizarUbicacion($ciudad) === 'BOGOTA'
        ) {
            $departamento = 'Cundinamarca';
        }

        return [
            'cedula' => trim((string)($filaSeleccionada['IDENTIFICACION'] ?? $cedula)),
            'nombre' => trim((string)($filaSeleccionada['APELLIDOS_Y_NOMBRES'] ?? '')),
            'email' => strtolower(trim((string)($filaSeleccionada['CORREO_ELECTRONICO'] ?? ''))),
            'empresa' => trim((string)($filaSeleccionada['EMP'] ?? '')),
            'proceso' => trim((string)($filaSeleccionada['CU_Proceso'] ?? '')),
            'cu1' => trim((string)($filaSeleccionada['UNIDAD_1_COD'] ?? '')),
            'descripcion_cu1' => trim((string)($filaSeleccionada['UNIDAD_1_DESCRIP'] ?? '')),
            'cu3' => trim((string)($filaSeleccionada['UNIDAD_3_COD'] ?? '')),
            'pais' => 'Colombia',
            'departamento' => $departamento,
            'ciudad' => $ciudad,
        ];

    } finally {
        $conexion->close();
    }
}
