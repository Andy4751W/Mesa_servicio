<?php
declare(strict_types=1);

function auditoriaModuloNombre(string $entrada): string
{
    $modulos = [
        'actualizarTicket.php' => 'Tickets',
        'adminAcciones.php' => 'Tickets',
        'asignarTicket.php' => 'Tickets',
        'catalogos.php' => 'Áreas',
        'configuraciones.php' => 'Configuraciones',
        'crearUsuarios.php' => 'Usuarios',
        'crearticket.php' => 'Tickets',
        'editarUsuario.php' => 'Usuarios',
        'editarcatalogos.php' => 'Áreas',
        'enviarMensaje.php' => 'Mensajes',
        'feriados.php' => 'Festivos',
        'flujoTicket.php' => 'Flujos de tickets',
        'mensajesApi.php' => 'Mensajes',
        'prioridades.php' => 'Prioridades',
        'procesos.php' => 'Flujos',
        'Registro.php' => 'Usuarios',
        'servicios.php' => 'Servicios',
        'sla.php' => 'SLA',
        'soluciones.php' => 'Soluciones',
    ];
    return $modulos[$entrada] ?? pathinfo($entrada, PATHINFO_FILENAME);
}

/** @param array<string, mixed> $datos */
function auditoriaResumenSolicitud(string $entrada, array $datos): array
{
    $clavesAccion = ['accion', 'action', 'operacion', 'tipo', 'modo', 'evento'];
    $accion = '';
    foreach ($clavesAccion as $clave) {
        if (isset($datos[$clave]) && is_scalar($datos[$clave])) {
            $accion = trim((string) $datos[$clave]);
            if ($accion !== '') {
                break;
            }
        }
    }
    if ($accion === '') {
        foreach (array_keys($datos) as $clave) {
            if (preg_match('/^(guardar|crear|editar|actualizar|eliminar|asignar|cerrar|agregar|quitar)/i', (string) $clave)) {
                $accion = (string) $clave;
                break;
            }
        }
    }

    $accion = $accion !== ''
        ? ucfirst(str_replace(['_', '-'], ' ', substr($accion, 0, 120)))
        : 'Modificación en ' . auditoriaModuloNombre($entrada);

    $ocultas = '/password|contrasena|contraseña|token|csrf|secreto|firma|contenido_archivo|base64/i';
    $detalle = [];
    foreach ($datos as $clave => $valor) {
        $clave = (string) $clave;
        if (preg_match($ocultas, $clave) || in_array($clave, $clavesAccion, true)) {
            continue;
        }
        if (is_array($valor)) {
            $detalle[] = $clave . ': ' . count($valor) . ' elemento(s)';
        } elseif (is_scalar($valor)) {
            $texto = trim(preg_replace('/\s+/u', ' ', (string) $valor) ?? '');
            if ($texto !== '') {
                $resumen = function_exists('mb_substr')
                    ? mb_substr($texto, 0, 160, 'UTF-8')
                    : substr($texto, 0, 160);
                $detalle[] = $clave . ': ' . $resumen;
            }
        }
        if (count($detalle) >= 10) {
            break;
        }
    }

    return [$accion, $detalle ? implode(' · ', $detalle) : 'Sin campos descriptivos disponibles.'];
}

/** @param array<string, mixed> $datos */
function auditoriaProgramarRegistro(
    string $entrada,
    array $datos,
    int $idUsuario,
    string $tokenSesion,
    string $direccionIp
): void {
    if ($idUsuario < 1 || strlen($tokenSesion) !== 64) {
        return;
    }

    [$accion, $detalle] = auditoriaResumenSolicitud($entrada, $datos);
    $modulo = auditoriaModuloNombre($entrada);
    $tokenHash = hash('sha256', $tokenSesion);
    $direccionIp = filter_var($direccionIp, FILTER_VALIDATE_IP) ? $direccionIp : '0.0.0.0';

    register_shutdown_function(static function () use (
        $idUsuario,
        $tokenHash,
        $modulo,
        $accion,
        $detalle,
        $direccionIp
    ): void {
        $estadoHttp = http_response_code();
        if ($estadoHttp < 200 || $estadoHttp >= 400) {
            return;
        }

        global $conn;
        if (!isset($conn) || !($conn instanceof mysqli)) {
            return;
        }

        try {
            $stmt = $conn->prepare(
                "INSERT INTO auditoria_sesiones
                          (id_sesion, id_usuario, modulo, accion, detalle,
                     direccion_ip, estado_http, fecha_hora)
                      SELECT id_sesion, ?, ?, ?, ?, ?, ?, NOW()
                 FROM sesiones_usuario
                 WHERE id_usuario = ? AND token_hash = ?
                 ORDER BY id_sesion DESC
                 LIMIT 1"
            );
            $stmt->bind_param(
                'issssiis',
                $idUsuario,
                $modulo,
                $accion,
                $detalle,
                $direccionIp,
                $estadoHttp,
                $idUsuario,
                $tokenHash
            );
            $stmt->execute();
            $stmt->close();
        } catch (Throwable $e) {
            error_log('No fue posible registrar la auditoría de sesión: ' . $e->getMessage());
        }
    });
}
