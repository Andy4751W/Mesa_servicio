<?php
declare(strict_types=1);

require_once __DIR__ . '/seguridad.php';

seguridadAplicarCabeceras(true);
seguridadIniciarSesion();
seguridadTokenCsrf();

require_once APP_ROOT . '/config/conexion.php';
require_once APP_ROOT . '/core/pais.php';
require_once APP_ROOT . '/core/chatEstado.php';
require_once APP_ROOT . '/core/sesionUnica.php';

if (!paisModuloInstalado($conn)) {
    http_response_code(503);
    exit('La separación por país todavía no está instalada. Ejecute la migración 005.');
}

function cerrarSesionYVolver(
    string $error,
    bool $cerrarSesionVigente = true
): void
{
    global $conn;
    $idUsuarioSesion = (int) ($_SESSION['usuario_id'] ?? 0);
    $tokenSesion = (string) ($_SESSION['sesion_unica_token'] ?? '');

    if ($conn instanceof mysqli && $cerrarSesionVigente) {
        $eraSesionVigente = sesionUnicaCerrar(
            $conn,
            $idUsuarioSesion,
            $tokenSesion,
            $error
        );
        if ($eraSesionVigente && !sesionUsuarioTieneAccesoActivo($conn, $idUsuarioSesion)) {
            chatSesionCerrada($conn, $idUsuarioSesion);
        }
    }
    seguridadCerrarSesion();
    seguridadIniciarSesion();
    $_SESSION['mesa_login_error'] = $error;
    header('Location: ' . mesaUrlInicio());
    exit;
}

$ahora = time();
$ultimaRotacion = (int) ($_SESSION['ultima_rotacion'] ?? $ahora);
$agenteActual = hash('sha256', (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
$agenteSesion = (string) ($_SESSION['agente_sesion'] ?? $agenteActual);
$motivoVencimiento = seguridadMotivoVencimiento($ahora);

if (
    $motivoVencimiento !== null
    || !hash_equals($agenteSesion, $agenteActual)
) {
    cerrarSesionYVolver(
        $motivoVencimiento ?? 'sesion_expirada'
    );
}

if ($ahora - $ultimaRotacion > 900) {
    session_regenerate_id(true);
    $_SESSION['ultima_rotacion'] = $ahora;
}

$_SESSION['agente_sesion'] = $agenteActual;

$idUsuario = filter_var(
    $_SESSION['usuario_id'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$idUsuario) {
    cerrarSesionYVolver('credenciales');
}

try {
    $stmt = $conn->prepare(
        "SELECT nombre, id_rol, id_pais_operacion, estado,
                sesion_activa_hash
         FROM usuarios
         WHERE id_usuario = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $idUsuario);
    $stmt->execute();

    $resultado = $stmt->get_result();
    $usuario = $resultado->fetch_assoc();
    $stmt->close();

    $estado = strtolower(trim((string) ($usuario['estado'] ?? '')));

    if (!$usuario || $estado !== 'activo') {
        cerrarSesionYVolver('sesion_inhabilitada');
    }

    $rolActual = (int) ($usuario['id_rol'] ?? 0);

    if (!sesionAccesoVigente(
        $conn,
        (int) $idUsuario,
        $rolActual,
        (string) ($_SESSION['sesion_unica_token'] ?? ''),
        (string) ($usuario['sesion_activa_hash'] ?? '')
    )) {
        cerrarSesionYVolver('sesion_reemplazada', false);
    }

    if (!in_array($rolActual, [1, 2, 3], true)) {
        cerrarSesionYVolver('rol');
    }

    $_SESSION['rol'] = $rolActual;
    $_SESSION['usuario'] = (string) ($usuario['nombre'] ?? 'Usuario');

    paisInicializarUsuario($conn, $usuario);

    if (!defined('MESA_OMITIR_ACTIVIDAD_SESION')) {
        $tokenSesionActual = (string) ($_SESSION['sesion_unica_token'] ?? '');
        $_SESSION['ultima_interaccion'] = time();
        sesionRegistrarActividad($conn, (int) $idUsuario, $tokenSesionActual);
        sesionRegistrarPais(
            $conn,
            (int) $idUsuario,
            $tokenSesionActual,
            paisContextoId()
        );
    }

    if (
        $rolActual === 1
        && paisContextoId() < 1
        && !defined('MESA_PERMITE_SIN_PAIS')
    ) {
        header('Location: seleccionarPais.php', true, 303);
        exit;
    }
} catch (Throwable $e) {
    error_log('No fue posible validar la sesión: ' . $e->getMessage());
    cerrarSesionYVolver('sistema');
}

/* Una sesión autenticada y vigente se refleja como usuario en línea. */
chatRegistrarActividad($conn, (int) $idUsuario);

/* Toda modificación autenticada exige origen propio y token antifalsificación. */
seguridadExigirOrigenPost();
seguridadExigirCsrfPost();

/*
 * El navegador interno carga los módulos mediante GET. Una vez validada la
 * sesión, retener su bloqueo hasta terminar consultas pesadas hace que los
 * clics rápidos queden en cola, incluso si el navegador canceló esas vistas.
 */
if (
    ($_SERVER['REQUEST_METHOD'] ?? '') === 'GET'
    && (
        strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'mesanavigation'
        || strtolower((string) ($_SERVER['HTTP_SEC_FETCH_DEST'] ?? '')) === 'iframe'
    )
    && session_status() === PHP_SESSION_ACTIVE
) {
    session_write_close();
}
