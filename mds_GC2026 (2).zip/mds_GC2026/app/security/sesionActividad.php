<?php
declare(strict_types=1);

require_once __DIR__ . '/seguridad.php';

seguridadAplicarCabeceras(true);
seguridadIniciarSesion();

require_once APP_ROOT . '/config/conexion.php';
require_once APP_ROOT . '/core/chatEstado.php';
require_once APP_ROOT . '/core/sesionUnica.php';

header('Content-Type: application/json; charset=UTF-8');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo json_encode(['ok' => false, 'motivo' => 'metodo']);
    exit;
}

if (!seguridadOrigenMismoSitio()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'motivo' => 'origen']);
    exit;
}

$ahora = time();
$motivo = seguridadMotivoVencimiento($ahora);

if ($motivo !== null) {
    $idUsuarioVencido = (int) ($_SESSION['usuario_id'] ?? 0);
    $eraSesionVigente = sesionUnicaCerrar(
        $conn,
        $idUsuarioVencido,
        (string) ($_SESSION['sesion_unica_token'] ?? ''),
        $motivo
    );
    if ($eraSesionVigente && !sesionUsuarioTieneAccesoActivo($conn, $idUsuarioVencido)) {
        chatSesionCerrada($conn, $idUsuarioVencido);
    }
    seguridadCerrarSesion();
    http_response_code(401);
    echo json_encode(['ok' => false, 'motivo' => $motivo]);
    exit;
}

$idUsuarioSesion = (int) ($_SESSION['usuario_id'] ?? 0);
$stmtSesion = $conn->prepare(
    'SELECT sesion_activa_hash, id_rol FROM usuarios WHERE id_usuario = ? LIMIT 1'
);
$stmtSesion->bind_param('i', $idUsuarioSesion);
$stmtSesion->execute();
$filaSesion = $stmtSesion->get_result()->fetch_assoc();
$stmtSesion->close();

$rolActual = (int) ($filaSesion['id_rol'] ?? 0);

if (!sesionAccesoVigente(
    $conn,
    $idUsuarioSesion,
    $rolActual,
    (string) ($_SESSION['sesion_unica_token'] ?? ''),
    (string) ($filaSesion['sesion_activa_hash'] ?? '')
)) {
    seguridadCerrarSesion();
    http_response_code(401);
    echo json_encode(['ok' => false, 'motivo' => 'sesion_reemplazada']);
    exit;
}

$accion = (string) ($_POST['accion'] ?? 'estado');
$pestanaId = strtolower(trim((string) ($_POST['pestana_id'] ?? '')));

if (!preg_match('/^[a-f0-9]{64}$/', $pestanaId)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'motivo' => 'pestana']);
    exit;
}

$pestanaRegistrada = (string) ($_SESSION['pestana_sesion_id'] ?? '');
if ($rolActual === 3) {
    if ($pestanaRegistrada === '') {
        $_SESSION['pestana_sesion_id'] = $pestanaId;
    } elseif (!hash_equals($pestanaRegistrada, $pestanaId)) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'motivo' => 'pestana_cerrada']);
        exit;
    }
}

$cargoActual = (fn ($__mesaMatchValue39) => (($__mesaMatchValue39 === (1)) ? ('Administrador global') : ((($__mesaMatchValue39 === (2)) ? ('Gestor') : ((($__mesaMatchValue39 === (3)) ? ('Solicitante') : ('Usuario')))))))($rolActual);
$nombreCompleto = trim((string) ($_SESSION['usuario'] ?? 'Usuario'));
$partesNombre = preg_split('/\s+/u', $nombreCompleto, -1, PREG_SPLIT_NO_EMPTY) ?: [];
$cantidadPartes = count($partesNombre);

if ($cantidadPartes >= 3) {
    $nombreCorto = $partesNombre[0] . ' ' . $partesNombre[$cantidadPartes - 2];
} elseif ($cantidadPartes === 2) {
    $nombreCorto = $partesNombre[0] . ' ' . $partesNombre[1];
} else {
    $nombreCorto = $partesNombre[0] ?? 'Usuario';
}

if ($accion === 'actividad') {
    $_SESSION['ultima_interaccion'] = $ahora;
} elseif (!in_array($accion, ['estado', 'vincular_pestana'], true)) {
    http_response_code(422);
    echo json_encode(['ok' => false, 'motivo' => 'accion']);
    exit;
}

sesionRegistrarActividad(
    $conn,
    $idUsuarioSesion,
    (string) ($_SESSION['sesion_unica_token'] ?? '')
);

$respuesta = [
    'ok' => true,
    'tiempos' => seguridadTiemposRestantes($ahora),
    'pais' => [
        'id' => (int) ($_SESSION['pais_operacion_id'] ?? 0),
        'codigo' => (string) ($_SESSION['pais_operacion_codigo'] ?? ''),
        'nombre' => (string) ($_SESSION['pais_operacion_nombre'] ?? ''),
        'color' => (string) ($_SESSION['pais_operacion_color'] ?? '#0f6fec'),
        'rol' => $rolActual,
        'administrador' => $rolActual === 1,
        'usuario' => $nombreCorto,
        'cargo' => $cargoActual,
    ],
];

/*
 * Libera inmediatamente el archivo de sesión. Así una comprobación periódica
 * nunca deja esperando la solicitud que está abriendo un módulo.
 */
session_write_close();

/* "estado" solo valida la sesión; no debe escribir presencia cada 30 s. */
if ($accion !== 'estado') {
    chatRegistrarActividad($conn, $idUsuarioSesion);
}

echo json_encode(
    $respuesta,
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);
