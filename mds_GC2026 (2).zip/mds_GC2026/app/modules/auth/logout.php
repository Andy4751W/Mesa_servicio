<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/seguridad.php';
require_once APP_ROOT . '/config/conexion.php';
require_once APP_ROOT . '/core/chatEstado.php';
require_once APP_ROOT . '/core/sesionUnica.php';

seguridadAplicarCabeceras(true);
seguridadIniciarSesion();
$motivo = (string) ($_GET['motivo'] ?? '');
$motivosPermitidos = [
    'inactividad',
    'tiempo_maximo',
    'sesion_expirada',
    'sesion_reemplazada',
    'pestana_cerrada',
];
$motivoRegistro = in_array($motivo, $motivosPermitidos, true)
    ? $motivo
    : 'cerrada';
$idUsuarioSesion = (int) ($_SESSION['usuario_id'] ?? 0);
$eraSesionVigente = sesionUnicaCerrar(
    $conn,
    $idUsuarioSesion,
    (string) ($_SESSION['sesion_unica_token'] ?? ''),
    $motivoRegistro
);
if ($eraSesionVigente && !sesionUsuarioTieneAccesoActivo($conn, $idUsuarioSesion)) {
    chatSesionCerrada($conn, $idUsuarioSesion);
}
seguridadCerrarSesion();
seguridadIniciarSesion();

if (in_array($motivo, $motivosPermitidos, true)) {
    $_SESSION['mesa_login_error'] = $motivo;
} else {
    $_SESSION['mesa_login_estado'] = 'cerrada';
}

$destino = mesaUrlInicio();

/*
 * Evita que el cierre de sesión o la respuesta de redirección queden
 * almacenados en caché.
 */
if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Location: ' . $destino, true, 303);
    exit;
}

/*
 * Respaldo únicamente para el caso excepcional en que ya se hayan enviado
 * cabeceras antes de llegar aquí.
 */
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta http-equiv="refresh" content="0;url=<?= htmlspecialchars($destino, ENT_QUOTES, 'UTF-8') ?>">
    <title>Cerrando sesión | Mesa de Servicio</title>
</head>
<body>
<script>
    window.location.replace(
        <?= json_encode($destino, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>
    );
</script>
</body>
</html>
