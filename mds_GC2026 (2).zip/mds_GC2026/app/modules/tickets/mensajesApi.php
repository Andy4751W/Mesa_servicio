<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

seguridadExigirRol([1, 2, 3]);

$idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
$rol = (int) ($_SESSION['rol'] ?? 0);
$idPaisOperacion = paisExigirContexto();

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function mensajesJson(array $datos, int $estado = 200): void
{
    http_response_code($estado);
    echo json_encode(
        $datos,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

function mensajesEsCerrado(array $ticket): bool
{
    return strtolower(trim((string) ($ticket['estado_flujo'] ?? ''))) === 'cerrado'
        || in_array(
            strtolower(trim((string) ($ticket['estado'] ?? ''))),
            ['cerrada', 'cancelada'],
            true
        );
}

function mensajesRolTexto(int $rol): string
{
    return (fn ($__mesaMatchValue28) => (($__mesaMatchValue28 === (1)) ? ('Administrador') : ((($__mesaMatchValue28 === (2)) ? ('Gestor') : ((($__mesaMatchValue28 === (3)) ? ('Solicitante') : ('Usuario')))))))($rol);
}

/** @return array<string,mixed>|null */
function mensajesTicketAutorizado(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol,
    int $idPaisOperacion
): ?array {
    if ($rol === 2) {
        $stmt = $conn->prepare(
            "SELECT
                t.*,
                solicitante.nombre AS solicitante_nombre,
                solicitante.id_usuario AS solicitante_id
             FROM tickets AS t
             LEFT JOIN usuarios AS solicitante
                ON solicitante.id_usuario = t.id_usuario
             WHERE t.id_ticket = ?
               AND t.id_pais_operacion = ?
               AND EXISTS (
                    SELECT 1
                    FROM ticket_etapas AS te
                    WHERE te.id_ticket = t.id_ticket
                      AND te.id_ticket_etapa_padre IS NULL
                      AND te.id_gestor = ?
               )
             LIMIT 1"
        );
        $stmt->bind_param('iii', $idTicket, $idPaisOperacion, $idUsuario);
    } else {
        $stmt = $conn->prepare(
            "SELECT
                t.*,
                solicitante.nombre AS solicitante_nombre,
                solicitante.id_usuario AS solicitante_id
             FROM tickets AS t
             LEFT JOIN usuarios AS solicitante
                ON solicitante.id_usuario = t.id_usuario
             WHERE t.id_ticket = ?
               AND t.id_pais_operacion = ?
               AND t.id_usuario = ?
             LIMIT 1"
        );
        $stmt->bind_param('iii', $idTicket, $idPaisOperacion, $idUsuario);
    }

    $stmt->execute();
    $ticket = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $ticket ?: null;
}

function mensajesEtapaEscritura(
    mysqli $conn,
    array $ticket,
    int $idUsuario,
    int $rol
): int {
    if (mensajesEsCerrado($ticket)) {
        return 0;
    }

    $idTicket = (int) ($ticket['id_ticket'] ?? 0);

    if ($rol === 2) {
        $stmt = $conn->prepare(
            "SELECT te.id_ticket_etapa
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             WHERE te.id_ticket = ?
               AND te.id_ticket_etapa_padre IS NULL
               AND te.id_gestor = ?
               AND te.estado IN (
                    'pendiente',
                    'en_proceso',
                    'en_espera_solicitante',
                    'pausada'
               )
             ORDER BY
                (te.id_ticket_etapa = t.id_etapa_actual) DESC,
                te.orden DESC,
                te.id_ticket_etapa DESC
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idTicket, $idUsuario);
    } else {
        $stmt = $conn->prepare(
            "SELECT te.id_ticket_etapa
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             WHERE te.id_ticket = ?
               AND t.id_usuario = ?
               AND te.id_ticket_etapa_padre IS NULL
               AND te.estado IN (
                    'pendiente',
                    'en_proceso',
                    'en_espera_solicitante',
                    'pausada'
               )
             ORDER BY
                (te.id_ticket_etapa = t.id_etapa_actual) DESC,
                te.orden DESC,
                te.id_ticket_etapa DESC
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idTicket, $idUsuario);
    }

    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return (int) ($fila['id_ticket_etapa'] ?? 0);
}

/** @return array{id:int,nombre:string,rol:string} */
function mensajesContraparte(
    mysqli $conn,
    array $ticket,
    int $idUsuario,
    int $rol
): array {
    if ($rol === 2) {
        return [
            'id' => (int) ($ticket['solicitante_id'] ?? 0),
            'nombre' => trim((string) ($ticket['solicitante_nombre'] ?? 'Solicitante')) ?: 'Solicitante',
            'rol' => 'Solicitante',
        ];
    }

    $idTicket = (int) ($ticket['id_ticket'] ?? 0);
    $stmt = $conn->prepare(
        "SELECT u.id_usuario, u.nombre
         FROM ticket_etapas AS te
         INNER JOIN usuarios AS u ON u.id_usuario = te.id_gestor
         INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
         WHERE te.id_ticket = ?
           AND te.id_ticket_etapa_padre IS NULL
           AND te.id_gestor IS NOT NULL
         ORDER BY
            (te.id_ticket_etapa = t.id_etapa_actual) DESC,
            FIELD(
                te.estado,
                'en_proceso',
                'pendiente',
                'en_espera_solicitante',
                'pausada',
                'listo_cierre',
                'completada',
                'cancelada'
            ),
            te.orden DESC,
            te.id_ticket_etapa DESC
         LIMIT 1"
    );
    $stmt->bind_param('i', $idTicket);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$fila) {
        return ['id' => 0, 'nombre' => 'Mesa de Servicio', 'rol' => 'Gestor'];
    }

    return [
        'id' => (int) $fila['id_usuario'],
        'nombre' => trim((string) $fila['nombre']) ?: 'Gestor',
        'rol' => 'Gestor',
    ];
}

/** @return array<int,array<string,mixed>> */
function mensajesLista(
    mysqli $conn,
    int $idUsuario,
    int $rol,
    int $idPaisOperacion,
    string $filtro,
    string $buscar,
    string $filtroLectura = 'todos'
): array {
    $estadoChatDisponible = chatEstadoDisponible($conn);
    if (!in_array($filtroLectura, ['todos', 'leidos', 'no_leidos'], true)) {
        $filtroLectura = 'todos';
    }
    $condicionLectura = (fn ($__mesaMatchValue29) => (($__mesaMatchValue29 === ('leidos')) ? ('HAVING mensajes_no_leidos = 0') : ((($__mesaMatchValue29 === ('no_leidos')) ? ('HAVING mensajes_no_leidos > 0') : ('')))))($filtroLectura);

    if ($filtro === 'completadas') {
        $buscarSql = '';
        if ($buscar !== '') {
            $buscarEscapado = $conn->real_escape_string($buscar);
            $buscarSql = " AND (
                CAST(t.id_ticket AS CHAR) LIKE '%{$buscarEscapado}%'
                OR t.titulo LIKE '%{$buscarEscapado}%'
                OR te.servicio_nombre LIKE '%{$buscarEscapado}%'
                OR te.catalogo_nombre LIKE '%{$buscarEscapado}%'
            )";
        }

        $visibilidadEtapa = $rol === 2
            ? "te.id_gestor = {$idUsuario}"
            : "t.id_usuario = {$idUsuario}";
        $interaccionEtapa = "(
            EXISTS (
                SELECT 1
                FROM solicitud_comunicaciones AS sci
                WHERE sci.id_ticket = te.id_ticket
                  AND sci.id_ticket_etapa = te.id_ticket_etapa
                  AND sci.tipo = 'publica'
                  AND sci.id_emisor IS NOT NULL
            )
            OR EXISTS (
                SELECT 1
                FROM solicitud_adjuntos AS sai
                WHERE sai.id_ticket = te.id_ticket
                  AND sai.id_ticket_etapa = te.id_ticket_etapa
                  AND sai.id_usuario IS NOT NULL
            )
        )";
        $noLeidosEtapaSql = $estadoChatDisponible
            ? "(SELECT COUNT(*)
                FROM solicitud_comunicaciones AS scn
                LEFT JOIN chat_conversacion_estado AS cen
                  ON cen.id_ticket = scn.id_ticket
                 AND cen.id_ticket_etapa = scn.id_ticket_etapa
                 AND cen.id_usuario = {$idUsuario}
                WHERE scn.id_ticket = t.id_ticket
                  AND scn.id_ticket_etapa = te.id_ticket_etapa
                  AND scn.tipo = 'publica'
                  AND scn.id_emisor IS NOT NULL
                  AND scn.id_emisor <> {$idUsuario}
                  AND (cen.leido_hasta IS NULL OR scn.creado_en > cen.leido_hasta))"
            : '0';
        $resultado = $conn->query(
            "SELECT
                t.id_ticket,
                t.titulo,
                te.id_ticket_etapa,
                te.orden,
                te.catalogo_nombre,
                te.servicio_nombre,
                te.fecha_finalizacion,
                te.actualizado_en,
                te.id_gestor,
                COALESCE(gestor.nombre, 'Gestor') AS gestor_nombre,
                t.id_usuario AS solicitante_id,
                COALESCE(solicitante.nombre, 'Solicitante') AS solicitante_nombre,
                (SELECT sc.mensaje
                 FROM solicitud_comunicaciones AS sc
                 WHERE sc.id_ticket_etapa = te.id_ticket_etapa
                   AND sc.tipo = 'publica'
                 ORDER BY sc.creado_en DESC, sc.id_comunicacion DESC
                 LIMIT 1) AS ultimo_mensaje,
                (SELECT sc.creado_en
                 FROM solicitud_comunicaciones AS sc
                 WHERE sc.id_ticket_etapa = te.id_ticket_etapa
                   AND sc.tipo = 'publica'
                 ORDER BY sc.creado_en DESC, sc.id_comunicacion DESC
                 LIMIT 1) AS ultimo_mensaje_fecha,
                (SELECT COUNT(*) FROM solicitud_comunicaciones AS sc
                 WHERE sc.id_ticket_etapa = te.id_ticket_etapa
                   AND sc.tipo = 'publica') AS total_mensajes,
                (SELECT COUNT(*) FROM solicitud_adjuntos AS sa
                 WHERE sa.id_ticket_etapa = te.id_ticket_etapa) AS total_adjuntos,
                {$noLeidosEtapaSql} AS mensajes_no_leidos
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN usuarios AS gestor ON gestor.id_usuario = te.id_gestor
             LEFT JOIN usuarios AS solicitante ON solicitante.id_usuario = t.id_usuario
             WHERE t.id_pais_operacion = {$idPaisOperacion}
               AND te.id_ticket_etapa_padre IS NULL
               AND te.estado IN ('completada', 'cancelada')
               AND {$visibilidadEtapa}
               AND {$interaccionEtapa}
               {$buscarSql}
             {$condicionLectura}
             ORDER BY COALESCE(te.fecha_finalizacion, te.actualizado_en) DESC
             LIMIT 200"
        );

        if ($resultado === false) {
            throw new RuntimeException('No fue posible cargar las etapas completadas.');
        }

        $etapas = [];
        while ($fila = $resultado->fetch_assoc()) {
            $contraparte = $rol === 2
                ? [
                    'id' => (int) ($fila['solicitante_id'] ?? 0),
                    'nombre' => (string) ($fila['solicitante_nombre'] ?? 'Solicitante'),
                    'rol' => 'Solicitante',
                ]
                : [
                    'id' => (int) ($fila['id_gestor'] ?? 0),
                    'nombre' => (string) ($fila['gestor_nombre'] ?? 'Gestor'),
                    'rol' => 'Gestor',
                ];
            $contraparte['presencia'] = chatObtenerPresencia(
                $conn,
                (int) ($contraparte['id'] ?? 0)
            );
            $ultimo = trim((string) ($fila['ultimo_mensaje'] ?? ''));
            if ($ultimo === '' && (int) ($fila['total_adjuntos'] ?? 0) > 0) {
                $ultimo = 'Documento o imagen compartida';
            } elseif ($ultimo === '') {
                $ultimo = 'Etapa completada sin mensajes';
            }

            $etapas[] = [
                'id_ticket' => (int) $fila['id_ticket'],
                'id_ticket_etapa' => (int) $fila['id_ticket_etapa'],
                'conversation_key' => (int) $fila['id_ticket'] . ':' . (int) $fila['id_ticket_etapa'],
                'titulo' => (string) $fila['titulo'],
                'titulo_etapa' => 'Etapa ' . (int) $fila['orden'] . ' · '
                    . trim((string) $fila['catalogo_nombre']) . ' / '
                    . trim((string) $fila['servicio_nombre']),
                'cerrado' => true,
                'solo_lectura' => true,
                'estado' => 'Etapa completada',
                'contraparte' => $contraparte,
                'ultimo_mensaje' => $ultimo,
                'ultima_actividad' => (string) (
                    $fila['ultimo_mensaje_fecha']
                    ?: $fila['fecha_finalizacion']
                    ?: $fila['actualizado_en']
                ),
                'total_mensajes' => (int) ($fila['total_mensajes'] ?? 0),
                'total_adjuntos' => (int) ($fila['total_adjuntos'] ?? 0),
                'mensajes_no_leidos' => (int) ($fila['mensajes_no_leidos'] ?? 0),
            ];
        }

        return $etapas;
    }

    $cerradoSql = "(LOWER(TRIM(t.estado_flujo)) = 'cerrado' OR LOWER(TRIM(t.estado)) IN ('cerrada','cancelada'))";
    $abiertoSql = "NOT {$cerradoSql}";

    if ($rol === 2) {
        $participacion = "EXISTS (
            SELECT 1 FROM ticket_etapas AS tep
            WHERE tep.id_ticket = t.id_ticket
              AND tep.id_ticket_etapa_padre IS NULL
              AND tep.id_gestor = {$idUsuario}
        )";
        $asignacionActiva = "EXISTS (
            SELECT 1 FROM ticket_etapas AS tea
            WHERE tea.id_ticket = t.id_ticket
              AND tea.id_ticket_etapa_padre IS NULL
              AND tea.id_gestor = {$idUsuario}
              AND tea.estado IN ('pendiente','en_proceso','en_espera_solicitante','pausada','listo_cierre')
        )";
        $visibilidad = "({$cerradoSql} OR {$asignacionActiva}) AND {$participacion}";
        $restriccionMensaje = "AND tem.id_gestor = {$idUsuario}";
        $restriccionNoLeido = "AND ten.id_gestor = {$idUsuario}";
        $restriccionAdjunto = "AND tea2.id_gestor = {$idUsuario}";
    } else {
        $visibilidad = "t.id_usuario = {$idUsuario}";
        $restriccionMensaje = '';
        $restriccionNoLeido = '';
        $restriccionAdjunto = '';
    }

    $condicionFiltro = (fn ($__mesaMatchValue30) => (($__mesaMatchValue30 === ('cerrados')) ? ($cerradoSql) : ((($__mesaMatchValue30 === ('todos')) ? ('1=1') : ($abiertoSql)))))($filtro);

    $buscarSql = '';
    if ($buscar !== '') {
        $buscarEscapado = $conn->real_escape_string($buscar);
        $buscarSql = " AND (
            CAST(t.id_ticket AS CHAR) LIKE '%{$buscarEscapado}%'
            OR t.titulo LIKE '%{$buscarEscapado}%'
            OR COALESCE(solicitante.nombre,'') LIKE '%{$buscarEscapado}%'
        )";
    }

    $noLeidosCasoSql = $estadoChatDisponible
        ? "(SELECT COUNT(*)
            FROM solicitud_comunicaciones AS scn
            INNER JOIN ticket_etapas AS ten
              ON ten.id_ticket_etapa = scn.id_ticket_etapa
             AND ten.id_ticket = scn.id_ticket
            LEFT JOIN chat_conversacion_estado AS cen
              ON cen.id_ticket = scn.id_ticket
             AND cen.id_ticket_etapa = scn.id_ticket_etapa
             AND cen.id_usuario = {$idUsuario}
            WHERE scn.id_ticket = t.id_ticket
              AND scn.tipo = 'publica'
              AND scn.id_emisor IS NOT NULL
              AND scn.id_emisor <> {$idUsuario}
              AND ten.id_ticket_etapa_padre IS NULL
              {$restriccionNoLeido}
              AND (cen.leido_hasta IS NULL OR scn.creado_en > cen.leido_hasta))"
        : '0';

    $sql = "SELECT
                t.id_ticket,
                t.titulo,
                t.estado,
                t.estado_flujo,
                t.actualizado_en,
                t.id_usuario AS solicitante_id,
                COALESCE(solicitante.nombre,'Solicitante') AS solicitante_nombre,
                (
                    SELECT sc.mensaje
                    FROM solicitud_comunicaciones AS sc
                    INNER JOIN ticket_etapas AS tem
                        ON tem.id_ticket_etapa = sc.id_ticket_etapa
                       AND tem.id_ticket = sc.id_ticket
                    WHERE sc.id_ticket = t.id_ticket
                      AND sc.tipo = 'publica'
                      AND tem.id_ticket_etapa_padre IS NULL
                      {$restriccionMensaje}
                    ORDER BY sc.creado_en DESC, sc.id_comunicacion DESC
                    LIMIT 1
                ) AS ultimo_mensaje,
                (
                    SELECT sc.creado_en
                    FROM solicitud_comunicaciones AS sc
                    INNER JOIN ticket_etapas AS tem
                        ON tem.id_ticket_etapa = sc.id_ticket_etapa
                       AND tem.id_ticket = sc.id_ticket
                    WHERE sc.id_ticket = t.id_ticket
                      AND sc.tipo = 'publica'
                      AND tem.id_ticket_etapa_padre IS NULL
                      {$restriccionMensaje}
                    ORDER BY sc.creado_en DESC, sc.id_comunicacion DESC
                    LIMIT 1
                ) AS ultimo_mensaje_fecha,
                (
                    SELECT COUNT(*)
                    FROM solicitud_comunicaciones AS sc
                    INNER JOIN ticket_etapas AS tem
                        ON tem.id_ticket_etapa = sc.id_ticket_etapa
                       AND tem.id_ticket = sc.id_ticket
                    WHERE sc.id_ticket = t.id_ticket
                      AND sc.tipo = 'publica'
                      AND tem.id_ticket_etapa_padre IS NULL
                      {$restriccionMensaje}
                ) AS total_mensajes,
                (
                    SELECT COUNT(*)
                    FROM solicitud_adjuntos AS sa
                    INNER JOIN ticket_etapas AS tea2
                        ON tea2.id_ticket_etapa = sa.id_ticket_etapa
                       AND tea2.id_ticket = sa.id_ticket
                    WHERE sa.id_ticket = t.id_ticket
                      AND tea2.id_ticket_etapa_padre IS NULL
                      {$restriccionAdjunto}
                ) AS total_adjuntos,
                {$noLeidosCasoSql} AS mensajes_no_leidos
            FROM tickets AS t
            LEFT JOIN usuarios AS solicitante
                ON solicitante.id_usuario = t.id_usuario
            WHERE t.id_pais_operacion = {$idPaisOperacion}
              AND {$visibilidad}
              AND {$condicionFiltro}
              {$buscarSql}
            {$condicionLectura}
            ORDER BY
                COALESCE(ultimo_mensaje_fecha, t.actualizado_en) DESC,
                t.id_ticket DESC
            LIMIT 150";

    $resultado = $conn->query($sql);
    if ($resultado === false) {
        throw new RuntimeException('No fue posible cargar las conversaciones.');
    }

    $filas = [];
    while ($fila = $resultado->fetch_assoc()) {
        $cerrado = mensajesEsCerrado($fila);
        $contraparte = mensajesContraparte($conn, $fila, $idUsuario, $rol);
        $contraparte['presencia'] = chatObtenerPresencia(
            $conn,
            (int) ($contraparte['id'] ?? 0)
        );
        $ultimo = trim((string) ($fila['ultimo_mensaje'] ?? ''));
        $totalAdjuntos = (int) ($fila['total_adjuntos'] ?? 0);

        if ($ultimo === '' && $totalAdjuntos > 0) {
            $ultimo = 'Documento o imagen compartida';
        } elseif ($ultimo === '') {
            $ultimo = 'Aún no hay mensajes en este caso';
        }

        $filas[] = [
            'id_ticket' => (int) $fila['id_ticket'],
            'titulo' => (string) $fila['titulo'],
            'cerrado' => $cerrado,
            'estado' => $cerrado ? 'Cerrado' : 'Activo',
            'contraparte' => $contraparte,
            'ultimo_mensaje' => $ultimo,
            'ultima_actividad' => (string) (
                $fila['ultimo_mensaje_fecha'] ?: $fila['actualizado_en']
            ),
            'total_mensajes' => (int) ($fila['total_mensajes'] ?? 0),
            'total_adjuntos' => $totalAdjuntos,
            'mensajes_no_leidos' => (int) ($fila['mensajes_no_leidos'] ?? 0),
        ];
    }

    return $filas;
}

/** @return array<int,array<string,mixed>> */
function mensajesEventos(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol,
    int $idSolicitante,
    int $idTicketEtapa = 0
): array {
    $restriccion = $rol === 2
        ? " AND te.id_gestor = {$idUsuario}"
        : '';
    $restriccionEtapa = $idTicketEtapa > 0
        ? " AND te.id_ticket_etapa = {$idTicketEtapa}"
        : '';

    $mensajes = [];
    $resultado = $conn->query(
        "SELECT
            sc.id_comunicacion AS id_evento,
            sc.id_emisor AS id_autor,
            sc.mensaje,
            sc.creado_en,
            u.nombre AS autor,
            u.id_rol AS autor_rol,
            te.id_ticket_etapa,
            te.id_gestor,
            te.orden AS etapa_orden,
            te.servicio_nombre
         FROM solicitud_comunicaciones AS sc
         INNER JOIN ticket_etapas AS te
            ON te.id_ticket_etapa = sc.id_ticket_etapa
           AND te.id_ticket = sc.id_ticket
         LEFT JOIN usuarios AS u ON u.id_usuario = sc.id_emisor
         WHERE sc.id_ticket = {$idTicket}
           AND sc.tipo = 'publica'
           AND te.id_ticket_etapa_padre IS NULL
           {$restriccionEtapa}
           {$restriccion}
         ORDER BY sc.creado_en DESC, sc.id_comunicacion DESC
         LIMIT 300"
    );

    if ($resultado === false) {
        throw new RuntimeException('No fue posible cargar los mensajes.');
    }

    while ($fila = $resultado->fetch_assoc()) {
        $mensajes[] = [
            'tipo' => 'mensaje',
            'id_evento' => (int) $fila['id_evento'],
            'id_autor' => (int) ($fila['id_autor'] ?? 0),
            'id_ticket_etapa' => (int) ($fila['id_ticket_etapa'] ?? 0),
            'id_gestor_etapa' => (int) ($fila['id_gestor'] ?? 0),
            'autor' => trim((string) ($fila['autor'] ?? 'Usuario')) ?: 'Usuario',
            'autor_rol' => mensajesRolTexto((int) ($fila['autor_rol'] ?? 0)),
            'mensaje' => (string) $fila['mensaje'],
            'creado_en' => (string) $fila['creado_en'],
            'etapa' => 'Etapa ' . (int) ($fila['etapa_orden'] ?? 0)
                . ' · ' . trim((string) ($fila['servicio_nombre'] ?? 'Atención')),
        ];
    }

    $adjuntos = [];
    $resultado = $conn->query(
        "SELECT
            sa.id_adjunto AS id_evento,
            sa.id_usuario AS id_autor,
            sa.nombre_original,
            sa.tipo_mime,
            sa.tamano,
            sa.creado_en,
            u.nombre AS autor,
            u.id_rol AS autor_rol,
            te.orden AS etapa_orden,
            te.servicio_nombre
         FROM solicitud_adjuntos AS sa
         INNER JOIN ticket_etapas AS te
            ON te.id_ticket_etapa = sa.id_ticket_etapa
           AND te.id_ticket = sa.id_ticket
         LEFT JOIN usuarios AS u ON u.id_usuario = sa.id_usuario
         WHERE sa.id_ticket = {$idTicket}
           AND te.id_ticket_etapa_padre IS NULL
           {$restriccionEtapa}
           {$restriccion}
         ORDER BY sa.creado_en DESC, sa.id_adjunto DESC
         LIMIT 200"
    );

    if ($resultado === false) {
        throw new RuntimeException('No fue posible cargar los archivos del chat.');
    }

    while ($fila = $resultado->fetch_assoc()) {
        $idAdjunto = (int) $fila['id_evento'];
        $mime = (string) ($fila['tipo_mime'] ?? 'application/octet-stream');
        $adjuntos[] = [
            'tipo' => 'adjunto',
            'id_evento' => $idAdjunto,
            'id_autor' => (int) ($fila['id_autor'] ?? 0),
            'autor' => trim((string) ($fila['autor'] ?? 'Usuario')) ?: 'Usuario',
            'autor_rol' => mensajesRolTexto((int) ($fila['autor_rol'] ?? 0)),
            'nombre' => (string) ($fila['nombre_original'] ?? 'Archivo'),
            'mime' => $mime,
            'tamano' => (int) ($fila['tamano'] ?? 0),
            'url' => 'descargarAdjunto.php?id=' . $idAdjunto,
            'preview' => str_starts_with($mime, 'image/')
                ? 'descargarAdjunto.php?id=' . $idAdjunto . '&inline=1'
                : '',
            'creado_en' => (string) $fila['creado_en'],
            'etapa' => 'Etapa ' . (int) ($fila['etapa_orden'] ?? 0)
                . ' · ' . trim((string) ($fila['servicio_nombre'] ?? 'Atención')),
        ];
    }

    // La entrega depende de que el destinatario tenga una sesión activa, no
    // de que primero abra o interactúe con esta conversación.
    $entregas = [];
    foreach ($mensajes as $mensajeEvento) {
        if ((int) ($mensajeEvento['id_autor'] ?? 0) !== $idUsuario) {
            continue;
        }
        $idDestinatario = $rol === 2
            ? $idSolicitante
            : (int) ($mensajeEvento['id_gestor_etapa'] ?? 0);
        $idEtapaMensaje = (int) ($mensajeEvento['id_ticket_etapa'] ?? 0);
        if ($idDestinatario > 0 && $idEtapaMensaje > 0) {
            $entregas[$idEtapaMensaje . ':' . $idDestinatario] = [
                $idEtapaMensaje,
                $idDestinatario,
            ];
        }
    }
    foreach ($entregas as [$idEtapaMensaje, $idDestinatario]) {
        chatMarcarEntregaSiEnLinea(
            $conn,
            $idTicket,
            $idEtapaMensaje,
            $idDestinatario
        );
    }

    $eventos = array_merge($mensajes, $adjuntos);
    usort(
        $eventos,
        static fn (array $a, array $b): int =>
            strcmp((string) $a['creado_en'], (string) $b['creado_en'])
            ?: ((int) $a['id_evento'] <=> (int) $b['id_evento'])
    );

    if (count($eventos) > 500) {
        $eventos = array_slice($eventos, -500);
    }

    $estados = chatEstadosDelTicket($conn, $idTicket);
    foreach ($eventos as &$evento) {
        $evento['propio'] = (int) ($evento['id_autor'] ?? 0) === $idUsuario;
        $evento['avatar'] = (int) ($evento['id_autor'] ?? 0) > 0
            ? 'imagenPerfil.php?usuario=' . (int) $evento['id_autor']
            : '';
        if ($evento['propio'] && ($evento['tipo'] ?? '') === 'mensaje') {
            $idDestinatario = $rol === 2
                ? $idSolicitante
                : (int) ($evento['id_gestor_etapa'] ?? 0);
            $evento['estado_envio'] = chatEstadoEvento(
                $estados,
                (int) ($evento['id_ticket_etapa'] ?? 0),
                $idDestinatario,
                (string) ($evento['creado_en'] ?? '')
            );
        }
        unset($evento['id_gestor_etapa']);
    }
    unset($evento);

    return $eventos;
}

function mensajesHilo(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol,
    int $idPaisOperacion,
    int $idTicketEtapa = 0,
    bool $marcarLeido = false
): array {
    $ticket = mensajesTicketAutorizado(
        $conn,
        $idTicket,
        $idUsuario,
        $rol,
        $idPaisOperacion
    );

    if (!$ticket) {
        throw new RuntimeException('No tiene acceso a esta conversación.');
    }

    $cerrado = mensajesEsCerrado($ticket);
    $etapaSeleccionada = null;
    if ($idTicketEtapa > 0) {
        $stmt = $conn->prepare(
            "SELECT te.*, COALESCE(u.nombre, 'Gestor') AS gestor_nombre
             FROM ticket_etapas AS te
             LEFT JOIN usuarios AS u ON u.id_usuario = te.id_gestor
             WHERE te.id_ticket = ?
               AND te.id_ticket_etapa = ?
               AND te.id_ticket_etapa_padre IS NULL
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idTicket, $idTicketEtapa);
        $stmt->execute();
        $etapaSeleccionada = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (
            !$etapaSeleccionada
            || ($rol === 2 && (int) ($etapaSeleccionada['id_gestor'] ?? 0) !== $idUsuario)
        ) {
            throw new RuntimeException('No tiene acceso a esta etapa.');
        }
    }
    $idEtapaEscritura = mensajesEtapaEscritura(
        $conn,
        $ticket,
        $idUsuario,
        $rol
    );
    $etapaSoloLectura = $etapaSeleccionada !== null && (
        $cerrado
        || $idEtapaEscritura < 1
        || (int) ($etapaSeleccionada['id_ticket_etapa'] ?? 0) !== $idEtapaEscritura
        || in_array(
            strtolower((string) ($etapaSeleccionada['estado'] ?? '')),
            ['completada', 'cancelada'],
            true
        )
    );
    $contraparte = mensajesContraparte($conn, $ticket, $idUsuario, $rol);
    if ($etapaSeleccionada && $rol === 3) {
        $contraparte = [
            'id' => (int) ($etapaSeleccionada['id_gestor'] ?? 0),
            'nombre' => (string) ($etapaSeleccionada['gestor_nombre'] ?? 'Gestor'),
            'rol' => 'Gestor',
        ];
    }

    chatMarcarRecepcion(
        $conn,
        $idTicket,
        $idUsuario,
        $rol,
        $idTicketEtapa,
        $marcarLeido
    );
    $eventos = mensajesEventos(
        $conn,
        $idTicket,
        $idUsuario,
        $rol,
        (int) ($ticket['solicitante_id'] ?? 0),
        $idTicketEtapa
    );
    if ($marcarLeido) {
        flujoMarcarNotificacionesContenidoVisto(
            $conn,
            $idUsuario,
            $idTicket,
            true,
            $idTicketEtapa > 0 ? $idTicketEtapa : null
        );
    }

    return [
        'ticket' => [
            'id_ticket' => (int) $ticket['id_ticket'],
            'titulo' => (string) $ticket['titulo'],
            'cerrado' => $cerrado || $etapaSoloLectura,
            'solo_lectura' => $etapaSoloLectura,
            'estado' => $etapaSoloLectura
                ? 'Etapa finalizada · solo lectura'
                : ($cerrado ? 'Caso cerrado' : 'Caso activo'),
            'titulo_etapa' => $etapaSeleccionada
                ? 'Etapa ' . (int) $etapaSeleccionada['orden'] . ' · '
                    . (string) $etapaSeleccionada['catalogo_nombre'] . ' / '
                    . (string) $etapaSeleccionada['servicio_nombre']
                : '',
            'puede_escribir' => !$etapaSoloLectura && !$cerrado && $idEtapaEscritura > 0,
            'url_caso' => $rol === 2
                ? 'flujoTicket.php?modo=mis_tickets&id_ticket=' . (int) $ticket['id_ticket']
                : 'panelSolicitante.php?vista=tickets&id_ticket=' . (int) $ticket['id_ticket'],
        ],
        'contraparte' => $contraparte + [
            'avatar' => $contraparte['id'] > 0
                ? 'imagenPerfil.php?usuario=' . $contraparte['id']
                : '',
            'presencia' => chatObtenerPresencia($conn, (int) ($contraparte['id'] ?? 0)),
        ],
        'eventos' => $eventos,
        'adjuntos' => array_values(array_filter(
            $eventos,
            static fn (array $evento): bool => ($evento['tipo'] ?? '') === 'adjunto'
        )),
    ];
}

/**
 * Devuelve el hilo exacto de una etapa, incluidas las derivaciones internas.
 * Es el contrato común utilizado por el chat emergente de flujoTicket.php.
 *
 * @return array<string,mixed>
 */
function mensajesHiloNodo(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idUsuario,
    int $rol,
    bool $marcarLeido = false
): array {
    $ticket = flujoObtenerTicket($conn, $idTicket);
    $nodo = flujoObtenerNodo($conn, $idTicket, $idTicketEtapa);

    if (
        !$ticket
        || !$nodo
        || !flujoPuedeVerTicket($conn, $idTicket, $idUsuario, $rol)
        || !flujoPuedeVerConversacionNodo(
            $conn,
            $idTicket,
            $idTicketEtapa,
            $idUsuario,
            $rol
        )
    ) {
        throw new RuntimeException('No tiene acceso a esta conversación.');
    }

    $participantes = flujoParticipantesConversacion(
        $conn,
        $idTicket,
        $idTicketEtapa
    ) ?? ['origen' => 0, 'destino' => 0];
    $idOrigen = (int) ($participantes['origen'] ?? 0);
    $idDestino = (int) ($participantes['destino'] ?? 0);
    $idContraparte = $idUsuario === $idDestino ? $idOrigen : $idDestino;
    if ($rol === 1 || $idContraparte < 1) {
        $idContraparte = $idDestino > 0 ? $idDestino : $idOrigen;
    }

    chatMarcarRecepcion(
        $conn,
        $idTicket,
        $idUsuario,
        $rol,
        $idTicketEtapa,
        $marcarLeido
    );

    $eventosBase = flujoLineaTiempoConversacion(
        flujoComunicacionesNodo($conn, $idTicket, $idTicketEtapa),
        flujoAdjuntosNodo($conn, $idTicket, $idTicketEtapa)
    );

    if ($idContraparte > 0) {
        foreach ($eventosBase as $eventoBase) {
            if (
                (string) ($eventoBase['tipo_evento'] ?? '') === 'mensaje'
                && (int) ($eventoBase['id_autor'] ?? 0) === $idUsuario
            ) {
                chatMarcarEntregaSiEnLinea(
                    $conn,
                    $idTicket,
                    $idTicketEtapa,
                    $idContraparte
                );
                break;
            }
        }
    }

    $estados = chatEstadosDelTicket($conn, $idTicket);
    $eventos = [];
    foreach ($eventosBase as $eventoBase) {
        $esAdjunto = (string) ($eventoBase['tipo_evento'] ?? '') === 'adjunto';
        $idAutor = (int) ($eventoBase['id_autor'] ?? 0);
        $evento = [
            'tipo' => $esAdjunto ? 'adjunto' : 'mensaje',
            'id_evento' => (int) ($eventoBase['id_evento'] ?? 0),
            'id_autor' => $idAutor,
            'autor' => trim((string) ($eventoBase['autor'] ?? 'Usuario')) ?: 'Usuario',
            'autor_rol' => mensajesRolTexto((int) ($eventoBase['autor_rol'] ?? 0)),
            'creado_en' => (string) ($eventoBase['creado_en'] ?? ''),
            'propio' => $idAutor === $idUsuario,
            'avatar' => $idAutor > 0 ? 'imagenPerfil.php?usuario=' . $idAutor : '',
        ];

        if ($esAdjunto) {
            $idAdjunto = (int) ($eventoBase['id_adjunto'] ?? 0);
            $mime = (string) ($eventoBase['tipo_mime'] ?? 'application/octet-stream');
            $evento += [
                'nombre' => (string) ($eventoBase['nombre_original'] ?? 'Archivo'),
                'mime' => $mime,
                'tamano' => (int) ($eventoBase['tamano'] ?? 0),
                'url' => 'descargarAdjunto.php?id=' . $idAdjunto,
                'preview' => str_starts_with($mime, 'image/')
                    ? 'descargarAdjunto.php?id=' . $idAdjunto . '&inline=1'
                    : '',
            ];
        } else {
            $evento['mensaje'] = (string) ($eventoBase['mensaje'] ?? '');
            if ($evento['propio']) {
                $evento['estado_envio'] = chatEstadoEvento(
                    $estados,
                    $idTicketEtapa,
                    $idContraparte,
                    $evento['creado_en']
                );
            }
        }
        $eventos[] = $evento;
    }

    $contraparte = ['id' => $idContraparte, 'nombre' => 'Usuario', 'rol' => 'Usuario'];
    if ($idContraparte > 0) {
        $stmt = $conn->prepare(
            "SELECT nombre, id_rol FROM usuarios WHERE id_usuario = ? LIMIT 1"
        );
        $stmt->bind_param('i', $idContraparte);
        $stmt->execute();
        $filaContraparte = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($filaContraparte) {
            $contraparte['nombre'] = trim((string) ($filaContraparte['nombre'] ?? 'Usuario')) ?: 'Usuario';
            $contraparte['rol'] = mensajesRolTexto((int) ($filaContraparte['id_rol'] ?? 0));
        }
    }

    if ($marcarLeido) {
        flujoMarcarNotificacionesContenidoVisto(
            $conn,
            $idUsuario,
            $idTicket,
            true,
            $idTicketEtapa
        );
    }

    $esDerivacion = (int) ($nodo['id_ticket_etapa_padre'] ?? 0) > 0;
    return [
        'ticket' => [
            'id_ticket' => $idTicket,
            'id_ticket_etapa' => $idTicketEtapa,
            'titulo' => (string) ($ticket['titulo'] ?? ''),
            'titulo_etapa' => $esDerivacion
                ? 'Ticket ' . flujoCodigoCaso($conn, $idTicket, $idTicketEtapa)
                : 'Etapa ' . flujoNumeroEtapaNodo($conn, $idTicket, $idTicketEtapa)
                    . ' · ' . (string) ($nodo['servicio_nombre'] ?? 'Atención'),
            'puede_escribir' => flujoPuedeEscribirNodo(
                $conn,
                $ticket,
                $idTicketEtapa,
                $idUsuario,
                $rol
            ),
        ],
        'contraparte' => $contraparte + [
            'avatar' => $idContraparte > 0
                ? 'imagenPerfil.php?usuario=' . $idContraparte
                : '',
            'presencia' => chatObtenerPresencia($conn, $idContraparte),
        ],
        'eventos' => $eventos,
        'adjuntos' => array_values(array_filter(
            $eventos,
            static fn (array $evento): bool => ($evento['tipo'] ?? '') === 'adjunto'
        )),
    ];
}

/** @return array<int,array{id_ticket_etapa:int,mensajes_no_leidos:int}> */
function mensajesConteosNodos(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol
): array {
    if (!flujoPuedeVerTicket($conn, $idTicket, $idUsuario, $rol)) {
        throw new RuntimeException('No tiene acceso a las conversaciones de este caso.');
    }

    $conteos = [];
    foreach (flujoConversacionesDisponibles($conn, $idTicket, $idUsuario, $rol) as $conversacion) {
        $idEtapa = (int) ($conversacion['id_ticket_etapa'] ?? 0);
        if ($idEtapa < 1) {
            continue;
        }
        if (!chatEstadoDisponible($conn)) {
            $conteos[] = [
                'id_ticket_etapa' => $idEtapa,
                'mensajes_no_leidos' => 0,
            ];
            continue;
        }
        $stmt = $conn->prepare(
            "SELECT COUNT(*) AS total
             FROM solicitud_comunicaciones AS sc
             LEFT JOIN chat_conversacion_estado AS ce
                ON ce.id_ticket = sc.id_ticket
               AND ce.id_ticket_etapa = sc.id_ticket_etapa
               AND ce.id_usuario = ?
             INNER JOIN ticket_etapas AS te
                ON te.id_ticket = sc.id_ticket
               AND te.id_ticket_etapa = sc.id_ticket_etapa
             WHERE sc.id_ticket = ?
               AND sc.id_ticket_etapa = ?
               AND sc.id_emisor IS NOT NULL
               AND sc.id_emisor <> ?
               AND (te.id_ticket_etapa_padre IS NOT NULL OR sc.tipo = 'publica')
               AND (ce.leido_hasta IS NULL OR sc.creado_en > ce.leido_hasta)"
        );
        $stmt->bind_param('iiii', $idUsuario, $idTicket, $idEtapa, $idUsuario);
        $stmt->execute();
        $total = (int) ($stmt->get_result()->fetch_assoc()['total'] ?? 0);
        $stmt->close();
        $conteos[] = [
            'id_ticket_etapa' => $idEtapa,
            'mensajes_no_leidos' => max(0, $total),
        ];
    }

    return $conteos;
}

function mensajesRevisionCaso(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol
): string {
    if (!flujoPuedeVerTicket($conn, $idTicket, $idUsuario, $rol)) {
        throw new RuntimeException('No tiene acceso a este caso.');
    }

    $ticket = flujoObtenerTicket($conn, $idTicket);
    if (!$ticket) {
        throw new RuntimeException('El caso solicitado no existe.');
    }

    $partes = [
        (string) ($ticket['estado'] ?? ''),
        (string) ($ticket['estado_flujo'] ?? ''),
        (string) ($ticket['id_etapa_actual'] ?? ''),
        (string) ($ticket['fecha_finalizacion'] ?? ''),
        (string) ($ticket['cierre_tipo'] ?? ''),
        (string) ($ticket['motivo_cierre'] ?? ''),
    ];
    $stmt = $conn->prepare(
        "SELECT
            id_ticket_etapa,
            id_ticket_etapa_padre,
            id_servicio,
            id_gestor,
            estado,
            fecha_activacion,
            fecha_vencimiento,
            fecha_pausa,
            fecha_marcado_listo,
            fecha_finalizacion,
            fecha_ultima_reapertura,
            cantidad_reaperturas,
            cantidad_pausas,
            id_solucion,
            solucion_nombre,
            comentario_cierre,
            solicita_cierre_definitivo,
            actualizado_en
         FROM ticket_etapas
         WHERE id_ticket = ?
         ORDER BY id_ticket_etapa"
    );
    $stmt->bind_param('i', $idTicket);
    $stmt->execute();
    $resultado = $stmt->get_result();

    while ($etapa = $resultado->fetch_assoc()) {
        $partes[] = implode('|', array_map(
            static fn ($valor): string => (string) ($valor ?? ''),
            array_values($etapa)
        ));
    }
    $stmt->close();

    return hash('sha256', implode("\n", $partes));
}

try {
    if (!flujoModuloInstalado($conn)) {
        mensajesJson([
            'ok' => false,
            'message' => 'El módulo de conversaciones aún no está disponible.'
        ], 503);
    }

    $metodo = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    $accion = strtolower(trim((string) ($_REQUEST['action'] ?? 'list')));

    if ($metodo === 'GET' && $accion === 'case_revision') {
        $idTicket = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        if ($idTicket < 1) {
            mensajesJson(['ok' => false, 'message' => 'Caso inválido.'], 422);
        }
        paisExigirTicket($conn, $idTicket);
        mensajesJson([
            'ok' => true,
            'revision' => mensajesRevisionCaso(
                $conn,
                $idTicket,
                $idUsuario,
                $rol
            ),
        ]);
    }

    if ($metodo === 'GET' && $accion === 'list') {
        $filtro = strtolower(trim((string) ($_GET['filter'] ?? 'abiertos')));
        if (!in_array($filtro, ['abiertos', 'cerrados', 'todos', 'completadas'], true)) {
            $filtro = 'abiertos';
        }
        $buscar = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 80);
        $filtroLectura = strtolower(trim((string) ($_GET['read'] ?? 'todos')));
        if (!in_array($filtroLectura, ['todos', 'leidos', 'no_leidos'], true)) {
            $filtroLectura = 'todos';
        }

        mensajesJson([
            'ok' => true,
            'conversaciones' => mensajesLista(
                $conn,
                $idUsuario,
                $rol,
                $idPaisOperacion,
                $filtro,
                $buscar,
                $filtroLectura
            ),
        ]);
    }

    if ($metodo === 'GET' && $accion === 'thread') {
        $idTicket = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_GET, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $marcarLeido = (string) ($_GET['mark_read'] ?? '0') === '1';
        if ($idTicket < 1) {
            mensajesJson(['ok' => false, 'message' => 'Caso inválido.'], 422);
        }

        mensajesJson([
            'ok' => true,
            'hilo' => mensajesHilo(
                $conn,
                $idTicket,
                $idUsuario,
                $rol,
                $idPaisOperacion,
                $idTicketEtapa,
                $marcarLeido
            ),
        ]);
    }

    if ($metodo === 'GET' && $accion === 'node_thread') {
        $idTicket = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_GET, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $marcarLeido = (string) ($_GET['mark_read'] ?? '0') === '1';
        if ($idTicket < 1 || $idTicketEtapa < 1) {
            mensajesJson(['ok' => false, 'message' => 'Conversación inválida.'], 422);
        }
        paisExigirTicket($conn, $idTicket);
        mensajesJson([
            'ok' => true,
            'hilo' => mensajesHiloNodo(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                $rol,
                $marcarLeido
            ),
        ]);
    }

    if ($metodo === 'GET' && $accion === 'node_counts') {
        $idTicket = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        if ($idTicket < 1) {
            mensajesJson(['ok' => false, 'message' => 'Caso inválido.'], 422);
        }
        paisExigirTicket($conn, $idTicket);
        mensajesJson([
            'ok' => true,
            'conteos' => mensajesConteosNodos(
                $conn,
                $idTicket,
                $idUsuario,
                $rol
            ),
        ]);
    }

    if ($metodo === 'POST' && $accion === 'read') {
        seguridadExigirCsrfPost();
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        if ($idTicket < 1) {
            mensajesJson(['ok' => false, 'message' => 'Caso inválido.'], 422);
        }

        // Valida la misma autorización y la etapa antes de registrar la lectura.
        mensajesHilo(
            $conn,
            $idTicket,
            $idUsuario,
            $rol,
            $idPaisOperacion,
            $idTicketEtapa
        );
        chatMarcarRecepcion(
            $conn,
            $idTicket,
            $idUsuario,
            $rol,
            $idTicketEtapa,
            true
        );

        mensajesJson(['ok' => true]);
    }

    if ($metodo === 'POST' && $accion === 'send') {
        seguridadExigirCsrfPost();
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $mensaje = trim((string) ($_POST['mensaje'] ?? ''));

        $ticket = mensajesTicketAutorizado(
            $conn,
            $idTicket,
            $idUsuario,
            $rol,
            $idPaisOperacion
        );

        if (!$ticket) {
            mensajesJson(['ok' => false, 'message' => 'No tiene acceso a este caso.'], 403);
        }

        if (mensajesEsCerrado($ticket)) {
            mensajesJson([
                'ok' => false,
                'closed' => true,
                'message' => 'El caso fue cerrado y la conversación quedó en modo lectura.'
            ], 409);
        }

        $idEtapa = mensajesEtapaEscritura($conn, $ticket, $idUsuario, $rol);
        if ($idEtapa < 1) {
            mensajesJson([
                'ok' => false,
                'message' => 'La conversación no está habilitada en la etapa actual.'
            ], 409);
        }

        flujoEnviarConversacion(
            $conn,
            $ticket,
            $idEtapa,
            $idUsuario,
            $rol,
            $mensaje,
            $_FILES['adjuntos'] ?? []
        );

        mensajesJson([
            'ok' => true,
            'id_ticket' => $idTicket,
            'id_ticket_etapa' => $idEtapa,
        ]);
    }

    if ($metodo === 'POST' && $accion === 'node_send') {
        seguridadExigirCsrfPost();
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $mensaje = trim((string) ($_POST['mensaje'] ?? ''));
        if ($idTicket < 1 || $idTicketEtapa < 1) {
            mensajesJson(['ok' => false, 'message' => 'Conversación inválida.'], 422);
        }
        paisExigirTicket($conn, $idTicket);
        $ticket = flujoObtenerTicket($conn, $idTicket);
        if (
            !$ticket
            || !flujoPuedeVerTicket($conn, $idTicket, $idUsuario, $rol)
            || !flujoPuedeVerConversacionNodo(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                $rol
            )
        ) {
            mensajesJson(['ok' => false, 'message' => 'No tiene acceso a esta conversación.'], 403);
        }
        flujoEnviarConversacion(
            $conn,
            $ticket,
            $idTicketEtapa,
            $idUsuario,
            $rol,
            $mensaje,
            $_FILES['adjuntos'] ?? []
        );
        mensajesJson([
            'ok' => true,
            'id_ticket' => $idTicket,
            'id_ticket_etapa' => $idTicketEtapa,
        ]);
    }

    mensajesJson(['ok' => false, 'message' => 'Acción no válida.'], 405);
} catch (RuntimeException $e) {
    mensajesJson(['ok' => false, 'message' => $e->getMessage()], 422);
} catch (Throwable $e) {
    error_log('Módulo Mensajes: ' . $e->getMessage());
    mensajesJson([
        'ok' => false,
        'message' => 'No fue posible completar la operación de mensajes.'
    ], 500);
}
