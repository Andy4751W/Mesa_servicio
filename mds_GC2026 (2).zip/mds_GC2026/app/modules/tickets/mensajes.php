<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';

seguridadExigirRol([2, 3]);
paisExigirContexto();

$idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
$rol = (int) ($_SESSION['rol'] ?? 0);
$nombre = trim((string) ($_SESSION['usuario'] ?? 'Usuario')) ?: 'Usuario';
$csrf = seguridadTokenCsrf();
$idInicial = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
$idEtapaInicial = filter_input(INPUT_GET, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Mensajes | Mesa de Servicio</title>
    <style>
        *{box-sizing:border-box}
        body{margin:0}
        .messages-page{min-height:calc(100vh - 70px);padding:22px;background:var(--mesa-theme-bg,#0f1117);font:14px/1.45 Inter,"Segoe UI",Arial,sans-serif;color:var(--mesa-theme-text,#e6edf3)}
        .messages-head{display:flex;align-items:flex-end;justify-content:space-between;gap:18px;max-width:1320px;margin:0 auto 15px}.messages-head h1{margin:0;color:var(--mesa-theme-heading,#f0f6fc);font-size:27px;letter-spacing:-.025em}.messages-head p{margin:4px 0 0;color:var(--mesa-theme-muted,#657b8f);font-size:12px}.messages-role{display:inline-flex;align-items:center;gap:7px;padding:7px 10px;border:1px solid var(--mesa-theme-border,#d9e4ed);border-radius:999px;color:var(--mesa-shell-color,#0f6fec);background:var(--mesa-theme-surface,#161b22);font-size:10px;font-weight:900}.messages-role::before{width:7px;height:7px;border-radius:50%;background:#23b17f;box-shadow:0 0 0 4px rgba(35,177,127,.12);content:""}
        .messenger{max-width:1320px;height:min(760px,calc(100vh - 145px));min-height:560px;display:grid;grid-template-columns:370px minmax(0,1fr);margin:0 auto;overflow:hidden;border:1px solid var(--mesa-theme-border,#d9e4ed);border-radius:20px;background:var(--mesa-theme-surface,#161b22);box-shadow:0 20px 48px rgba(16,42,67,.11)}
        .conversation-pane{min-width:0;display:flex;flex-direction:column;border-right:1px solid var(--mesa-theme-border,#d9e4ed);background:color-mix(in srgb,var(--mesa-theme-surface,#fff) 97%,var(--mesa-shell-color,#0f6fec))}.conversation-toolbar{padding:16px 15px 12px;border-bottom:1px solid var(--mesa-theme-border,#e0e8ef)}.conversation-toolbar-top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:11px}.conversation-toolbar strong{color:var(--mesa-theme-heading,#17324a);font-size:16px}.conversation-count{min-width:26px;height:24px;display:grid;place-items:center;padding:0 7px;border-radius:999px;color:var(--mesa-shell-color,#0f6fec);background:var(--mesa-theme-soft,#edf5ff);font-size:9px;font-weight:900}.search-wrap{position:relative}.search-wrap svg{position:absolute;left:11px;top:50%;width:16px;height:16px;transform:translateY(-50%);fill:none;stroke:#768da1;stroke-width:2}.search-wrap input{width:100%;height:40px;padding:8px 12px 8px 36px;border:1px solid var(--mesa-theme-border,#d4e0ea);border-radius:12px;outline:none;color:var(--mesa-theme-text,#e6edf3);background:var(--mesa-theme-bg,#f7fafc);font:inherit;font-size:11px}.search-wrap input:focus{border-color:var(--mesa-shell-color,#0f6fec);box-shadow:0 0 0 3px color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 12%,transparent)}.conversation-filter-section{display:grid;gap:7px;margin-top:10px}.conversation-filters{display:flex;flex-wrap:wrap;gap:6px;margin:0}.conversation-filter{padding:6px 10px;border:1px solid transparent;border-radius:999px;color:var(--mesa-theme-muted,#657b8f);background:transparent;cursor:pointer;font:800 9px/1.2 Inter,"Segoe UI",Arial,sans-serif}.conversation-filter:hover{background:var(--mesa-theme-soft,#edf5ff)}.conversation-filter.active{border-color:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 22%,transparent);color:var(--mesa-shell-color,#0f6fec);background:var(--mesa-theme-soft,#edf5ff)}.conversation-read-filters{display:flex;align-items:center;flex-wrap:wrap;gap:6px;width:100%}.conversation-read-filter{display:inline-flex;align-items:center;justify-content:center;gap:4px;min-height:25px;padding:5px 9px;border:1px solid var(--mesa-theme-border,#d4e0ea);border-radius:999px;color:var(--mesa-theme-muted,#657b8f);background:var(--mesa-theme-surface,#fff);cursor:pointer;font:800 9px/1.2 Inter,"Segoe UI",Arial,sans-serif;white-space:nowrap}.conversation-read-filter:hover{border-color:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 38%,var(--mesa-theme-border,#d4e0ea));background:var(--mesa-theme-soft,#edf5ff)}.conversation-read-filter.active{border-color:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 55%,var(--mesa-theme-border,#d4e0ea));color:var(--mesa-shell-color,#0f6fec);background:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 13%,var(--mesa-theme-surface,#fff));box-shadow:none}.conversation-read-count{font-weight:900;opacity:.78}
        .conversation-list{min-height:0;flex:1;overflow-y:auto;padding:7px}.conversation-item{width:100%;display:grid;grid-template-columns:48px minmax(0,1fr);gap:10px;padding:10px;border:0;border-radius:13px;color:inherit;background:transparent;text-align:left;cursor:pointer;transition:.15s ease}.conversation-item:hover{background:var(--mesa-theme-soft,#edf5ff)}.conversation-item.active{background:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 13%,var(--mesa-theme-surface,#fff))}.conversation-avatar{position:relative;width:48px;height:48px}.conversation-avatar img{width:48px;height:48px;display:block;border:2px solid var(--mesa-theme-surface,#fff);border-radius:50%;object-fit:cover;background:#e6edf4;box-shadow:0 3px 10px rgba(25,58,86,.12)}.conversation-state-dot{position:absolute;right:0;bottom:1px;width:12px;height:12px;border:2px solid var(--mesa-theme-surface,#fff);border-radius:50%;background:#24b47e}.conversation-item.closed .conversation-state-dot{background:#8595a5}.conversation-copy{min-width:0}.conversation-line{display:flex;align-items:center;justify-content:space-between;gap:8px}.conversation-line-meta{display:inline-flex;flex:0 0 auto;align-items:center;gap:6px}.conversation-name{overflow:hidden;color:var(--mesa-theme-heading,#153049);font-size:11px;font-weight:900;text-overflow:ellipsis;white-space:nowrap}.conversation-time{flex:0 0 auto;color:var(--mesa-theme-muted,#8092a3);font-size:8px}.conversation-unread-indicator{width:8px;height:8px;flex:0 0 8px;border:2px solid var(--mesa-theme-surface,#fff);border-radius:50%;background:var(--mesa-shell-color,#0f6fec);box-shadow:0 0 0 3px color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 16%,transparent);animation:conversationUnreadPulse 1.6s ease-in-out infinite}.conversation-unread-count{min-width:18px;height:18px;display:inline-grid;flex:0 0 auto;place-items:center;padding:0 5px;border:1px solid color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 70%,var(--mesa-theme-border,#d9e4ed));border-radius:999px;color:var(--mesa-theme-on-primary,#fff);background:var(--mesa-shell-color,#0f6fec);box-shadow:0 3px 8px color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 24%,transparent);font-size:8px;font-weight:950;line-height:1}.conversation-item.has-unread .conversation-name,.conversation-item.has-unread .conversation-case{font-weight:950}.conversation-item.has-unread .conversation-preview{color:var(--mesa-theme-heading,#153049);font-weight:800}@keyframes conversationUnreadPulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(.78);opacity:.72}}.conversation-case{display:block;margin-top:2px;overflow:hidden;color:var(--mesa-shell-color,#0f6fec);font-size:9px;font-weight:850;text-overflow:ellipsis;white-space:nowrap}.conversation-preview{display:block;margin-top:5px;overflow:hidden;color:var(--mesa-theme-muted,#667d91);font-size:9px;font-weight:600;text-overflow:ellipsis;white-space:nowrap}.conversation-empty{display:grid;place-items:center;min-height:230px;padding:28px;color:var(--mesa-theme-muted,#6b8194);text-align:center;font-size:11px}
        .thread-pane{min-width:0;display:flex;flex-direction:column;background:var(--mesa-theme-bg,#0d1117)}.thread-empty{height:100%;display:grid;place-items:center;padding:40px;text-align:center}.thread-empty-icon{width:72px;height:72px;display:grid;place-items:center;margin:0 auto 15px;border-radius:50%;color:var(--mesa-shell-color,#0f6fec);background:var(--mesa-theme-soft,#eaf3fd)}.thread-empty-icon svg{width:32px;height:32px;fill:none;stroke:currentColor;stroke-width:1.7}.thread-empty strong{display:block;color:var(--mesa-theme-heading,#17324a);font-size:18px}.thread-empty p{max-width:420px;margin:5px auto 0;color:var(--mesa-theme-muted,#6d8294);font-size:11px}.thread-content{height:100%;min-height:0;display:none;flex-direction:column}.thread-content.visible{display:flex}.thread-header{display:flex;align-items:center;justify-content:space-between;gap:14px;min-height:72px;padding:11px 17px;border-bottom:1px solid var(--mesa-theme-border,#dbe5ed);background:var(--mesa-theme-surface,#161b22)}.thread-person{min-width:0;display:flex;align-items:center;gap:10px}.thread-person img,.thread-person-fallback{width:43px;height:43px;flex:0 0 43px;border-radius:50%}.thread-person img{display:block;object-fit:cover;background:#e5edf4}.thread-person-fallback{display:grid;place-items:center;color:#fff;background:var(--mesa-shell-color,#0f6fec);font-size:10px;font-weight:900}.thread-person-copy{min-width:0}.thread-person-copy strong,.thread-person-copy small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.thread-person-copy strong{color:var(--mesa-theme-heading,#17324a);font-size:13px}.thread-person-copy small{margin-top:2px;color:var(--mesa-theme-muted,#6f8395);font-size:9px}.thread-actions{display:flex;align-items:center;gap:8px}.thread-status{padding:6px 9px;border-radius:999px;color:#16825e;background:#e7f8f1;font-size:8px;font-weight:900;text-transform:uppercase}.thread-status.closed{color:#65788a;background:#edf1f4}.thread-case-link{width:34px;height:34px;display:grid;place-items:center;border:1px solid var(--mesa-theme-border,#d7e1ea);border-radius:10px;color:var(--mesa-shell-color,#0f6fec);background:var(--mesa-theme-surface,#161b22);text-decoration:none}.thread-case-link svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.9}
        .closed-banner{display:none;align-items:center;justify-content:center;gap:8px;padding:9px 14px;color:#687b8d;background:#edf1f4;border-bottom:1px solid #dde5eb;font-size:9px;font-weight:800}.closed-banner.visible{display:flex}.closed-banner svg{width:15px;height:15px;fill:none;stroke:currentColor;stroke-width:2}
        .timeline{min-height:0;flex:1;overflow-y:auto;padding:18px 20px;background:linear-gradient(rgba(13,17,23,.92),rgba(13,17,23,.92)),radial-gradient(circle at 10px 10px,#30363d 1px,transparent 1px);background-size:auto,26px 26px;overscroll-behavior:contain}.timeline-empty{height:100%;display:grid;place-items:center;color:#6f8497;font-size:11px;text-align:center}.message-row{display:flex;align-items:flex-end;gap:8px;margin:7px 0}.message-row.mine{justify-content:flex-end}.message-avatar{width:27px;height:27px;flex:0 0 27px;border-radius:50%;object-fit:cover;background:#dfe8ef}.message-row.mine .message-avatar{order:2}.message-stack{max-width:min(72%,620px)}.message-author{display:flex;align-items:center;gap:5px;margin:0 3px 4px;color:#72869a;font-size:10px}.message-row.mine .message-author{justify-content:flex-end}.message-author strong{color:#8b949e;font-size:10px}.message-bubble{padding:9px 12px;border:1px solid var(--mesa-theme-border,#d7e1e9);border-radius:5px 16px 16px 16px;color:var(--mesa-theme-text,#1f2937);background:var(--mesa-theme-surface,#ffffff);box-shadow:0 3px 10px rgba(35,65,90,.05);font-size:11px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere;}.message-row.mine .message-bubble{border-color:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 30%,#d7e1e9);border-radius:16px 5px 16px 16px;background:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 11%,var(--mesa-theme-surface,#fff))}.message-meta{display:flex;justify-content:flex-end;gap:20px;margin:4px 4px 0;color:#8495a4;font-size:10px}.message-stage{max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.attachment-card{display:block;min-width:220px;color:inherit;text-decoration:none}.attachment-preview{width:min(320px,100%);max-height:250px;display:block;border-radius:10px;object-fit:cover;background:#dfe8ef}.attachment-file{display:grid;grid-template-columns:38px minmax(0,1fr) 22px;gap:8px;align-items:center}.attachment-icon{width:38px;height:38px;display:grid;place-items:center;border-radius:10px;color:var(--mesa-shell-color,#0f6fec);background:var(--mesa-theme-soft,#edf5ff);font-size:9px;font-weight:900}.attachment-copy{min-width:0}.attachment-copy strong,.attachment-copy small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.attachment-copy strong{font-size:9px}.attachment-copy small{margin-top:2px;color:#8b949e;font-size:7px}.attachment-download{color:var(--mesa-shell-color,#0f6fec);font-size:18px}
        .composer{flex:0 0 auto;padding:10px 13px 13px;border-top:1px solid var(--mesa-theme-border,#d9e4ec);background:var(--mesa-theme-surface,#161b22)}.composer-files{display:none;gap:6px;overflow-x:auto;margin-bottom:7px}.composer-files.visible{display:flex}.file-chip{flex:0 0 auto;max-width:180px;padding:5px 8px;border-radius:999px;color:var(--mesa-theme-muted,#61788e);background:var(--mesa-theme-soft,#eef4f9);font-size:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.composer-row{display:grid;grid-template-columns:39px minmax(0,1fr) 42px;gap:7px;align-items:end}.composer-attach,.composer-send{height:39px;display:grid;place-items:center;border:0;border-radius:50%;cursor:pointer}.composer-attach{color:#49677f;background:var(--mesa-theme-soft,#edf3f8)}.composer-send{color:#fff;background:var(--mesa-shell-color,#0f6fec);box-shadow:0 6px 14px color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 26%,transparent)}.composer-attach svg,.composer-send svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.9}.composer textarea{width:100%;height:39px;min-height:39px;max-height:110px;padding:10px 13px;border:1px solid var(--mesa-theme-border,#cddce8);border-radius:20px;outline:none;resize:none;color:var(--mesa-theme-text,#e6edf);background:var(--mesa-theme-bg,#f7fafc);font:inherit;font-size:11px;line-height:1.45}.composer textarea:focus{border-color:var(--mesa-shell-color,#0f6fec);box-shadow:0 0 0 3px color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 10%,transparent)}.composer input[type=file]{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}.composer.disabled{display:none}.compose-note{margin:6px 8px 0;color:#8091a1;font-size:10px;text-align:center}
        .toast{position:fixed;right:22px;bottom:22px;z-index:99999;max-width:340px;padding:10px 13px;border-radius:11px;color:#fff;background:#173a57;box-shadow:0 15px 35px rgba(10,35,58,.25);font-size:10px;font-weight:750;transform:translateY(15px);opacity:0;pointer-events:none;transition:.18s ease}.toast.visible{transform:none;opacity:1}.toast.error{background:#a43b46}
        @media(max-width:900px){.messages-page{padding:12px}.messages-head{align-items:flex-start;flex-direction:column}.messenger{height:calc(100vh - 150px);min-height:520px;grid-template-columns:310px minmax(0,1fr)}}
        @media(max-width:700px){.messenger{position:relative;display:block;height:calc(100vh - 150px)}.conversation-pane,.thread-pane{position:absolute;inset:0}.thread-pane{z-index:2;display:none}.messenger.thread-open .thread-pane{display:flex}.messenger.thread-open .conversation-pane{display:none}.thread-header{padding-left:10px}.thread-back{display:grid!important}.message-stack{max-width:84%}}
        .thread-back{width:34px;height:34px;display:none;place-items:center;border:0;border-radius:10px;color:#48657d;background:var(--mesa-theme-soft,#edf3f8);cursor:pointer}.thread-back svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:2}
    
        /* Distribución estable: solo la conversación se desplaza y el editor
           permanece visible. Los colores los aporta la capa global del tema. */
        html,body{height:100%;overflow:hidden}
        .messages-page{height:calc(100vh - 70px);overflow:hidden}
        .messenger{height:calc(100vh - 145px);min-height:0}
        .thread-pane,.thread-content{min-height:0}
        .thread-content{height:100%;display:none;flex-direction:column}
        .thread-content.visible{display:flex}
        .timeline{min-height:0;flex:1 1 auto;overflow-y:auto;padding-bottom:10px}
        .composer{position:relative;z-index:5;flex:0 0 auto;margin:0}
        .attachment-preview{max-width:320px;max-height:220px;object-fit:contain}
        .toggle-conversations,.show-conversations{place-items:center;border:1px solid var(--mesa-theme-border);border-radius:9px;color:var(--mesa-theme-text);background:var(--mesa-theme-surface);cursor:pointer}
        .toggle-conversations{width:28px;height:28px;display:none;font-size:15px}
        .messenger.thread-open .toggle-conversations{display:grid}
        .show-conversations{width:34px;height:34px;display:none;font-size:16px}
        .toggle-conversations:hover,.show-conversations:hover{background:var(--mesa-theme-soft)}
        .thread-files-toggle{min-height:34px;padding:7px 10px;border:1px solid var(--mesa-theme-border);border-radius:9px;color:var(--mesa-theme-heading);background:var(--mesa-theme-soft);font:inherit;font-size:10px;font-weight:850;cursor:pointer}
        .thread-files-panel{display:none;flex:0 0 auto;max-height:210px;overflow:auto;padding:10px 13px;border-bottom:1px solid var(--mesa-theme-border);background:var(--mesa-theme-soft)}
        .thread-files-panel.visible{display:block}.thread-files-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:8px}.thread-file-item{display:grid;grid-template-columns:34px minmax(0,1fr) auto;gap:8px;align-items:center;padding:8px;border:1px solid var(--mesa-theme-border);border-radius:10px;color:var(--mesa-theme-text);background:var(--mesa-theme-surface);text-decoration:none}.thread-file-item strong,.thread-file-item small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.thread-file-item strong{font-size:10px}.thread-file-item small{color:var(--mesa-theme-muted);font-size:8px}.thread-file-icon{width:34px;height:34px;display:grid;place-items:center;border-radius:8px;color:var(--mesa-theme-link);background:var(--mesa-theme-soft);font-size:9px;font-weight:900}.thread-files-empty{padding:12px;color:var(--mesa-theme-muted);text-align:center;font-size:10px}
        .messenger.hide-conversations{grid-template-columns:0 minmax(0,1fr)}
        .messenger.hide-conversations .conversation-pane{overflow:hidden;opacity:0;pointer-events:none}
        .messenger.hide-conversations .thread-pane{width:100%}
        .messenger.hide-conversations .show-conversations{display:grid}

        /* Presencia de sesión y confirmaciones reales del mensaje. */
        .conversation-state-dot.offline{background:#8595a5!important}
        .thread-presence{position:relative;padding-left:11px}
        .thread-presence::before{position:absolute;left:0;top:50%;width:7px;height:7px;border-radius:50%;background:#8595a5;transform:translateY(-50%);content:""}
        .thread-presence.online{color:#16825e!important;font-weight:800}
        .thread-presence.online::before{background:#24b47e;box-shadow:0 0 0 3px rgba(36,180,126,.12)}
        .message-meta{align-items:center;gap:9px}
        .message-stage{margin-right:auto}
        .message-receipt{min-width:14px;color:var(--mesa-theme-muted,#8495a4);font-size:12px;font-weight:900;letter-spacing:-3px;white-space:nowrap}
        .message-receipt.read{color:var(--mesa-shell-color,#0f6fec)}
        .message-row.pending .message-bubble{opacity:.82}
        .message-row.pending .message-receipt{letter-spacing:0}

</style>
<style id="messages-readable-density">
:root{
    --gc-readable-body:clamp(14px,.84rem + .22vw,16px);
    --gc-readable-secondary:clamp(13px,.78rem + .18vw,15px);
    --gc-readable-title:clamp(16px,.96rem + .42vw,20px);
}
.messages-page{font-size:var(--gc-readable-body);line-height:1.5}
.messages-head{width:100%;max-width:none;gap:22px;margin-bottom:20px}
.messages-head h1{font-size:clamp(20px,1.25rem + .45vw,27px)}
.messages-head p{margin-top:7px;font-size:var(--gc-readable-secondary)}
.messages-role{padding:9px 12px;font-size:var(--gc-readable-secondary)}
.messenger{width:100%;max-width:none;margin:0;grid-template-columns:minmax(320px,clamp(320px,24vw,380px)) minmax(0,1fr)}
.conversation-toolbar{padding:20px 18px 15px}
.conversation-toolbar-top{gap:12px;margin-bottom:14px}
.conversation-toolbar strong{font-size:var(--gc-readable-title)}
.conversation-count{min-width:30px;height:28px;padding:0 8px;font-size:var(--gc-readable-secondary)}
.search-wrap input{height:46px;padding:10px 13px 10px 39px;font-size:var(--gc-readable-body)}
.conversation-filter-section{gap:10px;margin-top:13px}
.conversation-filters,.conversation-read-filters{gap:8px}
.conversation-filter,.conversation-read-filter{
    min-height:36px;
    padding:8px 12px;
    font-size:var(--gc-readable-secondary);
}
.conversation-list{padding:9px}
.conversation-item{gap:12px;padding:13px 12px;border-radius:14px}
.conversation-name{font-size:var(--gc-readable-body)}
.conversation-time{font-size:var(--gc-readable-secondary)}
.conversation-case,.conversation-preview{font-size:var(--gc-readable-secondary)}
.conversation-preview{margin-top:7px;line-height:1.4}
.conversation-empty{padding:32px;font-size:var(--gc-readable-body)}
.thread-empty{padding:48px}
.thread-empty strong{font-size:var(--gc-readable-title)}
.thread-empty p{margin-top:8px;font-size:var(--gc-readable-secondary);line-height:1.5}
.thread-header{min-height:82px;padding:14px 20px}
.thread-person-copy strong{font-size:var(--gc-readable-body)}
.thread-person-copy small,.thread-status{font-size:var(--gc-readable-secondary)}
.thread-status{padding:8px 11px}
.closed-banner{padding:12px 16px;font-size:var(--gc-readable-secondary)}
.timeline{padding:22px 24px}
.message-row{gap:10px;margin:10px 0}
.message-author,.message-author strong,.message-meta{font-size:var(--gc-readable-secondary)}
.message-bubble{padding:12px 15px;font-size:var(--gc-readable-body);line-height:1.55}
.composer{padding:13px 16px 16px}
.thread-files-toggle{min-height:40px;padding:9px 13px;font-size:var(--gc-readable-secondary)}
.composer textarea{height:46px;min-height:46px;padding:11px 14px;font-size:var(--gc-readable-body)}
.compose-note{margin-top:8px;font-size:var(--gc-readable-secondary)}
.toast{padding:12px 15px;font-size:var(--gc-readable-secondary)}
@media(max-width:700px){
    .messages-page{padding:14px}
    .messenger{width:100%;grid-template-columns:1fr}
    .conversation-item{padding:12px 10px}
    .thread-header{padding:12px 14px}
    .timeline{padding:16px 14px}
}
/* Altura de trabajo y desplazamiento independiente por panel. */
.messages-page{
    height:calc(100vh - 96px);
    min-height:0;
    overflow:hidden;
    display:flex;
    flex-direction:column;
    padding:0;
}
.messenger{
    width:100%;
    height:100%;
    min-height:0;
    flex:1 1 auto;
    overflow:hidden;
}
.conversation-pane,
.thread-pane{
    min-height:0;
    overflow:hidden;
}
.conversation-list,
.timeline{
    min-height:0;
    overflow-y:auto;
    overflow-x:hidden;
    overscroll-behavior:contain;
    scrollbar-gutter:stable;
}
.thread-content{
    min-height:0;
    height:100%;
    overflow:hidden;
}
.thread-header,
.closed-banner,
.thread-files-panel,
.composer{
    flex:0 0 auto;
}
.thread-files-panel{
    overflow-y:auto;
}
@media(max-width:700px){
    .messages-page{height:100%;padding:0;}
    .messenger{height:100%;}
    .conversation-pane,
    .thread-pane{height:100%;}
}
/* Densidad compacta de bandeja y orden visual de filtros. */
.conversation-filters{
    display:flex;
    align-items:center;
    flex-wrap:nowrap;
    gap:6px;
}
.conversation-filter[data-filter="abiertos"]{order:1}
.conversation-filter[data-filter="completadas"]{order:2}
.conversation-filter[data-filter="cerrados"]{order:3}
.conversation-filter{
    min-width:0;
    padding:6px 9px;
    white-space:nowrap;
}
.conversation-list{padding:6px}
.conversation-item{
    grid-template-columns:40px minmax(0,1fr);
    gap:8px;
    min-height:64px;
    padding:8px 9px;
    border-radius:10px;
}
.conversation-avatar,
.conversation-avatar img{
    width:40px;
    height:40px;
}
.conversation-state-dot{width:10px;height:10px}
.conversation-line{gap:6px}
.conversation-name{font-size:var(--gc-readable-secondary);line-height:1.25}
.conversation-time{font-size:12px;line-height:1.2}
.conversation-case{
    margin-top:2px;
    font-size:12px;
    line-height:1.25;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}
.conversation-preview{
    max-width:100%;
    margin-top:2px;
    font-size:12px;
    line-height:1.25;
    overflow:hidden;
    text-overflow:ellipsis;
    white-space:nowrap;
}
@media(max-width:700px){
    .conversation-filters{flex-wrap:wrap}
    .conversation-filter{padding:6px 8px}
    .conversation-item{min-height:60px;padding:7px 8px}
}
</style>
</head>
<body>
<main class="messages-page">

    <section class="messenger" id="messenger-app" data-messages-version="2026-08-21.11">
        <aside class="conversation-pane">
            <div class="conversation-toolbar">
                <div class="conversation-toolbar-top">

    <strong>Conversaciones</strong>
                <div style="display:flex;gap:8px;align-items:center"><span class="conversation-count" id="conversation-count" aria-live="polite">0</span><button type="button"id="toggle-conversations"class="toggle-conversations"title="Expandir conversación">◀</button></div>
                </div>
                    <label class="search-wrap">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
                    <input id="conversation-search" type="search" placeholder="Buscar caso o persona" autocomplete="off">
                </label>
                <div class="conversation-filter-section">
                    <div class="conversation-read-filters" role="tablist" aria-label="Filtrar conversaciones por lectura">
                        <button class="conversation-read-filter active" type="button" data-read-filter="todos" aria-pressed="true">Todos</button>
                        <button class="conversation-read-filter" type="button" data-read-filter="no_leidos" aria-pressed="false">No leídos <span class="conversation-read-count" id="unread-filter-count">0</span></button>
                    </div>
                    <div class="conversation-filters" role="tablist" aria-label="Filtrar conversaciones por estado">
                        <button class="conversation-filter" type="button" data-filter="abiertos">Activos</button>
                        <button class="conversation-filter" type="button" data-filter="cerrados">Cerrados</button>
                        <button class="conversation-filter" type="button" data-filter="completadas">Etapas completadas</button>
                    </div>
                </div>
            </div>
            <div class="conversation-list" id="conversation-list" aria-live="polite"></div>
        </aside>

        <section class="thread-pane">
            <div class="thread-empty" id="thread-empty">
                <div>
                    <span class="thread-empty-icon"><svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/></svg></span>
                    <strong>Seleccione un chat</strong>
                    <p>Elija una conversación de la lista para consultar aquí los mensajes, imágenes y archivos del caso.</p>
                </div>
            </div>
            <div class="thread-content" id="thread-content">
                <header class="thread-header"><div class="thread-person"><button class="show-conversations"id="show-conversations"type="button"title="Mostrar conversaciones">☰</button><div id="thread-avatar-wrap"></div><div class="thread-person-copy"><strong id="thread-name">—</strong><small id="thread-subtitle">—</small><small class="thread-presence" id="thread-presence">Sin información de conexión</small></div></div><div class="thread-actions"><button class="thread-files-toggle" id="thread-files-toggle" type="button">Archivos adjuntos · 0</button><div class="thread-status" id="thread-status">Activo</div><a class="thread-case-link" id="thread-case-link" href="#" title="Abrir caso">
                <svg viewBox="0 0 24 24">
                <path d="M14 3h7v7"/>
                <path d="M10 14 21 3"/>
                <path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"/></svg>
                    </a>
                </div>
                </header>
                <div class="closed-banner" id="closed-banner"><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg><span>Este caso está cerrado. La conversación se conserva como historial de solo lectura.</span></div>
                <div class="thread-files-panel" id="thread-files-panel" aria-live="polite"></div>
                <div class="timeline" id="timeline" aria-live="polite"></div>
                <form class="composer" id="composer" enctype="multipart/form-data">
                    <div class="composer-files" id="composer-files"></div>
                    <div class="composer-row">
                        <label class="composer-attach" title="Adjuntar archivo"><input id="composer-file" type="file" name="adjuntos[]" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip"><svg viewBox="0 0 24 24"><path d="m21.4 11.6-8.9 8.9a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.6-8.6"/></svg></label>
                        <textarea id="composer-text" name="mensaje" placeholder="Escriba un mensaje..." maxlength="10000"></textarea>
                        <button class="composer-send" type="submit" title="Enviar"><svg viewBox="0 0 24 24"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg></button>
                    </div>
                    <p class="compose-note">Puede compartir texto, imágenes y documentos relacionados con el caso.</p>
                </form>
            </div>
        </section>
    </section>
</main>
<div class="toast" id="toast" role="status" aria-live="polite"></div>

<script>
(() => {
    const csrf = <?= json_encode($csrf, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
    const initialTicket = <?= (int) $idInicial ?>;
    const initialStage = <?= (int) $idEtapaInicial ?>;
    const currentUser = <?= json_encode([
        'id' => $idUsuario,
        'nombre' => $nombre,
        'rol' => $rol === 2 ? 'Gestor' : 'Solicitante',
        'avatar' => 'imagenPerfil.php?usuario=' . $idUsuario,
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;
    const app = document.getElementById('messenger-app');
    const showConversations = document.getElementById('show-conversations');
if(showConversations){
    showConversations.addEventListener('click',()=>{
        app.classList.remove('hide-conversations');
        const toggle = document.getElementById('toggle-conversations');
        if(toggle){
            toggle.textContent="◀";
            toggle.title="Ocultar conversaciones";
        }
    });
}

const toggleConversations = document.getElementById('toggle-conversations');
if(toggleConversations){
    toggleConversations.addEventListener('click',()=>{
        app.classList.toggle('hide-conversations');
        if(app.classList.contains('hide-conversations')){
            toggleConversations.textContent="⇤";
            toggleConversations.title="Mostrar conversaciones";
        }else{
            toggleConversations.textContent="◀";
            toggleConversations.title="Ocultar conversaciones";
        }
    });
}
    const list = document.getElementById('conversation-list');
    const count = document.getElementById('conversation-count');
    const search = document.getElementById('conversation-search');
    const filters = [...document.querySelectorAll('[data-filter]')];
    const readFilters = [...document.querySelectorAll('[data-read-filter]')];
    const unreadFilterCount = document.getElementById('unread-filter-count');
    const empty = document.getElementById('thread-empty');
    const content = document.getElementById('thread-content');
    const timeline = document.getElementById('timeline');
    const avatarWrap = document.getElementById('thread-avatar-wrap');
    const name = document.getElementById('thread-name');
    const subtitle = document.getElementById('thread-subtitle');
    const presence = document.getElementById('thread-presence');
    const status = document.getElementById('thread-status');
    const caseLink = document.getElementById('thread-case-link');
    const closedBanner = document.getElementById('closed-banner');
    const filesToggle = document.getElementById('thread-files-toggle');
    const filesPanel = document.getElementById('thread-files-panel');
    const composer = document.getElementById('composer');
    const composerText = document.getElementById('composer-text');
    const composerFile = document.getElementById('composer-file');
    const composerFiles = document.getElementById('composer-files');
    const toast = document.getElementById('toast');
    const back = document.getElementById('thread-back');

    let activeTicket = initialTicket || 0;
    let activeStage = initialStage || 0;
    let filter = 'abiertos';
    let readFilter = 'todos';
    let query = '';
    let conversations = [];
    let sending = false;
    let searchTimer = null;
    let threadTimer = null;
    let listTimer = null;
    let refreshingThread = false;
    let refreshingList = false;
    let lastTimelineSignature = '';

    const conversationIsVisible = () =>
        document.visibilityState === 'visible'
        && activeTicket > 0
        && (
            window.matchMedia('(min-width:701px)').matches
            || app.classList.contains('thread-open')
        );

    const api = async (url, options = {}) => {
        const response = await fetch(url, {cache: 'no-store', credentials: 'same-origin', ...options});
        let data = null;
        try { data = await response.json(); } catch (_) {}
        if (!response.ok || !data?.ok) {
            const error = new Error(data?.message || 'No fue posible completar la operación.');
            error.data = data || {};
            throw error;
        }
        return data;
    };

    const showToast = (message, error = false) => {
        toast.textContent = message;
        toast.classList.toggle('error', error);
        toast.classList.add('visible');
        window.setTimeout(() => toast.classList.remove('visible'), 2700);
    };

    const relativeTime = value => {
        if (!value) return '';
        const normalized = value.replace(' ', 'T');
        const date = new Date(normalized);
        if (Number.isNaN(date.getTime())) return '';
        const diff = Date.now() - date.getTime();
        if (diff < 60000) return 'Ahora';
        if (diff < 3600000) return `${Math.floor(diff / 60000)} min`;
        if (diff < 86400000) return date.toLocaleTimeString('es-CO', {hour:'2-digit', minute:'2-digit'});
        return date.toLocaleDateString('es-CO', {day:'2-digit', month:'short'});
    };

    const fullTime = value => {
        if (!value) return '';
        const date = new Date(value.replace(' ', 'T'));
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleString('es-CO', {day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit'});
    };

    const presenceText = current => {
        if (current?.en_linea) return 'En línea';
        if (!current?.ultima_actividad) return 'Última conexión no disponible';
        const date = new Date(current.ultima_actividad.replace(' ', 'T'));
        if (Number.isNaN(date.getTime())) return 'Última conexión no disponible';
        const now = new Date();
        const time = date.toLocaleTimeString('es-CO', {hour:'2-digit', minute:'2-digit'});
        const sameDay = date.getFullYear() === now.getFullYear()
            && date.getMonth() === now.getMonth()
            && date.getDate() === now.getDate();
        if (sameDay) return `Última vez hoy a las ${time}`;
        const yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
        const wasYesterday = date.getFullYear() === yesterday.getFullYear()
            && date.getMonth() === yesterday.getMonth()
            && date.getDate() === yesterday.getDate();
        if (wasYesterday) return `Última vez ayer a las ${time}`;
        return `Última vez el ${date.toLocaleDateString('es-CO', {day:'2-digit', month:'2-digit', year:'numeric'})} a las ${time}`;
    };

    const avatar = (person, cls = '') => {
        if (person?.avatar) {
            const img = document.createElement('img');
            img.src = person.avatar;
            img.alt = `Foto de ${person.nombre || 'usuario'}`;
            if (cls) img.className = cls;
            img.loading = 'lazy';
            return img;
        }
        const fallback = document.createElement('span');
        fallback.className = cls ? `${cls}-fallback` : 'thread-person-fallback';
        fallback.textContent = (person?.nombre || 'MS').split(/\s+/).slice(0,2).map(v => v[0] || '').join('').toUpperCase();
        return fallback;
    };

    const renderList = () => {
        list.replaceChildren();
        count.textContent = String(conversations.length);
        const totalUnread = conversations.reduce(
            (total, item) => total + Math.max(0, Number(item.mensajes_no_leidos) || 0),
            0
        );
        if (unreadFilterCount) {
            unreadFilterCount.textContent = totalUnread > 999 ? '999+' : String(totalUnread);
        }
        if (!conversations.length) {
            const box = document.createElement('div');
            box.className = 'conversation-empty';
            box.textContent = readFilter === 'no_leidos'
                ? 'No hay conversaciones con mensajes sin leer.'
                : (readFilter === 'leidos'
                    ? 'No hay conversaciones leídas.'
                    : (filter === 'cerrados'
                        ? 'No hay conversaciones de casos cerrados.'
                        : (filter === 'completadas'
                            ? 'No hay conversaciones de etapas completadas.'
                            : 'No hay conversaciones activas.')));
            list.append(box);
            return;
        }

        conversations.forEach(item => {
            const button = document.createElement('button');
            button.type = 'button';
            const itemStage = Number(item.id_ticket_etapa) || 0;
            const sameConversation = item.id_ticket === activeTicket
                && (itemStage === activeStage || itemStage === 0);
            const unreadMessages = Math.max(0, Number(item.mensajes_no_leidos) || 0);
            button.className = `conversation-item${item.cerrado ? ' closed' : ''}${sameConversation ? ' active' : ''}${unreadMessages > 0 ? ' has-unread' : ''}`;
            button.dataset.ticket = item.id_ticket;

            const avatarBox = document.createElement('span');
            avatarBox.className = 'conversation-avatar';
            const person = {...item.contraparte, avatar: item.contraparte.id ? `imagenPerfil.php?usuario=${item.contraparte.id}` : ''};
            const image = avatar(person);
            image.className = 'conversation-avatar-image';
            avatarBox.append(image);
            const dot = document.createElement('span');
            const online = Boolean(item.contraparte?.presencia?.en_linea);
            dot.className = `conversation-state-dot${online ? '' : ' offline'}`;
            dot.title = presenceText(item.contraparte?.presencia);
            avatarBox.append(dot);

            const copy = document.createElement('span');
            copy.className = 'conversation-copy';
            const line = document.createElement('span');
            line.className = 'conversation-line';
            const personName = document.createElement('span');
            personName.className = 'conversation-name';
            personName.textContent = item.contraparte.nombre;
            const time = document.createElement('time');
            time.className = 'conversation-time';
            time.textContent = relativeTime(item.ultima_actividad);
            const lineMeta = document.createElement('span');
            lineMeta.className = 'conversation-line-meta';
            lineMeta.append(time);
            if (unreadMessages > 0) {
                const unread = document.createElement('span');
                unread.className = 'conversation-unread-indicator';
                unread.title = unreadMessages === 1
                    ? '1 mensaje nuevo sin leer'
                    : `${unreadMessages} mensajes nuevos sin leer`;
                unread.setAttribute('aria-label', unread.title);
                lineMeta.append(unread);
                const unreadCount = document.createElement('span');
                unreadCount.className = 'conversation-unread-count';
                unreadCount.textContent = unreadMessages > 99 ? '99+' : String(unreadMessages);
                unreadCount.title = unread.title;
                unreadCount.setAttribute('aria-label', unread.title);
                lineMeta.append(unreadCount);
            }
            line.append(personName, lineMeta);
            const caseName = document.createElement('span');
            caseName.className = 'conversation-case';
            caseName.textContent = item.titulo_etapa || `Caso ${item.id_ticket} · ${item.titulo}`;
            const preview = document.createElement('span');
            preview.className = 'conversation-preview';
            preview.textContent = item.cerrado ? `Cerrado · ${item.ultimo_mensaje}` : item.ultimo_mensaje;
            copy.append(line, caseName, preview);
            button.append(avatarBox, copy);
            button.addEventListener('click', () => openThread(item.id_ticket, itemStage, true));
            list.append(button);
        });
    };

    const loadList = async (autoSelect = false) => {
        if (refreshingList) return;
        refreshingList = true;
        try {
            const params = new URLSearchParams({action:'list', filter, read:readFilter});
            if (query) params.set('q', query);
            const data = await api(`mensajesApi.php?${params}`);
            conversations = data.conversaciones || [];
            renderList();

            if (autoSelect && !activeTicket && conversations.length) {
                await openThread(conversations[0].id_ticket, Number(conversations[0].id_ticket_etapa) || 0, false);
            } else if (activeTicket && !conversations.some(item => {
                const itemStage = Number(item.id_ticket_etapa) || 0;
                return item.id_ticket === activeTicket
                    && (itemStage === activeStage || itemStage === 0);
            })) {
                // El caso pudo pasar a cerrado durante la conversación. Se mantiene abierto en pantalla,
                // pero desaparece de la bandeja Activos hasta que el usuario seleccione Cerrados/Todos.
                renderList();
            }
        } catch (error) {
            showToast(error.message, true);
        } finally {
            refreshingList = false;
        }
    };

    const createMessage = event => {
        const row = document.createElement('div');
        row.className = `message-row${event.propio ? ' mine' : ''}${event.pendiente ? ' pending' : ''}`;
        if (event.id_temporal) row.dataset.pendingId = event.id_temporal;

        const person = {nombre:event.autor, avatar:event.avatar};
        const image = avatar(person);
        image.className = 'message-avatar';

        const stack = document.createElement('div');
        stack.className = 'message-stack';
        const author = document.createElement('div');
        author.className = 'message-author';
        const strong = document.createElement('strong');
        strong.textContent = event.autor;
        const role = document.createElement('span');
        role.textContent = event.autor_rol;
        author.append(strong, role);

        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        if (event.tipo === 'mensaje') {
            bubble.textContent = event.mensaje;
        } else {
            const link = document.createElement('a');
            link.className = 'attachment-card';
            link.href = event.url;
            link.target = '_blank';
            link.rel = 'noopener';
            if (event.preview) {
                const preview = document.createElement('img');
                preview.className = 'attachment-preview';
                preview.src = event.preview;
                preview.alt = event.nombre;
                preview.loading = 'lazy';
                link.append(preview);
            } else {
                const file = document.createElement('span');
                file.className = 'attachment-file';
                const icon = document.createElement('span');
                icon.className = 'attachment-icon';
                icon.textContent = 'DOC';
                const copy = document.createElement('span');
                copy.className = 'attachment-copy';
                const n = document.createElement('strong');
                n.textContent = event.nombre;
                const s = document.createElement('small');
                s.textContent = event.mime || 'Archivo';
                copy.append(n,s);
                const down = document.createElement('span');
                down.className = 'attachment-download';
                down.textContent = '↓';
                file.append(icon,copy,down);
                link.append(file);
            }
            bubble.append(link);
        }

        const meta = document.createElement('div');
        meta.className = 'message-meta';
        const stage = document.createElement('span');
        stage.className = 'message-stage';
        stage.textContent = event.etapa || '';
        const time = document.createElement('time');
        time.textContent = fullTime(event.creado_en);
        meta.append(stage,time);
        if (event.propio && event.tipo === 'mensaje') {
            const state = event.estado_envio || 'enviado';
            const receipt = document.createElement('span');
            receipt.className = `message-receipt${state === 'leido' ? ' read' : ''}`;
            receipt.textContent = state === 'pendiente'
                ? '◷'
                : (state === 'enviado' ? '✓' : '✓✓');
            receipt.title = state === 'pendiente'
                ? 'Enviando'
                : (state === 'leido'
                    ? 'Leído'
                    : (state === 'entregado' ? 'Entregado' : 'Enviado'));
            receipt.setAttribute('aria-label', receipt.title);
            meta.append(receipt);
        }
        stack.append(author,bubble,meta);
        row.append(image,stack);
        return row;
    };

    const renderThread = hilo => {
        empty.style.display = 'none';
        content.classList.add('visible');

        const person = hilo.contraparte || {};
        avatarWrap.replaceChildren(avatar(person));
        name.textContent = person.nombre || 'Mesa de Servicio';
        subtitle.textContent = hilo.ticket.titulo_etapa || `${person.rol || 'Usuario'} · Caso ${hilo.ticket.id_ticket} · ${hilo.ticket.titulo}`;
        presence.textContent = presenceText(person.presencia);
        presence.classList.toggle('online', Boolean(person.presencia?.en_linea));
        status.textContent = hilo.ticket.estado || (hilo.ticket.cerrado ? 'Cerrado' : 'Activo');
        status.classList.toggle('closed', Boolean(hilo.ticket.cerrado));
        caseLink.href = hilo.ticket.url_caso || '#';
        closedBanner.classList.toggle('visible', Boolean(hilo.ticket.cerrado));
        const bannerText = closedBanner.querySelector('span');
        if (bannerText) bannerText.textContent = hilo.ticket.solo_lectura
            ? 'Esta etapa ya fue completada. Su conversación permanece disponible en modo de solo lectura.'
            : 'Este caso está cerrado. La conversación se conserva como historial de solo lectura.';
        composer.classList.toggle('disabled', !hilo.ticket.puede_escribir);
        renderFiles(hilo.adjuntos || []);

        const events = hilo.eventos || [];
        const threadKey = `${hilo.ticket.id_ticket}:${activeStage}`;
        const timelineSignature = `${threadKey}|${events.map(event =>
            `${event.tipo}:${event.id_evento}:${event.estado_envio || ''}`
        ).join('|')}`;

        if (timelineSignature !== lastTimelineSignature) {
            const sameThread = timeline.dataset.threadKey === threadKey;
            const previousScrollTop = timeline.scrollTop;
            const nearBottom = !sameThread
                || timeline.scrollHeight - timeline.scrollTop - timeline.clientHeight < 100;

            timeline.replaceChildren();
            if (!events.length) {
                const box = document.createElement('div');
                box.className = 'timeline-empty';
                box.textContent = hilo.ticket.cerrado
                    ? 'El caso está cerrado y no registra mensajes.'
                    : 'Todavía no hay mensajes. Puede iniciar la conversación.';
                timeline.append(box);
            } else {
                events.forEach(event => timeline.append(createMessage(event)));
            }

            timeline.dataset.threadKey = threadKey;
            lastTimelineSignature = timelineSignature;
            requestAnimationFrame(() => {
                timeline.scrollTop = nearBottom
                    ? timeline.scrollHeight
                    : previousScrollTop;
            });
        }
    };

    const showEmptyThread = () => {
        activeTicket = 0;
        activeStage = 0;
        lastTimelineSignature = '';
        content.classList.remove('visible');
        empty.style.display = '';
        app.classList.remove('thread-open');
        filesPanel.classList.remove('visible');
        timeline.replaceChildren();
        renderList();
        if (window.top === window.self) {
            const url = new URL(location.href);
            url.searchParams.delete('id_ticket');
            url.searchParams.delete('id_ticket_etapa');
            history.replaceState({}, '', url);
        }
    };

    const renderFiles = attachments => {
        filesToggle.textContent = `Archivos adjuntos · ${attachments.length}`;
        filesPanel.replaceChildren();
        if (!attachments.length) {
            const emptyFiles = document.createElement('div');
            emptyFiles.className = 'thread-files-empty';
            emptyFiles.textContent = 'Esta conversación no tiene archivos adjuntos.';
            filesPanel.append(emptyFiles);
            return;
        }
        const grid = document.createElement('div');
        grid.className = 'thread-files-grid';
        attachments.forEach(file => {
            const link = document.createElement('a');
            link.className = 'thread-file-item';
            link.href = file.url;
            const icon = document.createElement('span');
            icon.className = 'thread-file-icon';
            icon.textContent = file.preview ? 'IMG' : 'DOC';
            const copy = document.createElement('span');
            const strong = document.createElement('strong');
            strong.textContent = file.nombre || 'Archivo';
            const small = document.createElement('small');
            small.textContent = `${file.etapa || 'Conversación'} · ${fullTime(file.creado_en)}`;
            copy.append(strong, small);
            const down = document.createElement('span');
            down.textContent = '↓';
            link.append(icon, copy, down);
            grid.append(link);
        });
        filesPanel.append(grid);
    };

    filesToggle.addEventListener('click', () => {
        filesPanel.classList.toggle('visible');
    });

    const openThread = async (idTicket, idStage = 0, updateUrl = true) => {
        activeTicket = Number(idTicket) || 0;
        activeStage = Number(idStage) || 0;
        if (!activeTicket) return;
        app.classList.add('thread-open');
        renderList();
        if (updateUrl && window.top === window.self) {
            const url = new URL(location.href);
            url.searchParams.set('id_ticket', String(activeTicket));
            if (activeStage) url.searchParams.set('id_ticket_etapa', String(activeStage));
            else url.searchParams.delete('id_ticket_etapa');
            history.replaceState({}, '', url);
        }
        try {
            const markRead = conversationIsVisible() ? '1' : '0';
            const data = await api(`mensajesApi.php?action=thread&id_ticket=${encodeURIComponent(activeTicket)}&id_ticket_etapa=${encodeURIComponent(activeStage)}&mark_read=${markRead}`);
            renderThread(data.hilo);
            if (markRead === '1') {
                conversations.forEach(item => {
                    const itemStage = Number(item.id_ticket_etapa) || 0;
                    if (item.id_ticket === activeTicket && (itemStage === activeStage || itemStage === 0)) {
                        item.mensajes_no_leidos = 0;
                    }
                });
                renderList();
            }
        } catch (error) {
            showToast(error.message, true);
            if (error.data?.closed) await refreshThread();
        }
    };

    const refreshThread = async () => {
        if (
            document.visibilityState !== 'visible'
            || !activeTicket
            || sending
            || refreshingThread
        ) return;
        refreshingThread = true;
        try {
            const markRead = conversationIsVisible() ? '1' : '0';
            const data = await api(`mensajesApi.php?action=thread&id_ticket=${encodeURIComponent(activeTicket)}&id_ticket_etapa=${encodeURIComponent(activeStage)}&mark_read=${markRead}&_=${Date.now()}`);
            renderThread(data.hilo);
        } catch (_) {
        } finally {
            refreshingThread = false;
        }
    };

    window.addEventListener('focus', refreshThread);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
            void refreshThread();
            void loadList(false);
        }
    });

    filters.forEach(button => button.addEventListener('click', async () => {
        filters.forEach(item => item.classList.remove('active'));
        button.classList.add('active');
        filter = button.dataset.filter || 'abiertos';
        showEmptyThread();
        await loadList(false);
    }));

    readFilters.forEach(button => button.addEventListener('click', async () => {
        readFilter = button.dataset.readFilter || 'todos';
        readFilters.forEach(item => {
            const isActive = item.dataset.readFilter === readFilter;
            item.classList.toggle('active', isActive);
            item.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        });
        showEmptyThread();
        await loadList(false);
    }));

    search.addEventListener('input', () => {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(async () => {
            query = search.value.trim();
            await loadList(false);
        }, 240);
    });

    composerFile.addEventListener('change', () => {
        composerFiles.replaceChildren();
        [...composerFile.files].slice(0,5).forEach(file => {
            const chip = document.createElement('span');
            chip.className = 'file-chip';
            chip.textContent = file.name;
            composerFiles.append(chip);
        });
        composerFiles.classList.toggle('visible', composerFile.files.length > 0);
    });

    composerText.addEventListener('input', () => {
        composerText.style.height = '39px';
        composerText.style.height = `${Math.min(composerText.scrollHeight,110)}px`;
    });

    composerText.addEventListener('keydown', event => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            composer.requestSubmit();
        }
    });

    composer.addEventListener('submit', async event => {
        event.preventDefault();
        if (!activeTicket || sending) return;
        if (!composerText.value.trim() && !composerFile.files.length) return;
        if (composerFile.files.length > 5) {
            showToast('Puede adjuntar máximo cinco archivos.', true);
            return;
        }
        sending = true;
        const messageText = composerText.value.trim();
        const selectedFiles = [...composerFile.files];
        const pendingId = `pending-${Date.now()}-${Math.random().toString(16).slice(2)}`;
        const optimisticText = messageText || (selectedFiles.length === 1
            ? `Enviando ${selectedFiles[0].name}…`
            : `Enviando ${selectedFiles.length} archivos…`);
        const pendingRow = createMessage({
            tipo: 'mensaje',
            id_temporal: pendingId,
            propio: true,
            pendiente: true,
            autor: currentUser.nombre,
            autor_rol: currentUser.rol,
            avatar: currentUser.avatar,
            mensaje: optimisticText,
            etapa: 'Enviando…',
            creado_en: new Date().toISOString(),
            estado_envio: 'pendiente',
        });
        const emptyTimeline = timeline.querySelector('.timeline-empty');
        if (emptyTimeline) emptyTimeline.remove();
        timeline.append(pendingRow);
        requestAnimationFrame(() => { timeline.scrollTop = timeline.scrollHeight; });
        composerText.value = '';
        composerText.style.height = '39px';
        const form = new FormData();
        form.append('action','send');
        form.append('csrf_token',csrf);
        form.append('id_ticket',String(activeTicket));
        form.append('mensaje',messageText);
        selectedFiles.forEach(file => form.append('adjuntos[]',file));
        try {
            await api('mensajesApi.php', {method:'POST',body:form});
            const receipt = pendingRow.querySelector('.message-receipt');
            if (receipt) {
                receipt.textContent = '✓';
                receipt.title = 'Enviado';
                receipt.setAttribute('aria-label', 'Enviado');
            }
            pendingRow.classList.remove('pending');
            composerFile.value = '';
            composerFiles.replaceChildren();
            composerFiles.classList.remove('visible');
            sending = false;
            await refreshThread();
            void loadList(false);
        } catch (error) {
            pendingRow.remove();
            if (!composerText.value) {
                composerText.value = messageText;
                composerText.dispatchEvent(new Event('input'));
            }
            showToast(error.message, true);
            if (error.data?.closed) await refreshThread();
        } finally {
            sending = false;
        }
    });
    if(back){
        back.addEventListener('click', () => app.classList.remove('thread-open'));
    }
    
    (async () => {

    // sincronizar filtro visual
    filters.forEach(button => {

        button.classList.toggle(
            'active',
            button.dataset.filter === filter
        );

    });


    // cargar conversaciones iniciales
    await loadList(false);

    if(initialTicket){
        await openThread(initialTicket,initialStage,false);
    }


    threadTimer = setInterval(refreshThread,1500);


    listTimer = setInterval(()=>{
        if (document.visibilityState === 'visible') loadList(false);
    },5000);

    window.addEventListener('pagehide',()=>{
        clearInterval(threadTimer);
        clearInterval(listTimer);
    },{once:true});

})();

})();
</script>
</body>
</html>
