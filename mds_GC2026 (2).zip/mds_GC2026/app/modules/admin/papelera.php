<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/papelera.php';
seguridadExigirRol([1]);

$idPaisOperacion = paisExigirContexto();
$idAdministrador = (int) ($_SESSION['usuario_id'] ?? 0);

function escaparPapelera($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function redirigirPapelera(string $mensaje): void
{
    header('Location: papelera.php?msg=' . rawurlencode($mensaje), true, 303);
    exit;
}

function papeleraEliminarConfiguracion(
    mysqli $conn,
    int $idOpcion,
    string $tipo,
    int $idPaisOperacion
): void {
    if ($tipo === 'clasificacion') {
        $stmt = $conn->prepare('DELETE FROM configuraciones_servicio WHERE id_opcion = ? AND tipo = ? AND id_pais_operacion = ?');
        $stmt->bind_param('isi', $idOpcion, $tipo, $idPaisOperacion);
        $stmt->execute();
        $stmt->close();
        return;
    }

    $columnas = [
        'pais' => 'id_pais',
        'departamento' => 'id_departamento',
        'ciudad' => 'id_ciudad',
        'prioridad' => 'id_prioridad',
        'urgencia' => 'id_urgencia',
        'nivel' => 'id_nivel',
        'impacto' => 'id_impacto',
        'estado' => 'id_estado',
    ];

    if (!isset($columnas[$tipo])) {
        throw new RuntimeException('Este tipo de registro no admite eliminación definitiva.');
    }

    if ($tipo === 'pais') {
        $stmt = $conn->prepare("UPDATE usuarios SET id_pais = NULL, id_departamento = NULL, id_ciudad = NULL, ciudad = 'Sin asignar' WHERE id_pais = ? AND id_pais_operacion = ?");
        $stmt->bind_param('ii', $idOpcion, $idPaisOperacion);
        $stmt->execute();
        $stmt->close();
    } elseif ($tipo === 'departamento') {
        $stmt = $conn->prepare("UPDATE usuarios SET id_departamento = NULL, id_ciudad = NULL, ciudad = 'Sin asignar' WHERE id_departamento = ? AND id_pais_operacion = ?");
        $stmt->bind_param('ii', $idOpcion, $idPaisOperacion);
        $stmt->execute();
        $stmt->close();
    } elseif ($tipo === 'ciudad') {
        $stmt = $conn->prepare("UPDATE usuarios SET id_ciudad = NULL, ciudad = 'Sin asignar' WHERE id_ciudad = ? AND id_pais_operacion = ?");
        $stmt->bind_param('ii', $idOpcion, $idPaisOperacion);
        $stmt->execute();
        $stmt->close();
    }

    $columna = $columnas[$tipo];
    $stmt = $conn->prepare("UPDATE servicios SET `{$columna}` = NULL WHERE `{$columna}` = ? AND id_pais_operacion = ?");
    $stmt->bind_param('ii', $idOpcion, $idPaisOperacion);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare('UPDATE configuraciones_servicio SET id_padre = NULL WHERE id_padre = ? AND id_pais_operacion = ?');
    $stmt->bind_param('ii', $idOpcion, $idPaisOperacion);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare('DELETE FROM configuraciones_servicio WHERE id_opcion = ? AND tipo = ? AND id_pais_operacion = ?');
    $stmt->bind_param('isi', $idOpcion, $tipo, $idPaisOperacion);
    $stmt->execute();
    $stmt->close();
}

function papeleraEliminarCatalogo(mysqli $conn, int $idCatalogo, int $idPaisOperacion): void
{
    $consultas = [
        "DELETE ss FROM soluciones_servicio AS ss INNER JOIN servicios AS s ON s.id_servicio = ss.id_servicio WHERE s.id_catalogo = ? AND s.id_pais_operacion = ?",
        "DELETE pe FROM proceso_etapas AS pe INNER JOIN servicios AS s ON s.id_servicio = pe.id_servicio WHERE s.id_catalogo = ? AND s.id_pais_operacion = ?",
        'DELETE FROM servicios WHERE id_catalogo = ? AND id_pais_operacion = ?',
        'DELETE FROM catalogos WHERE id_catalogo = ? AND id_pais_operacion = ?',
    ];

    foreach ($consultas as $consulta) {
        $stmt = $conn->prepare($consulta);
        $stmt->bind_param('ii', $idCatalogo, $idPaisOperacion);
        $stmt->execute();
        $stmt->close();
    }
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    seguridadExigirOrigenPost();
    seguridadExigirCsrfPost();
    $accion = (string) ($_POST['accion'] ?? '');
    $idPapelera = filter_input(INPUT_POST, 'id_papelera', FILTER_VALIDATE_INT) ?: 0;

    if ($idPapelera < 1 || !in_array($accion, ['restaurar', 'eliminar_definitivo'], true)) {
        redirigirPapelera('solicitud_invalida');
    }

    try {
        $stmt = $conn->prepare('SELECT * FROM papelera WHERE id_papelera = ? AND id_pais_operacion = ? LIMIT 1');
        $stmt->bind_param('ii', $idPapelera, $idPaisOperacion);
        $stmt->execute();
        $registro = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$registro) {
            redirigirPapelera('no_encontrado');
        }

        $tipo = (string) $registro['tipo'];
        $idRegistro = (int) $registro['id_registro'];
        $datos = papeleraDecodificar((string) $registro['datos']);
        $estadoAnterior = in_array(($datos['estado'] ?? ''), ['activo', 'inhabilitado'], true)
            ? (string) $datos['estado']
            : 'activo';

        $conn->begin_transaction();

        if ($accion === 'restaurar') {
            if ($tipo === 'sla') {
                $stmt = $conn->prepare('UPDATE sla SET estado = ? WHERE id_sla = ? AND id_pais_operacion = ?');
                $stmt->bind_param('sii', $estadoAnterior, $idRegistro, $idPaisOperacion);
            } elseif ($tipo === 'feriado') {
                $stmt = $conn->prepare('UPDATE feriados SET estado = ? WHERE id_feriado = ? AND id_pais_operacion = ?');
                $stmt->bind_param('sii', $estadoAnterior, $idRegistro, $idPaisOperacion);
            } elseif ($tipo === 'configuracion') {
                $stmt = $conn->prepare('UPDATE configuraciones_servicio SET estado_registro = ? WHERE id_opcion = ? AND id_pais_operacion = ?');
                $stmt->bind_param('sii', $estadoAnterior, $idRegistro, $idPaisOperacion);
            } elseif ($tipo === 'catalogo') {
                $stmt = $conn->prepare('UPDATE catalogos SET estado = ? WHERE id_catalogo = ? AND id_pais_operacion = ?');
                $stmt->bind_param('sii', $estadoAnterior, $idRegistro, $idPaisOperacion);
            } else {
                throw new RuntimeException('El tipo de registro no admite restauración.');
            }
            $stmt->execute();
            $stmt->close();
        } else {
            if ($tipo === 'sla') {
                $stmtUso = $conn->prepare('SELECT COUNT(*) FROM servicios WHERE id_sla = ? AND id_pais_operacion = ?');
                $stmtUso->bind_param('ii', $idRegistro, $idPaisOperacion);
                $stmtUso->execute();
                $stmtUso->bind_result($totalUso);
                $stmtUso->fetch();
                $stmtUso->close();
                if ((int) $totalUso > 0) {
                    throw new RuntimeException('El SLA sigue asignado a servicios y no se puede eliminar definitivamente.');
                }
                $stmt = $conn->prepare('DELETE FROM sla WHERE id_sla = ? AND id_pais_operacion = ?');
                $stmt->bind_param('ii', $idRegistro, $idPaisOperacion);
                $stmt->execute();
                $stmt->close();
            } elseif ($tipo === 'feriado') {
                $stmt = $conn->prepare('DELETE FROM feriados WHERE id_feriado = ? AND id_pais_operacion = ?');
                $stmt->bind_param('ii', $idRegistro, $idPaisOperacion);
                $stmt->execute();
                $stmt->close();
            } elseif ($tipo === 'configuracion') {
                papeleraEliminarConfiguracion($conn, $idRegistro, (string) ($datos['tipo'] ?? ''), $idPaisOperacion);
            } elseif ($tipo === 'catalogo') {
                papeleraEliminarCatalogo($conn, $idRegistro, $idPaisOperacion);
            } else {
                throw new RuntimeException('El tipo de registro no admite eliminación definitiva.');
            }
        }

        $stmt = $conn->prepare('DELETE FROM papelera WHERE id_papelera = ? AND id_pais_operacion = ?');
        $stmt->bind_param('ii', $idPapelera, $idPaisOperacion);
        $stmt->execute();
        $stmt->close();
        $conn->commit();
        redirigirPapelera($accion === 'restaurar' ? 'restaurado' : 'eliminado');
    } catch (Throwable $e) {
        try { $conn->rollback(); } catch (Throwable $ignorado) {}
        error_log('Papelera: ' . $e->getMessage());
        $_SESSION['papelera_error'] = $e->getMessage();
        redirigirPapelera('error');
    }
}

$registros = [];
$instalada = papeleraDisponible($conn);
if ($instalada) {
    $stmt = $conn->prepare(
        "SELECT p.*, COALESCE(u.nombre, 'Usuario no disponible') AS eliminado_por_nombre
         FROM papelera AS p
         LEFT JOIN usuarios AS u ON u.id_usuario = p.eliminado_por
         WHERE p.id_pais_operacion = ?
         ORDER BY p.eliminado_en DESC, p.id_papelera DESC"
    );
    $stmt->bind_param('i', $idPaisOperacion);
    $stmt->execute();
    $registros = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

$mensajes = [
    'restaurado' => ['ok', 'El elemento fue restaurado correctamente.'],
    'eliminado' => ['ok', 'El elemento fue eliminado definitivamente.'],
    'no_encontrado' => ['error', 'El elemento ya no se encuentra en la papelera.'],
    'solicitud_invalida' => ['error', 'La operación solicitada no es válida.'],
    'error' => ['error', (string) (seguridadConsumirDatoSesion('papelera_error') ?? 'No fue posible completar la operación.')],
];
$mensaje = $mensajes[(string) ($_GET['msg'] ?? '')] ?? null;
$tipos = ['sla' => 'SLA', 'feriado' => 'Feriado', 'configuracion' => 'Configuración', 'catalogo' => 'Área'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Papelera | Mesa de Servicio</title>
    <style>
        :root{--primary:#0f6fec;--navy:#102a43;--text:#243b53;--muted:#627d98;--border:#d9e2ec;--bg:#f3f6fb;--danger:#c62832;--success:#15803d}*{box-sizing:border-box}body{margin:0;color:var(--text);background:var(--bg);font:13px/1.45 Inter,"Segoe UI",Arial,sans-serif}.shell{width:min(1280px,calc(100% - 28px));margin:16px auto}.top,.panel{border:1px solid var(--border);border-radius:14px;background:#fff;box-shadow:0 8px 24px rgba(16,42,67,.06)}.top{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:14px;padding:16px 18px}.title{display:flex;align-items:center;gap:12px}.trash-mark{width:42px;height:42px;display:grid;place-items:center;border-radius:11px;color:#fff;background:var(--primary)}h1,h2,p{margin:0}h1{color:var(--navy);font-size:22px}.top p,.panel-head p{color:var(--muted);font-size:11px}.back{padding:9px 12px;border:1px solid var(--border);border-radius:9px;color:var(--navy);text-decoration:none;font-weight:800}.alert{margin-bottom:12px;padding:10px 13px;border-radius:9px;font-weight:750}.alert.ok{color:var(--success);background:#eaf8ef}.alert.error{color:var(--danger);background:#fff0f1}.panel{overflow:hidden}.panel-head{display:flex;align-items:center;justify-content:space-between;padding:15px 18px;border-bottom:1px solid var(--border)}.panel-head h2{font-size:17px}.count{font-weight:850}.table-wrap{overflow:auto}table{width:100%;min-width:850px;border-collapse:collapse}th,td{padding:12px 14px;border-bottom:1px solid #e8eef5;text-align:left}th{position:sticky;top:0;z-index:2;color:#526d82;background:#f7f9fc;font-size:10px;text-transform:uppercase}.actions{display:flex;gap:8px}.icon-btn{width:36px;height:36px;display:grid;place-items:center;border:0;border-radius:9px;color:#fff;cursor:pointer}.restore{background:var(--success)}.delete{background:var(--danger)}.icon-btn svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2}.empty{padding:34px;color:var(--muted);text-align:center}@media(max-width:700px){.top{align-items:flex-start;flex-direction:column}.shell{width:calc(100% - 14px)}}
    </style>
</head>
<body>
<main class="shell">
    <header class="top"><div class="title"><span class="trash-mark">♻</span><div><h1>Papelera</h1><p>Restaure elementos eliminados por error o elimínelos definitivamente.</p></div></div><a class="back" href="panelAdmin.php">← Volver</a></header>
    <?php if (!$instalada): ?><div class="alert error">Importe primero <strong>migracion_papelera.sql</strong>.</div><?php endif; ?>
    <?php if ($mensaje): ?><div class="alert <?= escaparPapelera($mensaje[0]) ?>"><?= escaparPapelera($mensaje[1]) ?></div><?php endif; ?>
    <section class="panel"><div class="panel-head"><div><h2>Elementos eliminados</h2><p>La restauración conserva las relaciones originales.</p></div><span class="count"><?= count($registros) ?></span></div>
    <?php if (!$registros): ?><div class="empty">La papelera está vacía.</div><?php else: ?><div class="table-wrap"><table><thead><tr><th>Tipo</th><th>Elemento</th><th>Eliminado por</th><th>Fecha y hora</th><th>Restaurar</th><th>Eliminar definitivamente</th></tr></thead><tbody>
    <?php foreach ($registros as $registro): ?><tr><td><?= escaparPapelera($tipos[$registro['tipo']] ?? ucfirst((string) $registro['tipo'])) ?></td><td><strong><?= escaparPapelera($registro['nombre']) ?></strong></td><td><?= escaparPapelera($registro['eliminado_por_nombre']) ?></td><td><?= escaparPapelera(date('d/m/Y H:i', strtotime((string) $registro['eliminado_en']))) ?></td><td><form method="post"><input type="hidden" name="csrf_token" value="<?= escaparPapelera(seguridadTokenCsrf()) ?>"><input type="hidden" name="accion" value="restaurar"><input type="hidden" name="id_papelera" value="<?= (int) $registro['id_papelera'] ?>"><button class="icon-btn restore" title="Restaurar" aria-label="Restaurar <?= escaparPapelera($registro['nombre']) ?>"><svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg></button></form></td><td><form method="post" onsubmit="return confirm('Esta acción no se puede deshacer. ¿Eliminar definitivamente?')"><input type="hidden" name="csrf_token" value="<?= escaparPapelera(seguridadTokenCsrf()) ?>"><input type="hidden" name="accion" value="eliminar_definitivo"><input type="hidden" name="id_papelera" value="<?= (int) $registro['id_papelera'] ?>"><button class="icon-btn delete" title="Eliminar definitivamente" aria-label="Eliminar definitivamente <?= escaparPapelera($registro['nombre']) ?>"><svg viewBox="0 0 24 24"><path d="M3 6h18M8 6V4h8v2M6 6l1 15h10l1-15M10 10v7M14 10v7"/></svg></button></form></td></tr><?php endforeach; ?>
    </tbody></table></div><?php endif; ?></section>
</main>
<script src="assets/js/controlSesion.js" defer></script>
</body>
</html>
