<?php
declare(strict_types=1);

define('MESA_OMITIR_ACTIVIDAD_SESION', true);
require_once APP_ROOT . '/security/validarSesion.php';
seguridadExigirRol([1, 2]);

seguridadAplicarCabeceras(true);
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$sesiones = [];
$rolSesion = (int) ($_SESSION['rol'] ?? 0);
$idUsuarioSesion = (int) ($_SESSION['usuario_id'] ?? 0);
$filtroGestor = $rolSesion === 2 ? 'WHERE s.id_usuario = ' . $idUsuarioSesion : '';
$resultado = $conn->query(
    "SELECT
        s.id_sesion, s.id_usuario, s.direccion_ip, s.tipo_dispositivo,
        s.sistema_operativo, s.navegador, s.inicio_en,
        s.ultima_actividad_en, s.cerrada_en, s.motivo_cierre,
        u.nombre, u.email, u.id_rol,
        COALESCE(r.nombre_rol,
            CASE u.id_rol WHEN 1 THEN 'Administrador' WHEN 2 THEN 'Gestor'
                WHEN 3 THEN 'Solicitante' ELSE 'Sin rol' END
        ) AS rol,
        COALESCE(
            operaciones.paises,
            CASE WHEN u.id_rol IN (2, 3) THEN pais_usuario.nombre END,
            'Sin operación registrada'
        ) AS paises,
        COALESCE(
            operaciones.codigos,
            CASE WHEN u.id_rol IN (2, 3) THEN pais_usuario.codigo END,
            ''
        ) AS pais_codigos,
        CASE WHEN s.cerrada_en IS NULL
                  AND s.ultima_actividad_en >= DATE_SUB(NOW(), INTERVAL 90 SECOND)
             THEN 1 ELSE 0 END AS activa
     FROM sesiones_usuario AS s
     INNER JOIN usuarios AS u ON u.id_usuario = s.id_usuario
     LEFT JOIN roles AS r ON r.id_rol = u.id_rol
     LEFT JOIN paises_operacion AS pais_usuario
        ON pais_usuario.id_pais_operacion = u.id_pais_operacion
     LEFT JOIN (
        SELECT
            sup.id_sesion,
            GROUP_CONCAT(
                DISTINCT po.nombre ORDER BY po.id_pais_operacion SEPARATOR ' y '
            ) AS paises,
            GROUP_CONCAT(
                DISTINCT po.codigo ORDER BY po.id_pais_operacion SEPARATOR ','
            ) AS codigos
        FROM sesiones_usuario_paises AS sup
        INNER JOIN paises_operacion AS po
            ON po.id_pais_operacion = sup.id_pais_operacion
        GROUP BY sup.id_sesion
    ) AS operaciones ON operaciones.id_sesion = s.id_sesion
    {$filtroGestor}
     ORDER BY activa DESC, s.ultima_actividad_en DESC, s.id_sesion DESC
     LIMIT 300"
);
if ($resultado !== false) {
    $sesiones = $resultado->fetch_all(MYSQLI_ASSOC);
}

$idSesion = filter_input(INPUT_GET, 'id_sesion', FILTER_VALIDATE_INT) ?: 0;
$auditoria = [];
if ($idSesion > 0) {
    $stmt = $conn->prepare(
        "SELECT id_auditoria, modulo, accion, detalle, direccion_ip,
                estado_http, fecha_hora
         FROM auditoria_sesiones
                 WHERE id_sesion = ?
                     AND (? = 1 OR id_usuario = ?)
         ORDER BY fecha_hora DESC, id_auditoria DESC
         LIMIT 150"
    );
    $esAdministrador = $rolSesion === 1 ? 1 : 0;
    $stmt->bind_param('iii', $idSesion, $esAdministrador, $idUsuarioSesion);
    $stmt->execute();
    $auditoria = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

$activas = 0;
foreach ($sesiones as $sesion) {
    $activas += (int) $sesion['activa'];
}

echo json_encode([
    'ok' => true,
    'generado_en' => date('Y-m-d H:i:s'),
    'resumen' => [
        'activas' => $activas,
        'cerradas' => count($sesiones) - $activas,
        'total' => count($sesiones),
    ],
    'sesiones' => $sesiones,
    'auditoria' => $auditoria,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
