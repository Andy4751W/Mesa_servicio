Auditoría rápida: uso de $conn->query()

Resumen

Se detectaron múltiples usos de llamadas directas a $conn->query(...) en el código. Muchas de estas llamadas son perfectamente válidas (consultas estáticas, "SHOW TABLES", SELECT sin variables), pero hay que comprobar cada una para confirmar que no concatenan entrada de usuario sin escape.

Objetivo

Proveer una lista priorizada de archivos que contienen invocaciones a $conn->query para facilitar una revisión manual y la conversión a prepared statements cuando sea necesario.

Encontrado (extracto)

- [scripts/migrarArchivosPrivados.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/scripts/migrarArchivosPrivados.php)
- [app/modules/tickets/solicitudes.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/tickets/solicitudes.php)
- [app/modules/tickets/procesos.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/tickets/procesos.php)
- [app/modules/tickets/panelSolicitante.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/tickets/panelSolicitante.php)
- [app/modules/tickets/panelGestor.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/tickets/panelGestor.php)
- [app/modules/tickets/flujoTicket.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/tickets/flujoTicket.php)
- [app/modules/tickets/descargarSolicitudesExcel.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/tickets/descargarSolicitudesExcel.php)
- [app/modules/reportes/indicadores.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/reportes/indicadores.php)
- [app/modules/tickets/asignarTicket.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/tickets/asignarTicket.php)
- [app/modules/tickets/actualizarTicket.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/tickets/actualizarTicket.php)
- [app/modules/sla/verificarCalendarioSla.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/sla/verificarCalendarioSla.php)
- [app/modules/sla/sla.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/sla/sla.php)
- [app/modules/sla/feriados.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/sla/feriados.php)
- [app/modules/sistema/verificarFlujos.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/sistema/verificarFlujos.php)
- [app/modules/admin/diagnostico_relaciones.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/admin/diagnostico_relaciones.php)
- [app/modules/admin/crearUsuarios.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/admin/crearUsuarios.php)
- [app/modules/admin/configuraciones.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/admin/configuraciones.php)
- [app/core/recuperacionPassword.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/core/recuperacionPassword.php)
- [app/core/pais.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/core/pais.php)
- [app/core/motorFlujos.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/core/motorFlujos.php)
- [app/core/calendarioLaboral.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/core/calendarioLaboral.php)
- [app/core/automatizacionTickets.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/core/automatizacionTickets.php)
- [app/modules/catalogos/soluciones.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/catalogos/soluciones.php)
- [app/modules/catalogos/servicios.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/catalogos/servicios.php)
- [app/modules/catalogos/editarcatalogos.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/catalogos/editarcatalogos.php)
- [app/modules/catalogos/catalogos.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/catalogos/catalogos.php)
- [app/modules/auth/login.php](C:/xampp/htdocs/mesa_servicio.worktrees/deep-project-review/app/modules/auth/login.php)

Siguiente paso sugerido

1. Revisar manualmente cada archivo listado y buscar concatenaciones de variables en la cadena SQL. Criterio: si la consulta contiene variables (".", interpolation o sprintf) que provienen de entrada del usuario, convertirla a prepared statement con bind_param.
2. Priorizar review en endpoints públicos y en código que procesa datos de usuarios (tickets, uploads, login, paneles, exportaciones).
3. Añadir pruebas unitarias o de integración para los puntos corregidos.

Comandos útiles localmente

- Para obtener todos los matches y ver líneas de contexto:
  rg "\\$conn->query\(" -n app/ public/ scripts/ || findstr /s /n /c:"$conn->query(" app\* public\* scripts\*

- Para revisar en un solo archivo con contexto (ejemplo):
  sed -n '1,240p' app/modules/tickets/flujoTicket.php | sed -n '1,240p'

Notas

Esta auditoría es un punto de partida. Puedo continuar y generar un informe archivo por archivo (marcando línea, contenido exacto y un parche sugerido para convertir cada llamada en prepared statements). Indica si continuar con la conversión automática (puede ayudar a reducir trabajo manual) o prefieres revisiones manuales por prioridad.
