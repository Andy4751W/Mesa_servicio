@echo off
if not exist "C:\Users\Jhonny\MailDevData" mkdir "C:\Users\Jhonny\MailDevData"

start "n8n Mesa de Servicio" cmd /k npx.cmd n8n@2.35.0
timeout /t 5 /nobreak >nul

start "MailDev Mesa de Servicio" cmd /k npx.cmd --yes maildev --mail-directory "C:\Users\Jhonny\MailDevData"
timeout /t 3 /nobreak >nul

start "" http://localhost:5678
start "" http://localhost:1080