<?php
declare(strict_types=1);

require_once __DIR__ . '/seguridad.php';

seguridadAplicarCabeceras(true);
seguridadIniciarSesion();
seguridadTokenCsrf();

require_once APP_ROOT . '/config/conexion.php';
require_once APP_ROOT . '/core/pais.php';
require_once APP_ROOT . '/core/chatEstado.php';
require_once APP_ROOT . '/core/sesionUnica.php';

if (!paisModuloInstalado($conn)) {
    http_response_code(503);
    exit('La separación por país todavía no está instalada. Ejecute la migración 005.');
}

function cerrarSesionYVolver(
    string $error,
    bool $cerrarSesionVigente = true
): void
{
    global $conn;
    $idUsuarioSesion = (int) ($_SESSION['usuario_id'] ?? 0);
    $tokenSesion = (string) ($_SESSION['sesion_unica_token'] ?? '');

    if ($conn instanceof mysqli && $cerrarSesionVigente) {
        $eraSesionVigente = sesionUnicaCerrar(
            $conn,
            $idUsuarioSesion,
            $tokenSesion,
            $error
        );
        if ($eraSesionVigente && !sesionUsuarioTieneAccesoActivo($conn, $idUsuarioSesion)) {
            chatSesionCerrada($conn, $idUsuarioSesion);
        }
    }
    seguridadCerrarSesion();
    seguridadIniciarSesion();
    $_SESSION['mesa_login_error'] = $error;
    header('Location: ' . mesaUrlInicio());
    exit;
}

$ahora = time();
$ultimaRotacion = (int) ($_SESSION['ultima_rotacion'] ?? $ahora);
$agenteActual = hash('sha256', (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
$agenteSesion = (string) ($_SESSION['agente_sesion'] ?? $agenteActual);
$motivoVencimiento = seguridadMotivoVencimiento($ahora);

if (
    $motivoVencimiento !== null
    || !hash_equals($agenteSesion, $agenteActual)
) {
    cerrarSesionYVolver(
        $motivoVencimiento ?? 'sesion_expirada'
    );
}

if ($ahora - $ultimaRotacion > 900) {
    session_regenerate_id(true);
    $_SESSION['ultima_rotacion'] = $ahora;
}

$_SESSION['agente_sesion'] = $agenteActual;

$idUsuario = filter_var(
    $_SESSION['usuario_id'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$idUsuario) {
    cerrarSesionYVolver('credenciales');
}

try {
    $stmt = $conn->prepare(
        "SELECT nombre, id_rol, puede_consultar_global, id_pais_operacion, estado,
                sesion_activa_hash
         FROM usuarios
         WHERE id_usuario = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $idUsuario);
    $stmt->execute();

    $resultado = $stmt->get_result();
    $usuario = $resultado->fetch_assoc();
    $stmt->close();

    $estado = strtolower(trim((string) ($usuario['estado'] ?? '')));

    if (!$usuario || $estado !== 'activo') {
        cerrarSesionYVolver('sesion_inhabilitada');
    }

    $rolBase = (int) ($usuario['id_rol'] ?? 0);
    $permisoConsultaGlobal = (int) (
        $usuario['puede_consultar_global'] ?? 0
    ) === 1;
    $rolContexto = strtolower(trim((string) ($_SESSION['rol_contexto'] ?? '')));

    if (
        $permisoConsultaGlobal
        && in_array($rolContexto, ['administrador', 'gestor', 'solicitante'], true)
    ) {
        $rolActual = [
            'administrador' => 1,
            'gestor' => 2,
            'solicitante' => 3,
        ][$rolContexto];
    } else {
        $rolActual = $rolBase === 2 && $rolContexto === 'solicitante'
            ? 3
            : $rolBase;
    }

    if (!sesionAccesoVigente(
        $conn,
        (int) $idUsuario,
        $rolBase,
        (string) ($_SESSION['sesion_unica_token'] ?? ''),
        (string) ($usuario['sesion_activa_hash'] ?? '')
    )) {
        cerrarSesionYVolver('sesion_reemplazada', false);
    }

    if (!in_array($rolActual, [1, 2, 3], true)) {
        cerrarSesionYVolver('rol');
    }

    $_SESSION['rol_base'] = $rolBase;
    $_SESSION['rol'] = $rolActual;
    $_SESSION['permiso_consulta_global'] = $permisoConsultaGlobal;
    $_SESSION['usuario'] = (string) ($usuario['nombre'] ?? 'Usuario');

    paisInicializarUsuario($conn, $usuario);

    if (!defined('MESA_OMITIR_ACTIVIDAD_SESION')) {
        $tokenSesionActual = (string) ($_SESSION['sesion_unica_token'] ?? '');
        $ahoraActividad = time();
        $idPaisActividad = paisContextoId();
        $ultimaActividadPersistida = (int) (
            $_SESSION['actividad_db_actualizada_en'] ?? 0
        );
        $ultimoPaisPersistido = (int) (
            $_SESSION['actividad_db_pais_id'] ?? 0
        );

        $_SESSION['ultima_interaccion'] = $ahoraActividad;

        /*
         * La vigencia se comprueba arriba en cada solicitud. Estas escrituras
         * solo mantienen marcas informativas, por lo que no necesitan golpear
         * MySQL en cada cambio de pantalla.
         */
        if ($ahoraActividad - $ultimaActividadPersistida >= 20) {
            sesionRegistrarActividad(
                $conn,
                (int) $idUsuario,
                $tokenSesionActual
            );
            $_SESSION['actividad_db_actualizada_en'] = $ahoraActividad;
        }

        if (
            $idPaisActividad > 0
            && (
                $idPaisActividad !== $ultimoPaisPersistido
                || $ahoraActividad - $ultimaActividadPersistida >= 20
            )
        ) {
            sesionRegistrarPais(
                $conn,
                (int) $idUsuario,
                $tokenSesionActual,
                $idPaisActividad
            );
            $_SESSION['actividad_db_pais_id'] = $idPaisActividad;
        }
    }

    if (
        $rolActual === 1
        && paisContextoId() < 1
        && !defined('MESA_PERMITE_SIN_PAIS')
    ) {
        header('Location: seleccionarPais.php', true, 303);
        exit;
    }
} catch (Throwable $e) {
    error_log('No fue posible validar la sesión: ' . $e->getMessage());
    cerrarSesionYVolver('sistema');
}

/* Una sesión autenticada y vigente se refleja como usuario en línea. */
chatRegistrarActividad($conn, (int) $idUsuario);

/* Toda modificación autenticada exige origen propio y token antifalsificación. */
seguridadExigirOrigenPost();
seguridadExigirCsrfPost();

/*
 * El navegador interno carga los módulos mediante GET. Una vez validada la
 * sesión, retener su bloqueo hasta terminar consultas pesadas hace que los
 * clics rápidos queden en cola, incluso si el navegador canceló esas vistas.
 */
if (
    ($_SERVER['REQUEST_METHOD'] ?? '') === 'GET'
    && (
        strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'mesanavigation'
        || strtolower((string) ($_SERVER['HTTP_SEC_FETCH_DEST'] ?? '')) === 'iframe'
    )
    && session_status() === PHP_SESSION_ACTIVE
) {
    session_write_close();
}
