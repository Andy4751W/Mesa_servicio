<?php
declare(strict_types=1);

/**
 * Controles de seguridad comunes para la Mesa de Servicio.
 * Requiere PHP 7.4 o superior.
 */

const SEGURIDAD_SESION_INACTIVIDAD = 300;
const SEGURIDAD_SESION_AVISO = 15;
const SEGURIDAD_SESION_VENCIMIENTO = SEGURIDAD_SESION_INACTIVIDAD + SEGURIDAD_SESION_AVISO;
const SEGURIDAD_BLOQUEO_LOGIN_SEGUNDOS = 300;

function seguridadEntorno(): string
{
    $entorno = strtolower(trim((string) (getenv('MESA_ENV') ?: 'production')));

    return in_array($entorno, ['production', 'staging', 'development'], true)
        ? $entorno
        : 'production';
}

function seguridadEsProduccion(): bool
{
    return seguridadEntorno() === 'production';
}

/**
 * Identificador estable del control de intentos por cuenta.
 * Mantiene el bloqueo asociado al usuario para que Administración pueda
 * liberarlo sin depender de la IP desde la que se intentó acceder.
 */
function seguridadClaveIntentoLogin(string $email): string
{
    return hash('sha256', 'cuenta|' . strtolower(trim($email)));
}

function seguridadEsHttps(): bool
{
    if ((string) getenv('MESA_FORCE_HTTPS') === '1') {
        return true;
    }

    return isset($_SERVER['HTTPS'])
        && $_SERVER['HTTPS'] !== ''
        && strtolower((string) $_SERVER['HTTPS']) !== 'off';
}

function seguridadAplicarCabeceras(bool $contenidoPrivado = true): void
{
    if (headers_sent()) {
        return;
    }

    header('X-Content-Type-Options: nosniff');
    // El perfil se abre dentro de un iframe del mismo portal.
    header('X-Frame-Options: SAMEORIGIN');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header(
        "Content-Security-Policy: default-src 'self'; "
        . "base-uri 'self'; frame-ancestors 'self'; form-action 'self'; "
        . "object-src 'none'; img-src 'self' data: blob:; "
        . "font-src 'self' data:; style-src 'self' 'unsafe-inline'; "
        . "script-src 'self' 'unsafe-inline'; connect-src 'self'"
    );

    if ($contenidoPrivado) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
    }

    if (seguridadEsHttps()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function seguridadIniciarSesion(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.cookie_secure', seguridadEsHttps() ? '1' : '0');
    ini_set('session.gc_maxlifetime', (string) SEGURIDAD_SESION_VENCIMIENTO);

    session_name('MESA_SID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => seguridadEsHttps(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function seguridadMotivoVencimiento(?int $ahora = null): ?string
{
    if (empty($_SESSION['usuario_id'])) {
        return 'credenciales';
    }

    $ahora ??= time();
    $interaccion = (int) ($_SESSION['ultima_interaccion'] ?? 0);

    if ($interaccion < 1) {
        return 'sesion_expirada';
    }

    if ($ahora - $interaccion >= SEGURIDAD_SESION_VENCIMIENTO) {
        return 'inactividad';
    }

    return null;
}

/** @return array{inactividad:int,aviso:int,gracia:int} */
function seguridadTiemposRestantes(?int $ahora = null): array
{
    $ahora ??= time();
    $interaccion = (int) ($_SESSION['ultima_interaccion'] ?? $ahora);

    $transcurrido = max(0, $ahora - $interaccion);

    return [
        'inactividad' => max(0, SEGURIDAD_SESION_INACTIVIDAD - $transcurrido),
        'aviso' => SEGURIDAD_SESION_AVISO,
        'gracia' => max(0, SEGURIDAD_SESION_VENCIMIENTO - $transcurrido),
    ];
}

function seguridadTokenCsrf(): string
{
    seguridadIniciarSesion();

    if (
        !isset($_SESSION['csrf_token'])
        || !is_string($_SESSION['csrf_token'])
        || strlen($_SESSION['csrf_token']) !== 64
    ) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/** Lee y elimina un aviso de sesión incluso cuando una vista GET liberó su bloqueo. */
function seguridadConsumirDatoSesion(string $clave)
{
    $sesionReabierta = session_status() !== PHP_SESSION_ACTIVE;
    if ($sesionReabierta) {
        seguridadIniciarSesion();
    }

    $valor = $_SESSION[$clave] ?? null;
    unset($_SESSION[$clave]);

    if ($sesionReabierta) {
        session_write_close();
    }

    return $valor;
}

function seguridadCsrfValido($token): bool
{
    return is_string($token)
        && strlen($token) === 64
        && hash_equals(seguridadTokenCsrf(), $token);
}

function seguridadExigirCsrfPost(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        return;
    }

    $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');

    if (!seguridadCsrfValido($token)) {
        http_response_code(403);
        exit('La solicitud no es válida. Actualice la página e inténtelo de nuevo.');
    }
}

function seguridadOrigenMismoSitio(): bool
{
    $origen = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
    $referencia = trim((string) ($_SERVER['HTTP_REFERER'] ?? ''));
    $fuente = $origen !== '' ? $origen : $referencia;

    if ($fuente === '') {
        return false;
    }

    $esquemaActual = seguridadEsHttps() ? 'https' : 'http';
    $hostEncabezado = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
    $destino = parse_url($esquemaActual . '://' . $hostEncabezado);
    $origenParseado = parse_url($fuente);

    if (!is_array($destino) || !is_array($origenParseado)) {
        return false;
    }

    $hostFuente = strtolower((string) ($origenParseado['host'] ?? ''));
    $hostActual = strtolower((string) ($destino['host'] ?? ''));
    $esquemaFuente = strtolower((string) ($origenParseado['scheme'] ?? ''));
    $puertoFuente = (int) ($origenParseado['port'] ?? (
        $esquemaFuente === 'https' ? 443 : 80
    ));
    $puertoActual = (int) ($destino['port'] ?? (
        $esquemaActual === 'https' ? 443 : 80
    ));

    return $hostFuente !== ''
        && $hostActual !== ''
        && hash_equals($hostActual, $hostFuente)
        && hash_equals($esquemaActual, $esquemaFuente)
        && $puertoActual === $puertoFuente;
}

function seguridadExigirOrigenPost(): void
{
    if (
        ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'
        && !seguridadOrigenMismoSitio()
    ) {
        http_response_code(403);
        exit('Origen de solicitud no permitido.');
    }
}

/**
 * Permiso adicional para usuarios que necesitan consultar la operación
 * completa sin convertirse en administradores ni gestores.
 *
 * El permiso se carga desde usuarios en validarSesion.php. Nunca se confía en
 * un valor enviado por el navegador.
 */
function seguridadEsConsultaGlobal(): bool
{
    return !empty($_SESSION['permiso_consulta_global']);
}

/** El usuario de pruebas trabaja con casos aislados de la operación oficial. */
function seguridadEsUsuarioPrueba(): bool
{
    $idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
    $nombre = strtolower(trim((string) ($_SESSION['usuario'] ?? '')));
    $correo = strtolower(trim((string) ($_SESSION['correo'] ?? '')));

    return $idUsuario === 40
        || ($nombre === 'prueba' && str_contains($correo, 'prueba'));
}

/** Filtro SQL para ocultar casos creados por el usuario de pruebas. */
function seguridadFiltroCasosOficiales(string $alias = 't'): string
{
    if (seguridadEsUsuarioPrueba()) {
        return '';
    }

    $alias = preg_match('/^[a-zA-Z_][a-zA-Z0-9_]*$/', $alias)
        ? $alias
        : 't';

    return " AND {$alias}.es_prueba = 0";
}

function seguridadConsultaGlobalPuedeEscribirComoSolicitante(): bool
{
    if (!seguridadEsConsultaGlobal() || (int) ($_SESSION['rol'] ?? 0) !== 3) {
        return false;
    }

    $entrada = strtolower(basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')));

    return in_array(
        $entrada,
        [
            'panelsolicitante.php',
            'crearticket.php',
            'mensajes.php',
            'mensajesapi.php',
            'enviarmensaje.php',
            'consultarencuesta.php',
        ],
        true
    );
}

function seguridadConsultaGlobalPuedeEscribirComoPruebaGestor(): bool
{
    if (!seguridadEsUsuarioPrueba() || (int) ($_SESSION['rol'] ?? 0) !== 2) {
        return false;
    }

    $entrada = strtolower(basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')));

    return in_array(
        $entrada,
        [
            'flujoticket.php',
            'mensajes.php',
            'mensajesapi.php',
            'enviarmensaje.php',
        ],
        true
    );
}

/**
 * Rechaza una modificación de consulta global sin dejar al usuario en una
 * página de error vacía. Las peticiones AJAX reciben JSON; los formularios
 * normales regresan a la pantalla anterior con un aviso temporal.
 */
function seguridadRechazarSoloLectura(): never
{
    $mensaje = 'Este usuario es de solo consulta y no puede modificar información.';
    $esAjax = strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''))
        === 'xmlhttprequest';

    if ($esAjax || str_contains(
        strtolower((string) ($_SERVER['HTTP_ACCEPT'] ?? '')),
        'application/json'
    )) {
        http_response_code(403);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(
            ['ok' => false, 'codigo' => 'solo_lectura', 'mensaje' => $mensaje],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
        exit;
    }

    $_SESSION['mesa_aviso_solo_lectura'] = $mensaje;
    $destino = trim((string) ($_SERVER['HTTP_REFERER'] ?? ''));
    $hostActual = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
    $hostDestino = strtolower((string) parse_url($destino, PHP_URL_HOST));

    if ($destino === '' || ($hostDestino !== '' && $hostDestino !== $hostActual)) {
        $destino = (string) ($_SERVER['REQUEST_URI'] ?? '/');
    }

    session_write_close();
    header('Location: ' . $destino, true, 303);
    exit;
}

/** @param list<int> $roles */
function seguridadExigirRol(array $roles): void
{
    $rol = (int) ($_SESSION['rol'] ?? 0);
    $metodo = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

    if (in_array($rol, $roles, true)) {
        // Un usuario con consulta global solo conserva escritura en el
        // portal solicitante. Las vistas administrativas y de gestión son
        // estrictamente de lectura aunque su rol base coincida.
        if (
            seguridadEsConsultaGlobal()
            && $metodo === 'POST'
            && !seguridadConsultaGlobalPuedeEscribirComoSolicitante()
            && !seguridadConsultaGlobalPuedeEscribirComoPruebaGestor()
        ) {
            seguridadRechazarSoloLectura();
        }

        return;
    }

    // Las pantallas de consulta global se pueden abrir por GET sin cambiar el
    // rol base. Un POST nunca obtiene acceso por este permiso.
    if (seguridadEsConsultaGlobal() && $metodo === 'GET') {
        return;
    }

    if (!in_array($rol, $roles, true)) {
        http_response_code(403);
        exit('Acceso denegado.');
    }
}

function seguridadPasswordValida(string $password): bool
{
    $longitud = function_exists('mb_strlen')
        ? mb_strlen($password, 'UTF-8')
        : strlen($password);

    $tieneMayuscula = preg_match('/\p{Lu}/u', $password) === 1;
    $tieneNumero = preg_match('/[0-9]/', $password) === 1;

    return $longitud >= 8
        && $longitud <= 128
        && $tieneMayuscula
        && $tieneNumero;
}

function seguridadTexto($valor, int $maximo): string
{
    $texto = trim((string) $valor);

    if (function_exists('mb_substr')) {
        return mb_substr($texto, 0, $maximo, 'UTF-8');
    }

    return substr($texto, 0, $maximo);
}

function seguridadIpCliente(): string
{
    $ip = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));

    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}

function seguridadDiagnosticoHabilitado(): bool
{
    return !seguridadEsProduccion()
        || (string) getenv('MESA_ENABLE_DIAGNOSTICS') === '1';
}

function seguridadDirectorioPrivado(string $subdirectorio = ''): string
{
    if (!defined('MESA_STORAGE_PATH')) {
        throw new RuntimeException(
            'El almacenamiento privado no está configurado.'
        );
    }

    $base = rtrim((string) constant('MESA_STORAGE_PATH'), '/\\');
    $subdirectorio = trim($subdirectorio, '/\\');

    return $subdirectorio === ''
        ? $base
        : $base . DIRECTORY_SEPARATOR . $subdirectorio;
}

function seguridadUrlImagenCatalogo(int $idCatalogo, $ruta): string
{
    $referencia = trim((string) $ruta);
    if ($idCatalogo < 1 || $referencia === '') {
        return 'icons/default.png';
    }

    /*
     * La referencia cambia al reemplazar la imagen. El parámetro de versión
     * permite conservar el binario en el navegador sin mostrar uno anterior.
     */
    $version = substr(hash('sha256', $referencia), 0, 16);
    return 'imagenCatalogo.php?id=' . $idCatalogo . '&v=' . $version;
}

function seguridadCerrarSesion(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return;
    }

    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $parametros = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => $parametros['path'],
            'domain' => $parametros['domain'],
            'secure' => (bool) $parametros['secure'],
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    session_destroy();
}
