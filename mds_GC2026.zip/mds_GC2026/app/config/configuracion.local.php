<?php
declare(strict_types=1);

return [
    'db_host' => '68.178.198.21',
    'db_port' => '3306',
    'db_name' => 'mds_GC2026',
    'db_user' => 'mds_admin',
    'db_password' => 'elpatas2026*',
    'storage_path' => dirname(__DIR__, 2) . '/mds_storage',
'n8n_webhook_url' => 'https://n8n.srv904940.hstgr.cloud/webhook/1bf5bec6-2d49-4168-9b63-baa12736fc02',
'n8n_webhook_secret' => 'MesaServicioLocal2026_Prueba_9274',
'recovery_pepper' => 'MesaServicioLocal2026_Pepper_Recuperacion_5831',
'fuente_db_host' => '68.178.198.21',
'fuente_db_port' => '3306',
'fuente_db_name' => 'SRCGC',
'fuente_db_user' => 'TicsConectar',
'fuente_db_password' => 'Conectaraldia2*',
];
