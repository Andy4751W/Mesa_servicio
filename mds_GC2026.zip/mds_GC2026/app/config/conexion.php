<?php
declare(strict_types=1);

/**
 * Configuración y conexión unificadas para el servidor de producción.
 *
 * Este archivo reemplaza conjuntamente a:
 * - app/config/conexion.php
 * - app/config/configuracion.local.php
 *
 * Los módulos de n8n y fuente de personal vuelven a requerir esta misma ruta.
 * En esas cargas posteriores se retorna únicamente el arreglo de configuración
 * y no se abre una segunda conexión con la base de datos.
 */

if (!function_exists('mesaConfiguracionIntegrada')) {
    /** @return array<string, mixed> */
    function mesaConfiguracionIntegrada(): array
    {
        return [
            'db_host' => '68.178.198.21',
            'db_port' => '3306',
            'db_name' => 'mds_GC2026',
            'db_user' => 'mds_admin',
            'db_password' => 'elpatas2026*',
            'storage_path' => dirname(__DIR__, 2) . '/mds_storage',

            'n8n_webhook_url' => 'https://n8n.srv904940.hstgr.cloud/webhook/1bf5bec6-2d49-4168-9b63-baa12736fc02',
            'n8n_webhook_secret' => 'MesaServicioLocal2026_Prueba_9274',
            'recovery_pepper' => 'MesaServicioLocal2026_Pepper_Recuperacion_5831',

            'fuente_db_host' => '68.178.198.21',
            'fuente_db_port' => '3306',
            'fuente_db_name' => 'SRCGC',
            'fuente_db_user' => 'TicsConectar',
            'fuente_db_password' => 'Conectaraldia2*',
        ];
    }
}

$configuracionLocal = mesaConfiguracionIntegrada();

/*
 * correoN8n.php y fuentePersonal.php consultan MESA_CONFIG_FILE. Se les indica
 * que la configuración ahora está integrada en este mismo archivo.
 */
putenv('MESA_CONFIG_FILE=' . __FILE__);

/*
 * Si este archivo ya realizó la conexión, una carga posterior solo necesita
 * recibir el arreglo de configuración.
 */
if (defined('MESA_CONEXION_INTEGRADA_CARGADA')) {
    return $configuracionLocal;
}

define('MESA_CONEXION_INTEGRADA_CARGADA', true);

require_once APP_ROOT . '/security/seguridad.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$valorConexion = static function (
    string $variable,
    string $clave,
    string $predeterminado = ''
) use ($configuracionLocal): string {
    $entorno = getenv($variable);

    if ($entorno !== false && $entorno !== '') {
        return (string) $entorno;
    }

    return isset($configuracionLocal[$clave])
        ? (string) $configuracionLocal[$clave]
        : $predeterminado;
};

$servidor = $valorConexion('MESA_DB_HOST', 'db_host', 'localhost');
$puerto = (int) $valorConexion('MESA_DB_PORT', 'db_port', '3306');
$usuario = $valorConexion('MESA_DB_USER', 'db_user');
$password = $valorConexion('MESA_DB_PASSWORD', 'db_password');
$baseDatos = $valorConexion('MESA_DB_NAME', 'db_name', 'mesa_servicio');
$almacenamientoConfigurado = (
    (getenv('MESA_STORAGE_PATH') !== false
        && (string) getenv('MESA_STORAGE_PATH') !== '')
    || !empty($configuracionLocal['storage_path'])
);
$almacenamiento = $valorConexion(
    'MESA_STORAGE_PATH',
    'storage_path',
    dirname(__DIR__) . '/mesa_servicio_private'
);

if (
    $usuario === ''
    || $baseDatos === ''
    || (
        seguridadEsProduccion()
        && (strtolower($usuario) === 'root' || $password === '')
    )
) {
    error_log('Configuración de base de datos insegura o incompleta.');
    http_response_code(503);
    exit('El servicio no se encuentra disponible temporalmente.');
}

$rutaAbsoluta = str_starts_with($almacenamiento, '/')
    || preg_match('/^[A-Za-z]:[\\\\\/]/', $almacenamiento) === 1;
$documentRoot = rtrim((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\');
$almacenamientoNormalizado = rtrim(
    str_replace('\\', '/', $almacenamiento),
    '/'
);
$documentRootNormalizado = rtrim(
    str_replace('\\', '/', $documentRoot),
    '/'
);
$dentroDelDirectorioPublico = $documentRootNormalizado !== ''
    && (
        $almacenamientoNormalizado === $documentRootNormalizado
        || str_starts_with(
            $almacenamientoNormalizado . '/',
            $documentRootNormalizado . '/'
        )
    );
$almacenamientoProyectoPermitido = rtrim(
    str_replace('\\', '/', PROJECT_ROOT),
    '/'
) . '/mds_storage';
$esAlmacenamientoProyectoPermitido = hash_equals(
    $almacenamientoProyectoPermitido,
    $almacenamientoNormalizado
);

if (
    !$rutaAbsoluta
    || (seguridadEsProduccion() && !$almacenamientoConfigurado)
    || (
        seguridadEsProduccion()
        && $dentroDelDirectorioPublico
        && !$esAlmacenamientoProyectoPermitido
    )
) {
    error_log('La ruta de almacenamiento privado es insegura o inválida.');
    http_response_code(503);
    exit('El servicio no se encuentra disponible temporalmente.');
}

if (!defined('MESA_STORAGE_PATH')) {
    define('MESA_STORAGE_PATH', $almacenamientoNormalizado);
}

try {
    $conn = mysqli_init();
    $conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, 5);
    $conn->real_connect(
        $servidor,
        $usuario,
        $password,
        $baseDatos,
        $puerto
    );
    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '-05:00'");
} catch (Throwable $e) {
    error_log('Error de conexión a la base de datos: ' . $e->getMessage());
    http_response_code(503);
    exit('El servicio no se encuentra disponible temporalmente.');
}

return $configuracionLocal;
