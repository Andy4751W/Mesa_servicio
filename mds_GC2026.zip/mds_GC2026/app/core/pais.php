<?php
declare(strict_types=1);

/**
 * Contexto de país (tenant) de la Mesa de Servicio.
 *
 * Los administradores seleccionan el país después de autenticarse. Los
 * gestores y solicitantes reciben el país configurado en su usuario. Todas
 * las validaciones críticas deben basarse en este contexto del servidor y no
 * en valores enviados por formularios o por la URL.
 */

const PAIS_OPERACION_COLOMBIA = 1;
const PAIS_OPERACION_PERU = 2;

function paisModuloInstalado(mysqli $conn): bool
{
    $ahora = time();
    $cache = $_SESSION['pais_modulo_instalado_cache'] ?? null;
    if (
        is_array($cache)
        && !empty($cache['instalado'])
        && $ahora - (int) ($cache['comprobado_en'] ?? 0) < 3600
    ) {
        return true;
    }

    try {
        $resultado = $conn->query(
            "SELECT COUNT(*) AS total
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND (
                    (TABLE_NAME = 'paises_operacion'
                     AND COLUMN_NAME = 'id_pais_operacion')
                 OR (TABLE_NAME = 'usuarios'
                     AND COLUMN_NAME = 'id_pais_operacion')
                 OR (TABLE_NAME = 'tickets'
                     AND COLUMN_NAME = 'id_pais_operacion')
               )"
        );
        $fila = $resultado instanceof mysqli_result
            ? $resultado->fetch_assoc()
            : null;

        $instalado = (int) ($fila['total'] ?? 0) === 3;
        if ($instalado) {
            $_SESSION['pais_modulo_instalado_cache'] = [
                'instalado' => true,
                'comprobado_en' => $ahora,
            ];
        }

        return $instalado;
    } catch (Throwable $e) {
        return false;
    }
}

/** @return array<int, array<string, mixed>> */
function paisOperacionesActivas(mysqli $conn): array
{
    $resultado = $conn->query(
        "SELECT id_pais_operacion, codigo, nombre, zona_horaria,
                color_primario, color_secundario
         FROM paises_operacion
         WHERE estado = 'activo'
         ORDER BY orden, nombre"
    );

    return $resultado === false ? [] : $resultado->fetch_all(MYSQLI_ASSOC);
}

/** @return array<string, mixed>|null */
function paisBuscarOperacion(mysqli $conn, int $idPais): ?array
{
    if ($idPais < 1) {
        return null;
    }

    $stmt = $conn->prepare(
        "SELECT id_pais_operacion, codigo, nombre, zona_horaria,
                color_primario, color_secundario
         FROM paises_operacion
         WHERE id_pais_operacion = ? AND estado = 'activo'
         LIMIT 1"
    );
    $stmt->bind_param('i', $idPais);
    $stmt->execute();
    $pais = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $pais ?: null;
}

/** @param array<string, mixed> $pais */
function paisGuardarContexto(array $pais): void
{
    $_SESSION['pais_operacion_id'] = (int) $pais['id_pais_operacion'];
    $_SESSION['pais_operacion_codigo'] = (string) $pais['codigo'];
    $_SESSION['pais_operacion_nombre'] = (string) $pais['nombre'];
    $_SESSION['pais_operacion_zona'] = (string) $pais['zona_horaria'];
    $_SESSION['pais_operacion_color'] = (string) $pais['color_primario'];
    $_SESSION['pais_operacion_color_secundario'] = (string) $pais['color_secundario'];
    $_SESSION['pais_contexto_validado_en'] = time();

    $zona = trim((string) $pais['zona_horaria']);
    if ($zona !== '') {
        date_default_timezone_set($zona);
    }
}

function paisLimpiarContexto(): void
{
    foreach (
        [
            'pais_operacion_id',
            'pais_operacion_codigo',
            'pais_operacion_nombre',
            'pais_operacion_zona',
            'pais_operacion_color',
            'pais_operacion_color_secundario',
            'pais_contexto_validado_en',
        ] as $clave
    ) {
        unset($_SESSION[$clave]);
    }
}

function paisContextoId(): int
{
    return (int) ($_SESSION['pais_operacion_id'] ?? 0);
}

function paisContextoNombre(): string
{
    return (string) ($_SESSION['pais_operacion_nombre'] ?? '');
}

function paisContextoCodigo(): string
{
    return (string) ($_SESSION['pais_operacion_codigo'] ?? '');
}

function paisZonaHorariaActual(): string
{
    $zona = trim((string) ($_SESSION['pais_operacion_zona'] ?? ''));

    return $zona !== '' ? $zona : 'America/Bogota';
}

function paisColorActual(): string
{
    if (strtoupper(trim(paisContextoCodigo())) === 'PE') {
        return '#f47c20';
    }

    return (string) ($_SESSION['pais_operacion_color'] ?? '#0f6fec');
}

function paisColorSecundarioActual(): string
{
    if (strtoupper(trim(paisContextoCodigo())) === 'PE') {
        return '#155b89';
    }

    return (string) ($_SESSION['pais_operacion_color_secundario'] ?? '#facc15');
}

/** @param array<string, mixed> $usuario */
function paisInicializarUsuario(mysqli $conn, array $usuario): void
{
    $rol = (int) ($usuario['id_rol'] ?? 0);
    $idPaisEsperado = $rol === 1
        ? paisContextoId()
        : (int) ($usuario['id_pais_operacion'] ?? 0);
    $contextoCompleto = $idPaisEsperado > 0
        && paisContextoId() === $idPaisEsperado
        && trim(paisContextoCodigo()) !== ''
        && trim(paisContextoNombre()) !== '';
    $contextoReciente = time()
        - (int) ($_SESSION['pais_contexto_validado_en'] ?? 0) < 60;

    if ($contextoCompleto && $contextoReciente) {
        date_default_timezone_set(paisZonaHorariaActual());
        return;
    }

    if ($rol === 1) {
        $paisActual = paisBuscarOperacion($conn, paisContextoId());
        if ($paisActual) {
            paisGuardarContexto($paisActual);
        } else {
            paisLimpiarContexto();
        }
        return;
    }

    $idPais = (int) ($usuario['id_pais_operacion'] ?? 0);
    $pais = paisBuscarOperacion($conn, $idPais);

    if (!$pais) {
        http_response_code(403);
        exit('Su usuario no tiene un país de operación activo asignado.');
    }

    paisGuardarContexto($pais);
}

function paisExigirContexto(): int
{
    $idPais = paisContextoId();

    if ($idPais < 1) {
        http_response_code(403);
        exit('Seleccione un país de operación antes de continuar.');
    }

    return $idPais;
}

function paisExigirTicket(mysqli $conn, int $idTicket): void
{
    $idPais = paisExigirContexto();
    $stmt = $conn->prepare(
        'SELECT 1 FROM tickets WHERE id_ticket = ? AND id_pais_operacion = ? LIMIT 1'
    );
    $stmt->bind_param('ii', $idTicket, $idPais);
    $stmt->execute();
    $stmt->store_result();
    $permitido = $stmt->num_rows === 1;
    $stmt->close();

    if (!$permitido) {
        http_response_code(403);
        exit('El ticket no pertenece al país de operación seleccionado.');
    }
}

function paisRegistroPertenece(
    mysqli $conn,
    string $entidad,
    int $idRegistro
): bool {
    $entidades = [
        'catalogos' => 'id_catalogo',
        'configuraciones_servicio' => 'id_opcion',
        'feriados' => 'id_feriado',
        'procesos' => 'id_proceso',
        'servicios' => 'id_servicio',
        'sla' => 'id_sla',
        'tickets' => 'id_ticket',
    ];

    if ($idRegistro < 1 || !isset($entidades[$entidad])) {
        return false;
    }

    $idPais = paisExigirContexto();
    $columna = $entidades[$entidad];
    $stmt = $conn->prepare(
        "SELECT 1 FROM `{$entidad}`
         WHERE `{$columna}` = ? AND id_pais_operacion = ? LIMIT 1"
    );
    $stmt->bind_param('ii', $idRegistro, $idPais);
    $stmt->execute();
    $stmt->store_result();
    $pertenece = $stmt->num_rows === 1;
    $stmt->close();

    return $pertenece;
}

function paisHtmlNombre(): string
{
    return htmlspecialchars(paisContextoNombre(), ENT_QUOTES, 'UTF-8');
}

function paisHtmlEstilo(): string
{
    $primario = htmlspecialchars(paisColorActual(), ENT_QUOTES, 'UTF-8');
    $secundario = htmlspecialchars(paisColorSecundarioActual(), ENT_QUOTES, 'UTF-8');

    return "--pais-primary:{$primario};--pais-secondary:{$secundario};";
}
