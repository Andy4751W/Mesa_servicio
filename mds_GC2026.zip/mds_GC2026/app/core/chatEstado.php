<?php
declare(strict_types=1);

/**
 * Presencia y confirmaciones de entrega/lectura para las conversaciones.
 *
 * La lectura se guarda como un cursor temporal por caso, etapa y usuario. Así,
 * todos los mensajes anteriores al cursor comparten el mismo estado sin crear
 * una fila adicional por cada mensaje.
 */

/*
 * La marca en_linea puede quedar activa si el navegador se cierra, el equipo
 * pierde conexión o la sesión desaparece sin pasar por logout.php. La
 * presencia se considera vigente únicamente cuando hubo actividad reciente.
 * El módulo Mensajes renueva esta marca continuamente mientras permanece
 * abierto, de modo que el estado se apaga pocos segundos después de cerrarlo.
 */
const CHAT_PRESENCIA_VIGENCIA_SEGUNDOS = 5;

function chatEstadoDisponible(mysqli $conn): bool
{
    static $disponible = [];
    $clave = spl_object_id($conn);
    if (array_key_exists($clave, $disponible)) {
        return $disponible[$clave];
    }

    $resultado = $conn->query(
        "SELECT COUNT(*) AS total
         FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME IN (
               'chat_usuario_presencia',
               'chat_conversacion_estado'
           )"
    );
    $fila = $resultado instanceof mysqli_result
        ? $resultado->fetch_assoc()
        : null;
    $disponible[$clave] = (int) ($fila['total'] ?? 0) === 2;

    return $disponible[$clave];
}

function chatRegistrarActividad(mysqli $conn, int $idUsuario): void
{
    if ($idUsuario < 1 || !chatEstadoDisponible($conn)) {
        return;
    }

    $stmt = $conn->prepare(
        "INSERT INTO chat_usuario_presencia
            (id_usuario, en_linea, inicio_sesion_en, ultima_actividad_en)
         VALUES (?, 1, NOW(), NOW())
         ON DUPLICATE KEY UPDATE
            en_linea = 1,
            ultima_actividad_en = NOW()"
    );
    $stmt->bind_param('i', $idUsuario);
    $stmt->execute();
    $stmt->close();
}

function chatSesionIniciada(mysqli $conn, int $idUsuario): void
{
    if ($idUsuario < 1 || !chatEstadoDisponible($conn)) {
        return;
    }

    $stmt = $conn->prepare(
        "INSERT INTO chat_usuario_presencia
            (id_usuario, en_linea, inicio_sesion_en, ultima_actividad_en)
         VALUES (?, 1, NOW(), NOW())
         ON DUPLICATE KEY UPDATE
            en_linea = 1,
            inicio_sesion_en = NOW(),
            ultima_actividad_en = NOW()"
    );
    $stmt->bind_param('i', $idUsuario);
    $stmt->execute();
    $stmt->close();
}

function chatSesionCerrada(mysqli $conn, int $idUsuario): void
{
    if ($idUsuario < 1 || !chatEstadoDisponible($conn)) {
        return;
    }

    $stmt = $conn->prepare(
        "INSERT INTO chat_usuario_presencia
            (id_usuario, en_linea, ultima_actividad_en)
         VALUES (?, 0, NOW())
         ON DUPLICATE KEY UPDATE
            en_linea = 0,
            ultima_actividad_en = NOW()"
    );
    $stmt->bind_param('i', $idUsuario);
    $stmt->execute();
    $stmt->close();
}

/** @return array{en_linea:bool,ultima_actividad:string} */
function chatObtenerPresencia(mysqli $conn, int $idUsuario): array
{
    static $cache = [];
    $vacia = ['en_linea' => false, 'ultima_actividad' => ''];
    if ($idUsuario < 1 || !chatEstadoDisponible($conn)) {
        return $vacia;
    }
    $clave = spl_object_id($conn) . ':' . $idUsuario;
    if (isset($cache[$clave])) {
        return $cache[$clave];
    }

    $vigencia = CHAT_PRESENCIA_VIGENCIA_SEGUNDOS;
    $stmt = $conn->prepare(
        "SELECT
            ultima_actividad_en,
            (
                en_linea = 1
                AND ultima_actividad_en >= DATE_SUB(
                    NOW(),
                    INTERVAL {$vigencia} SECOND
                )
            ) AS en_linea
         FROM chat_usuario_presencia
         WHERE id_usuario = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $idUsuario);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$fila) {
        return $cache[$clave] = $vacia;
    }

    return $cache[$clave] = [
        'en_linea' => (bool) ($fila['en_linea'] ?? false),
        'ultima_actividad' => (string) ($fila['ultima_actividad_en'] ?? ''),
    ];
}

/**
 * Registra la entrega sin exigir que el destinatario abra esta conversación.
 * Una sesión iniciada representa que la aplicación ya puede entregarle el
 * mensaje. El cursor queda guardado y no retrocede cuando cierre sesión.
 */
function chatMarcarEntregaSiEnLinea(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idDestinatario
): void {
    if (
        $idTicket < 1
        || $idTicketEtapa < 1
        || $idDestinatario < 1
        || !chatEstadoDisponible($conn)
        || !chatObtenerPresencia($conn, $idDestinatario)['en_linea']
    ) {
        return;
    }

    $stmt = $conn->prepare(
        "SELECT MAX(creado_en) AS entregado_hasta
         FROM solicitud_comunicaciones
         WHERE id_ticket = ?
           AND id_ticket_etapa = ?
           AND id_emisor IS NOT NULL
           AND id_emisor <> ?"
    );
    $stmt->bind_param('iii', $idTicket, $idTicketEtapa, $idDestinatario);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $hasta = (string) ($fila['entregado_hasta'] ?? '');

    if ($hasta === '') {
        return;
    }

    $stmt = $conn->prepare(
        "INSERT INTO chat_conversacion_estado
            (id_ticket, id_ticket_etapa, id_usuario, entregado_hasta)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
            entregado_hasta = IF(
                entregado_hasta IS NULL OR entregado_hasta < VALUES(entregado_hasta),
                VALUES(entregado_hasta), entregado_hasta
            )"
    );
    $stmt->bind_param(
        'iiis',
        $idTicket,
        $idTicketEtapa,
        $idDestinatario,
        $hasta
    );
    $stmt->execute();
    $stmt->close();
}

/**
 * Marca como entregados o leídos los mensajes ajenos que el usuario ya recibió
 * dentro del hilo autorizado.
 */
function chatMarcarRecepcion(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol,
    int $idTicketEtapa = 0,
    bool $marcarLeido = false
): void {
    if ($idTicket < 1 || $idUsuario < 1 || !chatEstadoDisponible($conn)) {
        return;
    }

    $restriccionEtapa = $idTicketEtapa > 0
        ? " AND te.id_ticket_etapa = {$idTicketEtapa}"
        : " AND te.id_ticket_etapa_padre IS NULL";
    $restriccionTipo = $idTicketEtapa > 0
        ? ''
        : " AND sc.tipo = 'publica'";
    /* Cuando se indica una etapa concreta, la autorización ya fue validada
       por el módulo que abre el hilo. Esto también cubre al gestor que creó
       una derivación, aunque no sea el gestor destino de ese nodo. */
    $restriccionGestor = $rol === 2 && $idTicketEtapa < 1
        ? " AND te.id_gestor = {$idUsuario}"
        : '';
    $resultado = $conn->query(
        "SELECT
            te.id_ticket_etapa,
            MAX(sc.creado_en) AS recibido_hasta
         FROM solicitud_comunicaciones AS sc
         INNER JOIN ticket_etapas AS te
            ON te.id_ticket_etapa = sc.id_ticket_etapa
           AND te.id_ticket = sc.id_ticket
         WHERE sc.id_ticket = {$idTicket}
           {$restriccionTipo}
           AND sc.id_emisor IS NOT NULL
           AND sc.id_emisor <> {$idUsuario}
           {$restriccionEtapa}
           {$restriccionGestor}
         GROUP BY te.id_ticket_etapa"
    );

    if (!$resultado instanceof mysqli_result) {
        return;
    }

    $sql = $marcarLeido
        ? "INSERT INTO chat_conversacion_estado
                (id_ticket, id_ticket_etapa, id_usuario, entregado_hasta, leido_hasta)
           VALUES (?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
                entregado_hasta = IF(
                    entregado_hasta IS NULL OR entregado_hasta < VALUES(entregado_hasta),
                    VALUES(entregado_hasta), entregado_hasta
                ),
                leido_hasta = IF(
                    leido_hasta IS NULL OR leido_hasta < VALUES(leido_hasta),
                    VALUES(leido_hasta), leido_hasta
                )"
        : "INSERT INTO chat_conversacion_estado
                (id_ticket, id_ticket_etapa, id_usuario, entregado_hasta)
           VALUES (?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
                entregado_hasta = IF(
                    entregado_hasta IS NULL OR entregado_hasta < VALUES(entregado_hasta),
                    VALUES(entregado_hasta), entregado_hasta
                )";

    while ($fila = $resultado->fetch_assoc()) {
        $idEtapa = (int) ($fila['id_ticket_etapa'] ?? 0);
        $hasta = (string) ($fila['recibido_hasta'] ?? '');
        if ($idEtapa < 1 || $hasta === '') {
            continue;
        }

        $stmt = $conn->prepare($sql);
        if ($marcarLeido) {
            $stmt->bind_param('iiiss', $idTicket, $idEtapa, $idUsuario, $hasta, $hasta);
        } else {
            $stmt->bind_param('iiis', $idTicket, $idEtapa, $idUsuario, $hasta);
        }
        $stmt->execute();
        $stmt->close();
    }
}

/** @return array<string,array{entregado_hasta:string,leido_hasta:string}> */
function chatEstadosDelTicket(mysqli $conn, int $idTicket): array
{
    if ($idTicket < 1 || !chatEstadoDisponible($conn)) {
        return [];
    }

    $resultado = $conn->query(
        "SELECT id_ticket_etapa, id_usuario, entregado_hasta, leido_hasta
         FROM chat_conversacion_estado
         WHERE id_ticket = {$idTicket}"
    );
    if (!$resultado instanceof mysqli_result) {
        return [];
    }

    $estados = [];
    while ($fila = $resultado->fetch_assoc()) {
        $clave = (int) $fila['id_ticket_etapa'] . ':' . (int) $fila['id_usuario'];
        $estados[$clave] = [
            'entregado_hasta' => (string) ($fila['entregado_hasta'] ?? ''),
            'leido_hasta' => (string) ($fila['leido_hasta'] ?? ''),
        ];
    }
    return $estados;
}

/** @param array<string,array{entregado_hasta:string,leido_hasta:string}> $estados */
function chatEstadoEvento(
    array $estados,
    int $idTicketEtapa,
    int $idDestinatario,
    string $creadoEn
): string {
    if ($idTicketEtapa < 1 || $idDestinatario < 1 || $creadoEn === '') {
        return 'enviado';
    }

    $estado = $estados[$idTicketEtapa . ':' . $idDestinatario] ?? null;
    if (!$estado) {
        return 'enviado';
    }
    if (($estado['leido_hasta'] ?? '') !== '' && $creadoEn <= $estado['leido_hasta']) {
        return 'leido';
    }
    if (($estado['entregado_hasta'] ?? '') !== '' && $creadoEn <= $estado['entregado_hasta']) {
        return 'entregado';
    }
    return 'enviado';
}
