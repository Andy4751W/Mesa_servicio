<?php
declare(strict_types=1);

/** Campos adicionales configurables por servicio y diligenciados por etapa. */
function camposExtrasTablaDisponible(mysqli $conn): bool
{
    static $disponible = null;
    if ($disponible !== null) {
        return $disponible;
    }
    try {
        $resultado = $conn->query("SHOW TABLES LIKE 'servicio_campos_extra'");
        $disponible = $resultado instanceof mysqli_result && $resultado->num_rows > 0;
    } catch (Throwable $e) {
        $disponible = false;
    }
    return $disponible;
}

function camposExtrasPrepararEsquema(mysqli $conn): bool
{
    static $preparado = [];
    $clave = spl_object_id($conn);
    if (isset($preparado[$clave])) {
        return $preparado[$clave];
    }
    /* Evitar tres CREATE TABLE IF NOT EXISTS en cada navegación. En
     * instalaciones ya migradas una sola lectura de metadatos es suficiente;
     * solo se ejecutan los CREATE cuando realmente falta alguna tabla. */
    try {
        $resultadoTablas = $conn->query(
            "SELECT TABLE_NAME
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME IN (
                   'servicio_campos_extra',
                   'ticket_campos_extra',
                   'campos_extras_fuentes'
               )"
        );
        $tablasExistentes = [];
        if ($resultadoTablas instanceof mysqli_result) {
            while ($filaTabla = $resultadoTablas->fetch_assoc()) {
                $tablasExistentes[(string) ($filaTabla['TABLE_NAME'] ?? '')] = true;
            }
        }
        if (count($tablasExistentes) === 3) {
            return $preparado[$clave] = true;
        }
    } catch (Throwable $e) {
        /* Si information_schema no está disponible, se conserva el camino
         * compatible que intenta crear las tablas debajo. */
    }
    try {
        $conn->query(
            "CREATE TABLE IF NOT EXISTS servicio_campos_extra (
                id_campo_extra BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                id_servicio INT NOT NULL,
                etiqueta VARCHAR(255) NOT NULL,
                orden SMALLINT UNSIGNED NOT NULL DEFAULT 1,
                obligatorio TINYINT(1) NOT NULL DEFAULT 1,
                estado ENUM('activo','eliminado') NOT NULL DEFAULT 'activo',
                creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id_campo_extra),
                KEY idx_campos_extra_servicio_estado (id_servicio, estado, orden)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        $conn->query(
            "CREATE TABLE IF NOT EXISTS ticket_campos_extra (
                id_valor BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                id_ticket INT NOT NULL,
                id_ticket_etapa BIGINT UNSIGNED NOT NULL,
                id_campo_extra BIGINT UNSIGNED NOT NULL,
                etiqueta VARCHAR(255) NOT NULL,
                valor TEXT NOT NULL,
                id_usuario INT NULL,
                creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id_valor),
                UNIQUE KEY uq_ticket_campo_extra (id_ticket_etapa, id_campo_extra),
                KEY idx_ticket_campos_extra_ticket (id_ticket, id_ticket_etapa)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        $conn->query(
            "CREATE TABLE IF NOT EXISTS campos_extras_fuentes (
                nombre_fuente VARCHAR(120) NOT NULL PRIMARY KEY,
                aplicado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        $preparado[$clave] = true;
    } catch (Throwable $e) {
        error_log('No fue posible preparar campos extras: ' . $e->getMessage());
        $preparado[$clave] = false;
    }
    return $preparado[$clave];
}

/** Carga una sola vez las etiquetas entregadas en el catálogo V9. */
function camposExtrasSembrarCatalogo(mysqli $conn, int $idPaisOperacion): void
{
    static $ejecutado = [];
    $clave = spl_object_id($conn) . ':' . $idPaisOperacion;
    if (isset($ejecutado[$clave]) || !camposExtrasPrepararEsquema($conn)) return;
    $ejecutado[$clave] = true;
    $fuente = dirname(__DIR__, 2) . '/database/data/catalogo_campos_extras.json';
    if (!is_file($fuente)) return;
    $nombreFuente = basename($fuente);
    $stmtMarca = $conn->prepare('SELECT 1 FROM campos_extras_fuentes WHERE nombre_fuente = ? LIMIT 1');
    $stmtMarca->bind_param('s', $nombreFuente);
    $stmtMarca->execute();
    $stmtMarca->store_result();
    if ($stmtMarca->num_rows > 0) { $stmtMarca->close(); return; }
    $stmtMarca->close();
    $contenido = file_get_contents($fuente);
    $registros = json_decode((string) $contenido, true);
    if (!is_array($registros)) return;
    /*
     * Resolver los servicios y los que ya tienen campos en dos consultas
     * agrupadas. La versión anterior hacía una consulta por cada fila del
     * catálogo (más otra para contar campos), lo que hacía que la primera
     * apertura de módulos tardara varios segundos cuando había cientos de
     * servicios.
     */
    $stmtServicios = $conn->prepare(
        "SELECT id_servicio, nombre
         FROM servicios
         WHERE id_pais_operacion = ? AND estado <> 'eliminado'"
    );
    $stmtServicios->bind_param('i', $idPaisOperacion);
    $stmtServicios->execute();
    $resultadoServicios = $stmtServicios->get_result();
    $serviciosPorNombre = [];
    while ($filaServicio = $resultadoServicios->fetch_assoc()) {
        $nombreServicio = trim((string) ($filaServicio['nombre'] ?? ''));
        if ($nombreServicio === '') {
            continue;
        }
        $claveServicio = function_exists('mb_strtolower')
            ? mb_strtolower($nombreServicio, 'UTF-8')
            : strtolower($nombreServicio);
        if (!isset($serviciosPorNombre[$claveServicio])) {
            $serviciosPorNombre[$claveServicio] = (int) $filaServicio['id_servicio'];
        }
    }
    $stmtServicios->close();

    $idsServicio = array_values($serviciosPorNombre);
    $camposExistentes = [];
    if ($idsServicio !== []) {
        $marcadores = implode(',', array_fill(0, count($idsServicio), '?'));
        $tipos = str_repeat('i', count($idsServicio));
        $stmtCampos = $conn->prepare(
            "SELECT id_servicio, COUNT(*) AS total
             FROM servicio_campos_extra
             WHERE estado = 'activo' AND id_servicio IN ($marcadores)
             GROUP BY id_servicio"
        );
        $parametros = [];
        $parametros[] = &$tipos;
        foreach ($idsServicio as $indice => $idServicio) {
            $parametros[] = &$idsServicio[$indice];
        }
        call_user_func_array([$stmtCampos, 'bind_param'], $parametros);
        $stmtCampos->execute();
        $resultadoCampos = $stmtCampos->get_result();
        while ($filaCampo = $resultadoCampos->fetch_assoc()) {
            $camposExistentes[(int) $filaCampo['id_servicio']] = (int) $filaCampo['total'];
        }
        $stmtCampos->close();
    }

    $stmtInsertar = $conn->prepare(
        "INSERT INTO servicio_campos_extra (id_servicio, etiqueta, orden, obligatorio, estado)
         VALUES (?, ?, ?, 1, 'activo')"
    );
    $conn->begin_transaction();
    try {
        foreach ($registros as $registro) {
            $nombre = trim((string) ($registro['service'] ?? ''));
            $etiquetas = is_array($registro['fields'] ?? null)
                ? camposExtrasNormalizarEtiquetas($registro['fields'])
                : [];
            if ($nombre === '' || !$etiquetas) {
                continue;
            }
            $claveNombre = function_exists('mb_strtolower')
                ? mb_strtolower($nombre, 'UTF-8')
                : strtolower($nombre);
            $idServicio = (int) ($serviciosPorNombre[$claveNombre] ?? 0);
            if ($idServicio < 1 || !empty($camposExistentes[$idServicio])) {
                continue;
            }
        foreach ($etiquetas as $indice => $etiqueta) {
            $orden = $indice + 1;
            $stmtInsertar->bind_param('isi', $idServicio, $etiqueta, $orden);
            $stmtInsertar->execute();
        }
            $camposExistentes[$idServicio] = count($etiquetas);
        }
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        $stmtInsertar->close();
        throw $e;
    }
    $stmtInsertar->close();
    $stmtMarca = $conn->prepare('INSERT IGNORE INTO campos_extras_fuentes (nombre_fuente) VALUES (?)');
    $stmtMarca->bind_param('s', $nombreFuente); $stmtMarca->execute(); $stmtMarca->close();
}

/** @return array<int,array{id_campo_extra:int,etiqueta:string,orden:int,obligatorio:int}> */
function camposExtrasListarServicio(mysqli $conn, int $idServicio): array
{
    if ($idServicio < 1 || !camposExtrasTablaDisponible($conn)) {
        return [];
    }
    $stmt = $conn->prepare(
        "SELECT id_campo_extra, etiqueta, orden, obligatorio
         FROM servicio_campos_extra
         WHERE id_servicio = ? AND estado = 'activo'
         ORDER BY orden, id_campo_extra"
    );
    $stmt->bind_param('i', $idServicio);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $campos = [];
    while ($fila = $resultado->fetch_assoc()) {
        $campos[] = [
            'id_campo_extra' => (int) $fila['id_campo_extra'],
            'etiqueta' => trim((string) $fila['etiqueta']),
            'orden' => (int) $fila['orden'],
            'obligatorio' => (int) $fila['obligatorio'],
        ];
    }
    $stmt->close();
    return $campos;
}

/** Convierte el contenido del editor (una etiqueta por línea) en etiquetas únicas. */
function camposExtrasNormalizarEtiquetas($entrada): array
{
    if (is_array($entrada)) {
        $lineas = $entrada;
    } else {
        $lineas = preg_split('/\r\n|\r|\n/', (string) $entrada) ?: [];
    }
    $resultado = [];
    $vistos = [];
    foreach ($lineas as $linea) {
        $etiqueta = trim((string) $linea);
        $etiqueta = preg_replace('/^\s*\d+\s*[.)-]\s*/u', '', $etiqueta) ?? $etiqueta;
        $etiqueta = trim($etiqueta, " \t\n\r\0\x0B.-");
        $longitud = function_exists('mb_strlen') ? mb_strlen($etiqueta, 'UTF-8') : strlen($etiqueta);
        if ($etiqueta === '' || $longitud > 255) {
            continue;
        }
        $clave = function_exists('mb_strtolower') ? mb_strtolower($etiqueta, 'UTF-8') : strtolower($etiqueta);
        if (isset($vistos[$clave])) {
            continue;
        }
        $vistos[$clave] = true;
        $resultado[] = $etiqueta;
    }
    return $resultado;
}

function camposExtrasGuardarServicio(mysqli $conn, int $idServicio, $entrada): void
{
    if ($idServicio < 1) {
        return;
    }
    if (!camposExtrasPrepararEsquema($conn)) {
        throw new RuntimeException('No fue posible habilitar los campos extras.');
    }
    $etiquetas = camposExtrasNormalizarEtiquetas($entrada);
    $stmtDesactivar = $conn->prepare(
        "UPDATE servicio_campos_extra SET estado = 'eliminado' WHERE id_servicio = ? AND estado = 'activo'"
    );
    $stmtDesactivar->bind_param('i', $idServicio);
    $stmtDesactivar->execute();
    $stmtDesactivar->close();
    if (!$etiquetas) {
        return;
    }
    $stmt = $conn->prepare(
        "INSERT INTO servicio_campos_extra (id_servicio, etiqueta, orden, obligatorio, estado)
         VALUES (?, ?, ?, 1, 'activo')"
    );
    foreach ($etiquetas as $indice => $etiqueta) {
        $orden = $indice + 1;
        $stmt->bind_param('isi', $idServicio, $etiqueta, $orden);
        $stmt->execute();
    }
    $stmt->close();
}

/** @param array<mixed> $valores */
function camposExtrasValidarValores(mysqli $conn, int $idServicio, array $valores): array
{
    $campos = camposExtrasListarServicio($conn, $idServicio);
    $normalizados = [];
    $faltantes = [];
    foreach ($campos as $campo) {
        $idCampo = (int) $campo['id_campo_extra'];
        $valor = trim((string) ($valores[$idCampo] ?? ''));
        if ((int) $campo['obligatorio'] === 1 && $valor === '') {
            $faltantes[] = $campo['etiqueta'];
        }
        $normalizados[$idCampo] = $valor;
    }
    if ($faltantes) {
        throw new RuntimeException('Complete los campos extras obligatorios: ' . implode(', ', $faltantes) . '.');
    }
    return ['campos' => $campos, 'valores' => $normalizados];
}

/** @param array<mixed> $valores */
function camposExtrasGuardarValores(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idServicio,
    array $valores,
    int $idUsuario
): void {
    if ($idTicket < 1 || $idTicketEtapa < 1 || !camposExtrasTablaDisponible($conn)) {
        return;
    }
    $validado = camposExtrasValidarValores($conn, $idServicio, $valores);
    $stmt = $conn->prepare(
        "INSERT INTO ticket_campos_extra
            (id_ticket, id_ticket_etapa, id_campo_extra, etiqueta, valor, id_usuario)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE valor = VALUES(valor), etiqueta = VALUES(etiqueta), id_usuario = VALUES(id_usuario), actualizado_en = CURRENT_TIMESTAMP"
    );
    foreach ($validado['campos'] as $campo) {
        $idCampo = (int) $campo['id_campo_extra'];
        $etiqueta = (string) $campo['etiqueta'];
        $valor = (string) ($validado['valores'][$idCampo] ?? '');
        $stmt->bind_param('iiissi', $idTicket, $idTicketEtapa, $idCampo, $etiqueta, $valor, $idUsuario);
        $stmt->execute();
    }
    $stmt->close();
}

/** @return array<int,array{etiqueta:string,valor:string}> */
function camposExtrasValoresEtapa(mysqli $conn, int $idTicketEtapa): array
{
    if ($idTicketEtapa < 1 || !camposExtrasTablaDisponible($conn)) {
        return [];
    }
    $stmt = $conn->prepare(
        "SELECT etiqueta, valor FROM ticket_campos_extra WHERE id_ticket_etapa = ? ORDER BY id_valor"
    );
    $stmt->bind_param('i', $idTicketEtapa);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $valores = [];
    while ($fila = $resultado->fetch_assoc()) {
        $valores[] = ['etiqueta' => (string) $fila['etiqueta'], 'valor' => (string) $fila['valor']];
    }
    $stmt->close();
    return $valores;
}
