<?php
declare(strict_types=1);

/**
 * Compatibilidad con funciones incorporadas en PHP 8.
 *
 * Las declaraciones condicionales permiten conservar las implementaciones
 * nativas cuando la aplicacion se ejecuta en una version posterior.
 */

if (!function_exists('mesaStrStartsWith')) {
    function mesaStrStartsWith(string $haystack, string $needle): bool
    {
        return $needle === '' || strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

if (!function_exists('mesaStrContains')) {
    function mesaStrContains(string $haystack, string $needle): bool
    {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

/*
 * Conserva estos nombres para código heredado o integraciones que todavía
 * utilicen las funciones incorporadas a partir de PHP 8.
 */
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool
    {
        return mesaStrStartsWith($haystack, $needle);
    }
}

if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool
    {
        return mesaStrContains($haystack, $needle);
    }
}
