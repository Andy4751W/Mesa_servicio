<?php
declare(strict_types=1);

/**
 * Control de una sola sesión activa por usuario.
 *
 * El navegador conserva el token original dentro de la sesión PHP. En MySQL
 * solo se almacena su huella SHA-256. Un nuevo inicio de sesión reemplaza esa
 * huella y, por tanto, invalida cualquier sesión abierta anteriormente.
 */

function sesionUnicaHuella(string $token): string
{
    return hash('sha256', $token);
}

function sesionUnicaCrear(mysqli $conn, int $idUsuario): string
{
    if ($idUsuario < 1) {
        throw new InvalidArgumentException('El usuario de la sesión no es válido.');
    }

    $token = bin2hex(random_bytes(32));
    $huella = sesionUnicaHuella($token);
    $stmt = $conn->prepare(
        "UPDATE usuarios
         SET sesion_activa_hash = ?, sesion_activa_en = NOW()
         WHERE id_usuario = ?"
    );
    $stmt->bind_param('si', $huella, $idUsuario);
    $stmt->execute();
    $actualizados = $stmt->affected_rows;
    $stmt->close();

    if ($actualizados < 1) {
        throw new RuntimeException('No fue posible registrar la sesión activa.');
    }

    return $token;
}

function sesionUnicaVigente(
    int $idUsuario,
    string $token,
    ?string $huellaGuardada
): bool {
    $huellaGuardada = trim((string) $huellaGuardada);

    return $idUsuario > 0
        && strlen($token) === 64
        && strlen($huellaGuardada) === 64
        && hash_equals($huellaGuardada, sesionUnicaHuella($token));
}

/**
 * Invalida la sesión solo si todavía es la sesión vigente del usuario.
 * Esto evita que una sesión antigua cierre por accidente una sesión nueva.
 */
function sesionUnicaCerrar(
    mysqli $conn,
    int $idUsuario,
    string $token
): bool {
    if ($idUsuario < 1 || strlen($token) !== 64) {
        return false;
    }

    $huella = sesionUnicaHuella($token);
    $stmt = $conn->prepare(
        "UPDATE usuarios
         SET sesion_activa_hash = NULL, sesion_activa_en = NULL
         WHERE id_usuario = ? AND sesion_activa_hash = ?"
    );
    $stmt->bind_param('is', $idUsuario, $huella);
    $stmt->execute();
    $cerrada = $stmt->affected_rows > 0;
    $stmt->close();

    return $cerrada;
}
