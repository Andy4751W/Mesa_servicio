<?php
declare(strict_types=1);

/**
 * Matriz corporativa de prioridad.
 *
 * Urgencia: 1 = Más tarde, 2 = Pronto, 3 = Inmediato.
 * Impacto:  1 = Bajo, 2 = Moderado, 3 = Urgente.
 * Puntaje:  urgencia + impacto - 1 (rango 1 a 5).
 */

function matrizPrioridadValorValido($valor): ?int
{
    $numero = filter_var($valor, FILTER_VALIDATE_INT);

    return is_int($numero) && $numero >= 1 && $numero <= 3
        ? $numero
        : null;
}

/**
 * @return array{
 *   urgencia_valor:int,
 *   urgencia_nombre:string,
 *   impacto_valor:int,
 *   impacto_nombre:string,
 *   prioridad_valor:int,
 *   prioridad_nombre:string,
 *   codigo:string
 * }
 */
function matrizPrioridadCalcular(int $urgencia, int $impacto): array
{
    if ($urgencia < 1 || $urgencia > 3 || $impacto < 1 || $impacto > 3) {
        throw new InvalidArgumentException(
            'La urgencia y el impacto deben estar entre 1 y 3.'
        );
    }

    $nombresUrgencia = [
        1 => 'Más tarde',
        2 => 'Pronto',
        3 => 'Inmediato',
    ];
    $nombresImpacto = [
        1 => 'Bajo',
        2 => 'Moderado',
        3 => 'Urgente',
    ];
    $prioridades = [
        1 => [1 => 'Bajo', 2 => 'Bajo moderado', 3 => 'Bajo urgente'],
        2 => [1 => 'Moderado bajo', 2 => 'Moderado', 3 => 'Moderado urgente'],
        3 => [1 => 'Urgente bajo', 2 => 'Urgente moderado', 3 => 'Urgente'],
    ];

    return [
        'urgencia_valor' => $urgencia,
        'urgencia_nombre' => $nombresUrgencia[$urgencia],
        'impacto_valor' => $impacto,
        'impacto_nombre' => $nombresImpacto[$impacto],
        'prioridad_valor' => $urgencia + $impacto - 1,
        'prioridad_nombre' => $prioridades[$urgencia][$impacto],
        'codigo' => $urgencia . '-' . $impacto,
    ];
}

function matrizPrioridadColor(int $puntaje): string
{
    return (fn ($__mesaMatchValue5) => (($__mesaMatchValue5 === ($puntaje <= 1)) ? ('#16a34a') : ((($__mesaMatchValue5 === ($puntaje === 2)) ? ('#65a30d') : ((($__mesaMatchValue5 === ($puntaje === 3)) ? ('#ca8a04') : ((($__mesaMatchValue5 === ($puntaje === 4)) ? ('#ea580c') : ('#dc2626')))))))))(true);
}

