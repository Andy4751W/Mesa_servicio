<?php
declare(strict_types=1);

function fuentePersonalConfiguracion(): array
{
    static $configuracion = null;

    if (is_array($configuracion)) {
        return $configuracion;
    }

    $ruta = (string) (getenv('MESA_CONFIG_FILE') ?: '');
    if ($ruta === '') {
        $ruta = APP_ROOT . '/config/configuracion.local.php';
    }

    $local = is_file($ruta) ? require $ruta : [];
    if (!is_array($local)) {
        $local = [];
    }

    $valor = static function (string $variable, string $clave) use ($local): string {
        $entorno = getenv($variable);
        if ($entorno !== false && trim((string) $entorno) !== '') {
            return trim((string) $entorno);
        }

        return trim((string) ($local[$clave] ?? ''));
    };

    $configuracion = [
        'host' => $valor('MESA_FUENTE_DB_HOST', 'fuente_db_host'),
        'port' => (int) $valor('MESA_FUENTE_DB_PORT', 'fuente_db_port'),
        'name' => $valor('MESA_FUENTE_DB_NAME', 'fuente_db_name'),
        'user' => $valor('MESA_FUENTE_DB_USER', 'fuente_db_user'),
        'password' => $valor('MESA_FUENTE_DB_PASSWORD', 'fuente_db_password'),
    ];

    return $configuracion;
}

function fuentePersonalNormalizarUbicacion(string $valor): string
{
    $valor = strtoupper(trim($valor));
    $valor = strtr($valor, [
        'Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U', 'Ü' => 'U',
    ]);
    $valor = preg_replace('/\bD\.?\s*C\.?\b/', '', $valor) ?? $valor;
    $valor = preg_replace('/[^A-Z0-9]+/', ' ', $valor) ?? $valor;

    return trim(preg_replace('/\s+/', ' ', $valor) ?? $valor);
}

/** @return array<string, string>|null */
function fuentePersonalBuscar(string $cedula): ?array
{
    $cedula = trim($cedula);
    if ($cedula === '' || strlen($cedula) > 30) {
        return null;
    }

    $configuracion = fuentePersonalConfiguracion();
    if (
        $configuracion['host'] === ''
        || $configuracion['name'] === ''
        || $configuracion['user'] === ''
        || $configuracion['port'] < 1
    ) {
        throw new RuntimeException('La fuente externa de personal no está configurada.');
    }

    mysqli_report(MYSQLI_REPORT_OFF);
    $conexion = new mysqli(
        $configuracion['host'],
        $configuracion['user'],
        $configuracion['password'],
        $configuracion['name'],
        $configuracion['port']
    );
    if ($conexion->connect_errno) {
        throw new RuntimeException('No fue posible consultar la fuente externa de personal.');
    }

    try {
        $conexion->set_charset('utf8mb4');
        $stmt = $conexion->prepare(
            'SELECT identificacion, apellidos_y_nombres, correo_electronico,
                    emp, CU_Proceso, UNIDAD_1_COD, UNIDAD_1_DESCRIP,
                    UNIDAD_3_COD, CU_Regional, CU_Ciudad, CIUDAD, ciudad
             FROM mae_data_uniclass
             WHERE identificacion = ?
             LIMIT 1'
        );
        if ($stmt === false) {
            throw new RuntimeException('No fue posible preparar la consulta de personal.');
        }

        $stmt->bind_param('s', $cedula);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $fila = $resultado ? $resultado->fetch_assoc() : null;
        $stmt->close();

        $departamento = trim((string) ($fila['CU_Regional'] ?? ''));
        $ciudad = trim((string) ($fila['CIUDAD'] ?? $fila['ciudad'] ?? ''));
        if ($ciudad !== '') {
            $stmtCiudad = $conexion->prepare(
                'SELECT nombre, departamento
                 FROM mae_ciudades
                 WHERE REPLACE(REPLACE(REPLACE(UPPER(nombre), \'Á\', \'A\'), \'É\', \'E\'), \'Í\', \'I\') = ?
                   AND activo = 1
                 LIMIT 1'
            );
            if ($stmtCiudad !== false) {
                $ciudadNormalizada = fuentePersonalNormalizarUbicacion($ciudad);
                $stmtCiudad->bind_param('s', $ciudadNormalizada);
                $stmtCiudad->execute();
                $filaCiudad = $stmtCiudad->get_result()->fetch_assoc();
                $stmtCiudad->close();
                if (is_array($filaCiudad) && trim((string) ($filaCiudad['departamento'] ?? '')) !== '') {
                    $departamento = trim((string) $filaCiudad['departamento']);
                    $ciudad = trim((string) ($filaCiudad['nombre'] ?? $ciudad));
                }
            }
        }
        if (
            fuentePersonalNormalizarUbicacion($departamento) === 'BOGOTA'
            && fuentePersonalNormalizarUbicacion($ciudad) === 'BOGOTA'
        ) {
            $departamento = 'Cundinamarca';
        }
    } finally {
        $conexion->close();
    }

    if (!is_array($fila)) {
        return null;
    }

    return [
        'cedula' => trim((string) ($fila['identificacion'] ?? $cedula)),
        'nombre' => trim((string) ($fila['apellidos_y_nombres'] ?? '')),
        'email' => strtolower(trim((string) ($fila['correo_electronico'] ?? ''))),
        'empresa' => trim((string) ($fila['emp'] ?? '')),
        'proceso' => trim((string) ($fila['CU_Proceso'] ?? '')),
        'cu1' => trim((string) ($fila['UNIDAD_1_COD'] ?? '')),
        'descripcion_cu1' => trim((string) ($fila['UNIDAD_1_DESCRIP'] ?? '')),
        'cu3' => trim((string) ($fila['UNIDAD_3_COD'] ?? '')),
        'departamento' => $departamento,
        'ciudad' => $ciudad,
    ];
}
