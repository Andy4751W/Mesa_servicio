<?php
declare(strict_types=1);

require_once __DIR__ . '/pais.php';

/**
 * Calendario laboral común de la mesa de servicio.
 *
 * Jornada base: lunes a viernes, de 08:00 a 18:00 en la zona horaria del país.
 * Los días y horas se pueden ajustar desde el módulo Horarios. Cualquier
 * festivo o periodo adicional solo se excluye si está activo en `feriados`.
 */

const CALENDARIO_HORA_INICIO = 8;
const CALENDARIO_HORA_FIN = 18;
const CALENDARIO_MINUTOS_DIA_SLA = 600;

/** @return array<int, array{activo:bool,inicio:string,fin:string}> */
function calendarioHorariosPredeterminados(): array
{
    $horarios = [];
    for ($dia = 1; $dia <= 7; $dia++) {
        $horarios[$dia] = [
            'activo' => $dia <= 5,
            'inicio' => '08:00',
            'fin' => '18:00',
        ];
    }

    return $horarios;
}

function calendarioAsegurarTablaHorarios(mysqli $conn): bool
{
    static $estado = [];
    $clave = spl_object_id($conn);
    if (array_key_exists($clave, $estado)) {
        return $estado[$clave];
    }

    try {
        $resultado = $conn->query(
            "CREATE TABLE IF NOT EXISTS horarios_laborales_sla (
                id_horario INT UNSIGNED NOT NULL AUTO_INCREMENT,
                id_pais_operacion INT NOT NULL,
                dia_semana TINYINT UNSIGNED NOT NULL,
                activo TINYINT(1) NOT NULL DEFAULT 0,
                hora_inicio TIME NULL,
                hora_fin TIME NULL,
                actualizado_por INT NULL,
                actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id_horario),
                UNIQUE KEY uq_horario_pais_dia (id_pais_operacion, dia_semana),
                KEY idx_horario_pais (id_pais_operacion)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        );
        $estado[$clave] = $resultado !== false;
    } catch (Throwable $e) {
        error_log('No fue posible preparar la tabla de horarios SLA: ' . $e->getMessage());
        $estado[$clave] = false;
    }

    return $estado[$clave];
}

/** @return array<int, array{activo:bool,inicio:string,fin:string}> */
function calendarioHorariosLaborales(mysqli $conn): array
{
    static $cache = [];
    $idPais = paisExigirContexto();
    $clave = spl_object_id($conn) . ':' . $idPais;
    if (array_key_exists($clave, $cache)) {
        return $cache[$clave];
    }

    $horarios = calendarioHorariosPredeterminados();
    try {
        $stmt = $conn->prepare(
            'SELECT dia_semana, activo, hora_inicio, hora_fin
             FROM horarios_laborales_sla
             WHERE id_pais_operacion = ?
             ORDER BY dia_semana'
        );
        if (!$stmt) {
            return $cache[$clave] = $horarios;
        }
        $stmt->bind_param('i', $idPais);
        $stmt->execute();
        $resultado = $stmt->get_result();
        while ($fila = $resultado->fetch_assoc()) {
            $dia = (int) ($fila['dia_semana'] ?? 0);
            if ($dia < 1 || $dia > 7) {
                continue;
            }
            $inicio = substr((string) ($fila['hora_inicio'] ?? '08:00'), 0, 5);
            $fin = substr((string) ($fila['hora_fin'] ?? '18:00'), 0, 5);
            $horarios[$dia] = [
                'activo' => (int) ($fila['activo'] ?? 0) === 1,
                'inicio' => preg_match('/^\d{2}:\d{2}$/', $inicio) ? $inicio : '08:00',
                'fin' => preg_match('/^\d{2}:\d{2}$/', $fin) ? $fin : '18:00',
            ];
        }
        $stmt->close();
    } catch (Throwable $e) {
        error_log('No fue posible leer el horario laboral SLA: ' . $e->getMessage());
    }

    return $cache[$clave] = $horarios;
}

function calendarioMinutosDiaSla(mysqli $conn): int
{
    $total = 0;
    $diasActivos = 0;
    foreach (calendarioHorariosLaborales($conn) as $horario) {
        if (!$horario['activo']) {
            continue;
        }
        [$horaInicio, $minutoInicio] = array_map('intval', explode(':', $horario['inicio']));
        [$horaFin, $minutoFin] = array_map('intval', explode(':', $horario['fin']));
        $minutos = ($horaFin * 60 + $minutoFin) - ($horaInicio * 60 + $minutoInicio);
        if ($minutos > 0) {
            $total += $minutos;
            $diasActivos++;
        }
    }

    return $diasActivos > 0 ? max(1, (int) round($total / $diasActivos)) : CALENDARIO_MINUTOS_DIA_SLA;
}

function calendarioVersion(): string
{
    return '2026.09.30.1';
}

function calendarioZonaHoraria(): DateTimeZone
{
    static $zonas = [];
    $nombre = paisZonaHorariaActual();

    if (!isset($zonas[$nombre])) {
        $zonas[$nombre] = new DateTimeZone($nombre);
    }

    return $zonas[$nombre];
}

function calendarioTablaExiste(mysqli $conn, string $tabla): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $tabla)) {
        return false;
    }

    try {
        $patron = $conn->real_escape_string(addcslashes($tabla, '\\_%'));
        $resultado = $conn->query("SHOW TABLES LIKE '{$patron}'");

        return $resultado !== false && $resultado->num_rows > 0;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * @return array<int, array{
 *     nombre: string,
 *     inicio: DateTimeImmutable,
 *     fin: DateTimeImmutable
 * }>
 */
function calendarioFeriadosActivos(mysqli $conn): array
{
    static $cache = [];
    $idPais = paisExigirContexto();
    $clave = spl_object_id($conn) . ':' . $idPais;

    if (array_key_exists($clave, $cache)) {
        return $cache[$clave];
    }

    $cache[$clave] = [];

    try {
        $stmt = $conn->prepare(
            "SELECT id_feriado, nombre, tipo, fecha_inicio, fecha_fin
             FROM feriados
             WHERE id_pais_operacion = ?
               AND LOWER(TRIM(CAST(estado AS CHAR)))
                   IN ('activo', 'habilitado', '1')
             ORDER BY fecha_inicio ASC"
        );
        $stmt->bind_param('i', $idPais);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if (!$resultado) {
            return $cache[$clave];
        }

        $zona = calendarioZonaHoraria();

        while ($fila = $resultado->fetch_assoc()) {
            try {
                $inicio = new DateTimeImmutable(
                    (string) $fila['fecha_inicio'],
                    $zona
                );
                $fin = new DateTimeImmutable(
                    (string) $fila['fecha_fin'],
                    $zona
                );

                /*
                 * Compatibilidad con registros antiguos de día completo que
                 * pudieron guardar la misma fecha en inicio y fin. El formulario
                 * actual ya guarda el final como medianoche exclusiva del día
                 * siguiente.
                 */
                if (
                    (string) ($fila['tipo'] ?? '') === 'dia_completo'
                    && $fin <= $inicio
                ) {
                    $inicio = $inicio->setTime(0, 0);
                    $fin = $inicio->modify('+1 day');
                }

                if ($fin > $inicio) {
                    $cache[$clave][] = [
                        'nombre' => trim((string) ($fila['nombre'] ?? '')),
                        'inicio' => $inicio,
                        'fin' => $fin,
                    ];
                }
            } catch (Throwable $e) {
                continue;
            }
        }
        $stmt->close();
    } catch (Throwable $e) {
        error_log(
            'No fue posible leer los feriados del calendario SLA: '
            . $e->getMessage()
        );
        return $cache[$clave];
    }

    return $cache[$clave];
}

/**
 * Consulta directamente los feriados que se cruzan con una jornada concreta.
 * La caché es únicamente por fecha y por petición PHP; nunca se reutiliza entre
 * recargas del navegador.
 *
 * @return array<int, array{
 *     nombre: string,
 *     inicio: DateTimeImmutable,
 *     fin: DateTimeImmutable
 * }>
 */
function calendarioFeriadosDelDia(
    mysqli $conn,
    DateTimeImmutable $inicioJornada,
    DateTimeImmutable $finJornada
): array {
    static $cacheDias = [];

    $clave = spl_object_id($conn)
        . ':'
        . paisExigirContexto()
        . ':'
        . $inicioJornada->format('Y-m-d');

    if (array_key_exists($clave, $cacheDias)) {
        return $cacheDias[$clave];
    }

    $cacheDias[$clave] = [];

    foreach (calendarioFeriadosActivos($conn) as $feriado) {
        if (
            $feriado['inicio'] < $finJornada
            && $feriado['fin'] > $inicioJornada
        ) {
            $cacheDias[$clave][] = $feriado;
        }
    }

    return $cacheDias[$clave];
}

/**
 * Devuelve los tramos hábiles efectivos de un día, después de restar feriados.
 *
 * @return array<int, array{0: DateTimeImmutable, 1: DateTimeImmutable}>
 */
function calendarioIntervalosDelDia(
    mysqli $conn,
    DateTimeImmutable $dia
): array {
    $dia = $dia->setTimezone(calendarioZonaHoraria())->setTime(0, 0);

    $numeroDia = (int) $dia->format('N');
    $horario = calendarioHorariosLaborales($conn)[$numeroDia] ?? null;
    if (!$horario || !$horario['activo']) {
        return [];
    }

    [$horaInicio, $minutoInicio] = array_map('intval', explode(':', $horario['inicio']));
    [$horaFin, $minutoFin] = array_map('intval', explode(':', $horario['fin']));
    $inicioJornada = $dia->setTime($horaInicio, $minutoInicio);
    $finJornada = $dia->setTime($horaFin, $minutoFin);
    if ($finJornada <= $inicioJornada) {
        return [];
    }
    $intervalos = [[$inicioJornada, $finJornada]];

    foreach (
        calendarioFeriadosDelDia($conn, $inicioJornada, $finJornada)
        as $feriado
    ) {
        $inicioFeriado = $feriado['inicio'];
        $finFeriado = $feriado['fin'];

        if ($finFeriado <= $inicioJornada || $inicioFeriado >= $finJornada) {
            continue;
        }

        $restantes = [];

        foreach ($intervalos as [$inicioTramo, $finTramo]) {
            if ($finFeriado <= $inicioTramo || $inicioFeriado >= $finTramo) {
                $restantes[] = [$inicioTramo, $finTramo];
                continue;
            }

            if ($inicioFeriado > $inicioTramo) {
                $restantes[] = [
                    $inicioTramo,
                    $inicioFeriado < $finTramo
                        ? $inicioFeriado
                        : $finTramo,
                ];
            }

            if ($finFeriado < $finTramo) {
                $restantes[] = [
                    $finFeriado > $inicioTramo
                        ? $finFeriado
                        : $inicioTramo,
                    $finTramo,
                ];
            }
        }

        $intervalos = array_values(array_filter(
            $restantes,
            static fn (array $tramo): bool => $tramo[1] > $tramo[0]
        ));

        if (!$intervalos) {
            break;
        }
    }

    return $intervalos;
}

function calendarioMinutosSla(int $tiempo, string $unidad): int
{
    if ($tiempo < 1) {
        return 0;
    }

    return (fn ($__mesaMatchValue4) => (($__mesaMatchValue4 === ('minutos')) ? ($tiempo) : ((($__mesaMatchValue4 === ('horas')) ? ($tiempo * 60) : (0)))))($unidad);
}

/**
 * Suma días calendario hábiles conservando la hora de inicio. La franja
 * horaria no se aplica a los SLA expresados en días: solo se valida que cada
 * fecha intermedia sea laboral y no corresponda a un festivo activo. Por
 * ejemplo, un caso creado el lunes a las 08:00 con un SLA de un día vence el
 * martes a las 08:00; si el martes no es laboral, pasa al siguiente día hábil.
 */
function calcularVencimientoSlaDias(
    mysqli $conn,
    DateTimeImmutable $inicio,
    int $diasPendientes
): ?string {
    if ($diasPendientes < 1) {
        return null;
    }

    $horaVencimiento = [
        (int) $inicio->format('H'),
        (int) $inicio->format('i'),
        (int) $inicio->format('s'),
    ];
    $dia = $inicio->setTime(0, 0)->modify('+1 day');

    for ($contador = 0; $contador < 3660; $contador++) {
        $intervalos = calendarioIntervalosDelDia($conn, $dia);

        if (!$intervalos) {
            $dia = $dia->modify('+1 day')->setTime(0, 0);
            continue;
        }

        $diasPendientes--;

        if ($diasPendientes > 0) {
            $dia = $dia->modify('+1 day')->setTime(0, 0);
            continue;
        }

        return $dia
            ->setTime(
                $horaVencimiento[0],
                $horaVencimiento[1],
                $horaVencimiento[2]
            )
            ->format('Y-m-d H:i:s');
    }

    return null;
}

function calcularVencimientoSla(
    mysqli $conn,
    ?string $fechaInicio,
    int $tiempo,
    string $unidad
): ?string {
    if (!$fechaInicio || $tiempo < 1) {
        return null;
    }

    try {
        $cursor = new DateTimeImmutable(
            $fechaInicio,
            calendarioZonaHoraria()
        );
    } catch (Throwable $e) {
        return null;
    }

    if ($unidad === 'dias') {
        return calcularVencimientoSlaDias($conn, $cursor, $tiempo);
    }

    $minutos = calendarioMinutosSla($tiempo, $unidad);

    if ($minutos < 1) {
        return null;
    }

    $segundosPendientes = $minutos * 60;
    $dia = $cursor->setTime(0, 0);

    for ($contador = 0; $contador < 3660; $contador++) {
        foreach (calendarioIntervalosDelDia($conn, $dia) as [$inicio, $fin]) {
            $desde = $cursor > $inicio ? $cursor : $inicio;

            if ($desde >= $fin) {
                continue;
            }

            $disponibles = $fin->getTimestamp() - $desde->getTimestamp();

            if ($segundosPendientes <= $disponibles) {
                return $desde
                    ->modify('+' . $segundosPendientes . ' seconds')
                    ->format('Y-m-d H:i:s');
            }

            $segundosPendientes -= $disponibles;
            $cursor = $fin;
        }

        $dia = $dia->modify('+1 day')->setTime(0, 0);
        $cursor = $dia;
    }

    return null;
}

function minutosHabilesTranscurridos(
    mysqli $conn,
    string $fechaInicio,
    ?DateTimeImmutable $fechaFin = null
): int {
    try {
        $inicio = new DateTimeImmutable(
            $fechaInicio,
            calendarioZonaHoraria()
        );
    } catch (Throwable $e) {
        return 0;
    }

    $fin = ($fechaFin ?? new DateTimeImmutable('now', calendarioZonaHoraria()))
        ->setTimezone(calendarioZonaHoraria());

    if ($inicio >= $fin) {
        return 0;
    }

    $segundos = 0;
    $dia = $inicio->setTime(0, 0);
    $ultimoDia = $fin->setTime(0, 0);

    while ($dia <= $ultimoDia) {
        foreach (calendarioIntervalosDelDia($conn, $dia) as [$desde, $hasta]) {
            $inicioEfectivo = $inicio > $desde ? $inicio : $desde;
            $finEfectivo = $fin < $hasta ? $fin : $hasta;

            if ($finEfectivo > $inicioEfectivo) {
                $segundos += $finEfectivo->getTimestamp()
                    - $inicioEfectivo->getTimestamp();
            }
        }

        $dia = $dia->modify('+1 day')->setTime(0, 0);
    }

    return (int) floor($segundos / 60);
}

function horasHabilesCalendario(
    mysqli $conn,
    string $fechaInicio,
    ?DateTimeImmutable $fechaFin = null
): float {
    return minutosHabilesTranscurridos($conn, $fechaInicio, $fechaFin) / 60;
}
