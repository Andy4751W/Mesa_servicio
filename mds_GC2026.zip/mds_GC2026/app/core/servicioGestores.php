<?php
declare(strict_types=1);

/*
 * Relación de gestores habilitados por servicio.
 * La columna servicios.id_gestor se conserva como gestor predeterminado;
 * esta capa solo amplía los responsables disponibles.
 */

function servicioGestoresModuloDisponible(mysqli $conn): bool
{
    static $disponible = null;

    if ($disponible !== null) {
        return $disponible;
    }

    $resultado = $conn->query("SHOW TABLES LIKE 'servicio_gestores'");
    $disponible = $resultado !== false && $resultado->num_rows === 1;

    return $disponible;
}

/** @return array<int, int> */
function servicioGestoresIdsRecibidos($valor): array
{
    if (!is_array($valor)) {
        return [];
    }

    $ids = array_map('intval', $valor);
    $ids = array_filter($ids, static function (int $id): bool {
        return $id > 0;
    });

    return array_values(array_unique($ids));
}

function servicioGestoresTodosActivos(
    mysqli $conn,
    array $idsGestores,
    int $idPaisOperacion
): bool {
    if ($idsGestores === []) {
        return false;
    }

    $marcadores = implode(',', array_fill(0, count($idsGestores), '?'));
    $tipos = str_repeat('i', count($idsGestores)) . 'i';
    $parametros = array_merge($idsGestores, [$idPaisOperacion]);
    $stmt = $conn->prepare(
        "SELECT COUNT(*) AS total
         FROM usuarios
         WHERE id_usuario IN ({$marcadores})
           AND id_rol = 2
           AND estado = 'activo'
           AND id_pais_operacion = ?"
    );
    $stmt->bind_param($tipos, ...$parametros);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return (int) ($fila['total'] ?? 0) === count($idsGestores);
}

function servicioGestoresGestorHabilitado(
    mysqli $conn,
    int $idServicio,
    int $idGestor,
    int $idPaisOperacion
): bool {
    if (!servicioGestoresModuloDisponible($conn)) {
        return false;
    }

    $stmt = $conn->prepare(
        "SELECT 1
         FROM servicio_gestores AS sg
         INNER JOIN servicios AS s ON s.id_servicio = sg.id_servicio
         INNER JOIN usuarios AS u ON u.id_usuario = sg.id_usuario
         WHERE sg.id_servicio = ?
           AND sg.id_usuario = ?
           AND sg.estado = 'activo'
           AND s.id_pais_operacion = ?
           AND u.id_rol = 2
           AND u.estado = 'activo'
           AND u.id_pais_operacion = ?
         LIMIT 1"
    );
    $stmt->bind_param(
        'iiii',
        $idServicio,
        $idGestor,
        $idPaisOperacion,
        $idPaisOperacion
    );
    $stmt->execute();
    $stmt->store_result();
    $habilitado = $stmt->num_rows === 1;
    $stmt->close();

    if ($habilitado) {
        return true;
    }

    /*
     * Compatibilidad con servicios creados antes de 011_servicio_gestores:
     * si todavía no existe ninguna relación activa, el gestor predeterminado
     * de servicios sigue siendo válido para una reasignación. En cuanto haya
     * relaciones activas, esa lista explícita vuelve a ser la única fuente.
     */
    $stmt = $conn->prepare(
        "SELECT s.id_gestor
         FROM servicios AS s
         WHERE s.id_servicio = ?
           AND s.id_pais_operacion = ?
           AND s.id_gestor = ?
           AND NOT EXISTS (
                SELECT 1
                FROM servicio_gestores AS sg
                WHERE sg.id_servicio = s.id_servicio
                  AND sg.estado = 'activo'
           )
         LIMIT 1"
    );
    $stmt->bind_param('iii', $idServicio, $idPaisOperacion, $idGestor);
    $stmt->execute();
    $stmt->store_result();
    $habilitado = $stmt->num_rows === 1;
    $stmt->close();

    return $habilitado;
}

/**
 * Sincroniza la lista habilitada y garantiza que el gestor predeterminado
 * permanezca habilitado. Debe invocarse dentro de la transacción del servicio.
 *
 * @param array<int, int> $idsGestores
 */
function servicioGestoresSincronizar(
    mysqli $conn,
    int $idServicio,
    int $idGestorPredeterminado,
    array $idsGestores,
    int $idAdministrador,
    int $idPaisOperacion
): void {
    if (!servicioGestoresModuloDisponible($conn)) {
        throw new RuntimeException(
            'Falta la migración 011_servicio_gestores.sql.'
        );
    }

    if ($idServicio < 1 || $idGestorPredeterminado < 1) {
        throw new RuntimeException('El servicio y su gestor predeterminado son obligatorios.');
    }

    $idsGestores[] = $idGestorPredeterminado;
    $idsGestores = array_values(array_unique(array_filter(
        array_map('intval', $idsGestores),
        static function (int $id): bool {
            return $id > 0;
        }
    )));

    if (!servicioGestoresTodosActivos($conn, $idsGestores, $idPaisOperacion)) {
        throw new RuntimeException('Uno o más gestores no están activos en el país actual.');
    }

    $stmtDeshabilitar = $conn->prepare(
        "UPDATE servicio_gestores
         SET estado = 'inhabilitado', id_usuario_asigno = ?
         WHERE id_servicio = ?"
    );
    $stmtDeshabilitar->bind_param('ii', $idAdministrador, $idServicio);
    $stmtDeshabilitar->execute();
    $stmtDeshabilitar->close();

    $stmtHabilitar = $conn->prepare(
        "INSERT INTO servicio_gestores
            (id_servicio, id_usuario, estado, fecha_asignacion, id_usuario_asigno)
         VALUES (?, ?, 'activo', NOW(), ?)
         ON DUPLICATE KEY UPDATE
            estado = 'activo',
            fecha_asignacion = NOW(),
            id_usuario_asigno = VALUES(id_usuario_asigno)"
    );

    foreach ($idsGestores as $idGestor) {
        $stmtHabilitar->bind_param(
            'iii',
            $idServicio,
            $idGestor,
            $idAdministrador
        );
        $stmtHabilitar->execute();
    }
    $stmtHabilitar->close();
}

/**
 * Mantiene un único gestor activo por servicio. Las relaciones anteriores se
 * conservan inhabilitadas para no alterar la tabla ni los datos históricos.
 */
function servicioGestoresAsignarUnico(
    mysqli $conn,
    int $idServicio,
    int $idGestor,
    int $idAdministrador,
    int $idPaisOperacion
): void {
    servicioGestoresSincronizar(
        $conn,
        $idServicio,
        $idGestor,
        [],
        $idAdministrador,
        $idPaisOperacion
    );
}

/** @return array<int, array<int, bool>> */
function servicioGestoresActivosPorServicio(
    mysqli $conn,
    int $idPaisOperacion
): array {
    if (!servicioGestoresModuloDisponible($conn)) {
        return [];
    }

    $stmt = $conn->prepare(
        "SELECT sg.id_servicio, sg.id_usuario
         FROM servicio_gestores AS sg
         INNER JOIN servicios AS s ON s.id_servicio = sg.id_servicio
         INNER JOIN usuarios AS u ON u.id_usuario = sg.id_usuario
         WHERE sg.estado = 'activo'
           AND s.id_pais_operacion = ?
           AND u.id_rol = 2
           AND u.estado = 'activo'
           AND u.id_pais_operacion = ?"
    );
    $stmt->bind_param('ii', $idPaisOperacion, $idPaisOperacion);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $salida = [];

    while ($fila = $resultado->fetch_assoc()) {
        $salida[(int) $fila['id_servicio']][(int) $fila['id_usuario']] = true;
    }
    $stmt->close();

    /* Respaldar servicios antiguos que aún no tienen relaciones activas. */
    $stmt = $conn->prepare(
        "SELECT s.id_servicio, s.id_gestor AS id_usuario
         FROM servicios AS s
         INNER JOIN usuarios AS u ON u.id_usuario = s.id_gestor
         WHERE s.id_pais_operacion = ?
           AND s.id_gestor IS NOT NULL
           AND u.id_rol = 2
           AND u.estado = 'activo'
           AND u.id_pais_operacion = ?
           AND NOT EXISTS (
                SELECT 1
                FROM servicio_gestores AS sg
                WHERE sg.id_servicio = s.id_servicio
                  AND sg.estado = 'activo'
           )"
    );
    $stmt->bind_param('ii', $idPaisOperacion, $idPaisOperacion);
    $stmt->execute();
    $resultado = $stmt->get_result();
    while ($fila = $resultado->fetch_assoc()) {
        $salida[(int) $fila['id_servicio']][(int) $fila['id_usuario']] = true;
    }
    $stmt->close();

    return $salida;
}
