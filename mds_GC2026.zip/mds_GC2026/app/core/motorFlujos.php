<?php
declare(strict_types=1);

if (!function_exists('compatStrStartsWith')) {
    function compatStrStartsWith($haystack, $needle): bool {
        return $needle === '' || strpos((string)$haystack, (string)$needle) === 0;
    }
}

if (!function_exists('compatStrContains')) {
    function compatStrContains($haystack, $needle): bool {
        return strpos((string)$haystack, (string)$needle) !== false;
    }
}

require_once __DIR__ . '/calendarioLaboral.php';
require_once __DIR__ . '/correoN8n.php';
require_once __DIR__ . '/almacenamiento.php';
require_once __DIR__ . '/matrizPrioridad.php';
require_once __DIR__ . '/servicioGestores.php';
require_once __DIR__ . '/camposExtras.php';

/**
 * Motor central de tickets con casos padre e hijo.
 *
 * Cada etapa oficial del flujo conserva una conversación independiente entre
 * el solicitante y el gestor asignado. Los casos hijos creados por derivación
 * mantienen una conversación interna separada entre sus gestores. Al crear
 * hijos se pausa el SLA del padre, los hermanos trabajan en paralelo y el
 * padre se reanuda cuando todos finalizan.
 */

/** @return array<string,array<string,bool>> */
function flujoMapaEsquema(mysqli $conn): array
{
    static $cache = [];
    $clave = spl_object_id($conn);

    if (isset($cache[$clave])) {
        return $cache[$clave];
    }

    $mapa = [];
    $resultado = $conn->query(
        "SELECT TABLE_NAME, COLUMN_NAME
         FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()"
    );

    if ($resultado instanceof mysqli_result) {
        while ($fila = $resultado->fetch_assoc()) {
            $tabla = (string) ($fila['TABLE_NAME'] ?? '');
            $columna = (string) ($fila['COLUMN_NAME'] ?? '');
            if ($tabla !== '' && $columna !== '') {
                $mapa[$tabla][$columna] = true;
            }
        }
    }

    return $cache[$clave] = $mapa;
}

function flujoTablaExiste(mysqli $conn, string $tabla): bool
{

    if (!preg_match('/^[A-Za-z0-9_]+$/', $tabla)) {
        return false;
    }

    $mapa = flujoMapaEsquema($conn);

    return isset($mapa[$tabla]);
}

function flujoColumnaExiste(
    mysqli $conn,
    string $tabla,
    string $columna
): bool {
    if (
        !preg_match('/^[A-Za-z0-9_]+$/', $tabla)
        || !preg_match('/^[A-Za-z0-9_]+$/', $columna)
    ) {
        return false;
    }

    $mapa = flujoMapaEsquema($conn);

    return isset($mapa[$tabla][$columna]);
}

function flujoModuloInstalado(mysqli $conn): bool
{
    foreach (
        [
            'procesos',
            'proceso_etapas',
            'proceso_etapa_checklist',
            'ticket_etapas',
            'ticket_etapa_checklist',
            'notificaciones',
            'ticket_notificaciones_email_preferencias',
            'servicio_gestores',
        ] as $tabla
    ) {
        if (!flujoTablaExiste($conn, $tabla)) {
            return false;
        }
    }

    return flujoColumnaExiste($conn, 'tickets', 'id_proceso')
        && flujoColumnaExiste($conn, 'tickets', 'id_etapa_actual')
        && flujoColumnaExiste($conn, 'tickets', 'estado_flujo')
        && flujoColumnaExiste($conn, 'servicios', 'id_gestor')
        && flujoColumnaExiste(
            $conn,
            'solicitud_comunicaciones',
            'id_ticket_etapa'
        )
        && flujoColumnaExiste(
            $conn,
            'solicitud_adjuntos',
            'id_ticket_etapa'
        )
        && flujoColumnaExiste(
            $conn,
            'solicitud_calificaciones',
            'id_ticket_etapa'
        )
        && flujoColumnaExiste(
            $conn,
            'solicitud_historial',
            'id_ticket_etapa'
        )
        && flujoColumnaExiste(
            $conn,
            'ticket_etapas',
            'id_ticket_etapa_padre'
        )
        && flujoColumnaExiste($conn, 'ticket_etapas', 'nivel')
        && flujoColumnaExiste($conn, 'ticket_etapas', 'sla_minutos_total')
        && flujoColumnaExiste(
            $conn,
            'ticket_etapas',
            'sla_minutos_consumidos'
        )
        && flujoColumnaExiste(
            $conn,
            'ticket_etapas',
            'fecha_ultima_reanudacion'
        )
        && flujoColumnaExiste($conn, 'ticket_etapas', 'fecha_pausa')
        && flujoColumnaExiste($conn, 'ticket_etapas', 'cantidad_pausas')
        && flujoColumnaExiste($conn, 'ticket_etapas', 'creado_por')
        && flujoColumnaExiste($conn, 'ticket_etapas', 'motivo_derivacion');
}

function flujoModuloSolucionesInstalado(mysqli $conn): bool
{
    return flujoTablaExiste($conn, 'soluciones_servicio')
        && flujoColumnaExiste($conn, 'ticket_etapas', 'id_solucion')
        && flujoColumnaExiste($conn, 'ticket_etapas', 'solucion_nombre');
}

function flujoModuloCalificacionDetalladaInstalado(mysqli $conn): bool
{
    return flujoTablaExiste($conn, 'solicitud_calificaciones')
        && flujoColumnaExiste(
            $conn,
            'solicitud_calificaciones',
            'calificacion_area'
        )
        && flujoColumnaExiste(
            $conn,
            'solicitud_calificaciones',
            'calificacion_tiempo'
        );
}

function flujoModuloAprobacionCasosInstalado(mysqli $conn): bool
{
    foreach (
        [
            'fecha_marcado_listo',
            'minutos_hasta_listo',
            'resultado_sla_listo',
            'marcado_listo_por',
            'fecha_ultima_reapertura',
            'cantidad_reaperturas',
        ] as $columna
    ) {
        if (!flujoColumnaExiste($conn, 'ticket_etapas', $columna)) {
            return false;
        }
    }

    return flujoModuloCalificacionDetalladaInstalado($conn)
        && flujoColumnaExiste(
            $conn,
            'ticket_etapas',
            'solicita_cierre_definitivo'
        )
        && flujoColumnaExiste(
            $conn,
            'solicitud_calificaciones',
            'tipo_calificacion'
        );
}

function flujoAhora(): string
{
    return (new DateTimeImmutable('now', calendarioZonaHoraria()))
        ->format('Y-m-d H:i:s');
}

function flujoRegistrarHistorial(
    mysqli $conn,
    int $idTicket,
    ?int $idUsuario,
    string $accion,
    string $detalle = '',
    ?int $idTicketEtapa = null,
    bool $programarCorreo = true
): void {
    $stmt = $conn->prepare(
        "INSERT INTO solicitud_historial
            (id_ticket, id_ticket_etapa, id_usuario, accion, detalle)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param(
        'iiiss',
        $idTicket,
        $idTicketEtapa,
        $idUsuario,
        $accion,
        $detalle
    );
    $stmt->execute();
    $idHistorial = (int) $conn->insert_id;
    $stmt->close();

    if ($programarCorreo) {
        flujoProgramarCorreoHistorial($conn, $idHistorial);
    }
}

/**
 * Difiere el correo hasta el cierre de la petición. Así solo se notifica un
 * evento que realmente quedó confirmado por la transacción de la acción.
 */
function flujoProgramarCorreoHistorial(
    mysqli $conn,
    int $idHistorial
): void {
    static $despachadorRegistrado = false;

    if ($idHistorial < 1 || seguridadEsUsuarioPrueba()) {
        return;
    }

    // Evita registrar un trabajo de cierre cuando todos los posibles
    // destinatarios desactivaron expresamente el correo para este caso.
    if (flujoCorreoHistorialDesactivadoParaTodos($conn, $idHistorial)) {
        return;
    }

    if (!isset($GLOBALS['mesa_correos_historial'])) {
        $GLOBALS['mesa_correos_historial'] = [];
    }

    $clave = spl_object_id($conn) . ':' . $idHistorial;
    $GLOBALS['mesa_correos_historial'][$clave] = [$conn, $idHistorial];

    if (!$despachadorRegistrado) {
        register_shutdown_function(
            'flujoDespacharCorreosHistorialPendientes'
        );
        $despachadorRegistrado = true;
    }
}

function flujoCorreoHistorialDesactivadoParaTodos(
    mysqli $conn,
    int $idHistorial
): bool {
    if (
        $idHistorial < 1
        || !flujoTablaExiste($conn, 'ticket_notificaciones_email_preferencias')
    ) {
        return false;
    }

    $stmt = $conn->prepare(
        "SELECT
            t.id_usuario AS id_solicitante,
            COALESCE(te.id_gestor, t.id_tecnico) AS id_gestor,
            h.id_usuario AS id_actor,
            preferencia_solicitante.habilitada AS solicitante_habilitada,
            preferencia_gestor.habilitada AS gestor_habilitada,
            te.id_ticket_etapa_padre,
            te.nivel,
            h.accion
         FROM solicitud_historial AS h
         INNER JOIN tickets AS t ON t.id_ticket = h.id_ticket
         LEFT JOIN ticket_etapas AS te
            ON te.id_ticket = t.id_ticket
           AND te.id_ticket_etapa = COALESCE(
                h.id_ticket_etapa,
                t.id_etapa_actual
           )
         LEFT JOIN ticket_notificaciones_email_preferencias
            AS preferencia_solicitante
            ON preferencia_solicitante.id_ticket = t.id_ticket
           AND preferencia_solicitante.id_usuario = t.id_usuario
         LEFT JOIN ticket_notificaciones_email_preferencias
            AS preferencia_gestor
            ON preferencia_gestor.id_ticket = t.id_ticket
           AND preferencia_gestor.id_usuario = COALESCE(
                te.id_gestor,
                t.id_tecnico
           )
         WHERE h.id_historial = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $idHistorial);
    $stmt->execute();
    $evento = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$evento) {
        return false;
    }

    $idActor = (int) ($evento['id_actor'] ?? 0);
    $idGestor = (int) ($evento['id_gestor'] ?? 0);
    $gestorDesactivado = $idGestor < 1
        || $idGestor === $idActor
        || (
            $evento['gestor_habilitada'] !== null
            && (int) $evento['gestor_habilitada'] === 0
        );
    $accion = trim((string) ($evento['accion'] ?? ''));
    $idSolicitante = (int) ($evento['id_solicitante'] ?? 0);
    $solicitanteNoElegible = $idSolicitante < 1
        || $idSolicitante === $idActor
        || (int) ($evento['id_ticket_etapa_padre'] ?? 0) > 0
        || (int) ($evento['nivel'] ?? 0) > 0
        || in_array(
            $accion,
            [
                'Derivación creada',
                'Derivación múltiple creada',
                'Caso padre reanudado',
            ],
            true
        );
    $solicitanteDesactivado = $solicitanteNoElegible
        || (
            $evento['solicitante_habilitada'] !== null
            && (int) $evento['solicitante_habilitada'] === 0
        );

    return $gestorDesactivado && $solicitanteDesactivado;
}

function flujoDespacharCorreosHistorialPendientes(): void
{
    $pendientes = $GLOBALS['mesa_correos_historial'] ?? [];
    $GLOBALS['mesa_correos_historial'] = [];

    if (!is_array($pendientes)) {
        return;
    }

    /*
     * Libera cuanto antes la sesión y, bajo PHP-FPM, entrega la respuesta al
     * navegador antes de iniciar los avisos externos. De esta forma el cambio
     * de estado no queda visualmente esperando al proveedor de correo.
     */
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    }

    foreach ($pendientes as $pendiente) {
        if (
            !is_array($pendiente)
            || !isset($pendiente[0], $pendiente[1])
            || !$pendiente[0] instanceof mysqli
        ) {
            continue;
        }

        try {
            flujoEnviarCorreoHistorial(
                $pendiente[0],
                (int) $pendiente[1],
                true
            );
        } catch (Throwable $e) {
            error_log(
                'No fue posible preparar la notificación del histórico: '
                . $e->getMessage()
            );
        }
    }
}

function flujoTextoCorreo($valor): string
{
    return htmlspecialchars(
        (string) $valor,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function flujoUrlCorreoCaso(
    int $idTicket,
    int $idNodo,
    string $tipoDestinatario
): string {
    if ($idTicket < 1 || PHP_SAPI === 'cli') {
        return '';
    }

    $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
    $script = str_replace(
        '\\',
        '/',
        (string) ($_SERVER['SCRIPT_NAME'] ?? '')
    );

    if (
        $host === ''
        || preg_match('/^[A-Za-z0-9.\-\[\]:]+$/', $host) !== 1
        || $script === ''
    ) {
        return '';
    }

    $rutaBase = rtrim(str_replace('\\', '/', dirname($script)), '/');

    if ($rutaBase === '.' || $rutaBase === '') {
        $rutaBase = '';
    }

    $esHttps = !empty($_SERVER['HTTPS'])
        && strtolower((string) $_SERVER['HTTPS']) !== 'off';
    $esquema = $esHttps ? 'https' : 'http';

    if ($tipoDestinatario === 'solicitante') {
        $archivo = 'panelSolicitante.php';
        $parametros = [
            'vista' => 'tickets',
            'id_ticket' => $idTicket,
        ];
    } else {
        $archivo = 'flujoTicket.php';
        $parametros = ['id_ticket' => $idTicket];

        if ($idNodo > 0) {
            $parametros['id_nodo'] = $idNodo;
            $parametros['id_chat'] = $idNodo;
        }
    }

    return $esquema
        . '://'
        . $host
        . $rutaBase
        . '/'
        . $archivo
        . '?'
        . http_build_query($parametros);
}

function flujoEnviarCorreoHistorial(
    mysqli $conn,
    int $idHistorial,
    bool $sinEspera = false
): void {
    if ($idHistorial < 1) {
        return;
    }

    $stmt = $conn->prepare(
        "SELECT
            h.id_historial,
            h.id_ticket,
            h.id_ticket_etapa,
            h.id_usuario AS id_actor,
            h.accion,
            h.detalle,
            h.creado_en,
            t.titulo AS ticket_titulo,
            t.id_usuario AS id_solicitante,
            t.id_tecnico AS id_gestor_heredado,
            COALESCE(preferencia_solicitante.habilitada, 1)
                AS notificar_solicitante,
            COALESCE(preferencia_gestor.habilitada, 1)
                AS notificar_gestor,
            solicitante.nombre AS solicitante_nombre,
            solicitante.email AS solicitante_email,
            solicitante.estado AS solicitante_estado,
            actor.nombre AS actor_nombre,
            te.id_ticket_etapa AS id_nodo,
            te.id_ticket_etapa_padre,
            te.nivel,
            te.id_gestor AS id_gestor_etapa,
            te.catalogo_nombre,
            te.servicio_nombre,
            gestor.nombre AS gestor_nombre,
            gestor.email AS gestor_email,
            gestor.estado AS gestor_estado
         FROM solicitud_historial AS h
         INNER JOIN tickets AS t ON t.id_ticket = h.id_ticket
         LEFT JOIN ticket_etapas AS te
            ON te.id_ticket = t.id_ticket
           AND te.id_ticket_etapa = COALESCE(
                h.id_ticket_etapa,
                t.id_etapa_actual
           )
         LEFT JOIN usuarios AS solicitante
            ON solicitante.id_usuario = t.id_usuario
         LEFT JOIN usuarios AS actor
            ON actor.id_usuario = h.id_usuario
         LEFT JOIN usuarios AS gestor
            ON gestor.id_usuario = COALESCE(te.id_gestor, t.id_tecnico)
         LEFT JOIN ticket_notificaciones_email_preferencias
            AS preferencia_solicitante
            ON preferencia_solicitante.id_ticket = t.id_ticket
           AND preferencia_solicitante.id_usuario = t.id_usuario
         LEFT JOIN ticket_notificaciones_email_preferencias
            AS preferencia_gestor
            ON preferencia_gestor.id_ticket = t.id_ticket
           AND preferencia_gestor.id_usuario = COALESCE(
                te.id_gestor,
                t.id_tecnico
           )
         WHERE h.id_historial = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $idHistorial);
    $stmt->execute();
    $evento = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$evento) {
        // La transacción que creó el histórico no fue confirmada.
        return;
    }

    $idTicket = (int) $evento['id_ticket'];
    $idNodo = (int) ($evento['id_nodo'] ?? 0);
    $idSolicitante = (int) ($evento['id_solicitante'] ?? 0);
    $idGestor = (int) (
        $evento['id_gestor_etapa']
        ?? $evento['id_gestor_heredado']
        ?? 0
    );
    $esEtapaPublica = $idNodo < 1 || (
        (int) ($evento['id_ticket_etapa_padre'] ?? 0) === 0
        && (int) ($evento['nivel'] ?? 0) === 0
    );
    $accionEvento = trim((string) ($evento['accion'] ?? ''));
    $esEventoInternoSolicitante = $accionEvento === 'Caso padre reanudado';
    $esEventoDerivacion = in_array(
        $accionEvento,
        [
            'Derivación creada',
            'Derivación múltiple creada',
        ],
        true
    );
    $destinatarios = [];

    // El gestor solo es elegible si el caso del evento sigue asignado a él.
    if (
        $idGestor > 0
        && $idGestor !== (int) ($evento['id_actor'] ?? 0)
        && (int) ($evento['notificar_gestor'] ?? 1) === 1
        && (string) ($evento['gestor_estado'] ?? '') === 'activo'
        && filter_var(
            (string) ($evento['gestor_email'] ?? ''),
            FILTER_VALIDATE_EMAIL
        )
    ) {
        $destinatarios[strtolower((string) $evento['gestor_email'])] = [
            'nombre' => (string) ($evento['gestor_nombre'] ?? 'Gestor'),
            'email' => (string) $evento['gestor_email'],
            'tipo' => 'gestor',
        ];
    }

    // El solicitante recibe solo eventos públicos y únicamente por elección.
    if (
        ($esEtapaPublica || $esEventoDerivacion)
        && !$esEventoInternoSolicitante
        && (int) ($evento['notificar_solicitante'] ?? 0) === 1
        && $idSolicitante > 0
        && $idSolicitante !== (int) ($evento['id_actor'] ?? 0)
        && (string) ($evento['solicitante_estado'] ?? '') === 'activo'
        && filter_var(
            (string) ($evento['solicitante_email'] ?? ''),
            FILTER_VALIDATE_EMAIL
        )
    ) {
        $destinatarios[
            strtolower((string) $evento['solicitante_email'])
        ] = [
            'nombre' => (string) (
                $evento['solicitante_nombre'] ?? 'Solicitante'
            ),
            'email' => (string) $evento['solicitante_email'],
            'tipo' => 'solicitante',
        ];
    }

    if (!$destinatarios) {
        return;
    }

    $accion = $accionEvento !== '' ? $accionEvento : 'Actualización';
    $detalle = trim((string) ($evento['detalle'] ?? ''));
    $actor = trim((string) ($evento['actor_nombre'] ?? 'Sistema'));
    $tituloTicket = trim((string) ($evento['ticket_titulo'] ?? 'Solicitud'));
    $area = trim((string) ($evento['catalogo_nombre'] ?? ''));
    $servicio = trim((string) ($evento['servicio_nombre'] ?? ''));
    $contexto = trim($area . ($area !== '' && $servicio !== '' ? ' / ' : '') . $servicio);
    $asunto = "Caso #{$idTicket} | {$accion}";

    foreach ($destinatarios as $destinatario) {
        $nombreSeguro = flujoTextoCorreo($destinatario['nombre']);
        $accionSegura = flujoTextoCorreo($accion);
        $detalleSeguro = nl2br(flujoTextoCorreo($detalle));
        $actorSeguro = flujoTextoCorreo($actor);
        $tituloSeguro = flujoTextoCorreo($tituloTicket);
        $contextoSeguro = flujoTextoCorreo($contexto);
        $fechaCorreo = DateTimeImmutable::createFromFormat(
            'Y-m-d H:i:s',
            (string) $evento['creado_en'],
            calendarioZonaHoraria()
        );
        $fechaLegible = $fechaCorreo
            ? $fechaCorreo->format('d/m/Y · H:i')
            : (string) $evento['creado_en'];
        $fechaSegura = flujoTextoCorreo($fechaLegible);
        $tipoDestinatario = (string) $destinatario['tipo'];
        $rolSeguro = $tipoDestinatario === 'gestor'
            ? 'Gestor asignado'
            : 'Solicitante';
        $introduccion = $tipoDestinatario === 'gestor'
            ? 'Se registró una nueva acción en un caso asignado a su gestión.'
            : 'Se registró una nueva acción pública en su caso.';
        $enlaceCaso = flujoUrlCorreoCaso(
            $idTicket,
            $idNodo,
            $tipoDestinatario
        );
        $enlaceCasoSeguro = flujoTextoCorreo($enlaceCaso);
        $detalleHtml = $detalle !== ''
            ? '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:18px;border:1px solid #dbe5f0;border-radius:10px;background:#f7f9fc"><tr><td style="padding:16px 18px"><p style="margin:0 0 7px;color:#52667a;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase">Detalle de la acción</p><div style="color:#243b53;font-size:14px;line-height:1.6">'
                . $detalleSeguro . '</div></td></tr></table>'
            : '';
        $contextoHtml = $contexto !== ''
            ? '<tr><td style="padding:7px 0;color:#64788b;font-size:13px;width:145px">Proceso y servicio</td><td style="padding:7px 0;color:#1d3550;font-size:13px;font-weight:700">'
                . $contextoSeguro . '</td></tr>'
            : '';
        $botonHtml = $enlaceCaso !== ''
            ? '<table role="presentation" cellspacing="0" cellpadding="0" style="margin:22px 0 0"><tr><td style="border-radius:8px;background:#1769aa"><a href="'
                . $enlaceCasoSeguro
                . '" style="display:inline-block;padding:12px 19px;color:#ffffff;font-size:13px;font-weight:700;text-decoration:none">Consultar caso en <span style="color:#000000;background:#ffffff;padding:1px 3px;border-radius:2px">SMART</span><span style="color:#1769c2;background:#ffffff;padding:1px 3px;border-radius:2px">DESK</span></a></td></tr></table>'
            : '';
        $html = <<<HTML
<!doctype html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#edf2f7;font-family:Arial,Helvetica,sans-serif;color:#1d3550">
  <div style="display:none;max-height:0;overflow:hidden;opacity:0">Nueva actualización registrada en el Caso #{$idTicket}: {$accionSegura}</div>
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="width:100%;background:#edf2f7">
    <tr><td align="center">
      <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="width:100%;max-width:640px;margin:28px 12px;background:#ffffff;border:1px solid #d7e1ec;border-radius:14px;overflow:hidden;box-shadow:0 8px 24px rgba(31,55,80,.08)">
        <tr>
          <td style="padding:0;background:#0d355f;height:6px;font-size:1px;line-height:1px">&nbsp;</td>
        </tr>
        <tr>
          <td style="padding:20px 26px;border-bottom:1px solid #e3eaf2;background:#ffffff">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0">
              <tr>
                <td width="48" valign="middle"><div style="width:40px;height:40px;line-height:40px;border-radius:9px;background:#1769aa;color:#ffffff;font-size:14px;font-weight:800;text-align:center">MS</div></td>
                <td valign="middle"><p style="margin:0;font-family:'Orbitron','Arial Black',sans-serif;font-size:17px;font-weight:700;letter-spacing:.01em"><span style="color:#000000">SMART</span><span style="color:#1769c2">DESK</span></p><p style="margin:3px 0 0;color:#6b7f92;font-size:11px;letter-spacing:.06em;text-transform:uppercase">Gestión y seguimiento de casos</p></td>
                <td align="right" valign="middle"><span style="display:inline-block;padding:6px 10px;border-radius:999px;background:#eaf3fb;color:#1769aa;font-size:11px;font-weight:700">Caso #{$idTicket}</span></td>
              </tr>
            </table>
          </td>
        </tr>
        <tr><td style="padding:28px 26px 26px">
          <p style="margin:0 0 8px;color:#1769aa;font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase">{$rolSeguro}</p>
          <h1 style="margin:0 0 12px;color:#0d355f;font-size:24px;line-height:1.25">Nueva actualización del caso</h1>
          <p style="margin:0 0 5px;color:#243b53;font-size:14px;line-height:1.6">Hola, <strong>{$nombreSeguro}</strong>.</p>
          <p style="margin:0;color:#52667a;font-size:14px;line-height:1.6">{$introduccion}</p>

          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-top:20px;border-top:1px solid #e3eaf2;border-bottom:1px solid #e3eaf2">
            <tr><td style="padding:16px 0 8px;color:#64788b;font-size:13px;width:145px">Acción registrada</td><td style="padding:16px 0 8px;color:#0d355f;font-size:15px;font-weight:800">{$accionSegura}</td></tr>
            <tr><td style="padding:7px 0;color:#64788b;font-size:13px">Asunto del caso</td><td style="padding:7px 0;color:#1d3550;font-size:13px;font-weight:700">{$tituloSeguro}</td></tr>
            {$contextoHtml}
            <tr><td style="padding:7px 0;color:#64788b;font-size:13px">Registrado por</td><td style="padding:7px 0;color:#1d3550;font-size:13px;font-weight:700">{$actorSeguro}</td></tr>
            <tr><td style="padding:7px 0 16px;color:#64788b;font-size:13px">Fecha y hora</td><td style="padding:7px 0 16px;color:#1d3550;font-size:13px;font-weight:700">{$fechaSegura}</td></tr>
          </table>

          {$detalleHtml}
          {$botonHtml}
          <p style="margin:20px 0 0;color:#6b7f92;font-size:12px;line-height:1.55">Puede activar o desactivar estas notificaciones desde el detalle del caso.</p>
        </td></tr>
        <tr><td style="padding:17px 26px;border-top:1px solid #e3eaf2;background:#f7f9fc"><p style="margin:0;color:#75889a;font-size:11px;line-height:1.5">Mensaje automático de <span style="color:#000000;font-family:'Orbitron','Arial Black',sans-serif;font-weight:700">SMART</span><span style="color:#1769c2;font-family:'Orbitron','Arial Black',sans-serif;font-weight:700">DESK</span>. Por favor, no responda directamente a este correo.</p></td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;

        try {
            if ($sinEspera) {
                correoN8nEnviarSinEspera(
                    (string) $destinatario['email'],
                    $asunto,
                    $html,
                    'ticket_update'
                );
            } else {
                correoN8nEnviar(
                    (string) $destinatario['email'],
                    $asunto,
                    $html,
                    'ticket_update'
                );
            }
        } catch (Throwable $e) {
            error_log(
                "No fue posible enviar la notificación del Caso {$idTicket} "
                . 'a ' . $destinatario['tipo'] . ': ' . $e->getMessage()
            );
        }
    }
}

function flujoNotificacionesEmailHabilitadas(
    mysqli $conn,
    int $idTicket,
    int $idUsuario
): bool {
    if ($idTicket < 1 || $idUsuario < 1) {
        return false;
    }

    $stmt = $conn->prepare(
        "SELECT habilitada
         FROM ticket_notificaciones_email_preferencias
         WHERE id_ticket = ? AND id_usuario = ?
         LIMIT 1"
    );
    $stmt->bind_param('ii', $idTicket, $idUsuario);
    $stmt->execute();
    $preferencia = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // La ausencia de preferencia significa activado por defecto.
    return !$preferencia || (int) $preferencia['habilitada'] === 1;
}

function flujoPuedeConfigurarNotificacionesEmail(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol,
    int $idTicketEtapa = 0
): bool {
    if ($idTicket < 1 || $idUsuario < 1) {
        return false;
    }

    if ($rol === 3) {
        $stmt = $conn->prepare(
            "SELECT 1
             FROM tickets
             WHERE id_ticket = ? AND id_usuario = ?
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idTicket, $idUsuario);
    } elseif ($rol === 2 && $idTicketEtapa > 0) {
        $stmt = $conn->prepare(
            "SELECT 1
             FROM ticket_etapas
             WHERE id_ticket = ?
               AND id_ticket_etapa = ?
               AND id_gestor = ?
             LIMIT 1"
        );
        $stmt->bind_param(
            'iii',
            $idTicket,
            $idTicketEtapa,
            $idUsuario
        );
    } else {
        return false;
    }

    $stmt->execute();
    $stmt->store_result();
    $permitido = $stmt->num_rows === 1;
    $stmt->close();

    return $permitido;
}

function flujoConfigurarNotificacionesEmail(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol,
    bool $habilitada,
    int $idTicketEtapa = 0
): void {
    if (!flujoPuedeConfigurarNotificacionesEmail(
        $conn,
        $idTicket,
        $idUsuario,
        $rol,
        $idTicketEtapa
    )) {
        throw new RuntimeException(
            'Solo puede configurar correos de un caso propio o asignado.'
        );
    }

    $valor = $habilitada ? 1 : 0;
    $stmt = $conn->prepare(
        "INSERT INTO ticket_notificaciones_email_preferencias
            (id_ticket, id_usuario, habilitada)
         VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE
            habilitada = VALUES(habilitada),
            actualizada_en = CURRENT_TIMESTAMP"
    );
    $stmt->bind_param('iii', $idTicket, $idUsuario, $valor);
    $stmt->execute();
    $stmt->close();
}

function flujoNotificar(
    mysqli $conn,
    int $idUsuario,
    int $idTicket,
    ?int $idTicketEtapa,
    string $titulo,
    string $mensaje
): void {
    if ($idUsuario < 1 || seguridadEsUsuarioPrueba()) {
        return;
    }

    $stmt = $conn->prepare(
        "INSERT INTO notificaciones
            (
                id_usuario,
                id_ticket,
                id_ticket_etapa,
                titulo,
                mensaje
            )
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param(
        'iiiss',
        $idUsuario,
        $idTicket,
        $idTicketEtapa,
        $titulo,
        $mensaje
    );
    $stmt->execute();
    $stmt->close();
}

function flujoEsNotificacionConversacion(string $titulo, string $mensaje): bool
{
    return compatStrStartsWith(trim($titulo), 'Nuevo mensaje en ')
        || stripos(trim($mensaje), 'chat privado') !== false;
}

/**
 * Marca como vistas únicamente las notificaciones cuyo contenido ya se mostró.
 * Las novedades del caso y los mensajes conservan estados independientes.
 */
function flujoMarcarNotificacionesContenidoVisto(
    mysqli $conn,
    int $idUsuario,
    int $idTicket,
    bool $conversacion,
    ?int $idTicketEtapa = null
): int {
    if ($idUsuario < 1 || $idTicket < 1) {
        return 0;
    }

    $condicionConversacion = "(
        n.titulo LIKE 'Nuevo mensaje en %'
        OR n.mensaje LIKE '%chat privado%'
    )";
    $condicionTipo = $conversacion
        ? $condicionConversacion
        : "NOT {$condicionConversacion}";
    $filtrarEtapa = ($idTicketEtapa ?? 0) > 0;
    $sql = "UPDATE notificaciones AS n
            SET leida = 1,
                leida_en = COALESCE(n.leida_en, NOW())
            WHERE n.id_usuario = ?
              AND n.id_ticket = ?
              AND n.leida = 0
              AND {$condicionTipo}";

    if ($conversacion && $filtrarEtapa) {
        $sql .= ' AND n.id_ticket_etapa = ?';
    } elseif (!$conversacion) {
        $sql .= $filtrarEtapa
            ? " AND (n.titulo NOT IN ('Derivación reabierta', 'Caso reabierto') OR n.id_ticket_etapa = ?)"
            : " AND n.titulo NOT IN ('Derivación reabierta', 'Caso reabierto')";
    }

    $stmt = $conn->prepare($sql);
    if ($filtrarEtapa) {
        $etapa = (int) $idTicketEtapa;
        $stmt->bind_param('iii', $idUsuario, $idTicket, $etapa);
    } else {
        $stmt->bind_param('ii', $idUsuario, $idTicket);
    }
    $stmt->execute();
    $actualizadas = max(0, $stmt->affected_rows);
    $stmt->close();

    return $actualizadas;
}

function flujoSlaMinutosTotales(
    int $tiempo,
    string $unidad,
    ?mysqli $conn = null
): int
{
    if ($tiempo < 1) {
        return 0;
    }

    $minutosDia = $conn !== null
        ? calendarioMinutosDiaSla($conn)
        : CALENDARIO_MINUTOS_DIA_SLA;

    return (fn ($__mesaMatchValue6) => (($__mesaMatchValue6 === ('dias')) ? ($tiempo * $minutosDia) : ((($__mesaMatchValue6 === ('horas')) ? ($tiempo * 60) : ($tiempo)))))($unidad);
}

function flujoSlaMinutosTotalesNodo(array $nodo, ?mysqli $conn = null): int
{
    $tiempo = (int) ($nodo['sla_tiempo'] ?? 0);
    $unidad = (string) ($nodo['sla_unidad'] ?? '');

    if ($tiempo > 0 && in_array($unidad, ['dias', 'horas', 'minutos'], true)) {
        return flujoSlaMinutosTotales($tiempo, $unidad, $conn);
    }

    return max(0, (int) ($nodo['sla_minutos_total'] ?? 0));
}

function flujoCopiarChecklistPlantilla(
    mysqli $conn,
    int $idTicketEtapa,
    int $idProcesoEtapa
): void {
    /* La plantilla se copia muchas veces al crear un flujo. Reutilizar el
       statement evita una preparación y un viaje adicional por cada etapa. */
    static $statements = [];
    $claveConexion = spl_object_id($conn);
    if (!isset($statements[$claveConexion])) {
        $statements[$claveConexion] = $conn->prepare(
            "INSERT INTO ticket_etapa_checklist
                (
                    id_ticket_etapa,
                    id_checklist_plantilla,
                    nombre,
                    descripcion,
                    obligatorio,
                    requiere_evidencia,
                    orden
                )
             SELECT
                ?,
                pc.id_checklist,
                pc.nombre,
                pc.descripcion,
                pc.obligatorio,
                pc.requiere_evidencia,
                pc.orden
             FROM proceso_etapa_checklist AS pc
             WHERE pc.id_proceso_etapa = ?
               AND pc.estado = 'activo'
               AND NOT EXISTS (
                    SELECT 1
                    FROM ticket_etapa_checklist AS tc
                    WHERE tc.id_ticket_etapa = ?
                      AND tc.id_checklist_plantilla = pc.id_checklist
               )
             ORDER BY pc.orden, pc.id_checklist"
        );
    }
    $stmt = $statements[$claveConexion];
    $stmt->bind_param(
        'iii',
        $idTicketEtapa,
        $idProcesoEtapa,
        $idTicketEtapa
    );
    $stmt->execute();
}

function flujoSincronizarChecklistEtapaAbierta(
    mysqli $conn,
    int $idTicketEtapa
): void {
    $stmt = $conn->prepare(
        "SELECT id_proceso_etapa, estado
         FROM ticket_etapas
         WHERE id_ticket_etapa = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $idTicketEtapa);
    $stmt->execute();
    $etapa = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (
        !$etapa
        || (int) ($etapa['id_proceso_etapa'] ?? 0) < 1
        || !in_array(
            (string) $etapa['estado'],
            ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada'],
            true
        )
    ) {
        return;
    }

    flujoCopiarChecklistPlantilla(
        $conn,
        $idTicketEtapa,
        (int) $etapa['id_proceso_etapa']
    );
}

/**
 * @return array<string, mixed>|null
 */
function flujoObtenerNodo(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa
): ?array {
    $stmt = $conn->prepare(
        "SELECT te.*
         FROM ticket_etapas AS te
         WHERE te.id_ticket = ?
           AND te.id_ticket_etapa = ?
         LIMIT 1"
    );
    $stmt->bind_param('ii', $idTicket, $idTicketEtapa);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $fila ?: null;
}

/**
 * Devuelve el identificador visible del nodo.
 *
 * Las etapas oficiales pertenecen siempre al mismo caso principal y por eso
 * muestran el id del ticket (Caso 1, Caso 2, etc.). Solo las derivaciones
 * reciben un numero de ticket jerarquico basado en la etapa que las origino:
 * 1.1, 1.2, 2.1, 2.1.1, etc.
 */
function flujoCodigoCaso(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa
): string {
    static $cache = [];
    $claveCache = spl_object_id($conn) . ':' . $idTicket . ':' . $idTicketEtapa;

    if (isset($cache[$claveCache])) {
        return $cache[$claveCache];
    }

    $ruta = [];
    $actual = $idTicketEtapa;
    $visitados = [];

    while ($actual > 0 && !isset($visitados[$actual]) && count($ruta) < 100) {
        $visitados[$actual] = true;
        $stmt = $conn->prepare(
            "SELECT id_ticket_etapa, id_ticket_etapa_padre, orden
             FROM ticket_etapas
             WHERE id_ticket = ? AND id_ticket_etapa = ?
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idTicket, $actual);
        $stmt->execute();
        $nodo = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$nodo) {
            break;
        }

        $ruta[] = $nodo;
        $actual = (int) ($nodo['id_ticket_etapa_padre'] ?? 0);
    }

    if (!$ruta) {
        return $cache[$claveCache] = (string) $idTicketEtapa;
    }

    $ruta = array_reverse($ruta);

    /* Una etapa oficial nunca crea un caso nuevo. */
    if (count($ruta) === 1) {
        return $cache[$claveCache] = (string) $idTicket;
    }

    $raiz = $ruta[0];
    $ordenRaiz = (int) $raiz['orden'];
    $idRaiz = (int) $raiz['id_ticket_etapa'];
    $stmt = $conn->prepare(
        "SELECT COUNT(*) AS posicion
         FROM ticket_etapas
         WHERE id_ticket = ?
           AND id_ticket_etapa_padre IS NULL
           AND (orden < ? OR (orden = ? AND id_ticket_etapa <= ?))"
    );
    $stmt->bind_param(
        'iiii',
        $idTicket,
        $ordenRaiz,
        $ordenRaiz,
        $idRaiz
    );
    $stmt->execute();
    $posicionEtapa = (int) $stmt->get_result()->fetch_assoc()['posicion'];
    $stmt->close();
    $codigo = (string) max(1, $posicionEtapa);

    foreach (array_slice($ruta, 1) as $nodo) {
        $idPadre = (int) $nodo['id_ticket_etapa_padre'];
        $orden = (int) $nodo['orden'];
        $idNodo = (int) $nodo['id_ticket_etapa'];
        $stmt = $conn->prepare(
            "SELECT COUNT(*) AS posicion
             FROM ticket_etapas
             WHERE id_ticket = ?
               AND id_ticket_etapa_padre = ?
               AND (orden < ? OR (orden = ? AND id_ticket_etapa <= ?))"
        );
        $stmt->bind_param(
            'iiiii',
            $idTicket,
            $idPadre,
            $orden,
            $orden,
            $idNodo
        );
        $stmt->execute();
        $posicion = (int) $stmt->get_result()->fetch_assoc()['posicion'];
        $stmt->close();
        $codigo .= '.' . max(1, $posicion);
    }

    return $cache[$claveCache] = $codigo;
}

function flujoNumeroEtapaNodo(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa
): int {
    static $cache = [];
    $claveCache = spl_object_id($conn) . ':' . $idTicket . ':' . $idTicketEtapa;

    if (isset($cache[$claveCache])) {
        return $cache[$claveCache];
    }

    $actual = $idTicketEtapa;
    $raiz = null;
    $visitados = [];

    while ($actual > 0 && !isset($visitados[$actual])) {
        $visitados[$actual] = true;
        $stmt = $conn->prepare(
            "SELECT id_ticket_etapa, id_ticket_etapa_padre, orden
             FROM ticket_etapas
             WHERE id_ticket = ? AND id_ticket_etapa = ?
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idTicket, $actual);
        $stmt->execute();
        $nodo = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$nodo) {
            break;
        }

        $raiz = $nodo;
        $actual = (int) ($nodo['id_ticket_etapa_padre'] ?? 0);
    }

    if (!$raiz) {
        return $cache[$claveCache] = 0;
    }

    $orden = (int) $raiz['orden'];
    $idRaiz = (int) $raiz['id_ticket_etapa'];
    $stmt = $conn->prepare(
        "SELECT COUNT(*) AS posicion
         FROM ticket_etapas
         WHERE id_ticket = ?
           AND id_ticket_etapa_padre IS NULL
           AND (orden < ? OR (orden = ? AND id_ticket_etapa <= ?))"
    );
    $stmt->bind_param('iiii', $idTicket, $orden, $orden, $idRaiz);
    $stmt->execute();
    $posicion = (int) $stmt->get_result()->fetch_assoc()['posicion'];
    $stmt->close();

    return $cache[$claveCache] = max(1, $posicion);
}

function flujoEtiquetaNodo(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa
): string {
    $nodo = flujoObtenerNodo($conn, $idTicket, $idTicketEtapa);
    $esDerivacion = (int) ($nodo['id_ticket_etapa_padre'] ?? 0) > 0;

    if ($esDerivacion) {
        return 'Ticket ' . flujoCodigoCaso($conn, $idTicket, $idTicketEtapa);
    }

    return 'Caso ' . $idTicket . ' · etapa '
        . flujoNumeroEtapaNodo($conn, $idTicket, $idTicketEtapa);
}

/**
 * @return array{origen:int,destino:int}|null
 */
function flujoParticipantesConversacion(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa
): ?array {
    $stmt = $conn->prepare(
        "SELECT
            te.id_gestor AS destino,
            CASE
                WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                ELSE padre.id_gestor
            END AS origen
         FROM ticket_etapas AS te
         INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
         LEFT JOIN ticket_etapas AS padre
            ON padre.id_ticket_etapa = te.id_ticket_etapa_padre
         WHERE te.id_ticket = ?
           AND te.id_ticket_etapa = ?
           AND te.estado <> 'bloqueada'
         LIMIT 1"
    );
    $stmt->bind_param('ii', $idTicket, $idTicketEtapa);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$fila) {
        return null;
    }

    return [
        'origen' => (int) ($fila['origen'] ?? 0),
        'destino' => (int) ($fila['destino'] ?? 0),
    ];
}

function flujoPuedeVerConversacionNodo(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idUsuario,
    int $rol
): bool {
    $participantes = flujoParticipantesConversacion(
        $conn,
        $idTicket,
        $idTicketEtapa
    );

    if (!$participantes) {
        return false;
    }

    if ($rol === 1) {
        return true;
    }

    if ($rol === 2) {
        if (seguridadEsUsuarioPrueba()) {
            return true;
        }
        return in_array(
            $idUsuario,
            array_values($participantes),
            true
        );
    }

    if ($rol !== 3) {
        return false;
    }

    /* El solicitante solo participa en las etapas oficiales del flujo. Los
       casos hijos son derivaciones internas y nunca se exponen en su portal. */
    $stmt = $conn->prepare(
        "SELECT 1
         FROM ticket_etapas AS te
         INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
         WHERE te.id_ticket = ?
           AND te.id_ticket_etapa = ?
           AND te.id_ticket_etapa_padre IS NULL
           AND te.estado <> 'bloqueada'
           AND t.id_usuario = ?
         LIMIT 1"
    );
    $stmt->bind_param('iii', $idTicket, $idTicketEtapa, $idUsuario);
    $stmt->execute();
    $stmt->store_result();
    $puede = $stmt->num_rows > 0;
    $stmt->close();

    return $puede;
}

/**
 * @return array<int, array<string, mixed>>
 */
function flujoConversacionesDisponibles(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol
): array {
    $sql = "SELECT
                te.id_ticket_etapa,
                te.id_ticket_etapa_padre,
                te.nivel,
                te.orden,
                te.estado,
                te.catalogo_nombre,
                te.servicio_nombre,
                CASE
                    WHEN te.id_ticket_etapa_padre IS NULL THEN 'flujo'
                    ELSE 'derivacion'
                END AS tipo_conversacion,
                te.id_gestor AS id_gestor_destino,
                destino.nombre AS gestor_destino,
                CASE
                    WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                    ELSE padre.id_gestor
                END AS id_gestor_origen,
                origen.nombre AS gestor_origen,
                (SELECT COUNT(*)
                 FROM solicitud_comunicaciones AS sc
                 WHERE sc.id_ticket_etapa = te.id_ticket_etapa
                   AND (
                        te.id_ticket_etapa_padre IS NOT NULL
                        OR sc.tipo = 'publica'
                   )) AS total_mensajes,
                (SELECT COUNT(*)
                 FROM solicitud_adjuntos AS sa
                 WHERE sa.id_ticket_etapa = te.id_ticket_etapa) AS total_adjuntos
            FROM ticket_etapas AS te
            INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
            LEFT JOIN ticket_etapas AS padre
                ON padre.id_ticket_etapa = te.id_ticket_etapa_padre
            LEFT JOIN usuarios AS destino
                ON destino.id_usuario = te.id_gestor
            LEFT JOIN usuarios AS origen
                ON origen.id_usuario = CASE
                    WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                    ELSE padre.id_gestor
                END
            WHERE te.id_ticket = ?
              AND te.estado <> 'bloqueada'";

    if ($rol === 2) {
        if (seguridadEsUsuarioPrueba()) {
            $sql .= ' AND t.es_prueba = 1';
        } else {
            $sql .= " AND (
                        te.id_gestor = ?
                        OR CASE
                            WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                            ELSE padre.id_gestor
                        END = ?
                      )";
        }
    } elseif ($rol === 3) {
        $sql .= " AND te.id_ticket_etapa_padre IS NULL
                  AND t.id_usuario = ?";
    } elseif ($rol !== 1) {
        return [];
    }

    $sql .= " ORDER BY te.nivel, te.orden, te.id_ticket_etapa";
    $stmt = $conn->prepare($sql);

    if ($rol === 2 && !seguridadEsUsuarioPrueba()) {
        $stmt->bind_param('iii', $idTicket, $idUsuario, $idUsuario);
    } elseif ($rol === 3) {
        $stmt->bind_param('ii', $idTicket, $idUsuario);
    } else {
        $stmt->bind_param('i', $idTicket);
    }

    $stmt->execute();
    $resultado = $stmt->get_result();
    $filas = [];

    while ($fila = $resultado->fetch_assoc()) {
        $filas[] = $fila;
    }

    $stmt->close();

    foreach ($filas as &$fila) {
        $esDerivacion = (int) ($fila['id_ticket_etapa_padre'] ?? 0) > 0;
        $fila['numero_etapa'] = flujoNumeroEtapaNodo(
            $conn,
            $idTicket,
            (int) $fila['id_ticket_etapa']
        );
        $fila['codigo_nodo'] = flujoCodigoCaso(
            $conn,
            $idTicket,
            (int) $fila['id_ticket_etapa']
        );
        $fila['codigo_caso'] = (string) $idTicket;
        $fila['codigo_ticket'] = $esDerivacion
            ? (string) $fila['codigo_nodo']
            : (string) $fila['numero_etapa'];
    }
    unset($fila);

    return $filas;
}

function flujoNodoPuedeGestionar(
    array $nodo,
    int $idUsuario,
    int $rol,
    bool $permitirPausado = false
): bool {
    $estados = ['pendiente', 'en_proceso', 'en_espera_solicitante'];

    if ($permitirPausado) {
        $estados[] = 'pausada';
    }

    if (!in_array((string) ($nodo['estado'] ?? ''), $estados, true)) {
        return false;
    }

    return $rol === 1
        || ($rol === 2 && (
            seguridadEsUsuarioPrueba()
            || (int) ($nodo['id_gestor'] ?? 0) === $idUsuario
        ));
}

function flujoMinutosConsumidosNodo(
    mysqli $conn,
    array $nodo,
    ?string $hasta = null,
    bool $incluirEsperaCierre = false
): int {
    $consumidos = (int) ($nodo['sla_minutos_consumidos'] ?? 0);
    $estado = (string) ($nodo['estado'] ?? '');
    $desde = (string) (
        $nodo['fecha_ultima_reanudacion']
        ?? $nodo['fecha_activacion']
        ?? ''
    );

    if (
        $desde !== ''
        && in_array(
            $estado,
            $incluirEsperaCierre
                ? ['pendiente', 'en_proceso', 'en_espera_solicitante', 'listo_cierre']
                : ['pendiente', 'en_proceso', 'en_espera_solicitante'],
            true
        )
    ) {
        if ((string) ($nodo['sla_unidad'] ?? '') === 'dias') {
            try {
                $desde = (new DateTimeImmutable(
                    $desde,
                    calendarioZonaHoraria()
                ))
                    ->setTime(0, 0)
                    ->modify('+1 day')
                    ->format('Y-m-d H:i:s');
            } catch (Throwable $e) {
                return max(0, $consumidos);
            }
        }

        $fin = new DateTimeImmutable(
            $hasta ?: flujoAhora(),
            calendarioZonaHoraria()
        );
        $consumidos += minutosHabilesTranscurridos($conn, $desde, $fin);
    }

    return max(0, $consumidos);
}

/**
 * La primera etapa raíz representa el servicio solicitado y recibe la única
 * encuesta principal del ticket. Las etapas derivadas reciben evaluación
 * interna del gestor que abrió la derivación. Las demás etapas raíz heredadas
 * del flujo también exigen calificación, pero se identifican como evaluación
 * operativa del caso y no como otra encuesta del servicio solicitado.
 */
function flujoTipoCalificacionCaso(
    mysqli $conn,
    int $idTicket,
    array $etapa
): ?string {
    if ((int) ($etapa['id_ticket_etapa_padre'] ?? 0) > 0) {
        return 'evaluacion_derivacion';
    }

    $stmt = $conn->prepare(
        "SELECT id_ticket_etapa
         FROM ticket_etapas
         WHERE id_ticket = ?
           AND id_ticket_etapa_padre IS NULL
         ORDER BY orden, id_ticket_etapa
         LIMIT 1"
    );
    $stmt->bind_param('i', $idTicket);
    $stmt->execute();
    $primeraRaiz = (int) (
        $stmt->get_result()->fetch_assoc()['id_ticket_etapa'] ?? 0
    );
    $stmt->close();

    return $primeraRaiz === (int) ($etapa['id_ticket_etapa'] ?? 0)
        ? 'encuesta_servicio'
        : 'evaluacion_caso';
}

function flujoCalcularVencimientoRestante(
    mysqli $conn,
    array $nodo,
    string $inicio,
    int $minutosRestantes
): ?string {
    if ($minutosRestantes < 1) {
        return $inicio;
    }

    if ((string) ($nodo['sla_unidad'] ?? '') === 'dias') {
        $minutosDia = calendarioMinutosDiaSla($conn);
        if ($minutosRestantes % $minutosDia === 0) {
            return calcularVencimientoSla(
                $conn,
                $inicio,
                intdiv($minutosRestantes, $minutosDia),
                'dias'
            );
        }

        try {
            $inicio = (new DateTimeImmutable(
                $inicio,
                calendarioZonaHoraria()
            ))
                ->setTime(0, 0)
                ->modify('+1 day')
                ->format('Y-m-d H:i:s');
        } catch (Throwable $e) {
            return null;
        }
    }

    return calcularVencimientoSla(
        $conn,
        $inicio,
        $minutosRestantes,
        'minutos'
    );
}

function flujoRecalcularVencimientosActivos(
    mysqli $conn,
    int $idTicket
): void {
    $stmt = $conn->prepare(
        "SELECT *
         FROM ticket_etapas
         WHERE id_ticket = ?
           AND estado IN ('pendiente', 'en_proceso', 'en_espera_solicitante')
           AND COALESCE(fecha_ultima_reanudacion, fecha_activacion) IS NOT NULL"
    );
    $stmt->bind_param('i', $idTicket);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $actualizaciones = [];

    while ($nodo = $resultado->fetch_assoc()) {
        $total = flujoSlaMinutosTotalesNodo($nodo, $conn);
        $consumidos = (int) ($nodo['sla_minutos_consumidos'] ?? 0);
        $restantes = max(0, $total - $consumidos);
        $inicio = (string) (
            $nodo['fecha_ultima_reanudacion']
            ?? $nodo['fecha_activacion']
            ?? ''
        );

        if ($inicio === '') {
            continue;
        }

        $actualizaciones[] = [
            (int) $nodo['id_ticket_etapa'],
            flujoCalcularVencimientoRestante(
                $conn,
                $nodo,
                $inicio,
                $restantes
            ),
        ];
    }
    $stmt->close();

    foreach ($actualizaciones as [$idNodo, $vencimiento]) {
        $stmt = $conn->prepare(
            "UPDATE ticket_etapas
             SET fecha_vencimiento = ?
             WHERE id_ticket_etapa = ?"
        );
        $stmt->bind_param('si', $vencimiento, $idNodo);
        $stmt->execute();
        $stmt->close();
    }
}

/**
 * Proyecta la fecha de finalización integral del caso usando el calendario SLA.
 *
 * Las etapas oficiales se atienden en secuencia. Las derivaciones hermanas se
 * ejecutan en paralelo y la de mayor duración define cuándo puede reanudarse
 * su padre. El cálculo se hace en cada consulta para reflejar nuevas
 * derivaciones, cierres anticipados, reaperturas y cambios del calendario.
 *
 * @return array{fecha:?string,estado:string,pausado_por_derivacion:bool,calculado_en:string}
 */
function flujoProyeccionFinalizacionTicket(
    mysqli $conn,
    int $idTicket
): array {
    $ahora = flujoAhora();
    $salida = [
        'fecha' => null,
        'estado' => 'sin_proyeccion',
        'pausado_por_derivacion' => false,
        'calculado_en' => $ahora,
    ];

    $stmt = $conn->prepare(
        "SELECT estado_flujo, estado, fecha_finalizacion
         FROM tickets
         WHERE id_ticket = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $idTicket);
    $stmt->execute();
    $ticket = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$ticket) {
        return $salida;
    }

    if (
        (string) ($ticket['estado_flujo'] ?? '') === 'cerrado'
        || in_array((string) ($ticket['estado'] ?? ''), ['cerrada', 'cancelada'], true)
    ) {
        $salida['fecha'] = $ticket['fecha_finalizacion'] ?: null;
        $salida['estado'] = $salida['fecha'] ? 'finalizado' : 'cerrado';
        return $salida;
    }

    $stmt = $conn->prepare(
        "SELECT *
         FROM ticket_etapas
         WHERE id_ticket = ?
         ORDER BY orden, id_ticket_etapa"
    );
    $stmt->bind_param('i', $idTicket);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $porPadre = [];

    while ($nodo = $resultado->fetch_assoc()) {
        $padre = (int) ($nodo['id_ticket_etapa_padre'] ?? 0);
        $porPadre[$padre][] = $nodo;
        if ((string) ($nodo['estado'] ?? '') === 'pausada') {
            $salida['pausado_por_derivacion'] = true;
        }
    }
    $stmt->close();

    if (empty($porPadre[0])) {
        return $salida;
    }

    $proyectarNodo = function (
        array $nodo,
        string $inicioDisponible
    ) use (&$proyectarNodo, $conn, $porPadre, $ahora): string {
        $estado = (string) ($nodo['estado'] ?? 'bloqueada');

        if (in_array($estado, ['completada', 'cancelada'], true)) {
            return $inicioDisponible;
        }

        $inicioTrabajo = $inicioDisponible;
        $hijosAbiertos = array_values(array_filter(
            $porPadre[(int) ($nodo['id_ticket_etapa'] ?? 0)] ?? [],
            static fn (array $hijo): bool => !in_array(
                (string) ($hijo['estado'] ?? ''),
                ['completada', 'cancelada'],
                true
            )
        ));

        if ($hijosAbiertos) {
            $finHijos = $inicioDisponible;
            foreach ($hijosAbiertos as $hijo) {
                $finHijo = $proyectarNodo($hijo, $inicioDisponible);
                if (strcmp($finHijo, $finHijos) > 0) {
                    $finHijos = $finHijo;
                }
            }
            $inicioTrabajo = $finHijos;
        }

        $total = flujoSlaMinutosTotalesNodo($nodo, $conn);

        if ($estado === 'bloqueada') {
            $consumidos = 0;
        } elseif ($estado === 'pausada') {
            $consumidos = max(0, (int) ($nodo['sla_minutos_consumidos'] ?? 0));
        } else {
            $consumidos = flujoMinutosConsumidosNodo($conn, $nodo, $ahora, true);
        }

        $restantes = max(0, $total - $consumidos);
        if ($restantes < 1) {
            return $inicioTrabajo;
        }

        return flujoCalcularVencimientoRestante(
            $conn,
            $nodo,
            $inicioTrabajo,
            $restantes
        ) ?: $inicioTrabajo;
    };

    $cursor = $ahora;
    $tienePendientes = false;
    foreach ($porPadre[0] as $raiz) {
        if (in_array(
            (string) ($raiz['estado'] ?? ''),
            ['completada', 'cancelada'],
            true
        )) {
            continue;
        }
        $tienePendientes = true;
        $cursor = $proyectarNodo($raiz, $cursor);
    }

    if ($tienePendientes) {
        $salida['fecha'] = $cursor;
        $salida['estado'] = $salida['pausado_por_derivacion']
            ? 'proyectado_con_pausa'
            : 'proyectado';
    }

    return $salida;
}

/**
 * @return array<int, array<string, mixed>>
 */
function flujoServiciosDisponibles(mysqli $conn): array
{
    $idPaisOperacion = paisExigirContexto();
    
    // Compatibilidad con servicios directos y flujos horizontales existentes.
    $resultado = $conn->query(
        "SELECT
            s.id_servicio,
            s.codigo_servicio,
            s.nombre AS servicio_nombre,
            s.descripcion AS servicio_descripcion,
            c.id_catalogo,
            c.nombre AS catalogo_nombre,
            s.id_gestor,
            u.nombre AS gestor_nombre,
            sl.id_sla,
            sl.nombre AS sla_nombre,
            sl.tiempo_respuesta AS sla_tiempo,
            sl.unidad AS sla_unidad,
            s.tipo_solicitud,
            s.prioridad_valor,
            s.urgencia_valor,
            s.impacto_valor,
            p.id_proceso,
            pe.id_proceso_etapa,
            CASE
                WHEN p.id_proceso IS NULL THEN s.id_servicio
                ELSE p.id_proceso
            END AS id_proceso_final
         FROM servicios AS s
         INNER JOIN catalogos AS c
            ON c.id_catalogo = s.id_catalogo
           AND c.estado = 'activo'
         INNER JOIN usuarios AS u
            ON u.id_usuario = s.id_gestor
           AND u.id_rol = 2
           AND u.estado = 'activo'
         INNER JOIN servicio_gestores AS sg
            ON sg.id_servicio = s.id_servicio
           AND sg.id_usuario = s.id_gestor
           AND sg.estado = 'activo'
         INNER JOIN sla AS sl
            ON sl.id_sla = s.id_sla
           AND sl.estado = 'activo'
         LEFT JOIN proceso_etapas AS pe
            ON pe.id_servicio = s.id_servicio
           AND pe.estado = 'activo'
         LEFT JOIN procesos AS p
            ON p.id_proceso = pe.id_proceso
           AND p.estado = 'activo'
         WHERE s.estado = 'activo'
           AND s.id_pais_operacion = {$idPaisOperacion}
           AND (
                p.id_proceso IS NULL
                OR pe.orden = (
                    SELECT MIN(pe_base.orden)
                    FROM proceso_etapas AS pe_base
                    WHERE pe_base.id_proceso = p.id_proceso
                      AND pe_base.estado = 'activo'
                )
           )
         ORDER BY c.orden, c.nombre, s.nombre, p.id_proceso"
    );
    
    $filas = [];
    $vistos = [];

    while ($fila = $resultado->fetch_assoc()) {
        $idServicio = (int) $fila['id_servicio'];

        $fila['id_proceso'] = (int) $fila['id_proceso_final'];
        unset($fila['id_proceso_final']);

        if (isset($vistos[$idServicio])) {
            continue;
        }

        $vistos[$idServicio] = true;
        
        // Agregar nombres de prioridad y urgencia
        $fila['prioridad_nombre'] = flujoNombrePrioridad((int)($fila['prioridad_valor'] ?? 3));
        $fila['urgencia_nombre'] = flujoNombreUrgencia((int)($fila['urgencia_valor'] ?? 2));
        
        $filas[] = $fila;
    }

    return $filas;
}

// Agregar estas funciones auxiliares después de flujoServiciosDisponibles
function flujoNombrePrioridad(int $valor): string
{
    return (fn ($__mesaMatchValue7) => (($__mesaMatchValue7 === (1)) ? ('Baja') : ((($__mesaMatchValue7 === (2)) ? ('Baja moderada') : ((($__mesaMatchValue7 === (3)) ? ('Moderada') : ((($__mesaMatchValue7 === (4)) ? ('Moderada urgente') : ((($__mesaMatchValue7 === (5)) ? ('Urgente') : ('Media')))))))))))($valor);
}

function flujoNombreUrgencia(int $valor): string
{
    return (fn ($__mesaMatchValue8) => (($__mesaMatchValue8 === (1)) ? ('Más tarde') : ((($__mesaMatchValue8 === (2)) ? ('Pronto') : ((($__mesaMatchValue8 === (3)) ? ('Inmediato') : ('Moderada')))))))($valor);
}
/**
 * @return array<int, array<string, mixed>>
 */
function flujoSolucionesServicio(
    mysqli $conn,
    int $idServicio,
    bool $soloActivas = true
): array {
    if (
        $idServicio < 1
        || !flujoTablaExiste($conn, 'soluciones_servicio')
    ) {
        return [];
    }

    $sql = "SELECT id_solucion, id_servicio, nombre, descripcion, estado, orden
            FROM soluciones_servicio
            WHERE id_servicio = ?";

    if ($soloActivas) {
        $sql .= " AND estado = 'activo'";
    }

    $sql .= ' ORDER BY orden, nombre, id_solucion';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $idServicio);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $filas = [];

    while ($fila = $resultado->fetch_assoc()) {
        $filas[] = $fila;
    }

    $stmt->close();

    return $filas;
}

/**
 * @return array<int, array<string, mixed>>
 */
function flujoEtapasPlantilla(mysqli $conn, int $idProceso): array
{
    $idPaisOperacion = paisExigirContexto();
    $stmt = $conn->prepare(
        "SELECT
            pe.id_proceso_etapa,
            pe.orden,
            COALESCE(NULLIF(pe.nombre_etapa, ''), s.nombre) AS nombre_etapa,
            pe.instrucciones,
            c.id_catalogo,
            c.nombre AS catalogo_nombre,
            s.id_servicio,
            s.nombre AS servicio_nombre,
            s.tipo_solicitud,
            s.prioridad_valor,
            s.urgencia_valor,
            s.impacto_valor,
            s.id_gestor,
            u.nombre AS gestor_nombre,
            sl.id_sla,
            sl.nombre AS sla_nombre,
            sl.tiempo_respuesta AS sla_tiempo,
            sl.unidad AS sla_unidad
         FROM procesos AS p
         INNER JOIN proceso_etapas AS pe
            ON pe.id_proceso = p.id_proceso
           AND pe.estado = 'activo'
         INNER JOIN servicios AS s
            ON s.id_servicio = pe.id_servicio
           AND s.estado = 'activo'
         INNER JOIN catalogos AS c
            ON c.id_catalogo = s.id_catalogo
           AND c.estado = 'activo'
         INNER JOIN usuarios AS u
            ON u.id_usuario = s.id_gestor
           AND u.id_rol = 2
           AND u.estado = 'activo'
         INNER JOIN servicio_gestores AS sg
            ON sg.id_servicio = s.id_servicio
           AND sg.id_usuario = s.id_gestor
           AND sg.estado = 'activo'
         INNER JOIN sla AS sl
            ON sl.id_sla = s.id_sla
           AND sl.estado = 'activo'
         WHERE p.id_proceso = ?
           AND p.id_pais_operacion = ?
           AND p.estado = 'activo'
         ORDER BY pe.orden ASC, pe.id_proceso_etapa ASC"
    );
    $stmt->bind_param('ii', $idProceso, $idPaisOperacion);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $etapas = [];

    while ($fila = $resultado->fetch_assoc()) {
        $etapas[] = $fila;
    }

    $stmt->close();

    return $etapas;
}

function flujoMarcarTicketPrueba(mysqli $conn, int $idTicket): void
{
    if (
        $idTicket < 1
        || !seguridadEsUsuarioPrueba()
        || !flujoColumnaExiste($conn, 'tickets', 'es_prueba')
    ) {
        return;
    }

    $stmt = $conn->prepare(
        'UPDATE tickets SET es_prueba = 1 WHERE id_ticket = ?'
    );
    $stmt->bind_param('i', $idTicket);
    $stmt->execute();
    $stmt->close();
}

function flujoCrearTicket(
    mysqli $conn,
    int $idProceso,
    int $idSolicitante,
    string $titulo,
    string $descripcion,
    string $urgencia,
    ?int $idServicioSeleccionado = null,
    ?bool $seleccionEsProceso = null,
    array $camposExtras = []
): int {
    $idPaisOperacion = paisExigirContexto();
    $stmtPaisUsuario = $conn->prepare(
        "SELECT 1 FROM usuarios
         WHERE id_usuario = ? AND id_pais_operacion = ? AND estado = 'activo'
         LIMIT 1"
    );
    $stmtPaisUsuario->bind_param('ii', $idSolicitante, $idPaisOperacion);
    $stmtPaisUsuario->execute();
    $stmtPaisUsuario->store_result();
    $usuarioValido = $stmtPaisUsuario->num_rows === 1;
    $stmtPaisUsuario->close();

    if (!$usuarioValido) {
        throw new RuntimeException('El solicitante no pertenece al país de operación activo.');
    }

    /* Cuando el formulario ya confirmó que se eligió un proceso, no hay
       motivo para consultar primero el catálogo de servicios como si fuera
       un servicio directo. Esto elimina dos consultas en la ruta normal. */
    $servicioDirecto = null;
    if ($seleccionEsProceso !== true) {
        $idServicioConsulta = $idServicioSeleccionado ?: $idProceso;
        $stmtServicioDirecto = $conn->prepare(
            "SELECT s.id_servicio, s.nombre, s.descripcion, s.tipo_solicitud,
                    s.id_gestor, s.id_sla, s.prioridad_valor, s.urgencia_valor,
                    s.impacto_valor,
                    c.id_catalogo, c.nombre AS catalogo_nombre,
                    u.nombre AS gestor_nombre,
                    sl.nombre AS sla_nombre, sl.tiempo_respuesta, sl.unidad,
                    sl.id_sla
             FROM servicios AS s
             INNER JOIN catalogos AS c ON c.id_catalogo = s.id_catalogo
             INNER JOIN usuarios AS u ON u.id_usuario = s.id_gestor
             INNER JOIN servicio_gestores AS sg
                ON sg.id_servicio = s.id_servicio
               AND sg.id_usuario = s.id_gestor
               AND sg.estado = 'activo'
             INNER JOIN sla AS sl ON sl.id_sla = s.id_sla
             WHERE s.id_servicio = ?
               AND s.estado = 'activo'
               AND s.id_pais_operacion = ?
               AND c.estado = 'activo'
               AND u.estado = 'activo'
               AND sl.estado = 'activo'
             LIMIT 1"
        );
        $stmtServicioDirecto->bind_param('ii', $idServicioConsulta, $idPaisOperacion);
        $stmtServicioDirecto->execute();
        $servicioDirecto = $stmtServicioDirecto->get_result()->fetch_assoc();
        $stmtServicioDirecto->close();
    }

    if ($servicioDirecto) {
        // Verificar si el servicio tiene un proceso activo
        $tieneProceso = false;
        if ($seleccionEsProceso !== false) {
            $stmtProceso = $conn->prepare(
                "SELECT DISTINCT p.id_proceso
                 FROM procesos AS p
                 INNER JOIN proceso_etapas AS pe ON pe.id_proceso = p.id_proceso
                 WHERE pe.id_servicio = ?
                   AND p.estado = 'activo'
                   AND pe.estado = 'activo'
                   AND p.id_pais_operacion = ?
                 LIMIT 1"
            );
            $stmtProceso->bind_param('ii', $idProceso, $idPaisOperacion);
            $stmtProceso->execute();
            $stmtProceso->store_result();
            $tieneProceso = $stmtProceso->num_rows > 0;
            $stmtProceso->close();
        }

        if (!$tieneProceso) {
            // Crear ticket directo sin proceso
            return flujoCrearTicketDirecto(
                $conn,
                $servicioDirecto,
                $idSolicitante,
                $titulo,
                $descripcion,
                $urgencia,
                $camposExtras
            );
        }
    }

    // Si no es servicio directo o tiene proceso, usar el flujo con procesos
    $etapas = flujoEtapasPlantilla($conn, $idProceso);

    if (!$etapas) {
        // Si no hay etapas de proceso, intentar como servicio directo
        if ($servicioDirecto) {
            return flujoCrearTicketDirecto(
                $conn,
                $servicioDirecto,
                $idSolicitante,
                $titulo,
                $descripcion,
                $urgencia,
                $camposExtras
            );
        }
        throw new RuntimeException(
            'El servicio debe tener gestor y SLA activos.'
        );
    }

    $primera = $etapas[0];
    $urgenciaConfigurada = max(1, min(3, (int) ($primera['urgencia_valor'] ?? 2)));
    $impactoConfigurado = max(1, min(3, (int) ($primera['impacto_valor'] ?? 2)));
    $matrizRiesgo = matrizPrioridadCalcular(
        $urgenciaConfigurada,
        $impactoConfigurado
    );
    $urgencia = $matrizRiesgo['urgencia_nombre'];
    $impacto = $matrizRiesgo['impacto_nombre'];
    $prioridad = $matrizRiesgo['prioridad_nombre'];
    $prioridadConfigurada = (int) $matrizRiesgo['prioridad_valor'];
    $tipoSolicitud = trim((string) ($primera['tipo_solicitud'] ?? ''));
    if ($tipoSolicitud === '') {
        $tipoSolicitud = 'requerimiento';
    }

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare(
            "INSERT INTO tickets
                (
                    id_pais_operacion,
                    titulo,
                    descripcion,
                    estado,
                    urgencia,
                    urgencia_valor,
                    impacto,
                    impacto_valor,
                    prioridad,
                    prioridad_valor,
                    id_usuario,
                    id_tecnico,
                    id_servicio,
                    id_proceso,
                    tipo_solicitud,
                    estado_flujo,
                    fecha_creacion
                )
             VALUES (?, ?, ?, 'abierto', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'en_proceso', NOW())"
        );
        $idGestorInicial = (int) $primera['id_gestor'];
        $idServicioInicial = (int) $primera['id_servicio'];
        $stmt->bind_param(
            'isssisisiiiiis',
            $idPaisOperacion,
            $titulo,
            $descripcion,
            $urgencia,
            $urgenciaConfigurada,
            $impacto,
            $impactoConfigurado,
            $prioridad,
            $prioridadConfigurada,
            $idSolicitante,
            $idGestorInicial,
            $idServicioInicial,
            $idProceso,
            $tipoSolicitud
        );
        $stmt->execute();
        $idTicket = (int) $conn->insert_id;
        $stmt->close();
        flujoMarcarTicketPrueba($conn, $idTicket);

        $fechaActivacionInicial = flujoAhora();
        $idEtapaActual = 0;

        /* Todas las etapas comparten la misma sentencia de inserción. Se
           prepara una sola vez por caso, reduciendo viajes al servidor SQL. */
        $stmtEtapa = $conn->prepare(
            "INSERT INTO ticket_etapas
                (
                    id_ticket,
                    id_ticket_etapa_padre,
                    id_proceso_etapa,
                    nivel,
                    orden,
                    id_catalogo,
                    catalogo_nombre,
                    id_servicio,
                    servicio_nombre,
                    id_gestor,
                    gestor_nombre,
                    id_sla,
                    sla_nombre,
                    sla_tiempo,
                    sla_unidad,
                    sla_minutos_total,
                    estado,
                    fecha_activacion,
                    fecha_vencimiento,
                    fecha_ultima_reanudacion,
                    creado_por
                )
             VALUES (?, NULL, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                     ?, ?, ?, ?, ?)"
        );

        foreach ($etapas as $indice => $etapaPlantilla) {
            $esPrimera = $indice === 0;
            $idProcesoEtapa = (int) $etapaPlantilla['id_proceso_etapa'];
            $ordenEtapa = (int) $etapaPlantilla['orden'];
            $idCatalogo = (int) $etapaPlantilla['id_catalogo'];
            $catalogoNombre = (string) $etapaPlantilla['catalogo_nombre'];
            $idServicio = (int) $etapaPlantilla['id_servicio'];
            $servicioNombre = (string) $etapaPlantilla['servicio_nombre'];
            $idGestor = (int) $etapaPlantilla['id_gestor'];
            $gestorNombre = (string) $etapaPlantilla['gestor_nombre'];
            $idSla = (int) $etapaPlantilla['id_sla'];
            $slaNombre = (string) $etapaPlantilla['sla_nombre'];
            $slaTiempo = (int) $etapaPlantilla['sla_tiempo'];
            $slaUnidad = (string) $etapaPlantilla['sla_unidad'];
            $slaMinutosTotal = flujoSlaMinutosTotales(
                $slaTiempo,
                $slaUnidad,
                $conn
            );
            $estadoEtapa = $esPrimera ? 'pendiente' : 'bloqueada';
            $fechaActivacion = $esPrimera
                ? $fechaActivacionInicial
                : null;
            $fechaVencimiento = $esPrimera
                ? calcularVencimientoSla(
                    $conn,
                    $fechaActivacionInicial,
                    $slaTiempo,
                    $slaUnidad
                )
                : null;
            $fechaReanudacion = $fechaActivacion;
            $stmtEtapa->bind_param(
                'iiiisisisisisissssi',
                $idTicket,
                $idProcesoEtapa,
                $ordenEtapa,
                $idCatalogo,
                $catalogoNombre,
                $idServicio,
                $servicioNombre,
                $idGestor,
                $gestorNombre,
                $idSla,
                $slaNombre,
                $slaTiempo,
                $slaUnidad,
                $slaMinutosTotal,
                $estadoEtapa,
                $fechaActivacion,
                $fechaVencimiento,
                $fechaReanudacion,
                $idSolicitante
            );
            $stmtEtapa->execute();
            $idEtapa = (int) $conn->insert_id;

            if ($esPrimera) {
                $idEtapaActual = $idEtapa;
                camposExtrasGuardarValores(
                    $conn,
                    $idTicket,
                    $idEtapa,
                    $idServicio,
                    $camposExtras,
                    $idSolicitante
                );
            }

            flujoCopiarChecklistPlantilla(
                $conn,
                $idEtapa,
                $idProcesoEtapa
            );
        }
        $stmtEtapa->close();

        $stmt = $conn->prepare(
            "UPDATE tickets
             SET id_etapa_actual = ?
             WHERE id_ticket = ?"
        );
        $stmt->bind_param('ii', $idEtapaActual, $idTicket);
        $stmt->execute();
        $stmt->close();

        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idSolicitante,
            'Caso principal abierto',
            'Se creó el Caso '
                . $idTicket
                . ' y se activó la etapa 1 para '
                . $primera['catalogo_nombre']
                . ' / '
                . $primera['servicio_nombre']
                . '. Asunto: '
                . $titulo
                . '. Solicitud: '
                . $descripcion,
            $idEtapaActual
        );
        $esIncidente = strtolower(trim($tipoSolicitud)) === 'incidente';
        flujoNotificar(
            $conn,
            $idGestorInicial,
            $idTicket,
            $idEtapaActual,
            $esIncidente ? 'Incidente urgente asignado' : 'Nuevo ticket asignado',
            $esIncidente
                ? "El Caso {$idTicket}, etapa 1, es un incidente y requiere atención prioritaria."
                : "El Caso {$idTicket}, etapa 1, está disponible para su gestión."
        );

        $conn->commit();

        return $idTicket;
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

// Agregar esta nueva función después de flujoCrearTicket
function flujoCrearTicketDirecto(
    mysqli $conn,
    array $servicio,
    int $idSolicitante,
    string $titulo,
    string $descripcion,
    string $urgencia,
    array $camposExtras = []
): int {
    $idPaisOperacion = paisExigirContexto();
    $urgenciaConfigurada = max(1, min(3, (int) ($servicio['urgencia_valor'] ?? 2)));
    $impactoConfigurado = max(1, min(3, (int) ($servicio['impacto_valor'] ?? 2)));
    $matrizRiesgo = matrizPrioridadCalcular(
        $urgenciaConfigurada,
        $impactoConfigurado
    );
    $urgencia = $matrizRiesgo['urgencia_nombre'];
    $impacto = $matrizRiesgo['impacto_nombre'];
    $prioridad = $matrizRiesgo['prioridad_nombre'];
    $prioridadConfigurada = (int) $matrizRiesgo['prioridad_valor'];

    $conn->begin_transaction();

    try {
        $idGestor = (int) $servicio['id_gestor'];
        $idServicio = (int) $servicio['id_servicio'];
        $idCatalogo = (int) $servicio['id_catalogo'];
        $tipoSolicitud = trim((string) ($servicio['tipo_solicitud'] ?? ''));
        if ($tipoSolicitud === '') {
            $tipoSolicitud = 'requerimiento';
        }
        
        $stmt = $conn->prepare(
            "INSERT INTO tickets
                (
                    id_pais_operacion,
                    titulo,
                    descripcion,
                    estado,
                    urgencia,
                    urgencia_valor,
                    impacto,
                    impacto_valor,
                    prioridad,
                    prioridad_valor,
                    id_usuario,
                    id_tecnico,
                    id_servicio,
                    id_proceso,
                    tipo_solicitud,
                    estado_flujo,
                    fecha_creacion
                )
             VALUES (?, ?, ?, 'abierto', ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, 'en_proceso', NOW())"
        );
        $stmt->bind_param(
            'isssisisiiiis',
            $idPaisOperacion,
            $titulo,
            $descripcion,
            $urgencia,
            $urgenciaConfigurada,
            $impacto,
            $impactoConfigurado,
            $prioridad,
            $prioridadConfigurada,
            $idSolicitante,
            $idGestor,
            $idServicio,
            $tipoSolicitud
        );
        $stmt->execute();
        $idTicket = (int) $conn->insert_id;
        $stmt->close();
        flujoMarcarTicketPrueba($conn, $idTicket);

        // Crear etapa inicial
        $ahora = flujoAhora();
        $slaTiempo = (int) $servicio['sla_tiempo'];
        $slaUnidad = (string) $servicio['sla_unidad'];
        $slaMinutos = flujoSlaMinutosTotales($slaTiempo, $slaUnidad, $conn);
        $vencimiento = calcularVencimientoSla(
            $conn,
            $ahora,
            $slaTiempo,
            $slaUnidad
        );

        $stmt = $conn->prepare(
            "INSERT INTO ticket_etapas
                (
                    id_ticket,
                    id_ticket_etapa_padre,
                    id_proceso_etapa,
                    nivel,
                    orden,
                    id_catalogo,
                    catalogo_nombre,
                    id_servicio,
                    servicio_nombre,
                    id_gestor,
                    gestor_nombre,
                    id_sla,
                    sla_nombre,
                    sla_tiempo,
                    sla_unidad,
                    sla_minutos_total,
                    estado,
                    fecha_activacion,
                    fecha_vencimiento,
                    fecha_ultima_reanudacion,
                    creado_por
                )
             VALUES (?, NULL, NULL, 0, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                     'pendiente', ?, ?, ?, ?)"
        );
        $stmt->bind_param(
            'iisisisisisisssi',
            $idTicket,
            $idCatalogo,
            $servicio['catalogo_nombre'],
            $idServicio,
            $servicio['nombre'],
            $idGestor,
            $servicio['gestor_nombre'],
            $servicio['id_sla'],
            $servicio['sla_nombre'],
            $slaTiempo,
            $slaUnidad,
            $slaMinutos,
            $ahora,
            $vencimiento,
            $ahora,
            $idSolicitante
        );
        $stmt->execute();
        $idEtapa = (int) $conn->insert_id;
        $stmt->close();
        camposExtrasGuardarValores(
            $conn,
            $idTicket,
            $idEtapa,
            $idServicio,
            $camposExtras,
            $idSolicitante
        );

        // Actualizar ticket con la etapa actual
        $stmt = $conn->prepare(
            "UPDATE tickets SET id_etapa_actual = ? WHERE id_ticket = ?"
        );
        $stmt->bind_param('ii', $idEtapa, $idTicket);
        $stmt->execute();
        $stmt->close();

        // Registrar historial
        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idSolicitante,
            'Caso principal abierto',
            'Se creó el Caso ' . $idTicket . ' y se activó la etapa 1 para '
                . $servicio['catalogo_nombre'] . ' / ' . $servicio['nombre']
                . '. Asunto: ' . $titulo . '. Solicitud: ' . $descripcion,
            $idEtapa
        );

        // Notificar al gestor; los incidentes reciben un aviso claramente
        // distinguible para que puedan atenderse antes que un requerimiento.
        $esIncidente = strtolower(trim($tipoSolicitud)) === 'incidente';
        flujoNotificar(
            $conn,
            $idGestor,
            $idTicket,
            $idEtapa,
            $esIncidente ? 'Incidente urgente asignado' : 'Nuevo ticket asignado',
            $esIncidente
                ? "El Caso {$idTicket}, etapa 1, es un incidente y requiere atención prioritaria."
                : "El Caso {$idTicket}, etapa 1, está disponible para su gestión."
        );

        $conn->commit();

        return $idTicket;
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

/**
 * Crea entre uno y veinte hijos hermanos en una sola transacción.
 *
 * @param array<int, array{id_servicio_destino:int,motivo_derivacion:string,campos_extras?:array}> $derivaciones
 * @return array<int, int>
 */
function flujoCrearCasosHijos(
    mysqli $conn,
    int $idTicket,
    int $idNodoPadre,
    array $derivaciones,
    int $idGestorCreador,
    int $rol
): array {
    $idPaisOperacion = paisExigirContexto();
    if ($rol !== 2) {
        throw new RuntimeException(
            'Solo el gestor asignado a la etapa puede crear tickets derivados.'
        );
    }

    if (!$derivaciones || count($derivaciones) > 20) {
        throw new RuntimeException(
            'Agregue entre 1 y 20 derivaciones en la misma operación.'
        );
    }

    $normalizadas = [];
    $serviciosIncluidos = [];

    foreach ($derivaciones as $indice => $derivacion) {
        $idServicio = (int) ($derivacion['id_servicio_destino'] ?? 0);
        $motivo = trim((string) ($derivacion['motivo_derivacion'] ?? ''));

        if ($idServicio < 1 || $motivo === '' || strlen($motivo) > 2000) {
            throw new RuntimeException(
                'Complete el proceso y el requerimiento de la derivación '
                    . ((int) $indice + 1)
                    . '.'
            );
        }

        if (isset($serviciosIncluidos[$idServicio])) {
            throw new RuntimeException(
                'No repita el mismo proceso y servicio en una derivación múltiple.'
            );
        }

        $serviciosIncluidos[$idServicio] = true;
        $normalizadas[] = [
            'id_servicio_destino' => $idServicio,
            'motivo_derivacion' => $motivo,
            'campos_extras' => is_array($derivacion['campos_extras'] ?? null)
                ? $derivacion['campos_extras']
                : [],
        ];
    }

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare(
            "SELECT te.*, t.id_usuario AS id_creador_ticket,
                    t.es_prueba
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             WHERE te.id_ticket = ?
               AND te.id_ticket_etapa = ?
               AND t.id_pais_operacion = ?
             FOR UPDATE"
        );
        $stmt->bind_param('iii', $idTicket, $idNodoPadre, $idPaisOperacion);
        $stmt->execute();
        $padre = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (
            !$padre
            || (
                (int) $padre['id_gestor'] !== $idGestorCreador
                && !(
                    seguridadEsUsuarioPrueba()
                    && (int) ($padre['es_prueba'] ?? 0) === 1
                )
            )
            || !in_array(
                (string) $padre['estado'],
                ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada'],
                true
            )
        ) {
            throw new RuntimeException(
                'La etapa del caso no está disponible para este gestor.'
            );
        }

        $idServicioPadre = (int) ($padre['id_servicio'] ?? 0);
        $serviciosHijosActivos = [];
        $totalHijosActivos = 0;
        $stmt = $conn->prepare(
            "SELECT id_servicio
             FROM ticket_etapas
             WHERE id_ticket = ?
               AND id_ticket_etapa_padre = ?
               AND estado NOT IN ('completada', 'cancelada')
             FOR UPDATE"
        );
        $stmt->bind_param('ii', $idTicket, $idNodoPadre);
        $stmt->execute();
        $resultadoHijosActivos = $stmt->get_result();
        while ($hijoActivo = $resultadoHijosActivos->fetch_assoc()) {
            $totalHijosActivos++;
            $serviciosHijosActivos[(int) ($hijoActivo['id_servicio'] ?? 0)] = true;
        }
        $stmt->close();

        if ($totalHijosActivos + count($normalizadas) > 20) {
            throw new RuntimeException(
                'Una etapa puede tener como máximo 20 derivaciones activas al mismo tiempo.'
            );
        }

        /* Todas las derivaciones hermanas trabajan en paralelo. Este indicador
           solo decide qué hijo conserva el puntero legado del ticket cuando
           todavía no existe otra derivación activa. */
        $asignarPunteroAlPrimerHijo = empty($serviciosHijosActivos);

        foreach ($normalizadas as $derivacion) {
            $idServicioDestino = (int) $derivacion['id_servicio_destino'];

            if ($idServicioDestino === $idServicioPadre) {
                throw new RuntimeException(
                    'No puede solicitar apoyo al mismo servicio que está gestionando actualmente.'
                );
            }

            if (isset($serviciosHijosActivos[$idServicioDestino])) {
                throw new RuntimeException(
                    'Ya existe una derivación activa hacia uno de los servicios seleccionados.'
                );
            }
        }

        $sqlDestino = "SELECT
                s.id_servicio,
                s.nombre AS servicio_nombre,
                c.id_catalogo,
                c.nombre AS catalogo_nombre,
                s.id_gestor,
                u.nombre AS gestor_nombre,
                sl.id_sla,
                sl.nombre AS sla_nombre,
                sl.tiempo_respuesta AS sla_tiempo,
                sl.unidad AS sla_unidad,
                pe.id_proceso_etapa
             FROM servicios AS s
             INNER JOIN catalogos AS c
                ON c.id_catalogo = s.id_catalogo
               AND c.estado = 'activo'
             INNER JOIN usuarios AS u
                ON u.id_usuario = s.id_gestor
               AND u.id_rol = 2
               AND u.estado = 'activo'
             INNER JOIN servicio_gestores AS sg
                ON sg.id_servicio = s.id_servicio
               AND sg.id_usuario = s.id_gestor
               AND sg.estado = 'activo'
             INNER JOIN sla AS sl
                ON sl.id_sla = s.id_sla
               AND sl.estado = 'activo'
             INNER JOIN proceso_etapas AS pe
                ON pe.id_servicio = s.id_servicio
               AND pe.estado = 'activo'
             INNER JOIN procesos AS p
                ON p.id_proceso = pe.id_proceso
               AND p.estado = 'activo'
             WHERE s.id_servicio = ?
               AND s.id_pais_operacion = ?
               AND s.estado = 'activo'
               AND pe.orden = (
                    SELECT MIN(pe_base.orden)
                    FROM proceso_etapas AS pe_base
                    WHERE pe_base.id_proceso = p.id_proceso
                      AND pe_base.estado = 'activo'
               )
             ORDER BY p.id_proceso
             LIMIT 1";
        $stmtDestino = $conn->prepare($sqlDestino);
        $destinos = [];

        foreach ($normalizadas as $derivacion) {
            $idServicioDestino = $derivacion['id_servicio_destino'];
            $stmtDestino->bind_param('ii', $idServicioDestino, $idPaisOperacion);
            $stmtDestino->execute();
            $destino = $stmtDestino->get_result()->fetch_assoc();

            if (!$destino) {
                $stmtDestino->close();
                throw new RuntimeException(
                    'Uno de los servicios destino necesita flujo activo, gestor y SLA.'
                );
            }

            $destinos[] = [
                'configuracion' => $destino,
                'motivo_derivacion' => $derivacion['motivo_derivacion'],
            ];
        }
        $stmtDestino->close();

        $ahora = flujoAhora();
        $padreYaEstabaPausado = $padre['estado'] === 'pausada';

        if (!$padreYaEstabaPausado) {
            $consumidos = flujoMinutosConsumidosNodo($conn, $padre, $ahora);
            $stmt = $conn->prepare(
                "UPDATE ticket_etapas
                 SET estado = 'pausada',
                     sla_minutos_consumidos = ?,
                     fecha_pausa = ?,
                     fecha_ultima_reanudacion = NULL,
                     fecha_vencimiento = NULL,
                     cantidad_pausas = cantidad_pausas + 1
                 WHERE id_ticket_etapa = ?"
            );
            $stmt->bind_param('isi', $consumidos, $ahora, $idNodoPadre);
            $stmt->execute();
            $stmt->close();
        }

        $stmt = $conn->prepare(
            "SELECT COALESCE(MAX(orden), 0) + 1 AS siguiente
             FROM ticket_etapas
             WHERE id_ticket = ?
             FOR UPDATE"
        );
        $stmt->bind_param('i', $idTicket);
        $stmt->execute();
        $orden = (int) $stmt->get_result()->fetch_assoc()['siguiente'];
        $stmt->close();

        $nivel = (int) $padre['nivel'] + 1;
        $codigoPadre = flujoCodigoCaso($conn, $idTicket, $idNodoPadre);
        $numeroEtapaPadre = flujoNumeroEtapaNodo(
            $conn,
            $idTicket,
            $idNodoPadre
        );
        $origenDerivacion = (int) (
            $padre['id_ticket_etapa_padre'] ?? 0
        ) > 0
            ? 'Ticket ' . $codigoPadre
            : 'etapa ' . $numeroEtapaPadre . ' del Caso ' . $idTicket;
        $idsHijos = [];
        $resumenHijos = [];
        $primerHijoCreado = null;
        $hijoActivoNuevo = null;

        foreach ($destinos as $indiceDestino => $itemDestino) {
            $destino = $itemDestino['configuracion'];
            $motivo = (string) $itemDestino['motivo_derivacion'];
            $camposExtrasDestino = is_array($itemDestino['campos_extras'] ?? null)
                ? $itemDestino['campos_extras']
                : [];
            $esPrimeraDerivacion = $indiceDestino === 0;
            $slaTiempo = (int) $destino['sla_tiempo'];
            $slaUnidad = (string) $destino['sla_unidad'];
            $slaMinutos = flujoSlaMinutosTotales($slaTiempo, $slaUnidad, $conn);
            $estadoDerivacion = 'pendiente';
            $fechaActivacionDerivacion = $ahora;
            $vencimiento = calcularVencimientoSla(
                $conn,
                $ahora,
                $slaTiempo,
                $slaUnidad
            );
            $fechaReanudacionDerivacion = $fechaActivacionDerivacion;
            $idProcesoEtapa = (int) $destino['id_proceso_etapa'];
            $idCatalogo = (int) $destino['id_catalogo'];
            $catalogoNombre = (string) $destino['catalogo_nombre'];
            $idServicio = (int) $destino['id_servicio'];
            $servicioNombre = (string) $destino['servicio_nombre'];
            $idGestor = (int) $destino['id_gestor'];
            $gestorNombre = (string) $destino['gestor_nombre'];
            $idSla = (int) $destino['id_sla'];
            $slaNombre = (string) $destino['sla_nombre'];
            $stmt = $conn->prepare(
                "INSERT INTO ticket_etapas
                    (
                        id_ticket_etapa_padre,
                        id_ticket,
                        id_proceso_etapa,
                        nivel,
                        orden,
                        id_catalogo,
                        catalogo_nombre,
                        id_servicio,
                        servicio_nombre,
                        id_gestor,
                        gestor_nombre,
                        id_sla,
                        sla_nombre,
                        sla_tiempo,
                        sla_unidad,
                        sla_minutos_total,
                        estado,
                        fecha_activacion,
                        fecha_vencimiento,
                        fecha_ultima_reanudacion,
                        motivo_derivacion,
                        creado_por
                    )
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                         ?, ?, ?, ?, ?, ?)"
            );
            $stmt->bind_param(
                'iiiiiisisisisisisssssi',
                $idNodoPadre,
                $idTicket,
                $idProcesoEtapa,
                $nivel,
                $orden,
                $idCatalogo,
                $catalogoNombre,
                $idServicio,
                $servicioNombre,
                $idGestor,
                $gestorNombre,
                $idSla,
                $slaNombre,
                $slaTiempo,
                $slaUnidad,
                $slaMinutos,
                $estadoDerivacion,
                $fechaActivacionDerivacion,
                $vencimiento,
                $fechaReanudacionDerivacion,
                $motivo,
                $idGestorCreador
            );
            $stmt->execute();
            $idHijo = (int) $conn->insert_id;
            $stmt->close();
            camposExtrasGuardarValores(
                $conn,
                $idTicket,
                $idHijo,
                $idServicio,
                $camposExtrasDestino,
                $idGestorCreador
            );
            $codigoHijo = flujoCodigoCaso($conn, $idTicket, $idHijo);

            flujoCopiarChecklistPlantilla($conn, $idHijo, $idProcesoEtapa);
            flujoRegistrarHistorial(
                $conn,
                $idTicket,
                $idGestorCreador,
                'Ticket abierto por derivación',
                'Se abrió el Ticket '
                    . $codigoHijo
                    . ' desde '
                    . $origenDerivacion
                    . '. Destino: '
                    . $catalogoNombre
                    . ' / '
                    . $servicioNombre
                    . '. Motivo: '
                    . $motivo,
                $idHijo
            );
            flujoNotificar(
                $conn,
                $idGestor,
                $idTicket,
                $idHijo,
                'Nuevo ticket derivado asignado',
                "Se derivó a su proceso el Ticket {$codigoHijo} del Caso {$idTicket}."
            );
            $idCreadorTicket = (int) ($padre['id_creador_ticket'] ?? 0);

            if (
                $idCreadorTicket > 0
                && !in_array(
                    $idCreadorTicket,
                    [$idGestorCreador, $idGestor],
                    true
                )
            ) {
                flujoNotificar(
                    $conn,
                    $idCreadorTicket,
                    $idTicket,
                    $idHijo,
                    'Nueva dependencia en su ticket',
                    "Se creó el Ticket derivado {$codigoHijo} para {$catalogoNombre} / {$servicioNombre}."
                );
            }

            $idsHijos[] = $idHijo;
            $resumenHijos[] = $codigoHijo . ' (' . $catalogoNombre . ' / '
                . $servicioNombre . ')';
            if ($esPrimeraDerivacion) {
                $primerHijoCreado = [
                    'id_ticket_etapa' => $idHijo,
                    'id_gestor' => $idGestor,
                    'id_servicio' => $idServicio,
                ];
            }
            if ($esPrimeraDerivacion && $asignarPunteroAlPrimerHijo) {
                $hijoActivoNuevo = $primerHijoCreado;
            }
            $orden++;
        }

        if (!$primerHijoCreado) {
            throw new RuntimeException('No fue posible crear las derivaciones.');
        }

        if ($hijoActivoNuevo) {
            $idPrimerHijo = (int) $hijoActivoNuevo['id_ticket_etapa'];
            $idPrimerGestor = (int) $hijoActivoNuevo['id_gestor'];
            $idPrimerServicio = (int) $hijoActivoNuevo['id_servicio'];
            $stmt = $conn->prepare(
                "UPDATE tickets
                 SET id_etapa_actual = ?,
                     id_tecnico = ?,
                     id_servicio = ?,
                     estado = 'en_proceso',
                     estado_flujo = 'en_proceso'
                 WHERE id_ticket = ?"
            );
            $stmt->bind_param(
                'iiii',
                $idPrimerHijo,
                $idPrimerGestor,
                $idPrimerServicio,
                $idTicket
            );
            $stmt->execute();
            $stmt->close();
        }

        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idGestorCreador,
            count($idsHijos) === 1
                ? 'Derivación creada'
                : 'Derivación múltiple creada',
            'El caso '
                . $codigoPadre
                . ($padreYaEstabaPausado
                    ? ' mantuvo su SLA pausado y creó '
                    : ' pausó su SLA y creó ')
                . count($idsHijos)
                . ' caso(s) hijo(s): '
                . implode(', ', $resumenHijos)
                . '.',
            $idNodoPadre
        );

        $conn->commit();

        return $idsHijos;
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function flujoCrearCasoHijo(
    mysqli $conn,
    int $idTicket,
    int $idNodoPadre,
    int $idServicioDestino,
    int $idGestorCreador,
    int $rol,
    string $motivo
): int {
    $ids = flujoCrearCasosHijos(
        $conn,
        $idTicket,
        $idNodoPadre,
        [[
            'id_servicio_destino' => $idServicioDestino,
            'motivo_derivacion' => $motivo,
        ]],
        $idGestorCreador,
        $rol
    );

    return $ids[0];
}

/**
 * @return array<string, mixed>|null
 */
function flujoObtenerTicket(mysqli $conn, int $idTicket): ?array
{
    $idPaisOperacion = paisExigirContexto();
    $filtroCasosPrueba = seguridadFiltroCasosOficiales('t');
    $stmt = $conn->prepare(
        "SELECT
            t.*,
            p.nombre AS proceso_nombre,
            u.nombre AS creador_nombre,
            u.nombre AS solicitante_nombre,
            u.email AS solicitante_email
         FROM tickets AS t
         INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
         LEFT JOIN usuarios AS u ON u.id_usuario = t.id_usuario
         WHERE t.id_ticket = ?
           AND t.id_pais_operacion = ?
           {$filtroCasosPrueba}
           AND t.id_proceso IS NOT NULL
         LIMIT 1"
    );
    $stmt->bind_param('ii', $idTicket, $idPaisOperacion);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $fila ?: null;
}

/** Reactiva derivaciones que una versión anterior bloqueó al leer el caso. */
function flujoActivarDerivacionesParalelas(
    mysqli $conn,
    int $idTicket
): void {
    $stmt = $conn->prepare(
        "SELECT hija.id_ticket_etapa, hija.sla_tiempo, hija.sla_unidad,
                hija.creado_en
         FROM ticket_etapas AS hija
         INNER JOIN ticket_etapas AS padre
            ON padre.id_ticket_etapa = hija.id_ticket_etapa_padre
           AND padre.id_ticket = hija.id_ticket
         WHERE hija.id_ticket = ?
           AND hija.estado = 'bloqueada'
           AND padre.estado = 'pausada'"
    );
    $stmt->bind_param('i', $idTicket);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $bloqueadas = [];
    while ($fila = $resultado->fetch_assoc()) {
        $bloqueadas[] = $fila;
    }
    $stmt->close();

    $ahora = flujoAhora();
    foreach ($bloqueadas as $hija) {
        $idHija = (int) $hija['id_ticket_etapa'];
        $inicio = (string) ($hija['creado_en'] ?: $ahora);
        $vencimiento = calcularVencimientoSla(
            $conn,
            $inicio,
            (int) $hija['sla_tiempo'],
            (string) $hija['sla_unidad']
        );
        $stmt = $conn->prepare(
            "UPDATE ticket_etapas
             SET estado = 'pendiente',
                 fecha_activacion = COALESCE(fecha_activacion, ?),
                 fecha_vencimiento = ?,
                 fecha_ultima_reanudacion = ?,
                 resultado_sla = 'sin_iniciar'
             WHERE id_ticket_etapa = ?
               AND id_ticket = ?
               AND estado = 'bloqueada'"
        );
        $stmt->bind_param('sssii', $inicio, $vencimiento, $inicio, $idHija, $idTicket);
        $stmt->execute();
        $stmt->close();
    }
}

/**
 * @return array<int, array<string, mixed>>
 */
function flujoObtenerEtapasTicket(mysqli $conn, int $idTicket): array
{
    $idPaisOperacion = paisExigirContexto();
    $filtroCasosPrueba = seguridadFiltroCasosOficiales('t');
    /* Recupera las derivaciones que la antigua navegación secuencial bloqueó. */
    flujoActivarDerivacionesParalelas($conn, $idTicket);
    /* Reaplica el calendario vigente, incluidos los festivos y periodos
       administrativos que hayan sido creados, modificados o inhabilitados. */
    flujoRecalcularVencimientosActivos($conn, $idTicket);

    $columnasCalificacion = flujoModuloCalificacionDetalladaInstalado($conn)
        ? "cal.calificacion_area, cal.calificacion_tiempo,"
        : "cal.calificacion AS calificacion_area,
           cal.calificacion AS calificacion_tiempo,";
    $columnaTipoCalificacion = flujoModuloAprobacionCasosInstalado($conn)
        ? "cal.tipo_calificacion,"
        : "'historica' AS tipo_calificacion,";

    $stmt = $conn->prepare(
        "SELECT
            te.*,
            COALESCE(
                NULLIF(TRIM(gestor_actual.nombre), ''),
                NULLIF(TRIM(te.gestor_nombre), ''),
                'Pendiente'
            ) AS gestor_nombre_actual,
            CASE
                WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                ELSE padre_decision.id_gestor
            END AS id_creador_caso,
            COALESCE(creador_caso.nombre, creador_ticket.nombre, 'Usuario eliminado') AS creador_caso_nombre,
            COALESCE(marcador_listo.nombre, 'Sin marcar') AS marcador_listo_nombre,
            COALESCE(cerrador.nombre, 'Sin cerrar') AS cerrador_caso_nombre,
            COALESCE(evaluador.nombre, 'Sin calificar') AS evaluador_nombre,
            (SELECT COUNT(*)
             FROM ticket_etapas AS h
             WHERE h.id_ticket_etapa_padre = te.id_ticket_etapa) AS total_hijos,
            (SELECT COUNT(*)
             FROM ticket_etapas AS h
             WHERE h.id_ticket_etapa_padre = te.id_ticket_etapa
               AND h.estado NOT IN ('completada', 'cancelada')) AS hijos_pendientes,
            cal.id_calificacion,
            cal.calificacion,
            {$columnasCalificacion}
            {$columnaTipoCalificacion}
            cal.comentario AS comentario_calificacion
         FROM ticket_etapas AS te
         INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
         LEFT JOIN usuarios AS gestor_actual
            ON gestor_actual.id_usuario = te.id_gestor
         LEFT JOIN usuarios AS creador_ticket
            ON creador_ticket.id_usuario = t.id_usuario
         LEFT JOIN ticket_etapas AS padre_decision
            ON padre_decision.id_ticket_etapa = te.id_ticket_etapa_padre
           AND padre_decision.id_ticket = te.id_ticket
         LEFT JOIN usuarios AS creador_caso
            ON creador_caso.id_usuario = CASE
                WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                ELSE padre_decision.id_gestor
            END
         LEFT JOIN usuarios AS marcador_listo
            ON marcador_listo.id_usuario = te.marcado_listo_por
         LEFT JOIN usuarios AS cerrador
            ON cerrador.id_usuario = te.completado_por
         LEFT JOIN solicitud_calificaciones AS cal
            ON cal.id_ticket_etapa = te.id_ticket_etapa
         LEFT JOIN usuarios AS evaluador
            ON evaluador.id_usuario = cal.id_solicitante
         WHERE te.id_ticket = ?
           AND t.id_pais_operacion = ?
           {$filtroCasosPrueba}
         ORDER BY te.orden, te.id_ticket_etapa"
    );
    $stmt->bind_param('ii', $idTicket, $idPaisOperacion);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $filas = [];

    while ($fila = $resultado->fetch_assoc()) {
        $fila['gestor_nombre'] = (string) (
            $fila['gestor_nombre_actual']
            ?? $fila['gestor_nombre']
            ?? 'Pendiente'
        );
        $consumidos = flujoMinutosConsumidosNodo(
            $conn,
            $fila,
            null,
            true
        );
        $total = flujoSlaMinutosTotalesNodo($fila, $conn);
        $fila['sla_minutos_consumidos_actuales'] = $consumidos;
        $fila['sla_minutos_restantes'] = max(0, $total - $consumidos);
        $fila['minutos_indicador'] = $fila['minutos_hasta_listo']
            ?? $fila['minutos_atencion'];
        $fila['resultado_sla_indicador'] = $fila['resultado_sla_listo']
            ?? $fila['resultado_sla'];
        $fila['estado_sla_actual'] = (fn ($__mesaMatchValue11) => (($__mesaMatchValue11 === ('completada')) ? ((string) $fila['resultado_sla']) : ((($__mesaMatchValue11 === ('pausada')) ? ('pausado') : ((($__mesaMatchValue11 === ('cancelada') || $__mesaMatchValue11 === ('bloqueada')) ? ('sin_iniciar') : ($total > 0 && $consumidos > $total
                ? 'vencido'
                : 'en_tiempo')))))))((string) $fila['estado']);
        $filas[] = $fila;
    }

    $stmt->close();

    $derivacionActivaPorPadre = [];

    foreach ($filas as $fila) {
        $idPadre = (int) ($fila['id_ticket_etapa_padre'] ?? 0);
        $estado = (string) ($fila['estado'] ?? '');

        if (
            $idPadre > 0
            && !isset($derivacionActivaPorPadre[$idPadre])
            && !in_array(
                $estado,
                ['completada', 'cancelada', 'bloqueada'],
                true
            )
        ) {
            $derivacionActivaPorPadre[$idPadre] = $fila;
        }
    }

    foreach ($filas as &$fila) {
        $idEtapa = (int) ($fila['id_ticket_etapa'] ?? 0);

        if (
            (int) ($fila['id_ticket_etapa_padre'] ?? 0) === 0
            && isset($derivacionActivaPorPadre[$idEtapa])
        ) {
            $derivacionActiva = $derivacionActivaPorPadre[$idEtapa];
            $fila['gestor_nombre'] = (string) (
                $derivacionActiva['gestor_nombre'] ?? 'Pendiente'
            );
            $fila['gestor_derivacion_activa'] = true;
            $fila['id_gestor_derivacion_activa'] = (int) (
                $derivacionActiva['id_gestor'] ?? 0
            );
        }
    }

    unset($fila);

    return $filas;
}

function flujoPuedeVerTicket(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol
): bool {
    $filtroCasosPrueba = seguridadFiltroCasosOficiales('t');
    if ($rol === 1) {
        return flujoObtenerTicket($conn, $idTicket) !== null;
    }

    if ($rol === 2) {
        $idPaisOperacion = paisExigirContexto();
        if (seguridadEsUsuarioPrueba()) {
            $stmt = $conn->prepare(
                "SELECT 1
                 FROM tickets AS t
                 WHERE t.id_ticket = ?
                   AND t.id_pais_operacion = ?
                   AND t.es_prueba = 1
                   AND t.id_proceso IS NOT NULL
                 LIMIT 1"
            );
            $stmt->bind_param('ii', $idTicket, $idPaisOperacion);
        } else {
            $stmt = $conn->prepare(
                "SELECT 1
                 FROM tickets AS t
                 LEFT JOIN ticket_etapas AS te
                    ON te.id_ticket = t.id_ticket
                   AND te.id_gestor = ?
                 WHERE t.id_ticket = ?
                   AND t.id_pais_operacion = ?
                   {$filtroCasosPrueba}
                   AND t.id_proceso IS NOT NULL
                   AND te.id_ticket_etapa IS NOT NULL
                 LIMIT 1"
            );
            $stmt->bind_param('iii', $idUsuario, $idTicket, $idPaisOperacion);
        }
    } elseif ($rol === 3) {
        $idPaisOperacion = paisExigirContexto();
        $stmt = $conn->prepare(
            "SELECT 1
             FROM tickets AS t
             WHERE t.id_ticket = ?
               AND t.id_usuario = ?
               AND t.id_pais_operacion = ?
               {$filtroCasosPrueba}
               AND t.id_proceso IS NOT NULL
             LIMIT 1"
        );
        $stmt->bind_param('iii', $idTicket, $idUsuario, $idPaisOperacion);
    } else {
        return false;
    }

    $stmt->execute();
    $stmt->store_result();
    $puede = $stmt->num_rows > 0;
    $stmt->close();

    return $puede;
}

function flujoPuedeEscribirChat(
    mysqli $conn,
    array $ticket,
    int $idUsuario,
    int $rol
): bool {
    if (in_array((string) $ticket['estado'], ['cerrada', 'cancelada'], true)) {
        return false;
    }

    /* Al terminar la última etapa el chat queda en modo lectura. */
    if ((int) ($ticket['id_etapa_actual'] ?? 0) < 1) {
        return false;
    }

    if ($rol === 1) {
        return true;
    }

    if ($rol !== 2 || (int) $ticket['id_etapa_actual'] < 1) {
        return false;
    }

    $idEtapaActual = (int) $ticket['id_etapa_actual'];
    $stmt = $conn->prepare(
        "SELECT 1
         FROM ticket_etapas
         WHERE id_ticket_etapa = ?
           AND id_ticket = ?
           AND (id_gestor = ? OR ? = ?)
           AND estado IN ('pendiente', 'en_proceso', 'en_espera_solicitante')
         LIMIT 1"
    );
    $idTicket = (int) $ticket['id_ticket'];
    $idCreador = (int) $ticket['id_usuario'];
    $stmt->bind_param(
        'iiiii',
        $idEtapaActual,
        $idTicket,
        $idUsuario,
        $idCreador,
        $idUsuario
    );
    $stmt->execute();
    $stmt->store_result();
    $puede = $stmt->num_rows > 0;
    $stmt->close();

    return $puede;
}

function flujoPuedeEscribirNodo(
    mysqli $conn,
    array $ticket,
    int $idTicketEtapa,
    int $idUsuario,
    int $rol
): bool {
    if (in_array((string) $ticket['estado'], ['cerrada', 'cancelada'], true)) {
        return false;
    }

    $nodo = flujoObtenerNodo(
        $conn,
        (int) $ticket['id_ticket'],
        $idTicketEtapa
    );

    if (!$nodo) {
        return false;
    }

    if (!in_array($rol, [2, 3], true)) {
        /* Administración conserva auditoría de lectura, pero no interviene en
           conversaciones operativas ni internas. */
        return false;
    }

    if (!in_array(
        (string) $nodo['estado'],
        ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada'],
        true
    )) {
        return false;
    }

    if (
        $rol === 3
        && (
            (int) ($nodo['id_ticket_etapa_padre'] ?? 0) > 0
            || (int) ($ticket['id_usuario'] ?? 0) !== $idUsuario
        )
    ) {
        return false;
    }

    return flujoPuedeVerConversacionNodo(
        $conn,
        (int) $ticket['id_ticket'],
        $idTicketEtapa,
        $idUsuario,
        $rol
    );
}

/**
 * @return array<string, mixed>|null
 */
function flujoEtapaActual(mysqli $conn, int $idTicket): ?array
{
    $idPaisOperacion = paisExigirContexto();
    $filtroCasosPrueba = seguridadFiltroCasosOficiales('t');
    $stmt = $conn->prepare(
        "SELECT te.*
         FROM tickets AS t
         INNER JOIN ticket_etapas AS te
            ON te.id_ticket_etapa = t.id_etapa_actual
         WHERE t.id_ticket = ?
           AND t.id_pais_operacion = ?
           {$filtroCasosPrueba}
         LIMIT 1"
    );
    $stmt->bind_param('ii', $idTicket, $idPaisOperacion);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $fila ?: null;
}

/**
 * Selecciona el nodo que se mostrará en el panel lateral. La trazabilidad
 * completa sigue visible para todos los usuarios autorizados.
 *
 * @return array<string, mixed>|null
 */
function flujoSeleccionarNodoTicket(
    mysqli $conn,
    int $idTicket,
    int $idUsuario,
    int $rol,
    int $idPreferido = 0
): ?array {
    if ($idPreferido > 0) {
        $nodo = flujoObtenerNodo($conn, $idTicket, $idPreferido);

        if (
            $nodo
            && (
                $rol === 1
                || flujoPuedeVerConversacionNodo(
                    $conn,
                    $idTicket,
                    $idPreferido,
                    $idUsuario,
                    $rol
                )
            )
        ) {
            return $nodo;
        }
    }

    if ($rol === 2) {
        $stmt = $conn->prepare(
            "SELECT te.*
             FROM ticket_etapas AS te
             WHERE te.id_ticket = ?
               AND te.id_gestor = ?
             ORDER BY
                (te.id_gestor = ?) DESC,
                FIELD(
                    te.estado,
                    'listo_cierre',
                    'en_proceso',
                    'pendiente',
                    'en_espera_solicitante',
                    'pausada',
                    'completada',
                    'cancelada',
                    'bloqueada'
                ),
                te.orden DESC
             LIMIT 1"
        );
        $stmt->bind_param(
            'iii',
            $idTicket,
            $idUsuario,
            $idUsuario
        );
    } else {
        $stmt = $conn->prepare(
            "SELECT te.*
             FROM ticket_etapas AS te
             LEFT JOIN tickets AS t
                ON t.id_ticket = te.id_ticket
             WHERE te.id_ticket = ?
             ORDER BY
                (te.id_ticket_etapa = t.id_etapa_actual) DESC,
                FIELD(
                    te.estado,
                    'listo_cierre',
                    'en_proceso',
                    'pendiente',
                    'en_espera_solicitante',
                    'pausada',
                    'completada',
                    'cancelada',
                    'bloqueada'
                ),
                te.orden DESC
             LIMIT 1"
        );
        $stmt->bind_param('i', $idTicket);
    }

    $stmt->execute();
    $nodo = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $nodo ?: null;
}

function flujoGuardarComunicacion(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idUsuario,
    string $mensaje
): void {
    $stmt = $conn->prepare(
        "SELECT id_ticket_etapa_padre
         FROM ticket_etapas
         WHERE id_ticket = ?
           AND id_ticket_etapa = ?
         LIMIT 1"
    );
    $stmt->bind_param('ii', $idTicket, $idTicketEtapa);
    $stmt->execute();
    $nodo = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$nodo) {
        throw new RuntimeException('La conversación indicada no existe.');
    }

    $tipo = $nodo['id_ticket_etapa_padre'] === null
        ? 'publica'
        : 'interna';
    $stmt = $conn->prepare(
        "INSERT INTO solicitud_comunicaciones
            (id_ticket, id_ticket_etapa, id_emisor, tipo, mensaje)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param(
        'iiiss',
        $idTicket,
        $idTicketEtapa,
        $idUsuario,
        $tipo,
        $mensaje
    );
    $stmt->execute();
    $stmt->close();
}

/**
 * @return array<int, array<string, mixed>>
 */
function flujoComunicacionesNodo(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa
): array {
    $stmt = $conn->prepare(
        "SELECT
            sc.*,
            u.nombre AS emisor,
            u.id_rol AS emisor_rol
         FROM solicitud_comunicaciones AS sc
         INNER JOIN ticket_etapas AS te
            ON te.id_ticket_etapa = sc.id_ticket_etapa
           AND te.id_ticket = sc.id_ticket
         LEFT JOIN usuarios AS u ON u.id_usuario = sc.id_emisor
         WHERE sc.id_ticket = ?
           AND sc.id_ticket_etapa = ?
           AND (
                te.id_ticket_etapa_padre IS NOT NULL
                OR sc.tipo = 'publica'
           )
         ORDER BY sc.creado_en, sc.id_comunicacion"
    );
    $stmt->bind_param('ii', $idTicket, $idTicketEtapa);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $filas = [];

    while ($fila = $resultado->fetch_assoc()) {
        $filas[] = $fila;
    }

    $stmt->close();

    return $filas;
}

/**
 * @return array<int, array<string, mixed>>
 */
function flujoAdjuntosNodo(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa
): array {
    $stmt = $conn->prepare(
        "SELECT
            a.*,
            u.nombre AS usuario,
            u.id_rol AS usuario_rol
         FROM solicitud_adjuntos AS a
         LEFT JOIN usuarios AS u ON u.id_usuario = a.id_usuario
         WHERE a.id_ticket = ?
           AND a.id_ticket_etapa = ?
         ORDER BY a.creado_en, a.id_adjunto"
    );
    $stmt->bind_param('ii', $idTicket, $idTicketEtapa);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $filas = [];

    while ($fila = $resultado->fetch_assoc()) {
        $filas[] = $fila;
    }

    $stmt->close();

    return $filas;
}

/**
 * Une mensajes y archivos en una sola línea de tiempo para que el chat pueda
 * presentar los documentos en el punto en que fueron enviados.
 *
 * @param array<int, array<string, mixed>> $comunicaciones
 * @param array<int, array<string, mixed>> $adjuntos
 * @return array<int, array<string, mixed>>
 */
function flujoLineaTiempoConversacion(
    array $comunicaciones,
    array $adjuntos
): array {
    $eventos = [];

    foreach ($comunicaciones as $comunicacion) {
        $comunicacion['tipo_evento'] = 'mensaje';
        $comunicacion['id_evento'] = (int) (
            $comunicacion['id_comunicacion'] ?? 0
        );
        $comunicacion['id_autor'] = (int) (
            $comunicacion['id_emisor'] ?? 0
        );
        $comunicacion['autor'] = (string) (
            $comunicacion['emisor'] ?? 'Usuario'
        );
        $comunicacion['autor_rol'] = (int) (
            $comunicacion['emisor_rol'] ?? 0
        );
        $eventos[] = $comunicacion;
    }

    foreach ($adjuntos as $adjunto) {
        $adjunto['tipo_evento'] = 'adjunto';
        $adjunto['id_evento'] = (int) ($adjunto['id_adjunto'] ?? 0);
        $adjunto['id_autor'] = (int) ($adjunto['id_usuario'] ?? 0);
        $adjunto['autor'] = (string) ($adjunto['usuario'] ?? 'Usuario');
        $adjunto['autor_rol'] = (int) ($adjunto['usuario_rol'] ?? 0);
        $eventos[] = $adjunto;
    }

    usort(
        $eventos,
        static function (array $primero, array $segundo): int {
            $fechaPrimero = (string) ($primero['creado_en'] ?? '');
            $fechaSegundo = (string) ($segundo['creado_en'] ?? '');
            $comparacionFecha = strcmp($fechaPrimero, $fechaSegundo);

            if ($comparacionFecha !== 0) {
                return $comparacionFecha;
            }

            $ordenPrimero = (string) ($primero['tipo_evento'] ?? '')
                === 'mensaje' ? 0 : 1;
            $ordenSegundo = (string) ($segundo['tipo_evento'] ?? '')
                === 'mensaje' ? 0 : 1;

            if ($ordenPrimero !== $ordenSegundo) {
                return $ordenPrimero <=> $ordenSegundo;
            }

            return (int) ($primero['id_evento'] ?? 0)
                <=> (int) ($segundo['id_evento'] ?? 0);
        }
    );

    return $eventos;
}

function flujoFormatoTamanoArchivo(int $bytes): string
{
    if ($bytes < 1024) {
        return max(0, $bytes) . ' B';
    }

    if ($bytes < 1024 * 1024) {
        return number_format($bytes / 1024, 1, ',', '.') . ' KB';
    }

    return number_format($bytes / (1024 * 1024), 1, ',', '.') . ' MB';
}

function flujoNotificarConversacion(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idEmisor,
    bool $incluyeAdjuntos = false
): void {
    $participantes = flujoParticipantesConversacion(
        $conn,
        $idTicket,
        $idTicketEtapa
    );

    if (!$participantes) {
        return;
    }

    $nodoMensaje = flujoObtenerNodo($conn, $idTicket, $idTicketEtapa);
    $esDerivacion = (int) (
        $nodoMensaje['id_ticket_etapa_padre'] ?? 0
    ) > 0;
    $codigo = flujoCodigoCaso($conn, $idTicket, $idTicketEtapa);
    $etiqueta = $esDerivacion
        ? 'Ticket ' . $codigo
        : 'Caso ' . $idTicket . ' · etapa '
            . flujoNumeroEtapaNodo($conn, $idTicket, $idTicketEtapa);
    $destinatarios = array_unique(array_values($participantes));

    foreach ($destinatarios as $idDestinatario) {
        $idDestinatario = (int) $idDestinatario;

        if ($idDestinatario < 1 || $idDestinatario === $idEmisor) {
            continue;
        }

        flujoNotificar(
            $conn,
            $idDestinatario,
            $idTicket,
            $idTicketEtapa,
            'Nuevo mensaje en ' . $etiqueta,
            $incluyeAdjuntos
                ? "Recibió un mensaje o documento en el chat privado de {$etiqueta}."
                : "Recibió un mensaje en el chat privado de {$etiqueta}."
        );
    }
}

/**
 * @return array<int, string> referencias creadas para poder revertirlas.
 */
function flujoGuardarAdjuntos(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idUsuario,
    array $entrada
): array {
    if (!isset($entrada['name'])) {
        return [];
    }

    $nombres = is_array($entrada['name'])
        ? $entrada['name']
        : [$entrada['name']];
    $temporales = is_array($entrada['tmp_name'])
        ? $entrada['tmp_name']
        : [$entrada['tmp_name']];
    $errores = is_array($entrada['error'])
        ? $entrada['error']
        : [$entrada['error']];
    $tamanos = is_array($entrada['size'])
        ? $entrada['size']
        : [$entrada['size']];

    if (count($nombres) > 5) {
        throw new RuntimeException('Puede cargar máximo cinco archivos por mensaje.');
    }

    $permitidos = [
        'application/pdf' => 'pdf',
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'text/plain' => 'txt',
        'text/csv' => 'csv',
        'application/zip' => 'zip',
        'application/x-zip-compressed' => 'zip',
        'application/msword' => 'doc',
        'application/vnd.ms-excel' => 'xls',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
    ];
    $usaGraph = almacenamientoUsaGraph();
    $directorio = seguridadDirectorioPrivado('solicitudes');
    if ($usaGraph) {
        almacenamientoPrepararEsquema($conn);
    } elseif (
        !is_dir($directorio)
        && !mkdir($directorio, 0750, true)
        && !is_dir($directorio)
    ) {
        throw new RuntimeException('No se pudo preparar la carpeta de archivos.');
    }

    $stmtPais = $conn->prepare(
        'SELECT id_pais_operacion FROM tickets WHERE id_ticket = ? LIMIT 1'
    );
    $stmtPais->bind_param('i', $idTicket);
    $stmtPais->execute();
    $filaPais = $stmtPais->get_result()->fetch_assoc();
    $stmtPais->close();
    $idPais = (int) ($filaPais['id_pais_operacion'] ?? 0);
    $codigoPais = almacenamientoCodigoPais($conn, $idPais);

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $creados = [];

    try {
      foreach ($nombres as $indice => $nombreEntrada) {
        $error = (int) ($errores[$indice] ?? UPLOAD_ERR_NO_FILE);

        if ($error === UPLOAD_ERR_NO_FILE) {
            continue;
        }

        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException('Uno de los archivos no pudo cargarse.');
        }

        $tamano = (int) ($tamanos[$indice] ?? 0);

        if ($tamano < 1 || $tamano > 5 * 1024 * 1024) {
            throw new RuntimeException('Cada archivo debe pesar máximo 5 MB.');
        }

        $temporal = (string) ($temporales[$indice] ?? '');
        $mime = (string) $finfo->file($temporal);

        if (!isset($permitidos[$mime])) {
            throw new RuntimeException('Uno de los formatos adjuntos no está permitido.');
        }

        $nombreOriginal = trim(basename((string) $nombreEntrada));
        $nombreOriginal = $nombreOriginal !== '' ? $nombreOriginal : 'adjunto';
        $nombreGuardado = 'flujo_' . $idTicket . '_' . $idTicketEtapa . '_'
            . bin2hex(random_bytes(12))
            . '.' . $permitidos[$mime];
        $objeto = null;
        if ($usaGraph) {
            $objeto = almacenamientoGuardarGraph(
                'adjuntos/' . $codigoPais . '/' . date('Y') . '/' . date('m'),
                $temporal,
                $nombreGuardado,
                $mime
            );
            $rutaRelativa = (string) $objeto['referencia'];
            $creados[] = $rutaRelativa;
        } else {
            $rutaRelativa = 'private/solicitudes/' . $nombreGuardado;
            $rutaFisica = $directorio . DIRECTORY_SEPARATOR . $nombreGuardado;
            if (!move_uploaded_file($temporal, $rutaFisica)) {
                throw new RuntimeException('No fue posible guardar un archivo adjunto.');
            }
            @chmod($rutaFisica, 0640);
            $creados[] = $rutaFisica;
        }

        $stmt = $conn->prepare(
            "INSERT INTO solicitud_adjuntos
                (
                    id_ticket,
                    id_ticket_etapa,
                    id_usuario,
                    nombre_original,
                    nombre_guardado,
                    ruta,
                    tipo_mime,
                    tamano
                )
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param(
            'iiissssi',
            $idTicket,
            $idTicketEtapa,
            $idUsuario,
            $nombreOriginal,
            $nombreGuardado,
            $rutaRelativa,
            $mime,
            $tamano
        );
        $stmt->execute();
        $idAdjunto = (int) $conn->insert_id;
        $stmt->close();

        if (is_array($objeto)) {
            almacenamientoRegistrarObjeto(
                $conn,
                'solicitud_adjunto',
                $idAdjunto,
                $idPais,
                $objeto,
                $nombreOriginal
            );
        }
      }
    } catch (Throwable $e) {
        foreach ($creados as $referenciaCreada) {
            almacenamientoEliminarReferencia($referenciaCreada);
        }
        throw $e;
    }

    return $creados;
}

function flujoEnviarConversacion(
    mysqli $conn,
    array $ticket,
    int $idTicketEtapa,
    int $idUsuario,
    int $rol,
    string $mensaje,
    array $entradaAdjuntos = []
): void {
    $idTicket = (int) ($ticket['id_ticket'] ?? 0);
    $mensaje = trim($mensaje);
    $errores = isset($entradaAdjuntos['error'])
        ? (is_array($entradaAdjuntos['error'])
            ? $entradaAdjuntos['error']
            : [$entradaAdjuntos['error']])
        : [];
    $hayArchivos = count(array_filter(
        $errores,
        static fn ($error): bool =>
            (int) $error !== UPLOAD_ERR_NO_FILE
    )) > 0;

    if (
        $idTicket < 1
        || $idTicketEtapa < 1
        || !flujoPuedeEscribirNodo(
            $conn,
            $ticket,
            $idTicketEtapa,
            $idUsuario,
            $rol
        )
    ) {
        throw new RuntimeException(
            'La conversación no está habilitada para este usuario o etapa.'
        );
    }

    if ($mensaje === '' && !$hayArchivos) {
        throw new RuntimeException('Escriba un mensaje o seleccione un archivo.');
    }

    if (strlen($mensaje) > 10000) {
        throw new RuntimeException('El mensaje supera los 10.000 caracteres.');
    }

    $nodo = flujoObtenerNodo($conn, $idTicket, $idTicketEtapa);
    $esDerivacionInterna = (int) ($nodo['id_ticket_etapa_padre'] ?? 0) > 0;
    $rutas = [];
    if ($hayArchivos && almacenamientoUsaGraph()) {
        almacenamientoPrepararEsquema($conn);
    }
    $conn->begin_transaction();

    try {
        if ($mensaje !== '') {
            flujoGuardarComunicacion(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                $mensaje
            );
        }

        if ($hayArchivos) {
            $rutas = flujoGuardarAdjuntos(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                $entradaAdjuntos
            );
        }

        flujoNotificarConversacion(
            $conn,
            $idTicket,
            $idTicketEtapa,
            $idUsuario,
            count($rutas) > 0
        );
        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idUsuario,
            $esDerivacionInterna
                ? 'Comunicación interna registrada'
                : 'Comunicación con el solicitante registrada',
            'Se agregó un mensaje o archivo al '
                . ($esDerivacionInterna
                    ? 'chat interno del '
                    : 'chat de ')
                . flujoEtiquetaNodo($conn, $idTicket, $idTicketEtapa)
                . '.',
            $idTicketEtapa
        );
        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();

        foreach ($rutas as $ruta) {
            almacenamientoEliminarReferencia($ruta);
        }

        throw $e;
    }
}

/**
 * @return array<int, array<string, mixed>>
 */
function flujoChecklistEtapa(mysqli $conn, int $idTicketEtapa): array
{
    flujoSincronizarChecklistEtapaAbierta($conn, $idTicketEtapa);

    $stmt = $conn->prepare(
        "SELECT *
         FROM ticket_etapa_checklist
         WHERE id_ticket_etapa = ?
         ORDER BY orden, id_ticket_checklist"
    );
    $stmt->bind_param('i', $idTicketEtapa);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $filas = [];

    while ($fila = $resultado->fetch_assoc()) {
        $filas[] = $fila;
    }

    $stmt->close();

    return $filas;
}

function flujoGuardarChecklist(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idUsuario,
    int $rol,
    array $seleccionados,
    array $observaciones
): void {
    $etapa = flujoObtenerNodo($conn, $idTicket, $idTicketEtapa);

    if (
        !$etapa
        || !in_array(
            (string) $etapa['estado'],
            ['pendiente', 'en_proceso', 'en_espera_solicitante'],
            true
        )
        || (
            $rol !== 1
            && !seguridadEsUsuarioPrueba()
            && (int) $etapa['id_gestor'] !== $idUsuario
        )
    ) {
        throw new RuntimeException('La etapa no está disponible para este gestor.');
    }

    $items = flujoChecklistEtapa($conn, $idTicketEtapa);
    $stmt = $conn->prepare(
        "UPDATE ticket_etapa_checklist
         SET completado = ?,
             observacion = NULLIF(?, ''),
             completado_por = CASE WHEN ? = 1 THEN ? ELSE NULL END,
             completado_en = CASE WHEN ? = 1 THEN NOW() ELSE NULL END
         WHERE id_ticket_checklist = ?
           AND id_ticket_etapa = ?"
    );

    foreach ($items as $item) {
        $idItem = (int) $item['id_ticket_checklist'];
        $completado = isset($seleccionados[$idItem]) ? 1 : 0;
        $observacion = trim((string) ($observaciones[$idItem] ?? ''));
        $stmt->bind_param(
            'isiiiii',
            $completado,
            $observacion,
            $completado,
            $idUsuario,
            $completado,
            $idItem,
            $idTicketEtapa
        );
        $stmt->execute();
    }

    $stmt->close();
    $stmt = $conn->prepare(
        "UPDATE ticket_etapas
         SET estado = 'en_proceso'
         WHERE id_ticket_etapa = ?
           AND estado = 'pendiente'"
    );
    $stmt->bind_param('i', $idTicketEtapa);
    $stmt->execute();
    $stmt->close();
    flujoRegistrarHistorial(
        $conn,
        $idTicket,
        $idUsuario,
        'Checklist actualizado',
        'El gestor actualizó el checklist de la etapa activa.',
        $idTicketEtapa
    );
}

/**
 * Crea una solución reutilizable para un servicio o devuelve la existente
 * cuando ya hay una activa con el mismo nombre. Debe ejecutarse dentro de una
 * transacción cuando forme parte de otra operación del flujo.
 *
 * @return array{id_solucion:int,nombre:string,descripcion:string,creada:bool}
 */
function flujoCrearSolucionServicio(
    mysqli $conn,
    int $idServicio,
    int $idUsuario,
    string $nombre,
    string $descripcion
): array {
    $nombre = trim($nombre);
    $descripcion = trim($descripcion);

    if (
        $idServicio < 1
        || $idUsuario < 1
        || $nombre === ''
        || $descripcion === ''
        || strlen($nombre) > 180
        || strlen($descripcion) > 500
    ) {
        throw new RuntimeException(
            'La solución debe tener un nombre y una descripción válidos.'
        );
    }

    if (!flujoTablaExiste($conn, 'soluciones_servicio')) {
        throw new RuntimeException(
            'El administrador debe instalar el módulo de soluciones por servicio.'
        );
    }

    $stmt = $conn->prepare(
        "SELECT id_solucion, nombre, descripcion, estado
         FROM soluciones_servicio
         WHERE id_servicio = ?
           AND nombre = ?
         LIMIT 1
         FOR UPDATE"
    );
    $stmt->bind_param('is', $idServicio, $nombre);
    $stmt->execute();
    $existente = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($existente && (string) $existente['estado'] !== 'activo') {
        throw new RuntimeException(
            'Ya existe una solución retirada con ese nombre. Solicite al administrador que la reactive.'
        );
    }

    if ($existente) {
        return [
            'id_solucion' => (int) $existente['id_solucion'],
            'nombre' => trim((string) $existente['nombre']),
            'descripcion' => trim((string) ($existente['descripcion'] ?? '')),
            'creada' => false,
        ];
    }

    $stmt = $conn->prepare(
        "SELECT COALESCE(MAX(orden), 0) + 1 AS siguiente
         FROM soluciones_servicio
         WHERE id_servicio = ?"
    );
    $stmt->bind_param('i', $idServicio);
    $stmt->execute();
    $orden = (int) ($stmt->get_result()->fetch_assoc()['siguiente'] ?? 1);
    $stmt->close();

    $stmt = $conn->prepare(
        "INSERT INTO soluciones_servicio
            (id_servicio, nombre, descripcion, estado, orden, creado_por, actualizado_por)
         VALUES (?, ?, ?, 'activo', ?, ?, ?)"
    );
    $stmt->bind_param(
        'issiii',
        $idServicio,
        $nombre,
        $descripcion,
        $orden,
        $idUsuario,
        $idUsuario
    );
    $stmt->execute();
    $idSolucion = (int) $conn->insert_id;
    $stmt->close();

    return [
        'id_solucion' => $idSolucion,
        'nombre' => $nombre,
        'descripcion' => $descripcion,
        'creada' => true,
    ];
}

function flujoMarcarEtapaLista(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idUsuario,
    int $rol,
    int $idSolucion,
    string $comentarioCierre,
    bool $solicitaCierreDefinitivo = false,
    string $nuevaSolucionNombre = '',
    string $nuevaSolucionDescripcion = ''
): void {
    $comentarioCierre = trim($comentarioCierre);
    $nuevaSolucionNombre = trim($nuevaSolucionNombre);
    $nuevaSolucionDescripcion = trim($nuevaSolucionDescripcion);
    $crearNuevaSolucion = $nuevaSolucionNombre !== ''
        || $nuevaSolucionDescripcion !== '';

    if (!$crearNuevaSolucion && $idSolucion < 1) {
        throw new RuntimeException(
            'Seleccione una solución existente o cree una nueva antes de marcar el caso como listo.'
        );
    }

    if (
        $crearNuevaSolucion
        && (
            $nuevaSolucionNombre === ''
            || $nuevaSolucionDescripcion === ''
            || strlen($nuevaSolucionNombre) > 180
            || strlen($nuevaSolucionDescripcion) > 500
        )
    ) {
        throw new RuntimeException(
            'La nueva solución debe tener un nombre y una descripción válidos.'
        );
    }

    if ($comentarioCierre === '' || strlen($comentarioCierre) > 2000) {
        throw new RuntimeException(
            'Debe registrar obligatoriamente qué hizo para solucionar el caso.'
        );
    }

    if ($rol !== 2) {
        throw new RuntimeException(
            'Solo el gestor asignado puede marcar el caso como listo.'
        );
    }

    if (!flujoModuloAprobacionCasosInstalado($conn)) {
        throw new RuntimeException(
            'El administrador debe instalar la migración de aprobación y reapertura de casos.'
        );
    }

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare(
            "SELECT
                te.*,
                t.id_usuario,
                CASE
                    WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                    ELSE padre.id_gestor
                END AS id_creador_caso
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN ticket_etapas AS padre
                ON padre.id_ticket_etapa = te.id_ticket_etapa_padre
               AND padre.id_ticket = te.id_ticket
             WHERE te.id_ticket_etapa = ?
               AND te.id_ticket = ?
             FOR UPDATE"
        );
        $stmt->bind_param('ii', $idTicketEtapa, $idTicket);
        $stmt->execute();
        $etapa = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (
            !$etapa
            || !in_array(
                (string) $etapa['estado'],
                ['pendiente', 'en_proceso', 'en_espera_solicitante'],
                true
            )
            || (
                (int) $etapa['id_gestor'] !== $idUsuario
                && !seguridadEsUsuarioPrueba()
            )
        ) {
            throw new RuntimeException(
                'El caso ya no está disponible para marcarlo como listo.'
            );
        }

        if (
            $solicitaCierreDefinitivo
            && (int) ($etapa['id_ticket_etapa_padre'] ?? 0) > 0
        ) {
            throw new RuntimeException(
                'El cierre definitivo por primer contacto solo está disponible para las etapas del flujo, no para derivaciones.'
            );
        }

        if (!flujoTablaExiste($conn, 'soluciones_servicio')) {
            throw new RuntimeException(
                'El administrador debe instalar el módulo de soluciones por servicio.'
            );
        }

        $idServicioEtapa = (int) ($etapa['id_servicio'] ?? 0);
        if ($crearNuevaSolucion) {
            $solucion = flujoCrearSolucionServicio(
                $conn,
                $idServicioEtapa,
                $idUsuario,
                $nuevaSolucionNombre,
                $nuevaSolucionDescripcion
            );
            $idSolucion = (int) $solucion['id_solucion'];
            $nombreSolucion = (string) $solucion['nombre'];
        } else {
            $stmt = $conn->prepare(
                "SELECT id_solucion, nombre
                 FROM soluciones_servicio
                 WHERE id_solucion = ?
                   AND id_servicio = ?
                   AND estado = 'activo'
                 LIMIT 1
                 FOR UPDATE"
            );
            $stmt->bind_param('ii', $idSolucion, $idServicioEtapa);
            $stmt->execute();
            $solucion = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$solucion) {
                throw new RuntimeException(
                    'La solución seleccionada no está activa o no corresponde al servicio del caso.'
                );
            }

            $nombreSolucion = trim((string) $solucion['nombre']);
        }

        $stmt = $conn->prepare(
            "SELECT COUNT(*) AS pendientes
             FROM ticket_etapas
             WHERE id_ticket_etapa_padre = ?
               AND estado NOT IN ('completada', 'cancelada')"
        );
        $stmt->bind_param('i', $idTicketEtapa);
        $stmt->execute();
        $hijosPendientes = (int) $stmt->get_result()->fetch_assoc()['pendientes'];
        $stmt->close();

        if ($hijosPendientes > 0) {
            throw new RuntimeException(
                'No puede marcar este caso como listo mientras tenga casos hijos pendientes.'
            );
        }

        flujoCopiarChecklistPlantilla(
            $conn,
            $idTicketEtapa,
            (int) ($etapa['id_proceso_etapa'] ?? 0)
        );

        $stmt = $conn->prepare(
            "SELECT COUNT(*) AS pendientes
             FROM ticket_etapa_checklist
             WHERE id_ticket_etapa = ?
               AND obligatorio = 1
               AND completado = 0"
        );
        $stmt->bind_param('i', $idTicketEtapa);
        $stmt->execute();
        $pendientes = (int) $stmt->get_result()->fetch_assoc()['pendientes'];
        $stmt->close();

        if ($pendientes > 0) {
            throw new RuntimeException(
                'Debe completar todos los elementos obligatorios del checklist.'
            );
        }

        $ahora = flujoAhora();
        $minutos = flujoMinutosConsumidosNodo($conn, $etapa, $ahora);
        $slaTotal = flujoSlaMinutosTotalesNodo($etapa, $conn);

        $resultadoSla = $slaTotal < 1 || $minutos <= $slaTotal
            ? 'dentro_sla'
            : 'fuera_sla';

        $stmt = $conn->prepare(
            "UPDATE ticket_etapas
             SET estado = 'listo_cierre',
                 solicita_cierre_definitivo = ?,
                 fecha_marcado_listo = ?,
                 minutos_hasta_listo = ?,
                 resultado_sla_listo = ?,
                 marcado_listo_por = ?,
                 id_solucion = ?,
                 solucion_nombre = ?,
                 comentario_cierre = NULLIF(?, ''),
                 resultado_sla = 'sin_iniciar',
                 minutos_atencion = NULL,
                 fecha_finalizacion = NULL,
                 completado_por = NULL
             WHERE id_ticket_etapa = ?
               AND estado IN ('pendiente', 'en_proceso', 'en_espera_solicitante')"
        );
        $stmt->bind_param(
            'isisiissi',
            $solicitaCierreDefinitivo,
            $ahora,
            $minutos,
            $resultadoSla,
            $idUsuario,
            $idSolucion,
            $nombreSolucion,
            $comentarioCierre,
            $idTicketEtapa
        );
        $stmt->execute();

        if ($stmt->affected_rows !== 1) {
            $stmt->close();
            throw new RuntimeException(
                'El estado del caso cambió antes de marcarlo como listo.'
            );
        }

        $stmt->close();
        

        $etiquetaNodo = flujoEtiquetaNodo(
            $conn,
            $idTicket,
            $idTicketEtapa
        );
        $idCreadorCaso = (int) ($etapa['id_creador_caso'] ?? 0);
        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idUsuario,
            $solicitaCierreDefinitivo
                ? 'Cierre definitivo solicitado por primer contacto'
                : 'Atención marcada como lista',
            'El gestor asignado marcó '
                . $etiquetaNodo
                . ($solicitaCierreDefinitivo
                    ? ' como resuelto en primer contacto y solicitó el cierre definitivo del ticket. Las etapas siguientes no se activarán si el solicitante aprueba. El indicador SLA quedó cortado en '
                    : ' como listo para revisión. El indicador SLA quedó cortado en ')
                . $minutos
                . ' minuto(s) hábil(es), con resultado '
                . ($resultadoSla === 'dentro_sla'
                    ? 'dentro del SLA'
                    : 'fuera del SLA')
                . '. El vencimiento visible se conserva en '
                . (string) ($etapa['fecha_vencimiento'] ?? 'sin fecha')
                . '. Solución: '
                . $nombreSolucion
                . '. Observación: '
                . $comentarioCierre
                . '.',
            $idTicketEtapa
        );
        flujoNotificar(
            $conn,
            $idCreadorCaso,
            $idTicket,
            $idTicketEtapa,
            $solicitaCierreDefinitivo
                ? 'Solicitud de cierre definitivo'
                : 'Atención lista para revisión',
            $solicitaCierreDefinitivo
                ? "El gestor resolvió {$etiquetaNodo} en primer contacto y solicita cerrar definitivamente el ticket sin continuar el flujo. Revise la solución y apruebe o reabra."
                : "El gestor asignado marcó {$etiquetaNodo} como listo. Revise la solución y cierre o reabra la atención."
        );

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function flujoReabrirDerivacion(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idUsuario,
    int $rol,
    string $motivoReapertura
): void {
    $motivoReapertura = trim($motivoReapertura);

    if (!in_array($rol, [2, 3], true) || !flujoModuloAprobacionCasosInstalado($conn)) {
        throw new RuntimeException('No está autorizado para reabrir este caso.');
    }

    if ($motivoReapertura === '' || strlen($motivoReapertura) > 1000) {
        throw new RuntimeException(
            'Debe explicar por qué la solución informada no permite cerrar el caso.'
        );
    }

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare(
            "SELECT
                te.*,
                t.id_usuario,
                CASE
                    WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                    ELSE padre.id_gestor
                END AS id_creador_caso
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN ticket_etapas AS padre
                ON padre.id_ticket_etapa = te.id_ticket_etapa_padre
               AND padre.id_ticket = te.id_ticket
             WHERE te.id_ticket_etapa = ?
               AND te.id_ticket = ?
             FOR UPDATE"
        );
        $stmt->bind_param('ii', $idTicketEtapa, $idTicket);
        $stmt->execute();
        $etapa = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (
            !$etapa
            || (string) $etapa['estado'] !== 'listo_cierre'
            || (int) $etapa['id_creador_caso'] !== $idUsuario
            || (
                $rol === 3
                && (
                    (int) $etapa['id_usuario'] !== $idUsuario
                    || (int) ($etapa['id_ticket_etapa_padre'] ?? 0) > 0
                )
            )
        ) {
            throw new RuntimeException(
                'Solo el creador del caso puede reabrirlo mientras espera cierre.'
            );
        }

        $ahora = flujoAhora();
        $consumidos = flujoMinutosConsumidosNodo(
            $conn,
            $etapa,
            $ahora,
            true
        );
        $total = flujoSlaMinutosTotalesNodo($etapa, $conn);
        $restantes = max(0, $total - $consumidos);
        $vence = flujoCalcularVencimientoRestante(
            $conn,
            $etapa,
            $ahora,
            $restantes
        );
        $stmt = $conn->prepare(
            "UPDATE ticket_etapas
             SET estado = 'en_proceso',
                 solicita_cierre_definitivo = 0,
                 sla_minutos_consumidos = ?,
                 fecha_ultima_reanudacion = ?,
                 fecha_vencimiento = ?,
                 fecha_marcado_listo = NULL,
                 minutos_hasta_listo = NULL,
                 resultado_sla_listo = NULL,
                 marcado_listo_por = NULL,
                 fecha_ultima_reapertura = ?,
                 cantidad_reaperturas = cantidad_reaperturas + 1,
                 id_solucion = NULL,
                 solucion_nombre = NULL,
                 comentario_cierre = NULL,
                 resultado_sla = 'sin_iniciar',
                 minutos_atencion = NULL,
                 fecha_finalizacion = NULL,
                 completado_por = NULL
             WHERE id_ticket_etapa = ?
               AND estado = 'listo_cierre'"
        );
        $stmt->bind_param(
            'isssi',
            $consumidos,
            $ahora,
            $vence,
            $ahora,
            $idTicketEtapa
        );
        $stmt->execute();
        $stmt->close();

        $idGestor = (int) ($etapa['id_gestor'] ?? 0);
        $idServicio = (int) ($etapa['id_servicio'] ?? 0);
        $stmt = $conn->prepare(
            "UPDATE tickets
             SET id_etapa_actual = ?,
                 id_tecnico = ?,
                 id_servicio = ?,
                 estado = 'en_proceso',
                 estado_flujo = 'en_proceso'
             WHERE id_ticket = ?"
        );
        $stmt->bind_param(
            'iiii',
            $idTicketEtapa,
            $idGestor,
            $idServicio,
            $idTicket
        );
        $stmt->execute();
        $stmt->close();

        $codigoCaso = flujoCodigoCaso($conn, $idTicket, $idTicketEtapa);
        $fechaListoAnterior = (string) (
            $etapa['fecha_marcado_listo'] ?? 'sin fecha'
        );
        $minutosListoAnterior = (int) (
            $etapa['minutos_hasta_listo'] ?? 0
        );
        $resultadoListoAnterior = (string) (
            $etapa['resultado_sla_listo'] ?? 'sin_iniciar'
        );
        $etiquetaNodo = flujoEtiquetaNodo($conn, $idTicket, $idTicketEtapa);
        $stmt = $conn->prepare(
            "SELECT nombre FROM usuarios WHERE id_usuario = ? LIMIT 1"
        );
        $stmt->bind_param('i', $idUsuario);
        $stmt->execute();
        $nombreReabridor = trim((string) ($stmt->get_result()->fetch_assoc()['nombre'] ?? ''));
        $stmt->close();
        if ($nombreReabridor === '') {
            $nombreReabridor = 'El creador de la derivación';
        }
        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idUsuario,
            'Atención reabierta',
            'El creador reabrió '
                . $etiquetaNodo
                . '. Se invalidó el corte del '
                . $fechaListoAnterior
                . ' por '
                . $minutosListoAnterior
                . ' minuto(s), resultado '
                . $resultadoListoAnterior
                . '. Al reabrir acumulaba '
                . $consumidos
                . ' minuto(s) hábil(es), incluido el tiempo de espera. Nuevo vencimiento visible: '
                . (string) $vence
                . '. Motivo de reapertura: '
                . $motivoReapertura
                . '.',
            $idTicketEtapa
        );
        flujoNotificar(
            $conn,
            $idGestor,
            $idTicket,
            $idTicketEtapa,
            (int) ($etapa['id_ticket_etapa_padre'] ?? 0) > 0
                ? 'Derivación reabierta'
                : 'Caso reabierto',
            "{$nombreReabridor} reabrió {$etiquetaNodo}. Motivo: {$motivoReapertura}"
        );

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function flujoCompletarEtapa(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idUsuario,
    int $rol,
    int $calificacionArea = 0,
    int $calificacionTiempo = 0,
    string $comentarioCalificacion = ''
): void {
    if (!in_array($rol, [2, 3], true) || !flujoModuloAprobacionCasosInstalado($conn)) {
        throw new RuntimeException('No está autorizado para cerrar este caso.');
    }

    $comentarioCalificacion = trim($comentarioCalificacion);
    $conn->begin_transaction();

    try {
        /* Las derivaciones hermanas pueden cerrarse al mismo tiempo. Todas
           bloquean primero al padre y después a la hija para evitar el ciclo
           padre-hija / hija-padre que produciría interbloqueos en InnoDB. */
        $stmt = $conn->prepare(
            "SELECT COALESCE(id_ticket_etapa_padre, 0) AS id_padre
             FROM ticket_etapas
             WHERE id_ticket_etapa = ?
               AND id_ticket = ?
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idTicketEtapa, $idTicket);
        $stmt->execute();
        $idPadreBloqueo = (int) (
            $stmt->get_result()->fetch_assoc()['id_padre'] ?? 0
        );
        $stmt->close();

        if ($idPadreBloqueo > 0) {
            $stmt = $conn->prepare(
                "SELECT id_ticket_etapa
                 FROM ticket_etapas
                 WHERE id_ticket_etapa = ?
                   AND id_ticket = ?
                 FOR UPDATE"
            );
            $stmt->bind_param('ii', $idPadreBloqueo, $idTicket);
            $stmt->execute();
            $stmt->store_result();
            $stmt->close();
        }

        $stmt = $conn->prepare(
            "SELECT
                te.*,
                t.id_usuario,
                CASE
                    WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                    ELSE padre.id_gestor
                END AS id_creador_caso
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN ticket_etapas AS padre
                ON padre.id_ticket_etapa = te.id_ticket_etapa_padre
               AND padre.id_ticket = te.id_ticket
             WHERE te.id_ticket_etapa = ?
               AND te.id_ticket = ?
             FOR UPDATE"
        );
        $stmt->bind_param('ii', $idTicketEtapa, $idTicket);
        $stmt->execute();
        $etapa = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (
            !$etapa
            || (string) $etapa['estado'] !== 'listo_cierre'
            || (int) $etapa['id_creador_caso'] !== $idUsuario
            || (
                $rol === 3
                && (
                    (int) $etapa['id_usuario'] !== $idUsuario
                    || (int) ($etapa['id_ticket_etapa_padre'] ?? 0) > 0
                )
            )
        ) {
            throw new RuntimeException(
                'Solo el creador del caso puede cerrarlo después de que el gestor lo marque como listo.'
            );
        }

        $tipoCalificacion = flujoTipoCalificacionCaso(
            $conn,
            $idTicket,
            $etapa
        );

        if ($tipoCalificacion !== null) {
            if (
                $calificacionArea < 1
                || $calificacionArea > 5
                || $calificacionTiempo < 1
                || $calificacionTiempo > 5
            ) {
                throw new RuntimeException(
                    'Califique de 1 a 5 la gestión del proceso y el tiempo de respuesta.'
                );
            }

            if (strlen($comentarioCalificacion) > 1000) {
                throw new RuntimeException(
                    'La observación de la calificación supera los 1.000 caracteres.'
                );
            }

            $calificacionGeneral = (int) round(
                ($calificacionArea + $calificacionTiempo) / 2
            );
            $idGestor = (int) ($etapa['id_gestor'] ?? 0);
            $stmt = $conn->prepare(
                "INSERT INTO solicitud_calificaciones
                    (
                        id_ticket,
                        id_ticket_etapa,
                        id_solicitante,
                        id_gestor,
                        calificacion,
                        calificacion_area,
                        calificacion_tiempo,
                        tipo_calificacion,
                        comentario
                    )
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULLIF(?, ''))
                 ON DUPLICATE KEY UPDATE
                    id_solicitante = VALUES(id_solicitante),
                    id_gestor = VALUES(id_gestor),
                    calificacion = VALUES(calificacion),
                    calificacion_area = VALUES(calificacion_area),
                    calificacion_tiempo = VALUES(calificacion_tiempo),
                    tipo_calificacion = VALUES(tipo_calificacion),
                    comentario = VALUES(comentario),
                    creado_en = NOW()"
            );
            $stmt->bind_param(
                'iiiiiiiss',
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                $idGestor,
                $calificacionGeneral,
                $calificacionArea,
                $calificacionTiempo,
                $tipoCalificacion,
                $comentarioCalificacion
            );
            $stmt->execute();
            $stmt->close();
        }

        $ahora = flujoAhora();
        $minutos = (int) ($etapa['minutos_hasta_listo'] ?? 0);
        $resultadoSla = (string) (
            $etapa['resultado_sla_listo'] ?? 'sin_iniciar'
        );
        $stmt = $conn->prepare(
            "UPDATE ticket_etapas
             SET estado = 'completada',
                 fecha_finalizacion = ?,
                 minutos_atencion = ?,
                 sla_minutos_consumidos = ?,
                 fecha_ultima_reanudacion = NULL,
                 resultado_sla = ?,
                 completado_por = ?
             WHERE id_ticket_etapa = ?
               AND estado = 'listo_cierre'"
        );
        $stmt->bind_param(
            'siisii',
            $ahora,
            $minutos,
            $minutos,
            $resultadoSla,
            $idUsuario,
            $idTicketEtapa
        );
        $stmt->execute();

        if ($stmt->affected_rows !== 1) {
            $stmt->close();
            throw new RuntimeException(
                'El estado del caso cambió antes de confirmar el cierre.'
            );
        }

        $stmt->close();

        $cierreDefinitivoPrimerContacto =
            (int) ($etapa['solicita_cierre_definitivo'] ?? 0) === 1
            && (int) ($etapa['id_ticket_etapa_padre'] ?? 0) === 0;

        if ($cierreDefinitivoPrimerContacto) {
            $stmt = $conn->prepare(
                "UPDATE ticket_etapas
                 SET estado = 'cancelada',
                     fecha_finalizacion = ?,
                     resultado_sla = 'sin_iniciar'
                 WHERE id_ticket = ?
                   AND id_ticket_etapa_padre IS NULL
                   AND orden > ?
                   AND estado = 'bloqueada'"
            );
            $ordenActual = (int) $etapa['orden'];
            $stmt->bind_param('sii', $ahora, $idTicket, $ordenActual);
            $stmt->execute();
            $etapasCanceladas = $stmt->affected_rows;
            $stmt->close();

            $motivoTicket = 'Cierre definitivo aprobado por resolución en primer contacto.';
            $stmt = $conn->prepare(
                "UPDATE tickets
                 SET id_etapa_actual = NULL,
                     estado = 'cerrada',
                     estado_flujo = 'cerrado',
                     fecha_finalizacion = ?,
                     esperando_solicitante_desde = NULL,
                     cierre_tipo = 'aprobacion_por_caso',
                     motivo_cierre = ?
                 WHERE id_ticket = ?"
            );
            $stmt->bind_param('ssi', $ahora, $motivoTicket, $idTicket);
            $stmt->execute();
            $stmt->close();

            flujoRegistrarHistorial(
                $conn,
                $idTicket,
                $idUsuario,
                'Ticket cerrado por resolución en primer contacto',
                'El solicitante aprobó el cierre definitivo solicitado por el gestor. Se cancelaron '
                    . $etapasCanceladas
                    . ' etapa(s) futura(s) que no habían iniciado.',
                $idTicketEtapa
            );
            flujoNotificar(
                $conn,
                (int) ($etapa['id_gestor'] ?? 0),
                $idTicket,
                $idTicketEtapa,
                'Cierre definitivo aprobado',
                "El solicitante aprobó el cierre definitivo del ticket #{$idTicket} por resolución en primer contacto."
            );
            $conn->commit();
            return;
        }

        /* Las etapas raíz conservan su secuencia. Las derivaciones hijas se
           crean activas y se cierran de forma independiente, por lo que cerrar
           una de ellas nunca debe activar, pausar ni reiniciar a sus hermanas. */
        $orden = (int) $etapa['orden'];
        $idPadreSecuencia = (int) (
            $etapa['id_ticket_etapa_padre'] ?? 0
        );
        $siguiente = null;

        if ($idPadreSecuencia === 0) {
            $stmt = $conn->prepare(
                "SELECT *
                 FROM ticket_etapas
                 WHERE id_ticket = ?
                   AND id_ticket_etapa_padre IS NULL
                   AND orden > ?
                   AND estado = 'bloqueada'
                 ORDER BY orden, id_ticket_etapa
                 LIMIT 1
                 FOR UPDATE"
            );
            $stmt->bind_param('ii', $idTicket, $orden);
            $stmt->execute();
            $siguiente = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        }
        $nombreSolucion = trim((string) ($etapa['solucion_nombre'] ?? ''));
        $comentarioCierre = trim((string) ($etapa['comentario_cierre'] ?? ''));
        $etiquetaNodoCierre = flujoEtiquetaNodo(
            $conn,
            $idTicket,
            $idTicketEtapa
        );

        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idUsuario,
            'Atención cerrada',
            'Se cerró '
                . $etiquetaNodoCierre
                . '. '
                . $etapa['catalogo_nombre']
                . ' / '
                . $etapa['servicio_nombre']
                . ' finalizó su atención '
                . ($resultadoSla === 'dentro_sla'
                    ? 'dentro del SLA.'
                    : 'fuera del SLA.')
                . ' Solución: '
                . $nombreSolucion
                . '. Observación: '
                . $comentarioCierre
                . '. Calificación: gestión '
                . $calificacionArea
                . '/5 y tiempo '
                . $calificacionTiempo
                . '/5.',
            $idTicketEtapa
        );
        $idGestorAtencion = (int) ($etapa['id_gestor'] ?? 0);

        if ($idGestorAtencion !== $idUsuario) {
            flujoNotificar(
                $conn,
                $idGestorAtencion,
                $idTicket,
                $idTicketEtapa,
                'Atención aprobada y cerrada',
                'El creador aprobó y calificó '
                    . $etiquetaNodoCierre
                    . ". Gestión: {$calificacionArea}/5; tiempo: {$calificacionTiempo}/5."
            );
        }

        if ($siguiente) {
            $idSiguiente = (int) $siguiente['id_ticket_etapa'];
            $inicioSiguiente = $ahora;
            $venceSiguiente = calcularVencimientoSla(
                $conn,
                $inicioSiguiente,
                (int) $siguiente['sla_tiempo'],
                (string) $siguiente['sla_unidad']
            );
            $stmt = $conn->prepare(
                "UPDATE ticket_etapas
                 SET estado = 'pendiente',
                     fecha_activacion = ?,
                     fecha_vencimiento = ?,
                     fecha_ultima_reanudacion = ?,
                     resultado_sla = 'sin_iniciar'
                 WHERE id_ticket_etapa = ?
                   AND estado = 'bloqueada'"
            );
            $stmt->bind_param(
                'sssi',
                $inicioSiguiente,
                $venceSiguiente,
                $inicioSiguiente,
                $idSiguiente
            );
            $stmt->execute();
            $stmt->close();

            flujoCopiarChecklistPlantilla(
                $conn,
                $idSiguiente,
                (int) ($siguiente['id_proceso_etapa'] ?? 0)
            );

            $idGestor = (int) $siguiente['id_gestor'];
            $idServicio = (int) $siguiente['id_servicio'];
            $stmt = $conn->prepare(
                "UPDATE tickets
                 SET id_etapa_actual = ?,
                     id_tecnico = ?,
                     id_servicio = ?,
                     estado = 'en_proceso',
                     estado_flujo = 'en_proceso',
                     esperando_solicitante_desde = NULL
                 WHERE id_ticket = ?"
            );
            $stmt->bind_param(
                'iiii',
                $idSiguiente,
                $idGestor,
                $idServicio,
                $idTicket
            );
            $stmt->execute();
            $stmt->close();
            flujoRegistrarHistorial(
                $conn,
                $idTicket,
                $idUsuario,
                'Caso heredado habilitado',
                'Se habilitó '
                    . $siguiente['catalogo_nombre']
                    . ' / '
                    . $siguiente['servicio_nombre']
                    . '.',
                $idSiguiente
            );
            flujoNotificar(
                $conn,
                $idGestor,
                $idTicket,
                $idSiguiente,
                    'Caso habilitado para su proceso',
                "El caso anterior del ticket #{$idTicket} terminó. Ya puede atenderlo."
            );
            $conn->commit();
            return;
        }

        $idPadre = (int) ($etapa['id_ticket_etapa_padre'] ?? 0);

        if ($idPadre > 0) {
            $stmt = $conn->prepare(
                "SELECT * FROM ticket_etapas
                 WHERE id_ticket_etapa = ?
                   AND id_ticket = ?
                 FOR UPDATE"
            );
            $stmt->bind_param('ii', $idPadre, $idTicket);
            $stmt->execute();
            $padre = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            /* Compatibilidad con derivaciones creadas por versiones anteriores:
               si quedaron hermanas bloqueadas por la ejecución secuencial,
               se activan juntas al cerrar la primera que estaba disponible. */
            $stmt = $conn->prepare(
                "SELECT *
                 FROM ticket_etapas
                 WHERE id_ticket = ?
                   AND id_ticket_etapa_padre = ?
                   AND estado = 'bloqueada'
                 ORDER BY orden, id_ticket_etapa
                 FOR UPDATE"
            );
            $stmt->bind_param('ii', $idTicket, $idPadre);
            $stmt->execute();
            $resultadoBloqueadas = $stmt->get_result();
            $hermanasBloqueadas = [];
            while ($hermanaBloqueada = $resultadoBloqueadas->fetch_assoc()) {
                $hermanasBloqueadas[] = $hermanaBloqueada;
            }
            $stmt->close();

            foreach ($hermanasBloqueadas as $hermanaBloqueada) {
                $idHermana = (int) $hermanaBloqueada['id_ticket_etapa'];
                $venceHermana = calcularVencimientoSla(
                    $conn,
                    $ahora,
                    (int) $hermanaBloqueada['sla_tiempo'],
                    (string) $hermanaBloqueada['sla_unidad']
                );
                $stmt = $conn->prepare(
                    "UPDATE ticket_etapas
                     SET estado = 'pendiente',
                         fecha_activacion = COALESCE(fecha_activacion, ?),
                         fecha_vencimiento = ?,
                         fecha_ultima_reanudacion = ?,
                         resultado_sla = 'sin_iniciar'
                     WHERE id_ticket_etapa = ?
                       AND estado = 'bloqueada'"
                );
                $stmt->bind_param(
                    'sssi',
                    $ahora,
                    $venceHermana,
                    $ahora,
                    $idHermana
                );
                $stmt->execute();
                $activada = $stmt->affected_rows === 1;
                $stmt->close();

                if ($activada) {
                    flujoNotificar(
                        $conn,
                        (int) $hermanaBloqueada['id_gestor'],
                        $idTicket,
                        $idHermana,
                        'Ticket derivado habilitado',
                        "La derivación del ticket #{$idTicket} ya está disponible para atenderse en paralelo."
                    );
                }
            }

            $stmt = $conn->prepare(
                "SELECT id_ticket_etapa, estado
                 FROM ticket_etapas
                 WHERE id_ticket_etapa_padre = ?
                 FOR UPDATE"
            );
            $stmt->bind_param('i', $idPadre);
            $stmt->execute();
            $resultadoHermanos = $stmt->get_result();
            $hermanosPendientes = 0;

            while ($hermano = $resultadoHermanos->fetch_assoc()) {
                if (!in_array(
                    (string) $hermano['estado'],
                    ['completada', 'cancelada'],
                    true
                )) {
                    $hermanosPendientes++;
                }
            }
            $stmt->close();

            if ($hermanosPendientes === 0) {

                if ($padre && $padre['estado'] === 'pausada') {
                    $totalPadre = flujoSlaMinutosTotalesNodo($padre, $conn);
                    $consumidoPadre = (int) ($padre['sla_minutos_consumidos'] ?? 0);
                    $restantes = max(0, $totalPadre - $consumidoPadre);
                    $vencePadre = flujoCalcularVencimientoRestante(
                        $conn,
                        $padre,
                        $ahora,
                        $restantes
                    );
                    $stmt = $conn->prepare(
                        "UPDATE ticket_etapas
                         SET estado = 'en_proceso',
                             fecha_pausa = NULL,
                             fecha_ultima_reanudacion = ?,
                             fecha_vencimiento = ?
                         WHERE id_ticket_etapa = ?
                           AND estado = 'pausada'"
                    );
                    $stmt->bind_param('ssi', $ahora, $vencePadre, $idPadre);
                    $stmt->execute();
                    $stmt->close();

                    $idGestorPadre = (int) $padre['id_gestor'];
                    $idServicioPadre = (int) $padre['id_servicio'];
                    $stmt = $conn->prepare(
                        "UPDATE tickets
                         SET id_etapa_actual = ?,
                             id_tecnico = ?,
                             id_servicio = ?,
                             estado = 'en_proceso',
                             estado_flujo = 'en_proceso'
                         WHERE id_ticket = ?"
                    );
                    $stmt->bind_param(
                        'iiii',
                        $idPadre,
                        $idGestorPadre,
                        $idServicioPadre,
                        $idTicket
                    );
                    $stmt->execute();
                    $stmt->close();
                    flujoRegistrarHistorial(
                        $conn,
                        $idTicket,
                        $idUsuario,
                        'Caso padre reanudado',
                        'Todos los casos hijos finalizaron. Se reanudó '
                            . $padre['catalogo_nombre'] . ' / '
                            . $padre['servicio_nombre'] . ' con '
                            . $restantes . ' minuto(s) hábil(es) restantes.',
                        $idPadre
                    );
                    flujoNotificar(
                        $conn,
                        $idGestorPadre,
                        $idTicket,
                        $idPadre,
                        'Caso padre reanudado',
                        "Todos los hijos del ticket #{$idTicket} finalizaron. Su SLA volvió a correr."
                    );
                }
            } else {
                $stmt = $conn->prepare(
                    "SELECT id_ticket_etapa, id_gestor, id_servicio
                     FROM ticket_etapas
                     WHERE id_ticket_etapa_padre = ?
                       AND estado NOT IN ('completada', 'cancelada')
                     ORDER BY
                        CASE estado
                            WHEN 'en_proceso' THEN 1
                            WHEN 'pendiente' THEN 2
                            WHEN 'en_espera_solicitante' THEN 3
                            WHEN 'listo_cierre' THEN 4
                            WHEN 'pausada' THEN 5
                            ELSE 6
                        END,
                        orden,
                        id_ticket_etapa
                     LIMIT 1"
                );
                $stmt->bind_param('i', $idPadre);
                $stmt->execute();
                $activo = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if ($activo) {
                    $stmt = $conn->prepare(
                        "UPDATE tickets
                         SET id_etapa_actual = ?, id_tecnico = ?, id_servicio = ?
                         WHERE id_ticket = ?"
                    );
                    $idActivo = (int) $activo['id_ticket_etapa'];
                    $gestorActivo = (int) $activo['id_gestor'];
                    $servicioActivo = (int) $activo['id_servicio'];
                    $stmt->bind_param(
                        'iiii',
                        $idActivo,
                        $gestorActivo,
                        $servicioActivo,
                        $idTicket
                    );
                    $stmt->execute();
                    $stmt->close();
                }
            }
        } else {
            $stmt = $conn->prepare(
                "SELECT COUNT(*) AS pendientes
                 FROM ticket_etapas
                 WHERE id_ticket = ?
                   AND estado NOT IN ('completada', 'cancelada')"
            );
            $stmt->bind_param('i', $idTicket);
            $stmt->execute();
            $pendientesTicket = (int) (
                $stmt->get_result()->fetch_assoc()['pendientes'] ?? 0
            );
            $stmt->close();

            if ($pendientesTicket === 0) {
                $idCreador = (int) $etapa['id_usuario'];
                $motivoTicket = 'Cerrado automáticamente después de que el creador aprobó y calificó cada caso.';
                $stmt = $conn->prepare(
                    "UPDATE tickets
                     SET id_etapa_actual = NULL,
                         estado = 'cerrada',
                         estado_flujo = 'cerrado',
                         fecha_finalizacion = ?,
                         esperando_solicitante_desde = NULL,
                         cierre_tipo = 'aprobacion_por_caso',
                         motivo_cierre = ?
                     WHERE id_ticket = ?"
                );
                $stmt->bind_param(
                    'ssi',
                    $ahora,
                    $motivoTicket,
                    $idTicket
                );
                $stmt->execute();
                $stmt->close();
                flujoRegistrarHistorial(
                    $conn,
                    $idTicket,
                    $idUsuario,
                    'Ticket cerrado definitivamente',
                    'Todos los casos fueron marcados como listos, aprobados y calificados por sus respectivos creadores. La encuesta principal corresponde únicamente al servicio solicitado.',
                    $idTicketEtapa
                );
                flujoNotificar(
                    $conn,
                    $idCreador,
                    $idTicket,
                    null,
                    'Ticket cerrado definitivamente',
                    "Todos los casos del ticket #{$idTicket} fueron aprobados y calificados. El ticket quedó cerrado."
                );
            }
        }

        $conn->commit();
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

/**
 * Compatibilidad con tickets que ya estaban en pendiente_calificacion antes
 * de instalar la aprobación por caso. Registra únicamente la encuesta del
 * servicio solicitado y cierra ese ticket anterior.
 *
 * @param array<int|string, mixed> $calificacionesArea
 * @param array<int|string, mixed> $calificacionesTiempo
 * @param array<int|string, mixed> $comentarios
 */
function flujoCalificarCerrarTicket(
    mysqli $conn,
    int $idTicket,
    int $idCreador,
    array $calificacionesArea,
    array $calificacionesTiempo,
    array $comentarios
): int {
    $idPaisOperacion = paisExigirContexto();
    if (!flujoModuloAprobacionCasosInstalado($conn)) {
        throw new RuntimeException(
            'El administrador debe importar la migración de aprobación y encuestas por caso.'
        );
    }

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare(
            "SELECT id_ticket, id_usuario, estado, estado_flujo
             FROM tickets
             WHERE id_ticket = ?
               AND id_usuario = ?
               AND id_pais_operacion = ?
             FOR UPDATE"
        );
        $stmt->bind_param('iii', $idTicket, $idCreador, $idPaisOperacion);
        $stmt->execute();
        $ticket = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$ticket) {
            throw new RuntimeException(
                'Solo el gestor que creó el ticket puede realizar el cierre definitivo.'
            );
        }

        if ((string) $ticket['estado_flujo'] !== 'pendiente_calificacion') {
            throw new RuntimeException(
                'El ticket no está pendiente de calificación o ya fue cerrado.'
            );
        }

        $stmt = $conn->prepare(
            "SELECT
                id_ticket_etapa,
                id_gestor,
                catalogo_nombre,
                servicio_nombre,
                estado
             FROM ticket_etapas
             WHERE id_ticket = ?
               AND id_ticket_etapa_padre IS NULL
               AND estado <> 'cancelada'
             ORDER BY orden, id_ticket_etapa
             LIMIT 1
             FOR UPDATE"
        );
        $stmt->bind_param('i', $idTicket);
        $stmt->execute();
        $etapa = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$etapa || (string) $etapa['estado'] !== 'completada') {
            throw new RuntimeException(
                'El servicio solicitado todavía no está disponible para encuesta.'
            );
        }

        $idEtapa = (int) $etapa['id_ticket_etapa'];
        $calificacionArea = (int) ($calificacionesArea[$idEtapa] ?? 0);
        $calificacionTiempo = (int) ($calificacionesTiempo[$idEtapa] ?? 0);
        $comentario = trim((string) ($comentarios[$idEtapa] ?? ''));

        if (
            $calificacionArea < 1
            || $calificacionArea > 5
            || $calificacionTiempo < 1
            || $calificacionTiempo > 5
        ) {
            throw new RuntimeException(
                'Califique de 1 a 5 el servicio solicitado y su tiempo de respuesta.'
            );
        }

        if (strlen($comentario) > 1000) {
            throw new RuntimeException(
                'La observación supera los 1.000 caracteres.'
            );
        }

        $calificacionGeneral = (int) round(
            ($calificacionArea + $calificacionTiempo) / 2
        );
        $idGestor = (int) ($etapa['id_gestor'] ?? 0);
        $tipoCalificacion = 'encuesta_servicio';
        $stmt = $conn->prepare(
            "INSERT INTO solicitud_calificaciones
                (
                    id_ticket,
                    id_ticket_etapa,
                    id_solicitante,
                    id_gestor,
                    calificacion,
                    calificacion_area,
                    calificacion_tiempo,
                    tipo_calificacion,
                    comentario
                )
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULLIF(?, ''))
             ON DUPLICATE KEY UPDATE
                id_solicitante = VALUES(id_solicitante),
                id_gestor = VALUES(id_gestor),
                calificacion = VALUES(calificacion),
                calificacion_area = VALUES(calificacion_area),
                calificacion_tiempo = VALUES(calificacion_tiempo),
                tipo_calificacion = VALUES(tipo_calificacion),
                comentario = VALUES(comentario),
                creado_en = NOW()"
        );
        $stmt->bind_param(
            'iiiiiiiss',
            $idTicket,
            $idEtapa,
            $idCreador,
            $idGestor,
            $calificacionGeneral,
            $calificacionArea,
            $calificacionTiempo,
            $tipoCalificacion,
            $comentario
        );
        $stmt->execute();
        $stmt->close();

        $area = trim((string) $etapa['catalogo_nombre']);
        $servicio = trim((string) $etapa['servicio_nombre']);
        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idCreador,
            'Encuesta del servicio solicitado',
            "{$area} / {$servicio}: gestión {$calificacionArea}/5 y tiempo de respuesta {$calificacionTiempo}/5.",
            $idEtapa
        );

        $motivo = 'Cerrado definitivamente después de registrar una única encuesta del servicio solicitado.';
        $stmt = $conn->prepare(
            "UPDATE tickets
             SET estado = 'cerrada',
                 estado_flujo = 'cerrado',
                 fecha_finalizacion = NOW(),
                 esperando_solicitante_desde = NULL,
                 cierre_tipo = 'gestor_creador',
                 motivo_cierre = ?
             WHERE id_ticket = ?
               AND id_usuario = ?
               AND estado_flujo = 'pendiente_calificacion'"
        );
        $stmt->bind_param('sii', $motivo, $idTicket, $idCreador);
        $stmt->execute();

        if ($stmt->affected_rows !== 1) {
            $stmt->close();
            throw new RuntimeException(
                'El estado del ticket cambió antes de completar el cierre.'
            );
        }

        $stmt->close();
        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idCreador,
            'Ticket cerrado definitivamente',
            $motivo,
            null
        );

        $conn->commit();

        return 1;
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

function flujoCalificarEtapa(
    mysqli $conn,
    int $idTicket,
    int $idTicketEtapa,
    int $idSolicitante,
    int $calificacion,
    string $comentario
): bool {
    if ($calificacion < 1 || $calificacion > 5) {
        throw new RuntimeException('La calificación debe estar entre 1 y 5.');
    }

    $conn->begin_transaction();

    try {
        $stmt = $conn->prepare(
            "SELECT
                te.id_ticket_etapa,
                te.id_gestor,
                te.estado,
                t.estado_flujo
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             WHERE te.id_ticket_etapa = ?
               AND te.id_ticket = ?
               AND t.id_usuario = ?
             FOR UPDATE"
        );
        $stmt->bind_param(
            'iii',
            $idTicketEtapa,
            $idTicket,
            $idSolicitante
        );
        $stmt->execute();
        $etapa = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (
            !$etapa
            || $etapa['estado'] !== 'completada'
            || $etapa['estado_flujo'] !== 'pendiente_calificacion'
        ) {
            throw new RuntimeException('La etapa todavía no puede calificarse.');
        }

        $idGestor = (int) $etapa['id_gestor'];
        $calificacionDetallada = flujoModuloCalificacionDetalladaInstalado($conn);
        $stmt = $conn->prepare($calificacionDetallada
            ? "INSERT INTO solicitud_calificaciones
                (
                    id_ticket, id_ticket_etapa, id_solicitante, id_gestor,
                    calificacion, calificacion_area, calificacion_tiempo,
                    comentario
                )
               VALUES (?, ?, ?, ?, ?, ?, ?, NULLIF(?, ''))
               ON DUPLICATE KEY UPDATE
                    calificacion = VALUES(calificacion),
                    calificacion_area = VALUES(calificacion_area),
                    calificacion_tiempo = VALUES(calificacion_tiempo),
                    comentario = VALUES(comentario),
                    id_gestor = VALUES(id_gestor)"
            : "INSERT INTO solicitud_calificaciones
                (
                    id_ticket, id_ticket_etapa, id_solicitante, id_gestor,
                    calificacion, comentario
                )
               VALUES (?, ?, ?, ?, ?, NULLIF(?, ''))
               ON DUPLICATE KEY UPDATE
                    calificacion = VALUES(calificacion),
                    comentario = VALUES(comentario),
                    id_gestor = VALUES(id_gestor)"
        );

        if ($calificacionDetallada) {
            $stmt->bind_param(
                'iiiiiiis',
                $idTicket,
                $idTicketEtapa,
                $idSolicitante,
                $idGestor,
                $calificacion,
                $calificacion,
                $calificacion,
                $comentario
            );
        } else {
            $stmt->bind_param(
                'iiiiis',
                $idTicket,
                $idTicketEtapa,
                $idSolicitante,
                $idGestor,
                $calificacion,
                $comentario
            );
        }
        $stmt->execute();
        $stmt->close();

        $stmt = $conn->prepare(
            "SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN c.id_calificacion IS NOT NULL THEN 1 ELSE 0 END)
                    AS calificadas
             FROM ticket_etapas AS te
             LEFT JOIN solicitud_calificaciones AS c
                ON c.id_ticket_etapa = te.id_ticket_etapa
             WHERE te.id_ticket = ?
               AND te.estado = 'completada'"
        );
        $stmt->bind_param('i', $idTicket);
        $stmt->execute();
        $conteo = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $cerrado = (int) $conteo['total'] > 0
            && (int) $conteo['total'] === (int) $conteo['calificadas'];

        if ($cerrado) {
            $motivo = 'Cerrado automáticamente por el gestor creador después de calificar todos los procesos.';
            $stmt = $conn->prepare(
                "UPDATE tickets
                 SET estado = 'cerrada',
                     estado_flujo = 'cerrado',
                     fecha_finalizacion = NOW(),
                     esperando_solicitante_desde = NULL,
                     cierre_tipo = 'gestor_creador',
                     motivo_cierre = ?
                 WHERE id_ticket = ?"
            );
            $stmt->bind_param('si', $motivo, $idTicket);
            $stmt->execute();
            $stmt->close();
            flujoRegistrarHistorial(
                $conn,
                $idTicket,
                $idSolicitante,
                'Ticket cerrado',
                $motivo,
                $idTicketEtapa
            );
        } else {
            flujoRegistrarHistorial(
                $conn,
                $idTicket,
                $idSolicitante,
                'Etapa calificada',
                "El gestor creador calificó un caso con {$calificacion} estrella(s).",
                $idTicketEtapa
            );
        }

        $conn->commit();

        return $cerrado;
    } catch (Throwable $e) {
        $conn->rollback();
        throw $e;
    }
}

/**
 * @return array<int, array<string, mixed>>
 */
function flujoTicketsUsuario(
    mysqli $conn,
    int $idUsuario,
    int $rol
): array {
    $idPaisOperacion = paisExigirContexto();
    $filtroCasosPrueba = seguridadFiltroCasosOficiales('t');
    if ($rol === 1) {
        $sql = "SELECT DISTINCT t.*, p.nombre AS proceso_nombre,
                    u.nombre AS creador_nombre,
                    u.nombre AS solicitante_nombre
                FROM tickets AS t
                INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
                LEFT JOIN usuarios AS u ON u.id_usuario = t.id_usuario
                WHERE t.id_proceso IS NOT NULL
                  AND t.id_pais_operacion = {$idPaisOperacion}
                  {$filtroCasosPrueba}
                ORDER BY t.actualizado_en DESC, t.id_ticket DESC";
        $resultado = $conn->query($sql);
    } elseif ($rol === 2) {
        if (seguridadEsUsuarioPrueba()) {
            $stmt = $conn->prepare(
                "SELECT t.*, p.nombre AS proceso_nombre,
                        u.nombre AS creador_nombre,
                        u.nombre AS solicitante_nombre,
                        te.id_ticket_etapa AS gestor_id_nodo,
                        te.id_ticket_etapa_padre AS gestor_id_padre,
                        te.id_gestor AS gestor_id_asignado,
                        CASE
                            WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                            ELSE padre_gestor.id_gestor
                        END AS gestor_id_creador,
                        te.estado AS gestor_estado_nodo,
                        te.catalogo_nombre AS gestor_catalogo_nombre,
                        te.servicio_nombre AS gestor_servicio_nombre,
                        te.motivo_derivacion AS gestor_motivo_derivacion,
                        te.creado_en AS gestor_creado_en,
                        te.fecha_activacion AS gestor_fecha_activacion,
                        te.fecha_vencimiento AS gestor_fecha_vencimiento,
                        te.fecha_finalizacion AS gestor_fecha_finalizacion,
                        te.orden AS gestor_orden
                 FROM tickets AS t
                 INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
                 INNER JOIN ticket_etapas AS te ON te.id_ticket = t.id_ticket
                 LEFT JOIN ticket_etapas AS padre_gestor
                    ON padre_gestor.id_ticket_etapa = te.id_ticket_etapa_padre
                   AND padre_gestor.id_ticket = te.id_ticket
                 LEFT JOIN usuarios AS u ON u.id_usuario = t.id_usuario
                 WHERE t.id_pais_operacion = ?
                   AND t.es_prueba = 1
                 ORDER BY t.actualizado_en DESC, t.id_ticket DESC,
                          te.orden ASC, te.id_ticket_etapa ASC"
            );
            $stmt->bind_param('i', $idPaisOperacion);
        } else {
            $stmt = $conn->prepare(
            "SELECT t.*, p.nombre AS proceso_nombre,
                    u.nombre AS creador_nombre,
                    u.nombre AS solicitante_nombre,
                    te.id_ticket_etapa AS gestor_id_nodo,
                    te.id_ticket_etapa_padre AS gestor_id_padre,
                    te.id_gestor AS gestor_id_asignado,
                    CASE
                        WHEN te.id_ticket_etapa_padre IS NULL THEN t.id_usuario
                        ELSE padre_gestor.id_gestor
                    END AS gestor_id_creador,
                    te.estado AS gestor_estado_nodo,
                    te.catalogo_nombre AS gestor_catalogo_nombre,
                    te.servicio_nombre AS gestor_servicio_nombre,
                    te.motivo_derivacion AS gestor_motivo_derivacion,
                    te.creado_en AS gestor_creado_en,
                    te.fecha_activacion AS gestor_fecha_activacion,
                    te.fecha_vencimiento AS gestor_fecha_vencimiento,
                    te.fecha_finalizacion AS gestor_fecha_finalizacion,
                    te.orden AS gestor_orden
             FROM tickets AS t
             INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
             INNER JOIN ticket_etapas AS te ON te.id_ticket = t.id_ticket
             LEFT JOIN ticket_etapas AS padre_gestor
                ON padre_gestor.id_ticket_etapa = te.id_ticket_etapa_padre
               AND padre_gestor.id_ticket = te.id_ticket
             LEFT JOIN usuarios AS u ON u.id_usuario = t.id_usuario
             WHERE t.id_pais_operacion = ?
               {$filtroCasosPrueba}
               AND (
                    te.id_gestor = ?
                    OR (
                        te.id_ticket_etapa_padre IS NOT NULL
                        AND padre_gestor.id_gestor = ?
                    )
               )
             ORDER BY t.actualizado_en DESC, t.id_ticket DESC,
                      te.orden ASC, te.id_ticket_etapa ASC"
            );
            $stmt->bind_param('iii', $idPaisOperacion, $idUsuario, $idUsuario);
        }
        $stmt->execute();
        $resultado = $stmt->get_result();
    } elseif ($rol === 3) {
        $stmt = $conn->prepare(
            "SELECT DISTINCT t.*, p.nombre AS proceso_nombre,
                    u.nombre AS creador_nombre,
                    u.nombre AS solicitante_nombre
             FROM tickets AS t
             INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
             LEFT JOIN usuarios AS u ON u.id_usuario = t.id_usuario
             WHERE t.id_pais_operacion = ? AND t.id_usuario = ?
               {$filtroCasosPrueba}
             ORDER BY t.actualizado_en DESC, t.id_ticket DESC"
        );
        $stmt->bind_param('ii', $idPaisOperacion, $idUsuario);
        $stmt->execute();
        $resultado = $stmt->get_result();
    } else {
        return [];
    }

    $filas = [];

    if ($rol === 2) {
        $ticketsGestor = [];

        while ($fila = $resultado->fetch_assoc()) {
            $idTicket = (int) ($fila['id_ticket'] ?? 0);
            if ($idTicket < 1) {
                continue;
            }

            if (!isset($ticketsGestor[$idTicket])) {
                $ticketsGestor[$idTicket] = [
                    'ticket' => $fila,
                    'nodos' => [],
                ];
            }

            $ticketsGestor[$idTicket]['nodos'][] = [
                'id' => (int) ($fila['gestor_id_nodo'] ?? 0),
                'id_padre' => (int) ($fila['gestor_id_padre'] ?? 0),
                'id_gestor' => (int) ($fila['gestor_id_asignado'] ?? 0),
                'creado_por' => (int) ($fila['gestor_id_creador'] ?? 0),
                'estado' => strtolower(trim((string) ($fila['gestor_estado_nodo'] ?? ''))),
                'catalogo' => (string) ($fila['gestor_catalogo_nombre'] ?? ''),
                'servicio' => (string) ($fila['gestor_servicio_nombre'] ?? ''),
                'motivo' => (string) ($fila['gestor_motivo_derivacion'] ?? ''),
                'creado_en' => $fila['gestor_creado_en'] ?? null,
                'fecha_activacion' => $fila['gestor_fecha_activacion'] ?? null,
                'fecha_vencimiento' => $fila['gestor_fecha_vencimiento'] ?? null,
                'fecha_finalizacion' => $fila['gestor_fecha_finalizacion'] ?? null,
                'orden' => (int) ($fila['gestor_orden'] ?? 0),
            ];
        }

        $estadosAbiertos = ['pendiente', 'en_proceso', 'en_espera_solicitante'];
        $estadosFinalizados = [
            'completada',
            'completado',
            'cerrada',
            'cerrado',
            'finalizada',
            'finalizado',
        ];
        $estadosCancelados = ['cancelada', 'cancelado'];
        $estadosDerivacionPendiente = [
            'bloqueada',
            'pendiente',
            'en_proceso',
            'en_espera_solicitante',
            'pausada',
        ];

        foreach ($ticketsGestor as $grupo) {
            $ticket = $grupo['ticket'];
            $nodos = $grupo['nodos'];
            $abiertos = [];
            $derivacionesPendientes = [];
            $pendientesCalificacion = [];
            $finalizados = [];
            $tieneParticipacionPrincipal = false;

            foreach ($nodos as $nodo) {
                $asignadoAlGestor = seguridadEsUsuarioPrueba()
                    || $nodo['id_gestor'] === $idUsuario;
                if (
                    $asignadoAlGestor
                    && $nodo['id_padre'] === 0
                    && !in_array($nodo['estado'], $estadosCancelados, true)
                    && $nodo['estado'] !== 'bloqueada'
                    && !empty($nodo['fecha_activacion'])
                ) {
                    $tieneParticipacionPrincipal = true;
                }
                $derivacionCreada = $nodo['creado_por'] === $idUsuario
                    && $nodo['id_padre'] > 0;

                if ($asignadoAlGestor && in_array($nodo['estado'], $estadosAbiertos, true)) {
                    $abiertos[] = $nodo;
                }
                if (
                    $derivacionCreada
                    && in_array($nodo['estado'], $estadosDerivacionPendiente, true)
                ) {
                    $derivacionesPendientes[] = $nodo;
                }
                if ($derivacionCreada && $nodo['estado'] === 'listo_cierre') {
                    $pendientesCalificacion[] = $nodo;
                }
                if (
                    $asignadoAlGestor
                    && in_array($nodo['estado'], $estadosFinalizados, true)
                ) {
                    $finalizados[] = $nodo;
                }
            }

            $ticketCerrado = strtolower(trim((string) ($ticket['estado_flujo'] ?? ''))) === 'cerrado';

            foreach (array_keys($ticket) as $campo) {
                if (compatStrStartsWith((string) $campo, 'gestor_')) {
                    unset($ticket[$campo]);
                }
            }

            $agregarFila = static function (string $bandeja, array $nodo) use (&$filas, $ticket, $idUsuario): void {
                $fila = $ticket;
                $fila['bandeja_gestor'] = $bandeja;
                $fila['id_ticket_etapa_gestor'] = $nodo['id'];
                $fila['id_ticket_etapa_padre_gestor'] = $nodo['id_padre'];
                $fila['estado_etapa_gestor'] = $nodo['estado'];
                $fila['catalogo_gestor'] = $nodo['catalogo'];
                $fila['servicio_gestor'] = $nodo['servicio'];
                $fila['motivo_derivacion_gestor'] = $nodo['motivo'];
                $fila['creado_en_derivacion_gestor'] = $nodo['creado_en'];
                $fila['fecha_activacion_derivacion_gestor'] = $nodo['fecha_activacion'];
                $fila['fecha_vencimiento_derivacion_gestor'] = $nodo['fecha_vencimiento'];
                $fila['fecha_finalizacion_derivacion_gestor'] = $nodo['fecha_finalizacion'];
                $fila['es_derivacion_creada'] = $nodo['creado_por'] === $idUsuario
                    && $nodo['id_padre'] > 0;
                $filas[] = $fila;
            };

            if ($abiertos) {
                $agregarFila('abiertos', $abiertos[0]);
            }
            foreach ($derivacionesPendientes as $nodo) {
                $agregarFila('derivaciones', $nodo);
            }
            foreach ($pendientesCalificacion as $nodo) {
                $agregarFila('pendientes', $nodo);
            }
            if (!$tieneParticipacionPrincipal) {
                foreach ($finalizados as $nodo) {
                    if ($nodo['id_padre'] > 0) {
                        $agregarFila('derivaciones_cerradas', $nodo);
                    }
                }
            } elseif (
                $finalizados
                && (
                    $ticketCerrado
                    || (!$abiertos && !$derivacionesPendientes && !$pendientesCalificacion)
                )
            ) {
                $agregarFila('cerrados', $finalizados[count($finalizados) - 1]);
            }
        }
    } else {
        while ($fila = $resultado->fetch_assoc()) {
            $filas[] = $fila;
        }
    }

    if (isset($stmt)) {
        $stmt->close();
    }

    return $filas;
}
