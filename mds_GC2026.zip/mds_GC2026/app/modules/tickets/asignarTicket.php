<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

seguridadExigirRol([1]);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: panelAdmin.php');
    exit;
}

seguridadExigirOrigenPost();
seguridadExigirCsrfPost();

$idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
$idGestor = filter_input(INPUT_POST, 'id_tecnico', FILTER_VALIDATE_INT) ?: 0;
$idPaisOperacion = paisExigirContexto();
$filtroCasosPruebaSinAlias = seguridadEsUsuarioPrueba() ? '' : ' AND es_prueba = 0';

if (!$idTicket || !$idGestor) {
    http_response_code(422);
    exit('Datos no válidos.');
}

$stmt = $conn->prepare(
    "SELECT 1 FROM usuarios
     WHERE id_usuario = ?
       AND id_rol = 2
       AND id_pais_operacion = ?
       AND estado = 'activo'
     LIMIT 1"
);
$stmt->bind_param('ii', $idGestor, $idPaisOperacion);
$stmt->execute();
$stmt->store_result();
$gestorValido = $stmt->num_rows > 0;
$stmt->close();

if (!$gestorValido) {
    http_response_code(422);
    exit('El gestor no está disponible.');
}

$resultadoColumna = $conn->query(
    "SHOW COLUMNS FROM tickets LIKE 'id_proceso'"
);
$condicion = $resultadoColumna && $resultadoColumna->num_rows > 0
    ? ' AND id_proceso IS NULL'
    : '';
$stmt = $conn->prepare(
    "UPDATE tickets
     SET id_tecnico = ?, estado = 'en_proceso'
     WHERE id_ticket = ?
       AND id_pais_operacion = ?"
    . $filtroCasosPruebaSinAlias
    . $condicion
);
$stmt->bind_param('iii', $idGestor, $idTicket, $idPaisOperacion);
$stmt->execute();
$actualizados = $stmt->affected_rows;
$stmt->close();

if ($actualizados < 1) {
    http_response_code(403);
    exit('Los tickets se asignan automáticamente al gestor de cada etapa.');
}

flujoRegistrarHistorial(
    $conn,
    $idTicket,
    (int) ($_SESSION['usuario_id'] ?? 0),
    'Ticket asignado',
    'El ticket fue asignado a un gestor para iniciar su atención.'
);

header('Location: solicitudes.php?id_ticket=' . $idTicket);
exit;
