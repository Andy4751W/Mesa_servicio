<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

if ((int) ($_SESSION['rol'] ?? 0) !== 1) {
    http_response_code(403);
    exit('Acceso denegado.');
}

$idPaisOperacion = paisExigirContexto();

$paginaCasos = filter_input(INPUT_GET, 'pagina', FILTER_VALIDATE_INT) ?: 1;
$paginaCasos = max(1, $paginaCasos);
$casosPorPagina = 100;
$tipoBusquedaCasos = (string) ($_GET['tipo_busqueda'] ?? 'caso');
$busquedaCasos = trim((string) ($_GET['buscar'] ?? ''));
if (!in_array(
    $tipoBusquedaCasos,
    ['caso', 'derivacion', 'solicitante', 'gestor'],
    true
)) {
    $tipoBusquedaCasos = 'caso';
}
$totalCasos = 0;
$totalPaginasCasos = 1;

function escaparAdminCasos($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function etiquetaEstadoAdminCasos(string $estado): string
{
    return (fn ($__mesaMatchValue37) => (($__mesaMatchValue37 === ('pendiente')) ? ('Pendiente') : ((($__mesaMatchValue37 === ('en_proceso')) ? ('En proceso') : ((($__mesaMatchValue37 === ('en_espera_solicitante')) ? ('En espera del solicitante') : ((($__mesaMatchValue37 === ('pausada')) ? ('Pausado por casos hijos') : ((($__mesaMatchValue37 === ('listo_cierre')) ? ('Listo · pendiente de cierre') : ((($__mesaMatchValue37 === ('bloqueada')) ? ('Bloqueado') : ((($__mesaMatchValue37 === ('completada')) ? ('Completado') : ((($__mesaMatchValue37 === ('pendiente_calificacion')) ? ('Pendiente de calificación') : ((($__mesaMatchValue37 === ('cerrado')) ? ('Cerrado') : ((($__mesaMatchValue37 === ('cancelado') || $__mesaMatchValue37 === ('cancelada')) ? ('Cancelado') : (ucfirst(str_replace('_', ' ', $estado)))))))))))))))))))))))($estado);
}

function claseEstadoAdminCasos(string $estado): string
{
    return (fn ($__mesaMatchValue38) => (($__mesaMatchValue38 === ('pendiente') || $__mesaMatchValue38 === ('en_proceso')) ? ('proceso') : ((($__mesaMatchValue38 === ('en_espera_solicitante') || $__mesaMatchValue38 === ('pausada') || $__mesaMatchValue38 === ('listo_cierre') || $__mesaMatchValue38 === ('pendiente_calificacion')) ? ('espera') : ((($__mesaMatchValue38 === ('completada') || $__mesaMatchValue38 === ('cerrado')) ? ('cerrado') : ((($__mesaMatchValue38 === ('cancelado') || $__mesaMatchValue38 === ('cancelada')) ? ('cancelado') : ('neutro')))))))))($estado);
}

function responderJsonAdminCasos(array $datos, int $codigo = 200): void
{
    http_response_code($codigo);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode(
        $datos,
        JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
        | JSON_INVALID_UTF8_SUBSTITUTE
    );
    exit;
}

/**
 * Devuelve los nodos en orden visual y asigna una numeración estable:
 * Etapa 1, Caso hijo 1.1, Caso hijo 1.1.1, etc.
 *
 * @param array<int, array<string, mixed>> $etapas
 * @return array<int, array<string, mixed>>
 */
function prepararArbolAdminCasos(array $etapas): array
{
    $porPadre = [];
    $porId = [];

    foreach ($etapas as $etapa) {
        $id = (int) ($etapa['id_ticket_etapa'] ?? 0);
        if ($id < 1) {
            continue;
        }

        $padre = (int) ($etapa['id_ticket_etapa_padre'] ?? 0);
        $porId[$id] = $etapa;
        $porPadre[$padre][] = $etapa;
    }

    foreach ($porPadre as &$grupo) {
        usort(
            $grupo,
            static fn (array $a, array $b): int => [
                (int) ($a['orden'] ?? 0),
                (int) ($a['id_ticket_etapa'] ?? 0),
            ] <=> [
                (int) ($b['orden'] ?? 0),
                (int) ($b['id_ticket_etapa'] ?? 0),
            ]
        );
    }
    unset($grupo);

    $salida = [];
    $visitados = [];
    $agregar = static function (
        array $nodo,
        int $nivel,
        string $codigo,
        bool $esEtapa
    ) use (&$agregar, &$salida, &$visitados, $porPadre): void {
        $id = (int) ($nodo['id_ticket_etapa'] ?? 0);
        if ($id < 1 || isset($visitados[$id])) {
            return;
        }

        $visitados[$id] = true;
        $salida[] = [
            'id' => $id,
            'padre_id' => (int) ($nodo['id_ticket_etapa_padre'] ?? 0),
            'nivel' => $nivel,
            'codigo' => $codigo,
            'tipo' => $esEtapa ? 'etapa' : 'hijo',
            'catalogo' => (string) ($nodo['catalogo_nombre'] ?? ''),
            'servicio' => (string) ($nodo['servicio_nombre'] ?? ''),
            'id_gestor' => (int) ($nodo['id_gestor'] ?? 0),
            'gestor' => (string) ($nodo['gestor_nombre'] ?? 'Sin asignar'),
            'creador' => (string) ($nodo['creador_caso_nombre'] ?? 'Usuario eliminado'),
            'estado' => (string) ($nodo['estado'] ?? 'pendiente'),
            'sla_nombre' => (string) ($nodo['sla_nombre'] ?? 'Sin SLA'),
            'sla_tiempo' => (int) ($nodo['sla_tiempo'] ?? 0),
            'sla_unidad' => (string) ($nodo['sla_unidad'] ?? ''),
            'sla_estado' => (string) ($nodo['estado_sla_actual'] ?? 'sin_iniciar'),
            'sla_consumido' => (int) ($nodo['sla_minutos_consumidos_actuales'] ?? 0),
            'sla_total' => (int) ($nodo['sla_minutos_total'] ?? 0),
            'fecha_creacion' => $nodo['creado_en'] ?? null,
            'fecha_activacion' => $nodo['fecha_activacion'] ?? null,
            'fecha_vencimiento' => $nodo['fecha_vencimiento'] ?? null,
            'fecha_listo' => $nodo['fecha_marcado_listo'] ?? null,
            'fecha_finalizacion' => $nodo['fecha_finalizacion'] ?? null,
            'minutos_solucion' => $nodo['minutos_hasta_listo']
                ?? $nodo['minutos_atencion']
                ?? null,
            'resultado_sla' => (string) (
                $nodo['resultado_sla_listo']
                ?? $nodo['resultado_sla']
                ?? 'sin_iniciar'
            ),
            'solucion' => (string) ($nodo['solucion_nombre'] ?? ''),
            'observacion' => (string) ($nodo['comentario_cierre'] ?? ''),
            'motivo_derivacion' => (string) ($nodo['motivo_derivacion'] ?? ''),
            'reaperturas' => (int) ($nodo['cantidad_reaperturas'] ?? 0),
            'calificacion' => $nodo['calificacion'] !== null
                ? (int) $nodo['calificacion']
                : null,
            'calificacion_area' => $nodo['calificacion_area'] !== null
                ? (int) $nodo['calificacion_area']
                : null,
            'calificacion_tiempo' => $nodo['calificacion_tiempo'] !== null
                ? (int) $nodo['calificacion_tiempo']
                : null,
            'comentario_calificacion' => (string) ($nodo['comentario_calificacion'] ?? ''),
            'evaluador' => (string) ($nodo['evaluador_nombre'] ?? 'Sin calificar'),
            'es_actual' => !empty($nodo['es_actual']),
        ];

        foreach ($porPadre[$id] ?? [] as $indice => $hijo) {
            $agregar(
                $hijo,
                $nivel + 1,
                $codigo . '.' . ($indice + 1),
                false
            );
        }
    };

    foreach ($porPadre[0] ?? [] as $indice => $raiz) {
        $agregar($raiz, 0, (string) ($indice + 1), true);
    }

    /* Los registros históricos sin una raíz válida permanecen consultables. */
    foreach ($porId as $id => $etapa) {
        if (!isset($visitados[$id])) {
            $etapa['id_ticket_etapa_padre'] = null;
            $agregar($etapa, 0, (string) $id, false);
        }
    }

    return $salida;
}

/**
 * Construye índices separados sin cargar conversaciones ni archivos.
 *
 * @param array<int, array<string, mixed>> $etapas
 * @return array{derivaciones:string, gestores:string}
 */
function terminosBusquedaAdminCasos(array $etapas): array
{
    $porPadre = [];
    $porId = [];

    foreach ($etapas as $etapa) {
        $id = (int) ($etapa['id_ticket_etapa'] ?? 0);
        if ($id < 1) {
            continue;
        }

        $padre = (int) ($etapa['id_ticket_etapa_padre'] ?? 0);
        $porId[$id] = $etapa;
        $porPadre[$padre][] = $etapa;
    }

    foreach ($porPadre as &$grupo) {
        usort(
            $grupo,
            static fn (array $a, array $b): int => [
                (int) ($a['orden'] ?? 0),
                (int) ($a['id_ticket_etapa'] ?? 0),
            ] <=> [
                (int) ($b['orden'] ?? 0),
                (int) ($b['id_ticket_etapa'] ?? 0),
            ]
        );
    }
    unset($grupo);

    $derivaciones = [];
    $gestores = [];
    $visitados = [];
    $agregar = static function (
        array $nodo,
        string $codigo,
        bool $esEtapa
    ) use (&$agregar, &$derivaciones, &$gestores, &$visitados, $porPadre): void {
        $id = (int) ($nodo['id_ticket_etapa'] ?? 0);
        if ($id < 1 || isset($visitados[$id])) {
            return;
        }

        $visitados[$id] = true;
        $gestor = trim((string) ($nodo['gestor'] ?? ''));
        if ($gestor !== '') {
            $gestores[] = $gestor;
        }

        if (!$esEtapa) {
            $derivaciones[] = $codigo;
            $derivaciones[] = 'derivación ' . $codigo;
            $derivaciones[] = 'derivacion ' . $codigo;
            $derivaciones[] = 'ticket ' . $codigo;

            foreach (['catalogo_nombre', 'servicio_nombre', 'motivo_derivacion'] as $campo) {
                $valor = trim((string) ($nodo[$campo] ?? ''));
                if ($valor !== '') {
                    $derivaciones[] = $valor;
                }
            }
        }

        foreach ($porPadre[$id] ?? [] as $indice => $hijo) {
            $agregar($hijo, $codigo . '.' . ($indice + 1), false);
        }
    };

    foreach ($porPadre[0] ?? [] as $indice => $raiz) {
        $agregar($raiz, (string) ($indice + 1), true);
    }

    foreach ($porId as $id => $etapa) {
        if (!isset($visitados[$id])) {
            $agregar($etapa, (string) $id, false);
        }
    }

    return [
        'derivaciones' => implode(' ', array_values(array_unique($derivaciones))),
        'gestores' => implode(' ', array_values(array_unique($gestores))),
    ];
}

$moduloDisponible = flujoModuloInstalado($conn)
    && flujoModuloSolucionesInstalado($conn)
    && flujoModuloAprobacionCasosInstalado($conn);

/*
 * Reasignación excepcional desde la trazabilidad administrativa. El gestor
 * configurado en servicios no se modifica: solo cambia el responsable del
 * nodo concreto y, cuando corresponde, el responsable actual del ticket.
 */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && (string) ($_GET['ajax'] ?? '') === 'reasignar_gestor'
) {
    seguridadExigirOrigenPost();
    seguridadExigirCsrfPost();

    if (!$moduloDisponible) {
        responderJsonAdminCasos([
            'ok' => false,
            'mensaje' => 'El módulo de tickets todavía no está instalado por completo.',
        ], 503);
    }

    $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
    $idNodo = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
    $idGestorNuevo = filter_input(INPUT_POST, 'id_gestor', FILTER_VALIDATE_INT) ?: 0;
    $idAdministrador = (int) ($_SESSION['usuario_id'] ?? 0);

    if ($idTicket < 1 || $idNodo < 1 || $idGestorNuevo < 1) {
        responderJsonAdminCasos([
            'ok' => false,
            'mensaje' => 'Seleccione un caso, una etapa y un gestor válidos.',
        ], 422);
    }

    try {
        $stmt = $conn->prepare(
            "SELECT id_usuario, nombre, email, proceso
             FROM usuarios
             WHERE id_usuario = ?
               AND id_rol = 2
               AND id_pais_operacion = ?
               AND estado = 'activo'
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idGestorNuevo, $idPaisOperacion);
        $stmt->execute();
        $gestorNuevo = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$gestorNuevo) {
            responderJsonAdminCasos([
                'ok' => false,
                'mensaje' => 'El gestor seleccionado no está activo o no pertenece al país actual.',
            ], 422);
        }

        $stmt = $conn->prepare(
            "SELECT
                te.id_ticket_etapa,
                te.id_ticket_etapa_padre,
                te.id_gestor,
                te.gestor_nombre,
                te.catalogo_nombre,
                te.servicio_nombre,
                te.estado,
                t.id_etapa_actual,
                COALESCE(NULLIF(TRIM(u.nombre), ''), NULLIF(TRIM(te.gestor_nombre), ''), 'Sin asignar') AS gestor_anterior
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN usuarios AS u ON u.id_usuario = te.id_gestor
             WHERE te.id_ticket_etapa = ?
               AND te.id_ticket = ?
               AND t.id_pais_operacion = ?
             LIMIT 1"
        );
        $stmt->bind_param('iii', $idNodo, $idTicket, $idPaisOperacion);
        $stmt->execute();
        $nodo = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$nodo) {
            responderJsonAdminCasos([
                'ok' => false,
                'mensaje' => 'La etapa o derivación seleccionada no pertenece al caso.',
            ], 404);
        }

        $nombreGestorNuevo = trim((string) $gestorNuevo['nombre']);
        $nombreGestorAnterior = trim((string) ($nodo['gestor_anterior'] ?? 'Sin asignar'));
        $esNodoActual = (int) ($nodo['id_etapa_actual'] ?? 0) === $idNodo;
        $esDerivacion = (int) ($nodo['id_ticket_etapa_padre'] ?? 0) > 0;
        $tipoNodo = $esDerivacion ? 'derivación' : 'etapa';

        if ((int) ($nodo['id_gestor'] ?? 0) === $idGestorNuevo) {
            responderJsonAdminCasos([
                'ok' => true,
                'sin_cambios' => true,
                'mensaje' => 'El gestor seleccionado ya está asignado a este elemento.',
                'id_ticket_etapa' => $idNodo,
                'id_gestor' => $idGestorNuevo,
                'gestor' => $nombreGestorNuevo,
            ]);
        }

        $conn->begin_transaction();

        $stmt = $conn->prepare(
            "UPDATE ticket_etapas
             SET id_gestor = ?, gestor_nombre = ?
             WHERE id_ticket_etapa = ? AND id_ticket = ?"
        );
        $stmt->bind_param('isii', $idGestorNuevo, $nombreGestorNuevo, $idNodo, $idTicket);
        $stmt->execute();
        if ($stmt->affected_rows !== 1) {
            $stmt->close();
            throw new RuntimeException('No fue posible actualizar el responsable del elemento.');
        }
        $stmt->close();

        if ($esNodoActual) {
            $stmt = $conn->prepare(
                "UPDATE tickets
                 SET id_tecnico = ?, actualizado_en = CURRENT_TIMESTAMP
                 WHERE id_ticket = ? AND id_pais_operacion = ?"
            );
            $stmt->bind_param('iii', $idGestorNuevo, $idTicket, $idPaisOperacion);
            $stmt->execute();
            $stmt->close();
        }

        $referencia = trim(
            (string) ($nodo['catalogo_nombre'] ?? '')
            . ' / '
            . (string) ($nodo['servicio_nombre'] ?? ''),
            " /\t\n\r\0\x0B"
        );
        $detalle = 'El administrador reasignó la ' . $tipoNodo
            . ' de "' . ($referencia !== '' ? $referencia : 'servicio sin nombre') . '"'
            . ' de ' . $nombreGestorAnterior . ' a ' . $nombreGestorNuevo . '.';
        flujoRegistrarHistorial(
            $conn,
            $idTicket,
            $idAdministrador,
            'Gestor reasignado manualmente',
            $detalle,
            $idNodo,
            false
        );

        flujoNotificar(
            $conn,
            $idGestorNuevo,
            $idTicket,
            $idNodo,
            'Caso reasignado por el administrador',
            'Ahora tiene asignada la ' . $tipoNodo . ' del caso ' . $idTicket . '.'
        );

        $conn->commit();

        responderJsonAdminCasos([
            'ok' => true,
            'mensaje' => 'El gestor fue reasignado correctamente.',
            'id_ticket_etapa' => $idNodo,
            'id_gestor' => $idGestorNuevo,
            'gestor' => $nombreGestorNuevo,
            'es_nodo_actual' => $esNodoActual,
        ]);
    } catch (Throwable $e) {
        try {
            $conn->rollback();
        } catch (Throwable $ignorado) {
        }
        error_log('Reasignación administrativa de gestor: ' . $e->getMessage());
        responderJsonAdminCasos([
            'ok' => false,
            'mensaje' => 'No fue posible reasignar el gestor. Inténtelo nuevamente.',
        ], 500);
    }
}

/*
 * El detalle se consulta solo al abrir un caso. De esta manera, aunque existan
 * miles de casos, la página inicial no carga todos los árboles y sus datos.
 */
if ((string) ($_GET['ajax'] ?? '') === 'arbol') {
    if (!$moduloDisponible) {
        responderJsonAdminCasos([
            'ok' => false,
            'mensaje' => 'El módulo de tickets todavía no está instalado por completo.',
        ], 503);
    }

    $idTicket = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
    if ($idTicket < 1) {
        responderJsonAdminCasos([
            'ok' => false,
            'mensaje' => 'El número de caso no es válido.',
        ], 422);
    }

    try {
        $stmt = $conn->prepare(
            "SELECT
                t.id_ticket,
                t.titulo,
                t.descripcion,
                t.estado_flujo,
                t.id_etapa_actual,
                t.fecha_creacion,
                t.fecha_finalizacion,
                t.actualizado_en,
                p.nombre AS flujo_nombre,
                COALESCE(u.nombre, 'Usuario eliminado') AS solicitante
             FROM tickets AS t
             INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
             LEFT JOIN usuarios AS u ON u.id_usuario = t.id_usuario
             WHERE t.id_ticket = ?
               AND t.id_pais_operacion = ?
             LIMIT 1"
        );
        $stmt->bind_param('ii', $idTicket, $idPaisOperacion);
        $stmt->execute();
        $ticket = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$ticket) {
            responderJsonAdminCasos([
                'ok' => false,
                'mensaje' => 'El caso no existe en el país activo.',
            ], 404);
        }

        $idEtapaActual = (int) ($ticket['id_etapa_actual'] ?? 0);
        $etapas = flujoObtenerEtapasTicket($conn, $idTicket);
        foreach ($etapas as &$etapa) {
            $etapa['es_actual'] = (int) ($etapa['id_ticket_etapa'] ?? 0)
                === $idEtapaActual;
        }
        unset($etapa);

        $nodos = prepararArbolAdminCasos($etapas);

        /*
         * Cada nodo viaja con su propia conversación, archivos e histórico.
         * La separación por id_ticket_etapa evita mezclar actividades entre
         * etapas oficiales y derivaciones del mismo caso padre.
         */
        $stmtHistorialNodo = $conn->prepare(
            "SELECT
                h.accion,
                h.detalle,
                h.creado_en,
                COALESCE(u.nombre, 'Sistema') AS usuario
             FROM solicitud_historial AS h
             LEFT JOIN usuarios AS u ON u.id_usuario = h.id_usuario
             WHERE h.id_ticket = ?
               AND h.id_ticket_etapa = ?
             ORDER BY h.creado_en DESC, h.id_historial DESC"
        );

        foreach ($nodos as &$nodo) {
            $idNodo = (int) ($nodo['id'] ?? 0);
            $nodo['conversacion'] = flujoComunicacionesNodo(
                $conn,
                $idTicket,
                $idNodo
            );
            $nodo['archivos'] = flujoAdjuntosNodo(
                $conn,
                $idTicket,
                $idNodo
            );
            $nodo['historico'] = [];
            $stmtHistorialNodo->bind_param('ii', $idTicket, $idNodo);
            $stmtHistorialNodo->execute();
            $resultadoHistorialNodo = $stmtHistorialNodo->get_result();
            while ($evento = $resultadoHistorialNodo->fetch_assoc()) {
                $nodo['historico'][] = $evento;
            }
        }
        unset($nodo);
        $stmtHistorialNodo->close();

        $totalHijos = count(array_filter(
            $nodos,
            static fn (array $nodo): bool => $nodo['tipo'] === 'hijo'
        ));
        $totalEtapas = count($nodos) - $totalHijos;
        $proyeccionFinalizacion = flujoProyeccionFinalizacionTicket($conn, $idTicket);

        responderJsonAdminCasos([
            'ok' => true,
            'caso' => [
                'id' => (int) $ticket['id_ticket'],
                'titulo' => (string) ($ticket['titulo'] ?? ''),
                'descripcion' => (string) ($ticket['descripcion'] ?? ''),
                'solicitante' => (string) ($ticket['solicitante'] ?? ''),
                'flujo' => (string) ($ticket['flujo_nombre'] ?? ''),
                'estado' => (string) ($ticket['estado_flujo'] ?? ''),
                'id_etapa_actual' => (int) ($ticket['id_etapa_actual'] ?? 0),
                'fecha_creacion' => $ticket['fecha_creacion'] ?? null,
                'fecha_finalizacion' => $ticket['fecha_finalizacion'] ?? null,
                'actualizado_en' => $ticket['actualizado_en'] ?? null,
                'proyeccion_finalizacion' => $proyeccionFinalizacion,
                'total_etapas' => $totalEtapas,
                'total_hijos' => $totalHijos,
            ],
            'nodos' => $nodos,
        ]);
    } catch (Throwable $e) {
        error_log('Árbol administrativo de casos: ' . $e->getMessage());
        responderJsonAdminCasos([
            'ok' => false,
            'mensaje' => 'No fue posible cargar la trazabilidad del caso.',
        ], 500);
    }
}

$casosPadre = [];

if ($moduloDisponible) {
    $condicionBusquedaCasos = '';
    if ($busquedaCasos !== '') {
        $buscarEscapado = $conn->real_escape_string($busquedaCasos);
        $buscarLike = "'%{$buscarEscapado}%'";

        if ($tipoBusquedaCasos === 'caso') {
            $numeroCaso = filter_var($busquedaCasos, FILTER_VALIDATE_INT);
            $condicionBusquedaCasos = $numeroCaso && $numeroCaso > 0
                ? ' AND t.id_ticket = ' . (int) $numeroCaso
                : ' AND 1 = 0';
        } elseif ($tipoBusquedaCasos === 'solicitante') {
            $condicionBusquedaCasos = " AND solicitante.nombre LIKE {$buscarLike}";
        } elseif ($tipoBusquedaCasos === 'gestor') {
            $condicionBusquedaCasos = " AND EXISTS (
                SELECT 1
                FROM ticket_etapas AS te_busqueda_gestor
                LEFT JOIN usuarios AS u_busqueda_gestor
                  ON u_busqueda_gestor.id_usuario = te_busqueda_gestor.id_gestor
                WHERE te_busqueda_gestor.id_ticket = t.id_ticket
                  AND COALESCE(
                      NULLIF(u_busqueda_gestor.nombre, ''),
                      te_busqueda_gestor.gestor_nombre,
                      ''
                  ) LIKE {$buscarLike}
            )";
        } else {
            $condicionBusquedaCasos = " AND EXISTS (
                SELECT 1
                FROM ticket_etapas AS te_busqueda_derivacion
                WHERE te_busqueda_derivacion.id_ticket = t.id_ticket
                  AND (
                      CAST(te_busqueda_derivacion.id_ticket_etapa AS CHAR) LIKE {$buscarLike}
                      OR te_busqueda_derivacion.catalogo_nombre LIKE {$buscarLike}
                      OR te_busqueda_derivacion.servicio_nombre LIKE {$buscarLike}
                      OR COALESCE(te_busqueda_derivacion.motivo_derivacion, '') LIKE {$buscarLike}
                  )
            )";
        }
    }

    $resultadoConteo = $conn->query(
        "SELECT COUNT(*) AS total
         FROM tickets AS t
         LEFT JOIN usuarios AS solicitante ON solicitante.id_usuario = t.id_usuario
         WHERE t.id_proceso IS NOT NULL
           AND t.id_pais_operacion = {$idPaisOperacion}
           {$condicionBusquedaCasos}"
    );
    if ($resultadoConteo !== false) {
        $filaConteo = $resultadoConteo->fetch_assoc();
        $totalCasos = (int) ($filaConteo['total'] ?? 0);
    }
    $totalPaginasCasos = max(1, (int) ceil($totalCasos / $casosPorPagina));
    $paginaCasos = min($paginaCasos, $totalPaginasCasos);
    $desplazamientoCasos = ($paginaCasos - 1) * $casosPorPagina;

    $resultado = $conn->query(
        "SELECT
            t.id_ticket,
            t.titulo,
            t.descripcion,
            t.estado_flujo,
            t.fecha_creacion,
            t.actualizado_en,
            p.nombre AS flujo_nombre,
            te.id_ticket_etapa,
            te.catalogo_nombre,
            te.servicio_nombre,
            te.estado AS estado_caso,
            COALESCE(solicitante.nombre, 'Usuario eliminado') AS solicitante,
            COALESCE(
                NULLIF(gestor.nombre, ''),
                NULLIF(te.gestor_nombre, ''),
                'Sin asignar'
            ) AS gestor_actual,
            (
                SELECT COUNT(*)
                FROM ticket_etapas AS te_total
                WHERE te_total.id_ticket = t.id_ticket
                  AND te_total.id_ticket_etapa_padre IS NULL
            ) AS total_etapas,
            (
                SELECT COUNT(*)
                FROM ticket_etapas AS te_hijo
                WHERE te_hijo.id_ticket = t.id_ticket
                  AND te_hijo.id_ticket_etapa_padre IS NOT NULL
            ) AS total_hijos,
            EXISTS (
                SELECT 1
                FROM ticket_etapas AS te_hijo_activo
                WHERE te_hijo_activo.id_ticket = t.id_ticket
                  AND te_hijo_activo.id_ticket_etapa_padre IS NOT NULL
                  AND te_hijo_activo.estado NOT IN ('completada', 'cancelada')
            ) AS tiene_hijo_activo
         FROM tickets AS t
         INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
         LEFT JOIN usuarios AS solicitante ON solicitante.id_usuario = t.id_usuario
         LEFT JOIN ticket_etapas AS te
            ON te.id_ticket_etapa = COALESCE(
                (
                    SELECT te_activa.id_ticket_etapa
                    FROM ticket_etapas AS te_activa
                    WHERE te_activa.id_ticket = t.id_ticket
                      AND te_activa.id_ticket_etapa_padre IS NULL
                      AND te_activa.estado IN (
                          'pendiente',
                          'en_proceso',
                          'en_espera_solicitante',
                          'pausada',
                          'listo_cierre'
                      )
                    ORDER BY te_activa.orden, te_activa.id_ticket_etapa
                    LIMIT 1
                ),
                (
                    SELECT te_ultima.id_ticket_etapa
                    FROM ticket_etapas AS te_ultima
                    WHERE te_ultima.id_ticket = t.id_ticket
                      AND te_ultima.id_ticket_etapa_padre IS NULL
                    ORDER BY te_ultima.orden DESC, te_ultima.id_ticket_etapa DESC
                    LIMIT 1
                )
            )
         LEFT JOIN usuarios AS gestor ON gestor.id_usuario = te.id_gestor
         WHERE t.id_proceso IS NOT NULL
           AND t.id_pais_operacion = {$idPaisOperacion}
           {$condicionBusquedaCasos}
         ORDER BY t.actualizado_en DESC, t.id_ticket DESC
         LIMIT {$desplazamientoCasos}, {$casosPorPagina}"
    );

    if ($resultado !== false) {
        while ($caso = $resultado->fetch_assoc()) {
            $estadoFlujo = (string) ($caso['estado_flujo'] ?? '');
            $caso['estado_actual'] = in_array(
                $estadoFlujo,
                ['cerrado', 'pendiente_calificacion'],
                true
            )
                ? $estadoFlujo
                : (string) ($caso['estado_caso'] ?? $estadoFlujo);
            $casosPadre[] = $caso;
        }
    }

    $etapasBusquedaPorCaso = [];
    $idsCasosPagina = array_values(array_filter(array_map(
        static function (array $caso): int {
            return (int) ($caso['id_ticket'] ?? 0);
        },
        $casosPadre
    )));
    $resultadoBusqueda = $idsCasosPagina
        ? $conn->query(
        "SELECT
            te.id_ticket,
            te.id_ticket_etapa,
            te.id_ticket_etapa_padre,
            te.orden,
            te.catalogo_nombre,
            te.servicio_nombre,
            te.motivo_derivacion,
            COALESCE(NULLIF(gestor.nombre, ''), NULLIF(te.gestor_nombre, ''), '') AS gestor
         FROM ticket_etapas AS te
         INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
         LEFT JOIN usuarios AS gestor ON gestor.id_usuario = te.id_gestor
         WHERE t.id_proceso IS NOT NULL
           AND t.id_pais_operacion = {$idPaisOperacion}
           AND te.id_ticket IN (" . implode(',', $idsCasosPagina) . ")
         ORDER BY te.id_ticket, te.orden, te.id_ticket_etapa"
        )
        : false;

    if ($resultadoBusqueda !== false) {
        while ($etapaBusqueda = $resultadoBusqueda->fetch_assoc()) {
            $idCasoBusqueda = (int) ($etapaBusqueda['id_ticket'] ?? 0);
            if ($idCasoBusqueda > 0) {
                $etapasBusquedaPorCaso[$idCasoBusqueda][] = $etapaBusqueda;
            }
        }
    }

    foreach ($casosPadre as &$caso) {
        $idCasoBusqueda = (int) ($caso['id_ticket'] ?? 0);
        $indicesBusqueda = terminosBusquedaAdminCasos(
            $etapasBusquedaPorCaso[$idCasoBusqueda] ?? []
        );
        $caso['busqueda_derivaciones'] = $indicesBusqueda['derivaciones'];
        $caso['busqueda_gestores'] = $indicesBusqueda['gestores'];
    }
    unset($caso);
}

$nombreAdministrador = trim((string) (
    $_SESSION['usuario'] ?? 'Administrador'
));

$gestoresReasignacion = [];
$stmtGestoresReasignacion = $conn->prepare(
    "SELECT id_usuario, nombre, email, proceso
     FROM usuarios
     WHERE id_rol = 2
       AND id_pais_operacion = ?
       AND estado = 'activo'
     ORDER BY nombre, email"
);
$stmtGestoresReasignacion->bind_param('i', $idPaisOperacion);
$stmtGestoresReasignacion->execute();
$resultadoGestoresReasignacion = $stmtGestoresReasignacion->get_result();
while ($gestorReasignacion = $resultadoGestoresReasignacion->fetch_assoc()) {
    $gestoresReasignacion[] = [
        'id' => (int) $gestorReasignacion['id_usuario'],
        'nombre' => (string) ($gestorReasignacion['nombre'] ?? ''),
        'email' => (string) ($gestorReasignacion['email'] ?? ''),
        'proceso' => (string) ($gestorReasignacion['proceso'] ?? ''),
    ];
}
$stmtGestoresReasignacion->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tickets | Administración</title>
    <style>
        :root {
            --primary:#0f6fec;
            --primary-dark:#0b4fae;
            --navy:#102a43;
            --text:#243b53;
            --muted:#6b7f93;
            --border:#dce6f0;
            --background:#f4f7fb;
            --surface:#ffffff;
        }
        * { box-sizing:border-box; }
        body {
            min-height:100vh;margin:0;color:var(--text);background:var(--background);
            font:12.5px/1.4 Inter,"Segoe UI",Arial,sans-serif;
        }
        body.modal-caso-abierto { overflow-x:hidden;overflow-y:auto; }
        body.modal-caso-abierto main.shell > .panel { display:none; }
        button,input { font:inherit; }
        .shell { width:calc(100% - 24px);max-width:none;margin:auto;padding:16px 0 30px; }
        .topbar {
            min-height:58px;display:flex;align-items:center;justify-content:space-between;
            gap:14px;padding:9px 12px 9px 16px;border:1px solid var(--border);
            border-radius:12px;background:var(--surface);box-shadow:0 5px 18px rgba(16,42,67,.05);
        }
        .heading { display:flex;align-items:center;gap:10px;min-width:0; }
        .mark {
            width:34px;height:34px;display:grid;place-items:center;flex:0 0 auto;
            border-radius:9px;color:#fff;background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            font-size:10px;font-weight:850;letter-spacing:.04em;
        }
        h1 { margin:0;color:var(--navy);font-size:17px;line-height:1.15; }
        .subtitle { margin:2px 0 0;color:var(--muted);font-size:10.5px; }
        .actions { display:flex;align-items:center;gap:6px;flex-wrap:wrap; }
        .btn {
            min-height:32px;display:inline-flex;align-items:center;justify-content:center;
            padding:7px 10px;border:1px solid #d8e5f2;border-radius:8px;
            color:#24577f;background:#f7fbff;text-decoration:none;font-size:10.5px;
            font-weight:750;white-space:nowrap;cursor:pointer;
        }
        .btn.primary { color:#fff;border-color:var(--primary);background:var(--primary); }
        .panel {
            margin-top:12px;overflow:hidden;border:1px solid var(--border);border-radius:12px;
            background:var(--surface);box-shadow:0 7px 22px rgba(16,42,67,.05);
        }
        .panel-head {
            min-height:58px;display:flex;align-items:center;justify-content:space-between;
            gap:16px;padding:12px 18px;border-bottom:1px solid var(--border);
        }
        .panel-title { display:flex;align-items:center;gap:9px;flex-wrap:wrap; }
        .panel-head h2 { margin:0;color:var(--navy);font-size:14px; }
        .count {
            display:inline-flex;align-items:center;padding:4px 8px;border-radius:999px;
            color:#2b628f;background:#edf5fd;font-size:9.5px;font-weight:800;
        }
        .filter-bar {
            display:flex;align-items:end;justify-content:space-between;gap:14px;
            min-height:70px;padding:14px 18px;border-bottom:1px solid var(--border);background:#fbfdff;
        }
        .filter-copy label { display:block;color:var(--navy);font-size:10.5px;font-weight:850; }
        .filter-copy p { margin:2px 0 0;color:var(--muted);font-size:9.5px; }
        .filter-control { width:min(560px,100%);display:flex;align-items:center;gap:8px; }
        .filter-control select {
            width:155px;min-height:34px;flex:0 0 155px;padding:7px 30px 7px 10px;
            border:1px solid #cfddea;border-radius:8px;color:var(--navy);background:#fff;
            outline:none;cursor:pointer;
        }
        .filter-control input {
            min-width:0;flex:1;min-height:34px;padding:7px 10px;border:1px solid #cfddea;
            border-radius:8px;color:var(--navy);background:#fff;outline:none;
        }
        .filter-control :is(select,input):focus {
            border-color:var(--primary);box-shadow:0 0 0 3px rgba(15,111,236,.12);
        }
        .clear-filter {
            min-height:34px;padding:7px 10px;border:1px solid #d8e5f2;border-radius:8px;
            color:#315f85;background:#fff;font-size:10px;font-weight:800;cursor:pointer;
        }
        .clear-filter:disabled { opacity:.48;cursor:not-allowed; }
        .search-submit {
            min-height:34px;padding:7px 12px;border:1px solid var(--primary);
            border-radius:8px;color:#fff;background:var(--primary);font-size:10px;
            font-weight:800;cursor:pointer;
        }
        .pagination {
            display:flex;align-items:center;justify-content:space-between;gap:12px;
            padding:12px 18px;border-top:1px solid var(--border);background:#fbfdff;
        }
        .pagination-copy { color:var(--muted);font-size:10px;font-weight:700; }
        .pagination-links { display:flex;align-items:center;gap:5px;flex-wrap:wrap; }
        .page-link {
            min-width:32px;min-height:32px;display:inline-grid;place-items:center;
            padding:6px 9px;border:1px solid #d8e5f2;border-radius:8px;
            color:#24577f;background:#fff;text-decoration:none;font-size:10px;font-weight:800;
        }
        .page-link.current { color:#fff;border-color:var(--primary);background:var(--primary); }
        .page-link.disabled { opacity:.45;pointer-events:none; }
        .table-wrap { width:100%;overflow:auto; }
        table { width:100%;border-collapse:collapse;table-layout:fixed;min-width:1350px; }
        col.col-case { width:92px; }
        col.col-subject { width:205px; }
        col.col-requester { width:120px; }
        col.col-stage { width:225px; }
        col.col-manager { width:110px; }
        col.col-status { width:140px; }
        col.col-deadline { width:185px; }
        col.col-branches { width:145px; }
        col.col-updated { width:128px; }
        th {
            padding:11px 16px;text-align:left;color:#647b91;background:#f8fafc;
            border-bottom:1px solid var(--border);font-size:9.5px;font-weight:800;
            letter-spacing:.045em;text-transform:uppercase;overflow-wrap:normal;
            word-break:normal;hyphens:none;
        }
        td { height:64px;padding:12px 16px;border-bottom:1px solid #edf2f7;vertical-align:middle; }
        tbody tr { transition:background .14s ease; }
        tbody tr:hover { background:#f5f9fe; }
        tbody tr:last-child td { border-bottom:0; }
        .case-link {
            padding:0;border:0;color:#0d62c7;background:transparent;font-weight:850;
            text-decoration:none;cursor:pointer;
        }
        .case-link:hover,.case-link:focus { text-decoration:underline; }
        .case-number { font-size:13px; }
        .subject { display:grid;gap:3px;min-width:0; }
        .subject strong { color:var(--navy);font-size:11px; }
        .subject span,.muted { color:var(--muted);font-size:9.5px; }
        .case-stage-summary {
            display:grid;gap:3px;min-width:0;background:transparent!important;
        }
        .case-stage-summary strong {
            color:var(--mesa-theme-heading,#274b68);font-size:10.5px;
        }
        .case-stage-summary span {
            color:var(--mesa-theme-muted,var(--muted));font-size:9.5px;
        }
        .manager,.requester { color:#315875;font-weight:700;overflow-wrap:anywhere; }
        .status {
            display:inline-flex;align-items:center;gap:5px;max-width:100%;
            padding:4px 8px;border-radius:999px;font-size:9.5px;font-weight:800;
            line-height:1.2;white-space:normal;text-align:center;
            overflow-wrap:anywhere;
        }
        .status::before { content:"";width:6px;height:6px;border-radius:50%;background:currentColor;flex:0 0 auto; }
        .status.proceso { color:#1767b5;background:#eaf4ff; }
        .status.espera { color:#9a6500;background:#fff6d9; }
        .status.cerrado { color:#087443;background:#eaf8f1; }
        .status.cancelado { color:#a33b32;background:#fff0ee; }
        .status.neutro { color:#65788a;background:#eef2f6; }
        .branch-count { display:grid;gap:2px; }
        .branch-count strong { color:#274b68;font-size:10.5px;white-space:nowrap; }
        .branch-count span { color:var(--muted);font-size:9px;white-space:nowrap; }
        .branch-active { color:#8a6100!important; }
        .deadline-cell .case-stage-summary strong { white-space:nowrap; }
        .updated-at { display:grid;gap:2px;color:var(--muted);white-space:nowrap; }
        .updated-at span,.updated-at time { display:block;font-size:9.5px; }
        .empty { padding:34px 18px;text-align:center;color:var(--muted); }
        .filter-empty { border-top:1px solid var(--border);background:#fbfdff; }
        .installation { margin:12px;padding:12px;border-radius:9px;color:#8a5b00;background:#fff8e1; }

        .case-modal {
            position:static;z-index:auto;width:100%;display:none;
            margin:12px 0 30px;padding:0;background:transparent;backdrop-filter:none;
        }
        .case-modal.open { display:block; }
        .case-dialog {
            width:100%;min-height:calc(100vh - 145px);height:auto;
            display:grid;grid-template-rows:auto auto minmax(560px,auto);overflow:visible;
            border:1px solid #cbdced;border-radius:14px;background:#f5f8fc;
            box-shadow:0 8px 28px rgba(16,42,67,.08);
        }
        .modal-head {
            display:flex;align-items:center;justify-content:space-between;gap:16px;
            padding:13px 16px;border-bottom:1px solid #dbe6f0;background:#fff;
        }
        .modal-title { display:flex;align-items:center;gap:10px;min-width:0; }
        .modal-title-icon {
            width:36px;height:36px;display:grid;place-items:center;flex:0 0 auto;
            border-radius:10px;color:#fff;background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            font-size:17px;font-weight:900;
        }
        .modal-title h2 { margin:0;color:var(--navy);font-size:16px; }
        .modal-title p { margin:2px 0 0;color:var(--muted);font-size:9.5px; }
        .modal-close {
            width:36px;height:36px;display:grid;place-items:center;flex:0 0 auto;
            border:1px solid #d6e2ed;border-radius:9px;color:#385b77;background:#fff;
            font-size:20px;line-height:1;cursor:pointer;
        }
        .modal-summary {
            display:grid;grid-template-columns:minmax(0,1.4fr) repeat(5,minmax(105px,.7fr));
            gap:8px;padding:10px 14px;border-bottom:1px solid #dbe6f0;background:#fbfdff;
        }
        .summary-main,.summary-stat {
            min-width:0;padding:9px 10px;border:1px solid #dce7f1;border-radius:9px;background:#fff;
        }
        .summary-description {
            grid-column:1 / -1;min-width:0;padding:10px 12px;border:1px solid #dce7f1;
            border-radius:9px;background:#fff;
        }
        .summary-description span {
            display:block;color:var(--muted);font-size:9px;font-weight:800;
            letter-spacing:.035em;text-transform:uppercase;
        }
        .summary-description p {
            max-height:86px;margin:4px 0 0;overflow:auto;color:var(--navy);
            font-size:10.5px;line-height:1.48;white-space:pre-wrap;overflow-wrap:anywhere;
        }
        .summary-main span,.summary-stat span {
            display:block;color:var(--muted);font-size:9px;font-weight:800;
            letter-spacing:.035em;text-transform:uppercase;
        }
        .summary-main strong,.summary-stat strong {
            display:block;margin-top:2px;overflow:hidden;color:var(--navy);
            font-size:10.5px;text-overflow:ellipsis;white-space:nowrap;
        }
        .modal-content {
            position:relative;min-height:560px;display:grid;
            grid-template-columns:minmax(320px,.78fr) minmax(0,1.35fr);
            gap:10px;padding:10px;overflow:visible;align-items:start;
            transition:grid-template-columns .2s ease;
        }
        .modal-content.detail-collapsed { grid-template-columns:minmax(0,1fr); }
        .modal-content.detail-collapsed .detail-panel { display:none; }
        .modal-content.detail-collapsed .tree-panel { width:100%; }
        .tree-panel,.detail-panel {
            min-height:560px;overflow:visible;border:1px solid #dce6f0;border-radius:11px;background:#fff;
        }
        .tree-panel { height:auto; }
        .detail-panel {
            position:static;z-index:auto;width:auto;visibility:visible;transform:none;opacity:1;
            box-shadow:none;transition:none;
        }
        .detail-panel.open { visibility:visible;transform:none;opacity:1; }
        .detail-panel .section-head { padding:11px 12px; }
        .detail-head-copy { min-width:0; }
        .detail-head-copy h3 { margin:0;color:var(--navy);font-size:11.5px; }
        .detail-head-copy span { display:block;margin-top:2px;color:var(--muted);font-size:9px; }
        .drawer-close {
            width:31px;height:31px;display:grid;place-items:center;flex:0 0 auto;padding:0;
            border:1px solid #d6e2ed;border-radius:8px;color:#385b77;background:#fff;font-size:18px;cursor:pointer;
        }
        .detail-tabs {
            position:sticky;top:53px;z-index:2;display:grid;grid-template-columns:repeat(4,1fr);
            gap:5px;padding:8px 12px;border-bottom:1px solid #e1e9f1;background:#fff;
        }
        .detail-tab {
            min-height:34px;padding:7px;border:1px solid #dbe6f0;border-radius:8px;
            color:#4c6980;background:#f8fbfe;font-size:9px;font-weight:850;cursor:pointer;
        }
        .detail-tab.active { border-color:#8bbcf1;color:#075dbd;background:#eaf4ff; }
        .detail-view[hidden] { display:none; }
        .conversation-stream,.history-stream { display:grid;gap:8px;padding:12px; }
        .conversation-message,.history-event {
            padding:9px 10px;border:1px solid #e0e8f0;border-radius:9px;background:#fbfdff;
        }
        .conversation-message strong,.history-event strong { display:block;color:var(--navy);font-size:9.5px; }
        .conversation-message p,.history-event p { margin:4px 0;color:#294c67;font-size:9.5px;white-space:pre-wrap; }
        .event-meta { color:var(--muted);font-size:9px; }
        .node-files { display:grid;gap:6px;padding:0 12px 12px; }
        .node-file {
            display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 9px;
            border:1px solid #dce7f1;border-radius:8px;background:#fff;
        }
        .node-file span { min-width:0;overflow:hidden;color:#315875;font-size:9px;text-overflow:ellipsis;white-space:nowrap; }
        .node-file a { color:#075dbd;font-size:9px;font-weight:850;text-decoration:none; }
        .detail-filter {
            display:flex;align-items:center;gap:8px;margin:12px 12px 0;padding:8px 10px;
            border:1px solid #dce7f1;border-radius:9px;background:#f8fbfe;
        }
        .detail-filter label { color:#315875;font-size:9px;font-weight:850;white-space:nowrap; }
        .detail-filter select {
            min-width:0;flex:1;padding:7px 9px;border:1px solid #cdddeb;border-radius:7px;
            color:#294c67;background:#fff;font-size:9px;
        }
        .section-head {
            position:sticky;top:0;z-index:2;display:flex;align-items:center;
            justify-content:space-between;gap:10px;padding:10px 12px;border-bottom:1px solid #e1e9f1;
            background:rgba(255,255,255,.97);backdrop-filter:blur(3px);
        }
        .section-head h3 { margin:0;color:var(--navy);font-size:11.5px; }
        .section-head span { color:var(--muted);font-size:9px; }
        .tree-content { padding:12px; }
        .tree-root,.tree-node {
            position:relative;width:100%;display:grid;grid-template-columns:auto minmax(0,1fr) auto;
            align-items:center;gap:9px;padding:10px;border:1px solid #dbe6f0;border-radius:10px;
            color:var(--text);background:#fff;text-align:left;cursor:pointer;transition:.15s ease;
        }
        .tree-root { border-color:#b8d6f8;background:#f3f8ff; }
        .tree-node:hover,.tree-root:hover { border-color:#8fbeeF;background:#f6faff; }
        .tree-node.selected,.tree-root.selected {
            border-color:var(--primary);box-shadow:0 0 0 3px rgba(15,111,236,.11);background:#f4f9ff;
        }
        .node-code {
            min-width:62px;display:inline-flex;align-items:center;justify-content:center;
            padding:5px 8px;border-radius:7px;color:#075dbd;background:#e9f3ff;
            font-size:9.5px;font-weight:900;white-space:nowrap;
        }
        .tree-root .node-code { color:#fff;background:var(--primary); }
        .node-copy { min-width:0;display:grid;gap:1px; }
        .node-copy strong { overflow:hidden;color:var(--navy);font-size:10.5px;text-overflow:ellipsis;white-space:nowrap; }
        .node-copy span { overflow:hidden;color:var(--muted);font-size:9px;text-overflow:ellipsis;white-space:nowrap; }
        .current-mark {
            display:inline-flex;padding:3px 6px;border-radius:999px;color:#075dbd;
            background:#e6f2ff;font-size:9px;font-weight:850;white-space:nowrap;
        }
        .tree-children {
            position:relative;display:grid;gap:8px;margin:8px 0 0 24px;padding-left:18px;
            border-left:2px solid #d8e6f3;
        }
        .tree-branch { position:relative;display:grid;gap:8px; }
        .tree-branch::before {
            position:absolute;top:24px;left:-18px;width:18px;height:2px;background:#d8e6f3;content:"";
        }
        .loading-state,.error-state {
            min-height:260px;display:grid;place-items:center;padding:30px;text-align:center;color:var(--muted);
        }
        .loading-ring {
            width:34px;height:34px;margin:0 auto 10px;border:3px solid #dce9f7;
            border-top-color:var(--primary);border-radius:50%;animation:spin .7s linear infinite;
        }
        @keyframes spin { to { transform:rotate(360deg); } }
        .detail-content { padding:12px; }
        .detail-hero {
            display:grid;gap:7px;padding:12px;border-radius:10px;color:#fff;
            background:linear-gradient(135deg,#0d64cd,#0c4f9f);
        }
        .detail-hero small { opacity:.8;font-size:9px;font-weight:800;text-transform:uppercase; }
        .detail-hero h4 { margin:0;font-size:14px; }
        .detail-hero p { margin:0;opacity:.9;font-size:9.5px;white-space:pre-wrap; }
        .request-context {
            display:grid;grid-template-columns:minmax(180px,.55fr) minmax(0,1.45fr);
            gap:8px;margin-bottom:9px;padding:10px;border:1px solid #cfe0f1;
            border-radius:10px;background:#f4f8fd;
        }
        .request-context-item { min-width:0;padding:7px 8px;border-radius:8px;background:#fff; }
        .request-context-item span {
            display:block;color:var(--muted);font-size:8.5px;font-weight:850;
            letter-spacing:.04em;text-transform:uppercase;
        }
        .request-context-item strong,.request-context-item p {
            display:block;margin:4px 0 0;color:var(--navy);font-size:10px;overflow-wrap:anywhere;
        }
        .request-context-item p { max-height:92px;overflow:auto;line-height:1.45;white-space:pre-wrap; }
        .detail-grid { display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:9px; }
        .detail-card {
            min-width:0;padding:9px;border:1px solid #e0e8f0;border-radius:8px;background:#fbfdff;
        }
        .detail-card.wide { grid-column:1 / -1; }
        .detail-card span { display:block;color:var(--muted);font-size:9px;font-weight:800;text-transform:uppercase; }
        .detail-card strong,.detail-card p {
            display:block;margin:3px 0 0;color:var(--navy);font-size:9.5px;overflow-wrap:anywhere;
        }
        .detail-card p { white-space:pre-wrap;font-weight:500; }
        .manager-assignment {
            display:grid;gap:8px;margin-top:9px;padding:11px;border:1px solid #cfe0f1;
            border-radius:10px;background:#f4f8fd;
        }
        .manager-assignment-head { display:grid;gap:2px; }
        .manager-assignment-head strong { color:var(--navy);font-size:10.5px; }
        .manager-assignment-head span { color:var(--muted);font-size:9px;line-height:1.4; }
        .manager-assignment-controls { display:grid;grid-template-columns:minmax(0,1fr) auto;gap:7px; }
        .manager-assignment select {
            width:100%;min-height:35px;padding:7px 9px;border:1px solid #cfddea;
            border-radius:8px;color:var(--navy);background:#fff;outline:none;
        }
        .manager-assignment button {
            min-height:35px;padding:7px 12px;border:1px solid var(--primary);border-radius:8px;
            color:#fff;background:var(--primary);font-size:9.5px;font-weight:850;cursor:pointer;
        }
        .manager-assignment button:disabled { opacity:.55;cursor:wait; }
        .manager-assignment-status { min-height:14px;color:var(--muted);font-size:9px; }
        .manager-assignment-status.ok { color:#087443;font-weight:800; }
        .manager-assignment-status.error { color:#b42318;font-weight:800; }
        .rating-line { display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin-top:4px; }
        .rating-pill {
            padding:4px 7px;border-radius:7px;color:#725200;background:#fff3c7;
            font-size:9px;font-weight:850;
        }
        .history-event { display:grid;gap:8px;border-left:4px solid var(--primary); }
        .history-action { color:var(--navy);font-size:10.5px;font-weight:900; }
        .history-detail-label {
            display:block;margin-bottom:3px;color:var(--muted);font-size:8.5px;
            font-weight:850;letter-spacing:.04em;text-transform:uppercase;
        }
        .history-meta-grid {
            display:grid;grid-template-columns:minmax(140px,1fr) minmax(145px,1fr);
            gap:7px;
        }
        .history-meta-item { padding:7px 8px;border-radius:7px;background:#eef5fc; }
        .history-meta-item span { display:block;color:var(--muted);font-size:8px;font-weight:800;text-transform:uppercase; }
        .history-meta-item strong { display:block;margin-top:2px;color:var(--navy);font-size:9px; }
        .modal-hint {
            padding:9px 12px;border-top:1px solid #e4ebf2;color:#5b7184;
            background:#f9fbfd;font-size:9px;text-align:center;
        }
        @media (max-width:900px) {
            .modal-summary { grid-template-columns:1fr 1fr; }
            .summary-main { grid-column:1 / -1; }
            .modal-content { grid-template-columns:1fr;overflow:visible; }
            .tree-panel { min-height:330px; }
            .detail-panel { overflow:auto; }
            .request-context { grid-template-columns:1fr; }
        }
        @media (max-width:760px) {
            .shell { width:calc(100% - 14px);padding-top:7px; }
            .topbar { align-items:flex-start;flex-direction:column; }
            .actions { width:100%; }
            .btn { flex:1; }
            .filter-bar { align-items:stretch;flex-direction:column; }
            .filter-control { width:100%; }
            .filter-control select { width:135px;flex-basis:135px; }
            .case-modal { width:100%;padding:0; }
            .case-dialog { width:100%;min-height:calc(100vh - 90px);height:auto;border-radius:10px; }
            .modal-summary { grid-template-columns:1fr 1fr; }
            .modal-content { padding:7px; }
            .tree-children { margin-left:13px;padding-left:12px; }
            .tree-branch::before { left:-12px;width:12px; }
            .detail-grid { grid-template-columns:1fr; }
            .manager-assignment-controls { grid-template-columns:1fr; }
            .detail-card.wide { grid-column:auto; }
            .detail-panel { width:100%; }
            .history-meta-grid { grid-template-columns:1fr; }
        }

        /*
         * Trazabilidad: capa semántica de contraste.
         *
         * Esta vista no debe heredar blancos, negros ni azules fijos porque la
         * apariencia elegida puede invertir las superficies. El id del módulo
         * aumenta la especificidad para que estas reglas prevalezcan sobre la
         * capa transversal de apariencia sin afectar otros PHP.
         */
        body.mesa-php-shell #modalArbolCaso {
            --trace-bg:var(--mesa-theme-bg,var(--background));
            --trace-surface:var(--mesa-theme-surface,var(--surface));
            --trace-soft:var(--mesa-theme-soft,#f4f7fb);
            --trace-border:var(--mesa-theme-border,var(--border));
            --trace-heading:var(--mesa-theme-heading,var(--navy));
            --trace-text:var(--mesa-theme-text,var(--text));
            --trace-muted:var(--mesa-theme-muted,var(--muted));
            --trace-link:var(--mesa-theme-link,var(--primary));
            --trace-accent:var(--mesa-shell-color,var(--primary));
            color:var(--trace-text)!important;
        }
        body.mesa-php-shell #modalArbolCaso .case-dialog {
            border-color:var(--trace-border)!important;
            color:var(--trace-text)!important;
            background:var(--trace-bg)!important;
            box-shadow:0 8px 28px color-mix(in srgb,var(--trace-heading) 14%,transparent)!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(
            .modal-head,.modal-summary,.tree-panel,.detail-panel,.section-head,
            .detail-tabs,.tree-root,.tree-node,.summary-main,.summary-stat,
            .summary-description,.request-context-item,.detail-card,.node-file,
            .conversation-message,.history-event,.history-meta-item
        ) {
            border-color:var(--trace-border)!important;
            color:var(--trace-text)!important;
            background:var(--trace-surface)!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(.modal-summary,.modal-content,.request-context) {
            border-color:var(--trace-border)!important;
            color:var(--trace-text)!important;
            background:var(--trace-soft)!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(
            .modal-title h2,.section-head h3,.detail-head-copy h3,
            .summary-main strong,.summary-stat strong,.node-copy strong,
            .detail-card strong,.detail-card p,.request-context-item strong,
            .manager-assignment-head strong,
            .request-context-item p,.conversation-message strong,
            .conversation-message p,.history-event strong,.history-event p,
            .history-meta-item strong
        ) {
            color:var(--trace-heading)!important;
            opacity:1!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(
            .modal-title p,.section-head span,.detail-head-copy span,
            .summary-main span,.summary-stat span,.summary-description span,
            .node-copy span,.detail-card span,.request-context-item span,
            .manager-assignment-head span,.manager-assignment-status,
            .event-meta,.history-meta-item span,.modal-hint
        ) {
            color:var(--trace-muted)!important;
            opacity:1!important;
        }
        body.mesa-php-shell #modalArbolCaso .summary-description p {
            color:var(--trace-heading)!important;
            background:transparent!important;
            opacity:1!important;
            scrollbar-color:var(--trace-accent) var(--trace-soft);
        }
        body.mesa-php-shell #modalArbolCaso .modal-title-icon {
            border:1px solid color-mix(in srgb,var(--trace-accent) 55%,var(--trace-border))!important;
            color:var(--trace-link)!important;
            background:color-mix(in srgb,var(--trace-accent) 13%,var(--trace-surface))!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(.modal-close,.drawer-close) {
            border-color:var(--trace-border)!important;
            color:var(--trace-heading)!important;
            background:var(--trace-soft)!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(.modal-close,.drawer-close):hover {
            border-color:var(--trace-accent)!important;
            color:var(--trace-link)!important;
            background:color-mix(in srgb,var(--trace-accent) 12%,var(--trace-surface))!important;
        }
        body.mesa-php-shell #modalArbolCaso .detail-tab {
            border-color:var(--trace-border)!important;
            color:var(--trace-heading)!important;
            background:var(--trace-surface)!important;
        }
        body.mesa-php-shell #modalArbolCaso .detail-tab:hover {
            border-color:color-mix(in srgb,var(--trace-accent) 55%,var(--trace-border))!important;
            background:var(--trace-soft)!important;
        }
        body.mesa-php-shell #modalArbolCaso .detail-tab.active {
            border-color:var(--trace-accent)!important;
            color:var(--trace-heading)!important;
            background:color-mix(in srgb,var(--trace-accent) 16%,var(--trace-surface))!important;
            box-shadow:inset 0 -3px 0 var(--trace-accent)!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(.tree-root,.tree-node):hover {
            border-color:color-mix(in srgb,var(--trace-accent) 58%,var(--trace-border))!important;
            background:var(--trace-soft)!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(.tree-root.selected,.tree-node.selected) {
            border-color:var(--trace-accent)!important;
            color:var(--trace-text)!important;
            background:color-mix(in srgb,var(--trace-accent) 14%,var(--trace-surface))!important;
            box-shadow:0 0 0 2px color-mix(in srgb,var(--trace-accent) 24%,transparent)!important;
        }
        body.mesa-php-shell #modalArbolCaso .node-code,
        body.mesa-php-shell #modalArbolCaso .tree-root .node-code,
        body.mesa-php-shell #modalArbolCaso .current-mark {
            border:1px solid color-mix(in srgb,var(--trace-accent) 42%,var(--trace-border))!important;
            color:var(--trace-heading)!important;
            background:var(--trace-soft)!important;
        }
        body.mesa-php-shell #modalArbolCaso .tree-children {
            border-left-color:var(--trace-border)!important;
        }
        body.mesa-php-shell #modalArbolCaso .tree-branch::before {
            background:var(--trace-border)!important;
        }
        body.mesa-php-shell #modalArbolCaso .detail-hero {
            border:1px solid color-mix(in srgb,var(--trace-accent) 45%,var(--trace-border))!important;
            border-left:4px solid var(--trace-accent)!important;
            color:var(--trace-text)!important;
            background:color-mix(in srgb,var(--trace-accent) 12%,var(--trace-surface))!important;
            box-shadow:none!important;
        }
        body.mesa-php-shell #modalArbolCaso .detail-hero :is(small,h4,p) {
            color:var(--trace-heading)!important;
            opacity:1!important;
        }
        body.mesa-php-shell #modalArbolCaso .detail-hero small {
            color:var(--trace-muted)!important;
        }
        body.mesa-php-shell #modalArbolCaso :is(.detail-filter,select,input) {
            border-color:var(--trace-border)!important;
            color:var(--trace-text)!important;
            background:var(--trace-surface)!important;
        }
        body.mesa-php-shell #modalArbolCaso .manager-assignment {
            border-color:var(--trace-border)!important;
            color:var(--trace-text)!important;
            background:var(--trace-soft)!important;
        }
        body.mesa-php-shell #modalArbolCaso .manager-assignment button {
            border-color:var(--trace-accent)!important;
            color:var(--trace-heading)!important;
            background:color-mix(in srgb,var(--trace-accent) 18%,var(--trace-surface))!important;
        }
        body.mesa-php-shell.modal-caso-abierto main.shell > .topbar {
            border-color:var(--mesa-theme-border,var(--border))!important;
            color:var(--mesa-theme-text,var(--text))!important;
            background:var(--mesa-theme-surface,var(--surface))!important;
            opacity:1!important;
        }
        body.mesa-php-shell.modal-caso-abierto main.shell > .topbar :is(h1,.subtitle) {
            color:var(--mesa-theme-heading,var(--navy))!important;
            opacity:1!important;
        }
        body.mesa-php-shell.modal-caso-abierto main.shell > .topbar .btn {
            border-color:var(--mesa-theme-border,var(--border))!important;
            color:var(--mesa-theme-heading,var(--navy))!important;
            background:var(--mesa-theme-soft,#f4f7fb)!important;
            opacity:1!important;
        }
        body.mesa-php-shell.modal-caso-abierto main.shell > .topbar .btn.primary {
            border-color:var(--mesa-shell-color,var(--primary))!important;
            color:var(--mesa-theme-heading,var(--navy))!important;
            background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 15%,var(--mesa-theme-surface,var(--surface)))!important;
        }
        /* Tabla administrativa amplia y legible */
        @media (min-width:761px) {
            body{font-size:14px;line-height:1.48}
            .shell{width:calc(100% - 16px)!important;max-width:none!important;padding-top:18px}
            .topbar{min-height:70px;padding:12px 18px}
            .mark{width:40px;height:40px;font-size:12px}
            h1{font-size:24px}.subtitle{font-size:12px}
            .btn{min-height:40px;padding:9px 13px;font-size:12px}
            .panel-head{min-height:66px;padding:15px 18px}.panel-head h2{font-size:17px}
            .count{padding:5px 9px;font-size:11px}
            .filter-bar{min-height:82px;padding:16px 18px}
            .filter-copy label{font-size:13px}.filter-copy p{font-size:11px}
            .filter-control{width:min(650px,100%)}
            .filter-control select{width:175px;flex-basis:175px;min-height:40px;font-size:13px}
            .filter-control input{min-height:40px;font-size:13px}
            .clear-filter{min-height:40px;font-size:12px}
            th{padding:13px 16px;font-size:11px}
            td{height:76px;padding:14px 16px;font-size:13px}
            .case-number{font-size:15px}.subject strong{font-size:13px}
            .subject span,.muted,.stage-copy span{font-size:11px}
            .stage-copy strong,.branch-count strong{font-size:12px}
            .status{font-size:11px;padding:5px 9px}
            .branch-count span,.updated-at span,.updated-at time{font-size:10.5px}
        }
        tr[data-case-row]{cursor:pointer}tr[data-case-row]:hover{background:#f3f8ff}tr[data-case-row]:focus-visible{outline:3px solid #79b2ff;outline-offset:-3px}
    </style>
</head>
<body>
<main class="shell">
    <header class="topbar">
        <div class="heading">
            <div class="mark">MS</div>
            <div>
                <h1>Tickets</h1>
                <p class="subtitle"><?= escaparAdminCasos($nombreAdministrador) ?> · Administración</p>
            </div>
        </div>
        <nav class="actions" aria-label="Acciones administrativas">
            <a class="btn primary" href="descargarSolicitudesExcel.php">Descargar base</a>
            <a class="btn" href="procesos.php">Configurar tickets</a>
            <a class="btn" href="panelAdmin.php">Volver al panel</a>
        </nav>
    </header>

    <section class="panel">
        <div class="panel-head">
            <div class="panel-title">
                <h2>Casos</h2>
            </div>
            <span class="count" id="conteoCasosPadre">
                <?= count($casosPadre) ?> de <?= number_format($totalCasos, 0, ',', '.') ?> casos
            </span>
        </div>

        <div class="filter-bar">
            <div class="filter-copy">
                <label for="filtroCasosPadre">Buscar caso</label>
                <p>Filtre por caso, derivación, solicitante o gestor.</p>
            </div>
            <form class="filter-control" method="get" action="solicitudes.php">
                <select id="tipoFiltroCasos" name="tipo_busqueda" aria-label="Criterio de búsqueda">
                    <option value="caso" <?= $tipoBusquedaCasos === 'caso' ? 'selected' : '' ?>>Caso</option>
                    <option value="derivacion" <?= $tipoBusquedaCasos === 'derivacion' ? 'selected' : '' ?>>Derivación</option>
                    <option value="solicitante" <?= $tipoBusquedaCasos === 'solicitante' ? 'selected' : '' ?>>Solicitante</option>
                    <option value="gestor" <?= $tipoBusquedaCasos === 'gestor' ? 'selected' : '' ?>>Gestor</option>
                </select>
                <input
                    type="search"
                    id="filtroCasosPadre"
                    name="buscar"
                    placeholder="Número del caso"
                    autocomplete="off"
                    value="<?= escaparAdminCasos($busquedaCasos) ?>"
                >
                <button type="submit" class="search-submit">Buscar</button>
                <button type="button" class="clear-filter" id="limpiarFiltroCasos" <?= $busquedaCasos === '' ? 'disabled' : '' ?>>Limpiar</button>
            </form>
        </div>

        <?php if (!$moduloDisponible): ?>
            <div class="installation">
                El módulo de Tickets, soluciones y calificación detallada todavía no está instalado por completo.
            </div>
        <?php elseif (!$casosPadre): ?>
            <div class="empty">
                <?= $busquedaCasos !== ''
                    ? 'No hay casos que coincidan con la búsqueda.'
                    : 'No hay casos registrados.' ?>
            </div>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <colgroup>
                        <col class="col-case">
                        <col class="col-subject">
                        <col class="col-requester">
                        <col class="col-stage">
                        <col class="col-manager">
                        <col class="col-status">
                        <col class="col-deadline">
                        <col class="col-branches">
                        <col class="col-updated">
                    </colgroup>
                    <thead>
                    <tr>
                        <th>Caso</th>
                        <th>Asunto</th>
                        <th>Solicitante</th>
                        <th>Etapa actual</th>
                        <th>Gestor actual</th>
                        <th>Estado</th>
                        <th>Finalización prevista</th>
                        <th>Ramificación</th>
                        <th>Actualizado</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($casosPadre as $caso): ?>
                        <?php
                            $estadoActual = (string) ($caso['estado_actual'] ?? '');
                            $nombreEtapa = trim(implode(' / ', array_filter([
                                (string) ($caso['catalogo_nombre'] ?? ''),
                                (string) ($caso['servicio_nombre'] ?? ''),
                            ])));
                            if ($nombreEtapa === '') {
                                $nombreEtapa = 'Etapa no disponible';
                            }
                            $totalHijos = (int) ($caso['total_hijos'] ?? 0);
                            $fechaActualizacion = strtotime((string) ($caso['actualizado_en'] ?? ''));
                            $proyeccionCaso = flujoProyeccionFinalizacionTicket(
                                $conn,
                                (int) $caso['id_ticket']
                            );
                            $fechaProyectada = strtotime((string) ($proyeccionCaso['fecha'] ?? ''));
                        ?>
                        <tr
                            data-case-row
                            data-ticket-id="<?= (int) $caso['id_ticket'] ?>"
                            tabindex="0"
                            role="button"
                            aria-label="Abrir ticket <?= (int) $caso['id_ticket'] ?>"
                            onclick="if (!event.target.closest('a,button,input,select,textarea,form,details,summary')) { this.querySelector('[data-open-case]').click(); }"
                            onkeydown="if ((event.key === 'Enter' || event.key === ' ') && !event.target.closest('a,button,input,select,textarea')) { event.preventDefault(); this.querySelector('[data-open-case]').click(); }"
                            data-search-case="<?= escaparAdminCasos('caso ' . (int) $caso['id_ticket'] . ' ' . (int) $caso['id_ticket']) ?>"
                            data-search-derivation="<?= escaparAdminCasos($caso['busqueda_derivaciones'] ?? '') ?>"
                            data-search-requester="<?= escaparAdminCasos($caso['solicitante'] ?? '') ?>"
                            data-search-manager="<?= escaparAdminCasos(implode(' ', [
                                (string) ($caso['gestor_actual'] ?? ''),
                                (string) ($caso['busqueda_gestores'] ?? ''),
                            ])) ?>"
                        >
                            <td>
                                <button
                                    type="button"
                                    class="case-link case-number"
                                    data-open-case="<?= (int) $caso['id_ticket'] ?>"
                                    aria-label="Abrir información del caso <?= (int) $caso['id_ticket'] ?>"
                                ><?= (int) $caso['id_ticket'] ?></button>
                            </td>
                            <td>
                                <div class="subject">
                                    <strong><?= escaparAdminCasos($caso['titulo'] ?? 'Sin asunto') ?></strong>
                                    <span><?= escaparAdminCasos($caso['flujo_nombre'] ?? 'Flujo no disponible') ?></span>
                                </div>
                            </td>
                            <td class="requester"><?= escaparAdminCasos($caso['solicitante'] ?? 'Usuario eliminado') ?></td>
                            <td>
                                <div class="case-stage-summary">
                                    <strong><?= escaparAdminCasos($nombreEtapa) ?></strong>
                                    <span><?= (int) ($caso['total_etapas'] ?? 0) ?> etapa<?= (int) ($caso['total_etapas'] ?? 0) === 1 ? '' : 's' ?> en el flujo</span>
                                </div>
                            </td>
                            <td class="manager"><?= escaparAdminCasos($caso['gestor_actual'] ?? 'Sin asignar') ?></td>
                            <td>
                                <span class="status <?= escaparAdminCasos(claseEstadoAdminCasos($estadoActual)) ?>">
                                    <?= escaparAdminCasos(etiquetaEstadoAdminCasos($estadoActual)) ?>
                                </span>
                            </td>
                            <td class="deadline-cell">
                                <div class="case-stage-summary">
                                    <strong><?= $fechaProyectada ? date('d/m/Y H:i', $fechaProyectada) : 'Sin fecha' ?></strong>
                                    <span><?= !empty($proyeccionCaso['pausado_por_derivacion']) ? 'SLA pausado por derivación' : (($proyeccionCaso['estado'] ?? '') === 'finalizado' ? 'Fecha real' : 'Proyección dinámica') ?></span>
                                </div>
                            </td>
                            <td class="branches-cell">
                                <div class="branch-count">
                                    <strong><?= $totalHijos ?> caso<?= $totalHijos === 1 ? '' : 's' ?> hijo<?= $totalHijos === 1 ? '' : 's' ?></strong>
                                    <span class="<?= (int) ($caso['tiene_hijo_activo'] ?? 0) === 1 ? 'branch-active' : '' ?>">
                                        <?= (int) ($caso['tiene_hijo_activo'] ?? 0) === 1 ? 'Con gestión activa' : ($totalHijos > 0 ? 'Sin hijos activos' : 'Sin derivaciones') ?>
                                    </span>
                                </div>
                            </td>
                            <td>
                                <div class="updated-at">
                                    <?php if ($fechaActualizacion): ?>
                                        <span><?= date('d/m/Y', $fechaActualizacion) ?></span>
                                        <time datetime="<?= date('c', $fechaActualizacion) ?>"><?= date('H:i', $fechaActualizacion) ?></time>
                                    <?php else: ?>
                                        <span>Sin fecha</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="empty filter-empty" id="sinCasosPadre" hidden>
                No hay casos que coincidan con la búsqueda.
            </div>
            <?php if ($totalPaginasCasos > 1): ?>
                <?php
                    $paginaInicio = max(1, $paginaCasos - 2);
                    $paginaFin = min($totalPaginasCasos, $paginaCasos + 2);
                    $urlPagina = static function (int $pagina) use (
                        $tipoBusquedaCasos,
                        $busquedaCasos
                    ): string {
                        $parametros = ['pagina' => $pagina];
                        if ($busquedaCasos !== '') {
                            $parametros['tipo_busqueda'] = $tipoBusquedaCasos;
                            $parametros['buscar'] = $busquedaCasos;
                        }
                        return 'solicitudes.php?' . http_build_query($parametros);
                    };
                ?>
                <nav class="pagination" aria-label="Páginas de solicitudes">
                    <span class="pagination-copy">
                        Página <?= $paginaCasos ?> de <?= number_format($totalPaginasCasos, 0, ',', '.') ?>
                    </span>
                    <div class="pagination-links">
                        <a class="page-link<?= $paginaCasos <= 1 ? ' disabled' : '' ?>" href="<?= escaparAdminCasos($urlPagina(max(1, $paginaCasos - 1))) ?>">Anterior</a>
                        <?php for ($numeroPagina = $paginaInicio; $numeroPagina <= $paginaFin; $numeroPagina++): ?>
                            <a class="page-link<?= $numeroPagina === $paginaCasos ? ' current' : '' ?>" href="<?= escaparAdminCasos($urlPagina($numeroPagina)) ?>" <?= $numeroPagina === $paginaCasos ? 'aria-current="page"' : '' ?>><?= $numeroPagina ?></a>
                        <?php endfor; ?>
                        <a class="page-link<?= $paginaCasos >= $totalPaginasCasos ? ' disabled' : '' ?>" href="<?= escaparAdminCasos($urlPagina(min($totalPaginasCasos, $paginaCasos + 1))) ?>">Siguiente</a>
                    </div>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </section>

<div class="case-modal" id="modalArbolCaso" role="region" aria-labelledby="tituloModalCaso" hidden>
    <section class="case-dialog">
        <header class="modal-head">
            <div class="modal-title">
                <div class="modal-title-icon">⌘</div>
                <div>
                    <h2 id="tituloModalCaso">Trazabilidad del caso</h2>
                    <p id="subtituloModalCaso">Seleccione un caso para consultar su árbol.</p>
                </div>
            </div>
            <button type="button" class="modal-close" id="cerrarModalCaso" aria-label="Volver al listado de tickets">×</button>
        </header>
        <div class="modal-summary" id="resumenModalCaso" hidden></div>
        <div class="modal-content" id="contenidoModalCaso">
            <div class="tree-panel">
                <div class="loading-state">
                    <div><div class="loading-ring"></div>Cargando trazabilidad…</div>
                </div>
            </div>
            <div class="detail-panel">
                <div class="loading-state">El detalle aparecerá aquí.</div>
            </div>
        </div>
    </section>
</div>
</main>

<script>
(function () {
    'use strict';

    const filas = Array.from(document.querySelectorAll('[data-case-row]'));
    const tipoFiltro = document.getElementById('tipoFiltroCasos');
    const filtro = document.getElementById('filtroCasosPadre');
    const limpiar = document.getElementById('limpiarFiltroCasos');
    const conteo = document.getElementById('conteoCasosPadre');
    const sinResultados = document.getElementById('sinCasosPadre');
    const modal = document.getElementById('modalArbolCaso');
    const cerrar = document.getElementById('cerrarModalCaso');
    const tituloModal = document.getElementById('tituloModalCaso');
    const subtituloModal = document.getElementById('subtituloModalCaso');
    const resumenModal = document.getElementById('resumenModalCaso');
    const contenidoModal = document.getElementById('contenidoModalCaso');
    const gestoresReasignacion = <?= json_encode(
        $gestoresReasignacion,
        JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
        | JSON_HEX_TAG
        | JSON_HEX_AMP
        | JSON_HEX_APOS
        | JSON_HEX_QUOT
    ) ?>;
    const csrfReasignacion = <?= json_encode(
        seguridadTokenCsrf(),
        JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
    ) ?>;
    let botonOrigen = null;
    let controladorPeticion = null;
    let casoActual = null;

    function normalizar(valor) {
        return String(valor || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .toLocaleLowerCase('es')
            .trim();
    }

    function filtrarCasos() {
        if (!filtro) return;
        const termino = normalizar(filtro.value);
        const criterio = tipoFiltro ? tipoFiltro.value : 'caso';
        let visibles = 0;

        filas.forEach(function (fila) {
            let coincide = termino === '';

            if (!coincide && criterio === 'caso') {
                const numeroBuscado = termino
                    .replace(/^caso\s*/u, '')
                    .replace(/^#/u, '')
                    .trim();
                coincide = numeroBuscado !== ''
                    && String(fila.dataset.ticketId || '') === numeroBuscado;
            } else if (!coincide && criterio === 'derivacion') {
                coincide = normalizar(fila.dataset.searchDerivation || '')
                    .includes(termino);
            } else if (!coincide && criterio === 'solicitante') {
                coincide = normalizar(fila.dataset.searchRequester || '')
                    .includes(termino);
            } else if (!coincide && criterio === 'gestor') {
                coincide = normalizar(fila.dataset.searchManager || '')
                    .includes(termino);
            }

            fila.hidden = !coincide;
            if (coincide) visibles += 1;
        });

        if (conteo) {
            conteo.textContent = visibles + ' caso' + (visibles === 1 ? '' : 's');
        }
        if (limpiar) limpiar.disabled = termino === '';
        if (sinResultados) sinResultados.hidden = termino === '' || visibles > 0;
    }

    if (filtro) filtro.addEventListener('input', filtrarCasos);
    if (tipoFiltro) {
        const placeholders = {
            caso: 'Número del caso',
            derivacion: 'Código, área, servicio o motivo',
            solicitante: 'Nombre del solicitante',
            gestor: 'Nombre del gestor'
        };

        tipoFiltro.addEventListener('change', function () {
            if (filtro) {
                filtro.placeholder = placeholders[tipoFiltro.value] || 'Escriba para buscar';
            }
            filtrarCasos();
        });
    }
    if (limpiar) {
        limpiar.addEventListener('click', function () {
            if (window.parent !== window) {
                window.parent.postMessage({tipo: 'mesa-navegar', url: 'solicitudes.php'}, window.location.origin);
            } else {
                window.location.href = 'solicitudes.php';
            }
        });
    }

    function crearElemento(etiqueta, clase, texto) {
        const elemento = document.createElement(etiqueta);
        if (clase) elemento.className = clase;
        if (texto !== undefined && texto !== null) elemento.textContent = String(texto);
        return elemento;
    }

    function etiquetaEstado(estado) {
        const etiquetas = {
            pendiente: 'Pendiente',
            en_proceso: 'En proceso',
            en_espera_solicitante: 'En espera del solicitante',
            pausada: 'Pausado',
            listo_cierre: 'Listo · pendiente de cierre',
            bloqueada: 'Bloqueado',
            completada: 'Completado',
            pendiente_calificacion: 'Pendiente de calificación',
            cerrado: 'Cerrado',
            cancelado: 'Cancelado',
            cancelada: 'Cancelado'
        };
        return etiquetas[estado] || String(estado || 'Sin estado').replaceAll('_', ' ');
    }

    function claseEstado(estado) {
        if (['pendiente', 'en_proceso'].includes(estado)) return 'proceso';
        if (['en_espera_solicitante', 'pausada', 'listo_cierre', 'pendiente_calificacion'].includes(estado)) return 'espera';
        if (['completada', 'cerrado'].includes(estado)) return 'cerrado';
        if (['cancelado', 'cancelada'].includes(estado)) return 'cancelado';
        return 'neutro';
    }

    function formatearFecha(valor) {
        if (!valor) return 'Sin dato';
        const fecha = new Date(String(valor).replace(' ', 'T'));
        if (Number.isNaN(fecha.getTime())) return String(valor);
        return new Intl.DateTimeFormat('es-CO', {
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit', hour12: false
        }).format(fecha);
    }

    function formatearTiempo(minutos) {
        if (minutos === null || minutos === undefined || minutos === '') return 'Sin dato';
        const total = Math.max(0, Number(minutos) || 0);
        const horas = Math.floor(total / 60);
        const resto = total % 60;
        if (horas > 0) return horas + ' h ' + resto + ' min';
        return resto + ' min';
    }

    function estadoSla(valor) {
        const mapa = {
            dentro_sla: 'Dentro del SLA',
            fuera_sla: 'Fuera del SLA',
            en_tiempo: 'En tiempo',
            vencido: 'Vencido',
            pausado: 'Pausado',
            sin_iniciar: 'Sin iniciar'
        };
        return mapa[valor] || String(valor || 'Sin dato').replaceAll('_', ' ');
    }

    function agregarTarjeta(contenedor, etiqueta, valor, amplia, comoParrafo) {
        const tarjeta = crearElemento('div', 'detail-card' + (amplia ? ' wide' : ''));
        tarjeta.appendChild(crearElemento('span', '', etiqueta));
        const contenido = crearElemento(comoParrafo ? 'p' : 'strong', '', valor || 'Sin dato');
        tarjeta.appendChild(contenido);
        contenedor.appendChild(tarjeta);
        return tarjeta;
    }

    function crearControlReasignacion(contenedor, configuracion) {
        const idNodo = Number(configuracion.idNodo) || 0;
        const bloque = crearElemento('section', 'manager-assignment');
        const encabezado = crearElemento('div', 'manager-assignment-head');
        encabezado.appendChild(crearElemento('strong', '', configuracion.titulo || 'Reasignar gestor'));
        encabezado.appendChild(crearElemento(
            'span',
            '',
            'Cambio excepcional para este elemento. No modifica el gestor predeterminado del servicio.'
        ));
        bloque.appendChild(encabezado);

        if (idNodo < 1) {
            bloque.appendChild(crearElemento(
                'div',
                'manager-assignment-status',
                'Este caso no tiene una etapa actual disponible para reasignar.'
            ));
            contenedor.appendChild(bloque);
            return;
        }

        const controles = crearElemento('div', 'manager-assignment-controls');
        const selector = crearElemento('select');
        selector.setAttribute('aria-label', 'Nuevo gestor responsable');
        const opcionInicial = crearElemento('option', '', 'Seleccione un gestor activo');
        opcionInicial.value = '';
        selector.appendChild(opcionInicial);

        gestoresReasignacion.forEach(function (gestor) {
            const referencias = [];
            if (gestor.proceso) referencias.push(gestor.proceso);
            if (gestor.email) referencias.push(gestor.email);
            const opcion = crearElemento(
                'option',
                '',
                (gestor.nombre || 'Gestor sin nombre')
                    + (referencias.length ? ' · ' + referencias.join(' · ') : '')
            );
            opcion.value = String(gestor.id);
            if (Number(gestor.id) === Number(configuracion.idGestorActual)) {
                opcion.selected = true;
            }
            selector.appendChild(opcion);
        });

        const boton = crearElemento('button', '', 'Asignar gestor');
        boton.type = 'button';
        controles.appendChild(selector);
        controles.appendChild(boton);
        bloque.appendChild(controles);
        const estado = crearElemento('div', 'manager-assignment-status');
        bloque.appendChild(estado);

        boton.addEventListener('click', async function () {
            const idGestor = Number(selector.value) || 0;
            if (idGestor < 1) {
                estado.className = 'manager-assignment-status error';
                estado.textContent = 'Seleccione el nuevo gestor.';
                selector.focus();
                return;
            }
            if (idGestor === Number(configuracion.idGestorActual)) {
                estado.className = 'manager-assignment-status';
                estado.textContent = 'Ese gestor ya está asignado.';
                return;
            }

            const gestorElegido = gestoresReasignacion.find(function (gestor) {
                return Number(gestor.id) === idGestor;
            });
            const nombreElegido = gestorElegido?.nombre || 'el gestor seleccionado';
            if (!window.confirm(
                '¿Asignar ' + nombreElegido + ' a ' + configuracion.referencia + '?\n\n'
                + 'La configuración predeterminada del servicio no cambiará.'
            )) return;

            boton.disabled = true;
            selector.disabled = true;
            estado.className = 'manager-assignment-status';
            estado.textContent = 'Guardando la reasignación…';

            try {
                const formulario = new FormData();
                formulario.append('csrf_token', csrfReasignacion);
                formulario.append('id_ticket', String(casoActual?.caso?.id || 0));
                formulario.append('id_ticket_etapa', String(idNodo));
                formulario.append('id_gestor', String(idGestor));
                const respuesta = await fetch('solicitudes.php?ajax=reasignar_gestor', {
                    method: 'POST',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    headers: {'Accept': 'application/json'},
                    body: formulario
                });
                const tipo = respuesta.headers.get('content-type') || '';
                const datos = tipo.includes('application/json')
                    ? await respuesta.json()
                    : {ok: false, mensaje: await respuesta.text()};
                if (!respuesta.ok || !datos.ok) {
                    throw new Error(datos.mensaje || 'No fue posible reasignar el gestor.');
                }

                estado.className = 'manager-assignment-status ok';
                estado.textContent = datos.mensaje || 'Gestor reasignado correctamente.';
                const destino = new URL(window.location.href);
                destino.searchParams.set('id_ticket', String(casoActual.caso.id));
                if (configuracion.seleccionarNodoDespues) {
                    destino.searchParams.set('id_nodo', String(idNodo));
                } else {
                    destino.searchParams.delete('id_nodo');
                }
                window.history.replaceState(
                    {adminTicket: casoActual.caso.id},
                    '',
                    destino
                );
                await abrirCaso(casoActual.caso.id, null, false);
            } catch (error) {
                estado.className = 'manager-assignment-status error';
                estado.textContent = error && error.message
                    ? error.message
                    : 'No fue posible reasignar el gestor.';
                boton.disabled = false;
                selector.disabled = false;
            }
        });

        contenedor.appendChild(bloque);
    }

    function expandirPanelDetalle() {
        contenidoModal.classList.remove('detail-collapsed');
    }

    function contraerPanelDetalle() {
        contenidoModal.classList.add('detail-collapsed');
        const panel = contenidoModal.querySelector('.detail-panel');
        if (panel) panel.classList.remove('open');
    }

    function prepararPanelLateral(titulo, referencia, secciones) {
        expandirPanelDetalle();
        const panel = contenidoModal.querySelector('.detail-panel');
        panel.replaceChildren();

        const cabecera = crearElemento('div', 'section-head');
        const copia = crearElemento('div', 'detail-head-copy');
        copia.appendChild(crearElemento('h3', '', titulo));
        copia.appendChild(crearElemento('span', '', referencia));
        cabecera.appendChild(copia);
        const cerrarPanel = crearElemento('button', 'drawer-close', '×');
        cerrarPanel.type = 'button';
        cerrarPanel.setAttribute('aria-label', 'Minimizar información y ampliar el árbol del caso');
        cerrarPanel.title = 'Minimizar información y ampliar el árbol';
        cerrarPanel.addEventListener('click', function () {
            contraerPanelDetalle();
        });
        cabecera.appendChild(cerrarPanel);
        panel.appendChild(cabecera);

        const tabs = crearElemento('nav', 'detail-tabs');
        tabs.setAttribute('aria-label', 'Detalle del elemento seleccionado');
        const vistas = crearElemento('div', 'detail-views');
        secciones.forEach(function (seccion, indice) {
            const tab = crearElemento('button', 'detail-tab' + (indice === 0 ? ' active' : ''), seccion.titulo);
            tab.type = 'button';
            tab.setAttribute('aria-selected', indice === 0 ? 'true' : 'false');
            const vista = crearElemento('section', 'detail-view');
            vista.hidden = indice !== 0;
            seccion.render(vista);
            tab.addEventListener('click', function () {
                Array.from(tabs.children).forEach(function (item) {
                    item.classList.remove('active');
                    item.setAttribute('aria-selected', 'false');
                });
                Array.from(vistas.children).forEach(function (item) { item.hidden = true; });
                tab.classList.add('active');
                tab.setAttribute('aria-selected', 'true');
                vista.hidden = false;
                panel.scrollTop = 0;
            });
            tabs.appendChild(tab);
            vistas.appendChild(vista);
        });
        panel.appendChild(tabs);
        panel.appendChild(vistas);
        panel.classList.add('open');
        cerrarPanel.focus({preventScroll:true});

        return panel;
    }

    function renderizarConversacion(vista, nodo) {
        const mensajes = Array.isArray(nodo.conversacion) ? nodo.conversacion : [];
        const stream = crearElemento('div', 'conversation-stream');
        if (!mensajes.length) {
            stream.appendChild(crearElemento('div', 'empty', 'No hay mensajes registrados para este elemento.'));
        }
        mensajes.forEach(function (mensaje) {
            const item = crearElemento('article', 'conversation-message');
            item.appendChild(crearElemento('strong', '', mensaje.emisor || 'Usuario eliminado'));
            item.appendChild(crearElemento('p', '', mensaje.mensaje || ''));
            item.appendChild(crearElemento('div', 'event-meta', formatearFecha(mensaje.creado_en)));
            stream.appendChild(item);
        });
        vista.appendChild(stream);
    }

    function renderizarArchivos(vista, nodo) {
        const archivos = Array.isArray(nodo.archivos) ? nodo.archivos : [];
        const lista = crearElemento('div', 'node-files');
        if (!archivos.length) {
            lista.appendChild(crearElemento('div', 'empty', 'No hay archivos adjuntos para este elemento.'));
        }
        archivos.forEach(function (archivo) {
            const item = crearElemento('div', 'node-file');
            item.appendChild(crearElemento('span', '', archivo.nombre_original || 'Archivo adjunto'));
            const enlace = crearElemento('a', '', 'Descargar');
            enlace.href = 'descargarAdjunto.php?id=' + encodeURIComponent(archivo.id_adjunto);
            enlace.target = '_blank';
            enlace.rel = 'noopener';
            item.appendChild(enlace);
            lista.appendChild(item);
        });
        vista.appendChild(lista);
    }

    function origenNodo(nodo) {
        return {
            clave: String(nodo.id),
            etiqueta: nodo.tipo === 'hijo' ? 'Derivación ' + nodo.codigo : 'Etapa ' + nodo.codigo
        };
    }

    function consolidarPorNodo(nodos) {
        const salida = {conversacion: [], archivos: [], historico: [], origenes: []};
        nodos.forEach(function (nodo) {
            const origen = origenNodo(nodo);
            salida.origenes.push(origen);
            ['conversacion', 'archivos', 'historico'].forEach(function (grupo) {
                (nodo[grupo] || []).forEach(function (registro) {
                    salida[grupo].push(Object.assign({}, registro, {
                        _origen_clave: origen.clave,
                        _origen_etiqueta: origen.etiqueta
                    }));
                });
            });
        });
        return salida;
    }

    function renderizarConFiltro(vista, consolidado, grupo, renderizador) {
        const barra = crearElemento('div', 'detail-filter');
        const idFiltro = 'filtro-' + grupo + '-' + Math.random().toString(36).slice(2);
        const etiqueta = crearElemento('label', '', 'Filtrar por origen');
        etiqueta.htmlFor = idFiltro;
        const selector = document.createElement('select');
        selector.id = idFiltro;
        const todos = document.createElement('option');
        todos.value = '';
        todos.textContent = 'Todas las etapas y derivaciones';
        selector.appendChild(todos);
        (consolidado.origenes || []).forEach(function (origen) {
            const opcion = document.createElement('option');
            opcion.value = origen.clave;
            opcion.textContent = origen.etiqueta;
            selector.appendChild(opcion);
        });
        barra.appendChild(etiqueta);
        barra.appendChild(selector);
        vista.appendChild(barra);
        const resultados = crearElemento('div', 'filtered-results');
        vista.appendChild(resultados);
        const pintar = function () {
            resultados.replaceChildren();
            const registros = (consolidado[grupo] || []).filter(function (registro) {
                return selector.value === '' || registro._origen_clave === selector.value;
            });
            renderizador(resultados, {[grupo]: registros});
        };
        selector.addEventListener('change', pintar);
        pintar();
    }

    function renderizarHistorico(vista, nodo) {
        const eventos = Array.isArray(nodo.historico) ? nodo.historico : [];
        const stream = crearElemento('div', 'history-stream');
        if (!eventos.length) {
            stream.appendChild(crearElemento('div', 'empty', 'No hay eventos registrados para este elemento.'));
        }
        eventos.forEach(function (evento) {
            const item = crearElemento('article', 'history-event');
            item.appendChild(crearElemento('span', 'history-detail-label', 'Modificación realizada'));
            item.appendChild(crearElemento('strong', 'history-action', evento.accion || 'Actividad registrada'));

            const detalle = crearElemento('div', 'history-detail');
            detalle.appendChild(crearElemento('span', 'history-detail-label', 'Detalle del cambio'));
            detalle.appendChild(crearElemento('p', '', evento.detalle || 'No se registró información adicional.'));
            item.appendChild(detalle);

            const metadata = crearElemento('div', 'history-meta-grid');
            const autor = crearElemento('div', 'history-meta-item');
            autor.appendChild(crearElemento('span', '', 'Generado por'));
            autor.appendChild(crearElemento('strong', '', evento.usuario || 'Sistema'));
            metadata.appendChild(autor);

            const fecha = crearElemento('div', 'history-meta-item');
            fecha.appendChild(crearElemento('span', '', 'Fecha y hora'));
            fecha.appendChild(crearElemento('strong', '', formatearFecha(evento.creado_en)));
            metadata.appendChild(fecha);
            item.appendChild(metadata);
            stream.appendChild(item);
        });
        vista.appendChild(stream);
    }

    function renderizarDetalleCaso(caso) {
        const nodosCaso = casoActual && Array.isArray(casoActual.nodos) ? casoActual.nodos : [];
        const consolidadoCaso = consolidarPorNodo(nodosCaso);
        prepararPanelLateral('Información del caso', 'Caso ' + caso.id, [
            {
                titulo: 'Información',
                render: function (vista) {
                const contenido = crearElemento('div', 'detail-content');
                const hero = crearElemento('div', 'detail-hero');
                hero.appendChild(crearElemento('small', '', 'Caso ' + caso.id));
                hero.appendChild(crearElemento('h4', '', caso.titulo || 'Sin asunto'));
                hero.appendChild(crearElemento('p', '', caso.descripcion || 'Sin descripción'));
                contenido.appendChild(hero);
                const grid = crearElemento('div', 'detail-grid');
                agregarTarjeta(grid, 'Solicitante', caso.solicitante);
                agregarTarjeta(grid, 'Estado general', etiquetaEstado(caso.estado));
                agregarTarjeta(grid, 'Flujo', caso.flujo);
                agregarTarjeta(grid, 'Creado', formatearFecha(caso.fecha_creacion));
                agregarTarjeta(grid, 'Etapas oficiales', caso.total_etapas);
                agregarTarjeta(grid, 'Casos hijos', caso.total_hijos);
                agregarTarjeta(grid, 'Última actualización', formatearFecha(caso.actualizado_en), true);
                contenido.appendChild(grid);
                const nodoActual = nodosCaso.find(function (nodo) {
                    return Number(nodo.id) === Number(caso.id_etapa_actual);
                });
                crearControlReasignacion(contenido, {
                    titulo: 'Reasignar gestor del caso actual',
                    referencia: 'la etapa actual del caso ' + caso.id,
                    idNodo: caso.id_etapa_actual,
                    idGestorActual: nodoActual?.id_gestor || 0,
                    seleccionarNodoDespues: false
                });
                vista.appendChild(contenido);
                }
            },
            {
                titulo: 'Conversación (' + consolidadoCaso.conversacion.length + ')',
                render: function (vista) {
                    renderizarConFiltro(vista, consolidadoCaso, 'conversacion', renderizarConversacion);
                }
            },
            {
                titulo: 'Archivos (' + consolidadoCaso.archivos.length + ')',
                render: function (vista) {
                    renderizarConFiltro(vista, consolidadoCaso, 'archivos', renderizarArchivos);
                }
            },
            {
                titulo: 'Histórico (' + consolidadoCaso.historico.length + ')',
                render: function (vista) {
                    renderizarConFiltro(vista, consolidadoCaso, 'historico', renderizarHistorico);
                }
            }
        ]);
    }

    function renderizarDetalleNodo(nodo) {
        const esHijo = nodo.tipo === 'hijo';
        const referencia = esHijo ? 'Derivación ' + nodo.codigo : 'Etapa ' + nodo.codigo;
        const fuente = nodo;
        prepararPanelLateral(
            esHijo ? 'Información de la derivación' : 'Información de la etapa',
            referencia,
            [
                {
                    titulo: 'Información',
                    render: function (vista) {
                        const contenido = crearElemento('div', 'detail-content');
                        const caso = casoActual?.caso || {};
                        const contexto = crearElemento('section', 'request-context');
                        const asunto = crearElemento('div', 'request-context-item');
                        asunto.appendChild(crearElemento('span', '', 'Asunto de la solicitud'));
                        asunto.appendChild(crearElemento('strong', '', caso.titulo || 'Sin asunto'));
                        contexto.appendChild(asunto);
                        const descripcion = crearElemento('div', 'request-context-item');
                        descripcion.appendChild(crearElemento('span', '', 'Descripción original'));
                        descripcion.appendChild(crearElemento('p', '', caso.descripcion || 'Sin descripción registrada'));
                        contexto.appendChild(descripcion);
                        contenido.appendChild(contexto);

                        const hero = crearElemento('div', 'detail-hero');
                        hero.appendChild(crearElemento('small', '', referencia));
                        hero.appendChild(crearElemento('h4', '', (nodo.catalogo || 'Área') + ' / ' + (nodo.servicio || 'Servicio')));
                        hero.appendChild(crearElemento('p', '', etiquetaEstado(nodo.estado) + (nodo.es_actual ? ' · Etapa actual' : '')));
                        contenido.appendChild(hero);
                        const grid = crearElemento('div', 'detail-grid');
                        agregarTarjeta(grid, 'Gestor a cargo', nodo.gestor);
                        agregarTarjeta(grid, 'Creador', nodo.creador);
                        agregarTarjeta(grid, 'SLA configurado', (nodo.sla_nombre || 'Sin SLA') + (nodo.sla_tiempo ? ' · ' + nodo.sla_tiempo + ' ' + nodo.sla_unidad : ''));
                        agregarTarjeta(grid, 'Estado del SLA', estadoSla(nodo.resultado_sla !== 'sin_iniciar' ? nodo.resultado_sla : nodo.sla_estado));
                        agregarTarjeta(grid, 'Activación', formatearFecha(nodo.fecha_activacion));
                        agregarTarjeta(grid, 'Vencimiento', formatearFecha(nodo.fecha_vencimiento));
                        agregarTarjeta(grid, 'Marcado listo', formatearFecha(nodo.fecha_listo));
                        agregarTarjeta(grid, 'Tiempo de solución', formatearTiempo(nodo.minutos_solucion));
                        agregarTarjeta(grid, 'Finalización', formatearFecha(nodo.fecha_finalizacion));
                        agregarTarjeta(grid, 'Reaperturas', nodo.reaperturas);
                        if (esHijo || nodo.motivo_derivacion) agregarTarjeta(grid, 'Motivo de derivación', nodo.motivo_derivacion || 'Sin motivo registrado', true, true);
                        agregarTarjeta(grid, 'Solución', nodo.solucion || 'Sin solución registrada', true, true);
                        agregarTarjeta(grid, 'Observación de cierre', nodo.observacion || 'Sin observación registrada', true, true);
                        contenido.appendChild(grid);
                        crearControlReasignacion(contenido, {
                            titulo: esHijo ? 'Reasignar gestor de esta derivación' : 'Reasignar gestor de esta etapa',
                            referencia: (esHijo ? 'la derivación ' : 'la etapa ') + nodo.codigo,
                            idNodo: nodo.id,
                            idGestorActual: nodo.id_gestor,
                            seleccionarNodoDespues: true
                        });
                        vista.appendChild(contenido);
                    }
                },
                {
                    titulo: 'Conversación (' + (fuente.conversacion || []).length + ')',
                    render: function (vista) {
                        renderizarConversacion(vista, fuente);
                    }
                },
                {
                    titulo: 'Archivos (' + (fuente.archivos || []).length + ')',
                    render: function (vista) {
                        renderizarArchivos(vista, fuente);
                    }
                },
                {
                    titulo: 'Histórico (' + (fuente.historico || []).length + ')',
                    render: function (vista) {
                        renderizarHistorico(vista, fuente);
                    }
                }
            ]
        );
    }

    function crearBotonNodo(nodo, seleccionar) {
        const boton = crearElemento('button', 'tree-node');
        boton.type = 'button';
        boton.dataset.nodeId = String(nodo.id);
        boton.appendChild(crearElemento('span', 'node-code', nodo.tipo === 'hijo' ? 'Derivación ' + nodo.codigo : 'Etapa ' + nodo.codigo));

        const copia = crearElemento('span', 'node-copy');
        copia.appendChild(crearElemento('strong', '', (nodo.catalogo || 'Área') + ' / ' + (nodo.servicio || 'Servicio')));
        copia.appendChild(crearElemento('span', '', (nodo.gestor || 'Sin asignar') + ' · ' + etiquetaEstado(nodo.estado)));
        boton.appendChild(copia);

        if (nodo.es_actual) {
            boton.appendChild(crearElemento('span', 'current-mark', 'Actual'));
        } else {
            boton.appendChild(crearElemento('span', 'status ' + claseEstado(nodo.estado), etiquetaEstado(nodo.estado)));
        }
        boton.addEventListener('click', function () { seleccionar(nodo, boton); });
        return boton;
    }

    function renderizarArbol(datos) {
        casoActual = datos;
        expandirPanelDetalle();
        tituloModal.textContent = 'Caso ' + datos.caso.id + ' · trazabilidad';
        subtituloModal.textContent = 'Seleccione el caso, una etapa o una derivación para abrir su información, conversación e histórico.';
        resumenModal.hidden = false;
        resumenModal.replaceChildren();

        const principal = crearElemento('div', 'summary-main');
        principal.appendChild(crearElemento('span', '', 'Asunto'));
        principal.appendChild(crearElemento('strong', '', datos.caso.titulo || 'Sin asunto'));
        resumenModal.appendChild(principal);
        [
            ['Solicitante', datos.caso.solicitante],
            ['Estado', etiquetaEstado(datos.caso.estado)],
            [datos.caso.proyeccion_finalizacion?.estado === 'finalizado' ? 'Finalización real' : 'Finalización prevista', formatearFecha(datos.caso.proyeccion_finalizacion?.fecha)],
            ['Etapas', datos.caso.total_etapas],
            ['Casos hijos', datos.caso.total_hijos]
        ].forEach(function (item) {
            const bloque = crearElemento('div', 'summary-stat');
            bloque.appendChild(crearElemento('span', '', item[0]));
            bloque.appendChild(crearElemento('strong', '', item[1]));
            resumenModal.appendChild(bloque);
        });

        const descripcionSolicitud = crearElemento('div', 'summary-description');
        descripcionSolicitud.appendChild(crearElemento('span', '', 'Descripción de la solicitud'));
        descripcionSolicitud.appendChild(crearElemento('p', '', datos.caso.descripcion || 'Sin descripción registrada'));
        resumenModal.appendChild(descripcionSolicitud);

        contenidoModal.replaceChildren();
        const panelArbol = crearElemento('section', 'tree-panel');
        const headArbol = crearElemento('div', 'section-head');
        headArbol.appendChild(crearElemento('h3', '', 'Árbol del caso'));
        headArbol.appendChild(crearElemento('span', '', datos.nodos.length + ' nodo' + (datos.nodos.length === 1 ? '' : 's')));
        panelArbol.appendChild(headArbol);
        const arbol = crearElemento('div', 'tree-content');
        panelArbol.appendChild(arbol);
        contenidoModal.appendChild(panelArbol);
        contenidoModal.appendChild(crearElemento('section', 'detail-panel'));

        const botones = [];
        function seleccionarNodo(nodo, boton) {
            expandirPanelDetalle();
            botones.forEach(function (elemento) { elemento.classList.remove('selected'); });
            boton.classList.add('selected');
            renderizarDetalleNodo(nodo);
        }

        const raiz = crearElemento('button', 'tree-root');
        raiz.type = 'button';
        raiz.appendChild(crearElemento('span', 'node-code', 'Caso ' + datos.caso.id));
        const copiaRaiz = crearElemento('span', 'node-copy');
        copiaRaiz.appendChild(crearElemento('strong', '', datos.caso.titulo || 'Sin asunto'));
        copiaRaiz.appendChild(crearElemento('span', '', datos.caso.solicitante + ' · ' + etiquetaEstado(datos.caso.estado)));
        raiz.appendChild(copiaRaiz);
        raiz.appendChild(crearElemento('span', 'status ' + claseEstado(datos.caso.estado), etiquetaEstado(datos.caso.estado)));
        raiz.addEventListener('click', function () {
            expandirPanelDetalle();
            botones.forEach(function (elemento) { elemento.classList.remove('selected'); });
            raiz.classList.add('selected');
            renderizarDetalleCaso(datos.caso);
        });
        botones.push(raiz);
        arbol.appendChild(raiz);

        const porPadre = new Map();
        datos.nodos.forEach(function (nodo) {
            const padre = Number(nodo.padre_id) || 0;
            if (!porPadre.has(padre)) porPadre.set(padre, []);
            porPadre.get(padre).push(nodo);
        });

        function agregarRamas(idPadre, contenedor) {
            const hijos = porPadre.get(idPadre) || [];
            hijos.forEach(function (nodo) {
                const rama = crearElemento('div', 'tree-branch');
                const boton = crearBotonNodo(nodo, seleccionarNodo);
                botones.push(boton);
                rama.appendChild(boton);
                const descendientes = porPadre.get(Number(nodo.id)) || [];
                if (descendientes.length) {
                    const hijosContenedor = crearElemento('div', 'tree-children');
                    agregarRamas(Number(nodo.id), hijosContenedor);
                    rama.appendChild(hijosContenedor);
                }
                contenedor.appendChild(rama);
            });
        }

        const ramasRaiz = crearElemento('div', 'tree-children');
        agregarRamas(0, ramasRaiz);
        if (ramasRaiz.children.length) arbol.appendChild(ramasRaiz);
        else arbol.appendChild(crearElemento('div', 'empty', 'Este caso todavía no tiene etapas registradas.'));

        const nodoSolicitado = Number(new URL(window.location.href).searchParams.get('id_nodo')) || 0;
        const botonSolicitado = nodoSolicitado > 0
            ? arbol.querySelector('[data-node-id="' + nodoSolicitado + '"]')
            : null;
        if (botonSolicitado) {
            botonSolicitado.click();
        } else {
            raiz.classList.add('selected');
            renderizarDetalleCaso(datos.caso);
        }
    }

    function mostrarError(mensaje) {
        resumenModal.hidden = true;
        contenidoModal.replaceChildren();
        const panel = crearElemento('div', 'tree-panel error-state', mensaje || 'No fue posible cargar el caso.');
        contenidoModal.appendChild(panel);
        contenidoModal.appendChild(crearElemento('div', 'detail-panel error-state', 'Cierre la ventana e inténtelo nuevamente.'));
    }

    async function abrirCaso(idTicket, origen, actualizarDireccion) {
        if (!modal || !idTicket) return;
        botonOrigen = origen || document.activeElement;
        modal.hidden = false;
        modal.classList.add('open');
        document.body.classList.add('modal-caso-abierto');
        if (actualizarDireccion !== false) {
            const destino = new URL(window.location.href);
            destino.searchParams.set('id_ticket', String(idTicket));
            destino.searchParams.delete('id_nodo');
            window.history.pushState({adminTicket: idTicket}, '', destino);
        }
        tituloModal.textContent = 'Caso ' + idTicket + ' · trazabilidad';
        subtituloModal.textContent = 'Cargando el árbol del caso…';
        resumenModal.hidden = true;
        expandirPanelDetalle();
        contenidoModal.innerHTML = '<div class="tree-panel"><div class="loading-state"><div><div class="loading-ring"></div>Cargando trazabilidad…</div></div></div><div class="detail-panel"><div class="loading-state">Preparando información…</div></div>';
        window.scrollTo({top: 0, behavior: 'auto'});

        if (controladorPeticion) controladorPeticion.abort();
        controladorPeticion = new AbortController();

        try {
            const respuesta = await fetch(
                'solicitudes.php?ajax=arbol&id_ticket=' + encodeURIComponent(idTicket),
                {
                    credentials: 'same-origin',
                    cache: 'no-store',
                    headers: { 'Accept': 'application/json' },
                    signal: controladorPeticion.signal
                }
            );
            const datos = await respuesta.json();
            if (!respuesta.ok || !datos.ok) {
                throw new Error(datos.mensaje || 'No fue posible cargar el caso.');
            }
            renderizarArbol(datos);
        } catch (error) {
            if (error && error.name === 'AbortError') return;
            subtituloModal.textContent = 'No fue posible cargar la trazabilidad.';
            mostrarError(error && error.message ? error.message : 'No fue posible cargar el caso.');
        }
    }

    function cerrarCaso(actualizarDireccion) {
        if (!modal || !modal.classList.contains('open')) return;
        if (controladorPeticion) controladorPeticion.abort();
        modal.classList.remove('open');
        modal.hidden = true;
        document.body.classList.remove('modal-caso-abierto');
        resumenModal.hidden = true;
        casoActual = null;
        if (actualizarDireccion !== false) {
            const destino = new URL(window.location.href);
            destino.searchParams.delete('id_ticket');
            destino.searchParams.delete('id_nodo');
            window.history.pushState({adminTicket: null}, '', destino);
        }
        window.scrollTo({top: 0, behavior: 'auto'});
        if (botonOrigen && typeof botonOrigen.focus === 'function') botonOrigen.focus();
    }

    document.querySelectorAll('[data-open-case]').forEach(function (boton) {
        boton.addEventListener('click', function () {
            abrirCaso(Number(boton.dataset.openCase), boton, true);
        });
    });
    if (cerrar) cerrar.addEventListener('click', cerrarCaso);
    document.addEventListener('keydown', function (evento) {
        if (evento.key === 'Escape' && modal && modal.classList.contains('open')) {
            cerrarCaso();
        }
    });

    window.addEventListener('popstate', function () {
        const idTicket = Number(new URL(window.location.href).searchParams.get('id_ticket')) || 0;
        if (idTicket > 0) {
            abrirCaso(idTicket, null, false);
        } else {
            cerrarCaso(false);
        }
    });

    const ticketInicial = Number(new URL(window.location.href).searchParams.get('id_ticket')) || 0;
    if (ticketInicial > 0) {
        abrirCaso(ticketInicial, null, false);
    }
}());
</script>
<script src="assets/js/controlSesion.js" defer></script>
</body>
</html>
