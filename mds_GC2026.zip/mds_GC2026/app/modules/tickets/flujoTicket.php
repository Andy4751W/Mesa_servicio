<?php
declare(strict_types=1);

if (!function_exists('compatStrStartsWith')) {
    function compatStrStartsWith($haystack, $needle): bool {
        return $needle === '' || strpos((string)$haystack, (string)$needle) === 0;
    }
}

if (!function_exists('compatStrContains')) {
    function compatStrContains($haystack, $needle): bool {
        return strpos((string)$haystack, (string)$needle) !== false;
    }
}

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

// Los includes anteriores deben dejar disponible la conexión MySQLi usada por este módulo.
// La validación explícita también permite que Intelephense conozca el tipo de $conn.
if (!isset($conn) || !($conn instanceof \mysqli)) {
    throw new RuntimeException('No se pudo inicializar la conexión a la base de datos.');
}

/** @var \mysqli $conn */

$rol = (int) ($_SESSION['rol'] ?? 0);
$esConsultaGlobal = seguridadEsConsultaGlobal();
$esUsuarioPrueba = seguridadEsUsuarioPrueba();
$metodoFlujo = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$esConsultaGlobalSoloLectura = $esConsultaGlobal && $metodoFlujo === 'GET';
$idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
$nombreUsuario = trim((string) ($_SESSION['usuario'] ?? 'Usuario'));
$idPaisOperacion = paisExigirContexto();
camposExtrasPrepararEsquema($conn);
camposExtrasSembrarCatalogo($conn, $idPaisOperacion);
$rutaBaseTickets = (
    $rol === 1
    && basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')) === 'solicitudes.php'
) ? 'solicitudes.php' : 'flujoTicket.php';

if (
    $esConsultaGlobal
    && $metodoFlujo === 'POST'
    && !seguridadConsultaGlobalPuedeEscribirComoPruebaGestor()
) {
    seguridadRechazarSoloLectura();
}

if ($esConsultaGlobalSoloLectura && !in_array($rol, [1, 2], true)) {
    // El visor global utiliza la vista administrativa de casos, que no limita
    // los resultados al gestor o usuario autenticado.
    $rol = 1;
}

if (!in_array($rol, [1, 2], true)) {
    http_response_code(403);
    exit('Acceso denegado.');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/** @param $valor */
function escaparFlujo($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function rolChatFlujo(int $rolUsuario): string
{
    return (fn ($__mesaMatchValue21) => (($__mesaMatchValue21 === (1)) ? ('Administrador') : ((($__mesaMatchValue21 === (2)) ? ('Gestor') : ((($__mesaMatchValue21 === (3)) ? ('Solicitante') : ('Usuario')))))))($rolUsuario);
}

function fechaFlujo(?string $fecha): string
{
    if (!$fecha) {
        return 'Pendiente';
    }

    $marca = strtotime($fecha);

    return $marca ? date('d/m/Y H:i', $marca) : $fecha;
}

/** @param $minutos */
function tiempoFlujo($minutos): string
{
    if ($minutos === null || $minutos === '') {
        return 'Sin dato';
    }

    $total = max(0, (int) $minutos);
    global $conn;
    $minutosDia = isset($conn) && $conn instanceof mysqli
        ? calendarioMinutosDiaSla($conn)
        : (defined('CALENDARIO_MINUTOS_DIA_SLA')
            ? max(1, (int) CALENDARIO_MINUTOS_DIA_SLA)
            : 600);
    $dias = intdiv($total, $minutosDia);
    $horas = intdiv($total % $minutosDia, 60);
    $resto = $total % 60;

    if ($dias > 0) {
        return $dias . ' día(s) hábil(es) ' . $horas . ' h ' . $resto . ' min';
    }

    if ($horas > 0) {
        return $horas . ' h ' . $resto . ' min';
    }

    return $resto . ' min';
}

/**
 * @param array<int, array<string, mixed>> $nodos
 * @return array<int, array<string, mixed>>
 */
function ordenarArbolCasos(array $nodos, int $idCasoPrincipal): array
{
    $porPadre = [];
    $ids = [];

    foreach ($nodos as $nodo) {
        $id = (int) $nodo['id_ticket_etapa'];
        $padre = (int) ($nodo['id_ticket_etapa_padre'] ?? 0);
        $ids[$id] = true;
        $porPadre[$padre][] = $nodo;
    }

    foreach ($porPadre as &$grupo) {
        usort(
            $grupo,
            static fn (array $a, array $b): int =>
            [(int) $a['orden'], (int) $a['id_ticket_etapa']]
            <=> [(int) $b['orden'], (int) $b['id_ticket_etapa']]
        );
    }
    unset($grupo);

    $ordenados = [];
    $visitados = [];

    $recorrer = static function (
        int $idPadre,
        int $nivel,
        int $numeroEtapa = 0,
        string $codigoTicketPadre = ''
    ) use (
        &$recorrer,
        &$ordenados,
        &$visitados,
        $porPadre,
        $idCasoPrincipal
    ): void {
        foreach ($porPadre[$idPadre] ?? [] as $indice => $nodo) {
            $id = (int) $nodo['id_ticket_etapa'];
            if (isset($visitados[$id])) {
                continue;
            }

            $visitados[$id] = true;
            $nodo['nivel_visual'] = $nivel;

            $esEtapaOficial = $idPadre === 0;
            $etapaNodo = $esEtapaOficial ? $indice + 1 : $numeroEtapa;
            $codigoTicket = $esEtapaOficial
                ? (string) $etapaNodo
                : $codigoTicketPadre . '.' . ($indice + 1);

            $nodo['es_etapa_oficial'] = $esEtapaOficial;
            $nodo['es_derivacion'] = !$esEtapaOficial;
            $nodo['numero_etapa'] = $etapaNodo;
            $nodo['codigo_caso'] = (string) $idCasoPrincipal;
            $nodo['codigo_ticket'] = $codigoTicket;

            $ordenados[] = $nodo;

            $recorrer(
                $id,
                $nivel + 1,
                $etapaNodo,
                $codigoTicket
            );
        }
    };

    $recorrer(0, 0, 0, '');

    // Registros antiguos sin relación padre
    foreach ($nodos as $nodo) {
        $id = (int) $nodo['id_ticket_etapa'];
        if (!isset($visitados[$id])) {
            $nodo['nivel_visual'] = max(0, (int) ($nodo['nivel'] ?? 0));
            $esDerivacion = (int) ($nodo['id_ticket_etapa_padre'] ?? 0) > 0;
            $nodo['es_etapa_oficial'] = !$esDerivacion;
            $nodo['es_derivacion'] = $esDerivacion;
            $nodo['numero_etapa'] = max(1, (int) ($nodo['orden'] ?? 1));
            $nodo['codigo_caso'] = (string) $idCasoPrincipal;
            $nodo['codigo_ticket'] = $esDerivacion
                ? (string) $id
                : (string) $nodo['numero_etapa'];

            $ordenados[] = $nodo;
        }
    }

    return $ordenados;
}

function urlTicketFlujo(
    string $rutaBase,
    int $rol,
    int $idTicket,
    int $idNodo = 0
): string
{
    $parametros = ['id_ticket' => $idTicket];
    if ($idNodo > 0) {
        $parametros['id_nodo'] = $idNodo;
    }

    if ($rol === 2) {
        $bandeja = isset($GLOBALS['bandejaGestor'])
            ? (string) $GLOBALS['bandejaGestor']
            : (string) ($_GET['bandeja'] ?? 'abiertos');
        $parametros['modo'] = 'mis_tickets';
        $parametros['bandeja'] = in_array($bandeja, ['abiertos', 'derivaciones', 'pendientes', 'cerrados', 'derivaciones_cerradas'], true)
            ? $bandeja
            : 'abiertos';
        if ($idNodo > 0) {
            $parametros['vista'] = 'gestion';
        }

        $busqueda = trim((string) ($_GET['buscar'] ?? ''));
        $estadoBusqueda = trim((string) ($_GET['estado_busqueda'] ?? 'todos'));

        if ($busqueda !== '') {
            $parametros['buscar'] = substr($busqueda, 0, 120);
        }
        if ($estadoBusqueda !== '' && $estadoBusqueda !== 'todos') {
            $parametros['estado_busqueda'] = substr($estadoBusqueda, 0, 60);
        }
    }

    return $rutaBase . '?' . http_build_query($parametros);
}

function textoEstadoCaso(string $estado): string
{
    return (fn ($__mesaMatchValue22) => (($__mesaMatchValue22 === ('en_proceso')) ? ('En proceso') : ((($__mesaMatchValue22 === ('en_espera_solicitante')) ? ('En espera') : ((($__mesaMatchValue22 === ('listo_cierre')) ? ('Listo · pendiente de cierre') : ((($__mesaMatchValue22 === ('completada')) ? ('Completado') : ((($__mesaMatchValue22 === ('cancelada')) ? ('Cancelado') : ((($__mesaMatchValue22 === ('bloqueada')) ? ('Bloqueado') : ((($__mesaMatchValue22 === ('pausada')) ? ('Pausado') : ((($__mesaMatchValue22 === ('pendiente')) ? ('Pendiente') : (ucfirst(str_replace('_', ' ', $estado)))))))))))))))))))($estado);
}

function textoEstadoTicket(string $estado): string
{
    return (fn ($__mesaMatchValue23) => (($__mesaMatchValue23 === ('en_proceso')) ? ('En proceso') : ((($__mesaMatchValue23 === ('pendiente_calificacion')) ? ('Pendiente de calificación') : ((($__mesaMatchValue23 === ('cerrado')) ? ('Cerrado definitivamente') : ((($__mesaMatchValue23 === ('cancelado') || $__mesaMatchValue23 === ('cancelada')) ? ('Cancelado') : (ucfirst(str_replace('_', ' ', $estado)))))))))))($estado);
}

/**
 * @param array<int, array<int, array<string, mixed>>> $hijosPorPadre
 */
function contarDescendientesCaso(int $idPadre, array $hijosPorPadre): int
{
    $total = 0;

    foreach ($hijosPorPadre[$idPadre] ?? [] as $hijo) {
        $idHijo = (int) $hijo['id_ticket_etapa'];
        $total += 1 + contarDescendientesCaso($idHijo, $hijosPorPadre);
    }

    return $total;
}

/**
 * Renderiza una rama compacta. El <details> pertenece al caso padre, por lo
 * que al contraerlo solo desaparecen sus descendientes y el padre permanece.
 *
 * @param array<string, mixed> $nodo
 * @param array<int, array<int, array<string, mixed>>> $hijosPorPadre
 * @param array<int, bool> $rutaSeleccionada
 */
function renderizarRamaCasos(
    array $nodo,
    array $hijosPorPadre,
    string $rutaBase,
    int $idTicket,
    int $idSeleccionado,
    array $rutaSeleccionada
): void {

    $idNodo = (int) $nodo['id_ticket_etapa'];
    $idNodoDestino = (int) ($nodo['id_nodo_destino'] ?? $idNodo);

    $hijos = $hijosPorPadre[$idNodo] ?? [];
    $totalHijos = count($hijos);
    $totalDescendientes = contarDescendientesCaso($idNodo, $hijosPorPadre);

    $codigoCaso = (string) ($nodo['codigo_caso'] ?? $idTicket);
    $codigoTicket = (string) ($nodo['codigo_ticket'] ?? '');
    $esCasoPrincipal = !empty($nodo['es_caso_principal']);
    $esDerivacion = !$esCasoPrincipal && !empty($nodo['es_derivacion']);
    $numeroEtapa = max(1, (int) ($nodo['numero_etapa'] ?? 1));
    $totalEtapas = max($numeroEtapa, (int) ($nodo['total_etapas'] ?? $numeroEtapa));
    $estado = (string) ($nodo['estado'] ?? 'pendiente');
    $estadoClase = preg_replace('/[^a-z0-9_-]/', '', strtolower($estado)) ?: 'pendiente';
    $esSeleccionado = $idSeleccionado === $idNodoDestino;
    $ramaActiva = $esCasoPrincipal ? !empty($rutaSeleccionada) : isset($rutaSeleccionada[$idNodo]);
    $rolActual = (int) ($GLOBALS['rol'] ?? 0);
    $solucionNodo = trim((string) ($nodo['solucion_nombre'] ?? ''));
    $detalleSolucionNodo = trim((string) ($nodo['comentario_cierre'] ?? ''));
    $casoCerradoGlobal = !empty($GLOBALS['casoSeleccionadoCerrado']);
    $referenciaElementoSolucion = $esCasoPrincipal
        ? 'Caso ' . $codigoCaso
        : ($esDerivacion ? 'Ticket ' . $codigoTicket : 'Etapa ' . $numeroEtapa);
    $contextoElementoSolucion = $esCasoPrincipal
        ? 'Caso ' . $codigoCaso . ' · Etapa ' . $numeroEtapa . ' de ' . $totalEtapas
        : ($esDerivacion
            ? 'Caso ' . $codigoCaso . ' · Etapa ' . $numeroEtapa . ' · Derivación ' . $codigoTicket
            : 'Caso ' . $codigoCaso . ' · Etapa ' . $numeroEtapa . ' de ' . $totalEtapas);

    $urlNodo = urlTicketFlujo(
        $rutaBase,
        $rolActual,
        $idTicket,
        $idNodoDestino
    ) . '&' . http_build_query(['id_chat' => $idNodoDestino]);

    $momentoSla = (fn ($__mesaMatchValue24) => (
        ($__mesaMatchValue24 === ('pausada')) ? ('Pausado desde ' . fechaFlujo($nodo['fecha_pausa'] ?? null)) :
        (($__mesaMatchValue24 === ('listo_cierre')) ? ('Listo desde ' . fechaFlujo($nodo['fecha_marcado_listo'] ?? null)
            . ' · vencimiento visible ' . fechaFlujo($nodo['fecha_vencimiento'] ?? null)) :
        ('Vence ' . fechaFlujo($nodo['fecha_vencimiento'] ?? null)))
    ))($estado);

    $contenido = static function () use (
        $nodo,
        $codigoCaso,
        $codigoTicket,
        $esCasoPrincipal,
        $esDerivacion,
        $numeroEtapa,
        $totalEtapas,
        $estado,
        $momentoSla,
        $urlNodo,
        $esSeleccionado,
        $totalHijos,
        $solucionNodo,
        $detalleSolucionNodo,
        $referenciaElementoSolucion,
        $contextoElementoSolucion,
        $casoCerradoGlobal
    ): void {

        $esCerrado = in_array($estado, ['completada', 'cancelada'], true);
        $textoBoton = $rolActual === 2
            ? ($esDerivacion ? 'Gestionar derivación' : 'Gestionar etapa')
            : ($esDerivacion ? 'Ver derivación' : 'Ver etapa');
        $ayudaBoton = $rolActual === 2
            ? ($esDerivacion
                ? 'Abre la gestión de esta derivación.'
                : 'Abre la gestión de esta etapa.')
            : ($esDerivacion
                ? 'Abre la ficha de esta derivación en modo consulta.'
                : 'Abre la ficha de esta etapa en modo consulta.');
        ?>
        <div class="case-row-main">
            <div class="case-code-line">
                <span class="case-code"><?= $esDerivacion ? 'Derivación ' . escaparFlujo($codigoTicket) : 'Caso ' . escaparFlujo($codigoCaso) ?></span>
                <span class="case-status <?= escaparFlujo($estado) ?>"><?= escaparFlujo(textoEstadoCaso($estado)) ?></span>
            </div>
            <?php if (!$esDerivacion): ?>
                <span class="case-service">Etapa <?= $numeroEtapa ?> de <?= $totalEtapas ?></span>
            <?php endif; ?>
            <strong class="case-title"><?= escaparFlujo($nodo['catalogo_nombre'] ?? 'Proceso') ?></strong>
            <span class="case-service"><?= escaparFlujo($nodo['servicio_nombre'] ?? 'Servicio') ?></span>
        </div>
        <div class="case-row-meta">
            <span><b>Gestor:</b> <?= escaparFlujo($nodo['gestor_nombre'] ?? 'Pendiente') ?></span>
            <span><b>SLA:</b> <?= escaparFlujo($nodo['sla_nombre'] ?? 'Sin SLA') ?> · <?= escaparFlujo($nodo['estado_sla_actual'] ?? 'pendiente') ?></span>
            <span><?= escaparFlujo($momentoSla ?: 'Vence ' . fechaFlujo($nodo['fecha_vencimiento'] ?? null)) ?></span>

        </div>
        <?php if (!$esSeleccionado && !$esCerrado): ?>
            <a class="btn primary case-open"
               href="<?= escaparFlujo($urlNodo) ?>"
               data-flujo-nav
               title="<?= escaparFlujo($ayudaBoton) ?>"
               aria-label="<?= escaparFlujo($ayudaBoton) ?>"
               aria-current="false">
                <?= $textoBoton ?>
            </a>
        <?php endif; ?>
        <?php if ($casoCerradoGlobal && $esCerrado): ?>
            <button
                class="btn light case-solution-trigger"
                type="button"
                data-case-solution
                data-solution-title="<?= escaparFlujo($referenciaElementoSolucion . ' · ' . ($nodo['catalogo_nombre'] ?? 'Proceso') . ' · ' . ($nodo['servicio_nombre'] ?? 'Servicio')) ?>"
                data-solution-context="<?= escaparFlujo($contextoElementoSolucion) ?>"
                data-solution-name="<?= escaparFlujo($solucionNodo !== '' ? $solucionNodo : 'Sin solución registrada') ?>"
                data-solution-detail="<?= escaparFlujo($detalleSolucionNodo !== '' ? $detalleSolucionNodo : 'El gestor no dejó una descripción adicional.') ?>"
            >Ver solución</button>
        <?php endif; ?>
        <?php
    };

    if ($totalHijos > 0) {
        ?>
        <details class="case-branch <?= escaparFlujo($estadoClase) ?> <?= $esSeleccionado ? 'selected' : '' ?>"
                 data-case-branch
                 data-case-id="<?= $idNodo ?>"
                 <?= $ramaActiva ? 'open data-selected-path="true"' : '' ?>>
            <summary class="case-row">
                <span class="branch-chevron" aria-hidden="true"></span>
                <?php $contenido(); ?>
                <span class="branch-action">
                    <span class="when-open">− Ocultar <?= $totalDescendientes ?> ticket<?= $totalDescendientes === 1 ? '' : 's' ?> derivado<?= $totalDescendientes === 1 ? '' : 's' ?></span>
                    <span class="when-closed">＋ Mostrar <?= $totalDescendientes ?> ticket<?= $totalDescendientes === 1 ? '' : 's' ?> derivado<?= $totalDescendientes === 1 ? '' : 's' ?></span>
                </span>
            </summary>
            <div class="case-children">
                <?php foreach ($hijos as $hijo): ?>
                    <?php renderizarRamaCasos(
                        $hijo,
                        $hijosPorPadre,
                        $rutaBase,
                        $idTicket,
                        $idSeleccionado,
                        $rutaSeleccionada
                    ); ?>
                <?php endforeach; ?>
            </div>
        </details>
        <?php
        return;
    }
    ?>
    <article class="case-leaf <?= escaparFlujo($estadoClase) ?> <?= $esSeleccionado ? 'selected' : '' ?>">
        <div class="case-row">
            <span class="branch-dot" aria-hidden="true"></span>
            <?php $contenido(); ?>
        </div>
    </article>
    <?php
}

function redirigirFlujo(
    string $mensaje,
    int $idTicket = 0,
    int $idNodo = 0,
    int $idChat = 0
): void {
    global $rutaBaseTickets, $rol;
    $parametros = ['msg' => $mensaje];

    if ($rol === 2) {
        $parametros['modo'] = 'mis_tickets';
        $bandeja = isset($GLOBALS['bandejaGestor'])
            ? (string) $GLOBALS['bandejaGestor']
            : (string) ($_GET['bandeja'] ?? 'abiertos');
        $parametros['bandeja'] = in_array($bandeja, ['abiertos', 'derivaciones', 'pendientes', 'cerrados', 'derivaciones_cerradas'], true)
            ? $bandeja
            : 'abiertos';

        $busqueda = trim((string) ($_GET['buscar'] ?? ''));
        $estadoBusqueda = trim((string) ($_GET['estado_busqueda'] ?? 'todos'));

        if ($busqueda !== '') {
            $parametros['buscar'] = substr($busqueda, 0, 120);
        }
        if ($estadoBusqueda !== '' && $estadoBusqueda !== 'todos') {
            $parametros['estado_busqueda'] = substr($estadoBusqueda, 0, 60);
        }
    }

    if ($idTicket > 0) {
        $parametros['id_ticket'] = $idTicket;
    }

    if ($idNodo > 0) {
        $parametros['id_nodo'] = $idNodo;
        if ($rol === 2) {
            $parametros['vista'] = 'gestion';
        }
    }

    if ($idChat > 0) {
        $parametros['id_chat'] = $idChat;
    }

    header(
        'Location: ' . $rutaBaseTickets . '?' . http_build_query($parametros),
        true,
        303
    );
    header('Cache-Control: no-store');
    header('Content-Length: 0');

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    /* El navegador recibe la redirección antes de los correos diferidos. */
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        while (ob_get_level() > 0) {
            @ob_end_clean();
        }
        flush();
    }

    exit;
}

function solicitudChatFlujoEsAjax(): bool
{
    return strtolower((string) (
        $_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''
    )) === 'xmlhttprequest';
}

function responderChatFlujoJson(
    bool $correcto,
    string $mensaje,
    int $codigoHttp = 200
): void {
    http_response_code($codigoHttp);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');
    $cuerpo = json_encode(
        [
            'ok' => $correcto,
            'message' => $mensaje,
            'sent_at' => date('H:i'),
        ],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    $cuerpo = is_string($cuerpo)
        ? $cuerpo
        : '{"ok":false,"message":"Respuesta no disponible."}';
    header('Content-Length: ' . strlen($cuerpo));

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    echo $cuerpo;

    if (ob_get_level() > 0) {
        @ob_flush();
    }
    flush();
    exit;
}

/**
 * @param array<string, mixed> $datos
 */
function responderFlujoJson(
    bool $correcto,
    string $mensaje,
    array $datos = [],
    int $codigoHttp = 200
): void {
    http_response_code($codigoHttp);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');
    $cuerpo = json_encode(
        array_merge(
            [
                'ok' => $correcto,
                'message' => $mensaje,
            ],
            $datos
        ),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    $cuerpo = is_string($cuerpo)
        ? $cuerpo
        : '{"ok":false,"message":"Respuesta no disponible."}';
    header('Content-Length: ' . strlen($cuerpo));

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    echo $cuerpo;
    exit;
}

$estructuraGestorPorEtapa = flujoColumnaExiste(
    $conn,
    'proceso_etapas',
    'id_gestor'
) && flujoColumnaExiste($conn, 'proceso_etapas', 'id_sla');

if (
    !flujoModuloInstalado($conn)
    || !$estructuraGestorPorEtapa
    || !flujoModuloAprobacionCasosInstalado($conn)
) {
    ?><!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Instalación pendiente</title><style>body{font-family:Segoe UI,Arial;background:#f3f6fb;color:#243b53;padding:40px}.box{max-width:760px;margin:auto;background:#fff;border:1px solid #dfe7f1;border-radius:18px;padding:28px}.btn{display:inline-block;padding:11px 16px;border-radius:10px;background:#0f6fec;color:#fff;text-decoration:none}</style></head><body><section class="box"><h1>Instalación pendiente</h1><p>El administrador debe importar las migraciones pendientes, incluida <strong>002_notificaciones_email_tickets.sql</strong>, en la base <strong>mesa_servicio</strong>.</p><a class="btn" href="<?= $rol === 1 ? 'panelAdmin.php' : 'panelGestor.php' ?>">Volver al panel</a></section><script src="assets/js/controlSesion.js" defer></script></body></html><?php
    exit;
}

$idTicketSeleccionado = filter_input(
    INPUT_GET,
    'id_ticket',
    FILTER_VALIDATE_INT
) ?: 0;
$idNodoSeleccionado = filter_input(
    INPUT_GET,
    'id_nodo',
    FILTER_VALIDATE_INT
) ?: 0;
$idChatSeleccionado = filter_input(
    INPUT_GET,
    'id_chat',
    FILTER_VALIDATE_INT
) ?: 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token)
        || !hash_equals((string) $_SESSION['csrf_token'], $token)
    ) {
        redirigirFlujo('solicitud_invalida');
    }

    $accion = (string) ($_POST['accion'] ?? '');
    $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;

    if ($idTicket > 0) {
        paisExigirTicket($conn, $idTicket);
    }

    try {
        if ($accion === 'crear_ticket') {
            throw new RuntimeException(
                'Los tickets solo pueden ser creados desde el portal del solicitante.'
            );
        }

        $ticket = flujoObtenerTicket($conn, $idTicket);

        if (
            !$ticket
            || !flujoPuedeVerTicket($conn, $idTicket, $idUsuario, $rol)
        ) {
            throw new RuntimeException('No tiene acceso al ticket.');
        }

        if ($accion === 'crear_solucion_rapida') {
            if ($rol !== 2 || !solicitudChatFlujoEsAjax()) {
                throw new RuntimeException(
                    'La creación rápida de soluciones no está disponible.'
                );
            }

            $idTicketEtapa = filter_input(
                INPUT_POST,
                'id_ticket_etapa',
                FILTER_VALIDATE_INT
            ) ?: 0;
            $nombreSolucion = trim((string) (
                $_POST['nueva_solucion_nombre'] ?? ''
            ));
            $descripcionSolucion = trim((string) (
                $_POST['nueva_solucion_descripcion'] ?? ''
            ));

            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare(
                    "SELECT id_servicio
                     FROM ticket_etapas
                     WHERE id_ticket_etapa = ?
                       AND id_ticket = ?
                       AND id_gestor = ?
                       AND estado IN ('pendiente', 'en_proceso', 'en_espera_solicitante')
                     LIMIT 1
                     FOR UPDATE"
                );
                $stmt->bind_param(
                    'iii',
                    $idTicketEtapa,
                    $idTicket,
                    $idUsuario
                );
                $stmt->execute();
                $etapaSolucion = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$etapaSolucion) {
                    throw new RuntimeException(
                        'Esta etapa ya no está disponible para crear soluciones.'
                    );
                }

                $solucionCreada = flujoCrearSolucionServicio(
                    $conn,
                    (int) $etapaSolucion['id_servicio'],
                    $idUsuario,
                    $nombreSolucion,
                    $descripcionSolucion
                );
                $conn->commit();
            } catch (Throwable $errorSolucion) {
                $conn->rollback();
                throw $errorSolucion;
            }

            responderFlujoJson(
                true,
                !empty($solucionCreada['creada'])
                    ? 'Solución creada y seleccionada.'
                    : 'La solución ya existía y fue seleccionada.',
                ['solution' => $solucionCreada]
            );
        }

        if ($accion === 'configurar_notificaciones') {
            if ($rol !== 2) {
                throw new RuntimeException(
                    'Solo el gestor asignado puede configurar estos correos.'
                );
            }

            $idTicketEtapa = filter_input(
                INPUT_POST,
                'id_ticket_etapa',
                FILTER_VALIDATE_INT
            ) ?: 0;
            $valorHabilitada = (string) ($_POST['habilitada'] ?? '');

            if (!in_array($valorHabilitada, ['0', '1'], true)) {
                throw new RuntimeException(
                    'La preferencia de notificaciones no es válida.'
                );
            }

            flujoConfigurarNotificacionesEmail(
                $conn,
                $idTicket,
                $idUsuario,
                2,
                $valorHabilitada === '1',
                $idTicketEtapa
            );
            redirigirFlujo(
                $valorHabilitada === '1'
                    ? 'notificaciones_activadas'
                    : 'notificaciones_desactivadas',
                $idTicket,
                $idTicketEtapa,
                $idTicketEtapa
            );
        }

        if ($accion === 'crear_caso_hijo') {
            if ($rol !== 2) {
                throw new RuntimeException(
                    'Solo el gestor asignado puede crear casos hijos.'
                );
            }

            $idNodoPadre = filter_input(
                INPUT_POST,
                'id_ticket_etapa_padre',
                FILTER_VALIDATE_INT
            ) ?: 0;
            $filasDerivacion = $_POST['derivaciones'] ?? [];

            if (!is_array($filasDerivacion) || !$filasDerivacion) {
                /* Compatibilidad temporal con el formulario anterior. */
                $filasDerivacion = [[
                    'id_servicio_destino' => $_POST['id_servicio_destino'] ?? 0,
                    'motivo_derivacion' => $_POST['motivo_derivacion'] ?? '',
                ]];
            }

            $serviciosDestinoValidos = [];
            foreach (flujoServiciosDisponibles($conn) as $servicioDisponible) {
                $serviciosDestinoValidos[(int) $servicioDisponible['id_servicio']] =
                    (int) $servicioDisponible['id_catalogo'];
            }

            $derivaciones = [];
            foreach ($filasDerivacion as $filaDerivacion) {
                if (!is_array($filaDerivacion)) {
                    continue;
                }

                $idServicioDestino = (int) (
                    $filaDerivacion['id_servicio_destino'] ?? 0
                );
                $usaSeleccionCatalogo = array_key_exists(
                    'id_catalogo_destino',
                    $filaDerivacion
                );
                $idCatalogoDestino = (int) (
                    $filaDerivacion['id_catalogo_destino'] ?? 0
                );

                if (
                    $usaSeleccionCatalogo
                    && (
                        $idCatalogoDestino < 1
                        || !isset($serviciosDestinoValidos[$idServicioDestino])
                        || $serviciosDestinoValidos[$idServicioDestino]
                            !== $idCatalogoDestino
                    )
                ) {
                    throw new RuntimeException(
                        'Seleccione un servicio válido del proceso indicado.'
                    );
                }

                $derivaciones[] = [
                    'id_servicio_destino' => $idServicioDestino,
                    'motivo_derivacion' => trim((string) (
                        $filaDerivacion['motivo_derivacion'] ?? ''
                    )),
                    'campos_extras' => is_array($filaDerivacion['campos_extras'] ?? null)
                        ? $filaDerivacion['campos_extras']
                        : [],
                ];
            }

            flujoCrearCasosHijos(
                $conn,
                $idTicket,
                $idNodoPadre,
                $derivaciones,
                $idUsuario,
                $rol
            );
            redirigirFlujo('casos_hijos_creados', $idTicket, $idNodoPadre);
        }

        if ($accion === 'enviar_mensaje') {
            $idTicketEtapa = filter_input(
                INPUT_POST,
                'id_ticket_etapa',
                FILTER_VALIDATE_INT
            ) ?: 0;
            $mensaje = trim((string) ($_POST['mensaje'] ?? ''));
            flujoEnviarConversacion(
                $conn,
                $ticket,
                $idTicketEtapa,
                $idUsuario,
                $rol,
                $mensaje,
                isset($_FILES['adjuntos'])
                    ? (array) $_FILES['adjuntos']
                    : []
            );

            if (solicitudChatFlujoEsAjax()) {
                responderChatFlujoJson(true, 'Mensaje enviado.');
            }

            redirigirFlujo(
                'mensaje_enviado',
                $idTicket,
                $idTicketEtapa,
                $idTicketEtapa
            );
        }

        if ($accion === 'guardar_checklist') {
            if (!in_array($rol, [1, 2], true)) {
                throw new RuntimeException('No está autorizado para gestionar el checklist.');
            }

            $idTicketEtapa = filter_input(
                INPUT_POST,
                'id_ticket_etapa',
                FILTER_VALIDATE_INT
            ) ?: 0;
            flujoGuardarChecklist(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                $rol,
                (array) ($_POST['completado'] ?? []),
                (array) ($_POST['observacion'] ?? [])
            );
            redirigirFlujo(
                'checklist_guardado',
                $idTicket,
                $idTicketEtapa,
                $idTicketEtapa
            );
        }

        if (in_array($accion, ['marcar_listo', 'solicitar_cierre_definitivo'], true)) {
    if ($rol !== 2) {
        throw new RuntimeException(
            'Solo el gestor asignado puede marcar el caso como listo.'
        );
    }

    $idTicketEtapa = filter_input(
        INPUT_POST,
        'id_ticket_etapa',
        FILTER_VALIDATE_INT
    ) ?: 0;

    $idSolucion = filter_input(
        INPUT_POST,
        'id_solucion',
        FILTER_VALIDATE_INT
    ) ?: 0;

    $comentario = trim((string) ($_POST['comentario_cierre'] ?? ''));
    $nuevaSolucionNombre = trim((string) ($_POST['nueva_solucion_nombre'] ?? ''));
    $nuevaSolucionDescripcion = trim((string) ($_POST['nueva_solucion_descripcion'] ?? ''));

    flujoMarcarEtapaLista(
        $conn,
        $idTicket,
        $idTicketEtapa,
        $idUsuario,
        $rol,
        $idSolucion,
        $comentario,
        $accion === 'solicitar_cierre_definitivo',
        $nuevaSolucionNombre,
        $nuevaSolucionDescripcion
    );

    redirigirFlujo(
        $accion === 'solicitar_cierre_definitivo'
            ? 'cierre_definitivo_solicitado'
            : 'etapa_lista',
        $idTicket,
        $idTicketEtapa,
        $idTicketEtapa
    );
}


        if ($accion === 'cerrar_caso') {
            $idTicketEtapa = filter_input(
                INPUT_POST,
                'id_ticket_etapa',
                FILTER_VALIDATE_INT
            ) ?: 0;
            $calificacionArea = filter_input(
                INPUT_POST,
                'calificacion_area',
                FILTER_VALIDATE_INT
            ) ?: 0;
            $calificacionTiempo = filter_input(
                INPUT_POST,
                'calificacion_tiempo',
                FILTER_VALIDATE_INT
            ) ?: 0;
            $comentarioCalificacion = trim((string) (
                $_POST['comentario_calificacion'] ?? ''
            ));
            flujoCompletarEtapa(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                $rol,
                $calificacionArea,
                $calificacionTiempo,
                $comentarioCalificacion
            );
            redirigirFlujo(
                'caso_cerrado',
                $idTicket,
                $idTicketEtapa,
                $idTicketEtapa
            );
        }

        if ($accion === 'reabrir_derivacion') {
            $idTicketEtapa = filter_input(
                INPUT_POST,
                'id_ticket_etapa',
                FILTER_VALIDATE_INT
            ) ?: 0;
            $motivoReapertura = trim((string) (
                $_POST['motivo_reapertura'] ?? ''
            ));
            flujoReabrirDerivacion(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                $rol,
                $motivoReapertura
            );
            redirigirFlujo(
                'derivacion_reabierta',
                $idTicket,
                $idTicketEtapa,
                $idTicketEtapa
            );
        }

        if ($accion === 'calificar_cerrar_ticket') {
            if ($rol !== 2 || (int) $ticket['id_usuario'] !== $idUsuario) {
                throw new RuntimeException(
                    'Solo el gestor que creó el ticket puede cerrarlo definitivamente.'
                );
            }

            $total = flujoCalificarCerrarTicket(
                $conn,
                $idTicket,
                $idUsuario,
                (array) ($_POST['calificacion_area'] ?? []),
                (array) ($_POST['calificacion_tiempo'] ?? []),
                (array) ($_POST['comentario'] ?? [])
            );

            redirigirFlujo('ticket_cerrado', $idTicket);
        }

        /* Compatibilidad con formularios antiguos instalados antes de la
           encuesta consolidada. */
        if ($accion === 'calificar_etapa') {
            throw new RuntimeException(
                'Este formulario quedó deshabilitado. Cada caso debe marcarse Listo y ser calificado y cerrado por su propio creador.'
            );
        }

        redirigirFlujo('solicitud_invalida', $idTicket);
    } catch (Throwable $e) {
        error_log('Flujo de ticket: ' . $e->getMessage());

        if (
            in_array($accion, ['enviar_mensaje', 'crear_solucion_rapida'], true)
            && solicitudChatFlujoEsAjax()
        ) {
            if ($accion === 'crear_solucion_rapida') {
                responderFlujoJson(
                    false,
                    get_class($e) === RuntimeException::class
                        ? $e->getMessage()
                        : 'No fue posible crear la solución.',
                    [],
                    422
                );
            }
            responderChatFlujoJson(
                false,
                get_class($e) === RuntimeException::class
                    ? $e->getMessage()
                    : 'No fue posible enviar el mensaje.',
                422
            );
        }

        $_SESSION['error_flujo'] = get_class($e) === RuntimeException::class
            ? $e->getMessage()
            : 'No fue posible completar la operación. Inténtelo nuevamente.';
        redirigirFlujo('error_operacion', $idTicket);
    }
}

$procesosDisponibles = [];
$catalogosDisponibles = [];
$flujosPorServicio = [];
if (false && $rol === 2) {
    $resultado = $conn->query(
        "SELECT
            p.id_proceso,
            p.nombre,
            p.descripcion,
            c_inicial.id_catalogo,
            c_inicial.nombre AS catalogo_nombre,
            c_inicial.descripcion AS catalogo_descripcion,
            c_inicial.imagen AS catalogo_imagen,
            s_inicial.id_servicio,
            s_inicial.nombre AS servicio_nombre,
            s_inicial.descripcion AS servicio_descripcion,
            sl_inicial.nombre AS servicio_sla,
            sl_inicial.tiempo_respuesta AS servicio_sla_tiempo,
            sl_inicial.unidad AS servicio_sla_unidad,
            (
                SELECT COUNT(*)
                FROM proceso_etapas AS pe_total
                WHERE pe_total.id_proceso = p.id_proceso
                  AND pe_total.estado = 'activo'
            ) AS etapas
         FROM procesos AS p
         INNER JOIN proceso_etapas AS pe_inicial
            ON pe_inicial.id_proceso = p.id_proceso
           AND pe_inicial.estado = 'activo'
           AND pe_inicial.orden = (
                SELECT MIN(pe_primera.orden)
                FROM proceso_etapas AS pe_primera
                WHERE pe_primera.id_proceso = p.id_proceso
                  AND pe_primera.estado = 'activo'
           )
         INNER JOIN servicios AS s_inicial
            ON s_inicial.id_servicio = pe_inicial.id_servicio
           AND s_inicial.estado = 'activo'
         INNER JOIN catalogos AS c_inicial
            ON c_inicial.id_catalogo = s_inicial.id_catalogo
           AND c_inicial.estado = 'activo'
         INNER JOIN usuarios AS u_inicial
            ON u_inicial.id_usuario = COALESCE(
                pe_inicial.id_gestor,
                s_inicial.id_gestor
            )
           AND u_inicial.id_rol = 2
           AND u_inicial.estado = 'activo'
         INNER JOIN sla AS sl_inicial
            ON sl_inicial.id_sla = COALESCE(
                pe_inicial.id_sla,
                s_inicial.id_sla
            )
           AND sl_inicial.estado = 'activo'
         WHERE p.estado = 'activo'
           AND p.id_pais_operacion = {$idPaisOperacion}
           AND NOT EXISTS (
                SELECT 1
                FROM proceso_etapas AS pe_revision
                LEFT JOIN servicios AS s_revision
                   ON s_revision.id_servicio = pe_revision.id_servicio
                  AND s_revision.estado = 'activo'
                LEFT JOIN usuarios AS u_revision
                   ON u_revision.id_usuario = COALESCE(
                        pe_revision.id_gestor,
                        s_revision.id_gestor
                   )
                  AND u_revision.id_rol = 2
                  AND u_revision.estado = 'activo'
                LEFT JOIN sla AS sl_revision
                   ON sl_revision.id_sla = COALESCE(
                        pe_revision.id_sla,
                        s_revision.id_sla
                   )
                  AND sl_revision.estado = 'activo'
                WHERE pe_revision.id_proceso = p.id_proceso
                  AND pe_revision.estado = 'activo'
                  AND (
                    s_revision.id_servicio IS NULL
                    OR u_revision.id_usuario IS NULL
                    OR sl_revision.id_sla IS NULL
                  )
           )
         ORDER BY c_inicial.orden, c_inicial.nombre, s_inicial.nombre, p.nombre"
    );
    while ($fila = $resultado->fetch_assoc()) {
        $procesosDisponibles[] = $fila;
        $idServicioInicial = (int) $fila['id_servicio'];
        $flujosPorServicio[$idServicioInicial][] = $fila;
    }

    $resultadoCatalogos = $conn->query(
        "SELECT
            c.id_catalogo,
            c.nombre AS catalogo_nombre,
            c.descripcion AS catalogo_descripcion,
            c.imagen AS catalogo_imagen,
            c.orden AS catalogo_orden,
            s.id_servicio,
            s.nombre AS servicio_nombre,
            s.descripcion AS servicio_descripcion,
            sl.nombre AS servicio_sla,
            sl.tiempo_respuesta AS servicio_sla_tiempo,
            sl.unidad AS servicio_sla_unidad,
            u.nombre AS servicio_gestor
         FROM catalogos AS c
         LEFT JOIN servicios AS s
            ON s.id_catalogo = c.id_catalogo
           AND s.estado = 'activo'
         LEFT JOIN sla AS sl
            ON sl.id_sla = s.id_sla
           AND sl.estado = 'activo'
         LEFT JOIN usuarios AS u
            ON u.id_usuario = s.id_gestor
           AND u.id_rol = 2
           AND u.estado = 'activo'
         WHERE c.estado = 'activo'
           AND c.id_pais_operacion = {$idPaisOperacion}
         ORDER BY c.orden, c.nombre, s.nombre"
    );

    while ($fila = $resultadoCatalogos->fetch_assoc()) {
        $idCatalogo = (int) $fila['id_catalogo'];

        if (!isset($catalogosDisponibles[$idCatalogo])) {
            $catalogosDisponibles[$idCatalogo] = [
                'id_catalogo' => $idCatalogo,
                'nombre' => (string) $fila['catalogo_nombre'],
                'descripcion' => (string) ($fila['catalogo_descripcion'] ?? ''),
                'imagen' => (string) ($fila['catalogo_imagen'] ?? ''),
                'orden' => (int) $fila['catalogo_orden'],
                'servicios' => [],
            ];
        }

        $idServicio = (int) ($fila['id_servicio'] ?? 0);

        if ($idServicio > 0) {
            $fila['flujos'] = $flujosPorServicio[$idServicio] ?? [];
            $catalogosDisponibles[$idCatalogo]['servicios'][] = $fila;
        }
    }

    $catalogosDisponibles = array_values($catalogosDisponibles);
}

$ticketsUsuario = flujoTicketsUsuario($conn, $idUsuario, $rol);
$bandejaGestor = (string) ($_GET['bandeja'] ?? 'abiertos');
$busquedaGestor = substr(trim((string) ($_GET['buscar'] ?? '')), 0, 120);
$estadoBusquedaGestor = substr(trim((string) ($_GET['estado_busqueda'] ?? 'todos')), 0, 60);

if (!in_array($bandejaGestor, ['abiertos', 'derivaciones', 'pendientes', 'cerrados', 'derivaciones_cerradas'], true)) {
    $bandejaGestor = 'abiertos';
}

if ($rol === 2 && $idTicketSeleccionado > 0) {
    $bandejaSolicitada = (string) ($_GET['bandeja'] ?? '');
    $bandejaDelTicket = '';
    foreach ($ticketsUsuario as $ticketUsuario) {
        if ((int) ($ticketUsuario['id_ticket'] ?? 0) !== $idTicketSeleccionado) {
            continue;
        }

        $bandejaDelTicket = (string) ($ticketUsuario['bandeja_gestor'] ?? 'abiertos');
        if ($bandejaDelTicket === $bandejaSolicitada) {
            break;
        }
    }
    if ($bandejaDelTicket !== '') {
        $bandejaGestor = $bandejaDelTicket;
    }
}

$totalCasosAbiertos = 0;
$totalCasosDerivados = 0;
$totalCasosPendientes = 0;
$totalCasosCerrados = 0;
$totalDerivacionesCompletadas = 0;

foreach ($ticketsUsuario as $ticketUsuario) {
    switch ((string) ($ticketUsuario['bandeja_gestor'] ?? 'abiertos')) {
        case 'cerrados':
            $totalCasosCerrados++;
            break;
        case 'derivaciones_cerradas':
            $totalDerivacionesCompletadas++;
            break;
        case 'pendientes':
            $totalCasosPendientes++;
            break;
        case 'derivaciones':
            $totalCasosDerivados++;
            break;
        default:
            $totalCasosAbiertos++;
    }
}

$tickets = $rol === 2
    ? array_values(array_filter(
        $ticketsUsuario,
        static fn (array $ticket): bool =>
            (string) ($ticket['bandeja_gestor'] ?? 'abiertos') === $bandejaGestor
    ))
    : $ticketsUsuario;

/*
 * La urgencia operativa solo cambia el primer criterio de la bandeja del
 * gestor. Dentro de cada grupo se conserva el orden natural que ya tenía el
 * módulo: actividad reciente para casos abiertos y fecha de cierre para los
 * casos finalizados. Cuando un incidente deja de estar abierto, los demás
 * casos recuperan automáticamente ese orden secundario.
 */
if ($rol === 2) {
    $fechaOrdenTicket = static function ($valor): int {
        $texto = trim((string) ($valor ?? ''));
        if ($texto === '') {
            return 0;
        }

        $marca = strtotime($texto);
        return $marca === false ? 0 : $marca;
    };

    usort(
        $tickets,
        static function (array $a, array $b) use ($fechaOrdenTicket): int {
            $tipoA = strtolower(trim((string) ($a['tipo_solicitud'] ?? '')));
            $tipoB = strtolower(trim((string) ($b['tipo_solicitud'] ?? '')));
            $incidenteA = $tipoA === 'incidente' ? 0 : 1;
            $incidenteB = $tipoB === 'incidente' ? 0 : 1;

            if ($incidenteA !== $incidenteB) {
                return $incidenteA <=> $incidenteB;
            }

            $bandejaA = (string) ($a['bandeja_gestor'] ?? 'abiertos');
            $bandejaB = (string) ($b['bandeja_gestor'] ?? 'abiertos');
            $campoFechaA = $bandejaA === 'derivaciones_cerradas'
                ? 'fecha_finalizacion_derivacion_gestor'
                : ($bandejaA === 'cerrados'
                    ? 'fecha_finalizacion'
                    : 'actualizado_en');
            $campoFechaB = $bandejaB === 'derivaciones_cerradas'
                ? 'fecha_finalizacion_derivacion_gestor'
                : ($bandejaB === 'cerrados'
                    ? 'fecha_finalizacion'
                    : 'actualizado_en');
            $fechaA = $fechaOrdenTicket($a[$campoFechaA] ?? null);
            $fechaB = $fechaOrdenTicket($b[$campoFechaB] ?? null);
            if ($fechaA === 0 && $campoFechaA !== 'actualizado_en') {
                $fechaA = $fechaOrdenTicket($a['actualizado_en'] ?? null);
            }
            if ($fechaB === 0 && $campoFechaB !== 'actualizado_en') {
                $fechaB = $fechaOrdenTicket($b['actualizado_en'] ?? null);
            }

            if ($fechaA !== $fechaB) {
                return $fechaB <=> $fechaA;
            }

            $idA = (int) ($a['id_ticket'] ?? 0);
            $idB = (int) ($b['id_ticket'] ?? 0);
            if ($idA !== $idB) {
                return $idB <=> $idA;
            }

            return (int) ($a['id_ticket_etapa_gestor'] ?? 0)
                <=> (int) ($b['id_ticket_etapa_gestor'] ?? 0);
        }
    );
}

$proyeccionesTickets = [];
foreach ($tickets as $ticketProyeccion) {
    $idTicketProyeccion = (int) ($ticketProyeccion['id_ticket'] ?? 0);
    if ($idTicketProyeccion > 0 && !isset($proyeccionesTickets[$idTicketProyeccion])) {
        $proyeccionesTickets[$idTicketProyeccion] =
            flujoProyeccionFinalizacionTicket($conn, $idTicketProyeccion);
    }
}

$estadosGestorDisponibles = [];

if ($rol === 2) {
    foreach ($tickets as $ticketGestor) {
        $estadoGestor = (string) ($ticketGestor['estado_etapa_gestor'] ?? 'en_proceso');
        $estadosGestorDisponibles[$estadoGestor] = textoEstadoCaso($estadoGestor);
    }
    asort($estadosGestorDisponibles, SORT_NATURAL | SORT_FLAG_CASE);

    if (
        $estadoBusquedaGestor !== 'todos'
        && !array_key_exists($estadoBusquedaGestor, $estadosGestorDisponibles)
    ) {
        $estadoBusquedaGestor = 'todos';
    }
}

$serviciosDerivacion = $idTicketSeleccionado > 0
    ? flujoServiciosDisponibles($conn)
    : [];
$catalogosDerivacion = [];

foreach ($serviciosDerivacion as $servicioDerivacion) {
    $idCatalogoDerivacion = (int) ($servicioDerivacion['id_catalogo'] ?? 0);

    if (
        $idCatalogoDerivacion > 0
        && !isset($catalogosDerivacion[$idCatalogoDerivacion])
    ) {
        $catalogosDerivacion[$idCatalogoDerivacion] = [
            'id_catalogo' => $idCatalogoDerivacion,
            'nombre' => (string) (
                $servicioDerivacion['catalogo_nombre'] ?? 'Proceso'
            ),
        ];
    }
}

$serviciosDerivacionJson = json_encode(
    array_map(
        static fn (array $servicio): array => [
            'id_servicio' => (int) ($servicio['id_servicio'] ?? 0),
            'id_catalogo' => (int) ($servicio['id_catalogo'] ?? 0),
            'nombre' => (string) ($servicio['servicio_nombre'] ?? ''),
            'descripcion' => (string) ($servicio['servicio_descripcion'] ?? ''),
            'gestor' => (string) ($servicio['gestor_nombre'] ?? 'Sin gestor'),
            'sla' => (string) ($servicio['sla_nombre'] ?? 'Sin SLA'),
            'campos_extras' => array_map(
                static fn (array $campo): array => [
                    'id' => (int) ($campo['id_campo_extra'] ?? 0),
                    'etiqueta' => (string) ($campo['etiqueta'] ?? ''),
                    'obligatorio' => (int) ($campo['obligatorio'] ?? 1),
                ],
                camposExtrasListarServicio($GLOBALS['conn'], (int) ($servicio['id_servicio'] ?? 0))
            ),
        ],
        $serviciosDerivacion
    ),
    JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
        | JSON_HEX_TAG
        | JSON_HEX_AMP
        | JSON_HEX_APOS
        | JSON_HEX_QUOT
);

if (!is_string($serviciosDerivacionJson)) {
    $serviciosDerivacionJson = '[]';
}
/*
 * id_nodo identifica de forma suficiente una selección explícita hecha desde
 * el árbol del caso. Antes también se exigía vista=gestion; si la navegación
 * parcial o el contenedor principal omitían ese parámetro, el servidor volvía
 * a renderizar el resumen y el botón parecía limitarse a recargar la página.
 *
 * Las autorizaciones y el modo de solo lectura de etapas cerradas continúan
 * aplicándose más adelante mediante flujoPuedeVerTicket(), el estado del nodo
 * y $casoSeleccionadoCerrado.
 */
$vistaGestionEtapa = $rol === 2
    && $idTicketSeleccionado > 0
    && $idNodoSeleccionado > 0;
$ticketSeleccionado = null;
$etapas = [];
$etapaActual = null;
$checklist = [];
$checklistObligatorioTotal = 0;
$checklistObligatorioPendiente = 0;
$conversaciones = [];
$conversacionActual = null;
$chatSeleccionadoExplicito = false;
$comunicaciones = [];
$adjuntos = [];
$eventosConversacion = [];
$historial = [];
$avisoReapertura = null;
$puedeEscribir = false;
$casoSeleccionadoCerrado = false;
$etapasPorId = [];
$hijosPorPadre = [];
$hijosArbolVisual = [];
$totalApoyosArbol = 0;
$rutaCasoSeleccionado = [];
$etapasOficiales = [];
$casoPrincipalVisual = null;
$solucionesCaso = [];
$camposExtrasEtapa = [];
$etapaEncuestaLegacy = null;
$moduloCalificacionDetallada = flujoModuloCalificacionDetalladaInstalado($conn);

if ($idTicketSeleccionado > 0) {
    paisExigirTicket($conn, $idTicketSeleccionado);
    if (!flujoPuedeVerTicket($conn, $idTicketSeleccionado, $idUsuario, $rol)) {
        http_response_code(403);
        exit('El ticket todavía no está habilitado para su proceso.');
    }

    $ticketSeleccionado = flujoObtenerTicket($conn, $idTicketSeleccionado);
    $etapas = ordenarArbolCasos(
        flujoObtenerEtapasTicket($conn, $idTicketSeleccionado),
        $idTicketSeleccionado
    );
    $etapaActual = flujoSeleccionarNodoTicket(
        $conn,
        $idTicketSeleccionado,
        $idUsuario,
        $rol,
        $idNodoSeleccionado
    );

    /* Al abrir un caso pendiente desde la bandeja, el enlace puede no traer
       id_nodo. Seleccionamos la etapa asignada automáticamente para que el
       caso abierto use la misma ficha organizada que una etapa seleccionada. */
    if ($rol === 2 && $etapaActual && !$vistaGestionEtapa) {
        $vistaGestionEtapa = true;
    }

    foreach ($etapas as $etapaArbol) {
        $idEtapaArbol = (int) $etapaArbol['id_ticket_etapa'];
        $idPadreArbol = (int) ($etapaArbol['id_ticket_etapa_padre'] ?? 0);
        $etapasPorId[$idEtapaArbol] = $etapaArbol;
        $hijosPorPadre[$idPadreArbol][] = $etapaArbol;

        if (
            $etapaEncuestaLegacy === null
            && $idPadreArbol === 0
        ) {
            $etapaEncuestaLegacy = $etapaArbol;
        }

        if ($idPadreArbol === 0) {
            $etapasOficiales[] = $etapaArbol;
        }
    }

    if ($etapaActual) {
        $idEtapaActual = (int) $etapaActual['id_ticket_etapa'];
        $etapaActual = array_merge(
            $etapaActual,
            $etapasPorId[$idEtapaActual] ?? []
        );
        $camposExtrasEtapa = camposExtrasValoresEtapa(
            $conn,
            (int) ($etapaActual['id_ticket_etapa'] ?? 0)
        );
        $casoSeleccionadoCerrado = in_array(
            (string) $etapaActual['estado'],
            ['completada', 'cancelada'],
            true
        );

        /*
         * Los casos cerrados del gestor se abren directamente en consulta.
         * Así no dependen de un segundo clic ni de que el contenedor SPA
         * conserve id_nodo/vista al navegar dentro del mismo módulo.
         */
        if ($rol === 2 && $casoSeleccionadoCerrado) {
            $vistaGestionEtapa = true;
        }

        if (!$casoSeleccionadoCerrado) {
            $solucionesCaso = flujoSolucionesServicio(
                $conn,
                (int) ($etapaActual['id_servicio'] ?? 0)
            );
        }

        $idRuta = $idEtapaActual;
        while ($idRuta > 0 && isset($etapasPorId[$idRuta])) {
            $rutaCasoSeleccionado[$idRuta] = true;
            $idRuta = (int) (
                $etapasPorId[$idRuta]['id_ticket_etapa_padre'] ?? 0
            );
        }
    }

    /*
     * El arbol visible contiene un solo caso principal. Las etapas oficiales
     * son el historial secuencial de ese mismo caso y las unicas ramas son
     * los tickets creados por derivacion en cada etapa.
     */
    $idRaizActual = (int) ($ticketSeleccionado['id_etapa_actual'] ?? 0);
    while (
        $idRaizActual > 0
        && isset($etapasPorId[$idRaizActual])
        && (int) ($etapasPorId[$idRaizActual]['id_ticket_etapa_padre'] ?? 0) > 0
    ) {
        $idRaizActual = (int) $etapasPorId[$idRaizActual]['id_ticket_etapa_padre'];
    }

    $etapaPrincipalActual = $etapasPorId[$idRaizActual] ?? null;

    /*
     * En un caso cerrado, id_etapa_actual apunta normalmente a la última
     * etapa de todo el flujo. Para un gestor esa etapa puede pertenecer a otra
     * persona. El resumen debe representar primero la etapa oficial que fue
     * asignada al gestor conectado; de lo contrario el botón conduce a la
     * etapa de otro gestor y la pantalla termina regresando al resumen.
     */
    if (
        $rol === 2
        && $casoSeleccionadoCerrado
        && $etapaActual
        && (int) ($etapaActual['id_ticket_etapa_padre'] ?? 0) === 0
    ) {
        $etapaPrincipalActual = $etapaActual;
    }

    if (!$etapaPrincipalActual && $etapasOficiales) {
        foreach ($etapasOficiales as $etapaOficial) {
            if (!in_array(
                (string) ($etapaOficial['estado'] ?? ''),
                ['completada', 'cancelada', 'bloqueada'],
                true
            )) {
                $etapaPrincipalActual = $etapaOficial;
                break;
            }
        }
    }

    if (!$etapaPrincipalActual && $etapasOficiales) {
        $etapaPrincipalActual = $etapasOficiales[count($etapasOficiales) - 1];
    }

    $hijosArbolVisual = $hijosPorPadre;
    $hijosArbolVisual[0] = [];

    foreach ($etapasOficiales as $etapaOficial) {
        $idEtapaOficial = (int) $etapaOficial['id_ticket_etapa'];
        foreach ($hijosPorPadre[$idEtapaOficial] ?? [] as $ticketDerivado) {
            $hijosArbolVisual[0][] = $ticketDerivado;
        }
    }

    $totalApoyosArbol = contarDescendientesCaso(0, $hijosArbolVisual);

    if ($etapaPrincipalActual) {
        $idNodoDestinoPrincipal = (int) $etapaPrincipalActual['id_ticket_etapa'];
        $casoPrincipalVisual = $etapaPrincipalActual;
        $casoPrincipalVisual['id_ticket_etapa'] = 0;
        $casoPrincipalVisual['id_nodo_destino'] = $idNodoDestinoPrincipal;
        $casoPrincipalVisual['es_caso_principal'] = true;
        $casoPrincipalVisual['es_etapa_oficial'] = true;
        $casoPrincipalVisual['es_derivacion'] = false;
        $casoPrincipalVisual['codigo_caso'] = (string) $idTicketSeleccionado;
        $casoPrincipalVisual['total_etapas'] = count($etapasOficiales);
    }

    $conversaciones = flujoConversacionesDisponibles(
        $conn,
        $idTicketSeleccionado,
        $idUsuario,
        $rol
    );

    /* En modo consulta se conservan todas las conversaciones en las que el
       gestor participó. Filtrarlas a la etapa seleccionada ocultaba parte de
       la trazabilidad precisamente después de cerrar el caso. */
    $idChatPreferido = $idChatSeleccionado;

    if ($idChatPreferido < 1 && $etapaActual) {
        $idChatPreferido = (int) $etapaActual['id_ticket_etapa'];
    }

    foreach ($conversaciones as $conversacion) {
        if ((int) $conversacion['id_ticket_etapa'] === $idChatPreferido) {
            $conversacionActual = $conversacion;
            break;
        }
    }

    if (!$conversacionActual && $conversaciones) {
        $conversacionActual = $conversaciones[0];
    }

    $chatSeleccionadoExplicito = $idChatSeleccionado > 0
        && $conversacionActual
        && (int) $conversacionActual['id_ticket_etapa'] === $idChatSeleccionado;

    $puedeEscribir = $ticketSeleccionado && $conversacionActual
        ? flujoPuedeEscribirNodo(
            $conn,
            $ticketSeleccionado,
            (int) $conversacionActual['id_ticket_etapa'],
            $idUsuario,
            $rol
        )
        : false;

    if ($etapaActual) {
        $checklist = flujoChecklistEtapa(
            $conn,
            (int) $etapaActual['id_ticket_etapa']
        );
        foreach ($checklist as $itemChecklist) {
            if ((int) ($itemChecklist['obligatorio'] ?? 0) !== 1) {
                continue;
            }

            $checklistObligatorioTotal++;
            if ((int) ($itemChecklist['completado'] ?? 0) !== 1) {
                $checklistObligatorioPendiente++;
            }
        }
    }

    if ($conversacionActual) {
        $idConversacionActual = (int) $conversacionActual['id_ticket_etapa'];
        $comunicaciones = flujoComunicacionesNodo(
            $conn,
            $idTicketSeleccionado,
            $idConversacionActual
        );
        $adjuntos = flujoAdjuntosNodo(
            $conn,
            $idTicketSeleccionado,
            $idConversacionActual
        );
        $eventosConversacion = flujoLineaTiempoConversacion(
            $comunicaciones,
            $adjuntos
        );
    }

    if ($etapaActual) {
        $idCasoHistorial = (int) $etapaActual['id_ticket_etapa'];
        $stmt = $conn->prepare(
            "SELECT
                h.id_historial,
                h.accion,
                h.detalle,
                h.creado_en,
                COALESCE(u.nombre, 'Sistema') AS usuario,
                u.id_rol AS usuario_rol
             FROM solicitud_historial AS h
             LEFT JOIN usuarios AS u ON u.id_usuario = h.id_usuario
             WHERE h.id_ticket = ?
               AND h.id_ticket_etapa = ?
             ORDER BY h.creado_en, h.id_historial"
        );
        $stmt->bind_param('ii', $idTicketSeleccionado, $idCasoHistorial);
        $stmt->execute();
        $resultado = $stmt->get_result();
        while ($fila = $resultado->fetch_assoc()) {
            $historial[] = $fila;
        }
        $stmt->close();

        if (
            $rol === 2
            && ($esUsuarioPrueba || (int) ($etapaActual['id_gestor'] ?? 0) === $idUsuario)
            && in_array((string) ($etapaActual['estado'] ?? ''),
                ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada'], true)
        ) {
            $stmt = $conn->prepare(
                "SELECT titulo, mensaje, creada_en
                 FROM notificaciones
                 WHERE id_usuario = ?
                   AND id_ticket = ?
                   AND id_ticket_etapa = ?
                   AND titulo IN ('Derivación reabierta', 'Caso reabierto')
                 ORDER BY id_notificacion DESC
                 LIMIT 1"
            );
            $stmt->bind_param('iii', $idUsuario, $idTicketSeleccionado, $idCasoHistorial);
            $stmt->execute();
            $avisoReapertura = $stmt->get_result()->fetch_assoc() ?: null;
            $stmt->close();
        }
    }

    flujoMarcarNotificacionesContenidoVisto(
        $conn,
        $idUsuario,
        $idTicketSeleccionado,
        false,
        $avisoReapertura ? (int) ($etapaActual['id_ticket_etapa'] ?? 0) : null
    );
}

$esGestorNodo = false;
$esCreadorNodo = false;
$estadoNodo = '';
$puedeGestionar = false;
$puedeCrearHijo = false;
$puedeCerrarNodo = false;
$tipoCalificacionNodo = null;
$esTicketDerivadoActual = false;
$gestorTieneCasoPadreAsignado = false;
$etiquetaNodoActual = '';
$notificacionesEmailGestor = true;

if ($etapaActual) {
    if ($rol === 2) {
        foreach ($etapasOficiales as $etapaOficialGestor) {
            if ($esUsuarioPrueba || (int) ($etapaOficialGestor['id_gestor'] ?? 0) === $idUsuario) {
                $gestorTieneCasoPadreAsignado = true;
                break;
            }
        }
    }
    $esTicketDerivadoActual = (int) (
        $etapaActual['id_ticket_etapa_padre'] ?? 0
    ) > 0;
    $etiquetaNodoActual = $esTicketDerivadoActual
        ? 'Ticket ' . (string) ($etapaActual['codigo_ticket'] ?? '')
        : 'Caso ' . (string) $idTicketSeleccionado;
    $esGestorNodo = $rol === 2
        && ($esUsuarioPrueba || (int) $etapaActual['id_gestor'] === $idUsuario);
    if ($esGestorNodo) {
        $notificacionesEmailGestor =
            flujoNotificacionesEmailHabilitadas(
                $conn,
                (int) $etapaActual['id_ticket'],
                $idUsuario
            );
    }
    $idCreadorNodo = (int) (
        $etapaActual['id_creador_caso']
        ?? $etapaActual['creado_por']
        ?? $ticketSeleccionado['id_usuario']
        ?? 0
    );
    $esCreadorNodo = $rol === 2 && ($esUsuarioPrueba || $idCreadorNodo === $idUsuario);
    $estadoNodo = (string) $etapaActual['estado'];
    $puedeGestionar = $esGestorNodo
        && in_array(
            $estadoNodo,
            ['pendiente', 'en_proceso', 'en_espera_solicitante'],
            true
        );
    $puedeCrearHijo = $esGestorNodo
        && in_array(
            $estadoNodo,
            ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada'],
            true
        );
    $puedeCerrarNodo = $esCreadorNodo && $estadoNodo === 'listo_cierre';
    $tipoCalificacionNodo = flujoTipoCalificacionCaso(
        $conn,
        (int) $etapaActual['id_ticket'],
        $etapaActual
    );
}

$guiaGestorClase = 'consulta';
$guiaGestorTitulo = 'Etapa disponible para consulta';
$guiaGestorTexto = 'Revise la información, el historial y los archivos de esta etapa.';

if ($etapaActual) {
    if ($casoSeleccionadoCerrado) {
        $guiaGestorClase = 'completada';
        $guiaGestorTitulo = 'Esta etapa ya está cerrada';
        $guiaGestorTexto = 'Puede consultar la solución, los tiempos, el historial y los archivos.';
    } elseif ($estadoNodo === 'listo_cierre') {
        $guiaGestorClase = 'revision';
        $guiaGestorTitulo = $puedeCerrarNodo
            ? 'Revise la solución y decida el cierre'
            : 'Gestión enviada para revisión';
        $guiaGestorTexto = $puedeCerrarNodo
            ? 'Califique la atención y cierre el caso, o reábralo si la solución no es suficiente.'
            : 'El creador del caso debe calificar, cerrar o solicitar una reapertura.';
    } elseif ($estadoNodo === 'pausada') {
        $guiaGestorClase = 'pausada';
        $guiaGestorTitulo = 'Espere la respuesta de los procesos de apoyo';
        $guiaGestorTexto = 'Esta etapa está pausada mientras se completan los tickets derivados.';
    } elseif ($puedeGestionar && $checklistObligatorioPendiente > 0) {
        $guiaGestorClase = 'pendiente';
        $guiaGestorTitulo = 'Complete el checklist obligatorio';
        $guiaGestorTexto = 'Tiene ' . $checklistObligatorioPendiente
            . ' requisito(s) pendiente(s). Guárdelos antes de enviar la solución a revisión.';
    } elseif ($puedeGestionar) {
        $guiaGestorClase = 'gestion';
        $guiaGestorTitulo = 'Registre la solución y finalice su gestión';
        $guiaGestorTexto = 'El checklist está completo. Seleccione la solución aplicada y envíe el caso a revisión.';
    } elseif ($esGestorNodo) {
        $guiaGestorClase = 'espera';
        $guiaGestorTitulo = 'Revise el estado actual de la etapa';
        $guiaGestorTexto = 'Las acciones disponibles dependen del estado y de las derivaciones activas.';
    } else {
        $guiaGestorTexto = 'Esta etapa está asignada a '
            . (string) ($etapaActual['gestor_nombre'] ?? 'otro gestor')
            . '. Puede consultar su avance, pero no modificarla.';
    }
}

$mensajes = [
    'ticket_creado' => ['ok', 'Caso creado y primera etapa notificada.'],
    'caso_hijo_creado' => ['ok', 'Ticket derivado creado. El SLA de la etapa quedó pausado.'],
    'casos_hijos_creados' => ['ok', 'Derivaciones creadas. Los tickets derivados ya trabajan en paralelo y el SLA de la etapa quedó pausado.'],
    'mensaje_enviado' => ['ok', 'Mensaje enviado en la conversación privada del caso.'],
    'notificaciones_activadas' => ['ok', 'Recibirá correos por cada nueva acción del caso mientras continúe asignado a usted.'],
    'notificaciones_desactivadas' => ['aviso', 'Las notificaciones por correo de este caso fueron desactivadas para su usuario.'],
    'checklist_guardado' => ['ok', 'Checklist guardado correctamente.'],
    'etapa_lista' => ['ok', 'Caso marcado como listo. El creador fue notificado para calificarlo y decidir su cierre.'],
    'cierre_definitivo_solicitado' => ['ok', 'Solicitud enviada. El solicitante decidirá si cierra definitivamente el ticket por resolución en primer contacto.'],
    'caso_cerrado' => ['ok', 'Caso calificado y cerrado por su creador. El sistema verificó sus dependencias.'],
    'derivacion_reabierta' => ['ok', 'Caso reabierto. El corte anterior de Listo se anuló y el SLA volvió a contabilizar todo el tiempo.'],
    'calificacion_guardada' => ['ok', 'Calificación guardada. Complete los procesos restantes.'],
    'ticket_cerrado' => ['ok', 'Las etapas y sus tiempos de respuesta fueron calificados. El caso quedó cerrado definitivamente.'],
    'datos_incompletos' => ['error', 'Complete todos los campos obligatorios.'],
    'mensaje_vacio' => ['error', 'Escriba un mensaje o seleccione un archivo.'],
    'solicitud_invalida' => ['error', 'La solicitud no es válida.'],
    'error_operacion' => ['error', 'No fue posible completar la operación.'],
];
$mensajeActual = (string) ($_GET['msg'] ?? '');
$detalleError = trim((string) seguridadConsumirDatoSesion('error_flujo'));
$modoGestor = (string) ($_GET['modo'] ?? 'mis_tickets');
$panelCaso = (string) ($_GET['panel'] ?? 'estructura');
$abrirCierreDefinitivo = (string) ($_GET['encuesta'] ?? '') === '1';

if ($mensajeActual === 'mensaje_enviado' || $mensajeActual === 'mensaje_vacio') {
    $panelCaso = 'conversacion';
}

if (!in_array($panelCaso, ['estructura', 'resumen', 'conversacion', 'acciones', 'archivos'], true)) {
    $panelCaso = 'estructura';
}

$abrirChatCaso = $panelCaso === 'conversacion';

if ($abrirChatCaso) {
    $panelCaso = 'estructura';
}

if ($rol === 2) {
    if ($idTicketSeleccionado > 0) {
        $modoGestor = 'detalle';
    } else {
        $modoGestor = 'mis_tickets';
    }
}

$parametrosListadoGestor = [
    'modo' => 'mis_tickets',
    'bandeja' => $bandejaGestor,
];

if ($busquedaGestor !== '') {
    $parametrosListadoGestor['buscar'] = $busquedaGestor;
}
if ($estadoBusquedaGestor !== 'todos') {
    $parametrosListadoGestor['estado_busqueda'] = $estadoBusquedaGestor;
}

$rutaListadoGestor = 'flujoTicket.php?' . http_build_query($parametrosListadoGestor);
$titulosBandejaGestor = [
    'abiertos' => 'Casos abiertos',
    'derivaciones' => 'Derivaciones pendientes',
    'pendientes' => 'Pendientes de calificación',
    'cerrados' => 'Casos cerrados',
    'derivaciones_cerradas' => 'Derivaciones completadas',
];
$descripcionesBandejaGestor = [
    'abiertos' => 'Etapas asignadas que ya están habilitadas para su gestión.',
    'derivaciones' => 'Derivaciones que usted creó y que todavía están en espera de resolución.',
    'pendientes' => 'Etapas o derivaciones listas que están a la espera de calificación para poder cerrarse.',
    'cerrados' => 'Casos donde usted participó en una etapa principal realmente activada y su gestión ya finalizó. No incluye cancelaciones.',
    'derivaciones_cerradas' => 'Derivaciones finalizadas que le fueron asignadas únicamente como apoyo, sin participación activa en una etapa principal. No incluye cancelaciones.',
];
$tituloBandejaGestor = $titulosBandejaGestor[$bandejaGestor];
$descripcionBandejaGestor = $descripcionesBandejaGestor[$bandejaGestor];

$rutaPanel = $rol === 1
    ? 'panelAdmin.php'
    : 'panelGestor.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tickets | SMARTDESK</title>
    <style>
        :root {
            --primary: #0f6fec;
            --primary-dark: #0a56bd;
            --navy: #102a43;
            --text: #243b53;
            --muted: #526d82;
            --bg: #f3f6fb;
            --surface: #fff;
            --border: #dce6f1;
            --soft: #eef5ff;
            --ok: #087443;
            --danger: #b42318;
            --warning: #a15c00;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: linear-gradient(135deg, #f5f8fc 0%, #edf3fa 100%);
            color: var(--text);
            font: 12px/1.4 Inter, "Segoe UI", Arial, sans-serif;
        }

        a { color: inherit; }

        .shell {
            width: min(1320px, calc(100% - 20px));
            margin: auto;
            padding: 8px 0 24px;
        }

        .topbar,
        .card,
        .modebar,
        .notice-panel {
            border: 1px solid var(--border);
            background: var(--surface);
            box-shadow: 0 8px 22px rgba(15, 45, 75, .055);
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            min-height: 54px;
            padding: 7px 10px;
            border-radius: 12px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 9px;
            min-width: 0;
        }

        .brand-mark {
            display: grid;
            flex: 0 0 34px;
            width: 34px;
            height: 34px;
            place-items: center;
            border-radius: 9px;
            background: linear-gradient(135deg, #0f6fec, #0b89e8);
            color: #fff;
            font-size: 11px;
            font-weight: 900;
            box-shadow: 0 6px 14px rgba(15, 111, 236, .22);
        }

        .topbar h1 {
            margin: 0;
            color: var(--navy);
            font-size: 16px;
            line-height: 1.1;
        }

        .topbar p {
            margin: 2px 0 0;
            color: var(--muted);
            font-size: 9px;
        }

        .actions {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 6px;
        }

        .btn,
        button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 31px;
            padding: 6px 10px;
            border: 0;
            border-radius: 7px;
            font: inherit;
            font-weight: 800;
            text-decoration: none;
            cursor: pointer;
        }

        .btn.primary,
        button.primary {
            background: linear-gradient(135deg, var(--primary), #0b84e8);
            color: #fff;
            box-shadow: 0 5px 12px rgba(15, 111, 236, .18);
        }

        .btn.light,
        button.light {
            background: var(--soft);
            color: #225c93;
        }

        .btn.outline {
            border: 1px solid #cbdcf0;
            background: #fff;
            color: #225c93;
        }

        .btn.danger { background: #fff1f0; color: var(--danger); }

        .modebar {
            display: flex;
            gap: 4px;
            margin-top: 8px;
            padding: 4px;
            border-radius: 10px;
        }

        .mode-link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            min-height: 32px;
            padding: 6px 11px;
            border-radius: 7px;
            color: #315f8d;
            font-weight: 800;
            text-decoration: none;
        }

        .mode-link.active {
            background: var(--primary);
            color: #fff;
            box-shadow: 0 5px 11px rgba(15, 111, 236, .18);
        }

        .count {
            min-width: 18px;
            padding: 1px 5px;
            border-radius: 999px;
            background: rgba(15, 111, 236, .1);
            text-align: center;
            font-size: 9px;
        }

        .mode-link.active .count { background: rgba(255, 255, 255, .2); }

        .alert {
            margin-top: 8px;
            padding: 8px 10px;
            border-radius: 8px;
            font-weight: 700;
        }

        .alert.ok { background: #eaf8f1; color: var(--ok); }
        .alert.error { background: #fff0ee; color: var(--danger); }

        .notice-panel {
            margin-top: 8px;
            border-radius: 10px;
            overflow: hidden;
        }

        .notice-panel summary {
            display: flex;
            align-items: center;
            gap: 7px;
            min-height: 36px;
            padding: 7px 11px;
            color: var(--navy);
            font-weight: 850;
            cursor: pointer;
            list-style: none;
        }

        .notice-panel summary::-webkit-details-marker { display: none; }
        .notice-panel summary::before { content: "▸"; color: var(--primary); }
        .notice-panel[open] summary::before { content: "▾"; }
        .notice-panel summary .unread { color: var(--primary); font-size: 9px; }

        .notice-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
            gap: 6px;
            padding: 0 8px 8px;
        }

        .notice-item {
            display: block;
            padding: 7px 9px;
            border: 1px solid var(--border);
            border-radius: 8px;
            text-decoration: none;
        }

        .notice-item.unread { border-color: #80b5f2; background: #f2f8ff; }
        .notice-item strong { display: block; color: var(--navy); font-size: 10px; }
        .notice-item span { display: block; margin-top: 2px; color: var(--muted); font-size: 9px; }

        .card {
            margin-top: 8px;
            padding: 12px;
            border-radius: 11px;
        }

        .card-head {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 9px;
        }

        .card h2,
        .card h3 {
            margin: 0;
            color: var(--navy);
        }

        .card h2 { font-size: 16px; }
        .card h3 { font-size: 13px; }
        .card-head p { margin: 2px 0 0; }
        .muted, .meta { color: var(--muted); }
        .meta { font-size: 9px; }

        [hidden] { display: none !important; }

        .ticket-wizard {
            max-width: 1280px;
            margin: 8px auto 0;
        }

        .wizard-progress {
            display: flex;
            align-items: center;
            gap: 7px;
            margin-bottom: 8px;
            padding: 7px 10px;
            border: 1px solid var(--border);
            border-radius: 10px;
            background: #fff;
            box-shadow: 0 8px 22px rgba(15, 45, 75, .045);
        }

        .wizard-step {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            color: #7890a6;
            font-size: 9px;
            font-weight: 850;
        }

        .wizard-step span {
            display: grid;
            width: 19px;
            height: 19px;
            place-items: center;
            border-radius: 50%;
            background: #eaf0f7;
            color: #526d82;
        }

        .wizard-step.active { color: var(--primary); }
        .wizard-step.active span { background: var(--primary); color: #fff; }
        .wizard-line { width: 22px; height: 1px; background: #d9e4ef; }

        .catalog-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(135px, 1fr));
            gap: 9px;
        }

        .catalog-option {
            display: flex;
            min-height: 112px;
            padding: 10px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: #fff;
            color: var(--navy);
            box-shadow: 0 6px 16px rgba(15, 45, 75, .035);
            flex-direction: column;
            justify-content: center;
            gap: 7px;
            transition: transform .18s ease, border-color .18s ease, box-shadow .18s ease, background .18s ease;
        }

        .catalog-option:hover {
            border-color: #8eb9eb;
            box-shadow: 0 9px 20px rgba(15, 111, 236, .09);
            transform: translateY(-2px);
        }

        .catalog-option.active {
            border-color: #175b91;
            background: linear-gradient(145deg, #23699f, #164f80);
            color: #fff;
            box-shadow: 0 10px 24px rgba(16, 75, 122, .22);
        }

        .catalog-visual {
            position: relative;
            display: grid;
            width: 43px;
            height: 43px;
            margin: 0 auto;
            place-items: center;
            overflow: hidden;
            border: 1px solid #d8e4f0;
            border-radius: 10px;
            background: #f7f9fc;
            color: #225c93;
            font-size: 16px;
            font-weight: 900;
        }

        .catalog-visual img {
            position: absolute;
            inset: 0;
            z-index: 1;
            width: 100%;
            height: 100%;
            padding: 5px;
            object-fit: contain;
            background: #fff;
        }

        .catalog-option strong { font-size: 11px; text-align: center; }
        .catalog-option small { color: var(--muted); font-size:9px; text-align: center; }
        .catalog-option.active small { color: rgba(255, 255, 255, .78); }

        .service-panel { scroll-margin-top: 8px; }

        .service-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 8px;
        }

        .service-option {
            display: flex;
            align-items: stretch;
            min-height: 105px;
            padding: 10px;
            border: 1px solid var(--border);
            border-radius: 10px;
            background: #fff;
            color: var(--text);
            text-align: left;
            flex-direction: column;
            justify-content: space-between;
            transition: border-color .18s ease, box-shadow .18s ease, transform .18s ease;
        }

        .service-option:hover,
        .service-option.active {
            border-color: #6fa9ec;
            box-shadow: 0 8px 18px rgba(15, 111, 236, .09);
            transform: translateY(-1px);
        }

        .service-option.active { background: #f2f8ff; }
        .service-option.unavailable {
            border-style: dashed;
            background: #fafbfd;
            box-shadow: none;
            cursor: not-allowed;
            opacity: .72;
        }
        .service-option.unavailable:hover { transform: none; }
        .service-name { display: block; margin: 0; color: var(--navy); font-size: 12px; font-weight: 850; }
        .service-option p { margin: 4px 0 8px; color: var(--muted); font-size: 9px; }

        .service-tags {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 4px;
        }

        .service-tag {
            padding: 3px 6px;
            border-radius: 999px;
            background: #eef5ff;
            color: #225c93;
            font-size:9px;
            font-weight: 800;
        }

        .service-tag.warning { background: #fff4df; color: #925400; }

        .service-empty {
            grid-column: 1 / -1;
            padding: 18px;
            border: 1px dashed #cbd8e6;
            border-radius: 9px;
            background: #fafbfd;
            color: var(--muted);
            text-align: center;
        }

        .service-choose {
            align-self: flex-end;
            margin-top: 7px;
            color: var(--primary);
            font-size: 9px;
            font-weight: 900;
        }

        .form-card {
            max-width: 980px;
            margin-right: auto;
            margin-left: auto;
            scroll-margin-top: 8px;
        }

        .selected-service {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 10px;
            padding: 8px 10px;
            border: 1px solid #cfe1f4;
            border-radius: 8px;
            background: #f2f8ff;
        }

        .selected-service strong { display: block; color: var(--navy); }
        .selected-service small { display: block; margin-top: 2px; color: var(--muted); }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 220px;
            gap: 8px 10px;
        }

        .field.full { grid-column: 1 / -1; }

        label {
            display: block;
            margin: 0 0 4px;
            color: var(--navy);
            font-weight: 800;
        }

        input,
        select,
        textarea {
            width: 100%;
            min-height: 34px;
            padding: 7px 9px;
            border: 1px solid #cad8e8;
            border-radius: 7px;
            background: #fff;
            color: var(--text);
            font: inherit;
            outline: none;
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: #6aa7ee;
            box-shadow: 0 0 0 3px rgba(15, 111, 236, .09);
        }

        textarea { min-height: 76px; resize: vertical; }
        input[type="file"] { padding: 5px 7px; }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 6px;
            margin-top: 9px;
        }

        .table-wrap {
            overflow-x: auto;
            border: 1px solid var(--border);
            border-radius: 9px;
        }

        .manager-case-filters {
            display: grid;
            grid-template-columns: minmax(260px, 1fr) minmax(190px, .34fr) auto;
            gap: 10px;
            align-items: end;
            margin: 0 0 12px;
            padding: 11px;
            border: 1px solid #dbe7f2;
            border-radius: 11px;
            background: #f8fbff;
        }

        .manager-filter-field { display: grid; gap: 5px; }
        .manager-filter-field label { color: var(--navy); font-size: 10px; font-weight: 850; }
        .manager-filter-field input,
        .manager-filter-field select { width: 100%; height: 38px; padding: 8px 10px; border-radius: 9px; }
        .manager-search-control { position: relative; }
        .manager-search-control input { padding-right: 38px; }
        .manager-filter-clear {
            position: absolute;
            top: 5px;
            right: 5px;
            width: 28px;
            height: 28px;
            min-height: 28px;
            display: grid;
            place-items: center;
            padding: 0;
            border: 0;
            border-radius: 7px;
            color: #617b91;
            background: #eef4fa;
            cursor: pointer;
            font-size: 17px;
        }

        .manager-filter-count {
            min-width: 118px;
            padding: 10px 11px;
            color: #486985;
            text-align: center;
            font-size: 10px;
            font-weight: 850;
            white-space: nowrap;
        }

        .manager-filter-empty td { padding: 28px; color: var(--muted); text-align: center; }

        body.manager-ticket-modal-open { overflow: hidden; }
        .manager-ticket-modal {
            position: fixed;
            inset: 0;
            z-index: 2147483100;
            display: grid;
            place-items: center;
            padding: 18px;
            background: rgba(7, 25, 45, .62);
            backdrop-filter: blur(4px);
        }

        .manager-ticket-modal-window {
            width: min(1280px, 100%);
            height: min(900px, calc(100dvh - 36px));
            max-height: calc(100dvh - 36px);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            border: 1px solid #cbdbea;
            border-radius: 16px;
            background: #f4f7fb;
            box-shadow: 0 30px 90px rgba(4, 25, 48, .36);
        }

        .manager-ticket-modal-bar {
            min-height: 54px;
            display: flex;
            flex: 0 0 auto;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 10px 14px;
            border-bottom: 1px solid var(--border);
            background: #fff;
        }

        .manager-ticket-modal-bar strong,
        .manager-ticket-modal-bar small { display: block; }
        .manager-ticket-modal-bar strong { color: var(--navy); font-size: 14px; }
        .manager-ticket-modal-bar small { margin-top: 2px; color: var(--muted); font-size: 9px; }
        .case-back-link { display: inline-flex; align-items: center; width: fit-content; margin-bottom: 6px; text-decoration: none; }
        .manager-ticket-modal-close {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            min-height: 34px;
            padding: 7px 10px;
            border: 1px solid #cbdbea;
            border-radius: 9px;
            color: #315b7e;
            background: #fff;
            font: inherit;
            font-weight: 850;
            cursor: pointer;
        }

        .manager-ticket-modal-close span:first-child { font-size: 18px; line-height: 1; }
        .manager-ticket-modal-scroll {
            flex: 1 1 auto;
            min-height: 0;
            display: grid;
            gap: 10px;
            padding: 12px;
            overflow-y: auto;
            overscroll-behavior: contain;
        }

        .manager-ticket-modal-scroll > .card,
        .manager-ticket-modal-scroll > .closure-banner { margin: 0; }

        /* El caso abierto se integra en el módulo y aprovecha todo el contenido. */
        .case-detail-page { width: 100%; max-width: none; }
        .case-detail-page .manager-ticket-modal {
            position: static;
            inset: auto;
            z-index: auto;
            display: block;
            width: 100%;
            padding: 0;
            background: transparent;
            backdrop-filter: none;
        }
        .case-detail-page .manager-ticket-modal-window {
            width: 100%;
            height: auto;
            max-height: none;
            overflow: visible;
            border-radius: 13px;
            box-shadow: none;
        }
        .case-detail-page .manager-ticket-modal-scroll { overflow: visible; }
        body.mesa-flujo-navigating main.shell {
            opacity: .72;
            pointer-events: none;
            transition: opacity .12s ease;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 760px;
        }

        th,
        td {
            padding: 8px 9px;
            border-bottom: 1px solid #e8eef5;
            text-align: left;
            vertical-align: middle;
        }

        th {
            background: #f7f9fc;
            color: #526d82;
            font-size: 9px;
            letter-spacing: .04em;
            text-transform: uppercase;
        }

        tbody tr:last-child td { border-bottom: 0; }
        tbody tr:hover { background: #f8fbff; }
        .ticket-title { color: var(--navy); font-weight: 800; }
        .ticket-title small {
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            line-clamp: 2;
            overflow: hidden;
            margin-top: 3px;
            color: var(--muted);
            font-weight: 500;
            line-height: 1.35;
            overflow-wrap: anywhere;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 3px 7px;
            background: var(--soft);
            color: #225c93;
            font-size: 9px;
            font-weight: 850;
        }

        .empty {
            padding: 22px 10px;
            color: var(--muted);
            text-align: center;
        }

        .ticket-summary {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 12px;
            align-items: start;
        }

        .ticket-summary h2 { margin-top: 5px; }
        .ticket-summary p { margin: 6px 0 0; }

        .manager-request-copy {
            margin-top: 10px;
            padding: 9px 11px;
            border: 1px solid var(--mesa-theme-border, var(--border));
            border-radius: 9px;
            background: var(--mesa-theme-soft, #f6f9fc);
        }

        .manager-request-copy > span {
            display: block;
            color: var(--mesa-theme-muted, var(--muted));
            font-size: 9px;
            font-weight: 850;
            letter-spacing: .05em;
            text-transform: uppercase;
        }

        .manager-request-copy .description {
            margin-top: 4px;
            padding-top: 0;
            border-top: 0;
            color: var(--mesa-theme-text, var(--text));
        }

        .manager-tree-help {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 7px;
            margin-bottom: 9px;
        }

        .manager-tree-help > span {
            min-width: 0;
            display: grid;
            grid-template-columns: 25px minmax(0, 1fr);
            gap: 0 8px;
            align-items: center;
            padding: 8px 9px;
            border: 1px solid var(--mesa-theme-border, var(--border));
            border-radius: 9px;
            color: var(--mesa-theme-text, var(--text));
            background: var(--mesa-theme-soft, #f6f9fc);
        }

        .manager-tree-help b {
            grid-row: 1 / 3;
            width: 25px;
            height: 25px;
            display: grid;
            place-items: center;
            border-radius: 8px;
            color: var(--mesa-theme-on-primary, #fff);
            background: var(--mesa-shell-color, var(--primary));
        }

        .manager-tree-help strong,
        .manager-tree-help small { display: block; min-width: 0; }
        .manager-tree-help strong { color: var(--mesa-theme-heading, var(--navy)); font-size: 10px; }
        .manager-tree-help small { color: var(--mesa-theme-muted, var(--muted)); font-size: 8.5px; }

        .description {
            padding-top: 8px;
            border-top: 1px solid #edf1f6;
            white-space: pre-wrap;
        }

        .timeline {
            display: grid;
            gap: 6px;
            padding: 2px 0 4px;
        }

        .audit-log {
            display: grid;
            grid-template-columns: 1fr;
            gap: 0;
            counter-reset: audit-event;
            padding-left: 18px;
        }

        .audit-item {
            position: relative;
            min-height: 82px;
            padding: 10px 12px 10px 18px;
            border: 1px solid var(--border);
            border-radius: 8px;
            background: var(--mesa-theme-surface, #fbfdff);
            counter-increment: audit-event;
        }

        .audit-item + .audit-item { margin-top: 8px; }

        .audit-item::before {
            content: counter(audit-event);
            position: absolute;
            top: 12px;
            left: -29px;
            width: 24px;
            height: 24px;
            display: grid;
            place-items: center;
            border: 3px solid var(--mesa-theme-surface, #fff);
            border-radius: 50%;
            color: var(--mesa-theme-on-primary, #fff);
            background: var(--mesa-shell-color, var(--primary));
            font-size: 9px;
            font-weight: 900;
            z-index: 1;
        }

        .audit-item:not(:last-child)::after {
            content: "";
            position: absolute;
            top: 35px;
            bottom: -12px;
            left: -18px;
            width: 2px;
            background: var(--mesa-theme-border, var(--border));
        }

        .audit-item strong { color: var(--mesa-theme-heading, var(--navy)); }
        .audit-item p { margin: 7px 0; white-space: pre-wrap; }
        .audit-item-head,
        .audit-item-meta {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
        }
        .audit-item-label {
            display: block;
            margin-bottom: 3px;
            color: var(--muted);
            font-size: 8px;
            font-weight: 800;
            letter-spacing: .04em;
            text-transform: uppercase;
        }
        .audit-item-time { color: var(--muted); font-size: 9px; white-space: nowrap; }
        .audit-item-meta {
            justify-content: flex-start;
            padding-top: 7px;
            border-top: 1px solid var(--mesa-theme-border, var(--border));
            color: var(--muted);
            font-size: 9px;
        }
        .audit-item-meta b { color: var(--mesa-theme-heading, var(--navy)); }

        .action-summary {
            margin-bottom: 10px;
            padding: 11px;
            border: 1px solid var(--mesa-theme-border, #bfd6ea);
            border-radius: 10px;
            background: var(--mesa-theme-soft, #f6fbff);
        }
        .action-summary > summary {
            cursor: pointer;
            list-style: none;
        }
        .action-summary > summary::-webkit-details-marker { display: none; }
        .action-summary > summary::before {
            content: "+";
            display: grid;
            place-items: center;
            flex: 0 0 22px;
            width: 22px;
            height: 22px;
            border-radius: 7px;
            color: var(--mesa-theme-on-primary, #fff);
            background: var(--mesa-shell-color, var(--primary));
            font-size: 15px;
        }
        .action-summary[open] > summary::before { content: "−"; }
        .action-summary-body { padding-top: 9px; }
        .action-summary-head {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            gap: 10px;
            color: var(--navy);
        }
        .action-summary-head .case-status { margin-left: auto; }
        .action-summary-grid,
        .action-rating-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
            gap: 6px;
        }
        .action-summary-grid > div,
        .action-rating-summary > div {
            min-height: 52px;
            padding: 7px 8px;
            border: 1px solid var(--mesa-theme-border, #dce8f2);
            border-radius: 8px;
            background: var(--mesa-theme-surface, #fff);
        }
        .action-summary-grid span,
        .action-rating-summary span {
            display: block;
            color: var(--muted);
            font-size:9px;
            font-weight: 750;
            text-transform: uppercase;
        }
        .action-summary-grid strong,
        .action-rating-summary strong {
            display: block;
            margin-top: 4px;
            color: var(--navy);
            font-size: 10px;
        }
        .action-rating-summary { margin-top: 7px; }
        .action-detail { margin-top: 7px; }
        .action-detail summary {
            cursor: pointer;
            color: #155f9e;
            font-size: 9.5px;
            font-weight: 800;
        }
        .action-detail p {
            margin: 6px 0 0;
            padding: 8px;
            border-radius: 7px;
            background: #fff;
            white-space: pre-wrap;
        }

        .step {
            position: relative;
            width: calc(100% - min(calc(var(--level, 0) * 28px), 55%));
            margin-left: min(calc(var(--level, 0) * 28px), 55%);
            min-height: 86px;
            padding: 8px 9px;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: #fff;
        }

        .step::before {
            content: "";
            position: absolute;
            top: 18px;
            right: 100%;
            width: min(calc(var(--level, 0) * 28px), 55%);
            border-top: 2px solid #b8cce0;
        }

        .step-link {
            position: absolute;
            inset: 0;
            border-radius: inherit;
            z-index: 1;
        }

        .step-content { position: relative; z-index: 2; pointer-events: none; }
        .step.selected { box-shadow: 0 0 0 2px rgba(15,111,236,.22); }

        .step.bloqueada { opacity: .55; background: #f7f9fb; }
        .step.pendiente,
        .step.en_proceso,
        .step.en_espera_solicitante { border-color: #70abef; background: #f2f8ff; }
        .step.pausada { border-color: #e2aa55; background: #fff8ec; }
        .step.completada { border-color: #7bc6a2; background: #f0faf5; }
        .step strong { display: block; margin-bottom: 3px; color: var(--navy); }
        .step .meta { margin-top: 2px; }

        .tree-toolbar {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 6px;
        }

        .case-tree {
            display: grid;
            gap: 7px;
            padding: 2px 0 4px;
        }

        .case-branch,
        .case-leaf {
            margin: 0;
            border: 0;
        }

        .case-branch > summary {
            list-style: none;
            cursor: pointer;
        }

        .case-branch > summary::-webkit-details-marker { display: none; }

        .case-row {
            display: grid;
            grid-template-columns: 26px minmax(220px, 1.25fr) minmax(230px, .9fr) auto;
            gap: 7px 10px;
            align-items: center;
            min-height: 66px;
            padding: 9px 10px;
            border: 1px solid var(--border);
            border-left: 4px solid #8ba6bf;
            border-radius: 10px;
            background: #fff;
            box-shadow: 0 4px 12px rgba(15, 45, 75, .035);
            transition: border-color .18s ease, box-shadow .18s ease, background .18s ease;
        }

        .case-branch > summary:hover,
        .case-leaf .case-row:hover {
            border-color: #9fc2e9;
            background: #fbfdff;
            box-shadow: 0 7px 18px rgba(15, 83, 148, .08);
        }

        .case-branch.selected > summary,
        .case-leaf.selected .case-row {
            border-color: #4c96ea;
            background: #f2f8ff;
            box-shadow: 0 0 0 2px rgba(15, 111, 236, .14);
        }

        .case-branch.pausada > summary,
        .case-leaf.pausada .case-row { border-left-color: #e2a03d; }
        .case-branch.completada > summary,
        .case-leaf.completada .case-row { border-left-color: #42a878; }
        .case-branch.en_proceso > summary,
        .case-leaf.en_proceso .case-row { border-left-color: #368ce4; }
        .case-branch.pendiente > summary,
        .case-leaf.pendiente .case-row { border-left-color: #6ba7e7; }
        .case-branch.bloqueada > summary,
        .case-leaf.bloqueada .case-row {
            border-left-color: #aebdcb;
            background: #f8fafc;
            opacity: .72;
        }

        .branch-chevron,
        .branch-dot {
            display: grid;
            width: 24px;
            height: 24px;
            place-items: center;
            border-radius: 7px;
            background: #edf5ff;
            color: var(--primary);
            font-size: 12px;
            font-weight: 900;
        }

        .branch-chevron::before { content: "+"; }
        .case-branch[open] > summary .branch-chevron::before { content: "−"; }
        .branch-dot::before { content: "•"; }

        .case-row-main { min-width: 0; }

        .case-code-line {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 5px;
            margin-bottom: 2px;
        }

        .case-code {
            color: #0b5fae;
            font-size: 10px;
            font-weight: 900;
        }

        .case-status {
            display: inline-flex;
            padding: 2px 6px;
            border-radius: 999px;
            background: #eef3f8;
            color: #526d82;
            font-size:9px;
            font-weight: 850;
        }

        .case-status.completada { background: #e7f7ef; color: #087443; }
        .case-status.listo_cierre { background: #fff5d8; color: #8a5a00; }
        .checklist-gate {
            display: flex;
            gap: 10px;
            align-items: flex-start;
            margin: 0 0 14px;
            padding: 12px 14px;
            border: 1px solid #f2c36b;
            border-radius: 12px;
            background: #fff8e8;
            color: #744a00;
            font-size: 14px;
            line-height: 1.45;
        }
        .checklist-gate[hidden] { display: none; }
        .checklist-gate-icon { font-size: 20px; line-height: 1; }
        .checklist-gated-button[aria-disabled="true"] {
            opacity: .58;
            cursor: not-allowed;
            filter: grayscale(.15);
        }
        .checklist-row-missing {
            border-left: 3px solid #e7a52b;
            padding-left: 9px;
        }
        .case-status.pausada { background: #fff2dc; color: #9a5a00; }
        .case-status.en_proceso,
        .case-status.pendiente { background: #e8f3ff; color: #0b63b6; }

        .case-title,
        .case-service { display: block; }
        .case-title { overflow: hidden; color: var(--navy); font-size: 12px; text-overflow: ellipsis; white-space: nowrap; }
        .case-service { margin-top: 1px; overflow: hidden; color: var(--text); text-overflow: ellipsis; white-space: nowrap; }

        .case-row-meta {
            display: grid;
            gap: 2px;
            color: var(--muted);
            font-size: 9px;
        }

        .case-row-meta b { color: #46647f; }
        .case-open { position: relative; z-index: 2; min-width: 78px; }

        .branch-action {
            grid-column: 2 / 4;
            color: #1767ad;
            font-size: 9px;
            font-weight: 850;
        }

        .case-branch:not([open]) .when-open,
        .case-branch[open] .when-closed { display: none; }

        .case-children {
            display: grid;
            gap: 7px;
            margin: 7px 0 1px 18px;
            padding-left: 17px;
            border-left: 2px solid #c8dbed;
        }

        .case-children > .case-branch,
        .case-children > .case-leaf { position: relative; }

        .case-children > .case-branch::before,
        .case-children > .case-leaf::before {
            content: "";
            position: absolute;
            top: 31px;
            right: 100%;
            width: 17px;
            border-top: 2px solid #c8dbed;
        }

        .case-dialog {
            width: min(1180px, calc(100% - 28px));
            max-width: none;
            height: min(850px, calc(100dvh - 28px));
            max-height: none;
            margin: auto;
            padding: 0;
            border: 0;
            border-radius: 15px;
            background: #f4f7fb;
            color: var(--text);
            box-shadow: 0 28px 90px rgba(9, 32, 56, .32);
        }

        .case-dialog::backdrop {
            background: rgba(8, 28, 49, .66);
            backdrop-filter: blur(3px);
        }

        .case-dialog.is-embedded {
            position: static;
            inset: auto;
            width: 100%;
            max-width: none;
            height: auto;
            max-height: none;
            margin: 0;
            overflow: visible;
            border: 1px solid var(--border);
            border-radius: 13px;
            box-shadow: none;
        }
        body:has(.case-detail-page) {
            overflow-x: hidden !important;
            overflow-y: auto !important;
        }
        body:has(.case-detail-page) .case-detail-page,
        .case-dialog.is-embedded,
        .case-dialog.is-embedded .case-modal-shell,
        .case-dialog.is-embedded .case-modal-content {
            overscroll-behavior-y: auto;
            touch-action: pan-y;
        }
        .case-dialog.is-embedded::backdrop { display: none; }
        .case-dialog.is-embedded .case-modal-shell {
            height: auto;
            min-height: min(720px, calc(100dvh - 70px));
            overflow: visible;
        }
        .case-dialog.is-embedded .case-modal-header { position: sticky; top: 0; z-index: 5; }
        .case-dialog.is-embedded .case-modal-content {
            flex: 0 0 auto;
            min-height: 520px;
            overflow: visible;
        }

        .case-modal-shell {
            position: relative;
            display: flex;
            height: 100%;
            flex-direction: column;
            overflow: hidden;
        }

        .case-modal-header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            padding: 15px 17px 12px;
            border-bottom: 1px solid var(--border);
            background: #fff;
        }

        .case-modal-title-line {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 7px;
        }

        .case-modal-header h2 { margin: 0; color: var(--navy); font-size: 18px; }
        .case-modal-header p { margin: 3px 0 0; color: var(--muted); }

        .case-modal-header-actions {
            display: flex;
            flex: 0 0 auto;
            align-items: center;
            gap: 8px;
        }

        .case-modal-header .case-chat-launcher {
            position: relative;
            right: auto;
            bottom: auto;
            min-height: 38px;
            padding: 5px 11px 5px 6px;
            border-radius: 10px;
            box-shadow: 0 5px 13px rgba(15, 111, 236, .2);
        }

        .case-modal-header .case-chat-launcher-icon {
            width: 28px;
            height: 28px;
        }

        .case-modal-header .case-chat-launcher-copy small { display: none; }
        .case-modal-header .case-chat-launcher[hidden] { display: none !important; }

        .modal-close {
            flex: 0 0 34px;
            width: 34px;
            height: 34px;
            min-height: 34px;
            padding: 0;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: #fff;
            color: #526d82;
            font-size: 18px;
        }

        .case-tabs {
            display: flex;
            gap: 4px;
            padding: 7px 12px 0;
            border-bottom: 1px solid var(--border);
            background: #fff;
            overflow-x: auto;
        }

        .case-tab {
            min-height: 36px;
            padding: 7px 11px;
            border-bottom: 3px solid transparent;
            border-radius: 7px 7px 0 0;
            background: transparent;
            color: #526d82;
            white-space: nowrap;
        }

        .case-tab.active {
            border-bottom-color: var(--primary);
            background: #eef6ff;
            color: #0b5fae;
        }

        .case-modal-content {
            flex: 1;
            min-height: 0;
            padding: 12px;
            overflow-y: auto;
        }

        .case-pane { display: grid; gap: 10px; }
        .case-pane[hidden] { display: none !important; }

        .case-dialog-panes,
        .case-dialog-panes > div { display: contents; }

        .case-dialog .card {
            margin: 0;
            padding: 12px;
            border-radius: 11px;
            box-shadow: none;
        }

        .case-dialog .case-pane + .case-pane { margin-top: 0; }

        .case-panel-section {
            padding: 12px;
            border: 1px solid var(--border);
            border-radius: 11px;
            background: #fff;
        }

        .case-panel-section > h3 { margin: 0 0 8px; color: var(--navy); font-size: 13px; }

        .case-panel-toggle {
            border: 1px solid var(--border);
            border-radius: 10px;
            background: #fff;
            overflow: hidden;
        }

        .case-panel-toggle > summary {
            padding: 10px 12px;
            color: var(--navy);
            font-weight: 850;
            cursor: pointer;
            list-style: none;
        }

        .case-panel-toggle > summary::-webkit-details-marker { display: none; }
        .case-panel-toggle > summary::before { content: "+"; display: inline-block; width: 18px; color: var(--primary); }
        .case-panel-toggle[open] > summary::before { content: "−"; }
        .case-panel-toggle-body { padding: 0 12px 12px; }

        .case-toggle-copy {
            display: inline-grid;
            max-width: calc(100% - 24px);
            vertical-align: middle;
        }

        .case-toggle-copy strong {
            color: var(--mesa-theme-heading, var(--navy));
            font-size: 11px;
        }

        .case-toggle-copy small {
            margin-top: 2px;
            color: var(--mesa-theme-muted, var(--muted));
            font-size: 9px;
            font-weight: 600;
            line-height: 1.4;
        }

        .manager-task-guide {
            padding: 12px;
            border: 1px solid color-mix(in srgb, var(--mesa-shell-color, var(--primary)) 45%, var(--mesa-theme-border, var(--border)));
            border-left: 5px solid var(--mesa-shell-color, var(--primary));
            border-radius: 11px;
            color: var(--mesa-theme-text, var(--text));
            background: color-mix(in srgb, var(--mesa-shell-color, var(--primary)) 9%, var(--mesa-theme-surface, #fff));
        }

        .manager-task-guide.pendiente,
        .manager-task-guide.pausada {
            border-color: color-mix(in srgb, var(--mesa-state-warning, #f5b82e) 58%, var(--mesa-theme-border, var(--border)));
            border-left-color: var(--mesa-state-warning, #f5b82e);
            background: color-mix(in srgb, var(--mesa-state-warning, #f5b82e) 9%, var(--mesa-theme-surface, #fff));
        }

        .manager-task-guide.completada {
            border-color: color-mix(in srgb, var(--mesa-state-success, #087443) 55%, var(--mesa-theme-border, var(--border)));
            border-left-color: var(--mesa-state-success, #087443);
            background: color-mix(in srgb, var(--mesa-state-success, #087443) 8%, var(--mesa-theme-surface, #fff));
        }

        .manager-guide-head {
            display: grid;
            grid-template-columns: 35px minmax(0, 1fr);
            gap: 10px;
            align-items: start;
        }

        .manager-guide-icon {
            width: 35px;
            height: 35px;
            display: grid;
            place-items: center;
            border-radius: 10px;
            color: var(--mesa-theme-on-primary, #fff);
            background: var(--mesa-shell-color, var(--primary));
            font-size: 19px;
            font-weight: 900;
        }

        .manager-guide-kicker {
            display: block;
            color: var(--mesa-theme-link, var(--primary));
            font-size: 8.5px;
            font-weight: 900;
            letter-spacing: .07em;
            text-transform: uppercase;
        }

        .manager-task-guide h3 { margin: 2px 0 0; color: var(--mesa-theme-heading, var(--navy)); font-size: 13px; }
        .manager-task-guide p { margin: 3px 0 0; color: var(--mesa-theme-muted, var(--muted)); font-size: 10px; }

        .manager-guide-steps {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 6px;
            margin-top: 10px;
        }

        .manager-guide-steps > span {
            min-width: 0;
            display: grid;
            grid-template-columns: 25px minmax(0, 1fr);
            gap: 7px;
            align-items: center;
            padding: 7px 8px;
            border: 1px solid var(--mesa-theme-border, var(--border));
            border-radius: 9px;
            background: var(--mesa-theme-surface, #fff);
        }

        .manager-guide-steps b {
            width: 25px;
            height: 25px;
            display: grid;
            place-items: center;
            border-radius: 50%;
            color: var(--mesa-theme-muted, var(--muted));
            background: var(--mesa-theme-soft, #edf3f8);
        }

        .manager-guide-steps .done b { color: var(--mesa-state-on, #fff); background: var(--mesa-state-success, #087443); }
        .manager-guide-steps .current { border-color: var(--mesa-shell-color, var(--primary)); }
        .manager-guide-steps .current b { color: var(--mesa-theme-on-primary, #fff); background: var(--mesa-shell-color, var(--primary)); }
        .manager-guide-steps strong,
        .manager-guide-steps small { display: block; }
        .manager-guide-steps strong { color: var(--mesa-theme-heading, var(--navy)); font-size: 9.5px; }
        .manager-guide-steps small { color: var(--mesa-theme-muted, var(--muted)); font-size: 8px; }

        .manager-email-preference { padding: 8px 10px; }
        .manager-email-preference .email-preference-copy p { margin: 2px 0 4px; }
        .manager-action-panel[open] { border-color: color-mix(in srgb, var(--mesa-shell-color, var(--primary)) 50%, var(--mesa-theme-border, var(--border))); }
        .manager-exception-panel { opacity: .88; }

        .case-panel-toggle.derivation-panel,
        .case-panel-toggle.derivation-panel[open] {
            position: relative;
            z-index: 25;
            overflow: visible;
        }

        .case-modal-content .stage-summary {
            grid-template-columns: repeat(4, minmax(0, 1fr));
            margin: 0;
        }

        .case-modal-content .audit-log { grid-template-columns: repeat(auto-fit, minmax(270px, 1fr)); }

        body.case-modal-open { overflow: hidden; }

        .detail-grid {
            display: grid;
            grid-template-columns: minmax(0, 1.45fr) minmax(300px, .75fr);
            gap: 8px;
            align-items: start;
        }

        .detail-grid .card { margin-top: 0; margin-bottom: 8px; }

        .case-dialog .detail-grid.case-dialog-panes,
        .case-dialog .detail-grid.case-dialog-panes > div {
            display: contents;
        }

        .case-dialog .detail-grid.case-dialog-panes .card { margin-bottom: 0; }

        .case-chat-widget{position:absolute;inset:0;z-index:50;pointer-events:none}.case-chat-launcher{position:absolute;right:20px;bottom:18px;display:flex;align-items:center;gap:9px;min-height:50px;padding:9px 15px 9px 10px;border:0;border-radius:999px;color:#fff;background:linear-gradient(145deg,#0f6fec,#0b4fae);box-shadow:0 14px 30px rgba(7,63,126,.34);font:inherit;font-weight:850;cursor:pointer;pointer-events:auto;transition:.18s ease}.case-chat-launcher:hover{transform:translateY(-2px)}.case-chat-launcher-icon{width:33px;height:33px;display:grid;place-items:center;border-radius:50%;background:rgba(255,255,255,.17)}.case-chat-launcher svg,.case-chat-header svg,.case-chat-send svg,.case-chat-attach svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.case-chat-launcher-copy{display:grid;text-align:left}.case-chat-launcher-copy small{font-size:8px;font-weight:650;opacity:.82}.case-chat-panel{position:absolute;right:14px;bottom:14px;width:min(440px,calc(100% - 28px));height:min(660px,calc(100% - 28px));display:flex;flex-direction:column;overflow:hidden;border:1px solid #bfd3e6;border-radius:19px;background:#fff;box-shadow:0 22px 65px rgba(4,30,60,.38);opacity:0;transform:translateY(20px) scale(.96);transform-origin:bottom right;pointer-events:none;transition:opacity .2s ease,transform .2s ease}.case-chat-widget.is-open .case-chat-panel{opacity:1;transform:none;pointer-events:auto}.case-chat-widget.is-open .case-chat-launcher{opacity:0;transform:translateY(10px);pointer-events:none}.case-chat-header{display:flex;align-items:center;gap:10px;padding:13px 14px;color:#fff;background:linear-gradient(135deg,#0d355f,#0f6fec)}.case-chat-avatar{width:39px;height:39px;display:grid;flex:0 0 auto;place-items:center;border-radius:50%;background:rgba(255,255,255,.16)}.case-chat-header-copy{min-width:0;flex:1}.case-chat-header-copy strong,.case-chat-header-copy span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.case-chat-header-copy strong{font-size:13px}.case-chat-header-copy span{margin-top:2px;font-size:9px;opacity:.82}.case-chat-close{width:33px;height:33px;display:grid;place-items:center;border:0;border-radius:50%;color:#fff;background:rgba(255,255,255,.12);font-size:21px;cursor:pointer}.case-chat-stage{padding:9px 11px;border-bottom:1px solid #dce7f1;background:#f7faff}.case-chat-stage label{display:block;margin-bottom:4px;color:#526d82;font-size:8px;font-weight:850;text-transform:uppercase;letter-spacing:.06em}.case-chat-stage select{width:100%;height:35px;padding:7px 30px 7px 9px;border:1px solid #cbdbea;border-radius:9px;color:#173b5d;background:#fff;font:inherit;font-size:10px;font-weight:750}.case-chat-timeline{min-height:0;flex:1;display:grid;align-content:start;gap:8px;overflow-y:auto;padding:15px 12px;background:linear-gradient(rgba(245,249,253,.94),rgba(245,249,253,.94)),radial-gradient(circle at 12px 12px,#dbe7f1 1px,transparent 1px);background-size:auto,24px 24px;overscroll-behavior:contain}.case-chat-empty{margin:auto;padding:26px 16px;color:#637b90;text-align:center;font-size:10px}.case-chat-bubble{position:relative;max-width:85%;justify-self:start;padding:8px 10px 7px;border:1px solid #d4e0eb;border-radius:5px 14px 14px 14px;background:#fff;box-shadow:0 3px 9px rgba(31,65,94,.06)}.case-chat-bubble.mine{justify-self:end;border-color:#9dc5ef;border-radius:14px 5px 14px 14px;background:#e8f3ff}.case-chat-author{display:block;margin-bottom:3px;color:#1769aa;font-size:8px;font-weight:900}.case-chat-text{margin:0;color:#203d58;font-size:11px;line-height:1.48;white-space:pre-wrap;overflow-wrap:anywhere}.case-chat-time{display:flex;align-items:center;justify-content:flex-end;gap:4px;margin-top:4px;color:#6c8295;font-size:8px}.case-chat-time .read-mark{color:#0f6fec;font-size:10px;font-weight:900}.case-chat-bubble.is-file{width:min(315px,85%);padding:7px}.case-chat-attachment{display:block;color:inherit;text-decoration:none}.case-chat-image{width:100%;max-height:210px;display:block;border-radius:9px;object-fit:cover;background:#dfe9f2}.case-chat-file-card{display:grid;grid-template-columns:38px minmax(0,1fr) 24px;gap:8px;align-items:center;padding:8px;border-radius:9px;background:rgba(255,255,255,.72)}.case-chat-file-icon{width:38px;height:38px;display:grid;place-items:center;border-radius:9px;color:#0f6fec;background:#e8f2ff}.case-chat-file-icon svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8}.case-chat-file-copy{min-width:0}.case-chat-file-copy strong,.case-chat-file-copy span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.case-chat-file-copy strong{color:#173b5d;font-size:9px}.case-chat-file-copy span{margin-top:2px;color:#6a8093;font-size:8px}.case-chat-download{color:#0f6fec;font-size:16px;text-align:center}.case-chat-file-status{min-height:17px;padding:4px 12px 0;color:#526d82;background:#fff;font-size:8px}.case-chat-file-status:empty{display:none}.case-chat-compose{flex:0 0 auto;padding:8px 9px 9px;border-top:1px solid #dce7f1;background:#fff}.case-chat-compose-row{display:grid;grid-template-columns:37px minmax(0,1fr) 39px;gap:6px;align-items:end}.case-chat-file-input{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}.case-chat-attach,.case-chat-send{height:37px;display:grid;place-items:center;border:0;border-radius:50%;cursor:pointer}.case-chat-attach{color:#315f87;background:#edf3f8}.case-chat-send{color:#fff;background:#0f6fec;box-shadow:0 5px 12px rgba(15,111,236,.22)}.case-chat-compose textarea{width:100%;height:37px;min-height:37px;max-height:108px;padding:9px 11px;border:1px solid #cbdbea;border-radius:19px;color:#203d58;background:#f8fbfe;outline:none;resize:none;font:inherit;font-size:10px;line-height:1.42}.case-chat-compose textarea:focus{border-color:#6ba9eb;box-shadow:0 0 0 3px rgba(15,111,236,.1)}.case-chat-readonly{margin:0;padding:8px 11px;color:#5e7488;border-top:1px solid #dce7f1;background:#f3f6f9;text-align:center;font-size:9px}

        /* Mantiene la conversación por encima de la navegación y controles flotantes. */
        .case-chat-widget{z-index:2147483635}
        .case-chat-stage{background:linear-gradient(180deg,#f8fbff,#f3f8fd)}
        .case-chat-stage-label{display:block;margin-bottom:5px;color:#526d82;font-size:8px;font-weight:850;text-transform:uppercase;letter-spacing:.07em}
        .case-chat-picker{position:relative}
        .case-chat-picker summary{display:grid;grid-template-columns:31px minmax(0,1fr) auto 27px;gap:8px;align-items:center;min-height:47px;padding:7px 8px;border:1px solid #c6d9eb;border-radius:11px;color:#173b5d;background:#fff;box-shadow:0 4px 12px rgba(31,65,94,.06);cursor:pointer;list-style:none;transition:border-color .16s ease,box-shadow .16s ease}
        .case-chat-picker summary::-webkit-details-marker{display:none}
        .case-chat-picker summary:hover,.case-chat-picker[open] summary{border-color:#7fb4ea;box-shadow:0 0 0 3px rgba(15,111,236,.09)}
        .case-chat-stage-number{width:31px;height:31px;display:grid;place-items:center;border-radius:9px;color:#fff;background:linear-gradient(145deg,#0f6fec,#0b4fae);font-size:10px;font-weight:900}
        .case-chat-stage-current{min-width:0}.case-chat-stage-current strong,.case-chat-stage-current small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.case-chat-stage-current strong{color:#173b5d;font-size:10px}.case-chat-stage-current small{margin-top:1px;color:#637d94;font-size:8px;font-weight:650}
        .case-chat-stage-arrow{width:27px;height:27px;display:grid;place-items:center;border-radius:8px;color:#3972a7;background:#edf5fd;transition:transform .18s ease}.case-chat-stage-arrow svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}.case-chat-picker[open] .case-chat-stage-arrow{transform:rotate(180deg)}
        .case-chat-stage-options{position:absolute;z-index:4;top:calc(100% + 6px);right:0;left:0;max-height:210px;display:grid;gap:4px;overflow-y:auto;padding:6px;border:1px solid #c6d9eb;border-radius:11px;background:#fff;box-shadow:0 16px 34px rgba(16,42,67,.2)}
        .case-chat-stage-option{display:grid;grid-template-columns:29px minmax(0,1fr) auto 22px;gap:8px;align-items:center;min-height:43px;padding:6px 7px;border-radius:9px;color:#31546f;text-decoration:none;transition:background .15s ease,color .15s ease}.case-chat-stage-option:hover{color:#0b4fae;background:#eef6ff}.case-chat-stage-option.is-active{color:#0b4fae;background:#e7f2ff}
        .case-chat-stage-option-number{width:29px;height:29px;display:grid;place-items:center;border-radius:8px;color:#3972a7;background:#edf4fb;font-size:9px;font-weight:900}.case-chat-stage-option.is-active .case-chat-stage-option-number{color:#fff;background:#0f6fec}
        .case-chat-stage-option-copy{min-width:0}.case-chat-stage-option-copy strong,.case-chat-stage-option-copy small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.case-chat-stage-option-copy strong{font-size:9px}.case-chat-stage-option-copy small{margin-top:1px;color:#71879a;font-size:8px}.case-chat-stage-check{color:#0f6fec;font-size:15px;font-weight:900;text-align:center}
        .case-chat-unread{min-width:19px;height:19px;display:inline-grid;place-items:center;padding:0 5px;border:1px solid color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 72%,var(--mesa-theme-border,#d9e4ed));border-radius:999px;color:var(--mesa-theme-on-primary,#fff);background:var(--mesa-shell-color,#0f6fec);box-shadow:0 3px 9px color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 28%,transparent);font-size:8px;font-weight:950;line-height:1}.case-chat-unread[hidden]{display:none!important}.case-chat-launcher{position:absolute}.case-chat-launcher-unread{position:absolute;top:-5px;right:-5px;z-index:2;min-width:22px;height:22px;font-size:9px}
        .case-chat-selection-empty{min-height:0;flex:1;display:grid;place-items:center;padding:28px 20px;color:var(--mesa-theme-text,#203d58);background:linear-gradient(color-mix(in srgb,var(--mesa-theme-soft,#f3f8fd) 92%,transparent),color-mix(in srgb,var(--mesa-theme-surface,#fff) 96%,transparent)),radial-gradient(circle at 12px 12px,color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 15%,transparent) 1px,transparent 1px);background-size:auto,24px 24px;text-align:center}.case-chat-selection-empty span{width:52px;height:52px;display:grid;place-items:center;margin:0 auto 12px;border-radius:50%;color:var(--mesa-shell-color,#0f6fec);background:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 12%,var(--mesa-theme-surface,#fff));font-size:25px}.case-chat-selection-empty strong,.case-chat-selection-empty small{display:block}.case-chat-selection-empty strong{font-size:13px}.case-chat-selection-empty small{max-width:285px;margin-top:6px;color:var(--mesa-theme-muted,#637d94);font-size:9px;line-height:1.5}

        .derivation-list {
            display: grid;
            gap: 8px;
            padding: 8px;
        }

        .derivation-row {
            display: grid;
            grid-template-columns:
                minmax(155px, .7fr)
                minmax(225px, 1fr)
                minmax(240px, 1.15fr)
                auto;
            gap: 7px;
            align-items: end;
            padding: 8px;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: #fbfdff;
        }

        .derivation-row textarea { min-height: 58px; }
        .derivation-row .remove-derivation { align-self: end; }

        .derivation-service-combobox {
            position: relative;
        }

        .derivation-service-toggle {
            position: absolute;
            z-index: 2;
            top: 1px;
            right: 1px;
            bottom: 1px;
            width: 34px;
            padding: 0;
            border: 0;
            border-left: 1px solid #d5e1ec;
            border-radius: 0 5px 5px 0;
            background: #f8fbff;
            color: #315a7e;
            cursor: pointer;
            font-size: 13px;
            line-height: 1;
            box-shadow: none;
        }

        .derivation-service-toggle::before {
            content: "▾";
        }

        .derivation-service-toggle[aria-expanded="true"]::before {
            content: "▴";
        }

        .derivation-service-toggle:hover,
        .derivation-service-toggle:focus-visible {
            background: #e8f2fd;
            color: #084f91;
            outline: 2px solid #8bc2f5;
            outline-offset: -2px;
        }

        .derivation-service-toggle:disabled {
            background: #eef3f8;
            color: #9cabb9;
            cursor: not-allowed;
        }

        .derivation-service-search {
            padding-right: 42px;
        }

        .derivation-service-search:disabled {
            cursor: not-allowed;
            background: #eef3f8;
            color: #74889d;
        }

        .derivation-service-menu {
            position: absolute;
            z-index: 1000;
            top: auto;
            right: 0;
            bottom: calc(100% + 4px);
            left: 0;
            max-height: min(316px, 65vh);
            overflow-y: auto;
            overscroll-behavior: contain;
            padding: 3px 0;
            border: 1px solid #8da9c2;
            border-radius: 5px;
            background: #fff;
            box-shadow: 0 -12px 30px rgba(23, 75, 120, .2);
        }

        .derivation-service-option {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 24px;
            align-items: center;
            width: 100%;
            min-height: 44px;
            padding: 7px 10px;
            border: 0;
            border-radius: 0;
            background: transparent;
            color: #123c62;
            font-size: 11px;
            font-weight: 700;
            line-height: 1.35;
            text-align: left;
            box-shadow: none;
            white-space: normal;
        }

        .derivation-service-option-name {
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .derivation-service-info {
            width: 22px;
            height: 22px;
            display: inline-grid;
            place-items: center;
            justify-self: end;
            border: 1px solid #8da9c2;
            border-radius: 50%;
            color: #315d82;
            background: #f3f8fd;
            cursor: help;
            font-size: 12px;
            font-weight: 900;
            line-height: 1;
        }

        .derivation-service-info:hover,
        .derivation-service-info:focus-visible {
            border-color: #2778bb;
            color: #084f91;
            background: #e3effc;
            outline: 2px solid #8bc2f5;
            outline-offset: 1px;
        }

        .derivation-service-description {
            display: none;
            grid-column: 1 / -1;
            margin-top: 4px;
            padding: 8px 9px;
            border: 1px solid #b8cee2;
            border-radius: 8px;
            color: #345875;
            background: #f5faff;
            font-size: 10px;
            font-weight: 550;
            line-height: 1.45;
            overflow-wrap: anywhere;
        }

        .derivation-service-option.is-info-open {
            background: #edf6ff;
            color: #084f91;
        }

        .derivation-service-option.is-info-open .derivation-service-description {
            display: block;
        }

        .derivation-service-option.is-info-open .derivation-service-info {
            border-color: #2778bb;
            color: #084f91;
            background: #dbeeff;
        }

        .derivation-service-option:hover .derivation-service-info,
        .derivation-service-option:focus .derivation-service-info {
            border-color: #2778bb;
        }

        .derivation-service-option:hover,
        .derivation-service-option:focus {
            background: #e3effc;
            color: #084f91;
            outline: none;
        }

        .derivation-service-option:hover .derivation-service-description,
        .derivation-service-option:focus .derivation-service-description,
        .derivation-service-option.is-info-open .derivation-service-description {
            color: #345875;
        }

        .derivation-service-option:hover .derivation-service-info,
        .derivation-service-option:focus .derivation-service-info,
        .derivation-service-option.is-info-open .derivation-service-info {
            background: #dbeeff;
        }

        @media (max-width: 560px) {
            .derivation-service-menu { max-height: min(280px, 55vh); }
            .derivation-service-option { padding: 8px 9px; font-size: 10.5px; }
            .derivation-service-description { font-size: 10px; }
        }

        .derivation-service-empty,
        .derivation-service-help {
            color: var(--muted);
            font-size: 9px;
        }

        .derivation-service-empty {
            padding: 10px;
            text-align: center;
        }

        .derivation-service-help {
            display: block;
            margin-top: 4px;
            line-height: 1.35;
        }

        .derivation-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 7px;
            padding: 0 8px 8px;
        }

        .closed-case {
            padding: 10px;
            border: 1px solid #8bc9aa;
            border-radius: 9px;
            background: #effaf5;
            color: #22543d;
        }

        .closed-case strong { color: #145c3b; }
        .closed-case p { margin: 5px 0 0; white-space: pre-wrap; }

        .ready-approval {
            --ready-accent: var(--warning);
            margin-top: 12px;
            padding: 12px;
            border: 1px solid color-mix(in srgb, var(--ready-accent) 48%, var(--border));
            border-radius: 11px;
            background: color-mix(in srgb, var(--ready-accent) 6%, var(--surface));
        }
        .ready-approval.is-continue { --ready-accent: var(--primary); }
        .ready-approval.is-final { --ready-accent: var(--ok); }
        .ready-approval.is-definitive { --ready-accent: var(--warning); }
        .ready-approval.is-derivation {
            --ready-accent: color-mix(in srgb, var(--primary) 55%, var(--danger));
        }
        .ready-approval-head {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
        }
        .ready-approval-head strong { color: var(--ready-accent); }
        .ready-approval-head p { margin: 4px 0 0; color: var(--muted); }
        .ready-solution-context {
            display: grid;
            grid-template-columns: minmax(190px, .9fr) minmax(270px, 1.35fr);
            gap: 9px;
            margin: 11px 0;
        }
        .ready-solution-context > div {
            padding: 10px 11px;
            border: 1px solid color-mix(in srgb, var(--primary) 25%, var(--border));
            border-radius: 9px;
            background: color-mix(in srgb, var(--primary) 5%, var(--surface));
        }
        .ready-solution-context > div:last-child {
            --context-accent: var(--primary);
            position: relative;
            padding-right: 47px;
            border-color: color-mix(in srgb, var(--context-accent) 42%, var(--border));
            border-left: 5px solid var(--context-accent);
            background: color-mix(in srgb, var(--context-accent) 10%, var(--surface));
            box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--context-accent) 7%, transparent);
        }
        .ready-solution-context > div:last-child::after {
            content: "";
            position: absolute;
            top: 12px;
            right: 13px;
            width: 18px;
            height: 18px;
            border: 5px solid color-mix(in srgb, var(--context-accent) 22%, var(--surface));
            border-radius: 50%;
            background: var(--context-accent);
            box-shadow: 0 0 0 1px color-mix(in srgb, var(--context-accent) 72%, var(--border));
        }
        .ready-solution-context > div.is-continue { --context-accent: var(--primary); }
        .ready-solution-context > div.is-final { --context-accent: var(--ok); }
        .ready-solution-context > div.is-definitive { --context-accent: var(--warning); }
        .ready-solution-context > div.is-derivation {
            --context-accent: color-mix(in srgb, var(--primary) 55%, var(--danger));
        }
        .ready-solution-context span {
            display: block;
            color: var(--muted);
            font-size: 9px;
            font-weight: 850;
            letter-spacing: .05em;
            text-transform: uppercase;
        }
        .ready-solution-context strong { display: block; margin-top: 3px; color: var(--navy); }
        .ready-solution-context > div:last-child span,
        .ready-solution-context > div:last-child strong { color: var(--context-accent); }
        .ready-solution-context p { margin: 4px 0 0; color: var(--text); font-size: 10px; line-height: 1.45; }
        .ready-delivery {
            display: grid;
            grid-template-columns: minmax(190px, .9fr) minmax(270px, 1.35fr);
            gap: 9px;
            margin: 11px 0;
        }
        .ready-delivery > div {
            padding: 10px 11px;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: var(--surface);
        }
        .ready-delivery span {
            display: block;
            color: var(--muted);
            font-size: 9px;
            font-weight: 850;
            letter-spacing: .05em;
            text-transform: uppercase;
        }
        .ready-delivery strong { display: block; margin-top: 4px; color: var(--navy); }
        .ready-delivery p { margin: 4px 0 0; color: var(--text); line-height: 1.5; overflow-wrap: anywhere; }
        .reopen-notice {
            margin: 12px clamp(18px, 2.2vw, 30px);
            padding: 12px 14px;
            border: 1px solid color-mix(in srgb, var(--warning) 48%, var(--border));
            border-left: 5px solid var(--warning);
            border-radius: 9px;
            background: color-mix(in srgb, var(--warning) 9%, var(--surface));
        }
        .reopen-notice strong { display: block; color: var(--navy); }
        .reopen-notice p { margin: 6px 0 0; line-height: 1.5; overflow-wrap: anywhere; }
        .reopen-notice small { display: block; margin-top: 6px; color: var(--muted); }
        .case-rating-form {
            margin-top: 12px;
            padding: 11px;
            border: 1px solid #d9e5ef;
            border-radius: 9px;
            background: #fff;
        }
        .case-rating-form h3 { margin: 0; color: var(--navy); font-size: 13px; }
        .case-rating-form > p { margin: 4px 0 0; }
        .approval-actions { display: flex; justify-content: flex-end; margin-top: 10px; }
        .reopen-form {
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #f0cbc6;
            border-radius: 9px;
            background: #fff8f7;
        }
        .reopen-form label { display: block; margin-bottom: 4px; color: #8f3e37; font-size: 9px; font-weight: 800; }
        .reopen-form textarea { width: 100%; min-height: 62px; }

        .files { display: grid; gap: 6px; }

        .file {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 8px;
            padding: 7px 8px;
            border: 1px solid var(--border);
            border-radius: 8px;
        }

        .file strong { color: var(--navy); font-size: 10px; }

        .stage-summary {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 6px;
            margin: 8px 0;
        }

        .stage-data {
            padding: 7px 8px;
            border-radius: 7px;
            background: #f6f9fc;
        }

        .stage-data span { display: block; color: var(--muted); font-size:9px; }
        .stage-data strong { display: block; margin-top: 1px; color: var(--navy); font-size: 10px; }

        .check {
            padding: 7px 0;
            border-bottom: 1px solid #edf1f6;
        }

        .check label { display: flex; align-items: flex-start; gap: 7px; margin: 0 0 5px; }
        .check input[type="checkbox"] { width: auto; min-height: 0; margin-top: 2px; }

        .survey {
            margin-top: 7px;
            padding: 8px;
            border: 1px solid var(--border);
            border-radius: 8px;
        }

        .survey select { max-width: 180px; }

        .closure-banner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            margin-bottom: 10px;
            padding: 13px 15px;
            border: 1px solid #f2cf75;
            border-radius: 12px;
            color: #704b00;
            background: linear-gradient(135deg, #fff9e8, #fff4cb);
            box-shadow: 0 6px 18px rgba(130, 92, 0, .08);
        }

        .closure-banner strong { display: block; color: #594000; font-size: 13px; }
        .closure-banner p { margin: 3px 0 0; font-size: 10px; }

        .final-rating-dialog {
            width: min(1040px, calc(100% - 20px));
            max-height: calc(100vh - 24px);
            padding: 0;
            overflow: hidden;
            border: 0;
            border-radius: 15px;
            color: var(--text);
            background: var(--surface);
            box-shadow: 0 24px 80px rgba(16, 42, 67, .28);
        }

        .final-rating-dialog::backdrop { background: rgba(16, 42, 67, .58); }
        .final-rating-shell { display: flex; max-height: calc(100vh - 24px); flex-direction: column; }
        .final-rating-head {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            padding: 15px 17px;
            color: #fff;
            background: linear-gradient(135deg, #0f6fec, #0a4fae);
        }
        .final-rating-head h2 { margin: 0; color: #fff; font-size: 17px; }
        .final-rating-head p { margin: 4px 0 0; color: #dcecff; font-size: 10px; }
        .final-rating-body { padding: 13px 15px; overflow: auto; background: #f6f9fc; }
        .final-rating-intro {
            margin-bottom: 10px;
            padding: 10px 12px;
            border: 1px solid #dbe7f3;
            border-radius: 10px;
            color: #34536d;
            background: #fff;
        }
        .final-rating-intro strong { color: var(--navy); }
        .rating-case-list { display: grid; gap: 9px; }
        .rating-case {
            padding: 11px;
            border: 1px solid #dce6f0;
            border-radius: 11px;
            background: #fff;
        }
        .rating-case-head {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            gap: 10px;
            align-items: start;
        }
        .rating-case-title { display: flex; align-items: center; gap: 7px; flex-wrap: wrap; }
        .rating-case-title strong { color: var(--navy); font-size: 12px; }
        .rating-case-title span { color: var(--muted); font-size: 9.5px; }
        .rating-case-times {
            display: flex;
            justify-content: flex-end;
            gap: 6px;
            flex-wrap: wrap;
        }
        .rating-case-times span {
            padding: 4px 7px;
            border-radius: 999px;
            color: #315875;
            background: #eef5fb;
            font-size:9px;
            font-weight: 750;
        }
        .rating-case-times .inside { color: #087443; background: #eaf8f1; }
        .rating-case-times .outside { color: #a33b32; background: #fff0ee; }
        .rating-fields {
            display: grid;
            grid-template-columns: minmax(170px, .7fr) minmax(170px, .7fr) minmax(260px, 1.6fr);
            gap: 8px;
            margin-top: 9px;
        }
        .rating-fields label { display: block; margin-bottom: 4px; color: #587087; font-size: 9px; font-weight: 800; }
        .rating-fields select,
        .rating-fields textarea { width: 100%; }
        .rating-fields textarea { min-height: 54px; }
        .final-rating-actions {
            display: flex;
            justify-content: flex-end;
            gap: 7px;
            position: sticky;
            bottom: -13px;
            margin: 12px -15px -13px;
            padding: 10px 15px;
            border-top: 1px solid #dce6f0;
            background: #fff;
        }

        .case-chat-bubble.is-pending { opacity: .68; }
        .case-chat-bubble.is-error {
            border-color: #e49a9a;
            background: #fff0f0;
        }

        @media (max-width: 940px) {
            .ready-solution-context { grid-template-columns: 1fr; }
            .ready-delivery { grid-template-columns: 1fr; }
            .detail-grid { grid-template-columns: 1fr; }
            .derivation-row { grid-template-columns: 1fr; }
            .topbar { align-items: flex-start; }
            .case-row { grid-template-columns: 26px minmax(0, 1fr) auto; }
            .case-row-main { grid-column: 2; }
            .case-row-meta { grid-column: 2; }
            .case-open { grid-column: 3; grid-row: 1 / span 2; }
            .branch-action { grid-column: 2 / 4; }
            .case-modal-content .stage-summary { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }

        .email-preference {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            margin: 0 0 13px;
            padding: 10px 12px;
            border: 1px solid #cfe0ef;
            border-radius: 11px;
            background: #f7faff;
        }
        .email-preference-copy { min-width: 0; }
        .email-preference-copy strong {
            display: block;
            color: var(--navy);
            font-size: 12px;
        }
        .email-preference-copy p {
            margin: 2px 0 0;
            color: var(--muted);
            font-size: 10px;
        }
        .email-preference-status {
            display: inline-flex;
            margin-top: 5px;
            padding: 3px 7px;
            border-radius: 999px;
            color: #087443;
            background: #eaf8f1;
            font-size: 9px;
            font-weight: 850;
        }
        .email-preference-status.off {
            color: #8a5800;
            background: #fff4d6;
        }
        .email-preference form { flex: 0 0 auto; }
        .email-toggle {
            min-height: 34px;
            padding: 7px 11px;
            border: 1px solid #bdd2e5;
            color: #255a83;
            background: #fff;
            font-size: 10px;
        }
        .manager-email-preference { margin-bottom: 0; padding: 8px 10px; }
        .manager-email-preference .email-preference-copy p { margin: 2px 0 4px; }

        @media (max-width: 640px) {
            .shell { width: min(100% - 12px, 1320px); padding-top: 6px; }
            .topbar { flex-direction: column; }
            .topbar .actions { width: 100%; }
            .topbar .actions .btn { flex: 1 1 auto; }
            .closure-banner { align-items: stretch; flex-direction: column; }
            .rating-case-head,
            .rating-fields { grid-template-columns: 1fr; }
            .rating-case-times { justify-content: flex-start; }
            .modebar { overflow-x: auto; }
            .mode-link { flex: 1 0 auto; justify-content: center; }
            .wizard-progress { overflow-x: auto; }
            .wizard-step { flex: 0 0 auto; }
            .catalog-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .service-grid { grid-template-columns: 1fr; }
            .selected-service { align-items: flex-start; flex-direction: column; }
            .form-grid { grid-template-columns: 1fr; }
            .field.full { grid-column: auto; }
            .card-head, .ticket-summary { grid-template-columns: 1fr; flex-direction: column; }
            .stage-summary { grid-template-columns: 1fr; }
            .file { align-items: flex-start; flex-direction: column; }
            .tree-toolbar { width: 100%; }
            .tree-toolbar .btn { flex: 1; }
            .manager-tree-help,
            .manager-guide-steps { grid-template-columns: 1fr; }
            .case-row { grid-template-columns: 24px minmax(0, 1fr); }
            .case-row-main,
            .case-row-meta,
            .case-open,
            .branch-action { grid-column: 2; grid-row: auto; }
            .case-open { justify-self: start; }
            .case-children { margin-left: 11px; padding-left: 12px; }
            .case-children > .case-branch::before,
            .case-children > .case-leaf::before { width: 12px; }
            .case-dialog { width: calc(100% - 10px); height: calc(100dvh - 10px); }
            .case-chat-launcher{right:13px;bottom:12px}.case-chat-panel{inset:6px;width:auto;height:auto;border-radius:15px}.case-chat-widget.is-open .case-chat-launcher{display:none}.case-chat-bubble{max-width:91%}.case-chat-bubble.is-file{width:min(315px,91%)}
            .case-modal-header { padding: 12px; }
            .case-modal-header h2 { font-size: 15px; }
            .case-modal-header .case-chat-launcher-copy { display: none; }
            .case-modal-header .case-chat-launcher { padding: 5px; }
            .case-modal-content { padding: 7px; }
            .case-modal-content .stage-summary { grid-template-columns: 1fr; }
            .manager-case-filters { grid-template-columns: 1fr; }
            .manager-filter-count { padding: 0 2px; text-align: left; }
            .manager-ticket-modal { padding: 6px; }
            .manager-ticket-modal-window { max-height: calc(100dvh - 12px); border-radius: 12px; }
            .manager-ticket-modal-bar { padding: 8px 10px; }
            .manager-ticket-modal-close-label { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0, 0, 0, 0); }
            .manager-ticket-modal-scroll { padding: 7px; }
            .email-preference { align-items: stretch; flex-direction: column; }
            .email-preference form,
            .email-preference button { width: 100%; }
        }
    </style>

<style id="chat-identidad-participantes">
.case-chat-author-row{
    display:flex;
    align-items:center;
    gap:7px;
    margin-bottom:6px;
}
.case-chat-profile-image,
.case-chat-profile-fallback{
    width:28px;
    height:28px;
    flex:0 0 28px;
    border-radius:50%;
}
.case-chat-profile-image{
    display:block;
    object-fit:cover;
    border:2px solid var(--mesa-theme-border,#d4e0eb);
    background:var(--mesa-theme-soft,#dfe9f2);
}
.case-chat-profile-fallback{
    display:grid;
    place-items:center;
    color:var(--mesa-theme-on-primary,#fff);
    background:var(--mesa-shell-color,#315f87);
    font-size:8px;
    font-weight:900;
}
.case-chat-author-copy{
    min-width:0;
    display:grid;
    line-height:1.15;
}
.case-chat-author-copy strong{
    overflow:hidden;
    color:var(--mesa-theme-heading,#1769aa);
    font-size:9px;
    font-weight:900;
    text-overflow:ellipsis;
    white-space:nowrap;
}
.case-chat-author-copy small{
    margin-top:2px;
    color:var(--mesa-theme-muted,#72879a);
    font-size:7px;
    font-weight:750;
}
.case-chat-bubble.mine .case-chat-author-row{
    justify-content:flex-end;
}
.case-chat-bubble.mine .case-chat-author-copy{
    text-align:right;
}
.case-chat-bubble.mine,
.case-chat-bubble[data-mesa-own-message="1"]{
    border-color:var(--mesa-theme-border,#d4e0eb)!important;
    border-color:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 55%,var(--mesa-theme-border,#d4e0eb))!important;
    color:var(--mesa-theme-text,#203d58)!important;
    background:var(--mesa-theme-soft,#edf6ff)!important;
    background:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 16%,var(--mesa-theme-surface,#fff))!important;
}
.case-chat-bubble.mine .case-chat-author-copy,
.case-chat-bubble.mine .case-chat-author-copy strong,
.case-chat-bubble.mine .case-chat-text,
.case-chat-bubble[data-mesa-own-message="1"] .case-chat-author-copy,
.case-chat-bubble[data-mesa-own-message="1"] .case-chat-author-copy strong,
.case-chat-bubble[data-mesa-own-message="1"] .case-chat-text{color:var(--mesa-theme-heading,#173b5d)!important}
.case-chat-bubble.mine .case-chat-author-copy small,
.case-chat-bubble.mine .case-chat-time,
.case-chat-bubble[data-mesa-own-message="1"] .case-chat-author-copy small,
.case-chat-bubble[data-mesa-own-message="1"] .case-chat-time{color:var(--mesa-theme-meta,var(--mesa-theme-muted,#637d94))!important}
.case-chat-bubble.mine .read-mark,
.case-chat-bubble[data-mesa-own-message="1"] .read-mark{color:var(--mesa-theme-muted,#637d94)!important;font-size:10px;font-weight:900}
.case-chat-bubble.mine .read-mark.is-read,
.case-chat-bubble[data-mesa-own-message="1"] .read-mark.is-read{color:var(--mesa-theme-link,var(--mesa-shell-color,#0f6fec))!important}
.case-chat-presence{display:flex!important;align-items:center;gap:5px}.case-chat-presence::before{content:"";width:6px;height:6px;flex:0 0 auto;border-radius:50%;background:var(--mesa-theme-muted,#91a2b1)}.case-chat-presence.is-online::before{background:#19b979;box-shadow:0 0 0 3px rgba(25,185,121,.14)}
.case-chat-bubble.mine .case-chat-profile-image{
    order:2;
    border-color:var(--mesa-theme-border,#d4e0eb);
}
.case-chat-files{flex:0 0 auto;border-bottom:1px solid var(--mesa-theme-border,#dce7f1);background:var(--mesa-theme-soft,#f3f8fd)}
.case-chat-files summary{display:flex;align-items:center;justify-content:space-between;padding:8px 11px;color:var(--mesa-theme-heading,#173b5d);font-size:9px;font-weight:850;cursor:pointer;list-style:none}.case-chat-files summary::-webkit-details-marker{display:none}.case-chat-files summary span{padding:2px 7px;border-radius:999px;color:var(--mesa-theme-link,#0f6fec);background:var(--mesa-theme-surface,#fff)}
.case-chat-files-list{max-height:165px;display:grid;gap:6px;overflow:auto;padding:0 9px 9px}.case-chat-files-list a{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;padding:8px;border:1px solid var(--mesa-theme-border,#d4e0eb);border-radius:9px;color:var(--mesa-theme-text,#203d58);background:var(--mesa-theme-surface,#fff);text-decoration:none}.case-chat-files-list strong,.case-chat-files-list small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.case-chat-files-list strong{font-size:9px}.case-chat-files-list small{color:var(--mesa-theme-muted,#637d94);font-size:8px}.case-chat-files-empty{padding:0 11px 9px;color:var(--mesa-theme-muted,#637d94);font-size:8px}
.solution-choice-grid{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(260px,.95fr);gap:12px;align-items:stretch}.solution-choice-main{min-width:0}.solution-choice-actions{display:flex;gap:7px;flex-wrap:wrap;margin-top:8px}.solution-guide{min-width:0;padding:11px 13px;border:1px solid var(--mesa-theme-border,var(--border));border-left:4px solid var(--mesa-shell-color,var(--primary));border-radius:10px;color:var(--mesa-theme-text,var(--text));background:var(--mesa-theme-soft,var(--soft))}.solution-guide>span,.solution-guide>strong,.solution-guide>p{display:block}.solution-guide>span{color:var(--mesa-theme-link,var(--primary));font-size:9px;font-weight:900;text-transform:uppercase;letter-spacing:.04em}.solution-guide>strong{margin-top:4px;color:var(--mesa-theme-heading,var(--navy));font-size:12px}.solution-guide>p{margin:5px 0 0;color:var(--mesa-theme-muted,var(--muted));font-size:10px;line-height:1.5;white-space:pre-line}.new-solution-panel{display:grid;grid-template-columns:minmax(0,.72fr) minmax(0,1.28fr);gap:9px 12px;margin:10px 0;padding:13px;border:1px solid color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 38%,var(--mesa-theme-border,var(--border)));border-left:4px solid var(--mesa-shell-color,var(--primary));border-radius:10px;color:var(--mesa-theme-text,var(--text));background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 7%,var(--mesa-theme-surface,var(--surface)))}
.new-solution-panel[hidden]{display:none!important}.new-solution-panel-head,.new-solution-panel-actions,.new-solution-status{grid-column:1/-1}.new-solution-panel-head strong{display:block;color:var(--mesa-theme-heading,var(--navy));font-size:12px}.new-solution-panel-head p{margin:2px 0 0;color:var(--mesa-theme-muted,var(--muted));font-size:9px}.new-solution-field label{display:block;margin-bottom:4px}.new-solution-field input,.new-solution-field textarea{width:100%}.new-solution-field textarea{min-height:70px}.new-solution-panel-actions{display:flex;justify-content:flex-end;gap:7px}.new-solution-status{margin:0;color:var(--mesa-theme-muted,var(--muted));font-size:10px}.new-solution-status.is-error{color:var(--mesa-state-danger,#b42318)}.new-solution-status.is-ok{color:var(--mesa-state-success,#087458)}
@media(max-width:760px){.solution-choice-grid,.new-solution-panel{grid-template-columns:1fr}.new-solution-panel-head,.new-solution-panel-actions,.new-solution-status{grid-column:auto}}
</style>

<style id="manager-case-readable-layout">
/* El detalle del gestor comparte la misma jerarquía visual del detalle del solicitante. */
.case-detail-page{
    --manager-case-blue:var(--mesa-shell-color,#0d62b5);
    --manager-case-blue-strong:color-mix(in srgb,var(--manager-case-blue) 72%,#082f57);
    --manager-case-line:var(--mesa-theme-border,#d7e3ed);
    --manager-case-surface:var(--mesa-theme-surface,#fff);
    --manager-case-soft:var(--mesa-theme-soft,#f3f7fb);
    --manager-case-text:var(--mesa-theme-text,#17334d);
    --manager-case-muted:var(--mesa-theme-muted,#62788c);
}
.case-detail-page .manager-ticket-modal-window,
.case-detail-page .manager-ticket-modal-scroll,
.case-detail-page .case-dialog.is-embedded,
.case-detail-page .case-modal-shell{
    width:100%;
    max-width:none;
    border:0;
    border-radius:0;
    color:var(--manager-case-text);
    background:var(--manager-case-surface);
    box-shadow:none;
}
.case-detail-page .manager-ticket-modal-scroll{display:block;padding:0}
.case-detail-page .case-dialog.is-embedded .case-modal-shell{min-height:calc(100dvh - 64px)}
.case-detail-page .case-modal-header{
    position:relative;
    top:auto;
    z-index:2;
    align-items:center;
    margin:0;
    padding:20px clamp(18px,2.2vw,32px);
    overflow:hidden;
    border:0;
    color:var(--mesa-theme-on-primary,#fff);
    background:linear-gradient(120deg,var(--manager-case-blue-strong),var(--manager-case-blue));
    box-shadow:none;
}
.case-detail-page .case-modal-header::after{
    content:"";
    position:absolute;
    right:-48px;
    bottom:-95px;
    width:220px;
    height:220px;
    border:38px solid rgba(255,255,255,.08);
    border-radius:50%;
    pointer-events:none;
}
.case-detail-page .case-modal-header>div{position:relative;z-index:1}
.case-detail-page .case-modal-header h2{margin-top:6px;color:var(--mesa-theme-on-primary,#fff);font-size:clamp(21px,1.75vw,27px);line-height:1.16;letter-spacing:-.02em}
.case-detail-page .case-modal-header p{max-width:760px;margin-top:5px;color:color-mix(in srgb,var(--mesa-theme-on-primary,#fff) 82%,transparent);font-size:12px}
.case-detail-page .case-code,
.case-detail-page .case-modal-header .case-status{border:1px solid rgba(255,255,255,.32);color:var(--mesa-theme-on-primary,#fff)!important;background:rgba(255,255,255,.13)!important}
.case-detail-page .case-modal-header .case-chat-launcher{border-color:rgba(255,255,255,.35);color:var(--manager-case-blue-strong);background:#fff;box-shadow:0 7px 18px rgba(5,31,57,.18)}
.case-detail-page .case-tabs{
    position:sticky;
    top:0;
    z-index:4;
    gap:2px;
    padding:0 clamp(14px,2.2vw,30px);
    border-color:var(--manager-case-line);
    background:var(--manager-case-surface);
}
.case-detail-page .case-tab{min-height:42px;padding:9px 13px;border-radius:0;color:var(--manager-case-muted);font-size:12px}
.case-detail-page .case-tab.active{color:var(--manager-case-blue);background:transparent}
.case-detail-page .case-modal-content{padding:0;overflow:visible;background:var(--manager-case-surface)}
.case-detail-page .case-dialog .card.case-pane{
    display:block;
    margin:0!important;
    padding:0!important;
    border:0!important;
    border-radius:0!important;
    background:var(--manager-case-surface)!important;
    box-shadow:none!important;
}
.case-detail-page .case-pane>.card-head{
    align-items:center;
    margin:0;
    padding:16px clamp(18px,2.2vw,30px) 12px;
    border:0;
    border-bottom:1px solid var(--manager-case-line);
}
.case-detail-page .case-pane>.card-head h2{font-size:18px}
.case-detail-page .case-pane>.card-head p{font-size:11px}
.manager-request-overview{
    display:grid;
    grid-template-columns:minmax(0,.72fr) minmax(0,1.28fr);
    margin:0;
    padding:12px clamp(18px,2.2vw,30px);
    border-left:5px solid var(--manager-case-blue);
    border-bottom:1px solid var(--manager-case-line);
    background:var(--manager-case-surface);
}
.manager-request-overview-item{min-width:0;padding:3px 16px 7px 0}
.manager-request-overview-item.is-description{padding-left:18px;border-left:1px solid var(--manager-case-line)}
.manager-request-overview-item>span,
.manager-request-overview-meta span{
    display:block;
    color:var(--manager-case-muted);
    font-size:10px;
    font-weight:850;
    letter-spacing:.055em;
    text-transform:uppercase;
}
.manager-request-overview-item>span::before{content:"";display:inline-block;width:5px;height:5px;margin:0 7px 2px 0;border-radius:1px;background:var(--manager-case-blue)}
.manager-request-overview-item strong{display:block;margin-top:6px;color:var(--mesa-theme-heading,#17334d);font-size:15px;line-height:1.4}
.manager-request-overview-item p{margin:6px 0 0;color:var(--manager-case-text);font-size:13px;line-height:1.55;overflow-wrap:anywhere}
.manager-request-overview-meta{grid-column:1/-1;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));margin-top:7px;padding-top:10px;border-top:1px solid var(--manager-case-line)}
.manager-request-overview-meta>div{min-width:0;padding-right:16px}
.manager-request-overview-meta>div+div{padding-left:18px;border-left:1px solid var(--manager-case-line)}
.manager-request-overview-meta strong{display:block;margin-top:3px;color:var(--mesa-theme-heading,#17334d);font-size:12px}
.case-detail-page .manager-task-guide{
    margin:0;
    padding:18px clamp(18px,2.2vw,30px);
    border:0;
    border-left:5px solid var(--manager-case-blue);
    border-bottom:1px solid var(--manager-case-line);
    border-radius:0;
    background:color-mix(in srgb,var(--manager-case-surface) 94%,var(--manager-case-blue));
}
.case-detail-page .manager-task-guide.pendiente,
.case-detail-page .manager-task-guide.pausada{border-left-color:var(--mesa-state-warning,#d99900)}
.case-detail-page .manager-task-guide.completada{border-left-color:var(--mesa-state-success,#087443)}
.case-detail-page .manager-task-guide h3{font-size:16px}
.case-detail-page .manager-task-guide p{font-size:11px}
.case-detail-page .manager-guide-steps{gap:0;margin:14px 0 0;border:1px solid var(--manager-case-line);border-radius:9px;overflow:hidden}
.case-detail-page .manager-guide-steps>span{padding:8px 10px;border:0;border-right:1px solid var(--manager-case-line);border-radius:0;background:var(--manager-case-surface)}
.case-detail-page .manager-guide-steps>span:last-child{border-right:0}
.case-detail-page .manager-guide-steps strong{font-size:10px}.case-detail-page .manager-guide-steps small{font-size:9px}
.case-detail-page .manager-email-preference{
    align-items:center;
    margin:0;
    padding:11px clamp(18px,2.2vw,30px);
    border:0;
    border-bottom:1px solid var(--manager-case-line);
    border-radius:0;
    background:var(--manager-case-surface);
}
.case-detail-page .manager-email-preference .email-preference-copy{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.case-detail-page .manager-email-preference .email-preference-copy strong{font-size:12px}
.case-detail-page .manager-email-preference .email-preference-copy p{margin:0;font-size:10px}
.case-detail-page .manager-email-preference .email-preference-status{margin:0}
.case-detail-page .manager-email-preference .email-toggle{min-height:32px}
.case-detail-page .case-modal-content .stage-summary{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:0;
    margin:0;
    padding:0 clamp(18px,2.2vw,30px);
    border-bottom:1px solid var(--manager-case-line);
    background:var(--manager-case-soft);
}
.case-detail-page .case-modal-content .stage-data{padding:12px 14px;border:0;border-right:1px solid var(--manager-case-line);border-radius:0;background:transparent}
.case-detail-page .case-modal-content .stage-data:first-child{padding-left:0}.case-detail-page .case-modal-content .stage-data:last-child{border-right:0}
.case-detail-page .case-modal-content .stage-data span{font-size:9px;text-transform:uppercase;letter-spacing:.045em}.case-detail-page .case-modal-content .stage-data strong{margin-top:3px;font-size:11px}
.case-detail-page .case-panel-toggle{
    margin:0!important;
    border:0;
    border-bottom:1px solid var(--manager-case-line);
    border-radius:0;
    background:var(--manager-case-surface);
}
.case-detail-page .case-panel-toggle>summary{padding:13px clamp(18px,2.2vw,30px);font-size:12px}
.case-detail-page .case-panel-toggle-body{padding:0 clamp(18px,2.2vw,30px) 18px}
.case-detail-page .manager-action-panel[open]{border-color:var(--manager-case-line)}
.case-detail-page .case-pane[data-case-panel="acciones"],
.case-detail-page .case-pane[data-case-panel="archivos"]{padding:18px clamp(18px,2.2vw,30px)!important}
.case-detail-page .case-pane[data-case-panel="acciones"]>.card-head,
.case-detail-page .case-pane[data-case-panel="archivos"]>.card-head{padding:0 0 14px;border-bottom:1px solid var(--manager-case-line)}
.case-detail-page .solution-choice-grid{margin-top:4px}
.case-detail-page .solution-guide{border-radius:8px}
.case-detail-page .closed-case{margin:0;padding:18px clamp(18px,2.2vw,30px);border-radius:0}

@media(max-width:900px){
    .manager-request-overview{grid-template-columns:1fr}
    .manager-request-overview-item.is-description{padding-top:11px;padding-left:0;border-top:1px solid var(--manager-case-line);border-left:0}
    .case-detail-page .case-modal-content .stage-summary{grid-template-columns:repeat(2,minmax(0,1fr))}
    .case-detail-page .case-modal-content .stage-data:nth-child(2){border-right:0}
    .case-detail-page .case-modal-content .stage-data:nth-child(-n+2){border-bottom:1px solid var(--manager-case-line)}
}
@media(max-width:640px){
    .case-detail-page .case-modal-header{align-items:flex-start;padding:17px 14px}
    .case-detail-page .case-modal-header h2{font-size:20px}
    .case-detail-page .case-tabs{padding:0 8px}
    .case-detail-page .case-tab{font-size:11px}
    .case-detail-page .case-pane>.card-head,
    .manager-request-overview,
    .case-detail-page .manager-task-guide,
    .case-detail-page .manager-email-preference,
    .case-detail-page .case-panel-toggle>summary,
    .case-detail-page .case-panel-toggle-body{padding-right:14px;padding-left:14px}
    .manager-request-overview-meta{grid-template-columns:1fr;gap:9px}
    .manager-request-overview-meta>div+div{padding-top:9px;padding-left:0;border-top:1px solid var(--manager-case-line);border-left:0}
    .case-detail-page .manager-guide-steps{grid-template-columns:1fr}
    .case-detail-page .manager-guide-steps>span{border-right:0;border-bottom:1px solid var(--manager-case-line)}
    .case-detail-page .manager-guide-steps>span:last-child{border-bottom:0}
    .case-detail-page .manager-email-preference{align-items:stretch;flex-direction:row}
    .case-detail-page .manager-email-preference form,.case-detail-page .manager-email-preference button{width:auto}
    .case-detail-page .manager-email-preference .email-preference-copy p{display:none}
    .case-detail-page .case-modal-content .stage-summary{grid-template-columns:1fr;padding:0 14px}
    .case-detail-page .case-modal-content .stage-data{padding:10px 0;border-right:0;border-bottom:1px solid var(--manager-case-line)!important}
    .case-detail-page .case-modal-content .stage-data:last-child{border-bottom:0!important}
    .case-detail-page .case-pane[data-case-panel="acciones"],
    .case-detail-page .case-pane[data-case-panel="archivos"]{padding:14px!important}
}
</style>

<style id="manager-case-polished-layout">
/* Capa final: usa mayor especificidad que el tema corporativo sin perder su paleta. */
body.mesa-php-shell .case-detail-page .manager-ticket-modal-scroll{
    padding:14px!important;
    background:var(--mesa-theme-bg,#eef4fa)!important;
}
body.mesa-php-shell .case-detail-page .case-dialog.is-embedded{
    overflow:hidden!important;
    border:1px solid var(--mesa-theme-border,#d7e3ed)!important;
    border-radius:18px!important;
    background:var(--mesa-theme-surface,#fff)!important;
    box-shadow:0 14px 36px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 13%,transparent)!important;
}
body.mesa-php-shell .case-detail-page .case-modal-header{
    min-height:104px!important;
    padding:22px clamp(20px,2.4vw,36px)!important;
    border:0!important;
    color:var(--mesa-theme-on-primary,#fff)!important;
    background:linear-gradient(120deg,var(--manager-case-blue-strong),var(--manager-case-blue))!important;
}
body.mesa-php-shell .case-detail-page .case-modal-header h2,
body.mesa-php-shell .case-detail-page .case-modal-header p{
    color:var(--mesa-theme-on-primary,#fff)!important;
}
body.mesa-php-shell .case-detail-page .case-modal-header p{opacity:.84}
body.mesa-php-shell .case-detail-page .case-modal-header .case-code,
body.mesa-php-shell .case-detail-page .case-modal-header .case-status{
    border-color:rgba(255,255,255,.42)!important;
    color:var(--mesa-theme-on-primary,#fff)!important;
    background:rgba(255,255,255,.14)!important;
    box-shadow:none!important;
}
body.mesa-php-shell .case-detail-page .case-modal-header .case-chat-launcher{
    min-height:42px!important;
    padding:6px 13px 6px 7px!important;
    border:1px solid rgba(255,255,255,.55)!important;
    border-radius:12px!important;
    color:var(--manager-case-blue-strong)!important;
    background:#fff!important;
    box-shadow:0 9px 22px rgba(3,30,58,.24)!important;
}
body.mesa-php-shell .case-detail-page .case-modal-header .case-chat-launcher-icon{
    color:#fff!important;
    background:var(--manager-case-blue)!important;
}
body.mesa-php-shell .case-detail-page .case-tabs{
    gap:7px!important;
    padding:10px clamp(16px,2.1vw,30px)!important;
    border-bottom:1px solid var(--manager-case-line)!important;
    background:var(--manager-case-surface)!important;
    box-shadow:0 5px 14px rgba(24,55,84,.06)!important;
}
body.mesa-php-shell .case-detail-page .case-tab{
    min-height:38px!important;
    display:inline-flex!important;
    align-items:center!important;
    gap:7px!important;
    padding:8px 13px!important;
    border:1px solid transparent!important;
    border-radius:10px!important;
    color:var(--manager-case-muted)!important;
    background:transparent!important;
    font-size:11px!important;
    box-shadow:none!important;
}
body.mesa-php-shell .case-detail-page .case-tab::before{
    width:21px;
    height:21px;
    display:grid;
    place-items:center;
    border-radius:7px;
    color:var(--manager-case-blue);
    background:color-mix(in srgb,var(--manager-case-blue) 10%,var(--manager-case-surface));
    font-size:11px;
    font-weight:900;
}
body.mesa-php-shell .case-detail-page .case-tab[data-case-tab="resumen"]::before{content:"✓"}
body.mesa-php-shell .case-detail-page .case-tab[data-case-tab="acciones"]::before{content:"↺"}
body.mesa-php-shell .case-detail-page .case-tab[data-case-tab="archivos"]::before{content:"↥"}
body.mesa-php-shell .case-detail-page .case-tab:hover{
    border-color:color-mix(in srgb,var(--manager-case-blue) 24%,var(--manager-case-line))!important;
    background:color-mix(in srgb,var(--manager-case-blue) 5%,var(--manager-case-surface))!important;
}
body.mesa-php-shell .case-detail-page .case-tab.active{
    border-color:color-mix(in srgb,var(--manager-case-blue) 38%,var(--manager-case-line))!important;
    color:var(--manager-case-blue)!important;
    background:color-mix(in srgb,var(--manager-case-blue) 9%,var(--manager-case-surface))!important;
    box-shadow:0 4px 12px color-mix(in srgb,var(--manager-case-blue) 12%,transparent)!important;
}
body.mesa-php-shell .case-detail-page .case-modal-content{
    padding:16px!important;
    color:var(--manager-case-text)!important;
    background:var(--mesa-theme-bg,#eef4fa)!important;
}
body.mesa-php-shell .case-detail-page .case-dialog .card.case-pane{
    overflow:hidden!important;
    border:1px solid var(--manager-case-line)!important;
    border-radius:15px!important;
    background:var(--manager-case-surface)!important;
    box-shadow:0 8px 22px rgba(25,55,83,.07)!important;
}
body.mesa-php-shell .case-detail-page .case-pane>.card-head{
    padding:16px 20px!important;
    border-bottom:1px solid var(--manager-case-line)!important;
    background:linear-gradient(110deg,color-mix(in srgb,var(--manager-case-blue) 9%,var(--manager-case-surface)),var(--manager-case-surface))!important;
}
body.mesa-php-shell .case-detail-page .case-pane>.card-head h2{color:var(--mesa-theme-heading,#17334d)!important;font-size:18px!important}
body.mesa-php-shell .case-detail-page .case-pane>.card-head p{color:var(--manager-case-muted)!important;font-size:11px!important}
body.mesa-php-shell .case-detail-page .manager-request-overview{
    gap:0!important;
    margin:16px 18px 12px!important;
    padding:0!important;
    overflow:hidden!important;
    border:1px solid var(--manager-case-line)!important;
    border-left:5px solid var(--manager-case-blue)!important;
    border-radius:12px!important;
    background:var(--manager-case-surface)!important;
    box-shadow:0 6px 18px rgba(25,55,83,.055)!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-item,
body.mesa-php-shell .case-detail-page .manager-request-overview-meta>div{
    padding:15px 17px!important;
    background:transparent!important;
    border-top:0!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-item.is-description,
body.mesa-php-shell .case-detail-page .manager-request-overview-meta>div+div{
    padding-left:17px!important;
    border-left:1px solid var(--manager-case-line)!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-meta{
    margin:0!important;
    padding:0!important;
    border-top:1px solid var(--manager-case-line)!important;
    background:transparent!important;
    display:contents!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-meta>div{
    border-top:1px solid var(--manager-case-line)!important;
}
body.mesa-php-shell .case-detail-page .manager-task-guide{
    margin:12px 18px!important;
    padding:16px!important;
    border:1px solid color-mix(in srgb,var(--manager-case-blue) 30%,var(--manager-case-line))!important;
    border-left:5px solid var(--manager-case-blue)!important;
    border-radius:12px!important;
    background:linear-gradient(115deg,color-mix(in srgb,var(--manager-case-blue) 8%,var(--manager-case-surface)),var(--manager-case-surface))!important;
    box-shadow:0 7px 18px rgba(25,55,83,.055)!important;
}
body.mesa-php-shell .case-detail-page .manager-task-guide.pendiente,
body.mesa-php-shell .case-detail-page .manager-task-guide.pausada{border-left-color:var(--mesa-state-warning,#d99900)!important}
body.mesa-php-shell .case-detail-page .manager-task-guide.completada{border-left-color:var(--mesa-state-success,#087443)!important}
body.mesa-php-shell .case-detail-page .manager-guide-icon{border-radius:11px!important;box-shadow:0 6px 14px color-mix(in srgb,var(--manager-case-blue) 25%,transparent)!important}
body.mesa-php-shell .case-detail-page .manager-guide-steps{
    border:1px solid var(--manager-case-line)!important;
    border-radius:10px!important;
    background:var(--manager-case-surface)!important;
}
body.mesa-php-shell .case-detail-page .manager-guide-steps>span{
    border-color:var(--manager-case-line)!important;
    background:var(--manager-case-surface)!important;
}
body.mesa-php-shell .case-detail-page .manager-email-preference{
    margin:12px 18px!important;
    padding:11px 13px!important;
    border:1px solid var(--manager-case-line)!important;
    border-radius:11px!important;
    background:var(--manager-case-soft)!important;
}
body.mesa-php-shell .case-detail-page .manager-email-preference .email-toggle,
body.mesa-php-shell .case-detail-page .btn{
    border:1px solid color-mix(in srgb,var(--manager-case-blue) 28%,var(--manager-case-line))!important;
    border-radius:9px!important;
    color:var(--manager-case-blue)!important;
    background:var(--manager-case-surface)!important;
    box-shadow:0 3px 9px rgba(25,55,83,.06)!important;
    transition:transform .16s ease,box-shadow .16s ease,background .16s ease!important;
}
body.mesa-php-shell .case-detail-page .manager-email-preference .email-toggle:hover,
body.mesa-php-shell .case-detail-page .btn:hover{transform:translateY(-1px)!important;box-shadow:0 7px 16px rgba(25,55,83,.12)!important}
body.mesa-php-shell .case-detail-page button.primary,
body.mesa-php-shell .case-detail-page .btn.primary{
    border-color:var(--manager-case-blue)!important;
    color:var(--mesa-theme-on-primary,#fff)!important;
    background:linear-gradient(135deg,var(--manager-case-blue),var(--manager-case-blue-strong))!important;
    box-shadow:0 7px 17px color-mix(in srgb,var(--manager-case-blue) 25%,transparent)!important;
}
body.mesa-php-shell .case-detail-page .case-modal-content .stage-summary{
    margin:12px 18px!important;
    padding:0!important;
    overflow:hidden!important;
    border:1px solid var(--manager-case-line)!important;
    border-radius:11px!important;
    background:var(--manager-case-soft)!important;
}
body.mesa-php-shell .case-detail-page .case-modal-content .stage-data{
    padding:12px 14px!important;
    border-color:var(--manager-case-line)!important;
    background:transparent!important;
}
body.mesa-php-shell .case-detail-page .case-panel-toggle{
    margin:10px 18px!important;
    overflow:hidden!important;
    border:1px solid var(--manager-case-line)!important;
    border-radius:11px!important;
    background:var(--manager-case-surface)!important;
    box-shadow:0 4px 13px rgba(25,55,83,.045)!important;
}
body.mesa-php-shell .case-detail-page .case-panel-toggle>summary{
    position:relative!important;
    padding:13px 46px 13px 15px!important;
    color:var(--mesa-theme-heading,#17334d)!important;
    background:var(--manager-case-surface)!important;
}
body.mesa-php-shell .case-detail-page .case-panel-toggle>summary::before{
    position:absolute!important;
    top:50%!important;
    right:14px!important;
    width:25px!important;
    height:25px!important;
    display:grid!important;
    place-items:center!important;
    border-radius:8px!important;
    color:var(--manager-case-blue)!important;
    background:color-mix(in srgb,var(--manager-case-blue) 10%,var(--manager-case-surface))!important;
    transform:translateY(-50%)!important;
}
body.mesa-php-shell .case-detail-page .case-panel-toggle[open]>summary{border-bottom:1px solid var(--manager-case-line)!important;background:var(--manager-case-soft)!important}
body.mesa-php-shell .case-detail-page .case-panel-toggle-body{
    padding:15px!important;
    color:var(--manager-case-text)!important;
    background:var(--manager-case-surface)!important;
}
body.mesa-php-shell .case-detail-page .solution-guide,
body.mesa-php-shell .case-detail-page .new-solution-panel{
    border-radius:11px!important;
    box-shadow:0 5px 14px rgba(25,55,83,.05)!important;
}
/* Historial: dos columnas legibles en escritorio, una línea de tiempo en móvil. */
body.mesa-php-shell .case-detail-page .case-pane[data-case-panel="acciones"]{
    padding:18px!important;
}
body.mesa-php-shell .case-detail-page .case-pane[data-case-panel="acciones"]>.card-head{margin:-18px -18px 16px!important}
body.mesa-php-shell .case-detail-page .action-summary{
    margin:0 0 16px!important;
    padding:0!important;
    overflow:hidden!important;
    border:1px solid var(--manager-case-line)!important;
    border-radius:11px!important;
    background:var(--manager-case-surface)!important;
    box-shadow:0 5px 15px rgba(25,55,83,.05)!important;
}
body.mesa-php-shell .case-detail-page .action-summary-head{padding:12px 14px!important;background:var(--manager-case-soft)!important}
body.mesa-php-shell .case-detail-page .action-summary-body{padding:14px!important}
body.mesa-php-shell .case-detail-page .audit-log{
    grid-template-columns:repeat(2,minmax(0,1fr))!important;
    gap:12px!important;
    padding:0!important;
}
body.mesa-php-shell .case-detail-page .audit-item{
    min-height:138px!important;
    padding:14px!important;
    border:1px solid var(--manager-case-line)!important;
    border-top:4px solid color-mix(in srgb,var(--manager-case-blue) 72%,var(--manager-case-line))!important;
    border-radius:12px!important;
    background:var(--manager-case-surface)!important;
    box-shadow:0 7px 18px rgba(25,55,83,.065)!important;
}
body.mesa-php-shell .case-detail-page .audit-item+.audit-item{margin-top:0!important}
body.mesa-php-shell .case-detail-page .audit-item::before{
    top:-10px!important;
    right:12px!important;
    left:auto!important;
    width:25px!important;
    height:25px!important;
    border-width:3px!important;
    box-shadow:0 4px 10px color-mix(in srgb,var(--manager-case-blue) 24%,transparent)!important;
}
body.mesa-php-shell .case-detail-page .audit-item::after{display:none!important}
body.mesa-php-shell .case-detail-page .audit-item-head{gap:8px!important}
body.mesa-php-shell .case-detail-page .audit-item-head strong{font-size:13px!important}
body.mesa-php-shell .case-detail-page .audit-item p{font-size:11px!important;line-height:1.5!important}
/* Adjuntos: tarjetas identificables y acción de descarga visible. */
body.mesa-php-shell .case-detail-page .case-pane[data-case-panel="archivos"]{padding:18px!important}
body.mesa-php-shell .case-detail-page .case-pane[data-case-panel="archivos"]>.card-head{margin:-18px -18px 16px!important}
body.mesa-php-shell .case-detail-page .files{
    grid-template-columns:repeat(3,minmax(0,1fr))!important;
    gap:12px!important;
}
body.mesa-php-shell .case-detail-page .file{
    position:relative!important;
    min-height:108px!important;
    display:grid!important;
    grid-template-columns:42px minmax(0,1fr)!important;
    grid-template-rows:auto auto!important;
    align-items:center!important;
    gap:8px 11px!important;
    padding:14px!important;
    border:1px solid var(--manager-case-line)!important;
    border-radius:12px!important;
    background:linear-gradient(145deg,var(--manager-case-surface),var(--manager-case-soft))!important;
    box-shadow:0 7px 18px rgba(25,55,83,.06)!important;
}
body.mesa-php-shell .case-detail-page .file::before{
    content:"↥";
    width:42px;
    height:42px;
    display:grid;
    grid-row:1/3;
    place-items:center;
    border-radius:11px;
    color:var(--manager-case-blue);
    background:color-mix(in srgb,var(--manager-case-blue) 12%,var(--manager-case-surface));
    font-size:18px;
    font-weight:900;
}
body.mesa-php-shell .case-detail-page .file>div{min-width:0!important}
body.mesa-php-shell .case-detail-page .file strong{display:block!important;overflow:hidden!important;color:var(--mesa-theme-heading,#17334d)!important;font-size:12px!important;text-overflow:ellipsis!important;white-space:nowrap!important}
body.mesa-php-shell .case-detail-page .file .meta{margin-top:4px!important;color:var(--manager-case-muted)!important;font-size:9px!important;line-height:1.45!important}
body.mesa-php-shell .case-detail-page .file .btn{
    grid-column:2!important;
    width:max-content!important;
    min-height:31px!important;
    padding:6px 10px!important;
}
body.mesa-php-shell .case-detail-page .file .btn::before{content:"↓";margin-right:6px;font-weight:900}

@media(max-width:1050px){
    body.mesa-php-shell .case-detail-page .files{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media(max-width:760px){
    body.mesa-php-shell .case-detail-page .manager-ticket-modal-scroll{padding:7px!important}
    body.mesa-php-shell .case-detail-page .case-dialog.is-embedded{border-radius:13px!important}
    body.mesa-php-shell .case-detail-page .case-modal-header{min-height:92px!important;padding:16px!important}
    body.mesa-php-shell .case-detail-page .case-modal-header-actions{align-self:flex-start!important}
    body.mesa-php-shell .case-detail-page .case-modal-header .case-chat-launcher{min-width:40px!important;padding:5px!important}
    body.mesa-php-shell .case-detail-page .case-tabs{gap:4px!important;padding:8px!important}
    body.mesa-php-shell .case-detail-page .case-tab{flex:1 1 0!important;justify-content:center!important;padding:7px!important;font-size:10px!important}
    body.mesa-php-shell .case-detail-page .case-tab::before{display:none!important}
    body.mesa-php-shell .case-detail-page .case-modal-content{padding:9px!important}
    body.mesa-php-shell .case-detail-page .manager-request-overview,
    body.mesa-php-shell .case-detail-page .manager-task-guide,
    body.mesa-php-shell .case-detail-page .manager-email-preference,
    body.mesa-php-shell .case-detail-page .case-modal-content .stage-summary,
    body.mesa-php-shell .case-detail-page .case-panel-toggle{margin:9px!important}
    body.mesa-php-shell .case-detail-page .manager-email-preference{align-items:center!important;flex-direction:row!important}
    body.mesa-php-shell .case-detail-page .manager-email-preference form,
    body.mesa-php-shell .case-detail-page .manager-email-preference button{width:auto!important}
    body.mesa-php-shell .case-detail-page .audit-log{grid-template-columns:1fr!important}
    body.mesa-php-shell .case-detail-page .files{grid-template-columns:1fr!important}
}
@media(max-width:480px){
    body.mesa-php-shell .case-detail-page .case-modal-header{display:grid!important;grid-template-columns:minmax(0,1fr) auto!important;gap:10px!important}
    body.mesa-php-shell .case-detail-page .case-modal-header h2{font-size:18px!important}
    body.mesa-php-shell .case-detail-page .case-modal-header p{font-size:10px!important}
    body.mesa-php-shell .case-detail-page .case-tab{font-size:9px!important}
    body.mesa-php-shell .case-detail-page .manager-request-overview-item{padding:12px!important}
    body.mesa-php-shell .case-detail-page .manager-request-overview-meta{grid-template-columns:1fr!important}
    body.mesa-php-shell .case-detail-page .manager-request-overview-item.is-description,
    body.mesa-php-shell .case-detail-page .manager-request-overview-meta>div+div{
        padding-left:12px!important;
        border-left:0!important;
        border-top:1px solid var(--manager-case-line)!important;
    }
    body.mesa-php-shell .case-detail-page .manager-guide-head{grid-template-columns:30px minmax(0,1fr)!important}
    body.mesa-php-shell .case-detail-page .manager-guide-icon{width:30px!important;height:30px!important}
    body.mesa-php-shell .case-detail-page .manager-task-guide h3{font-size:14px!important}
    body.mesa-php-shell .case-detail-page .manager-email-preference .email-preference-copy p{display:none!important}
    body.mesa-php-shell .case-detail-page .file{grid-template-columns:36px minmax(0,1fr)!important;padding:11px!important}
body.mesa-php-shell .case-detail-page .file::before{width:36px;height:36px!important}
}
</style>

<style id="manager-case-palette-correction">
/*
 * Corrección de contraste y jerarquía. El id del diálogo evita que la hoja
 * corporativa, que se inyecta al final, vuelva a pintar estos componentes.
 */
body.mesa-php-shell .case-detail-page #caseDialog.case-dialog.is-embedded{
    border-color:var(--mesa-theme-border)!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{
    min-height:82px!important;
    display:flex!important;
    align-items:center!important;
    justify-content:space-between!important;
    gap:18px!important;
    padding:17px clamp(16px,2vw,28px)!important;
    border:0!important;
    border-bottom:1px solid var(--mesa-theme-border)!important;
    color:var(--mesa-theme-text)!important;
    background:
        radial-gradient(circle at 92% 18%,color-mix(in srgb,var(--mesa-shell-color) 17%,transparent) 0 70px,transparent 71px),
        linear-gradient(125deg,color-mix(in srgb,var(--mesa-shell-color) 10%,var(--mesa-theme-surface)),var(--mesa-theme-surface) 64%)!important;
    box-shadow:none!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header::after{display:none!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header>div:first-child{min-width:0!important;flex:1 1 auto!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-title-line{gap:7px!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header h2{
    margin:5px 0 0!important;
    color:var(--mesa-theme-heading)!important;
    font-size:clamp(18px,1.45vw,24px)!important;
    line-height:1.2!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header p{
    margin:4px 0 0!important;
    color:var(--mesa-theme-muted)!important;
    font-size:clamp(10px,.72vw,12px)!important;
    line-height:1.4!important;
    opacity:1!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-code,
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-status{
    border:1px solid color-mix(in srgb,var(--mesa-shell-color) 32%,var(--mesa-theme-border))!important;
    color:var(--mesa-theme-heading)!important;
    background:color-mix(in srgb,var(--mesa-shell-color) 10%,var(--mesa-theme-surface))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header-actions{
    position:relative!important;
    z-index:2!important;
    display:flex!important;
    flex:0 0 auto!important;
    align-items:center!important;
    gap:8px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-header-form{display:flex!important;margin:0!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-toggle,
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-chat-launcher{
    position:relative!important;
    inset:auto!important;
    min-height:42px!important;
    display:inline-flex!important;
    align-items:center!important;
    gap:8px!important;
    padding:6px 11px 6px 7px!important;
    border:1px solid color-mix(in srgb,var(--mesa-shell-color) 38%,var(--mesa-theme-border))!important;
    border-radius:11px!important;
    color:var(--mesa-theme-on-primary)!important;
    background:linear-gradient(145deg,var(--mesa-shell-color),color-mix(in srgb,var(--mesa-shell-color) 88%,var(--mesa-theme-accent)))!important;
    box-shadow:0 6px 16px color-mix(in srgb,var(--mesa-shell-dark) 20%,transparent)!important;
    cursor:pointer!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-toggle{
    border-color:color-mix(in srgb,var(--mesa-state-success) 55%,var(--mesa-theme-border))!important;
    color:var(--mesa-theme-heading)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-toggle.is-off{
    border-color:var(--mesa-theme-border)!important;
    color:var(--mesa-theme-muted)!important;
    background:var(--mesa-theme-soft)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-icon,
body.mesa-php-shell .case-detail-page #caseDialog .case-chat-launcher-icon{
    width:29px!important;
    height:29px!important;
    display:grid!important;
    flex:0 0 29px!important;
    place-items:center!important;
    border-radius:9px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-icon{
    color:var(--mesa-state-success)!important;
    background:color-mix(in srgb,var(--mesa-state-success) 12%,var(--mesa-theme-surface))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-toggle.is-off .manager-mail-icon{
    color:var(--mesa-theme-muted)!important;
    background:color-mix(in srgb,var(--mesa-theme-muted) 12%,var(--mesa-theme-surface))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-icon svg,
body.mesa-php-shell .case-detail-page #caseDialog .case-chat-launcher-icon svg{
    width:17px!important;
    height:17px!important;
    fill:none!important;
    stroke:currentColor!important;
    stroke-width:1.9!important;
    stroke-linecap:round!important;
    stroke-linejoin:round!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-slash{stroke-width:2.5!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-copy,
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-copy strong,
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-copy small{display:block!important;text-align:left!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-copy strong{color:inherit!important;font-size:10px!important;line-height:1.05!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-copy small{margin-top:2px!important;color:inherit!important;font-size:8px!important;font-weight:750!important;opacity:.82!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-chat-launcher-icon{
    color:var(--mesa-theme-on-primary)!important;
    background:color-mix(in srgb,var(--mesa-theme-on-primary) 15%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-chat-launcher-copy strong{color:var(--mesa-theme-on-primary)!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-toggle:hover,
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-chat-launcher:hover{transform:translateY(-1px)!important}

body.mesa-php-shell .case-detail-page #caseDialog .case-tabs{
    border-color:var(--mesa-theme-border)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tab{
    border-color:transparent!important;
    color:var(--mesa-theme-muted)!important;
    background:transparent!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tab::before{
    color:var(--mesa-theme-link)!important;
    background:var(--mesa-theme-soft)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tab.active{
    border-color:var(--mesa-shell-color)!important;
    color:var(--mesa-theme-on-primary)!important;
    background:var(--mesa-shell-color)!important;
    box-shadow:0 5px 13px color-mix(in srgb,var(--mesa-shell-color) 22%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tab.active::before{
    color:var(--mesa-shell-color)!important;
    background:var(--mesa-theme-on-primary)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content{background:var(--mesa-theme-bg)!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-dialog-panes .card.case-pane{
    border-color:var(--mesa-theme-border)!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane>.card-head{
    border-color:var(--mesa-theme-border)!important;
    background:linear-gradient(110deg,color-mix(in srgb,var(--mesa-shell-color) 8%,var(--mesa-theme-surface)),var(--mesa-theme-surface))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane>.card-head :is(h2,strong){color:var(--mesa-theme-heading)!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane>.card-head :is(p,.muted){color:var(--mesa-theme-muted)!important}

body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview{
    grid-template-columns:1fr!important;
    gap:0!important;
    border-color:var(--mesa-theme-border)!important;
    border-left-color:var(--mesa-shell-color)!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item{
    min-height:0!important;
    padding:12px 16px!important;
    border:0!important;
    background:transparent!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item:first-child{
    padding-bottom:11px!important;
    border-bottom:1px solid var(--mesa-theme-border)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item.is-description{
    padding-top:11px!important;
    border:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item>span,
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta span{color:var(--mesa-theme-muted)!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item>span::before{background:var(--mesa-shell-color)!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item strong{
    margin-top:4px!important;
    color:var(--mesa-theme-heading)!important;
    font-size:clamp(13px,.9vw,15px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item p{
    max-width:110ch!important;
    margin:5px 0 0!important;
    padding:0!important;
    border:0!important;
    color:var(--mesa-theme-text)!important;
    background:transparent!important;
    font-size:clamp(12px,.76vw,14px)!important;
    line-height:1.55!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta{
    grid-template-columns:repeat(2,minmax(0,1fr))!important;
    border-color:var(--mesa-theme-border)!important;
    background:var(--mesa-theme-soft)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta>div{padding:9px 16px!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta strong{color:var(--mesa-theme-heading)!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-task-guide{
    border-color:color-mix(in srgb,var(--mesa-shell-color) 38%,var(--mesa-theme-border))!important;
    border-left-color:var(--mesa-shell-color)!important;
    color:var(--mesa-theme-text)!important;
    background:linear-gradient(115deg,color-mix(in srgb,var(--mesa-shell-color) 7%,var(--mesa-theme-surface)),var(--mesa-theme-surface))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-task-guide :is(h3,strong){color:var(--mesa-theme-heading)!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-task-guide :is(p,small,.manager-guide-kicker){color:var(--mesa-theme-muted)!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-guide-icon{color:var(--mesa-theme-on-primary)!important;background:var(--mesa-shell-color)!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-guide-steps,
body.mesa-php-shell .case-detail-page #caseDialog .manager-guide-steps>span{
    border-color:var(--mesa-theme-border)!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .stage-summary,
body.mesa-php-shell .case-detail-page #caseDialog .stage-data{
    border-color:var(--mesa-theme-border)!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-soft)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-panel-toggle{
    border-color:var(--mesa-theme-border)!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-panel-toggle>summary{
    color:var(--mesa-theme-heading)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-panel-toggle[open]>summary{background:var(--mesa-theme-soft)!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-panel-toggle-body{color:var(--mesa-theme-text)!important;background:var(--mesa-theme-surface)!important}
body.mesa-php-shell .case-detail-page #caseDialog .card.case-pane[data-case-panel="resumen"]:has(.derivation-service-menu:not([hidden])),
body.mesa-php-shell .case-detail-page #caseDialog .case-panel-toggle.derivation-panel:has(.derivation-service-menu:not([hidden])){
    position:relative;
    z-index:20;
    overflow:visible!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .derivation-row:has(.derivation-service-menu:not([hidden])){
    position:relative;
    z-index:21;
}
body.mesa-php-shell .case-detail-page #caseDialog :is(.solution-guide,.new-solution-panel){
    border-color:color-mix(in srgb,var(--mesa-shell-color) 38%,var(--mesa-theme-border))!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-soft)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog :is(button.primary,.btn.primary){
    border-color:var(--mesa-shell-color)!important;
    color:var(--mesa-theme-on-primary)!important;
    background:linear-gradient(145deg,var(--mesa-shell-color),color-mix(in srgb,var(--mesa-shell-color) 88%,var(--mesa-theme-accent)))!important;
}

@media(max-width:760px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{
        min-height:0!important;
        display:grid!important;
        grid-template-columns:minmax(0,1fr)!important;
        gap:12px!important;
        padding:14px!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header-actions{
        width:100%!important;
        justify-content:flex-start!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-toggle,
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-chat-launcher{min-width:0!important}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview{margin:9px!important}
}
@media(max-width:480px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header-actions{display:grid!important;grid-template-columns:1fr 1fr!important}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-mail-toggle,
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-chat-launcher{width:100%!important;justify-content:center!important}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta{grid-template-columns:1fr!important}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta>div+div{border-top:1px solid var(--mesa-theme-border)!important;border-left:0!important}
}
</style>

<style id="manager-case-responsive-type">
/* Escala tipográfica responsive para Casos Asignados del Gestor. */
:root{
    --gc-type-xs:clamp(.72rem,.64rem + .16vw,.79rem);
    --gc-type-sm:clamp(.78rem,.69rem + .19vw,.86rem);
    --gc-type-md:clamp(.84rem,.75rem + .23vw,.93rem);
    --gc-type-lg:clamp(.93rem,.84rem + .29vw,1.05rem);
    --gc-type-xl:clamp(1.06rem,.95rem + .4vw,1.2rem);
    --gc-type-xxl:clamp(1.22rem,1.05rem + .62vw,1.5rem);
}

/* Menú lateral: acceso a Casos asignados en esta vista. */
body.mesa-php-shell .mesa-php-nav a[href*="modo=mis_tickets"]{
    font-size:clamp(.84rem,.78rem + .2vw,.93rem)!important;
}

/* Cabecera de bandejas y contador. */
.mode-link{
    font-size:var(--gc-type-md);
}
.count{
    font-size:var(--gc-type-xs);
}

/* Filtros del listado del gestor. */
.manager-filter-field label{
    font-size:var(--gc-type-sm);
}
.manager-filter-count{
    font-size:var(--gc-type-sm);
}

/* Tabla de casos asignados. */
th{
    font-size:var(--gc-type-xs);
}
td,
.ticket-title{
    font-size:var(--gc-type-sm);
}
.badge{
    font-size:var(--gc-type-xs);
}

/* Árbol de casos y acciones rápidas. */
.case-code{
    font-size:var(--gc-type-xs);
}
.case-status{
    font-size:var(--gc-type-xs);
}
.case-title{
    font-size:var(--gc-type-md);
}
.case-service,
.case-row-meta,
.branch-action{
    font-size:var(--gc-type-sm);
}
.case-open{
    font-size:var(--gc-type-sm);
}

/* Cabecera del detalle de caso asignado. */
.case-modal-header h2{
    font-size:var(--gc-type-xxl);
}
.case-modal-header p{
    font-size:var(--gc-type-sm);
}
.case-tab{
    font-size:var(--gc-type-md);
}

/* Información del gestor, SLA, fechas y estados. */
.manager-request-overview-item > span,
.manager-request-overview-meta span,
.stage-data span{
    font-size:var(--gc-type-xs);
}
.manager-request-overview-item strong{
    font-size:var(--gc-type-lg);
}
.manager-request-overview-item p,
.manager-request-overview-meta strong,
.stage-data strong{
    font-size:var(--gc-type-md);
}
.manager-task-guide h3{
    font-size:var(--gc-type-xl);
}
.manager-task-guide p,
.manager-guide-steps small{
    font-size:var(--gc-type-sm);
}
.manager-guide-steps strong{
    font-size:var(--gc-type-md);
}

/* Tarjetas de historial y textos internos de acciones. */
.action-summary-head,
.action-summary-grid span,
.action-rating-summary span,
.action-detail summary,
.audit-item-label,
.audit-item-time,
.audit-item-meta{
    font-size:var(--gc-type-xs);
}
.action-summary-grid strong,
.action-rating-summary strong,
.audit-item p,
.action-detail p{
    font-size:var(--gc-type-sm);
}
.audit-item-head strong{
    font-size:var(--gc-type-md);
}

/* Botones del módulo con escala proporcional. */
.btn,
button,
.email-toggle,
.manager-ticket-modal-close{
    font-size:var(--gc-type-sm);
}

@media (max-width: 1366px){
    .case-modal-header h2{
        font-size:clamp(1.16rem,1.03rem + .56vw,1.38rem);
    }
}
</style>

<style id="manager-case-readable-density">
/* Ajuste local de legibilidad para Casos Asignados del Gestor. */
:root{
    --gc-readable-body:clamp(14px,.84rem + .22vw,16px);
    --gc-readable-secondary:clamp(13px,.78rem + .18vw,15px);
    --gc-readable-title:clamp(16px,.96rem + .42vw,20px);
}

body.mesa-php-shell main.shell{
    font-size:var(--gc-readable-body);
}

/* Listado, filtros y menú lateral. */
body.mesa-php-shell .mesa-php-nav a[href*="modo=mis_tickets"]{
    min-height:44px!important;
    padding:10px 11px!important;
    font-size:var(--gc-readable-secondary)!important;
}
.mode-link{
    min-height:40px;
    padding:9px 13px;
    font-size:var(--gc-readable-secondary)!important;
}
.manager-case-filters{
    gap:12px;
    margin-bottom:16px;
    padding:14px;
}
.manager-filter-field{
    gap:7px;
}
.manager-filter-field label,
.manager-filter-count{
    font-size:var(--gc-readable-secondary)!important;
}
.manager-filter-field input,
.manager-filter-field select{
    height:42px;
    padding:9px 11px;
    font-size:var(--gc-readable-body)!important;
}
th{
    padding:11px 12px;
    font-size:var(--gc-readable-secondary)!important;
}
td{
    padding:11px 12px;
    font-size:var(--gc-readable-body)!important;
}
.ticket-title{
    font-size:var(--gc-readable-body)!important;
}
.badge,
.case-status{
    padding:5px 9px;
    font-size:var(--gc-readable-secondary)!important;
}
.btn,
button,
.email-toggle,
.manager-ticket-modal-close{
    min-height:40px;
    padding:9px 14px;
    font-size:var(--gc-readable-secondary)!important;
}

/* Árbol y filas de casos. */
.case-row{
    min-height:78px;
    padding:12px 13px;
    gap:9px 12px;
}
.case-code{
    font-size:var(--gc-readable-secondary)!important;
}
/* El identificador del nodo pertenece al contenido del árbol, no a la
   cabecera del detalle. Debe conservar el color de enlace de la paleta. */
body.mesa-php-shell .case-detail-page .case-tree .case-code{
    border:0!important;
    color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))!important;
    background:transparent!important;
    box-shadow:none!important;
}
.case-title{
    font-size:var(--gc-readable-title)!important;
}
.case-service,
.case-row-meta,
.branch-action,
.case-open{
    font-size:var(--gc-readable-secondary)!important;
}
.case-row-meta{
    gap:4px;
}

/* Detalle del caso, SLA, gestor, fechas y estados. */
body.mesa-php-shell .case-detail-page .case-modal-header h2{
    font-size:var(--gc-readable-title)!important;
}
body.mesa-php-shell .case-detail-page .case-modal-header p,
body.mesa-php-shell .case-detail-page .case-pane>.card-head p{
    margin-top:7px!important;
    font-size:var(--gc-readable-secondary)!important;
    line-height:1.45!important;
}
body.mesa-php-shell .case-detail-page .case-pane>.card-head{
    padding:19px 22px!important;
}
body.mesa-php-shell .case-detail-page .case-pane>.card-head h2{
    font-size:var(--gc-readable-title)!important;
}
body.mesa-php-shell .case-detail-page .case-tab{
    min-height:44px!important;
    padding:10px 15px!important;
    font-size:var(--gc-readable-secondary)!important;
}
body.mesa-php-shell .case-detail-page .case-panel-toggle>summary,
body.mesa-php-shell .case-detail-page .case-toggle-copy strong,
body.mesa-php-shell .case-detail-page .solution-guide>span,
body.mesa-php-shell .case-detail-page .solution-guide>strong,
body.mesa-php-shell .case-detail-page .new-solution-panel-head strong,
body.mesa-php-shell .case-detail-page .email-preference-copy strong,
body.mesa-php-shell .case-detail-page .email-preference-status{
    font-size:var(--gc-readable-body)!important;
}
body.mesa-php-shell .case-detail-page .case-toggle-copy small,
body.mesa-php-shell .case-detail-page .solution-guide>p,
body.mesa-php-shell .case-detail-page .new-solution-panel-head p,
body.mesa-php-shell .case-detail-page .new-solution-status,
body.mesa-php-shell .case-detail-page .email-preference-copy p,
body.mesa-php-shell .case-detail-page .file .meta,
body.mesa-php-shell .case-detail-page .file strong{
    font-size:var(--gc-readable-secondary)!important;
    line-height:1.45!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-item,
body.mesa-php-shell .case-detail-page .manager-request-overview-meta>div{
    padding:16px 18px!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-item>span,
body.mesa-php-shell .case-detail-page .manager-request-overview-meta span,
body.mesa-php-shell .case-detail-page .stage-data span{
    font-size:var(--gc-readable-secondary)!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-item strong{
    margin-top:8px!important;
    font-size:var(--gc-readable-title)!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-item p,
body.mesa-php-shell .case-detail-page .manager-request-overview-meta strong,
body.mesa-php-shell .case-detail-page .stage-data strong{
    font-size:var(--gc-readable-body)!important;
    line-height:1.5!important;
}
body.mesa-php-shell .case-detail-page .case-modal-content .stage-data{
    padding:15px 16px!important;
}
body.mesa-php-shell .case-detail-page .manager-email-preference{
    padding:14px 16px!important;
}
body.mesa-php-shell .case-detail-page .manager-task-guide{
    margin:15px 20px!important;
    padding:19px!important;
}
body.mesa-php-shell .case-detail-page .manager-task-guide h3{
    font-size:var(--gc-readable-title)!important;
}
body.mesa-php-shell .case-detail-page .manager-task-guide p,
body.mesa-php-shell .case-detail-page .manager-guide-steps small{
    font-size:var(--gc-readable-secondary)!important;
    line-height:1.45!important;
}
body.mesa-php-shell .case-detail-page .manager-guide-steps{
    margin-top:16px!important;
}
body.mesa-php-shell .case-detail-page .manager-guide-steps>span{
    padding:11px 12px!important;
}
body.mesa-php-shell .case-detail-page .manager-guide-steps strong{
    font-size:var(--gc-readable-body)!important;
}

/* Historial y acciones. */
body.mesa-php-shell .case-detail-page .case-pane[data-case-panel="acciones"],
body.mesa-php-shell .case-detail-page .case-pane[data-case-panel="archivos"]{
    padding:22px!important;
}
body.mesa-php-shell .case-detail-page .action-summary-head{
    padding:15px 17px!important;
    font-size:var(--gc-readable-body)!important;
}
body.mesa-php-shell .case-detail-page .action-summary-body{
    padding:17px!important;
}
body.mesa-php-shell .case-detail-page .action-summary-grid,
body.mesa-php-shell .case-detail-page .action-rating-summary{
    gap:9px;
}
body.mesa-php-shell .case-detail-page .action-summary-grid>div,
body.mesa-php-shell .case-detail-page .action-rating-summary>div{
    min-height:64px;
    padding:10px 11px;
}
body.mesa-php-shell .case-detail-page .action-summary-grid span,
body.mesa-php-shell .case-detail-page .action-rating-summary span,
body.mesa-php-shell .case-detail-page .action-detail summary,
body.mesa-php-shell .case-detail-page .audit-item-label,
body.mesa-php-shell .case-detail-page .audit-item-time,
body.mesa-php-shell .case-detail-page .audit-item-meta{
    font-size:var(--gc-readable-secondary)!important;
}
body.mesa-php-shell .case-detail-page .action-summary-grid strong,
body.mesa-php-shell .case-detail-page .action-rating-summary strong,
body.mesa-php-shell .case-detail-page .action-detail p,
body.mesa-php-shell .case-detail-page .audit-item p{
    font-size:var(--gc-readable-body)!important;
    line-height:1.5!important;
}
body.mesa-php-shell .case-detail-page .audit-log{
    gap:16px!important;
}
body.mesa-php-shell .case-detail-page .audit-item{
    min-height:160px!important;
    padding:17px!important;
}
body.mesa-php-shell .case-detail-page .audit-item-head strong{
    font-size:var(--gc-readable-body)!important;
}

/* La decisión pendiente debe quedar antes de los datos operativos extensos. */
body.mesa-php-shell .case-detail-page #caseDialog
    .case-pane[data-case-panel="resumen"]{
    display:flex!important;
    flex-direction:column!important;
}
body.mesa-php-shell .case-detail-page #caseDialog
    .case-pane[data-case-panel="resumen"]>*{
    order:2;
}
body.mesa-php-shell .case-detail-page #caseDialog
    .case-pane[data-case-panel="resumen"]>.card-head{
    order:0;
}
body.mesa-php-shell .case-detail-page #caseDialog
    .case-pane[data-case-panel="resumen"]>.ready-approval{
    order:1;
    margin:16px 18px 4px;
}

@media(max-width:760px){
    body.mesa-php-shell .case-detail-page .case-modal-header h2{
        font-size:clamp(16px,4.2vw,20px)!important;
    }
    body.mesa-php-shell .case-detail-page .case-tab{
        min-height:42px!important;
        padding:9px 10px!important;
        font-size:13px!important;
    }
    body.mesa-php-shell .case-detail-page .case-pane[data-case-panel="acciones"],
    body.mesa-php-shell .case-detail-page .case-pane[data-case-panel="archivos"]{
        padding:16px!important;
    }
    body.mesa-php-shell .case-detail-page .audit-item{
        min-height:0!important;
    }
}
</style>

<style id="manager-case-adaptive-compact-density">
/* Reduce el espacio de las fichas sin modificar la escala tipográfica. */
body.mesa-php-shell .case-detail-page{
    --case-row-block:clamp(7px,.55vw,10px);
    --case-row-inline:clamp(9px,.75vw,12px);
    --case-tree-gap:clamp(4px,.35vw,6px);
}
body.mesa-php-shell .case-detail-page .case-tree{
    gap:var(--case-tree-gap)!important;
}
body.mesa-php-shell .case-detail-page .case-row{
    min-height:clamp(62px,4.8vw,70px)!important;
    padding:var(--case-row-block) var(--case-row-inline)!important;
    gap:5px 10px!important;
}
body.mesa-php-shell .case-detail-page .case-code-line{margin-bottom:0!important}
body.mesa-php-shell .case-detail-page .case-row-meta{gap:1px!important}
body.mesa-php-shell .case-detail-page .case-service{margin-top:0!important}
body.mesa-php-shell .case-detail-page .branch-action{line-height:1.25!important}
body.mesa-php-shell .case-detail-page .case-children{
    gap:var(--case-tree-gap)!important;
    margin-top:var(--case-tree-gap)!important;
    margin-bottom:0!important;
    margin-left:clamp(11px,1.2vw,17px)!important;
    padding-left:clamp(11px,1.2vw,16px)!important;
}
body.mesa-php-shell .case-detail-page .case-children>.case-branch::before,
body.mesa-php-shell .case-detail-page .case-children>.case-leaf::before{
    top:clamp(27px,2.35vw,32px)!important;
    width:clamp(11px,1.2vw,16px)!important;
}
body.mesa-php-shell .case-detail-page .manager-request-overview-item,
body.mesa-php-shell .case-detail-page .manager-request-overview-meta>div{
    padding:clamp(11px,.9vw,14px)!important;
}
body.mesa-php-shell .case-detail-page .case-modal-content .stage-data{
    padding:clamp(9px,.75vw,12px)!important;
}
body.mesa-php-shell .case-detail-page .manager-email-preference{
    padding:clamp(9px,.75vw,12px) clamp(14px,1.4vw,20px)!important;
}
body.mesa-php-shell .case-detail-page .manager-task-guide{
    margin:clamp(9px,.8vw,13px) clamp(12px,1.4vw,18px)!important;
    padding:clamp(12px,1vw,15px)!important;
}
body.mesa-php-shell .case-detail-page .manager-task-guide p{margin-top:3px!important}
body.mesa-php-shell .case-detail-page .manager-guide-steps{
    margin-top:clamp(8px,.7vw,11px)!important;
}
body.mesa-php-shell .case-detail-page .manager-guide-steps>span{
    padding:clamp(7px,.55vw,9px) clamp(9px,.7vw,11px)!important;
}

@media (max-height:800px) and (min-width:761px){
    body.mesa-php-shell .case-detail-page{
        --case-row-block:6px;
        --case-row-inline:9px;
        --case-tree-gap:4px;
    }
    body.mesa-php-shell .case-detail-page .case-row{min-height:60px!important}
    body.mesa-php-shell .case-detail-page .manager-task-guide{margin:8px 14px!important;padding:11px 13px!important}
    body.mesa-php-shell .case-detail-page .manager-guide-steps{margin-top:7px!important}
    body.mesa-php-shell .case-detail-page .manager-guide-steps>span{padding:6px 9px!important}
}

@media (max-width:760px){
    body.mesa-php-shell .case-detail-page .case-row{
        min-height:0!important;
        padding:10px!important;
        gap:7px!important;
    }
    body.mesa-php-shell .case-detail-page .case-children{
        margin-left:8px!important;
        padding-left:10px!important;
    }
    body.mesa-php-shell .case-detail-page .case-children>.case-branch::before,
    body.mesa-php-shell .case-detail-page .case-children>.case-leaf::before{
        width:10px!important;
    }
}
</style>

<style id="manager-case-plain-identifiers">
/* Identificador y estado del listado: texto limpio, legible y sin burbujas. */
body.mesa-php-shell tr[data-manager-case-row] > td:first-child > .badge,
body.mesa-php-shell tr[data-manager-case-row] > td:nth-child(5) > .badge{
    display:inline!important;
    min-width:0!important;
    margin:0!important;
    padding:0!important;
    border:0!important;
    border-radius:0!important;
    box-shadow:none!important;
    background:transparent!important;
    font-size:var(--gc-readable-secondary,14px)!important;
    line-height:1.35!important;
    white-space:normal!important;
}
body.mesa-php-shell tr[data-manager-case-row] > td:first-child > .badge{
    color:var(--mesa-theme-link,var(--mesa-shell-color,#0f6fec))!important;
    font-weight:850!important;
}
body.mesa-php-shell tr[data-manager-case-row] > td:nth-child(5) > .badge{
    color:var(--mesa-theme-heading,var(--navy,#173b5d))!important;
    font-weight:750!important;
}
body.mesa-php-shell tr[data-manager-case-row][data-manager-case-state="completada"] > td:nth-child(5) > .badge{
    color:var(--mesa-state-success,#087443)!important;
}
body.mesa-php-shell tr[data-manager-case-row][data-manager-case-state="cancelada"] > td:nth-child(5) > .badge,
body.mesa-php-shell tr[data-manager-case-row][data-manager-case-state="cancelado"] > td:nth-child(5) > .badge{
    color:var(--mesa-state-danger,#b42318)!important;
}
body.mesa-php-shell tr[data-manager-case-row][data-manager-case-state="listo_cierre"] > td:nth-child(5) > .badge{
    color:#9a6500!important;
}
body.mesa-php-shell tr[data-manager-case-row][data-manager-case-state="en_proceso"] > td:nth-child(5) > .badge,
body.mesa-php-shell tr[data-manager-case-row][data-manager-case-state="pendiente"] > td:nth-child(5) > .badge,
body.mesa-php-shell tr[data-manager-case-row][data-manager-case-state="en_espera_solicitante"] > td:nth-child(5) > .badge{
    color:var(--mesa-theme-link,var(--mesa-shell-color,#0f6fec))!important;
}
</style>

<style id="manager-case-remove-tree-dots">
/* El árbol conserva +/−, pero elimina el marcador circular de las hojas. */
body.mesa-php-shell .case-leaf .branch-dot{
    color:transparent!important;
    background:transparent!important;
    box-shadow:none!important;
}
body.mesa-php-shell .case-leaf .branch-dot::before{content:none!important}
</style>

<style id="manager-case-plain-inbox-tabs">
/* Las bandejas son navegación, no tarjetas: la activa se marca solo con texto
   y una línea inferior para evitar el recuadro azul. */
body.mesa-php-shell .modebar .mode-link.active{
    background:transparent!important;
    color:var(--mesa-theme-link,var(--primary,#0f6fec))!important;
    box-shadow:none!important;
    border-radius:0!important;
    border-bottom:2px solid var(--mesa-theme-link,var(--primary,#0f6fec));
}
body.mesa-php-shell .modebar .mode-link.active .count{
    color:var(--mesa-theme-link,var(--primary,#0f6fec))!important;
    background:color-mix(in srgb,var(--mesa-theme-link,var(--primary,#0f6fec)) 10%,transparent)!important;
}
</style>

<style id="manager-case-plain-inbox-heading">
/* La cabecera de cada bandeja debe integrarse con la superficie blanca del
   listado; no es una tarjeta independiente ni una franja de estado. */
body.mesa-php-shell main.shell:not(.case-detail-page)>section.card>.card-head{
    background:transparent!important;
    border-bottom-color:transparent!important;
}
</style>

<style id="manager-case-organized-list">
/* Casos asignados: ficha organizada por caso, con datos agrupados y acción
   visible, sin obligar al gestor a leer una tabla horizontal estrecha. */
body.mesa-php-shell .manager-case-list{
    overflow:visible!important;
    border:0!important;
    border-radius:0!important;
}
body.mesa-php-shell .manager-case-list table{
    display:block!important;
    width:100%!important;
    border:0!important;
    border-spacing:0!important;
    background:transparent!important;
}
body.mesa-php-shell .manager-case-list thead{display:none!important}
body.mesa-php-shell .manager-case-list tbody{
    display:grid!important;
    gap:12px;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]{
    display:grid!important;
    grid-template-columns:minmax(150px,1.05fr) minmax(210px,1.8fr) minmax(155px,1.25fr) minmax(145px,1.15fr) minmax(128px,.9fr);
    grid-template-areas:
        "case title flow requester action"
        "state created due due action";
    align-items:center;
    width:100%;
    margin:0!important;
    padding:0!important;
    overflow:hidden;
    border:1px solid var(--mesa-theme-border)!important;
    border-left:4px solid var(--mesa-shell-color)!important;
    border-radius:15px!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
    box-shadow:0 8px 22px color-mix(in srgb,var(--mesa-shell-dark) 12%,transparent);
    transition:border-color .18s ease,box-shadow .18s ease,transform .18s ease;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]:hover{
    border-color:color-mix(in srgb,var(--mesa-shell-color) 48%,var(--mesa-theme-border))!important;
    box-shadow:0 12px 28px color-mix(in srgb,var(--mesa-shell-color) 15%,transparent);
    transform:translateY(-1px);
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td{
    min-width:0;
    padding:14px 13px!important;
    border:0!important;
    color:var(--mesa-theme-text)!important;
    background:transparent!important;
    vertical-align:middle;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td::before{
    display:block;
    margin-bottom:4px;
    color:var(--mesa-theme-muted)!important;
    font-size:11px;
    font-weight:850;
    letter-spacing:.045em;
    line-height:1.2;
    text-transform:uppercase;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1){grid-area:case}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1)::before{content:"Identificador"}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(2){grid-area:title}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(2)::before{content:"Asunto"}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(3){grid-area:flow}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(3)::before{content:"Servicio / flujo"}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(4){grid-area:requester}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(4)::before{content:"Solicitante"}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(5){grid-area:state}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(5)::before{content:"Estado"}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(6){grid-area:created}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(6)::before{content:"Creado"}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(7){grid-area:due}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(7)::before{content:"Vencimiento / cierre"}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(8){
    grid-area:action;
    display:flex;
    min-height:100%;
    align-items:center;
    justify-content:center;
    border-left:1px solid var(--mesa-theme-border)!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(8)::before{display:none}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .ticket-title{
    overflow-wrap:anywhere;
    color:var(--mesa-theme-heading)!important;
    font-size:var(--gc-readable-title,18px)!important;
    font-weight:850;
    line-height:1.25;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .ticket-title small{
    display:block;
    margin-top:5px;
    color:var(--mesa-theme-muted)!important;
    font-size:var(--gc-readable-secondary,14px)!important;
    font-weight:650;
    line-height:1.35;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(3),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(4),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(6),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(7){
    overflow-wrap:anywhere;
    font-size:var(--gc-readable-secondary,14px)!important;
    line-height:1.35;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1)>.badge{
    color:var(--mesa-theme-link,var(--mesa-shell-color))!important;
    font-size:var(--gc-readable-body,15px)!important;
    font-weight:900!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(5)>.badge{
    display:inline-flex!important;
    align-items:center;
    min-height:28px;
    padding:5px 10px!important;
    border:1px solid color-mix(in srgb,var(--mesa-theme-link) 35%,var(--mesa-theme-border))!important;
    border-radius:999px!important;
    color:var(--mesa-theme-link)!important;
    background:color-mix(in srgb,var(--mesa-theme-link) 10%,var(--mesa-theme-surface))!important;
    font-size:var(--gc-readable-secondary,14px)!important;
    font-weight:850!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .case-open{
    width:100%;
    min-width:120px;
    min-height:42px;
    white-space:normal;
    text-align:center;
}
@media(max-width:1180px){
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]{
        grid-template-columns:minmax(145px,1fr) minmax(190px,1.55fr) minmax(145px,1.15fr) minmax(130px,1fr);
        grid-template-areas:
            "case title title action"
            "flow requester state action"
            "created due due action";
    }
}
@media(max-width:760px){
    body.mesa-php-shell .manager-case-list tbody{gap:10px}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]{
        display:grid!important;
        grid-template-columns:1fr;
        grid-template-areas:none;
        gap:0;
        padding:7px 0!important;
    }
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td{
        display:grid;
        grid-template-columns:minmax(115px,.42fr) minmax(0,1fr);
        gap:9px;
        align-items:center;
        padding:10px 13px!important;
        border-bottom:1px solid var(--mesa-theme-border)!important;
    }
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td::before{
        margin:0;
        font-size:10px;
    }
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(8){
        display:flex;
        padding:12px 13px!important;
        border-bottom:0!important;
        border-left:0!important;
    }
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .case-open{width:100%}
}
</style>

<style id="manager-case-detail-reference">
/* La ficha se organiza como una pantalla de gestión; el listado conserva su tabla. */
body.mesa-php-shell .case-detail-page.is-stage-view .case-context-summary,
body.mesa-php-shell .case-detail-page.is-stage-view .case-context-closure,
body.mesa-php-shell .case-detail-page.is-stage-view .case-context-tree{
    display:none!important;
}
body.mesa-php-shell .case-detail-page.is-stage-view .manager-ticket-modal-scroll{
    padding:0!important;
    background:var(--mesa-theme-bg,#eef4fa)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{
    min-height:100px!important;
    padding:20px clamp(20px,3vw,42px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header h2{
    margin-top:7px!important;
    font-size:clamp(21px,1.8vw,29px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header p{
    font-size:clamp(11px,.78vw,13px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs{
    padding:10px clamp(20px,3vw,42px)!important;
}
body.mesa-php-shell .case-detail-page .case-stage-progress{
    margin:0!important;
    padding:16px clamp(20px,3vw,42px) 18px!important;
    border-bottom:1px solid var(--mesa-theme-border)!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page .case-stage-progress-head{
    display:flex;
    align-items:flex-end;
    justify-content:space-between;
    gap:12px;
    margin-bottom:14px;
}
body.mesa-php-shell .case-detail-page .case-stage-progress-head strong,
body.mesa-php-shell .case-detail-page .case-stage-progress-head>span:last-child{
    color:var(--mesa-theme-heading)!important;
    font-size:clamp(12px,.85vw,15px)!important;
    font-weight:900!important;
}
body.mesa-php-shell .case-detail-page .case-stage-progress-head>span:last-child{
    color:var(--mesa-theme-link)!important;
    white-space:nowrap;
}
body.mesa-php-shell .case-detail-page .case-stage-progress-kicker{
    display:block;
    margin-bottom:3px;
    color:var(--mesa-theme-muted)!important;
    font-size:10px!important;
    font-weight:850!important;
    letter-spacing:.07em;
    text-transform:uppercase;
}
body.mesa-php-shell .case-detail-page .case-stage-progress-track{
    position:relative;
    display:grid;
    grid-template-columns:repeat(var(--case-stage-count),minmax(130px,1fr));
    gap:10px;
    min-width:0;
}
body.mesa-php-shell .case-detail-page .case-stage-progress-track::before{
    content:"";
    position:absolute;
    top:17px;
    right:7%;
    left:7%;
    height:3px;
    border-radius:99px;
    background:var(--mesa-theme-border);
}
body.mesa-php-shell .case-detail-page .case-stage-step{
    position:relative;
    z-index:1;
    display:grid;
    grid-template-columns:35px minmax(0,1fr);
    grid-template-areas:"marker title" "marker service" "marker state";
    column-gap:9px;
    align-items:center;
    min-width:0;
}
body.mesa-php-shell .case-detail-page .case-stage-step-marker{
    grid-area:marker;
    width:35px;
    height:35px;
    display:grid;
    place-items:center;
    border:3px solid var(--mesa-theme-surface);
    border-radius:50%;
    color:var(--mesa-theme-muted);
    background:var(--mesa-theme-border);
    box-shadow:0 0 0 1px var(--mesa-theme-border);
    font-size:12px;
    font-weight:950;
}
body.mesa-php-shell .case-detail-page .case-stage-step strong{
    grid-area:title;
    overflow:hidden;
    color:var(--mesa-theme-heading)!important;
    font-size:11px!important;
    font-weight:900!important;
    text-overflow:ellipsis;
    white-space:nowrap;
}
body.mesa-php-shell .case-detail-page .case-stage-step small{
    grid-area:service;
    overflow:hidden;
    color:var(--mesa-theme-muted)!important;
    font-size:10px!important;
    text-overflow:ellipsis;
    white-space:nowrap;
}
body.mesa-php-shell .case-detail-page .case-stage-step em{
    grid-area:state;
    color:var(--mesa-theme-muted)!important;
    font-size:9px!important;
    font-style:normal;
    font-weight:750;
}
body.mesa-php-shell .case-detail-page .case-stage-step.is-done .case-stage-step-marker{
    color:var(--mesa-theme-on-primary)!important;
    background:var(--mesa-state-success,#087443)!important;
    box-shadow:0 0 0 1px var(--mesa-state-success,#087443);
}
body.mesa-php-shell .case-detail-page .case-stage-step.is-current .case-stage-step-marker{
    color:var(--mesa-theme-on-primary)!important;
    background:var(--mesa-shell-color)!important;
    box-shadow:0 0 0 1px var(--mesa-shell-color),0 4px 10px color-mix(in srgb,var(--mesa-shell-color) 28%,transparent);
}
body.mesa-php-shell .case-detail-page .case-stage-step.is-current em{color:var(--mesa-shell-color)!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content{
    display:block!important;
    padding:clamp(14px,2.2vw,30px)!important;
    background:var(--mesa-theme-bg)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-dialog-panes,
body.mesa-php-shell .case-detail-page #caseDialog .case-dialog-panes>div{
    display:block!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]{
    width:100%!important;
    margin:0!important;
    overflow:hidden!important;
    border:1px solid var(--mesa-theme-border)!important;
    border-radius:16px!important;
    background:var(--mesa-theme-surface)!important;
    box-shadow:0 9px 24px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 9%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.card-head{
    min-height:68px;
    padding:15px 20px!important;
    background:linear-gradient(110deg,color-mix(in srgb,var(--mesa-shell-color) 10%,var(--mesa-theme-surface)),var(--mesa-theme-surface))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview{
    grid-template-columns:minmax(210px,.72fr) minmax(0,1.28fr)!important;
    margin:18px!important;
    border-left:5px solid var(--mesa-shell-color)!important;
    border-radius:13px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item{
    min-height:112px!important;
    padding:16px 18px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item.is-description{
    padding-left:20px!important;
    border-left:1px solid var(--mesa-theme-border)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta{
    grid-column:1/-1!important;
    grid-template-columns:repeat(2,minmax(0,1fr))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-task-guide{
    margin:14px 18px!important;
    border-radius:13px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content .stage-summary{
    grid-template-columns:repeat(4,minmax(0,1fr))!important;
    gap:10px!important;
    margin:14px 18px!important;
    padding:0!important;
    overflow:visible!important;
    border:0!important;
    background:transparent!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content .stage-data{
    min-width:0;
    padding:14px!important;
    border:1px solid var(--mesa-theme-border)!important;
    border-radius:11px!important;
    background:var(--mesa-theme-soft)!important;
    box-shadow:0 3px 10px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 6%,transparent);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content .stage-data:first-child,
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content .stage-data:last-child{padding-left:14px!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-panel-toggle{
    margin:12px 18px!important;
    border-radius:12px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .closed-case{
    margin:14px 18px!important;
    border-radius:12px!important;
}
@media(max-width:900px){
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview{grid-template-columns:1fr!important}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item.is-description{padding-left:18px!important;border-top:1px solid var(--mesa-theme-border)!important;border-left:0!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content .stage-summary{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media(max-width:640px){
    body.mesa-php-shell .case-detail-page .case-stage-progress{padding-right:14px!important;padding-left:14px!important;overflow-x:auto}
    body.mesa-php-shell .case-detail-page .case-stage-progress-track{min-width:520px}
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content{padding:10px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview,
    body.mesa-php-shell .case-detail-page #caseDialog .manager-task-guide,
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content .stage-summary,
    body.mesa-php-shell .case-detail-page #caseDialog .case-panel-toggle,
    body.mesa-php-shell .case-detail-page #caseDialog .closed-case{margin-right:10px!important;margin-left:10px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content .stage-summary{grid-template-columns:1fr!important}
}
</style>

<style id="manager-case-dashboard-layout">
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-breadcrumb{
    display:flex!important;
    align-items:center!important;
    gap:8px!important;
    width:max-content!important;
    min-height:0!important;
    margin:0 0 9px!important;
    padding:0!important;
    border:0!important;
    border-radius:0!important;
    color:color-mix(in srgb,var(--mesa-theme-on-primary) 78%,transparent)!important;
    background:transparent!important;
    box-shadow:none!important;
    font-size:11px!important;
    font-weight:750!important;
    text-decoration:none!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-breadcrumb:hover{
    color:var(--mesa-theme-on-primary)!important;
    transform:none!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-breadcrumb b{
    color:color-mix(in srgb,var(--mesa-theme-on-primary) 55%,transparent)!important;
    font-size:16px!important;
    font-weight:500!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-breadcrumb strong{
    color:var(--mesa-theme-on-primary)!important;
    font-weight:900!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]{
    display:grid!important;
    grid-template-columns:minmax(0,1fr) minmax(255px,330px)!important;
    column-gap:18px!important;
    align-items:start!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.card-head{
    grid-column:1/-1!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-quick-info{
    grid-column:2!important;
    grid-row:2 / span 30!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.manager-request-overview,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.reopen-notice,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.manager-task-guide,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.closed-case,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.stage-summary,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.ready-approval,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-panel-toggle,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.alert{
    grid-column:1!important;
    min-width:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info{
    margin:18px 18px 14px 0!important;
    padding:0!important;
    overflow:hidden!important;
    border:1px solid var(--mesa-theme-border)!important;
    border-radius:14px!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
    box-shadow:0 8px 20px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 8%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:10px;
    padding:15px 16px 12px;
    border-bottom:1px solid var(--mesa-theme-border);
    background:linear-gradient(110deg,color-mix(in srgb,var(--mesa-shell-color) 8%,var(--mesa-theme-surface)),var(--mesa-theme-surface));
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-head span:first-child{
    display:block;
    color:var(--mesa-theme-muted);
    font-size:9px;
    font-weight:850;
    letter-spacing:.07em;
    text-transform:uppercase;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-head strong{
    display:block;
    margin-top:3px;
    color:var(--mesa-theme-heading);
    font-size:15px;
    font-weight:900;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-mark{
    width:25px;
    height:25px;
    display:grid;
    place-items:center;
    border-radius:8px;
    color:var(--mesa-theme-on-primary);
    background:var(--mesa-shell-color);
    font-size:13px;
    font-weight:950;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-list{
    display:grid;
    gap:0;
    margin:0;
    padding:4px 16px 8px;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-list>div{
    display:grid;
    grid-template-columns:minmax(78px,.62fr) minmax(0,1fr);
    gap:10px;
    padding:10px 0;
    border-bottom:1px solid var(--mesa-theme-border);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-list>div:last-child{border-bottom:0}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-list dt{
    color:var(--mesa-theme-muted);
    font-size:10px;
    font-weight:750;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-list dd{
    margin:0;
    color:var(--mesa-theme-heading);
    font-size:11px;
    font-weight:850;
    line-height:1.35;
    overflow-wrap:anywhere;
}
@media(max-width:900px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]{
        display:block!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-quick-info{
        margin:12px 14px!important;
    }
}
</style>

<style id="manager-case-workspace-reference">
/* Tablero de trabajo: navegación a la izquierda, gestión al centro e información a la derecha. */
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-shell{
    display:flex!important;
    flex-direction:column!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{order:0!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata{
    order:1;
    display:grid;
    grid-template-columns:repeat(5,minmax(0,1fr));
    gap:0;
    padding:0 clamp(22px,3.1vw,42px) 16px;
    border-bottom:1px solid var(--mesa-theme-border);
    color:var(--mesa-theme-text);
    background:var(--mesa-theme-surface);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item{
    min-width:0;
    padding:10px 16px;
    border-left:1px solid var(--mesa-theme-border);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item:first-child{
    padding-left:0;
    border-left:0;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item>span,
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item strong,
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item small{display:block}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item>span{
    color:var(--mesa-theme-muted);
    font-size:10px;
    font-weight:800;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item strong{
    overflow:hidden;
    margin-top:4px;
    color:var(--mesa-theme-heading);
    font-size:13px;
    font-weight:900;
    line-height:1.25;
    text-overflow:ellipsis;
    white-space:nowrap;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item small{
    overflow:hidden;
    margin-top:2px;
    color:var(--mesa-theme-muted);
    font-size:10px;
    font-weight:650;
    text-overflow:ellipsis;
    white-space:nowrap;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item.due strong{
    color:var(--mesa-state-danger,#d92d20);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-progress{order:2!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs{order:3!important;display:none!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content{
    order:4!important;
    display:grid!important;
    grid-template-columns:205px minmax(0,1fr)!important;
    gap:18px!important;
    align-items:start!important;
    padding:18px clamp(20px,2.5vw,34px) 28px!important;
    background:var(--mesa-theme-bg)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav{
    position:sticky;
    top:72px;
    grid-column:1;
    grid-row:1;
    display:grid;
    gap:5px;
    padding:12px;
    border:1px solid var(--mesa-theme-border);
    border-radius:14px;
    background:var(--mesa-theme-surface);
    box-shadow:0 8px 22px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 7%,transparent);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-title{
    padding:3px 8px 7px;
    color:var(--mesa-theme-muted);
    font-size:10px;
    font-weight:900;
    letter-spacing:.07em;
    text-transform:uppercase;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link{
    width:100%;
    min-height:40px!important;
    display:flex!important;
    align-items:center!important;
    gap:9px!important;
    padding:9px 10px!important;
    border:1px solid transparent!important;
    border-radius:10px!important;
    color:var(--mesa-theme-heading)!important;
    background:transparent!important;
    box-shadow:none!important;
    font:800 12px/1.25 Inter,"Segoe UI",Arial,sans-serif!important;
    text-align:left!important;
    text-decoration:none!important;
    cursor:pointer;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link span{
    width:22px;
    height:22px;
    display:grid;
    flex:0 0 auto;
    place-items:center;
    border-radius:7px;
    color:var(--mesa-theme-link);
    background:var(--mesa-theme-soft);
    font-size:11px;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link:hover{
    color:var(--mesa-theme-link)!important;
    background:color-mix(in srgb,var(--mesa-shell-color) 8%,var(--mesa-theme-surface))!important;
    transform:none!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link.active{
    border-color:color-mix(in srgb,var(--mesa-shell-color) 26%,var(--mesa-theme-border))!important;
    color:var(--mesa-theme-on-primary)!important;
    background:var(--mesa-shell-color)!important;
    box-shadow:0 7px 15px color-mix(in srgb,var(--mesa-shell-color) 22%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link.active span{
    color:var(--mesa-shell-color);
    background:var(--mesa-theme-on-primary);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-dialog-panes,
body.mesa-php-shell .case-detail-page #caseDialog .case-dialog-panes>div{
    display:contents!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel]{
    grid-column:2!important;
    min-width:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]{
    grid-template-columns:minmax(0,1fr) minmax(245px,310px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-quick-info{
    margin-right:16px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="acciones"],
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="archivos"]{
    padding:18px!important;
    border:1px solid var(--mesa-theme-border)!important;
    border-radius:15px!important;
    background:var(--mesa-theme-surface)!important;
    box-shadow:0 8px 22px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 7%,transparent)!important;
}
@media(max-width:1050px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata{grid-template-columns:repeat(3,minmax(0,1fr))}
    body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item:nth-child(4){border-left:0}
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content{grid-template-columns:185px minmax(0,1fr)!important;padding-right:16px!important;padding-left:16px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]{grid-template-columns:1fr!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-quick-info{position:static!important;grid-column:1!important;grid-row:auto!important;margin:12px 14px!important}
}
@media(max-width:760px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata{grid-template-columns:repeat(2,minmax(0,1fr));padding:0 14px 10px}
    body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item{padding:8px 9px;border-left:0;border-top:1px solid var(--mesa-theme-border)}
    body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item:nth-child(-n+2){border-top:0}
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content{grid-template-columns:1fr!important;padding:10px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav{position:static;grid-column:1;grid-row:auto;grid-template-columns:repeat(2,minmax(0,1fr))}
    body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-title{grid-column:1/-1}
    body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link{min-height:37px!important;font-size:11px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel]{grid-column:1!important}
}
</style>

<style id="manager-case-workspace-polish">
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{
    min-height:126px!important;
    padding:20px clamp(24px,3vw,40px)!important;
    border-bottom:0!important;
    color:var(--mesa-theme-heading)!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header::after{opacity:.06!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header h2{
    color:var(--mesa-theme-heading)!important;
    font-size:clamp(23px,1.8vw,30px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header p{
    color:var(--mesa-theme-muted)!important;
    font-size:12px!important;
    opacity:1!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-breadcrumb,
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-breadcrumb:hover{
    color:var(--mesa-theme-muted)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-breadcrumb b{
    color:var(--mesa-theme-muted)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-breadcrumb strong{
    color:var(--mesa-theme-heading)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-code,
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header .case-status{
    border-color:color-mix(in srgb,var(--mesa-shell-color) 32%,var(--mesa-theme-border))!important;
    color:var(--mesa-theme-link)!important;
    background:var(--mesa-theme-soft)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata{
    padding-bottom:18px!important;
    box-shadow:0 8px 18px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 5%,transparent);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-progress{
    padding-top:18px!important;
    padding-bottom:20px!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step strong{font-size:12px!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step small{font-size:10px!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav{
    padding:14px 10px!important;
    border:0!important;
    border-radius:16px!important;
    color:var(--mesa-theme-sidebar-text)!important;
    background:linear-gradient(165deg,var(--mesa-shell-dark),color-mix(in srgb,var(--mesa-shell-dark) 84%,var(--mesa-shell-color)) 68%,color-mix(in srgb,var(--mesa-shell-dark) 88%,#000))!important;
    box-shadow:0 14px 30px color-mix(in srgb,var(--mesa-shell-dark) 24%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-title{
    color:color-mix(in srgb,var(--mesa-theme-sidebar-text) 72%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link{
    color:var(--mesa-theme-sidebar-text)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link span{
    color:var(--mesa-theme-sidebar-text)!important;
    background:color-mix(in srgb,var(--mesa-theme-accent) 20%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link:hover{
    color:var(--mesa-theme-sidebar-text)!important;
    background:color-mix(in srgb,var(--mesa-theme-accent) 20%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav-link.active{
    color:var(--mesa-theme-on-primary)!important;
    background:var(--mesa-shell-color)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]{
    border-radius:17px!important;
    box-shadow:0 14px 30px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 8%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.card-head{
    min-height:76px!important;
    padding:18px 20px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.card-head h2{
    font-size:19px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview{
    margin:18px!important;
    border-radius:13px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item strong{
    font-size:14px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item p,
body.mesa-php-shell .case-detail-page #caseDialog .manager-task-guide p,
body.mesa-php-shell .case-detail-page #caseDialog .closed-case p{
    font-size:12px!important;
    line-height:1.55!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info{
    border-radius:13px!important;
    box-shadow:0 10px 22px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 9%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-quick-info{
    grid-column:2!important;
    grid-row:auto!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-list dt{font-size:10px!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-quick-info-list dd{font-size:11px!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-recent-activity{
    grid-column:2!important;
    grid-row:auto!important;
    margin:0 16px 18px 0!important;
    padding:0!important;
    overflow:hidden!important;
    border:1px solid var(--mesa-theme-border)!important;
    border-radius:13px!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
    box-shadow:0 10px 22px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 8%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-recent-activity-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:8px;
    padding:14px 15px 10px;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-recent-activity-head strong{
    color:var(--mesa-theme-heading)!important;
    font-size:14px!important;
    font-weight:900!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-recent-activity-head .case-tab{
    min-height:28px!important;
    padding:5px 8px!important;
    border:0!important;
    border-radius:8px!important;
    color:var(--mesa-theme-link)!important;
    background:var(--mesa-theme-soft)!important;
    font-size:10px!important;
    font-weight:850!important;
    box-shadow:none!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline{
    display:grid;
    gap:0;
    margin:0;
    padding:2px 15px 14px;
    list-style:none;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline li{
    position:relative;
    display:grid;
    grid-template-columns:30px minmax(0,1fr);
    gap:9px;
    min-height:70px;
    padding:4px 0 8px;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline li:not(:last-child)::after{
    position:absolute;
    top:31px;
    bottom:-2px;
    left:14px;
    width:2px;
    border-radius:2px;
    background:var(--mesa-theme-border);
    content:"";
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-dot{
    position:relative;
    z-index:1;
    width:29px;
    height:29px;
    display:grid;
    place-items:center;
    border-radius:50%;
    color:var(--mesa-theme-muted);
    background:var(--mesa-theme-border);
    font-size:12px;
    font-weight:950;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline li.current .case-activity-dot{
    color:var(--mesa-theme-on-primary);
    background:var(--mesa-shell-color);
    box-shadow:0 4px 11px color-mix(in srgb,var(--mesa-shell-color) 25%,transparent);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline li.done .case-activity-dot{
    color:var(--mesa-theme-on-primary);
    background:var(--mesa-state-success);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline strong,
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline p,
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline time{display:block}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline strong{
    color:var(--mesa-theme-heading)!important;
    font-size:11px!important;
    font-weight:900!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline p{
    margin:2px 0!important;
    color:var(--mesa-theme-text)!important;
    font-size:10px!important;
    line-height:1.35!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-activity-timeline time{
    color:var(--mesa-theme-muted)!important;
    font-size:10px!important;
    font-weight:700;
}
body.mesa-php-shell .case-detail-page #caseDialog .closed-case{
    margin:16px 18px 22px!important;
    padding:18px 20px!important;
    border:1px solid color-mix(in srgb,var(--mesa-state-success) 50%,var(--mesa-theme-border))!important;
    border-left:5px solid var(--mesa-state-success)!important;
    border-radius:14px!important;
    background:color-mix(in srgb,var(--mesa-state-success) 7%,var(--mesa-theme-surface))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .closed-case strong{
    color:var(--mesa-theme-heading)!important;
    font-size:14px!important;
}
@media(max-width:1050px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-quick-info,
    body.mesa-php-shell .case-detail-page #caseDialog .case-recent-activity{
        grid-column:1!important;
        grid-row:auto!important;
        margin:12px 14px!important;
    }
}
@media(max-width:760px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{min-height:0!important;padding:16px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-workspace-nav{border-radius:13px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-recent-activity{margin:12px 14px!important}
}
</style>

<style id="manager-case-layout-fixes">
/* Evita que las tarjetas laterales desplacen la gestión hacia abajo. */
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-detail-side{
    grid-column:2!important;
    grid-row:2 / span 30!important;
    display:grid!important;
    align-content:start!important;
    gap:14px!important;
    margin:18px 16px 18px 0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-side>.case-quick-info,
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-side>.case-recent-activity{
    grid-column:auto!important;
    grid-row:auto!important;
    width:auto!important;
    margin:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-progress-track{
    grid-template-columns:repeat(4,minmax(0,1fr))!important;
    gap:0!important;
    padding:0 2.5%!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-progress-track::before{display:none!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step{
    display:grid!important;
    grid-template-columns:1fr!important;
    grid-template-areas:"marker" "title" "service" "state"!important;
    justify-items:center!important;
    gap:3px!important;
    min-height:94px!important;
    text-align:center!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step::after{
    position:absolute;
    z-index:0;
    top:17px;
    left:50%;
    width:100%;
    height:3px;
    border-radius:99px;
    background:var(--mesa-theme-border);
    content:"";
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step:last-child::after{display:none}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step.is-done::after{
    background:var(--mesa-state-success)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step.is-current::after{
    background:var(--mesa-shell-color)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step-marker{
    z-index:1!important;
    grid-area:marker!important;
    width:38px!important;
    height:38px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step strong{
    grid-area:title!important;
    max-width:100%;
    overflow:visible!important;
    text-align:center!important;
    text-overflow:clip!important;
    white-space:normal!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step small{
    grid-area:service!important;
    min-height:14px;
    overflow:visible!important;
    text-align:center!important;
    text-overflow:clip!important;
    white-space:normal!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step em{
    grid-area:state!important;
    color:var(--mesa-theme-muted)!important;
    font-size:10px!important;
    font-weight:800!important;
}
@media(max-width:1050px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-detail-side{
        grid-column:1!important;
        grid-row:auto!important;
        margin:12px 14px!important;
    }
}
@media(max-width:640px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-stage-progress-track{min-width:620px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step{min-height:100px!important}
}
</style>

<style id="manager-case-horizontal-navigation">
/* Navegación de la ficha: una sola fila debajo del flujo y un panel a la vez. */
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-back-button{
    display:inline-flex!important;
    align-items:center!important;
    gap:6px!important;
    width:max-content!important;
    min-height:32px!important;
    margin:0 0 clamp(4px,.45vw,7px)!important;
    padding:6px 11px!important;
    border:1px solid color-mix(in srgb,var(--mesa-shell-color) 28%,var(--mesa-theme-border))!important;
    border-radius:8px!important;
    color:var(--mesa-theme-link)!important;
    background:var(--mesa-theme-soft)!important;
    box-shadow:0 3px 9px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 7%,transparent)!important;
    font-size:clamp(10px,.67vw,12px)!important;
    font-weight:850!important;
    line-height:1!important;
    text-decoration:none!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-back-button:hover{
    color:var(--mesa-theme-on-primary)!important;
    background:var(--mesa-shell-color)!important;
    transform:translateY(-1px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-back-button span{
    font-size:15px!important;
    line-height:1!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-title-line{
    display:flex!important;
    align-items:center!important;
    flex-wrap:wrap!important;
    gap:8px!important;
    margin:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-title-line .case-code,
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-title-line .case-status{
    display:inline-flex!important;
    align-items:center!important;
    min-height:30px!important;
    margin:0!important;
    padding:5px 10px!important;
    border:1px solid color-mix(in srgb,var(--mesa-shell-color) 34%,var(--mesa-theme-border))!important;
    border-radius:8px!important;
    font-size:clamp(12px,.8vw,15px)!important;
    font-weight:900!important;
    line-height:1!important;
    white-space:nowrap!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-title-line .case-code{
    color:var(--mesa-theme-link)!important;
    background:var(--mesa-theme-soft)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-title-line .case-status{
    color:var(--mesa-state-success,#087443)!important;
    background:color-mix(in srgb,var(--mesa-state-success,#087443) 10%,var(--mesa-theme-surface))!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview{
    grid-template-columns:repeat(2,minmax(0,1fr))!important;
    align-items:stretch!important;
    margin:clamp(12px,1.45vw,20px)!important;
    overflow:hidden!important;
    border-left:4px solid var(--mesa-shell-color)!important;
    border-radius:13px!important;
    box-shadow:0 5px 16px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 7%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item{
    min-height:108px!important;
    display:flex!important;
    flex-direction:column!important;
    justify-content:flex-start!important;
    padding:clamp(14px,1.25vw,20px)!important;
    border-bottom:1px solid var(--mesa-theme-border)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item.is-description{
    padding-left:clamp(14px,1.25vw,20px)!important;
    border-top:0!important;
    border-left:1px solid var(--mesa-theme-border)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item>span,
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta span{
    font-size:clamp(11px,.7vw,13px)!important;
    line-height:1.25!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item>span::before{width:5px!important;height:5px!important}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item strong{
    margin-top:7px!important;
    font-size:clamp(14px,.9vw,17px)!important;
    line-height:1.35!important;
    overflow-wrap:anywhere!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item p{
    margin:7px 0 0!important;
    font-size:clamp(13px,.82vw,16px)!important;
    line-height:1.5!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta{
    grid-template-columns:repeat(2,minmax(0,1fr))!important;
    gap:0!important;
    margin-top:0!important;
    padding-top:0!important;
    border-top:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta>div{
    min-height:72px!important;
    padding:clamp(12px,1vw,16px) clamp(14px,1.25vw,20px)!important;
    border-top:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta>div+div{
    padding-left:clamp(14px,1.25vw,20px)!important;
    border-left:1px solid var(--mesa-theme-border)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta strong{
    margin-top:5px!important;
    font-size:clamp(13px,.82vw,16px)!important;
    line-height:1.35!important;
    overflow-wrap:anywhere!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{
    min-height:clamp(92px,8vw,112px)!important;
    height:auto!important;
    align-items:flex-start!important;
    padding:clamp(12px,1.35vw,18px) clamp(16px,3vw,42px) clamp(10px,1.1vw,15px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header>div:first-child{
    min-width:0!important;
    flex:1 1 auto!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-title-line{
    gap:6px!important;
    margin:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header h2{
    max-width:100%!important;
    margin:clamp(3px,.35vw,6px) 0 0!important;
    overflow-wrap:anywhere!important;
    font-size:clamp(20px,1.65vw,29px)!important;
    line-height:1.12!important;
    letter-spacing:-.02em!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header p{
    max-width:100%!important;
    margin:clamp(3px,.35vw,6px) 0 0!important;
    font-size:clamp(10px,.68vw,12px)!important;
    line-height:1.3!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata{
    padding:0 clamp(16px,3vw,42px) clamp(10px,1.1vw,15px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item{
    padding:clamp(7px,.7vw,10px) clamp(9px,1.05vw,16px)!important;
    border-left:0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item>span{
    font-size:clamp(11px,.72vw,13px)!important;
    line-height:1.25!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item strong{
    margin-top:3px!important;
    font-size:clamp(13px,.95vw,16px)!important;
    line-height:1.25!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item small{
    margin-top:1px!important;
    font-size:clamp(11px,.78vw,13px)!important;
    line-height:1.25!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-progress-head strong,
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-progress-head>span:last-child{
    font-size:clamp(13px,.9vw,16px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step strong{
    font-size:clamp(12px,.82vw,15px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step small,
body.mesa-php-shell .case-detail-page #caseDialog .case-stage-step em{
    font-size:clamp(11px,.72vw,13px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs{
    position:relative!important;
    top:auto!important;
    z-index:3!important;
    order:3!important;
    display:flex!important;
    align-items:center!important;
    gap:8px!important;
    min-height:58px!important;
    padding:9px clamp(20px,3vw,42px)!important;
    overflow-x:auto!important;
    overflow-y:hidden!important;
    border-top:1px solid var(--mesa-theme-border)!important;
    border-bottom:1px solid var(--mesa-theme-border)!important;
    background:var(--mesa-theme-surface)!important;
    box-shadow:0 7px 18px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 6%,transparent)!important;
    scrollbar-width:thin;
    scroll-snap-type:x proximity;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab{
    min-height:38px!important;
    display:inline-flex!important;
    flex:0 0 auto!important;
    align-items:center!important;
    gap:8px!important;
    padding:8px 13px!important;
    scroll-snap-align:start;
    border:1px solid transparent!important;
    border-radius:9px!important;
    color:var(--mesa-theme-muted)!important;
    background:transparent!important;
    box-shadow:none!important;
    font-size:clamp(13px,.86vw,16px)!important;
    font-weight:850!important;
    line-height:1.2!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab::before{
    width:22px!important;
    height:22px!important;
    display:grid!important;
    flex:0 0 22px!important;
    place-items:center!important;
    border-radius:7px!important;
    color:var(--mesa-theme-link)!important;
    background:var(--mesa-theme-soft)!important;
    font-size:11px!important;
    font-weight:950!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab[data-case-tab="estructura"]::before{content:"⌘"!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab[data-case-tab="resumen"]::before{content:"▶"!important;font-size:9px!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab[data-case-tab="resumen"].is-solution::before{content:"✓"!important;font-size:11px!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab[data-case-tab="acciones"]::before{content:"↺"!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab[data-case-tab="archivos"]::before{content:"↥"!important}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab:hover{
    border-color:color-mix(in srgb,var(--mesa-shell-color) 24%,var(--mesa-theme-border))!important;
    color:var(--mesa-theme-link)!important;
    background:color-mix(in srgb,var(--mesa-shell-color) 6%,var(--mesa-theme-surface))!important;
    transform:none!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab.active{
    border-color:var(--mesa-shell-color)!important;
    color:var(--mesa-theme-on-primary)!important;
    background:var(--mesa-shell-color)!important;
    box-shadow:0 6px 15px color-mix(in srgb,var(--mesa-shell-color) 24%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab.active::before{
    color:var(--mesa-shell-color)!important;
    background:var(--mesa-theme-on-primary)!important;
}

body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content{
    order:4!important;
    display:block!important;
    min-width:0!important;
    padding:18px clamp(16px,2.5vw,34px) 30px!important;
    background:var(--mesa-theme-bg)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-dialog-panes,
body.mesa-php-shell .case-detail-page #caseDialog .case-dialog-panes>div{
    display:contents!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel]{
    width:100%!important;
    min-width:0!important;
    grid-column:auto!important;
}
/* Esta regla debe ganar a los estilos de cuadrícula de Gestión. */
body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content .case-pane[data-case-panel][hidden]{
    display:none!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="acciones"],
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="archivos"],
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="estructura"]{
    padding:0!important;
    overflow:hidden!important;
    border:1px solid var(--mesa-theme-border)!important;
    border-radius:16px!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
    box-shadow:0 10px 26px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 8%,transparent)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="acciones"]>.card-head,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="archivos"]>.card-head,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="estructura"]>.card-head{
    margin:0!important;
    padding:18px 20px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="acciones"]>.action-summary,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="acciones"]>.audit-log,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="archivos"]>.files{
    margin:16px 18px!important;
}

body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]{
    grid-template-columns:minmax(0,1fr)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-detail-side{
    grid-column:2!important;
    grid-row:2 / span 30!important;
    margin:18px 16px 18px 0!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-detail-side>.case-recent-activity{
    width:auto!important;
    margin:0!important;
}

body.mesa-php-shell .case-detail-page #caseDialog .case-structure-body{
    display:grid!important;
    grid-template-columns:minmax(0,1fr)!important;
    gap:16px!important;
    padding:18px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree,
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-solutions{
    min-width:0;
    padding:16px;
    border:1px solid var(--mesa-theme-border);
    border-radius:13px;
    background:color-mix(in srgb,var(--mesa-theme-soft) 36%,var(--mesa-theme-surface));
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree{
    max-height:clamp(420px,68vh,760px)!important;
    overflow-x:auto!important;
    overflow-y:auto!important;
    align-self:start;
    scrollbar-width:thin;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-structure{min-width:0}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-full-stage-card,
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-row{
    min-width:760px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-row{
    min-height:56px!important;
    padding:7px 10px!important;
    gap:4px 8px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-children{
    margin-left:clamp(34px,4vw,72px)!important;
    padding-left:clamp(18px,2vw,34px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-full-derivations{
    margin-left:8px;
    padding-left:clamp(24px,2.4vw,38px);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations>.case-branch,
body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations>.case-leaf{
    width:calc(100% - clamp(76px,7vw,132px));
    margin-left:clamp(22px,4vw,64px);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-children>.case-branch,
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-children>.case-leaf{
    width:calc(100% - clamp(62px,6vw,112px));
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-full-stage-card{
    padding:10px 12px;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-full-stage-meta{
    gap:8px;
    margin-top:8px;
    padding-top:8px;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-row-main,
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-row-meta{
    line-height:1.15;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree .case-solution-trigger{
    min-height:28px!important;
    padding:4px 8px!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-actions{
    display:flex;
    justify-content:flex-end;
    gap:8px;
    margin-top:10px;
    padding-top:10px;
    border-top:1px solid var(--mesa-theme-border);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-trigger{
    min-height:32px!important;
    padding:6px 10px!important;
    border:1px solid color-mix(in srgb,var(--mesa-shell-color) 30%,var(--mesa-theme-border))!important;
    border-radius:8px!important;
    color:var(--mesa-theme-link)!important;
    background:var(--mesa-theme-soft)!important;
    font-size:clamp(11px,.72vw,13px)!important;
    font-weight:850!important;
    line-height:1.1!important;
    white-space:nowrap;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-trigger:hover{
    color:var(--mesa-theme-on-primary)!important;
    background:var(--mesa-shell-color)!important;
    transform:translateY(-1px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-row .case-solution-trigger{
    grid-column:4;
    justify-self:end;
}
body.mesa-php-shell .case-structure-solution-dialog{
    position:fixed;
    inset:104px 28px auto auto;
    z-index:1000;
    width:min(440px,calc(100% - 28px));
    max-width:none;
    max-height:min(80vh,620px);
    margin:0;
    padding:0;
    border:1px solid var(--mesa-theme-border);
    border-radius:15px;
    color:var(--mesa-theme-text);
    background:var(--mesa-theme-surface);
    box-shadow:0 18px 46px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 26%,transparent);
    transform:none;
}
body.mesa-php-shell .case-structure-solution-dialog::backdrop{
    background:rgba(8,28,49,.52);
    backdrop-filter:blur(3px);
}
body.mesa-php-shell .case-structure-solution-shell{overflow:hidden;border-radius:inherit}
body.mesa-php-shell .case-structure-solution-head{
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:14px;
    padding:16px 18px 13px;
    border-bottom:1px solid var(--mesa-theme-border);
    background:linear-gradient(135deg,var(--mesa-theme-soft),var(--mesa-theme-surface));
    cursor:grab;
    touch-action:none;
    user-select:none;
}
body.mesa-php-shell .case-structure-solution-dialog.is-dragging .case-structure-solution-head{cursor:grabbing}
body.mesa-php-shell .case-structure-solution-head span,
body.mesa-php-shell .case-structure-solution-body>div>span{
    display:block;
    margin-bottom:4px;
    color:var(--mesa-theme-muted);
    font-size:10px;
    font-weight:900;
    letter-spacing:.08em;
    text-transform:uppercase;
}
body.mesa-php-shell .case-structure-solution-head h2{margin:0;color:var(--mesa-theme-heading);font-size:18px;line-height:1.25}
body.mesa-php-shell .case-structure-solution-context{margin:4px 0 0;color:var(--mesa-theme-muted);font-size:12px;line-height:1.35}
body.mesa-php-shell .case-structure-solution-close{
    display:grid;
    width:32px;
    height:32px;
    flex:0 0 auto;
    place-items:center;
    border:1px solid var(--mesa-theme-border);
    border-radius:8px;
    color:var(--mesa-theme-heading);
    background:var(--mesa-theme-surface);
    font-size:22px;
    line-height:1;
    cursor:pointer;
}
body.mesa-php-shell .case-structure-solution-close:hover{color:var(--mesa-theme-on-primary);background:var(--mesa-shell-color)}
body.mesa-php-shell .case-structure-solution-body{display:grid;gap:12px;padding:18px}
body.mesa-php-shell .case-structure-solution-body>div{padding:12px;border:1px solid var(--mesa-theme-border);border-radius:10px;background:color-mix(in srgb,var(--mesa-theme-soft) 32%,var(--mesa-theme-surface))}
body.mesa-php-shell .case-structure-solution-body strong,
body.mesa-php-shell .case-structure-solution-body p{display:block;margin:0;color:var(--mesa-theme-text);font-size:clamp(13px,.85vw,16px);line-height:1.45;overflow-wrap:anywhere}
body.mesa-php-shell .case-structure-solution-body p{white-space:pre-wrap}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-section-head{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    margin-bottom:14px;
    padding-bottom:12px;
    border-bottom:1px solid var(--mesa-theme-border);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-section-head span{
    display:block;
    margin-bottom:3px;
    color:var(--mesa-theme-muted);
    font-size:clamp(10px,.68vw,12px);
    font-weight:900;
    letter-spacing:.08em;
    text-transform:uppercase;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-section-head strong{
    color:var(--mesa-theme-heading);
    font-size:clamp(17px,1.05vw,21px);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-timeline{
    display:grid;
    gap:10px;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-item{
    position:relative;
    display:grid;
    grid-template-columns:34px minmax(0,1fr);
    gap:10px;
    padding:12px;
    border:1px solid var(--mesa-theme-border);
    border-radius:11px;
    background:var(--mesa-theme-surface);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-number{
    width:30px;
    height:30px;
    display:grid;
    place-items:center;
    border-radius:50%;
    color:var(--mesa-theme-on-primary);
    background:var(--mesa-shell-color);
    font-size:11px;
    font-weight:950;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-item div>span{
    display:block;
    color:var(--mesa-theme-muted);
    font-size:clamp(10px,.66vw,12px);
    font-weight:900;
    letter-spacing:.05em;
    text-transform:uppercase;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-item strong{
    display:block;
    margin-top:3px;
    color:var(--mesa-theme-heading);
    font-size:clamp(13px,.82vw,16px);
    line-height:1.35;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-item p,
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-item small{
    display:block;
    margin:5px 0 0;
    color:var(--mesa-theme-text);
    font-size:clamp(12px,.76vw,14px);
    line-height:1.45;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-solution-item small{color:var(--mesa-theme-muted)}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-metrics{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:9px;
    margin:0 0 14px;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-metrics>div{
    display:flex;
    align-items:center;
    gap:9px;
    min-width:0;
    padding:10px 12px;
    border:1px solid var(--mesa-theme-border);
    border-radius:10px;
    background:var(--mesa-theme-surface);
}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-metrics strong{color:var(--mesa-theme-link);font-size:clamp(18px,1.2vw,23px);line-height:1}
body.mesa-php-shell .case-detail-page #caseDialog .case-structure-metrics span{color:var(--mesa-theme-muted);font-size:clamp(11px,.7vw,13px);font-weight:800;line-height:1.25}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-list{display:grid;gap:13px;margin:0;padding:0;list-style:none}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage{position:relative;min-width:0;padding-left:38px}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage::before{position:absolute;top:31px;bottom:-13px;left:14px;width:2px;background:color-mix(in srgb,var(--mesa-shell-color) 24%,var(--mesa-theme-border));content:""}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage:last-child::before{display:none}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-number{position:absolute;top:13px;left:0;z-index:1;width:30px;height:30px;display:grid;place-items:center;border:3px solid var(--mesa-theme-surface);border-radius:50%;color:var(--mesa-theme-on-primary);background:var(--mesa-shell-color);box-shadow:0 0 0 1px var(--mesa-shell-color);font-size:12px;font-weight:950}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage.is-current .case-full-stage-number{box-shadow:0 0 0 2px var(--mesa-shell-color),0 5px 12px color-mix(in srgb,var(--mesa-shell-color) 26%,transparent)}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-card{display:grid;min-width:0;padding:14px 15px;border:1px solid var(--mesa-theme-border);border-radius:12px;background:var(--mesa-theme-surface);box-shadow:0 4px 12px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 6%,transparent)}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage.is-current .case-full-stage-card{border-color:color-mix(in srgb,var(--mesa-shell-color) 48%,var(--mesa-theme-border));box-shadow:0 5px 15px color-mix(in srgb,var(--mesa-shell-color) 12%,transparent)}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-topline{display:flex;align-items:center;justify-content:space-between;gap:10px}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-topline>span{color:var(--mesa-theme-muted);font-size:clamp(10px,.67vw,12px);font-weight:850;text-transform:uppercase;letter-spacing:.05em}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-status{display:inline-flex;align-items:center;min-height:24px;padding:4px 9px;border-radius:999px;color:var(--mesa-theme-link);background:var(--mesa-theme-soft);font-size:clamp(10px,.65vw,12px);white-space:nowrap}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-status.completada{color:var(--mesa-state-success,#087443);background:color-mix(in srgb,var(--mesa-state-success,#087443) 12%,var(--mesa-theme-surface))}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-status.cancelada{color:var(--mesa-state-danger,#c92a2a);background:color-mix(in srgb,var(--mesa-state-danger,#c92a2a) 10%,var(--mesa-theme-surface))}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-title{display:block;margin-top:7px;color:var(--mesa-theme-heading);font-size:clamp(15px,1vw,19px);line-height:1.3}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:12px;padding-top:10px;border-top:1px solid var(--mesa-theme-border)}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta span{display:flex;flex-direction:column;gap:3px;min-width:0;color:var(--mesa-theme-text);font-size:clamp(11px,.7vw,13px);overflow-wrap:anywhere}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta b{color:var(--mesa-theme-muted);font-size:clamp(10px,.62vw,12px);text-transform:uppercase;letter-spacing:.05em}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations{margin:10px 0 0;padding:12px 0 0 14px;border-left:2px solid color-mix(in srgb,var(--mesa-shell-color) 23%,var(--mesa-theme-border))}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations-head{display:flex;align-items:baseline;justify-content:space-between;gap:10px;margin-bottom:8px}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations-head strong{color:var(--mesa-theme-heading);font-size:clamp(12px,.78vw,14px)}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations-head span{color:var(--mesa-theme-muted);font-size:clamp(10px,.65vw,12px)}
body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations>.case-branch,
body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations>.case-leaf{margin-bottom:8px}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="acciones"]>.card-head h2,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="archivos"]>.card-head h2,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="estructura"]>.card-head h2{
    font-size:clamp(19px,1.25vw,24px)!important;
    line-height:1.2!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="acciones"]>.card-head p,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="archivos"]>.card-head p,
body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="estructura"]>.card-head p{
    font-size:clamp(12px,.78vw,15px)!important;
    line-height:1.4!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .action-summary-head{
    font-size:clamp(13px,.86vw,16px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .action-summary-grid span,
body.mesa-php-shell .case-detail-page #caseDialog .action-rating-summary span,
body.mesa-php-shell .case-detail-page #caseDialog .audit-item-label,
body.mesa-php-shell .case-detail-page #caseDialog .audit-item-time,
body.mesa-php-shell .case-detail-page #caseDialog .audit-item-meta{
    font-size:clamp(11px,.72vw,13px)!important;
}
body.mesa-php-shell .case-detail-page #caseDialog .action-summary-grid strong,
body.mesa-php-shell .case-detail-page #caseDialog .action-rating-summary strong,
body.mesa-php-shell .case-detail-page #caseDialog .audit-item-head strong,
body.mesa-php-shell .case-detail-page #caseDialog .audit-item p{
    font-size:clamp(13px,.86vw,16px)!important;
    line-height:1.5!important;
}

@keyframes managerCasePanelEnterHorizontal{
    from{opacity:0;transform:translateX(28px)}
    to{opacity:1;transform:translateX(0)}
}
body.mesa-php-shell .case-detail-page #caseDialog .case-pane.is-panel-entering{
    animation:managerCasePanelEnterHorizontal .24s ease-out both;
}
@media(prefers-reduced-motion:reduce){
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane.is-panel-entering{animation:none!important}
}
@media(max-width:1050px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]{
        grid-template-columns:1fr!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-pane[data-case-panel="resumen"]>.case-detail-side{
        grid-column:1!important;
        grid-row:auto!important;
        margin:12px 14px!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-structure-body{
        grid-template-columns:1fr!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:940px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-row .case-open{
        grid-column:3;
        grid-row:1;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-row .case-solution-trigger{
        grid-column:3;
        grid-row:2;
        justify-self:start;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-row .branch-action{
        grid-column:2 / 3;
        grid-row:2;
    }
}
@media(max-width:900px){
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview{
        grid-template-columns:1fr!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-item.is-description{
        border-top:1px solid var(--mesa-theme-border)!important;
        border-left:0!important;
    }
}
@media(max-width:760px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{
        min-height:0!important;
        padding:14px 14px 10px!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header h2{
        font-size:clamp(19px,4.8vw,24px)!important;
    }
}
@media(max-width:640px){
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header{
        min-height:0!important;
        padding:12px 14px 10px!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header h2{
        font-size:clamp(18px,5.2vw,23px)!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-header p{font-size:11px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata{
        padding:0 12px 10px!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-header-metadata-item{
        padding:7px 9px!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-tabs{
        min-height:54px!important;
        padding:8px 12px!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-tabs>.case-tab{
        min-height:36px!important;
        padding:7px 10px!important;
        font-size:12px!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-modal-content{padding:12px 10px 22px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-structure-body{padding:12px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-structure-metrics{grid-template-columns:1fr}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage{padding-left:31px}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta{grid-template-columns:1fr}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations{padding-left:9px}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations-head{display:block}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations-head span{display:block;margin-top:3px}
    body.mesa-php-shell .case-detail-page #caseDialog .case-structure-tree{max-height:62vh!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-row .case-open,
    body.mesa-php-shell .case-detail-page #caseDialog .case-row .case-solution-trigger,
    body.mesa-php-shell .case-detail-page #caseDialog .case-row .branch-action{
        grid-column:2;
        grid-row:auto;
        justify-self:start;
    }
    body.mesa-php-shell .case-structure-solution-dialog{
        inset:72px 10px auto auto;
        width:calc(100% - 20px);
    }
    body.mesa-php-shell .case-structure-solution-body{padding:14px}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview{margin:10px!important}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta{grid-template-columns:1fr!important}
    body.mesa-php-shell .case-detail-page #caseDialog .manager-request-overview-meta>div+div{
        border-top:1px solid var(--mesa-theme-border)!important;
        border-left:0!important;
    }
}
</style>

<style id="manager-case-list-restore">
/* El listado conserva la tabla original; la ficha organizada se reserva para
   la vista de detalle/gestión del caso, etapa o derivación. */
body.mesa-php-shell .manager-case-list{
    overflow-x:auto!important;
    overflow-y:visible!important;
    border:1px solid var(--border)!important;
    border-radius:9px!important;
}
body.mesa-php-shell .manager-case-list table{
    display:table!important;
    width:100%!important;
    border-collapse:collapse!important;
    border-spacing:0!important;
    background:var(--mesa-theme-surface)!important;
}
body.mesa-php-shell .manager-case-list thead{display:table-header-group!important}
body.mesa-php-shell .manager-case-list tbody{display:table-row-group!important}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]{
    display:table-row!important;
    width:auto!important;
    margin:0!important;
    padding:0!important;
    overflow:visible!important;
    border:0!important;
    border-left:0!important;
    border-radius:0!important;
    background:transparent!important;
    box-shadow:none!important;
    transform:none!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]:hover{
    border-color:transparent!important;
    box-shadow:none!important;
    transform:none!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td{
    display:table-cell!important;
    min-width:0!important;
    padding:11px 12px!important;
    border:1px solid var(--mesa-theme-border)!important;
    border-left:0!important;
    color:var(--mesa-theme-text)!important;
    background:var(--mesa-theme-surface)!important;
    vertical-align:middle!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td::before{display:none!important}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(2),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(3),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(4),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(5),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(6),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(7){grid-area:auto!important}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(8){
    display:table-cell!important;
    min-height:0!important;
    border-left:0!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .ticket-title{
    overflow:hidden;
    color:var(--mesa-theme-heading)!important;
    font-size:var(--gc-readable-body,15px)!important;
    font-weight:800;
    line-height:1.35;
    white-space:normal;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .ticket-title small{
    display:block;
    margin-top:3px;
    color:var(--mesa-theme-muted)!important;
    font-size:var(--gc-readable-secondary,14px)!important;
    font-weight:650;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(3),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(4),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(6),
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(7){
    overflow-wrap:normal;
    font-size:var(--gc-readable-body,15px)!important;
    line-height:1.35;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1)>.badge,
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(5)>.badge{
    display:inline!important;
    min-height:0!important;
    margin:0!important;
    padding:0!important;
    border:0!important;
    border-radius:0!important;
    box-shadow:none!important;
    background:transparent!important;
    font-size:var(--gc-readable-secondary,14px)!important;
    line-height:1.35!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1)>.badge{
    color:var(--mesa-theme-link,var(--mesa-shell-color))!important;
    font-weight:850!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(5)>.badge{
    color:var(--mesa-theme-heading)!important;
    font-weight:750!important;
}
body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .case-open{
    width:auto;
    min-width:78px;
    min-height:40px;
    white-space:nowrap;
}
<style id="gestor-estructura-paleta">
    /* La estructura y los árboles respetan siempre la paleta elegida por el usuario. */
    body.mesa-php-shell .case-detail-page #caseDialog .case-row,
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-card,
    body.mesa-php-shell .case-detail-page #caseDialog .case-panel-section,
    body.mesa-php-shell .case-detail-page #caseDialog .case-panel-toggle{
        border-color:var(--mesa-theme-border)!important;
        color:var(--mesa-theme-text)!important;
        background:var(--mesa-theme-surface)!important;
        box-shadow:0 4px 12px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 6%,transparent)!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-row:hover,
    body.mesa-php-shell .case-detail-page #caseDialog .case-branch.selected>.case-row,
    body.mesa-php-shell .case-detail-page #caseDialog .case-leaf.selected .case-row{
        border-color:color-mix(in srgb,var(--mesa-shell-color) 48%,var(--mesa-theme-border))!important;
        background:color-mix(in srgb,var(--mesa-shell-color) 7%,var(--mesa-theme-surface))!important;
    }
    body.mesa-php-shell .case-detail-page #caseDialog .case-row-main,
    body.mesa-php-shell .case-detail-page #caseDialog .case-row-meta,
    body.mesa-php-shell .case-detail-page #caseDialog .case-title,
    body.mesa-php-shell .case-detail-page #caseDialog .case-service{color:var(--mesa-theme-text)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-title{color:var(--mesa-theme-heading)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-code{color:var(--mesa-theme-link)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-row-meta b{color:var(--mesa-theme-heading)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .branch-chevron,
    body.mesa-php-shell .case-detail-page #caseDialog .branch-dot{color:var(--mesa-theme-link)!important;background:var(--mesa-theme-soft)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-status{color:var(--mesa-theme-link)!important;background:var(--mesa-theme-soft)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-status.completada{color:var(--mesa-state-success,#087443)!important;background:color-mix(in srgb,var(--mesa-state-success,#087443) 12%,var(--mesa-theme-surface))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-status.cancelada{color:var(--mesa-state-danger,#c92a2a)!important;background:color-mix(in srgb,var(--mesa-state-danger,#c92a2a) 10%,var(--mesa-theme-surface))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-status.pausada,
    body.mesa-php-shell .case-detail-page #caseDialog .case-status.listo_cierre{color:var(--mesa-state-warning,#a15c00)!important;background:color-mix(in srgb,var(--mesa-state-warning,#a15c00) 11%,var(--mesa-theme-surface))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-children{border-left-color:color-mix(in srgb,var(--mesa-shell-color) 24%,var(--mesa-theme-border))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-children>.case-branch::before,
    body.mesa-php-shell .case-detail-page #caseDialog .case-children>.case-leaf::before{border-top-color:color-mix(in srgb,var(--mesa-shell-color) 24%,var(--mesa-theme-border))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-topline>span,
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta b{color:var(--mesa-theme-muted)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-title{color:var(--mesa-theme-heading)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta span{color:var(--mesa-theme-text)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-card{background:var(--mesa-theme-surface)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-status{color:var(--mesa-theme-link)!important;background:var(--mesa-theme-soft)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-status.completada{color:var(--mesa-state-success,#087443)!important;background:color-mix(in srgb,var(--mesa-state-success,#087443) 12%,var(--mesa-theme-surface))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-status.cancelada{color:var(--mesa-state-danger,#c92a2a)!important;background:color-mix(in srgb,var(--mesa-state-danger,#c92a2a) 10%,var(--mesa-theme-surface))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta{border-top-color:var(--mesa-theme-border)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-number{color:var(--mesa-theme-on-primary)!important;background:var(--mesa-shell-color)!important;box-shadow:0 0 0 1px var(--mesa-shell-color)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage::before{background:color-mix(in srgb,var(--mesa-shell-color) 24%,var(--mesa-theme-border))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations{border-left-color:color-mix(in srgb,var(--mesa-shell-color) 24%,var(--mesa-theme-border))!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations-head strong{color:var(--mesa-theme-heading)!important}
    body.mesa-php-shell .case-detail-page #caseDialog .case-full-derivations-head span{color:var(--mesa-theme-muted)!important}

    /* Listado de casos: elimina marcos anidados y conserva las fichas de cada caso. */
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.topbar,
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar,
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>section.card{
        border:0!important;
        border-radius:0!important;
        background:transparent!important;
        box-shadow:none!important;
    }
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>section.card{padding:0!important}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.topbar{padding-right:0;padding-left:0}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar{margin-top:12px;padding:0;border-bottom:1px solid var(--mesa-theme-border)!important}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>section.card>.card-head{padding:18px 0 12px!important;border-bottom:1px solid var(--mesa-theme-border);background:transparent!important}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar .mode-link{border-radius:7px 7px 0 0}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-filters{margin:16px 0 12px;padding:0;border:0;border-radius:0;background:transparent}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list{padding:0;border:0;border-radius:0;background:transparent}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list tbody{gap:9px}

    /* Anula el restaurador de tabla y fuerza fichas independientes por caso. */
    body.mesa-php-shell .manager-case-list table{display:block!important;width:100%!important;border:0!important;border-spacing:0!important;background:transparent!important}
    body.mesa-php-shell .manager-case-list thead{display:none!important}
    body.mesa-php-shell .manager-case-list tbody{display:grid!important;gap:9px!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]{display:grid!important;grid-template-columns:minmax(145px,1.05fr) minmax(190px,1.7fr) minmax(150px,1.2fr) minmax(140px,1.1fr) minmax(108px,.8fr)!important;grid-template-areas:"case title flow requester action" "state created due due action";align-items:center;width:100%!important;margin:0!important;padding:0!important;overflow:hidden;border:1px solid var(--mesa-theme-border)!important;border-left:4px solid var(--mesa-shell-color)!important;border-radius:11px!important;background:var(--mesa-theme-surface)!important;box-shadow:0 5px 16px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 9%,transparent)!important;transform:none!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td{display:block!important;min-width:0!important;padding:11px 12px!important;border:0!important;color:var(--mesa-theme-text)!important;background:transparent!important;vertical-align:middle!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td::before{display:block!important;margin-bottom:3px;color:var(--mesa-theme-muted)!important;font-size:10px;font-weight:850;letter-spacing:.04em;line-height:1.2;text-transform:uppercase}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1){grid-area:case}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1)::before{content:"Identificador"}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(2){grid-area:title}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(2)::before{content:"Asunto"}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(3){grid-area:flow}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(3)::before{content:"Servicio / flujo"}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(4){grid-area:requester}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(4)::before{content:"Solicitante"}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(5){grid-area:state}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(5)::before{content:"Estado"}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(6){grid-area:created}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(6)::before{content:"Creado"}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(7){grid-area:due}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(7)::before{content:"Vencimiento / cierre"}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(8){grid-area:action;display:flex!important;align-items:center;justify-content:center;border-left:1px solid var(--mesa-theme-border)!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(8)::before{display:none!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .ticket-title{color:var(--mesa-theme-heading)!important;font-size:var(--gc-readable-title,18px)!important;font-weight:850;line-height:1.25;overflow-wrap:anywhere}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(1)>.badge{color:var(--mesa-theme-link)!important;font-size:var(--gc-readable-body,15px)!important;font-weight:900!important;background:transparent!important;border:0!important}
    @media(max-width:940px){body.mesa-php-shell .manager-case-list tr[data-manager-case-row]{grid-template-columns:minmax(130px,1fr) minmax(180px,1.4fr) minmax(130px,1fr) minmax(105px,.85fr)!important;grid-template-areas:"case title title action" "flow requester state action" "created due due action"}}
    @media(max-width:640px){body.mesa-php-shell .manager-case-list tr[data-manager-case-row]{display:grid!important;grid-template-columns:1fr!important;grid-template-areas:"case" "title" "flow" "requester" "state" "created" "due" "action"!important}body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(8){border-left:0!important;border-top:1px solid var(--mesa-theme-border)!important}}

    /* Mantiene la tabla normal, únicamente sin el marco/margen exterior redundante. */
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list{overflow-x:auto!important;overflow-y:visible!important;border:0!important;border-radius:0!important;background:transparent!important}
    body.mesa-php-shell .manager-case-list table{display:table!important;width:100%!important;border-collapse:collapse!important;border-spacing:0!important;background:var(--mesa-theme-surface)!important}
    body.mesa-php-shell .manager-case-list thead{display:table-header-group!important}
    body.mesa-php-shell .manager-case-list tbody{display:table-row-group!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]{display:table-row!important;width:auto!important;margin:0!important;padding:0!important;overflow:visible!important;border:0!important;border-left:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;transform:none!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td{display:table-cell!important;min-width:0!important;padding:11px 12px!important;border:1px solid var(--mesa-theme-border)!important;color:var(--mesa-theme-text)!important;background:var(--mesa-theme-surface)!important;vertical-align:middle!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td::before{display:none!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row]>td:nth-child(8){display:table-cell!important;border-left:1px solid var(--mesa-theme-border)!important}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .ticket-title{font-size:var(--gc-readable-body,15px)!important;line-height:1.35;white-space:normal}
    body.mesa-php-shell .manager-case-list tr[data-manager-case-row] .case-open{width:auto;min-width:78px;min-height:40px;white-space:nowrap}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list th,
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list td,
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list tr[data-manager-case-row]>td:nth-child(8){border:0!important;border-left:0!important;border-right:0!important}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list thead tr,
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list tbody tr{border:0!important}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list) .manager-case-list table{border:0!important}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar{display:flex;gap:7px;align-items:center;flex-wrap:wrap;padding:0 0 8px;border-bottom:1px solid var(--mesa-theme-border)!important;background:transparent!important}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar .mode-link{min-height:36px;padding:8px 12px;border:1px solid var(--mesa-theme-border)!important;border-radius:9px!important;color:var(--mesa-theme-text)!important;background:var(--mesa-theme-surface)!important;box-shadow:0 2px 7px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 6%,transparent);font-size:var(--gc-readable-secondary,13px)!important;font-weight:800;transition:background .18s ease,border-color .18s ease,color .18s ease,transform .18s ease}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar .mode-link:hover{border-color:color-mix(in srgb,var(--mesa-shell-color) 48%,var(--mesa-theme-border))!important;color:var(--mesa-theme-link)!important;background:var(--mesa-theme-soft)!important;transform:translateY(-1px)}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar .mode-link.active{border-color:var(--mesa-shell-color)!important;color:var(--mesa-theme-on-primary)!important;background:var(--mesa-shell-color)!important;box-shadow:0 5px 12px color-mix(in srgb,var(--mesa-shell-color) 22%,transparent)!important}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar .mode-link .count{min-width:18px;height:18px;display:inline-grid;place-items:center;padding:0 5px;border:1px solid color-mix(in srgb,var(--mesa-theme-link) 24%,var(--mesa-theme-border));border-radius:999px;color:var(--mesa-theme-link);background:var(--mesa-theme-soft);font-size:10px;font-weight:900}
    body.mesa-php-shell main.shell:not(.case-detail-page):has(.manager-case-list)>.modebar .mode-link.active .count{border-color:color-mix(in srgb,var(--mesa-theme-on-primary) 40%,transparent)!important;color:var(--mesa-theme-on-primary)!important;background:color-mix(in srgb,var(--mesa-theme-on-primary) 16%,transparent)!important}
    /* Las mismas pestañas y superficies se conservan aunque la bandeja esté vacía. */
    body.mesa-php-shell main.shell:not(.case-detail-page)>.modebar{display:flex;gap:7px;align-items:center;flex-wrap:wrap;margin-top:12px;padding:0 0 8px;border:0!important;border-bottom:1px solid var(--mesa-theme-border)!important;border-radius:0!important;background:transparent!important;box-shadow:none!important}
    body.mesa-php-shell main.shell:not(.case-detail-page)>.modebar .mode-link{min-height:36px;padding:8px 12px;border:1px solid var(--mesa-theme-border)!important;border-radius:9px!important;color:var(--mesa-theme-text)!important;background:var(--mesa-theme-surface)!important;box-shadow:0 2px 7px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 6%,transparent);font-size:var(--gc-readable-secondary,13px)!important;font-weight:800;transition:background .18s ease,border-color .18s ease,color .18s ease,transform .18s ease}
    body.mesa-php-shell main.shell:not(.case-detail-page)>.modebar .mode-link:hover{border-color:color-mix(in srgb,var(--mesa-shell-color) 48%,var(--mesa-theme-border))!important;color:var(--mesa-theme-link)!important;background:var(--mesa-theme-soft)!important;transform:translateY(-1px)}
    body.mesa-php-shell main.shell:not(.case-detail-page)>.modebar .mode-link.active{border-color:var(--mesa-shell-color)!important;color:var(--mesa-theme-on-primary)!important;background:var(--mesa-shell-color)!important;box-shadow:0 5px 12px color-mix(in srgb,var(--mesa-shell-color) 22%,transparent)!important}
    body.mesa-php-shell main.shell:not(.case-detail-page)>.modebar .mode-link .count{min-width:18px;height:18px;display:inline-grid;place-items:center;padding:0 5px;border:1px solid color-mix(in srgb,var(--mesa-theme-link) 24%,var(--mesa-theme-border));border-radius:999px;color:var(--mesa-theme-link);background:var(--mesa-theme-soft);font-size:10px;font-weight:900}
    body.mesa-php-shell main.shell:not(.case-detail-page)>.modebar .mode-link.active .count{border-color:color-mix(in srgb,var(--mesa-theme-on-primary) 40%,transparent)!important;color:var(--mesa-theme-on-primary)!important;background:color-mix(in srgb,var(--mesa-theme-on-primary) 16%,transparent)!important}
     body.mesa-php-shell main.shell:not(.case-detail-page):has(>.modebar)>section.card{border:0!important;border-radius:0!important;padding:0!important;background:transparent!important;box-shadow:none!important}
     body.mesa-php-shell main.shell:not(.case-detail-page):has(>.modebar)>section.card>.card-head{padding:18px 0 12px!important;border-bottom:0!important;background:transparent!important}

     /* Estructura: tarjetas limpias, sin separadores internos y con la solución elevada. */
     body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-card,
     body.mesa-php-shell .case-detail-page #caseDialog .case-row{
         border:0!important;
         border-left:0!important;
         box-shadow:none!important;
     }
     body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-card{
         position:relative!important;
     }
     body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-content{
         min-width:0;
         padding-right:116px;
     }
     body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-meta{
         margin-top:7px!important;
         padding-top:0!important;
         border:0!important;
     }
     body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-actions{
         position:absolute!important;
         top:52px!important;
         right:10px!important;
         z-index:2;
         display:flex!important;
         align-items:center!important;
         gap:8px!important;
         margin:0!important;
         padding:0!important;
         border:0!important;
     }
     body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-actions .case-solution-trigger{
         margin:0!important;
     }
     @media(max-width:760px){
         body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-content{padding-right:0}
         body.mesa-php-shell .case-detail-page #caseDialog .case-full-stage-actions{position:static!important;margin-top:6px!important;justify-content:flex-start!important}
     }

     /* Fallback directo para el panel gestor embebido: evita que el estilo base
        de las tarjetas vuelva a mostrar bordes o devuelva el botón al final. */
     #caseDialog .case-full-stage-card{
         position:relative!important;
         border-width:0!important;
         border-style:none!important;
         box-shadow:none!important;
     }
     #caseDialog .case-full-stage-meta{
         margin-top:7px!important;
         padding-top:0!important;
         border-top:0!important;
         border-bottom:0!important;
     }
     #caseDialog .case-full-stage-actions{
         position:absolute!important;
         top:52px!important;
         right:10px!important;
         z-index:2!important;
         margin:0!important;
         padding:0!important;
         border:0!important;
     }
     #caseDialog .case-full-stage-content{min-width:0;padding-right:116px}
     #caseDialog .case-row{
         border-width:0!important;
         border-style:none!important;
         box-shadow:none!important;
     }
     @media(max-width:760px){
         #caseDialog .case-full-stage-content{padding-right:0}
         #caseDialog .case-full-stage-actions{position:static!important;margin-top:6px!important}
     }

      /* Tipografía adaptable para el formulario de derivaciones. En pantallas
         estrechas conserva un mínimo legible y en escritorio crece de forma
         proporcional sin alterar el resto del detalle del caso. */
      .derivation-panel{
          --derivation-body-size:clamp(13px,.78rem + .25vw,16px);
          --derivation-secondary-size:clamp(12px,.7rem + .2vw,14px);
          --derivation-title-size:clamp(15px,.86rem + .34vw,18px);
      }
      .derivation-panel .case-toggle-copy strong{
          font-size:var(--derivation-title-size)!important;
          line-height:1.25;
      }
      .derivation-panel .case-toggle-copy small{
          font-size:var(--derivation-secondary-size)!important;
          line-height:1.45;
      }
      .derivation-panel .derivation-row label{
          margin-bottom:6px;
          font-size:var(--derivation-secondary-size)!important;
          line-height:1.3;
      }
      .derivation-panel .derivation-row input,
      .derivation-panel .derivation-row select,
      .derivation-panel .derivation-row textarea{
          min-height:42px;
          font-size:var(--derivation-body-size)!important;
          line-height:1.35;
      }
      .derivation-panel .derivation-row textarea{min-height:92px}
      .derivation-panel .derivation-service-toggle{
          width:40px;
          font-size:16px!important;
      }
      .derivation-panel .derivation-service-search{padding-right:48px}
      .derivation-panel .derivation-service-option{
          min-height:48px;
          padding:9px 11px;
          font-size:var(--derivation-body-size)!important;
      }
      .derivation-panel .derivation-service-info{
          width:26px;
          height:26px;
          font-size:14px;
      }
      .derivation-panel .derivation-service-description,
      .derivation-panel .derivation-service-help,
      .derivation-panel .derivation-footer .muted,
      .derivation-panel>form>p{
          font-size:var(--derivation-secondary-size)!important;
          line-height:1.45;
      }
      .derivation-panel .derivation-footer .btn,
      .derivation-panel .derivation-footer button{
          min-height:42px;
          font-size:var(--derivation-secondary-size)!important;
      }
      @media(max-width:560px){
          .derivation-panel .derivation-row input,
          .derivation-panel .derivation-row select,
          .derivation-panel .derivation-row textarea{font-size:14px!important}
          .derivation-panel .derivation-service-option{font-size:14px!important}
      }
</style>

</head>
<body>
        <main class="shell<?= $rol === 2 && $ticketSeleccionado ? ' case-detail-page' : '' ?><?= $rol === 2 && $ticketSeleccionado && $vistaGestionEtapa ? ' is-stage-view' : '' ?>">
    <?php if (!($rol === 2 && $ticketSeleccionado)): ?>
    <header class="topbar">
        <div class="brand">
            <span class="brand-mark" aria-hidden="true">MS</span>
            <div>
                <h1>Casos</h1>
                <p><?= escaparFlujo($nombreUsuario) ?> · <?= $rol === 1 ? 'Administrador' : 'Gestor' ?></p>
            </div>
        </div>
        <div class="actions">
            <?php if ($rol !== 2): ?>
                <a class="btn outline" href="<?= escaparFlujo($rutaPanel) ?>">← Volver al panel</a>
            <?php endif; ?>
            <?php if ($rol === 1): ?>
                <?php if ($rutaBaseTickets === 'solicitudes.php' && $idTicketSeleccionado > 0): ?>
                    <a class="btn light" href="solicitudes.php">Listado</a>
                <?php endif; ?>
                <a class="btn light" href="descargarSolicitudesExcel.php">Descargar base</a>
                <a class="btn light" href="procesos.php">Configurar tickets</a>
            <?php endif; ?>
        </div>
    </header>
    <?php endif; ?>

    <?php if ($rol === 2 && !$ticketSeleccionado): ?>
        <nav class="modebar" aria-label="Opciones de tickets">
            <a class="mode-link <?= $bandejaGestor === 'abiertos' ? 'active' : '' ?>" data-flujo-nav href="flujoTicket.php?modo=mis_tickets&amp;bandeja=abiertos">
                Casos abiertos <span class="count"><?= $totalCasosAbiertos ?></span>
            </a>
            <a class="mode-link <?= $bandejaGestor === 'derivaciones' ? 'active' : '' ?>" data-flujo-nav href="flujoTicket.php?modo=mis_tickets&amp;bandeja=derivaciones">
                Derivaciones pendientes <span class="count"><?= $totalCasosDerivados ?></span>
            </a>
            <a class="mode-link <?= $bandejaGestor === 'pendientes' ? 'active' : '' ?>" data-flujo-nav href="flujoTicket.php?modo=mis_tickets&amp;bandeja=pendientes">
                Pendientes de calificación <span class="count"><?= $totalCasosPendientes ?></span>
            </a>
            <a class="mode-link <?= $bandejaGestor === 'cerrados' ? 'active' : '' ?>" data-flujo-nav href="flujoTicket.php?modo=mis_tickets&amp;bandeja=cerrados">
                Casos cerrados <span class="count"><?= $totalCasosCerrados ?></span>
            </a>
            <a class="mode-link <?= $bandejaGestor === 'derivaciones_cerradas' ? 'active' : '' ?>" data-flujo-nav href="flujoTicket.php?modo=mis_tickets&amp;bandeja=derivaciones_cerradas">
                Derivaciones completadas <span class="count"><?= $totalDerivacionesCompletadas ?></span>
            </a>
        </nav>
    <?php endif; ?>

    <?php if (isset($mensajes[$mensajeActual])): ?>
        <div class="alert <?= escaparFlujo($mensajes[$mensajeActual][0]) ?>">
            <?= escaparFlujo($mensajes[$mensajeActual][1]) ?>
            <?php if ($detalleError !== '' && $mensajeActual === 'error_operacion'): ?>
                <div><?= escaparFlujo($detalleError) ?></div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if (false): ?>
        <div class="ticket-wizard">
            <div class="wizard-progress" aria-label="Pasos para crear el ticket">
                <div class="wizard-step active" data-wizard-step="1"><span>1</span> Proceso</div>
                <i class="wizard-line" aria-hidden="true"></i>
                <div class="wizard-step" data-wizard-step="2"><span>2</span> Servicio</div>
                <i class="wizard-line" aria-hidden="true"></i>
                <div class="wizard-step" data-wizard-step="3"><span>3</span> Solicitud</div>
            </div>

            <section class="card">
                <div class="card-head">
                    <div>
                        <h2>Seleccione el proceso</h2>
                        <p class="muted">Las opciones se actualizan automáticamente con la configuración del administrador.</p>
                    </div>
                    <span class="badge">Paso 1</span>
                </div>

                <?php if (!$catalogosDisponibles): ?>
                    <div class="empty">
                        No hay servicios disponibles. El administrador debe revisar el gestor, SLA y estado de los servicios.
                    </div>
                <?php else: ?>
                    <div class="catalog-grid" id="catalogGrid">
                        <?php foreach ($catalogosDisponibles as $catalogo): ?>
                            <button
                                type="button"
                                class="catalog-option"
                                data-catalogo="<?= (int) $catalogo['id_catalogo'] ?>"
                                data-nombre="<?= escaparFlujo($catalogo['nombre']) ?>"
                                aria-pressed="false"
                            >
                                <span class="catalog-visual" aria-hidden="true">
                                    <span><?= escaparFlujo(strtoupper(substr((string) $catalogo['nombre'], 0, 1))) ?></span>
                                    <?php if ($catalogo['imagen'] !== ''): ?>
                                        <img
                                            src="<?= escaparFlujo(seguridadUrlImagenCatalogo(
                                                (int) $catalogo['id_catalogo'],
                                                $catalogo['imagen']
                                            )) ?>"
                                            alt=""
                                            loading="lazy"
                                            decoding="async"
                                            fetchpriority="low"
                                            onerror="this.style.display='none'"
                                        >
                                    <?php endif; ?>
                                </span>
                                <strong><?= escaparFlujo($catalogo['nombre']) ?></strong>
                                <small><?= count($catalogo['servicios']) ?> servicio<?= count($catalogo['servicios']) === 1 ? '' : 's' ?> disponible<?= count($catalogo['servicios']) === 1 ? '' : 's' ?></small>
                            </button>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>

            <?php if ($catalogosDisponibles): ?>
                <section class="card service-panel" id="servicePanel" hidden>
                    <div class="card-head">
                        <div>
                            <h2 id="servicePanelTitle">Servicios disponibles</h2>
                            <p class="muted">Seleccione el servicio que necesita solicitar.</p>
                        </div>
                        <span class="badge">Paso 2</span>
                    </div>
                    <div class="service-grid" id="serviceGrid">
                        <?php foreach ($catalogosDisponibles as $catalogo): ?>
                            <?php if (!$catalogo['servicios']): ?>
                                <div class="service-empty" data-catalogo="<?= (int) $catalogo['id_catalogo'] ?>" hidden>
                                    Este proceso todavía no tiene servicios activos.
                                </div>
                            <?php endif; ?>
                            <?php foreach ($catalogo['servicios'] as $servicio): ?>
                                <?php if ($servicio['flujos']): ?>
                                    <?php foreach ($servicio['flujos'] as $flujo): ?>
                                        <button
                                            type="button"
                                            class="service-option"
                                            data-catalogo="<?= (int) $catalogo['id_catalogo'] ?>"
                                            data-proceso="<?= (int) $flujo['id_proceso'] ?>"
                                            data-catalogo-nombre="<?= escaparFlujo($catalogo['nombre']) ?>"
                                            data-servicio-nombre="<?= escaparFlujo($servicio['servicio_nombre']) ?>"
                                            data-flujo-nombre="<?= escaparFlujo($flujo['nombre']) ?>"
                                            hidden
                                        >
                                            <span>
                                                <span class="service-name"><?= escaparFlujo($servicio['servicio_nombre']) ?></span>
                                                <p><?= escaparFlujo($servicio['servicio_descripcion'] ?: $flujo['descripcion']) ?></p>
                                            </span>
                                            <span>
                                                <span class="service-tags">
                                                    <span class="service-tag">Flujo: <?= escaparFlujo($flujo['nombre']) ?></span>
                                                    <span class="service-tag"><?= (int) $flujo['etapas'] ?> etapa<?= (int) $flujo['etapas'] === 1 ? '' : 's' ?> secuencial<?= (int) $flujo['etapas'] === 1 ? '' : 'es' ?></span>
                                                    <?php if ($servicio['servicio_sla']): ?>
                                                        <span class="service-tag">SLA: <?= escaparFlujo($servicio['servicio_sla']) ?></span>
                                                    <?php endif; ?>
                                                </span>
                                                <span class="service-choose">Seleccionar servicio →</span>
                                            </span>
                                        </button>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <button
                                        type="button"
                                        class="service-option unavailable"
                                        data-catalogo="<?= (int) $catalogo['id_catalogo'] ?>"
                                        hidden
                                        disabled
                                    >
                                        <span>
                                            <span class="service-name"><?= escaparFlujo($servicio['servicio_nombre']) ?></span>
                                            <p><?= escaparFlujo($servicio['servicio_descripcion']) ?></p>
                                        </span>
                                        <span>
                                            <span class="service-tags">
                                                <span class="service-tag warning">Sin flujo de inicio configurado</span>
                                                <?php if ($servicio['servicio_sla']): ?>
                                                    <span class="service-tag">SLA: <?= escaparFlujo($servicio['servicio_sla']) ?></span>
                                                <?php endif; ?>
                                            </span>
                                            <span class="service-choose">Configurar en Flujos por servicio</span>
                                        </span>
                                    </button>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="card form-card" id="ticketFormPanel" hidden>
                    <div class="card-head">
                        <div>
                            <h2>Complete la solicitud</h2>
                            <p class="muted">El caso conservará el mismo número durante todas las etapas. Cada gestor podrá crear tickets derivados cuando su etapa esté activa.</p>
                        </div>
                        <span class="badge">Paso 3</span>
                    </div>

                    <div class="selected-service">
                        <div>
                            <strong id="selectedServiceName">Servicio seleccionado</strong>
                            <small id="selectedServiceFlow"></small>
                        </div>
                        <button class="light" id="changeServiceButton" type="button">Cambiar servicio</button>
                    </div>

                    <form method="post" enctype="multipart/form-data" id="ticketCreateForm">
                        <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                        <input type="hidden" name="accion" value="crear_ticket">
                        <input type="hidden" id="id_proceso" name="id_proceso" value="" required>
                        <div class="form-grid">
                            <div class="field">
                                <label for="titulo">Asunto</label>
                                <input id="titulo" name="titulo" maxlength="180" required>
                            </div>
                            <div class="field">
                                <label for="urgencia">Urgencia</label>
                                <select id="urgencia" name="urgencia">
                                    <option value="baja">Baja</option>
                                    <option value="moderada" selected>Moderada</option>
                                    <option value="alta">Alta</option>
                                    <option value="urgente">Urgente</option>
                                </select>
                            </div>
                            <div class="field full">
                                <label for="descripcion">Descripción</label>
                                <textarea id="descripcion" name="descripcion" maxlength="15000" required></textarea>
                            </div>
                            <div class="field full">
                                <label for="adjuntos_nuevo">Adjuntos</label>
                                <input id="adjuntos_nuevo" type="file" name="adjuntos[]" multiple>
                            </div>
                        </div>
                        <div class="form-actions">
                            <a class="btn light" href="flujoTicket.php?modo=mis_tickets&amp;bandeja=abiertos">Cancelar</a>
                            <button class="primary" type="submit">Crear ticket</button>
                        </div>
                    </form>
                </section>
            <?php endif; ?>
        </div>
    <?php elseif (!$ticketSeleccionado): ?>
        <section class="card">
            <div class="card-head">
                <div>
                    <h2><?= $rol === 2 ? escaparFlujo($tituloBandejaGestor) : 'Casos' ?></h2>
                    <p class="muted"><?= $rol === 2
                        ? escaparFlujo($descripcionBandejaGestor)
                        : 'Consulte el estado y abra un caso para revisar sus etapas y tickets derivados.' ?></p>
                </div>
            </div>

            <?php if (!$tickets): ?>
                <div class="empty">
                    <strong><?= $rol === 2
                        ? escaparFlujo([
                            'abiertos' => 'No tiene casos habilitados para gestionar.',
                            'derivaciones' => 'No tiene derivaciones pendientes.',
                            'pendientes' => 'No tiene casos pendientes de calificación.',
                            'cerrados' => 'No tiene participaciones principales finalizadas.',
                            'derivaciones_cerradas' => 'No tiene derivaciones finalizadas asignadas únicamente como apoyo.',
                        ][$bandejaGestor])
                        : 'No hay casos disponibles.' ?></strong>
                    <?php if ($rol === 2 && $bandejaGestor === 'abiertos'): ?><p>Un caso aparecerá aquí únicamente cuando llegue el turno de su etapa.</p><?php endif; ?>
                </div>
            <?php else: ?>
                <?php if ($rol === 2): ?>
                    <div class="manager-case-filters" aria-label="Filtros de casos">
                        <div class="manager-filter-field">
                            <label for="buscar-casos-gestor">Buscar casos</label>
                            <div class="manager-search-control">
                                <input
                                    id="buscar-casos-gestor"
                                    type="search"
                                    value="<?= escaparFlujo($busquedaGestor) ?>"
                                    maxlength="120"
                                    autocomplete="off"
                                    placeholder="Número, asunto, flujo, solicitante, estado o fecha"
                                >
                                <button class="manager-filter-clear" id="limpiar-filtro-gestor" type="button" aria-label="Limpiar búsqueda" hidden>×</button>
                            </div>
                        </div>
                        <div class="manager-filter-field">
                            <label for="estado-casos-gestor">Estado</label>
                            <select id="estado-casos-gestor">
                                <option value="todos">Todos los estados</option>
                                <?php foreach ($estadosGestorDisponibles as $valorEstado => $etiquetaEstado): ?>
                                    <option value="<?= escaparFlujo($valorEstado) ?>" <?= $estadoBusquedaGestor === $valorEstado ? 'selected' : '' ?>><?= escaparFlujo($etiquetaEstado) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <span class="manager-filter-count" id="contador-casos-gestor" aria-live="polite"><?= count($tickets) ?> <?= in_array($bandejaGestor, ['derivaciones', 'pendientes', 'derivaciones_cerradas'], true) ? 'derivación(es)' : 'caso(s)' ?></span>
                    </div>
                <?php endif; ?>
                <div class="table-wrap<?= $rol === 2 ? ' manager-case-list' : '' ?>">
                    <table>
                        <thead>
                            <tr>
                                <th><?= $rol === 2 && in_array($bandejaGestor, ['derivaciones', 'pendientes', 'derivaciones_cerradas'], true) ? 'Derivación' : 'Número de caso' ?></th>
                                <th>Asunto</th>
                                <th>Flujo asignado</th>
                                <th>Solicitante</th>
                                <th>Estado</th>
                                <th>Creado</th>
                                <th><?= $rol === 2 && $bandejaGestor === 'derivaciones' ? 'Vencimiento de la derivación' : ($rol === 2 && $bandejaGestor === 'derivaciones_cerradas' ? 'Finalización de la derivación' : 'Finalización prevista') ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tickets as $ticket): ?>
                                <?php $estadoFilaGestor = (string) ($ticket['estado_etapa_gestor'] ?? $ticket['estado_flujo'] ?? 'en_proceso'); ?>
                                <tr<?= $rol === 2 ? ' data-manager-case-row data-manager-case-state="' . escaparFlujo($estadoFilaGestor) . '"' : '' ?>>
                                    <td><span class="badge"><?= $rol === 2 && in_array($bandejaGestor, ['derivaciones', 'pendientes', 'derivaciones_cerradas'], true)
                                        ? 'Caso ' . (int) $ticket['id_ticket'] . ' · Derivación #' . (int) ($ticket['id_ticket_etapa_gestor'] ?? 0)
                                        : 'Caso ' . (int) $ticket['id_ticket'] ?></span></td>
                                    <td class="ticket-title">
                                        <?= escaparFlujo($ticket['titulo']) ?>
                                        <?php if ($rol === 2 && in_array($bandejaGestor, ['derivaciones', 'derivaciones_cerradas'], true) && trim((string) ($ticket['motivo_derivacion_gestor'] ?? '')) !== ''): ?>
                                            <small>Solicitud: <?= escaparFlujo((string) $ticket['motivo_derivacion_gestor']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= escaparFlujo($rol === 2
                                        ? trim((string) ($ticket['catalogo_gestor'] ?? '') . ' · ' . (string) ($ticket['servicio_gestor'] ?? ''), ' ·')
                                        : (string) $ticket['proceso_nombre']) ?></td>
                                    <td><?= escaparFlujo($ticket['creador_nombre'] ?? $ticket['solicitante_nombre']) ?></td>
                                    <td><span class="badge"><?= escaparFlujo($rol === 2
                                        ? textoEstadoCaso($estadoFilaGestor)
                                        : textoEstadoTicket((string) $ticket['estado_flujo'])) ?></span></td>
                                    <td><?= escaparFlujo(fechaFlujo($rol === 2 && in_array($bandejaGestor, ['derivaciones', 'derivaciones_cerradas'], true)
                                        ? ($ticket['creado_en_derivacion_gestor'] ?? null)
                                        : ($ticket['fecha_creacion'] ?? null))) ?></td>
                                    <td>
                                        <?php if ($rol === 2 && $bandejaGestor === 'derivaciones'): ?>
                                            <strong><?= escaparFlujo(fechaFlujo($ticket['fecha_vencimiento_derivacion_gestor'] ?? null)) ?></strong>
                                        <?php elseif ($rol === 2 && $bandejaGestor === 'derivaciones_cerradas'): ?>
                                            <strong><?= escaparFlujo(fechaFlujo($ticket['fecha_finalizacion_derivacion_gestor'] ?? null)) ?></strong>
                                        <?php else: ?>
                                            <?php $proyeccionFila = $proyeccionesTickets[(int) $ticket['id_ticket']] ?? []; ?>
                                            <strong><?= escaparFlujo(fechaFlujo($proyeccionFila['fecha'] ?? null)) ?></strong>
                                            <?php if (!empty($proyeccionFila['pausado_por_derivacion'])): ?><small>SLA pausado por derivación</small><?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                            $esCierrePendiente = $rol === 2
                                                && (int) ($ticket['id_usuario'] ?? 0) === $idUsuario
                                                && (string) ($ticket['estado_flujo'] ?? '') === 'pendiente_calificacion';
                                            $idNodoFila = $rol === 2
                                                && in_array((string) ($ticket['bandeja_gestor'] ?? ''), ['derivaciones', 'pendientes', 'cerrados', 'derivaciones_cerradas'], true)
                                                ? (int) ($ticket['id_ticket_etapa_gestor'] ?? 0)
                                                : 0;
                                            $urlFila = urlTicketFlujo(
                                                $rutaBaseTickets,
                                                $rol,
                                                (int) $ticket['id_ticket'],
                                                $idNodoFila
                                            ) . ($esCierrePendiente ? '&encuesta=1' : '');
                                        ?>
                                        <a class="btn <?= $esCierrePendiente ? 'primary' : 'light' ?>"<?= $rol === 2 ? ' data-manager-case-view data-flujo-nav' : '' ?> href="<?= escaparFlujo($urlFila) ?>">
                                            <?= $esCierrePendiente
                                                ? 'Calificar y cerrar'
                                                : ($bandejaGestor === 'pendientes' ? 'Calificar derivación' : (in_array($bandejaGestor, ['derivaciones', 'derivaciones_cerradas'], true) ? 'Ver derivación' : ($idNodoFila > 0 ? 'Ver etapa' : 'Ver'))) ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if ($rol === 2): ?>
                                <tr class="manager-filter-empty" id="sin-resultados-gestor" hidden>
                                    <td colspan="8">No se encontraron casos con los filtros seleccionados.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    <?php else: ?>
        <?php if ($rol === 2): ?>
            <section
                class="manager-ticket-modal"
                id="manager-ticket-modal"
                role="region"
                <?= $vistaGestionEtapa
                    ? 'aria-label="Gestión de la etapa seleccionada"'
                    : 'aria-labelledby="manager-ticket-modal-title"' ?>
            >
                <div class="manager-ticket-modal-window">
                    <?php if (!$vistaGestionEtapa): ?>
                    <header class="manager-ticket-modal-bar">
                        <div>
                            <a class="btn light case-back-link" href="<?= escaparFlujo($rutaListadoGestor) ?>">← Atrás</a>
                            <strong id="manager-ticket-modal-title">Gestión del caso <?= (int) $ticketSeleccionado['id_ticket'] ?></strong>
                            <small>Revise la solicitud, ubique su etapa y abra las acciones de gestión.</small>
                        </div>
                    </header>
                    <?php endif; ?>
                    <div class="manager-ticket-modal-scroll">
        <?php endif; ?>
        <?php if (
            $rol !== 2
            || !$vistaGestionEtapa
            || $casoSeleccionadoCerrado
        ): ?>
        <section class="card ticket-summary case-context-summary">
            <div>
                <span class="badge">Caso <?= (int) $ticketSeleccionado['id_ticket'] ?></span>
                <h2><?= escaparFlujo($ticketSeleccionado['titulo']) ?></h2>
                <p class="muted">
                    <?= escaparFlujo($ticketSeleccionado['proceso_nombre']) ?> ·
                    Solicitante: <?= escaparFlujo($ticketSeleccionado['solicitante_nombre'] ?? $ticketSeleccionado['creador_nombre']) ?>
                </p>
                <div class="manager-request-copy">
                    <span>Solicitud recibida</span>
                    <p class="description"><?= escaparFlujo($ticketSeleccionado['descripcion']) ?></p>
                </div>
            </div>
            <span class="badge"><?= escaparFlujo(textoEstadoTicket((string) $ticketSeleccionado['estado_flujo'])) ?></span>
        </section>
        <?php $proyeccionSeleccionada = $proyeccionesTickets[(int) $ticketSeleccionado['id_ticket']] ?? flujoProyeccionFinalizacionTicket($conn, (int) $ticketSeleccionado['id_ticket']); ?>
        <section class="closure-banner case-context-closure" aria-label="Fecha de finalización del caso">
            <div>
                <strong><?= ($proyeccionSeleccionada['estado'] ?? '') === 'finalizado' ? 'Caso finalizado' : 'Fecha objetivo del caso' ?></strong>
                <p><?= escaparFlujo(fechaFlujo($proyeccionSeleccionada['fecha'] ?? null)) ?><?= !empty($proyeccionSeleccionada['pausado_por_derivacion']) ? ' · El SLA del caso está pausado por derivaciones activas.' : ' · Calculada con el calendario laboral y los SLA pendientes.' ?></p>
            </div>
        </section>

        <?php if (
            $rol === 2
            && (int) $ticketSeleccionado['id_usuario'] === $idUsuario
            && $ticketSeleccionado['estado_flujo'] === 'pendiente_calificacion'
            && $etapaEncuestaLegacy
        ): ?>
            <section class="closure-banner case-context-closure" aria-label="Cierre definitivo pendiente">
                <div>
                    <strong>Caso anterior: falta la encuesta única del servicio solicitado</strong>
                    <p>Este formulario de compatibilidad no solicita calificar todos los procesos.</p>
                </div>
                <button class="primary" type="button" data-open-final-rating>
                    Calificar servicio y cerrar caso
                </button>
            </section>

            <dialog
                id="finalRatingDialog"
                class="final-rating-dialog"
                data-auto-open="<?= $abrirCierreDefinitivo ? 'true' : 'false' ?>"
            >
                <div class="final-rating-shell">
                    <header class="final-rating-head">
                        <div>
                            <h2>Cierre definitivo del Caso <?= $idTicketSeleccionado ?></h2>
                            <p>Esta acción registra una sola encuesta del servicio solicitado y cierra el caso anterior.</p>
                        </div>
                        <form method="dialog">
                            <button class="modal-close" type="submit" aria-label="Cerrar ventana">×</button>
                        </form>
                    </header>
                    <div class="final-rating-body">
                        <?php if (!$moduloCalificacionDetallada): ?>
                            <div class="alert error">
                                El administrador debe importar <strong>migracion_calificacion_cierre_definitivo.sql</strong> antes de utilizar este formulario.
                            </div>
                        <?php else: ?>
                            <div class="final-rating-intro">
                                <strong>Califique únicamente el servicio solicitado.</strong>
                                Las evaluaciones de los tickets derivados se registran por separado cuando el gestor que creó cada derivación confirma su cierre.
                            </div>
                            <form method="post" data-final-rating-form>
                                <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                <input type="hidden" name="accion" value="calificar_cerrar_ticket">
                                <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                <div class="rating-case-list">
                                    <?php foreach ([$etapaEncuestaLegacy] as $etapa): ?>
                                        <?php if (!$etapa || (string) $etapa['estado'] !== 'completada') continue; ?>
                                        <?php
                                            $idEtapaCalificar = (int) $etapa['id_ticket_etapa'];
                                            $resultadoSla = (string) ($etapa['resultado_sla'] ?? 'sin_iniciar');
                                            $claseResultado = $resultadoSla === 'dentro_sla'
                                                ? 'inside'
                                                : ($resultadoSla === 'fuera_sla' ? 'outside' : '');
                                            $textoResultado = $resultadoSla === 'dentro_sla'
                                                ? 'Dentro del SLA'
                                                : ($resultadoSla === 'fuera_sla' ? 'Fuera del SLA' : 'Sin evaluación SLA');
                                        ?>
                                        <article class="rating-case">
                                            <div class="rating-case-head">
                                                <div>
                                                    <div class="rating-case-title">
                                                        <span class="case-code"><?=
                                                            !empty($etapa['es_derivacion'])
                                                                ? 'Ticket ' . escaparFlujo($etapa['codigo_ticket'] ?? '')
                                                                : 'Caso ' . escaparFlujo($idTicketSeleccionado)
                                                        ?></span>
                                                        <strong><?= escaparFlujo($etapa['catalogo_nombre'] . ' · ' . $etapa['servicio_nombre']) ?></strong>
                                                    </div>
                                                    <div class="rating-case-title" style="margin-top:4px">
                                                        <span>Gestor asignado: <?= escaparFlujo($etapa['gestor_nombre'] ?? 'Sin asignar') ?></span>
                                                    </div>
                                                </div>
                                                <div class="rating-case-times">
                                                    <span>SLA: <?= escaparFlujo((string) $etapa['sla_tiempo'] . ' ' . (string) $etapa['sla_unidad']) ?></span>
                                                    <span>Tiempo real: <?= escaparFlujo(tiempoFlujo($etapa['minutos_atencion'] ?? null)) ?></span>
                                                    <span class="<?= escaparFlujo($claseResultado) ?>"><?= escaparFlujo($textoResultado) ?></span>
                                                </div>
                                            </div>
                                            <div class="rating-fields">
                                                <div>
                                                    <label for="area-<?= $idEtapaCalificar ?>">Calificación del proceso *</label>
                                                    <select id="area-<?= $idEtapaCalificar ?>" name="calificacion_area[<?= $idEtapaCalificar ?>]" required>
                                                        <option value="">Seleccione</option>
                                                        <?php for ($nota = 5; $nota >= 1; $nota--): ?>
                                                            <option value="<?= $nota ?>" <?= (int) ($etapa['calificacion_area'] ?? 0) === $nota ? 'selected' : '' ?>><?= $nota ?> - <?= ['','Muy deficiente','Deficiente','Aceptable','Muy buena','Excelente'][$nota] ?></option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </div>
                                                <div>
                                                    <label for="tiempo-<?= $idEtapaCalificar ?>">Tiempo de respuesta *</label>
                                                    <select id="tiempo-<?= $idEtapaCalificar ?>" name="calificacion_tiempo[<?= $idEtapaCalificar ?>]" required>
                                                        <option value="">Seleccione</option>
                                                        <?php for ($nota = 5; $nota >= 1; $nota--): ?>
                                                            <option value="<?= $nota ?>" <?= (int) ($etapa['calificacion_tiempo'] ?? 0) === $nota ? 'selected' : '' ?>><?= $nota ?> - <?= ['','Muy deficiente','Deficiente','Aceptable','Muy buena','Excelente'][$nota] ?></option>
                                                        <?php endfor; ?>
                                                    </select>
                                                </div>
                                                <div>
                                                    <label for="comentario-<?= $idEtapaCalificar ?>">Observación opcional</label>
                                                    <textarea id="comentario-<?= $idEtapaCalificar ?>" name="comentario[<?= $idEtapaCalificar ?>]" maxlength="1000" placeholder="Indique qué fue positivo o qué debería mejorar"><?= escaparFlujo($etapa['comentario_calificacion'] ?? '') ?></textarea>
                                                </div>
                                            </div>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                                <div class="final-rating-actions">
                                    <button class="light" type="button" data-close-final-rating>Volver</button>
                                    <button class="primary" type="submit">Enviar encuesta y cerrar definitivamente</button>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </dialog>
        <?php endif; ?>

        <section class="card case-context-tree">
            <div class="card-head">
                <div>
                    <h2>Etapas y apoyos de otros procesos</h2>
                    <p class="muted">Busque la etapa que tiene asignada y pulse <strong>Gestionar etapa</strong>. La estructura es <strong>Proceso · Subproceso · Servicio</strong>; los códigos con punto, como 3.1, son solicitudes enviadas a otro proceso.</p>
                </div>
                <?php if ($totalApoyosArbol > 0): ?>
                    <div class="tree-toolbar" aria-label="Controles de apoyos de otros procesos">
                        <button class="btn light" type="button" data-tree-expand aria-controls="case-support-tree">Mostrar apoyos</button>
                        <button class="btn outline" type="button" data-tree-collapse aria-controls="case-support-tree">Ocultar apoyos</button>
                    </div>
                <?php else: ?>
                    <span class="badge">Sin apoyos solicitados</span>
                <?php endif; ?>
            </div>
            <div class="manager-tree-help" aria-label="Cómo interpretar las etapas">
                <span><b>1</b><strong>Caso principal</strong><small>Es la solicitud original.</small></span>
                <span><b>2</b><strong>Etapa asignada</strong><small>Revise gestor, SLA y vencimiento.</small></span>
                <span><b>3</b><strong><?= $rol === 2 ? 'Gestionar etapa' : 'Consultar etapa' ?></strong><small><?= $rol === 2 ? 'Abre checklist, solución y cierre.' : 'Abre la información de la etapa.' ?></small></span>
            </div>
            <div id="case-support-tree" class="case-tree" data-case-tree data-tree-key="ticket-<?= $idTicketSeleccionado ?>">
                <?php if (!$casoPrincipalVisual): ?>
                    <p class="muted">Este caso todavía no tiene una etapa disponible.</p>
                <?php else: ?>
                    <?php renderizarRamaCasos(
                        $casoPrincipalVisual,
                        $hijosArbolVisual,
                        $rutaBaseTickets,
                        $idTicketSeleccionado,
                        (int) ($etapaActual['id_ticket_etapa'] ?? 0),
                        $rutaCasoSeleccionado
                    ); ?>
                <?php endif; ?>
            </div>
        </section>
        <?php endif; ?>

        <?php if ($etapaActual && ($rol !== 2 || $vistaGestionEtapa)): ?>
        <dialog id="caseStructureSolutionDialog" class="case-structure-solution-dialog" aria-labelledby="caseStructureSolutionTitle">
            <div class="case-structure-solution-shell">
                <header class="case-structure-solution-head" data-case-solution-drag title="Arrastra para mover este panel">
                    <div>
                        <span>Detalle del elemento</span>
                        <h2 id="caseStructureSolutionTitle">Solución registrada</h2>
                        <p id="caseStructureSolutionContext" class="case-structure-solution-context"></p>
                    </div>
                    <button type="button" class="case-structure-solution-close" data-case-solution-close aria-label="Cerrar">×</button>
                </header>
                <div class="case-structure-solution-body">
                    <div>
                        <span>Solución seleccionada</span>
                        <strong id="caseStructureSolutionName">Sin solución registrada</strong>
                    </div>
                    <div>
                        <span>Descripción del gestor</span>
                        <p id="caseStructureSolutionDetail">El gestor no dejó una descripción adicional.</p>
                    </div>
                </div>
            </div>
        </dialog>
        <?php if ($rol === 2): ?>
        <section
            id="caseDialog"
            class="case-dialog is-embedded"
            data-embedded="true"
            data-auto-open="<?= $idNodoSeleccionado > 0 ? 'true' : 'false' ?>"
            data-initial-panel="<?= escaparFlujo($panelCaso) ?>"
        >
        <?php else: ?>
        <dialog
            id="caseDialog"
            class="case-dialog"
            data-embedded="false"
            data-auto-open="<?= $idNodoSeleccionado > 0 ? 'true' : 'false' ?>"
            data-initial-panel="<?= escaparFlujo($panelCaso) ?>"
        >
        <?php endif; ?>
            <div class="case-modal-shell">
                <header class="case-modal-header">
                    <div>
                        <?php if ($rol === 2): ?>
                            <a class="btn light case-back-link case-detail-back-button" data-flujo-nav href="<?= escaparFlujo($rutaListadoGestor) ?>">
                                <span aria-hidden="true">←</span> Atrás
                            </a>
                        <?php endif; ?>
                        <div class="case-modal-title-line">
                            <span class="case-code"><?= escaparFlujo($etiquetaNodoActual) ?></span>
                            <span class="case-status <?= escaparFlujo($etapaActual['estado']) ?>"><?= escaparFlujo(textoEstadoCaso((string) $etapaActual['estado'])) ?></span>
                        </div>
                        <h2><?= escaparFlujo($etapaActual['catalogo_nombre'] . ' · ' . $etapaActual['servicio_nombre']) ?></h2>
                        <p><?= $esTicketDerivadoActual
                            ? 'Revise la información de esta derivación del caso principal.'
                            : 'Revise la etapa actual y la información completa del mismo caso.' ?></p>
                    </div>
                    <div class="case-modal-header-actions">
                        <?php if ($esGestorNodo): ?>
                            <form method="post" class="manager-mail-header-form">
                                <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                <input type="hidden" name="accion" value="configurar_notificaciones">
                                <input type="hidden" name="id_ticket" value="<?= (int) $ticketSeleccionado['id_ticket'] ?>">
                                <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaActual['id_ticket_etapa'] ?>">
                                <input type="hidden" name="habilitada" value="<?= $notificacionesEmailGestor ? '0' : '1' ?>">
                                <button
                                    class="manager-mail-toggle <?= $notificacionesEmailGestor ? 'is-on' : 'is-off' ?>"
                                    type="submit"
                                    title="<?= $notificacionesEmailGestor
                                        ? 'Recibirá un correo cuando esta etapa tenga una novedad. Pulse para desactivar.'
                                        : 'Los avisos por correo están desactivados. Pulse para activar.' ?>"
                                    aria-label="<?= $notificacionesEmailGestor
                                        ? 'Avisos por correo activados. Desactivar avisos.'
                                        : 'Avisos por correo desactivados. Activar avisos.' ?>"
                                >
                                    <span class="manager-mail-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24">
                                            <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/>
                                            <path d="M10 21h4"/>
                                            <?php if (!$notificacionesEmailGestor): ?>
                                                <path class="manager-mail-slash" d="M4 4l16 16"/>
                                            <?php endif; ?>
                                        </svg>
                                    </span>
                                    <span class="manager-mail-copy">
                                        <strong>Correo</strong>
                                        <small><?= $notificacionesEmailGestor ? 'Activado' : 'Desactivado' ?></small>
                                    </span>
                                </button>
                            </form>
                        <?php endif; ?>
                        <button
                            class="case-chat-launcher"
                            type="button"
                            data-case-chat-open
                            aria-controls="case-chat-panel"
                            aria-expanded="false"
                        >
                            <span class="case-chat-launcher-icon" aria-hidden="true">
                                <svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 9h8M8 13h5"/></svg>
                            </span>
                            <span class="case-chat-launcher-copy"><strong>Conversación</strong></span>
                            <span class="case-chat-unread case-chat-launcher-unread" data-case-chat-unread-total hidden aria-label="0 mensajes nuevos">0</span>
                        </button>
                    </div>
                </header>

                <?php $fechaCreacionCaso = $ticketSeleccionado['fecha_creacion'] ?? $ticketSeleccionado['creado_en'] ?? null; ?>
                <section class="case-header-metadata" aria-label="Información principal del caso">
                    <div class="case-header-metadata-item">
                        <span>Solicitante</span>
                        <strong><?= escaparFlujo($ticketSeleccionado['solicitante_nombre'] ?? $ticketSeleccionado['creador_nombre'] ?? 'Usuario no disponible') ?></strong>
                        <small><?= escaparFlujo($ticketSeleccionado['solicitante_email'] ?? '') ?></small>
                    </div>
                    <div class="case-header-metadata-item">
                        <span>Proceso</span>
                        <strong><?= escaparFlujo($etapaActual['catalogo_nombre'] ?? $ticketSeleccionado['proceso_nombre'] ?? 'Sin proceso') ?></strong>
                        <small><?= escaparFlujo($etapaActual['servicio_nombre'] ?? 'Sin servicio') ?></small>
                    </div>
                    <div class="case-header-metadata-item">
                        <span>Fecha creación</span>
                        <strong><?= escaparFlujo(fechaFlujo($fechaCreacionCaso)) ?></strong>
                    </div>
                    <div class="case-header-metadata-item">
                        <span>Prioridad</span>
                        <strong><?= escaparFlujo($ticketSeleccionado['prioridad'] ?? 'Sin prioridad') ?></strong>
                    </div>
                    <div class="case-header-metadata-item due">
                        <span>Fecha estimada de vencimiento</span>
                        <strong><?= escaparFlujo(fechaFlujo($etapaActual['fecha_vencimiento'] ?? null)) ?></strong>
                    </div>
                </section>

                <?php
                    $estadoFlujoLinea = (string) ($ticketSeleccionado['estado_flujo'] ?? '');
                    $etapaCerradaLinea = in_array(
                        (string) ($etapaActual['estado'] ?? ''),
                        ['completada', 'cancelada'],
                        true
                    );
                    $casoCerradoLinea = in_array($estadoFlujoLinea, ['cerrado', 'cancelado', 'cancelada'], true);
                    $pendienteCalificacionLinea = $estadoFlujoLinea === 'pendiente_calificacion'
                        || (string) ($etapaActual['estado'] ?? '') === 'listo_cierre';
                    $pasoActualLinea = $casoCerradoLinea
                        ? 4
                        : (($pendienteCalificacionLinea || $etapaCerradaLinea) ? 3 : 2);
                    $pasosLineaCaso = [
                        [
                            'titulo' => 'Recepción',
                            'fecha' => $fechaCreacionCaso,
                            'estado' => 'is-done',
                            'detalle' => 'Caso recibido',
                        ],
                        [
                            'titulo' => 'Revisión',
                            'fecha' => $etapaActual['fecha_activacion'] ?? null,
                            'estado' => $pasoActualLinea > 2 || $etapaCerradaLinea ? 'is-done' : 'is-current',
                            'detalle' => $pasoActualLinea === 2 ? 'En curso' : 'Gestión completada',
                        ],
                        [
                            'titulo' => 'Pendiente de calificación',
                            'fecha' => $etapaActual['fecha_marcado_listo'] ?? null,
                            'estado' => $pasoActualLinea > 3 ? 'is-done' : ($pasoActualLinea === 3 ? 'is-current' : 'is-pending'),
                            'detalle' => $pasoActualLinea === 3 ? 'Pendiente' : ($pasoActualLinea > 3 ? 'Calificado' : 'Pendiente'),
                        ],
                        [
                            'titulo' => 'Cierre',
                            'fecha' => $ticketSeleccionado['fecha_finalizacion'] ?? $etapaActual['fecha_finalizacion'] ?? null,
                            'estado' => $pasoActualLinea === 4 ? 'is-done' : 'is-pending',
                            'detalle' => $pasoActualLinea === 4 ? 'Caso cerrado' : 'Pendiente',
                        ],
                    ];
                ?>
                <section class="case-stage-progress" aria-label="Línea de etapas del caso">
                    <div class="case-stage-progress-head">
                        <div>
                            <span class="case-stage-progress-kicker">Seguimiento del caso</span>
                            <strong>Etapas del proceso</strong>
                        </div>
                        <span><?= $pasoActualLinea ?> de 4</span>
                    </div>
                    <div class="case-stage-progress-track" style="--case-stage-count: 4">
                        <?php foreach ($pasosLineaCaso as $indiceLinea => $pasoLinea): ?>
                            <div class="case-stage-step <?= escaparFlujo($pasoLinea['estado']) ?>">
                                <span class="case-stage-step-marker" aria-hidden="true">
                                    <?= $pasoLinea['estado'] === 'is-done' ? '✓' : ($indiceLinea + 1) ?>
                                </span>
                                <strong><?= escaparFlujo($pasoLinea['titulo']) ?></strong>
                                <small><?= escaparFlujo($pasoLinea['detalle']) ?></small>
                                <em><?= escaparFlujo(fechaFlujo($pasoLinea['fecha'])) ?></em>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <nav class="case-tabs" aria-label="Secciones del caso">
                    <?php foreach ([
                        'estructura' => 'Estructura',
                        'resumen' => $casoSeleccionadoCerrado
                            ? 'Solución'
                            : ($rol === 2 ? 'Gestionar etapa' : 'Información de etapa'),
                        'acciones' => 'Historial (' . count($historial) . ')',
                        'archivos' => 'Adjuntos (' . count($adjuntos) . ')',
                    ] as $clavePanel => $tituloPanel): ?>
                        <button
                            class="case-tab <?= $panelCaso === $clavePanel ? 'active' : '' ?> <?= $clavePanel === 'resumen' && $casoSeleccionadoCerrado ? 'is-solution' : '' ?>"
                            type="button"
                            data-case-tab="<?= escaparFlujo($clavePanel) ?>"
                            aria-selected="<?= $panelCaso === $clavePanel ? 'true' : 'false' ?>"
                        ><?= escaparFlujo($tituloPanel) ?></button>
                    <?php endforeach; ?>
                </nav>

                <div class="case-modal-content">
        <section
            class="card case-pane case-structure-panel"
            data-case-panel="estructura"
            <?= $panelCaso === 'estructura' ? '' : 'hidden' ?>
        >
            <div class="card-head">
                <div>
                    <h2>Estructura del caso</h2>
                    <p class="muted">Consulte las etapas, derivaciones y soluciones registradas durante todo el flujo.</p>
                </div>
                <span class="badge"><?= count($etapasOficiales) ?> etapa<?= count($etapasOficiales) === 1 ? '' : 's' ?> · <?= max(0, count($etapas) - count($etapasOficiales)) ?> derivación<?= max(0, count($etapas) - count($etapasOficiales)) === 1 ? '' : 'es' ?></span>
            </div>
            <div class="case-structure-body">
                <section class="case-structure-tree" aria-label="Etapas y derivaciones">
                    <div class="case-structure-section-head">
                        <div>
                            <span>Flujo completo</span>
                            <strong>Todas las etapas y sus derivaciones</strong>
                        </div>
                    </div>
                    <div class="case-structure-metrics" aria-label="Totales de la estructura del caso">
                        <div><strong><?= count($etapasOficiales) ?></strong><span>Etapas del caso</span></div>
                        <div><strong><?= max(0, count($etapas) - count($etapasOficiales)) ?></strong><span>Derivaciones totales</span></div>
                        <div><strong><?= count(array_filter($etapas, static fn (array $etapaResumen): bool => (string) ($etapaResumen['estado'] ?? '') === 'completada')) ?></strong><span>Elementos completados</span></div>
                    </div>
                    <div class="case-full-structure" data-case-tree data-tree-key="estructura-ticket-<?= $idTicketSeleccionado ?>">
                        <?php if (!$etapasOficiales): ?>
                            <p class="muted">Este caso todavía no tiene etapas disponibles.</p>
                        <?php else: ?>
                            <ol class="case-full-stage-list">
                                <?php foreach ($etapasOficiales as $indiceEtapaEstructura => $etapaEstructura): ?>
                                    <?php
                                        $idEtapaEstructura = (int) ($etapaEstructura['id_ticket_etapa'] ?? 0);
                                        $estadoEstructura = (string) ($etapaEstructura['estado'] ?? 'pendiente');
                                        $estadoClaseEstructura = preg_replace('/[^a-z0-9_-]/', '', strtolower($estadoEstructura)) ?: 'pendiente';
                                        $derivacionesEtapaEstructura = $hijosPorPadre[$idEtapaEstructura] ?? [];
                                        $esEtapaActualEstructura = $idEtapaEstructura === (int) ($etapaActual['id_ticket_etapa'] ?? 0);
                                    ?>
                                    <li class="case-full-stage <?= $esEtapaActualEstructura ? 'is-current' : '' ?>">
                                        <article class="case-full-stage-card">
                                            <span class="case-full-stage-number"><?= $indiceEtapaEstructura + 1 ?></span>
                                            <div class="case-full-stage-content">
                                                <div class="case-full-stage-topline">
                                                    <span>Etapa <?= $indiceEtapaEstructura + 1 ?> de <?= count($etapasOficiales) ?></span>
                                                    <b class="case-full-stage-status <?= escaparFlujo($estadoClaseEstructura) ?>"><?= escaparFlujo(textoEstadoCaso($estadoEstructura)) ?></b>
                                                </div>
                                                <strong class="case-full-stage-title"><?= escaparFlujo(($etapaEstructura['catalogo_nombre'] ?? 'Proceso') . ' · ' . ($etapaEstructura['servicio_nombre'] ?? 'Servicio')) ?></strong>
                                                <?php if ($casoSeleccionadoCerrado && in_array($estadoEstructura, ['completada', 'cancelada'], true)): ?>
                                                    <div class="case-full-stage-actions">
                                                        <button
                                                            class="btn light case-solution-trigger"
                                                            type="button"
                                                            data-case-solution
                                                            data-solution-title="<?= escaparFlujo('Etapa ' . ($indiceEtapaEstructura + 1) . ' · ' . ($etapaEstructura['catalogo_nombre'] ?? 'Proceso') . ' · ' . ($etapaEstructura['servicio_nombre'] ?? 'Servicio')) ?>"
                                                            data-solution-context="<?= escaparFlujo('Caso ' . $idTicketSeleccionado . ' · Etapa ' . ($indiceEtapaEstructura + 1) . ' de ' . count($etapasOficiales)) ?>"
                                                            data-solution-name="<?= escaparFlujo(trim((string) ($etapaEstructura['solucion_nombre'] ?? '')) ?: 'Sin solución registrada') ?>"
                                                            data-solution-detail="<?= escaparFlujo(trim((string) ($etapaEstructura['comentario_cierre'] ?? '')) ?: 'El gestor no dejó una descripción adicional.') ?>"
                                                        >Ver solución</button>
                                                    </div>
                                                <?php endif; ?>
                                                <div class="case-full-stage-meta">
                                                    <span><b>Gestor</b><?= escaparFlujo($etapaEstructura['gestor_nombre'] ?? 'Sin asignar') ?></span>
                                                    <span><b>Activación</b><?= escaparFlujo(fechaFlujo($etapaEstructura['fecha_activacion'] ?? $etapaEstructura['creado_en'] ?? null)) ?></span>
                                                    <span><b>Vencimiento</b><?= escaparFlujo(fechaFlujo($etapaEstructura['fecha_vencimiento'] ?? null)) ?></span>
                                                </div>
                                            </div>
                                        </article>
                                        <?php if ($derivacionesEtapaEstructura): ?>
                                            <div class="case-full-derivations">
                                                <div class="case-full-derivations-head">
                                                    <strong><?= count($derivacionesEtapaEstructura) ?> derivación<?= count($derivacionesEtapaEstructura) === 1 ? '' : 'es' ?> de esta etapa</strong>
                                                    <span>Incluye todos sus niveles y apoyos relacionados</span>
                                                </div>
                                                <?php foreach ($derivacionesEtapaEstructura as $derivacionEstructura): ?>
                                                    <?php renderizarRamaCasos(
                                                        $derivacionEstructura,
                                                        $hijosPorPadre,
                                                        $rutaBaseTickets,
                                                        $idTicketSeleccionado,
                                                        (int) ($etapaActual['id_ticket_etapa'] ?? 0),
                                                        $rutaCasoSeleccionado
                                                    ); ?>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; ?>
                            </ol>
                        <?php endif; ?>
                    </div>
                </section>
            </div>
        </section>
        <section
            class="card case-pane"
            data-case-panel="acciones"
            <?= $panelCaso === 'acciones' ? '' : 'hidden' ?>
        >
            <div class="card-head">
                <div>
                    <h2>Acciones de <?= escaparFlujo($etiquetaNodoActual) ?></h2>
                    <p class="muted">Solo se muestran las acciones registradas en la etapa o derivación seleccionada.</p>
                </div>
                <span class="badge"><?= count($historial) ?> eventos</span>
            </div>
            <details class="action-summary">
                <summary class="action-summary-head">
                    <strong>Resumen completo de trazabilidad</strong>
                    <span class="case-status <?= escaparFlujo((string) $etapaActual['estado']) ?>"><?= escaparFlujo(textoEstadoCaso((string) $etapaActual['estado'])) ?></span>
                </summary>
                <div class="action-summary-body">
                <div class="action-summary-grid">
                    <div><span>Creador del caso</span><strong><?= escaparFlujo($etapaActual['creador_caso_nombre'] ?? 'Usuario eliminado') ?></strong></div>
                    <div><span>Gestor asignado</span><strong><?= escaparFlujo($etapaActual['gestor_nombre'] ?? 'Sin asignar') ?></strong></div>
                    <div><span>Activación</span><strong><?= escaparFlujo(fechaFlujo($etapaActual['fecha_activacion'] ?? null)) ?></strong></div>
                    <div><span>Vencimiento visible</span><strong><?= escaparFlujo(fechaFlujo($etapaActual['fecha_vencimiento'] ?? null)) ?></strong></div>
                    <div><span>Marcado Listo por</span><strong><?= escaparFlujo($etapaActual['marcador_listo_nombre'] ?? 'Sin marcar') ?></strong></div>
                    <div><span>Fecha de Listo</span><strong><?= escaparFlujo(fechaFlujo($etapaActual['fecha_marcado_listo'] ?? null)) ?></strong></div>
                    <div><span>Tiempo oficial hasta Listo</span><strong><?= escaparFlujo(tiempoFlujo($etapaActual['minutos_hasta_listo'] ?? null)) ?></strong></div>
                    <div><span>SLA para indicadores</span><strong><?= escaparFlujo((fn ($__mesaMatchValue25) => (($__mesaMatchValue25 === ('dentro_sla')) ? ('Dentro del SLA') : ((($__mesaMatchValue25 === ('fuera_sla')) ? ('Fuera del SLA') : ('Sin evaluación')))))((string) ($etapaActual['resultado_sla_listo'] ?? $etapaActual['resultado_sla'] ?? 'sin_iniciar'))) ?></strong></div>
                    <div><span>Estado SLA visible actual</span><strong><?= escaparFlujo((string) ($etapaActual['estado_sla_actual'] ?? 'sin_iniciar')) ?></strong></div>
                    <div><span>Reaperturas</span><strong><?= (int) ($etapaActual['cantidad_reaperturas'] ?? 0) ?></strong></div>
                    <div><span>Última reapertura</span><strong><?= escaparFlujo(fechaFlujo($etapaActual['fecha_ultima_reapertura'] ?? null)) ?></strong></div>
                    <div><span>Cerrado por</span><strong><?= escaparFlujo($etapaActual['cerrador_caso_nombre'] ?? 'Sin cerrar') ?></strong></div>
                    <div><span>Fecha de cierre</span><strong><?= escaparFlujo(fechaFlujo($etapaActual['fecha_finalizacion'] ?? null)) ?></strong></div>
                    <div><span>Solución seleccionada</span><strong><?= escaparFlujo($etapaActual['solucion_nombre'] ?? 'Sin solución') ?></strong></div>
                </div>

                <?php if (trim((string) ($etapaActual['comentario_cierre'] ?? '')) !== ''): ?>
                    <details class="action-detail"><summary>Ver observación completa de la solución</summary><p><?= nl2br(escaparFlujo($etapaActual['comentario_cierre'])) ?></p></details>
                <?php endif; ?>

                <div class="action-rating-summary">
                    <div>
                        <span>Tipo de calificación</span>
                        <strong><?= escaparFlujo((fn ($__mesaMatchValue26) => (($__mesaMatchValue26 === ('encuesta_servicio')) ? ('Encuesta única del servicio solicitado') : ((($__mesaMatchValue26 === ('evaluacion_derivacion')) ? ('Evaluación interna de la derivación') : ((($__mesaMatchValue26 === ('evaluacion_caso')) ? ('Evaluación operativa del caso') : ('Pendiente de calificación')))))))((string) ($etapaActual['tipo_calificacion'] ?? ''))) ?></strong>
                    </div>
                    <div><span>Evaluador</span><strong><?= escaparFlujo($etapaActual['evaluador_nombre'] ?? 'Sin calificar') ?></strong></div>
                    <div><span>Gestión del proceso</span><strong><?= ($etapaActual['calificacion_area'] ?? null) === null ? 'Pendiente' : (int) $etapaActual['calificacion_area'] . '/5' ?></strong></div>
                    <div><span>Tiempo de respuesta</span><strong><?= ($etapaActual['calificacion_tiempo'] ?? null) === null ? 'Pendiente' : (int) $etapaActual['calificacion_tiempo'] . '/5' ?></strong></div>
                    <div><span>Calificación general</span><strong><?= ($etapaActual['calificacion'] ?? null) === null ? 'Pendiente' : (int) $etapaActual['calificacion'] . '/5' ?></strong></div>
                </div>
                <?php if (trim((string) ($etapaActual['comentario_calificacion'] ?? '')) !== ''): ?>
                    <details class="action-detail"><summary>Ver comentario completo de la calificación</summary><p><?= nl2br(escaparFlujo($etapaActual['comentario_calificacion'])) ?></p></details>
                <?php endif; ?>
                </div>
            </details>
            <div class="audit-log">
                <?php if (!$historial): ?><p class="muted">Este caso no tiene acciones registradas todavía.</p><?php endif; ?>
                <?php foreach ($historial as $evento): ?>
                    <article class="audit-item">
                        <div class="audit-item-head">
                            <div>
                                <span class="audit-item-label">Acción realizada</span>
                                <strong><?= escaparFlujo($evento['accion']) ?></strong>
                            </div>
                            <time class="audit-item-time" datetime="<?= escaparFlujo((string) $evento['creado_en']) ?>">
                                <?= escaparFlujo(fechaFlujo($evento['creado_en'])) ?>
                            </time>
                        </div>
                        <p><span class="audit-item-label">Qué se hizo</span><?= escaparFlujo($evento['detalle']) ?></p>
                        <div class="audit-item-meta">
                            <span>
                                Realizado por:
                                <b><?= escaparFlujo($evento['usuario']) ?></b>
                                · <?= escaparFlujo(rolChatFlujo((int) ($evento['usuario_rol'] ?? 0))) ?>
                            </span>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

        <div class="detail-grid case-dialog-panes">
            <div>
                <?php
                    $chatActualInterno = $conversacionActual
                        && (string) ($conversacionActual['tipo_conversacion'] ?? '')
                            === 'derivacion';
                ?>
                <section
                    class="card case-pane"
                    data-case-panel="archivos"
                    <?= $panelCaso === 'archivos' ? '' : 'hidden' ?>
                >
                    <div class="card-head"><h2>Archivos</h2></div>
                    <div class="files">
                        <?php if (!$adjuntos): ?><p class="muted">No hay archivos adjuntos en esta conversación.</p><?php endif; ?>
                        <?php foreach ($adjuntos as $archivo): ?>
                            <div class="file">
                                <div>
                                    <strong><?= escaparFlujo($archivo['nombre_original']) ?></strong>
                                    <div class="meta">
                                        <?= $chatActualInterno
                                            ? 'Ticket ' . escaparFlujo($conversacionActual['codigo_ticket'] ?? '')
                                            : 'Caso ' . escaparFlujo($conversacionActual['codigo_caso'] ?? '')
                                                . ' · Etapa ' . (int) ($conversacionActual['numero_etapa'] ?? 1)
                                        ?> ·
                                        <?= escaparFlujo(($archivo['usuario'] ?: 'Usuario') . ' · ' . fechaFlujo($archivo['creado_en'])) ?>
                                    </div>
                                </div>
                                <a class="btn light" href="descargarAdjunto.php?id=<?= (int) $archivo['id_adjunto'] ?>">Descargar</a>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>
            </div>

            <div>
                <?php if ($etapaActual): ?>
                    <section
                        id="case-main-summary"
                        class="card case-pane"
                        data-case-panel="resumen"
                        <?= $panelCaso === 'resumen' ? '' : 'hidden' ?>
                    >
                        <div class="card-head">
                            <div>
                                <h2><?= $casoSeleccionadoCerrado ? 'Solución de ' : 'Gestión de ' ?><?= escaparFlujo($etiquetaNodoActual) ?></h2>
                                <p class="muted"><?= escaparFlujo($etapaActual['catalogo_nombre'] . ' · ' . $etapaActual['servicio_nombre']) ?></p>
                            </div>
                            <span class="case-status <?= escaparFlujo($estadoNodo) ?>"><?= escaparFlujo(textoEstadoCaso($estadoNodo)) ?></span>
                        </div>

                        <?php if ($esTicketDerivadoActual): ?>
                            <section id="case-request-overview" class="manager-request-overview" aria-label="Solicitud de la derivación">
                                <div class="manager-request-overview-item">
                                    <span>Apoyo solicitado</span>
                                    <strong><?= escaparFlujo($etapaActual['catalogo_nombre'] . ' · ' . $etapaActual['servicio_nombre']) ?></strong>
                                </div>
                                <div class="manager-request-overview-item is-description">
                                    <span>Solicitud del gestor creador</span>
                                    <p><?= nl2br(escaparFlujo(trim((string) ($etapaActual['motivo_derivacion'] ?? '')) ?: 'Sin detalle registrado.')) ?></p>
                                </div>
                            </section>
                        <?php else: ?>
                            <section id="case-request-overview" class="manager-request-overview" aria-label="Solicitud original del caso">
                                <div class="manager-request-overview-item">
                                    <span>Asunto</span>
                                    <strong><?= escaparFlujo($ticketSeleccionado['titulo']) ?></strong>
                                </div>
                                <div class="manager-request-overview-item is-description">
                                    <span>Descripción de la solicitud</span>
                                    <p><?= nl2br(escaparFlujo($ticketSeleccionado['descripcion'])) ?></p>
                                </div>
                            </section>
                        <?php endif; ?>

                        <?php if ($camposExtrasEtapa): ?>
                            <section class="manager-request-overview campos-extra-informacion" aria-label="Campos extras del servicio">
                                <div class="manager-request-overview-item is-description">
                                    <span>Información adicional del servicio</span>
                                    <div class="campos-extra-informacion-grid">
                                        <?php foreach ($camposExtrasEtapa as $campoExtraEtapa): ?>
                                            <div class="campos-extra-informacion-item">
                                                <strong><?= escaparFlujo($campoExtraEtapa['etiqueta']) ?></strong>
                                                <p><?= nl2br(escaparFlujo($campoExtraEtapa['valor'])) ?></p>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </section>
                        <?php endif; ?>

                        <section class="stage-summary case-secondary-info" aria-label="Información complementaria de la etapa">
                            <div class="stage-data">
                                <span>Solicitante</span>
                                <strong><?= escaparFlujo($ticketSeleccionado['solicitante_nombre'] ?? $ticketSeleccionado['creador_nombre'] ?? 'Usuario no disponible') ?></strong>
                            </div>
                            <div class="stage-data">
                                <span>Proceso</span>
                                <strong><?= escaparFlujo(trim((string) ($etapaActual['catalogo_nombre'] ?? '') . ' · ' . (string) ($etapaActual['servicio_nombre'] ?? ''), ' ·') ?: 'Sin proceso' ) ?></strong>
                            </div>
                            <div class="stage-data">
                                <span>Gestor</span>
                                <strong><?= escaparFlujo($etapaActual['gestor_nombre'] ?? 'Sin asignar') ?></strong>
                            </div>
                            <div class="stage-data">
                                <span>SLA</span>
                                <strong><?= escaparFlujo($etapaActual['sla_nombre'] ?? 'Sin SLA') ?></strong>
                            </div>
                        </section>

                        <?php if ($avisoReapertura): ?>
                            <aside class="reopen-notice" role="status" aria-label="Aviso de reapertura">
                                <strong><?= (int) ($etapaActual['id_ticket_etapa_padre'] ?? 0) > 0 ? 'Esta derivación fue reabierta' : 'Este caso fue reabierto' ?></strong>
                                <p><?= nl2br(escaparFlujo((string) $avisoReapertura['mensaje'])) ?></p>
                                <small><?= escaparFlujo(fechaFlujo($avisoReapertura['creada_en'] ?? null)) ?></small>
                            </aside>
                        <?php endif; ?>

                        <?php if ($casoSeleccionadoCerrado): ?>
                            <div class="closed-case">
                                <strong>Caso cerrado · modo consulta</strong>
                                <p>Marcado listo: <?= escaparFlujo(fechaFlujo($etapaActual['fecha_marcado_listo'] ?? $etapaActual['fecha_finalizacion'])) ?></p>
                                <p>Cerrado por su creador: <?= escaparFlujo(fechaFlujo($etapaActual['fecha_finalizacion'])) ?></p>
                                <p>Tiempo medido hasta Listo: <?= escaparFlujo(tiempoFlujo($etapaActual['minutos_hasta_listo'] ?? $etapaActual['minutos_atencion'])) ?></p>
                                <p>Resultado SLA para indicadores: <?= escaparFlujo($etapaActual['resultado_sla']) ?></p>
                                <?php if (trim((string) ($etapaActual['solucion_nombre'] ?? '')) !== ''): ?>
                                    <p><strong>Solución seleccionada:</strong> <?= escaparFlujo($etapaActual['solucion_nombre']) ?></p>
                                <?php elseif (trim((string) ($etapaActual['comentario_cierre'] ?? '')) !== ''): ?>
                                    <p><strong>Solución seleccionada:</strong> Cierre anterior sin clasificación</p>
                                <?php endif; ?>
                                <?php if (trim((string) ($etapaActual['comentario_cierre'] ?? '')) !== ''): ?>
                                    <details>
                                        <summary><strong>Ver observación de la solución</strong></summary>
                                        <p><?= nl2br(escaparFlujo($etapaActual['comentario_cierre'])) ?></p>
                                    </details>
                                <?php endif; ?>
                                <?php if (($etapaActual['calificacion'] ?? null) !== null): ?>
                                    <p><strong>Calificación del cierre:</strong> proceso <?= (int) $etapaActual['calificacion_area'] ?>/5 · tiempo <?= (int) $etapaActual['calificacion_tiempo'] ?>/5 · general <?= (int) $etapaActual['calificacion'] ?>/5</p>
                                    <?php if (trim((string) ($etapaActual['comentario_calificacion'] ?? '')) !== ''): ?>
                                        <details>
                                            <summary><strong>Ver comentario de la calificación</strong></summary>
                                            <p><?= nl2br(escaparFlujo($etapaActual['comentario_calificacion'])) ?></p>
                                        </details>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <p>La comunicación, los archivos y las acciones de este caso permanecen disponibles únicamente para consulta.</p>
                            </div>
                        <?php else: ?>
                        <?php if ($estadoNodo === 'listo_cierre'): ?>
                            <?php
                                $slaVisible = (string) (
                                    $etapaActual['estado_sla_actual']
                                    ?? 'en_tiempo'
                                );
                                $textoTipoCalificacion = (fn ($__mesaMatchValue27) => (($__mesaMatchValue27 === ('encuesta_servicio')) ? ('Encuesta única del servicio solicitado') : ((($__mesaMatchValue27 === ('evaluacion_derivacion')) ? ('Evaluación interna de la derivación') : ('Evaluación operativa del caso')))))($tipoCalificacionNodo);
                                $esDerivacionLista = (int) ($etapaActual['id_ticket_etapa_padre'] ?? 0) > 0;
                                $esCierreDefinitivoListo = !empty($etapaActual['solicita_cierre_definitivo']);
                                $numeroEtapaLista = (int) ($etapaActual['numero_etapa'] ?? $etapaActual['orden'] ?? 1);
                                $etiquetaSolucionLista = $esDerivacionLista
                                    ? 'Derivación ' . (string) ($etapaActual['codigo_ticket'] ?? $etapaActual['codigo_nodo'] ?? $numeroEtapaLista)
                                    : 'Etapa ' . $numeroEtapaLista;
                                $etiquetaSolucionLista .= ' · ' . trim(
                                    (string) ($etapaActual['catalogo_nombre'] ?? '') . ' / '
                                        . (string) ($etapaActual['servicio_nombre'] ?? ''),
                                    ' /'
                                );
                                $siguienteEtapaLista = null;

                                if (!$esDerivacionLista && !$esCierreDefinitivoListo) {
                                    $ordenEtapaLista = (int) ($etapaActual['orden'] ?? 0);
                                    foreach ($etapasOficiales as $posibleSiguienteLista) {
                                        if (
                                            (int) ($posibleSiguienteLista['orden'] ?? 0) > $ordenEtapaLista
                                            && (string) ($posibleSiguienteLista['estado'] ?? '') === 'bloqueada'
                                        ) {
                                            $siguienteEtapaLista = $posibleSiguienteLista;
                                            break;
                                        }
                                    }
                                }

                                if ($esCierreDefinitivoListo) {
                                    $claseResultadoSolucion = 'is-definitive';
                                    $tipoResultadoSolucion = 'Solución definitiva';
                                    $tituloResultadoSolucion = 'Cierra todo el caso';
                                    $detalleResultadoSolucion = 'Al aprobar, se cerrará el caso y se cancelarán las etapas futuras que no hayan iniciado.';
                                    $textoBotonResultadoSolucion = 'Calificar y aprobar cierre definitivo';
                                    $confirmacionResultadoSolucion = '¿Confirma la calificación y el cierre definitivo del caso?';
                                } elseif ($esDerivacionLista) {
                                    $claseResultadoSolucion = 'is-derivation';
                                    $tipoResultadoSolucion = 'Solución de una derivación';
                                    $tituloResultadoSolucion = 'Devuelve el control a la etapa solicitante';
                                    $detalleResultadoSolucion = 'Al aprobar, esta derivación quedará completada. La etapa que pidió el apoyo se reanudará cuando terminen las demás derivaciones pendientes.';
                                    $textoBotonResultadoSolucion = 'Calificar y aprobar derivación';
                                    $confirmacionResultadoSolucion = '¿Confirma la calificación y la aprobación de esta derivación?';
                                } elseif ($siguienteEtapaLista) {
                                    $claseResultadoSolucion = 'is-continue';
                                    $numeroSiguienteLista = (int) ($siguienteEtapaLista['numero_etapa'] ?? $siguienteEtapaLista['orden'] ?? ($numeroEtapaLista + 1));
                                    $tipoResultadoSolucion = 'Solución de una etapa';
                                    $tituloResultadoSolucion = 'Continúa a la siguiente etapa';
                                    $detalleResultadoSolucion = 'Al aprobar, continuará la Etapa ' . $numeroSiguienteLista . ' · '
                                        . trim((string) ($siguienteEtapaLista['catalogo_nombre'] ?? '') . ' / '
                                            . (string) ($siguienteEtapaLista['servicio_nombre'] ?? ''), ' /') . '.';
                                    $textoBotonResultadoSolucion = 'Calificar y continuar el flujo';
                                    $confirmacionResultadoSolucion = '¿Confirma la calificación? Esta etapa se completará y se habilitará la siguiente.';
                                } else {
                                    $claseResultadoSolucion = 'is-final';
                                    $tipoResultadoSolucion = 'Solución de la etapa final';
                                    $tituloResultadoSolucion = 'Finaliza el flujo';
                                    $detalleResultadoSolucion = 'Al aprobar, esta última etapa quedará completada y el caso se cerrará.';
                                    $textoBotonResultadoSolucion = 'Calificar y finalizar el caso';
                                    $confirmacionResultadoSolucion = '¿Confirma la calificación y el cierre del caso al completar su última etapa?';
                                }
                            ?>
                            <div class="ready-approval <?= escaparFlujo($claseResultadoSolucion) ?>">
                                <div class="ready-approval-head">
                                    <div>
                                        <strong><?= !empty($etapaActual['solicita_cierre_definitivo']) ? 'Cierre definitivo solicitado · resolución en primer contacto' : 'Listo · pendiente de decisión del creador' ?></strong>
                                        <p>El gestor asignado terminó su gestión el <?= escaparFlujo(fechaFlujo($etapaActual['fecha_marcado_listo'] ?? null)) ?>.</p>
                                    </div>
                                    <span class="badge"><?= escaparFlujo($slaVisible === 'vencido' ? 'Visualmente vencido' : 'Visualmente en tiempo') ?></span>
                                </div>
                                <div class="ready-solution-context" aria-label="Contexto de la solución pendiente">
                                    <div>
                                        <span><?= $esDerivacionLista ? 'Derivación que presenta la solución' : 'Etapa que presenta la solución' ?></span>
                                        <strong><?= escaparFlujo($etiquetaSolucionLista) ?></strong>
                                    </div>
                                    <div class="<?= escaparFlujo($claseResultadoSolucion) ?>">
                                        <span><?= escaparFlujo($tipoResultadoSolucion) ?></span>
                                        <strong><?= escaparFlujo($tituloResultadoSolucion) ?></strong>
                                        <p><?= escaparFlujo($detalleResultadoSolucion) ?></p>
                                    </div>
                                </div>
                                <div class="ready-delivery">
                                    <div>
                                        <span>Solución informada por el gestor</span>
                                        <strong><?= escaparFlujo($etapaActual['solucion_nombre'] ?? 'Sin clasificar') ?></strong>
                                    </div>
                                    <div>
                                        <span>Detalle de la solución</span>
                                        <p><?= nl2br(escaparFlujo(trim((string) ($etapaActual['comentario_cierre'] ?? '')) ?: 'Sin detalle registrado.')) ?></p>
                                    </div>
                                </div>

                                <?php if ($puedeCerrarNodo): ?>
                                    <form method="post" class="case-rating-form" onsubmit="return confirm('<?= escaparFlujo($confirmacionResultadoSolucion) ?>')">
                                        <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                        <input type="hidden" name="accion" value="cerrar_caso">
                                        <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                        <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaActual['id_ticket_etapa'] ?>">
                                        <h3><?= escaparFlujo($textoTipoCalificacion) ?></h3>
                                        <p class="muted"><?= escaparFlujo($detalleResultadoSolucion) ?></p>
                                        <div class="rating-fields">
                                            <div>
                                                    <label for="calificacion_area_caso">Gestión del proceso *</label>
                                                <select id="calificacion_area_caso" name="calificacion_area" required>
                                                    <option value="">Seleccione</option>
                                                    <?php for ($nota = 5; $nota >= 1; $nota--): ?>
                                                        <option value="<?= $nota ?>"><?= $nota ?> - <?= ['','Muy deficiente','Deficiente','Aceptable','Muy buena','Excelente'][$nota] ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                            <div>
                                                <label for="calificacion_tiempo_caso">Tiempo de respuesta *</label>
                                                <select id="calificacion_tiempo_caso" name="calificacion_tiempo" required>
                                                    <option value="">Seleccione</option>
                                                    <?php for ($nota = 5; $nota >= 1; $nota--): ?>
                                                        <option value="<?= $nota ?>"><?= $nota ?> - <?= ['','Muy deficiente','Deficiente','Aceptable','Muy buena','Excelente'][$nota] ?></option>
                                                    <?php endfor; ?>
                                                </select>
                                            </div>
                                            <div>
                                                <label for="comentario_calificacion_caso">Observación opcional</label>
                                                <textarea id="comentario_calificacion_caso" name="comentario_calificacion" maxlength="1000" placeholder="Indique qué fue positivo o qué debe mejorar"></textarea>
                                            </div>
                                        </div>
                                        <div class="approval-actions">
                                            <button class="primary" type="submit"><?= escaparFlujo($textoBotonResultadoSolucion) ?></button>
                                        </div>
                                    </form>
                                    <form method="post" class="reopen-form" onsubmit="return confirm('¿Reabrir este caso? El corte de Listo se anulará y el SLA incluirá todo el tiempo transcurrido.')">
                                        <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                        <input type="hidden" name="accion" value="reabrir_derivacion">
                                        <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                        <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaActual['id_ticket_etapa'] ?>">
                                        <label for="motivo_reapertura">Motivo obligatorio de reapertura</label>
                                        <textarea id="motivo_reapertura" name="motivo_reapertura" maxlength="1000" required placeholder="Explique por qué la solución informada no permite cerrar el caso"></textarea>
                                        <div class="approval-actions"><button class="btn danger" type="submit"><?= (int) ($etapaActual['id_ticket_etapa_padre'] ?? 0) > 0 ? 'Reabrir derivación' : 'Reabrir caso' ?></button></div>
                                    </form>
                                <?php else: ?>
                                    <div class="alert info" style="margin-top:12px">
                                        Solo el creador de este caso puede calificarlo, cerrarlo o reabrirlo. Mientras tanto, el vencimiento visible continúa; el dashboard conserva el corte realizado al marcar Listo.
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php
                            $totalDerivacionesActivasNodo = max(
                                0,
                                (int) ($etapaActual['hijos_pendientes'] ?? 0)
                            );
                            $cuposDerivacionesNodo = max(
                                0,
                                20 - $totalDerivacionesActivasNodo
                            );
                        ?>
                        <?php if (
                            $estadoNodo !== 'listo_cierre'
                            && $puedeCrearHijo
                            && $cuposDerivacionesNodo > 0
                        ): ?>
                            <?php
                                $serviciosBloqueadosDerivacion = [
                                    (int) ($etapaActual['id_servicio'] ?? 0),
                                ];
                                foreach (
                                    $hijosPorPadre[(int) $etapaActual['id_ticket_etapa']] ?? []
                                    as $hijoActivoDerivacion
                                ) {
                                    if (!in_array(
                                        (string) ($hijoActivoDerivacion['estado'] ?? ''),
                                        ['completada', 'cancelada'],
                                        true
                                    )) {
                                        $serviciosBloqueadosDerivacion[] = (int) (
                                            $hijoActivoDerivacion['id_servicio'] ?? 0
                                        );
                                    }
                                }
                                $serviciosBloqueadosDerivacion = array_values(array_unique(
                                    array_filter($serviciosBloqueadosDerivacion)
                                ));
                            ?>
                            <details class="case-panel-toggle derivation-panel" style="margin:10px 0">
                                <summary><span class="case-toggle-copy"><strong>Solicitar apoyo de otro proceso</strong><small>Úselo si necesita que otro proceso resuelva una parte del caso. Su SLA se pausará mientras recibe respuesta.</small></span></summary>
                                <form
                                    class="derivation-form"
                                    method="post"
                                    data-max-derivaciones="<?= $cuposDerivacionesNodo ?>"
                                    data-blocked-services="<?= escaparFlujo((string) json_encode($serviciosBloqueadosDerivacion)) ?>"
                                >
                                    <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                    <input type="hidden" name="accion" value="crear_caso_hijo">
                                    <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                    <input type="hidden" name="id_ticket_etapa_padre" value="<?= (int) $etapaActual['id_ticket_etapa'] ?>">
                                    <div class="derivation-list" data-derivation-list>
                                        <div class="derivation-row" data-derivation-row>
                                            <div>
                                                <label>Proceso destino</label>
                                                <select name="derivaciones[0][id_catalogo_destino]" data-derivation-catalog required>
                                                    <option value="">Seleccione el proceso</option>
                                                    <?php foreach ($catalogosDerivacion as $catalogoDestino): ?>
                                                        <option value="<?= (int) $catalogoDestino['id_catalogo'] ?>">
                                                            <?= escaparFlujo($catalogoDestino['nombre']) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div>
                                                <label>Buscar servicio destino</label>
                                                <div class="derivation-service-combobox" data-service-combobox>
                                                    <input
                                                        class="derivation-service-search"
                                                        type="search"
                                                        data-service-search
                                                        autocomplete="off"
                                                        placeholder="Seleccione primero un proceso"
                                                        role="combobox"
                                                        aria-autocomplete="list"
                                                        aria-expanded="false"
                                                        required
                                                        disabled
                                                    >
                                                    <button
                                                        class="derivation-service-toggle"
                                                        type="button"
                                                        data-service-toggle
                                                        aria-label="Mostrar todos los servicios del proceso"
                                                        aria-expanded="false"
                                                        disabled
                                                    ></button>
                                                    <input type="hidden" name="derivaciones[0][id_servicio_destino]" data-service-id>
                                                    <div class="derivation-service-menu" data-service-menu role="listbox" hidden></div>
                                                </div>
                                                <small class="derivation-service-help" data-service-help>Los servicios se habilitan al seleccionar el proceso.</small>
                                                <div class="derivation-extra-fields" data-derivation-extra-fields hidden></div>
                                            </div>
                                            <div>
                                                <label>Motivo y requerimiento</label>
                                                <textarea name="derivaciones[0][motivo_derivacion]" maxlength="2000" required placeholder="Explique qué necesita del proceso destino"></textarea>
                                            </div>
                                            <button class="btn danger remove-derivation" type="button" data-remove-derivation hidden>Quitar</button>
                                        </div>
                                    </div>
                                    <div class="derivation-footer">
                                        <button class="btn light" type="button" data-add-derivation>＋ Agregar otro proceso</button>
                                        <span class="muted" data-derivation-count>1 derivación preparada</span>
                                        <button class="primary" type="submit">Enviar solicitudes de apoyo</button>
                                    </div>
                                    <p class="muted" style="padding:0 8px 8px">Puede enviar hasta <?= $cuposDerivacionesNodo ?> derivación<?= $cuposDerivacionesNodo === 1 ? '' : 'es' ?> adicional<?= $cuposDerivacionesNodo === 1 ? '' : 'es' ?>. El servicio actual y los apoyos que ya están activos se excluyen automáticamente.</p>
                                    <script type="application/json" data-derivation-services-json><?= $serviciosDerivacionJson ?></script>
                                    <template data-derivation-template>
                                        <div class="derivation-row" data-derivation-row>
                                            <div>
                                                <label>Proceso destino</label>
                                                <select name="derivaciones[__INDEX__][id_catalogo_destino]" data-derivation-catalog required>
                                                    <option value="">Seleccione el proceso</option>
                                                    <?php foreach ($catalogosDerivacion as $catalogoDestino): ?>
                                                        <option value="<?= (int) $catalogoDestino['id_catalogo'] ?>">
                                                            <?= escaparFlujo($catalogoDestino['nombre']) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div>
                                                <label>Buscar servicio destino</label>
                                                <div class="derivation-service-combobox" data-service-combobox>
                                                    <input
                                                        class="derivation-service-search"
                                                        type="search"
                                                        data-service-search
                                                        autocomplete="off"
                                                        placeholder="Seleccione primero un proceso"
                                                        role="combobox"
                                                        aria-autocomplete="list"
                                                        aria-expanded="false"
                                                        required
                                                        disabled
                                                    >
                                                    <button
                                                        class="derivation-service-toggle"
                                                        type="button"
                                                        data-service-toggle
                                                        aria-label="Mostrar todos los servicios del proceso"
                                                        aria-expanded="false"
                                                        disabled
                                                    ></button>
                                                    <input type="hidden" name="derivaciones[__INDEX__][id_servicio_destino]" data-service-id>
                                                    <div class="derivation-service-menu" data-service-menu role="listbox" hidden></div>
                                                </div>
                                                <small class="derivation-service-help" data-service-help>Los servicios se habilitan al seleccionar el proceso.</small>
                                                <div class="derivation-extra-fields" data-derivation-extra-fields hidden></div>
                                            </div>
                                            <div>
                                                <label>Motivo y requerimiento</label>
                                                <textarea name="derivaciones[__INDEX__][motivo_derivacion]" maxlength="2000" required placeholder="Explique qué necesita del proceso destino"></textarea>
                                            </div>
                                            <button class="btn danger remove-derivation" type="button" data-remove-derivation>Quitar</button>
                                        </div>
                                    </template>
                                </form>
                            </details>
                        <?php elseif (
                            $estadoNodo !== 'listo_cierre'
                            &&
                            in_array(
                                $estadoNodo,
                                ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada'],
                                true
                            )
                        ): ?>
                            <div class="alert info" style="margin:10px 0">
                                <?php if ($rol === 1): ?>
                                    La trazabilidad está disponible, pero el ticket derivado debe crearlo el gestor asignado a esta etapa.
                                <?php else: ?>
                                    Solo <strong><?= escaparFlujo($etapaActual['gestor_nombre']) ?></strong>, gestor asignado a esta etapa, puede derivar el caso a otro proceso.
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($estadoNodo !== 'listo_cierre' && $puedeGestionar): ?>
                            <details class="case-panel-toggle manager-action-panel" style="margin-top:10px" <?= $checklistObligatorioPendiente > 0 ? 'open' : '' ?>>
                                <summary><span class="case-toggle-copy"><strong>Revisar checklist de la etapa</strong><small>Complete y guarde los requisitos obligatorios antes de finalizar su gestión.</small></span></summary>
                                <div class="case-panel-toggle-body">
                                    <form method="post" data-case-checklist-form>
                                        <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                        <input type="hidden" name="accion" value="guardar_checklist">
                                        <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                        <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaActual['id_ticket_etapa'] ?>">
                                        <?php if (!$checklist): ?>
                                            <p class="muted">Esta etapa no tiene elementos configurados.</p>
                                            <?php if ($rol === 1 && !empty($etapaActual['id_proceso_etapa'])): ?>
                                                <div class="notice-panel">
                                                    <strong>Configure la plantilla de esta etapa.</strong>
                                                    <p>Los elementos activos se copiarán automáticamente a los casos nuevos.</p>
                                                    <span class="muted">La plantilla del checklist debe configurarse desde la administración del proceso.</span>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php foreach ($checklist as $item): ?>
                                            <div class="check" <?= (int) $item['obligatorio'] === 1 ? 'data-required-checklist-row' : '' ?>>
                                                <label>
                                                    <input type="checkbox" name="completado[<?= (int) $item['id_ticket_checklist'] ?>]" value="1" <?= (int) $item['completado'] === 1 ? 'checked' : '' ?> <?= (int) $item['obligatorio'] === 1 ? 'data-required-checklist' : '' ?>>
                                                    <span>
                                                        <strong><?= escaparFlujo($item['nombre']) ?><?= (int) $item['obligatorio'] === 1 ? ' *' : '' ?></strong>
                                                        <span class="meta"><?= escaparFlujo($item['descripcion']) ?></span>
                                                    </span>
                                                </label>
                                                <input name="observacion[<?= (int) $item['id_ticket_checklist'] ?>]" value="<?= escaparFlujo($item['observacion']) ?>" placeholder="Observación opcional">
                                            </div>
                                        <?php endforeach; ?>
                                        <div class="form-actions"><button class="light" type="submit">Guardar checklist</button></div>
                                    </form>
                                </div>
                            </details>

                            <details class="case-panel-toggle manager-action-panel" style="margin-top:10px" <?= $checklistObligatorioPendiente === 0 ? 'open' : '' ?>>
                                <summary><span class="case-toggle-copy"><strong>Finalizar mi gestión y enviar a revisión</strong><small>Seleccione la solución aplicada y describa el resultado obtenido.</small></span></summary>
                                <div class="case-panel-toggle-body">
                                    <form method="post" data-checklist-protected-form data-solution-form data-confirm-message="¿Confirma que la solución está lista para revisión? El creador del caso será notificado para calificar, cerrar o reabrir?">
                                        <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                        <input type="hidden" name="accion" value="marcar_listo">
                                        <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                        <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaActual['id_ticket_etapa'] ?>">
                                        <div class="solution-choice-grid">
                                            <div class="solution-choice-main">
                                                <label for="id_solucion">Solución aplicada *</label>
                                                <select id="id_solucion" name="id_solucion" required data-solution-select>
                                                    <option value="">Seleccione una solución existente</option>
                                                    <?php foreach ($solucionesCaso as $solucionCaso): ?>
                                                        <option
                                                            value="<?= (int) $solucionCaso['id_solucion'] ?>"
                                                            data-description="<?= escaparFlujo($solucionCaso['descripcion'] ?? '') ?>"
                                                        ><?= escaparFlujo($solucionCaso['nombre']) ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <div class="solution-choice-actions">
                                                    <button class="btn light" type="button" data-new-solution-toggle>+ Crear solución</button>
                                                    <a class="btn light" href="soluciones.php?id_servicio=<?= (int) ($etapaActual['id_servicio'] ?? 0) ?>">Ver biblioteca</a>
                                                </div>
                                            </div>
                                            <aside class="solution-guide" data-solution-guide aria-live="polite">
                                                <span>Guía de la solución</span>
                                                <strong data-solution-guide-title>Seleccione una solución</strong>
                                                <p data-solution-guide-text>Aquí verá para qué casos debe utilizarse y podrá elegir la alternativa adecuada.</p>
                                            </aside>
                                        </div>
                                        <div class="new-solution-panel" data-new-solution hidden>
                                            <div class="new-solution-panel-head"><strong>Crear una solución reutilizable</strong><p>Defina qué es y cuándo debe utilizarse. Después de crearla quedará seleccionada en este caso.</p></div>
                                            <div class="new-solution-field"><label for="nueva_solucion_nombre">Nombre de la solución *</label><input id="nueva_solucion_nombre" name="nueva_solucion_nombre" maxlength="180" disabled placeholder="Ej. Reinicio del computador"></div>
                                            <div class="new-solution-field"><label for="nueva_solucion_descripcion">Descripción y criterio de uso *</label><textarea id="nueva_solucion_descripcion" name="nueva_solucion_descripcion" maxlength="500" disabled placeholder="Ej. Utilizar cuando el equipo no responde; reiniciar, conectar el cargador y validar que inicie correctamente."></textarea></div>
                                            <p class="new-solution-status" data-new-solution-status aria-live="polite"></p>
                                            <div class="new-solution-panel-actions"><button class="btn light" type="button" data-new-solution-cancel>Cancelar</button><button class="primary" type="button" data-create-solution>Crear y seleccionar</button></div>
                                        </div>
                                        <div data-solution-observation hidden>
                                            <label for="comentario_cierre">Detalle de lo realizado en este caso *</label>
                                            <p class="muted">Registre la acción concreta, las validaciones y el resultado de este caso. Esta información quedará en su trazabilidad.</p>
                                            <textarea id="comentario_cierre" name="comentario_cierre" maxlength="2000" required disabled placeholder="Ej. Se reinició el equipo, se conectó el cargador y se validó el inicio correcto con el usuario."></textarea>
                                        </div>
                                        <div class="checklist-gate" data-checklist-gate <?= $checklistObligatorioPendiente === 0 ? 'hidden' : '' ?>>
                                            <span class="checklist-gate-icon" aria-hidden="true">⚠</span>
                                            <div><strong>Checklist obligatorio pendiente.</strong><br><span data-checklist-gate-text>Complete y guarde los <?= $checklistObligatorioPendiente ?> ítem(s) obligatorio(s) pendiente(s) antes de continuar.</span></div>
                                        </div>
                                        <div class="form-actions"><button class="primary checklist-gated-button" type="submit" data-checklist-action="Enviar solución a revisión" aria-disabled="<?= $checklistObligatorioPendiente > 0 ? 'true' : 'false' ?>">Enviar solución a revisión</button></div>
                                    </form>
                                </div>
                            </details>

                            <?php if (empty($etapaActual['es_derivacion']) && (int) ($etapaActual['id_ticket_etapa_padre'] ?? 0) === 0): ?>
                            <details class="case-panel-toggle manager-exception-panel" style="margin-top:10px">
                                <summary><span class="case-toggle-copy"><strong>Cerrar todo el caso desde esta etapa</strong><small>Opción excepcional: utilícela solo si resolvió completamente la solicitud y no deben continuar más etapas.</small></span></summary>
                                <div class="case-panel-toggle-body">
                                    <div class="alert info" style="margin-bottom:12px">
                                        Use esta opción únicamente cuando esta etapa resolvió completamente la necesidad y no es necesario continuar con las siguientes etapas del flujo.
                                    </div>
                                    <form method="post" data-checklist-protected-form data-solution-form data-confirm-message="¿Confirma que el caso fue resuelto en primer contacto? Si el solicitante aprueba, las etapas siguientes no se ejecutarán y el ticket se cerrará definitivamente?">
                                        <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                        <input type="hidden" name="accion" value="solicitar_cierre_definitivo">
                                        <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                        <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaActual['id_ticket_etapa'] ?>">
                                        <div class="solution-choice-grid">
                                            <div class="solution-choice-main">
                                                <label for="id_solucion_primer_contacto">Solución aplicada *</label>
                                                <select id="id_solucion_primer_contacto" name="id_solucion" required data-solution-select>
                                                    <option value="">Seleccione una solución existente</option>
                                                    <?php foreach ($solucionesCaso as $solucionCaso): ?>
                                                        <option value="<?= (int) $solucionCaso['id_solucion'] ?>" data-description="<?= escaparFlujo($solucionCaso['descripcion'] ?? '') ?>"><?= escaparFlujo($solucionCaso['nombre']) ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <div class="solution-choice-actions">
                                                    <button class="btn light" type="button" data-new-solution-toggle>+ Crear solución</button>
                                                    <a class="btn light" href="soluciones.php?id_servicio=<?= (int) ($etapaActual['id_servicio'] ?? 0) ?>">Ver biblioteca</a>
                                                </div>
                                            </div>
                                            <aside class="solution-guide" data-solution-guide aria-live="polite">
                                                <span>Guía de la solución</span>
                                                <strong data-solution-guide-title>Seleccione una solución</strong>
                                                <p data-solution-guide-text>Aquí verá para qué casos debe utilizarse y podrá elegir la alternativa adecuada.</p>
                                            </aside>
                                        </div>
                                        <div class="new-solution-panel" data-new-solution hidden>
                                            <div class="new-solution-panel-head"><strong>Crear una solución reutilizable</strong><p>Defina qué es y cuándo debe utilizarse. Después de crearla quedará seleccionada en este caso.</p></div>
                                            <div class="new-solution-field"><label for="nueva_solucion_nombre_primer_contacto">Nombre de la solución *</label><input id="nueva_solucion_nombre_primer_contacto" name="nueva_solucion_nombre" maxlength="180" disabled placeholder="Ej. Reinicio del computador"></div>
                                            <div class="new-solution-field"><label for="nueva_solucion_descripcion_primer_contacto">Descripción y criterio de uso *</label><textarea id="nueva_solucion_descripcion_primer_contacto" name="nueva_solucion_descripcion" maxlength="500" disabled placeholder="Ej. Utilizar cuando el equipo no responde; reiniciar, conectar el cargador y validar que inicie correctamente."></textarea></div>
                                            <p class="new-solution-status" data-new-solution-status aria-live="polite"></p>
                                            <div class="new-solution-panel-actions"><button class="btn light" type="button" data-new-solution-cancel>Cancelar</button><button class="primary" type="button" data-create-solution>Crear y seleccionar</button></div>
                                        </div>
                                        <div data-solution-observation hidden>
                                            <label for="comentario_primer_contacto">Detalle de lo realizado en este caso *</label>
                                            <p class="muted">Registre la acción concreta, las validaciones y por qué el caso puede cerrarse sin continuar el flujo.</p>
                                            <textarea id="comentario_primer_contacto" name="comentario_cierre" maxlength="2000" required disabled placeholder="Explique qué resolvió, cómo lo hizo y el resultado validado con el usuario."></textarea>
                                        </div>
                                        <div class="checklist-gate" data-checklist-gate <?= $checklistObligatorioPendiente === 0 ? 'hidden' : '' ?>>
                                            <span class="checklist-gate-icon" aria-hidden="true">⚠</span>
                                            <div><strong>Checklist obligatorio pendiente.</strong><br><span data-checklist-gate-text>Complete y guarde los <?= $checklistObligatorioPendiente ?> ítem(s) obligatorio(s) pendiente(s) antes de continuar.</span></div>
                                        </div>
                                        <div class="form-actions"><button class="primary checklist-gated-button" type="submit" data-checklist-action="Solicitar cierre definitivo" aria-disabled="<?= $checklistObligatorioPendiente > 0 ? 'true' : 'false' ?>">Solicitar cierre definitivo</button></div>
                                    </form>
                                </div>
                            </details>
                            <?php endif; ?>
                        <?php elseif ($estadoNodo !== 'listo_cierre'): ?>
                            <p class="muted">
                                <?= $estadoNodo === 'pausada'
                                    ? 'Este caso está pausado mientras finalizan sus hijos.'
                                    : 'Solo el gestor asignado puede gestionar este caso.' ?>
                            </p>
                        <?php endif; ?>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>

            </div>
        </div>
                </div>
                <div
                    class="case-chat-widget"
                    data-case-chat-widget
                    data-ticket-id="<?= $idTicketSeleccionado ?>"
                    data-stage-id="<?= (int) ($conversacionActual['id_ticket_etapa'] ?? 0) ?>"
                    data-chat-selected="<?= $chatSeleccionadoExplicito ? 'true' : 'false' ?>"
                    data-chat-theme-version="2026-08-24.1"
                    data-auto-open="<?= $abrirChatCaso ? 'true' : 'false' ?>"
                >
                    <section
                        class="case-chat-panel"
                        id="case-chat-panel"
                        aria-label="Conversación del caso"
                        aria-hidden="true"
                    >
                        <header class="case-chat-header">
                            <span class="case-chat-avatar" aria-hidden="true">
                                <svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 9h8M8 13h5"/></svg>
                            </span>
                            <div class="case-chat-header-copy">
                                <strong><?= $chatSeleccionadoExplicito ? escaparFlujo($etiquetaNodoActual) . ' · Conversación' : 'Conversaciones del caso' ?></strong>
                                <span><?= $chatSeleccionadoExplicito && $conversacionActual
                                    ? escaparFlujo(
                                        $chatActualInterno
                                            ? ($conversacionActual['gestor_origen'] ?: 'Gestor de origen')
                                                . ' ↔ '
                                                . ($conversacionActual['gestor_destino'] ?: 'Gestor destino')
                                            : 'Solicitante ↔ '
                                                . ($conversacionActual['gestor_destino'] ?: 'Gestor asignado')
                                    )
                                    : 'Seleccione una etapa o derivación para consultar el chat' ?></span>
                                <?php if ($chatSeleccionadoExplicito && $conversacionActual): ?>
                                    <span class="case-chat-presence" data-case-chat-presence>Consultando presencia…</span>
                                <?php endif; ?>
                            </div>
                            <button class="case-chat-close" type="button" data-case-chat-close aria-label="Cerrar conversación">×</button>
                        </header>

                        <?php if ($conversaciones): ?>
                            <?php
                                $indiceConversacionActiva = 0;
                                $tituloConversacionActiva = 'Conversación activa';

                                foreach ($conversaciones as $indiceConversacion => $conversacion) {
                                    $idConversacionIterada = (int) $conversacion['id_ticket_etapa'];
                                    $esDerivacionIterada = (string) ($conversacion['tipo_conversacion'] ?? '') === 'derivacion';
                                    $tituloIterado = $esDerivacionIterada
                                        ? 'Ticket ' . (string) ($conversacion['codigo_ticket'] ?? '')
                                        : 'Caso ' . (string) ($conversacion['codigo_caso'] ?? '')
                                            . ' · Etapa ' . (int) ($conversacion['numero_etapa'] ?? 1);

                                    if (
                                        $conversacionActual
                                        && (int) $conversacionActual['id_ticket_etapa'] === $idConversacionIterada
                                    ) {
                                        $indiceConversacionActiva = $indiceConversacion;
                                        $tituloConversacionActiva = $tituloIterado;
                                        break;
                                    }
                                }

                                $mensajesConversacionActiva = (int) ($conversacionActual['total_mensajes'] ?? 0);
                                $adjuntosConversacionActiva = (int) ($conversacionActual['total_adjuntos'] ?? 0);
                            ?>
                            <div class="case-chat-stage">
                                <span class="case-chat-stage-label">Conversación por etapa</span>
                                <details class="case-chat-picker" data-case-chat-picker>
                                    <summary aria-label="Seleccionar otra conversación" data-case-chat-stage-summary="<?= $chatSeleccionadoExplicito ? (int) ($conversacionActual['id_ticket_etapa'] ?? 0) : 0 ?>">
                                        <span class="case-chat-stage-number"><?= $chatSeleccionadoExplicito ? $indiceConversacionActiva + 1 : '···' ?></span>
                                        <span class="case-chat-stage-current">
                                            <strong><?= $chatSeleccionadoExplicito ? escaparFlujo($tituloConversacionActiva) : 'Seleccione una conversación' ?></strong>
                                            <small><?= $chatSeleccionadoExplicito ? ($mensajesConversacionActiva . ' ' . ($mensajesConversacionActiva === 1 ? 'mensaje' : 'mensajes') . ' · ' . $adjuntosConversacionActiva . ' ' . ($adjuntosConversacionActiva === 1 ? 'archivo' : 'archivos')) : (count($conversaciones) . ' conversaciones disponibles') ?></small>
                                        </span>
                                        <?php if ($chatSeleccionadoExplicito): ?><span class="case-chat-unread" data-case-chat-unread="<?= (int) ($conversacionActual['id_ticket_etapa'] ?? 0) ?>" hidden>0</span><?php endif; ?>
                                        <span class="case-chat-stage-arrow" aria-hidden="true">
                                            <svg viewBox="0 0 24 24"><path d="m7 9 5 5 5-5"/></svg>
                                        </span>
                                    </summary>
                                    <nav class="case-chat-stage-options" aria-label="Conversaciones disponibles">
                                        <?php foreach ($conversaciones as $indiceConversacion => $conversacion): ?>
                                            <?php
                                                $idConversacion = (int) $conversacion['id_ticket_etapa'];
                                                $esConversacionActual = $chatSeleccionadoExplicito && $conversacionActual
                                                    && (int) $conversacionActual['id_ticket_etapa'] === $idConversacion;
                                                $esDerivacionConversacion = (string) ($conversacion['tipo_conversacion'] ?? '') === 'derivacion';
                                                $mensajesConversacion = (int) ($conversacion['total_mensajes'] ?? 0);
                                                $adjuntosConversacion = (int) ($conversacion['total_adjuntos'] ?? 0);
                                                $urlConversacion = $rutaBaseTickets . '?' . http_build_query([
                                                    'id_ticket' => $idTicketSeleccionado,
                                                    'id_nodo' => $idNodoSeleccionado ?: $idConversacion,
                                                    'id_chat' => $idConversacion,
                                                    'panel' => 'conversacion',
                                                    'modo' => $rol === 2 ? 'mis_tickets' : null,
                                                    'bandeja' => $rol === 2 ? $bandejaGestor : null,
                                                    'vista' => $rol === 2 ? 'gestion' : null,
                                                ]);
                                                $tituloConversacion = $esDerivacionConversacion
                                                    ? 'Ticket ' . (string) ($conversacion['codigo_ticket'] ?? '')
                                                    : 'Caso ' . (string) ($conversacion['codigo_caso'] ?? '')
                                                        . ' · Etapa ' . (int) ($conversacion['numero_etapa'] ?? 1);
                                            ?>
                                            <a
                                                class="case-chat-stage-option <?= $esConversacionActual ? 'is-active' : '' ?>"
                                                href="<?= escaparFlujo($urlConversacion) ?>"
                                                <?= $rol === 2 ? 'data-flujo-nav' : '' ?>
                                                <?= $esConversacionActual ? 'aria-current="page"' : '' ?>
                                            >
                                                <span class="case-chat-stage-option-number"><?= $indiceConversacion + 1 ?></span>
                                                <span class="case-chat-stage-option-copy">
                                                    <strong><?= escaparFlujo($tituloConversacion) ?></strong>
                                                    <small><?= $mensajesConversacion ?> <?= $mensajesConversacion === 1 ? 'mensaje' : 'mensajes' ?> · <?= $adjuntosConversacion ?> <?= $adjuntosConversacion === 1 ? 'archivo' : 'archivos' ?></small>
                                                </span>
                                                <span class="case-chat-unread" data-case-chat-unread="<?= $idConversacion ?>" hidden>0</span>
                                                <span class="case-chat-stage-check" aria-hidden="true"><?= $esConversacionActual ? '✓' : '' ?></span>
                                            </a>
                                        <?php endforeach; ?>
                                    </nav>
                                </details>
                            </div>
                        <?php endif; ?>

                        <?php if (!$chatSeleccionadoExplicito): ?>
                            <div class="case-chat-selection-empty" data-case-chat-selection-empty>
                                <div><span aria-hidden="true">💬</span><strong>Seleccione una conversación</strong><small>Elija una etapa o derivación en la lista superior para consultar sus mensajes y archivos. Nada se marcará como leído hasta abrirla.</small></div>
                            </div>
                        <?php elseif ($conversacionActual): ?>
                            <details class="case-chat-files" data-case-chat-files>
                                <summary>Archivos adjuntos <span data-case-chat-files-count><?= count($adjuntos) ?></span></summary>
                                <?php if ($adjuntos): ?>
                                    <div class="case-chat-files-list" data-case-chat-files-list>
                                        <?php foreach ($adjuntos as $archivoChat): ?>
                                            <a href="descargarAdjunto.php?id=<?= (int) $archivoChat['id_adjunto'] ?>">
                                                <span><strong><?= escaparFlujo($archivoChat['nombre_original'] ?? 'Archivo adjunto') ?></strong><small><?= escaparFlujo(fechaFlujo($archivoChat['creado_en'] ?? null)) ?></small></span><span aria-hidden="true">↓</span>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?><div class="case-chat-files-empty" data-case-chat-files-list>Esta conversación no tiene archivos adjuntos.</div><?php endif; ?>
                            </details>
                        <?php endif; ?>

                        <?php if ($chatSeleccionadoExplicito): ?>
                        <div class="case-chat-timeline" data-case-chat-timeline aria-live="polite">
                            <?php if (!$conversacionActual): ?>
                                <div class="case-chat-empty">No tiene conversaciones habilitadas en este ticket.</div>
                            <?php elseif (!$eventosConversacion): ?>
                                <div class="case-chat-empty">Todavía no hay mensajes. Puede iniciar la conversación desde el campo inferior.</div>
                            <?php endif; ?>

                            <?php foreach ($eventosConversacion as $eventoConversacion): ?>
                                <?php
                                    $idAutorChat = (int) ($eventoConversacion['id_autor'] ?? 0);
                                    $nombreAutorChat = trim((string) ($eventoConversacion['autor'] ?? 'Usuario'));
                                    $rolAutorChat = (int) ($eventoConversacion['autor_rol'] ?? 0);
                                    $esEventoPropio = $idAutorChat === $idUsuario;
                                    $esAdjuntoChat = (string) ($eventoConversacion['tipo_evento'] ?? '') === 'adjunto';
                                ?>
                                <?php if (!$esAdjuntoChat): ?>
                                    <article class="case-chat-bubble <?= $esEventoPropio ? 'mine' : '' ?>" <?= $esEventoPropio ? 'data-mesa-own-message="1"' : '' ?>>
                                        <span class="case-chat-author-row">
                                            <?php if ($idAutorChat > 0): ?>
                                                <img class="case-chat-profile-image" src="imagenPerfil.php?usuario=<?= $idAutorChat ?>" alt="Foto de <?= escaparFlujo($nombreAutorChat) ?>" loading="lazy">
                                            <?php else: ?>
                                                <span class="case-chat-profile-fallback" aria-hidden="true">US</span>
                                            <?php endif; ?>
                                            <span class="case-chat-author-copy">
                                                <strong><?= escaparFlujo($nombreAutorChat !== '' ? $nombreAutorChat : 'Usuario') ?></strong>
                                                <small><?= escaparFlujo(rolChatFlujo($rolAutorChat)) ?></small>
                                            </span>
                                        </span>
                                        <p class="case-chat-text"><?= escaparFlujo($eventoConversacion['mensaje']) ?></p>
                                        <span class="case-chat-time">
                                            <?= escaparFlujo(fechaFlujo($eventoConversacion['creado_en'])) ?>
                                            <?= $esEventoPropio ? '<span class="read-mark" aria-label="Enviado">✓</span>' : '' ?>
                                        </span>
                                    </article>
                                <?php else: ?>
                                    <?php
                                        $idAdjuntoChat = (int) $eventoConversacion['id_adjunto'];
                                        $nombreAdjuntoChat = (string) $eventoConversacion['nombre_original'];
                                        $tipoAdjuntoChat = (string) ($eventoConversacion['tipo_mime'] ?? '');
                                        $esImagenChat = compatStrStartsWith($tipoAdjuntoChat, 'image/');
                                    ?>
                                    <article class="case-chat-bubble is-file <?= $esEventoPropio ? 'mine' : '' ?>" <?= $esEventoPropio ? 'data-mesa-own-message="1"' : '' ?>>
                                        <span class="case-chat-author-row">
                                            <?php if ($idAutorChat > 0): ?>
                                                <img class="case-chat-profile-image" src="imagenPerfil.php?usuario=<?= $idAutorChat ?>" alt="Foto de <?= escaparFlujo($nombreAutorChat) ?>" loading="lazy">
                                            <?php else: ?>
                                                <span class="case-chat-profile-fallback" aria-hidden="true">US</span>
                                            <?php endif; ?>
                                            <span class="case-chat-author-copy">
                                                <strong><?= escaparFlujo($nombreAutorChat !== '' ? $nombreAutorChat : 'Usuario') ?></strong>
                                                <small><?= escaparFlujo(rolChatFlujo($rolAutorChat)) ?></small>
                                            </span>
                                        </span>
                                        <a class="case-chat-attachment" href="descargarAdjunto.php?id=<?= $idAdjuntoChat ?>" title="Descargar <?= escaparFlujo($nombreAdjuntoChat) ?>">
                                            <?php if ($esImagenChat): ?>
                                                <img class="case-chat-image" src="descargarAdjunto.php?id=<?= $idAdjuntoChat ?>&amp;inline=1" alt="Vista previa de <?= escaparFlujo($nombreAdjuntoChat) ?>" loading="lazy">
                                            <?php endif; ?>
                                            <span class="case-chat-file-card">
                                                <span class="case-chat-file-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7Z"/><path d="M14 3v6h5M10 14h6M10 17h5"/></svg></span>
                                                <span class="case-chat-file-copy">
                                                    <strong><?= escaparFlujo($nombreAdjuntoChat) ?></strong>
                                                    <span><?= escaparFlujo(flujoFormatoTamanoArchivo((int) ($eventoConversacion['tamano'] ?? 0))) ?> · Pulse para descargar</span>
                                                </span>
                                                <span class="case-chat-download" aria-hidden="true">↓</span>
                                            </span>
                                        </a>
                                        <span class="case-chat-time">
                                            <?= escaparFlujo(fechaFlujo($eventoConversacion['creado_en'])) ?>
                                            <?= $esEventoPropio ? '<span class="read-mark" aria-label="Enviado">✓</span>' : '' ?>
                                        </span>
                                    </article>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>

                        <?php if ($puedeEscribir && $conversacionActual): ?>
                            <form class="case-chat-compose" method="post" enctype="multipart/form-data" data-case-chat-compose>
                                <input type="hidden" name="csrf_token" value="<?= escaparFlujo($_SESSION['csrf_token']) ?>">
                                <input type="hidden" name="accion" value="enviar_mensaje">
                                <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                <input type="hidden" name="id_ticket_etapa" value="<?= (int) $conversacionActual['id_ticket_etapa'] ?>">
                                <div class="case-chat-file-status" data-case-chat-file-status aria-live="polite"></div>
                                <div class="case-chat-compose-row">
                                    <input class="case-chat-file-input" id="adjuntos_chat" type="file" name="adjuntos[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.txt,.csv,.zip,.doc,.docx,.xls,.xlsx" data-case-chat-file-input>
                                    <label class="case-chat-attach" for="adjuntos_chat" title="Adjuntar archivos" aria-label="Adjuntar archivos">
                                        <svg viewBox="0 0 24 24"><path d="m20.5 11.5-8.8 8.8a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 1 1-2.8-2.8l8.5-8.5"/></svg>
                                    </label>
                                    <textarea id="mensaje_chat" name="mensaje" maxlength="10000" rows="1" placeholder="Escriba un mensaje" aria-label="Mensaje"></textarea>
                                    <button class="case-chat-send" type="submit" title="Enviar mensaje" aria-label="Enviar mensaje">
                                        <svg viewBox="0 0 24 24"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                                    </button>
                                </div>
                            </form>
                        <?php elseif ($conversacionActual): ?>
                            <p class="case-chat-readonly"><?= $rol === 1
                                ? 'Administración puede auditar esta conversación, pero no responder.'
                                : 'Esta conversación finalizó y permanece disponible para consulta.' ?></p>
                        <?php endif; ?>
                        <?php endif; ?>
                    </section>
                </div>
            </div>
        <?php if ($rol === 2): ?>
        </section>
        <?php else: ?>
        </dialog>
        <?php endif; ?>
        <?php endif; ?>
        <?php if ($rol === 2): ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>
</main>
<script data-flujo-runtime>
    (() => {
        window.__MESA_GESTOR_BANDEJAS_MODAL_VERSION__ = '2026-08-10.2';
        window.__MESA_DERIVACION_CATALOGO_VERSION__ = '2026-08-10.3';

        const entradaBusquedaGestor = document.getElementById('buscar-casos-gestor');
        const selectorEstadoGestor = document.getElementById('estado-casos-gestor');
        const botonLimpiarGestor = document.getElementById('limpiar-filtro-gestor');
        const contadorGestor = document.getElementById('contador-casos-gestor');
        const esBandejaDerivaciones = <?= in_array($bandejaGestor, ['derivaciones', 'pendientes', 'derivaciones_cerradas'], true) ? 'true' : 'false' ?>;
        const filaSinResultadosGestor = document.getElementById('sin-resultados-gestor');
        const filasGestor = Array.from(document.querySelectorAll('[data-manager-case-row]'));
        let tareaFiltroGestor = 0;

        const normalizarTextoGestor = (valor) => String(valor || '')
            .toLocaleLowerCase('es')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .trim();

        const guardarFiltrosGestor = () => {
            if (window.top !== window.self) return;
            if (!window.history || typeof window.history.replaceState !== 'function') return;

            const url = new URL(window.location.href);
            const busqueda = entradaBusquedaGestor?.value.trim() || '';
            const estado = selectorEstadoGestor?.value || 'todos';

            if (busqueda) url.searchParams.set('buscar', busqueda);
            else url.searchParams.delete('buscar');

            if (estado !== 'todos') url.searchParams.set('estado_busqueda', estado);
            else url.searchParams.delete('estado_busqueda');

            window.history.replaceState({}, '', url.toString());
        };

        const aplicarFiltrosGestor = (persistir = false) => {
            if (!entradaBusquedaGestor || !selectorEstadoGestor || !filasGestor.length) return;

            const texto = normalizarTextoGestor(entradaBusquedaGestor.value);
            const estado = selectorEstadoGestor.value || 'todos';
            let visibles = 0;

            filasGestor.forEach((fila) => {
                const coincideTexto = !texto || normalizarTextoGestor(fila.textContent).includes(texto);
                const coincideEstado = estado === 'todos' || fila.dataset.managerCaseState === estado;
                const visible = coincideTexto && coincideEstado;
                fila.hidden = !visible;
                if (visible) visibles += 1;
            });

            if (contadorGestor) {
                contadorGestor.textContent = esBandejaDerivaciones
                    ? (visibles === 1 ? '1 derivación encontrada' : `${visibles} derivaciones encontradas`)
                    : (visibles === 1 ? '1 caso encontrado' : `${visibles} casos encontrados`);
            }
            if (filaSinResultadosGestor) filaSinResultadosGestor.hidden = visibles !== 0;
            if (botonLimpiarGestor) botonLimpiarGestor.hidden = entradaBusquedaGestor.value.length === 0;
            if (persistir) guardarFiltrosGestor();
        };

        if (entradaBusquedaGestor && selectorEstadoGestor && filasGestor.length) {
            entradaBusquedaGestor.addEventListener('input', () => {
                if (tareaFiltroGestor) window.cancelAnimationFrame(tareaFiltroGestor);
                tareaFiltroGestor = window.requestAnimationFrame(() => {
                    tareaFiltroGestor = 0;
                    aplicarFiltrosGestor(true);
                });
            });
            selectorEstadoGestor.addEventListener('change', () => aplicarFiltrosGestor(true));
            botonLimpiarGestor?.addEventListener('click', () => {
                entradaBusquedaGestor.value = '';
                aplicarFiltrosGestor(true);
                entradaBusquedaGestor.focus();
            });
            document.querySelectorAll('[data-manager-case-view]').forEach((enlace) => {
                enlace.addEventListener('click', () => {
                    const url = new URL(enlace.dataset.mesaRoute || enlace.href, window.location.href);
                    const busqueda = entradaBusquedaGestor.value.trim();
                    const estado = selectorEstadoGestor.value || 'todos';

                    if (busqueda) url.searchParams.set('buscar', busqueda);
                    else url.searchParams.delete('buscar');

                    if (estado !== 'todos') url.searchParams.set('estado_busqueda', estado);
                    else url.searchParams.delete('estado_busqueda');

                    enlace.dataset.mesaRoute = url.toString();
                    enlace.href = url.toString();
                });
            });
            aplicarFiltrosGestor(false);
        }

        const finalRatingDialog = document.getElementById('finalRatingDialog');

        if (finalRatingDialog) {
            document.querySelectorAll('[data-open-final-rating]').forEach((button) => {
                button.addEventListener('click', () => {
                    if (!finalRatingDialog.open) finalRatingDialog.showModal();
                });
            });

            finalRatingDialog.querySelector('[data-close-final-rating]')
                ?.addEventListener('click', () => finalRatingDialog.close());

            finalRatingDialog.querySelector('[data-final-rating-form]')
                ?.addEventListener('submit', (event) => {
                    if (!window.confirm(
                        '¿Confirma la encuesta única del servicio solicitado y el cierre definitivo de este ticket anterior?'
                    )) {
                        event.preventDefault();
                    }
                });

            if (
                finalRatingDialog.dataset.autoOpen === 'true'
                && !finalRatingDialog.open
            ) {
                finalRatingDialog.showModal();
            }
        }

        const tree = document.querySelector('[data-case-tree]');

        if (tree) {
            const branches = Array.from(tree.querySelectorAll('[data-case-branch]'));
            const storageKey = `mesa-servicio-${tree.dataset.treeKey || 'arbol'}`;
            const treeCard = tree.closest('.card');
            const expandButton = treeCard?.querySelector('[data-tree-expand]');
            const collapseButton = treeCard?.querySelector('[data-tree-collapse]');

            const updateTreeControls = () => {
                const hasBranches = branches.length > 0;
                const allExpanded = hasBranches && branches.every((branch) => branch.open);
                const allCollapsed = hasBranches && branches.every((branch) => !branch.open);

                if (expandButton) expandButton.disabled = !hasBranches || allExpanded;
                if (collapseButton) collapseButton.disabled = !hasBranches || allCollapsed;
            };

            try {
                const saved = JSON.parse(window.localStorage.getItem(storageKey) || '{}');

                branches.forEach((branch) => {
                    const id = branch.dataset.caseId || '';

                    if (branch.dataset.selectedPath !== 'true' && Object.prototype.hasOwnProperty.call(saved, id)) {
                        branch.open = Boolean(saved[id]);
                    }
                });
            } catch (error) {
                /* El árbol funciona aunque el navegador bloquee localStorage. */
            }

            const persist = () => {
                const state = {};
                branches.forEach((branch) => {
                    state[branch.dataset.caseId || ''] = branch.open;
                });

                try {
                    window.localStorage.setItem(storageKey, JSON.stringify(state));
                } catch (error) {
                    /* Sin persistencia, el control de ramas sigue disponible. */
                }
            };

            branches.forEach((branch) => branch.addEventListener('toggle', () => {
                persist();
                updateTreeControls();
            }));

            tree.querySelectorAll('.case-open').forEach((link) => {
                link.addEventListener('click', (event) => event.stopPropagation());
            });

            expandButton?.addEventListener('click', () => {
                branches.forEach((branch) => { branch.open = true; });
                persist();
                updateTreeControls();
            });

            collapseButton?.addEventListener('click', () => {
                branches.forEach((branch) => { branch.open = false; });
                persist();
                updateTreeControls();
            });

            updateTreeControls();
        }

        const dialog = document.getElementById('caseDialog');
        const standaloneCasePage = document.querySelector('.case-detail-page');

        // Tanto el resumen como la gestión son páginas independientes. La
        // navegación parcial no reemplaza el body, por lo que hay que retirar
        // siempre las clases de bloqueo que pudiera dejar una vista anterior.
        if (standaloneCasePage) {
            document.body.classList.remove('case-modal-open', 'manager-ticket-modal-open');
        }

        // El resumen no contiene caseDialog y antes salía de este módulo sin
        // instalar la protección de rueda. Se registra aquí específicamente
        // para esa pantalla; la gestión conserva el controlador más completo.
        if (standaloneCasePage && !dialog) {
            const summaryWheel = (event) => {
                if (event.ctrlKey || !standaloneCasePage.contains(event.target)) return;

                const multiplier = event.deltaMode === WheelEvent.DOM_DELTA_LINE
                    ? 18
                    : (event.deltaMode === WheelEvent.DOM_DELTA_PAGE ? window.innerHeight : 1);
                const delta = event.deltaY * multiplier;
                if (Math.abs(delta) < 0.01) return;

                const origin = event.target instanceof Element ? event.target : null;
                const nested = origin?.closest('textarea, select, .derivation-service-menu');
                if (nested instanceof HTMLElement) {
                    const nestedMaximum = nested.scrollHeight - nested.clientHeight;
                    const nestedCanMove = nestedMaximum > 1
                        && (delta < 0 ? nested.scrollTop > 0 : nested.scrollTop < nestedMaximum - 1);
                    if (nestedCanMove) return;
                }

                const scroller = document.scrollingElement || document.documentElement;
                const maximum = scroller.scrollHeight - scroller.clientHeight;
                const canMove = maximum > 1
                    && (delta < 0 ? scroller.scrollTop > 0 : scroller.scrollTop < maximum - 1);
                if (!canMove) return;

                event.preventDefault();
                scroller.scrollTop += delta;
            };

            document.addEventListener('wheel', summaryWheel, {capture: true, passive: false});
            window.addEventListener('mesa:flujo:dispose', () => {
                document.removeEventListener('wheel', summaryWheel, {capture: true});
            }, {once: true});
        }

        if (!dialog) {
            return;
        }

        const embeddedCaseDetail = dialog.dataset.embedded === 'true';
        const caseDetailIsOpen = () => embeddedCaseDetail || dialog.open === true;

        // La navegación parcial reemplaza el contenido principal, pero no las
        // clases del body. Al entrar desde el modal anterior podían quedar estas
        // clases activas y bloquear la rueda aunque la barra siguiera visible.
        if (embeddedCaseDetail) {
            document.body.classList.remove('case-modal-open', 'manager-ticket-modal-open');
        }

        const tabs = Array.from(dialog.querySelectorAll('[data-case-tab]'));
        const panels = Array.from(dialog.querySelectorAll('[data-case-panel]'));
        const chatWidget = dialog.querySelector('[data-case-chat-widget]');
        const chatLauncher = dialog.querySelector('[data-case-chat-open]');
        const chatClose = chatWidget?.querySelector('[data-case-chat-close]');
        const chatPanel = chatWidget?.querySelector('.case-chat-panel');
        const chatTimeline = chatWidget?.querySelector('[data-case-chat-timeline]');
        const chatForm = chatWidget?.querySelector('[data-case-chat-compose]');
        const chatTextarea = chatForm?.querySelector('textarea');
        const chatFileInput = chatForm?.querySelector('[data-case-chat-file-input]');
        const chatFileStatus = chatForm?.querySelector('[data-case-chat-file-status]');
        const chatPresence = chatWidget?.querySelector('[data-case-chat-presence]');
        const chatFiles = chatWidget?.querySelector('[data-case-chat-files]');
        const chatFilesCount = chatWidget?.querySelector('[data-case-chat-files-count]');
        const chatUnreadTotal = dialog.querySelector('[data-case-chat-unread-total]');
        const chatPicker = chatWidget?.querySelector('[data-case-chat-picker]');
        const chatHasSelection = chatWidget?.dataset.chatSelected === 'true';
        let caseChatTimer = null;
        let caseChatPresenceTimer = null;
        let caseChatCountTimer = null;
        let caseChatRefreshing = false;
        let caseChatRevisionChecking = false;
        let caseChatCountsRefreshing = false;
        let caseChatSignature = '';
        let caseChatRevision = '';
        let caseChatLastActivityAt = Date.now();
        const CASE_CHAT_POLL_FAST_MS = 2000;
        const CASE_CHAT_POLL_IDLE_MS = 5000;
        const CASE_CHAT_ACTIVITY_WINDOW_MS = 60000;
        const CASE_CHAT_POLL_JITTER_MS = 250;

        const embeddedPage = embeddedCaseDetail ? dialog.closest('.case-detail-page') : null;
        const nestedWheelSelector = [
            '[data-case-chat-timeline]',
            '.case-chat-files-list',
            '.case-chat-stage-options',
            '.derivation-service-menu',
            'textarea',
            'select'
        ].join(',');

        const wheelDeltaPixels = (event) => {
            if (event.deltaMode === WheelEvent.DOM_DELTA_LINE) return event.deltaY * 18;
            if (event.deltaMode === WheelEvent.DOM_DELTA_PAGE) return event.deltaY * window.innerHeight;
            return event.deltaY;
        };

        const canWheelScroll = (element, delta) => {
            if (!(element instanceof HTMLElement) || Math.abs(delta) < 0.01) return false;
            const maximum = element.scrollHeight - element.clientHeight;
            if (maximum <= 1) return false;
            return delta < 0 ? element.scrollTop > 0 : element.scrollTop < maximum - 1;
        };

        const resolvePageScroller = () => {
            let current = embeddedPage?.parentElement || null;
            while (current && current !== document.body && current !== document.documentElement) {
                const overflowY = window.getComputedStyle(current).overflowY;
                if (/(auto|scroll)/.test(overflowY) && current.scrollHeight > current.clientHeight + 1) {
                    return current;
                }
                current = current.parentElement;
            }
            return document.scrollingElement || document.documentElement;
        };

        const forwardEmbeddedWheel = (event) => {
            if (!embeddedPage || event.ctrlKey || !embeddedPage.contains(event.target)) return;

            const delta = wheelDeltaPixels(event);
            if (Math.abs(delta) < 0.01) return;

            const origin = event.target instanceof Element ? event.target : null;
            const nestedScroller = origin?.closest(nestedWheelSelector);
            if (nestedScroller && embeddedPage.contains(nestedScroller) && canWheelScroll(nestedScroller, delta)) {
                return;
            }

            const pageScroller = resolvePageScroller();
            if (!canWheelScroll(pageScroller, delta)) return;

            event.preventDefault();
            pageScroller.scrollTop += delta;
        };

        if (embeddedPage) {
            document.addEventListener('wheel', forwardEmbeddedWheel, {capture: true, passive: false});
        }

        window.addEventListener('mesa:flujo:dispose', () => {
            window.clearTimeout(caseChatTimer);
            window.clearInterval(caseChatPresenceTimer);
            window.clearInterval(caseChatCountTimer);
            caseChatTimer = null;
            caseChatPresenceTimer = null;
            caseChatCountTimer = null;
            document.removeEventListener('wheel', forwardEmbeddedWheel, {capture: true});
        }, {once: true});

        const resizeChatTextarea = () => {
            if (!chatTextarea) return;
            chatTextarea.style.height = '37px';
            chatTextarea.style.height = `${Math.min(chatTextarea.scrollHeight, 108)}px`;
        };

        const openCaseChat = () => {
            if (!chatWidget || !chatPanel) return;
            chatWidget.classList.add('is-open');
            chatPanel.setAttribute('aria-hidden', 'false');
            chatLauncher?.setAttribute('aria-expanded', 'true');
            if (chatLauncher) chatLauncher.hidden = true;
            if (!chatHasSelection && chatPicker) chatPicker.open = true;
            caseChatRevision = '';
            caseChatLastActivityAt = Date.now();
            void refreshCaseChat(true);
            window.clearTimeout(caseChatTimer);
            window.clearInterval(caseChatPresenceTimer);
            // Se consulta una huella ligera y solo se descarga el hilo cuando
            // realmente cambió. Con actividad reciente se revisa cada 2 s,
            // igual que el módulo Mensajes; en inactividad baja a 5 s.
            caseChatTimer = null;
            scheduleCaseChatRevision();
            caseChatPresenceTimer = window.setInterval(() => void refreshCaseChat(false), 30000);
            window.requestAnimationFrame(() => {
                if (chatTimeline) chatTimeline.scrollTop = chatTimeline.scrollHeight;
                (chatTextarea || chatClose)?.focus();
            });
        };

        const closeCaseChat = () => {
            if (!chatWidget || !chatPanel) return;
            chatWidget.classList.remove('is-open');
            chatPanel.setAttribute('aria-hidden', 'true');
            chatLauncher?.setAttribute('aria-expanded', 'false');
            if (chatLauncher) chatLauncher.hidden = false;
            window.clearTimeout(caseChatTimer);
            window.clearInterval(caseChatPresenceTimer);
            caseChatTimer = null;
            caseChatPresenceTimer = null;
            chatLauncher?.focus();
        };

        chatLauncher?.addEventListener('click', openCaseChat);
        chatClose?.addEventListener('click', closeCaseChat);
        chatTextarea?.addEventListener('input', resizeChatTextarea);
        chatTextarea?.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                chatForm?.requestSubmit();
            }
        });
        chatFileInput?.addEventListener('change', () => {
            if (!chatFileStatus) return;
            const names = Array.from(chatFileInput.files || []).map((file) => file.name);
            chatFileStatus.textContent = names.length
                ? `${names.length} archivo(s): ${names.join(', ')}`
                : '';
        });
        const caseTicketId = Number(chatWidget?.dataset.ticketId || 0);
        const caseStageId = chatHasSelection
            ? Number(chatWidget?.dataset.stageId || 0)
            : 0;

        const caseChatApi = async (url, options = {}) => {
            const response = await fetch(url, {
                cache: 'no-store',
                credentials: 'same-origin',
                ...options
            });
            const data = await response.json().catch(() => ({}));
            if (!response.ok || data.ok !== true) {
                throw new Error(data.message || 'No fue posible actualizar la conversación.');
            }
            return data;
        };

        const renderCaseChatCounts = (counts) => {
            const byStage = new Map();
            let total = 0;
            (counts || []).forEach((item) => {
                const stage = Number(item.id_ticket_etapa) || 0;
                const unread = Math.max(0, Number(item.mensajes_no_leidos) || 0);
                if (stage > 0) byStage.set(stage, unread);
                total += unread;
            });

            chatWidget?.querySelectorAll('[data-case-chat-unread]').forEach((badge) => {
                const unread = byStage.get(Number(badge.dataset.caseChatUnread) || 0) || 0;
                badge.textContent = unread > 99 ? '99+' : String(unread);
                badge.hidden = unread < 1;
                badge.title = unread === 1 ? '1 mensaje nuevo' : `${unread} mensajes nuevos`;
                badge.setAttribute('aria-label', badge.title);
            });

            if (chatUnreadTotal) {
                chatUnreadTotal.textContent = total > 99 ? '99+' : String(total);
                chatUnreadTotal.hidden = total < 1;
                chatUnreadTotal.title = total === 1
                    ? '1 mensaje nuevo en las conversaciones del caso'
                    : `${total} mensajes nuevos en las conversaciones del caso`;
                chatUnreadTotal.setAttribute('aria-label', chatUnreadTotal.title);
            }
        };

        const refreshCaseChatCounts = async () => {
            if (
                document.visibilityState !== 'visible'
                || !caseDetailIsOpen()
                || !caseTicketId
                || caseChatCountsRefreshing
            ) return;
            caseChatCountsRefreshing = true;
            try {
                const params = new URLSearchParams({
                    action: 'node_counts',
                    id_ticket: String(caseTicketId),
                    _: String(Date.now())
                });
                const data = await caseChatApi(`mensajesApi.php?${params}`);
                renderCaseChatCounts(data.conteos || []);
            } catch (_) {
            } finally {
                caseChatCountsRefreshing = false;
            }
        };

        const caseChatTime = (value) => {
            const date = new Date(String(value || '').replace(' ', 'T'));
            return Number.isNaN(date.getTime())
                ? String(value || '')
                : date.toLocaleString('es-CO', {day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit'});
        };

        const caseChatPresenceText = (presence) => {
            if (presence?.en_linea) return 'En línea';
            if (!presence?.ultima_actividad) return 'Última conexión no disponible';
            const date = new Date(presence.ultima_actividad.replace(' ', 'T'));
            if (Number.isNaN(date.getTime())) return 'Última conexión no disponible';
            const now = new Date();
            const time = date.toLocaleTimeString('es-CO', {hour:'2-digit', minute:'2-digit'});
            const sameDay = date.toDateString() === now.toDateString();
            return sameDay
                ? `Última vez hoy a las ${time}`
                : `Última vez el ${date.toLocaleDateString('es-CO')} a las ${time}`;
        };

        const createCaseChatAuthor = (event) => {
            const row = document.createElement('span');
            row.className = 'case-chat-author-row';
            if (event.avatar) {
                const image = document.createElement('img');
                image.className = 'case-chat-profile-image';
                image.src = event.avatar;
                image.alt = `Foto de ${event.autor || 'usuario'}`;
                row.append(image);
            } else {
                const fallback = document.createElement('span');
                fallback.className = 'case-chat-profile-fallback';
                fallback.textContent = 'US';
                row.append(fallback);
            }
            const copy = document.createElement('span');
            copy.className = 'case-chat-author-copy';
            const name = document.createElement('strong');
            name.textContent = event.autor || 'Usuario';
            const role = document.createElement('small');
            role.textContent = event.autor_rol || 'Usuario';
            copy.append(name, role);
            row.append(copy);
            return row;
        };

        const createCaseChatEvent = (event) => {
            const article = document.createElement('article');
            article.className = `case-chat-bubble${event.tipo === 'adjunto' ? ' is-file' : ''}${event.propio ? ' mine' : ''}`;
            if (event.propio) article.dataset.mesaOwnMessage = '1';
            article.append(createCaseChatAuthor(event));
            if (event.tipo === 'adjunto') {
                const link = document.createElement('a');
                link.className = 'case-chat-attachment';
                link.href = event.url;
                link.target = '_blank';
                link.rel = 'noopener';
                if (event.preview) {
                    const image = document.createElement('img');
                    image.className = 'case-chat-image';
                    image.src = event.preview;
                    image.alt = event.nombre || 'Archivo adjunto';
                    image.loading = 'lazy';
                    link.append(image);
                }
                const card = document.createElement('span');
                card.className = 'case-chat-file-card';
                const icon = document.createElement('span');
                icon.className = 'case-chat-file-icon';
                icon.textContent = 'DOC';
                const copy = document.createElement('span');
                copy.className = 'case-chat-file-copy';
                const name = document.createElement('strong');
                name.textContent = event.nombre || 'Archivo';
                const mime = document.createElement('span');
                mime.textContent = event.mime || 'Pulse para descargar';
                copy.append(name, mime);
                const down = document.createElement('span');
                down.className = 'case-chat-download';
                down.textContent = '↓';
                card.append(icon, copy, down);
                link.append(card);
                article.append(link);
            } else {
                const text = document.createElement('p');
                text.className = 'case-chat-text';
                text.textContent = event.mensaje || '';
                article.append(text);
            }
            const time = document.createElement('span');
            time.className = 'case-chat-time';
            time.append(document.createTextNode(caseChatTime(event.creado_en)));
            if (event.propio && event.tipo === 'mensaje') {
                const state = event.estado_envio || 'enviado';
                const mark = document.createElement('span');
                mark.className = `read-mark${state === 'leido' ? ' is-read' : ''}`;
                mark.textContent = state === 'pendiente' ? '◷' : (state === 'enviado' ? '✓' : '✓✓');
                mark.title = state === 'pendiente' ? 'Enviando' : (state === 'leido' ? 'Leído' : (state === 'entregado' ? 'Entregado' : 'Enviado'));
                mark.setAttribute('aria-label', mark.title);
                time.append(mark);
            }
            article.append(time);
            return article;
        };

        const renderCaseChatFiles = (files) => {
            if (!chatFiles || !chatFilesCount) return;
            chatFilesCount.textContent = String(files.length);
            const box = document.createElement('div');
            box.dataset.caseChatFilesList = '';
            if (!files.length) {
                box.className = 'case-chat-files-empty';
                box.textContent = 'Esta conversación no tiene archivos adjuntos.';
            } else {
                box.className = 'case-chat-files-list';
                files.forEach((file) => {
                    const link = document.createElement('a');
                    link.href = file.url;
                    link.target = '_blank';
                    link.rel = 'noopener';
                    const copy = document.createElement('span');
                    const name = document.createElement('strong');
                    name.textContent = file.nombre || 'Archivo';
                    const date = document.createElement('small');
                    date.textContent = caseChatTime(file.creado_en);
                    copy.append(name, date);
                    const down = document.createElement('span');
                    down.textContent = '↓';
                    link.append(copy, down);
                    box.append(link);
                });
            }
            chatFiles.querySelector('[data-case-chat-files-list]')?.replaceWith(box);
        };

        const refreshCaseChat = async (forceBottom = false) => {
            if (
                document.visibilityState !== 'visible'
                || !chatWidget?.classList.contains('is-open')
                || !caseTicketId
                || !caseStageId
                || caseChatRefreshing
            ) return;
            caseChatRefreshing = true;
            try {
                const markRead = document.visibilityState === 'visible' ? '1' : '0';
                const params = new URLSearchParams({
                    action: 'node_thread',
                    id_ticket: String(caseTicketId),
                    id_ticket_etapa: String(caseStageId),
                    mark_read: markRead,
                    _: String(Date.now())
                });
                const data = await caseChatApi(`mensajesApi.php?${params}`);
                if (data.revision) caseChatRevision = data.revision;
                const hilo = data.hilo || {};
                if (chatForm) {
                    const enabled = Boolean(hilo.ticket?.puede_escribir);
                    chatForm.classList.toggle('is-disabled', !enabled);
                    chatForm.querySelectorAll('textarea,input,button').forEach((control) => {
                        control.disabled = !enabled;
                    });
                }
                const presence = hilo.contraparte?.presencia || {};
                if (chatPresence) {
                    chatPresence.textContent = caseChatPresenceText(presence);
                    chatPresence.classList.toggle('is-online', Boolean(presence.en_linea));
                }
                const events = hilo.eventos || [];
                const signature = events.map((item) => `${item.tipo}:${item.id_evento}:${item.estado_envio || ''}`).join('|');
                if (signature !== caseChatSignature && chatTimeline) {
                    caseChatLastActivityAt = Date.now();
                    const previousTop = chatTimeline.scrollTop;
                    const nearBottom = forceBottom || chatTimeline.scrollHeight - previousTop - chatTimeline.clientHeight < 90;
                    chatTimeline.replaceChildren();
                    if (!events.length) {
                        const empty = document.createElement('div');
                        empty.className = 'case-chat-empty';
                        empty.textContent = 'Todavía no hay mensajes. Puede iniciar la conversación desde el campo inferior.';
                        chatTimeline.append(empty);
                    } else {
                        events.forEach((item) => chatTimeline.append(createCaseChatEvent(item)));
                    }
                    caseChatSignature = signature;
                    requestAnimationFrame(() => {
                        chatTimeline.scrollTop = nearBottom ? chatTimeline.scrollHeight : previousTop;
                    });
                }
                renderCaseChatFiles(hilo.adjuntos || []);
                void refreshCaseChatCounts();
            } catch (error) {
                if (chatFileStatus) chatFileStatus.textContent = error instanceof Error ? error.message : 'No fue posible actualizar el chat.';
            } finally {
                caseChatRefreshing = false;
            }
        };

        const checkCaseChatRevision = async () => {
            if (
                document.visibilityState !== 'visible'
                || !chatWidget?.classList.contains('is-open')
                || !caseTicketId
                || !caseStageId
                || caseChatRevisionChecking
            ) return;

            caseChatRevisionChecking = true;
            try {
                const params = new URLSearchParams({
                    action: 'node_revision',
                    id_ticket: String(caseTicketId),
                    id_ticket_etapa: String(caseStageId),
                    _: String(Date.now())
                });
                const data = await caseChatApi(`mensajesApi.php?${params}`);
                if (!data.revision) return;
                if (caseChatRevision === '') {
                    caseChatRevision = data.revision;
                } else if (caseChatRevision !== data.revision) {
                    caseChatRevision = data.revision;
                    await refreshCaseChat(false);
                }
            } catch (_) {
                // El refresco completo al recuperar foco mantiene la
                // conversación disponible ante un fallo transitorio.
            } finally {
                caseChatRevisionChecking = false;
            }
        };

        const scheduleCaseChatRevision = () => {
            if (caseChatTimer !== null) {
                window.clearTimeout(caseChatTimer);
                caseChatTimer = null;
            }
            if (
                document.visibilityState !== 'visible'
                || !chatWidget?.classList.contains('is-open')
                || !caseTicketId
                || !caseStageId
            ) return;

            const active = Date.now() - caseChatLastActivityAt <= CASE_CHAT_ACTIVITY_WINDOW_MS;
            const baseDelay = active ? CASE_CHAT_POLL_FAST_MS : CASE_CHAT_POLL_IDLE_MS;
            const jitter = Math.floor(Math.random() * (CASE_CHAT_POLL_JITTER_MS * 2 + 1))
                - CASE_CHAT_POLL_JITTER_MS;
            caseChatTimer = window.setTimeout(async () => {
                await checkCaseChatRevision();
                scheduleCaseChatRevision();
            }, Math.max(1000, baseDelay + jitter));
        };

        chatForm?.addEventListener('submit', async (event) => {
            event.preventDefault();

            if (chatForm.dataset.sending === 'true') return;

            const message = (chatTextarea?.value || '').trim();
            const files = Array.from(chatFileInput?.files || []);

            if (!message && files.length === 0) {
                chatTextarea?.focus();
                return;
            }

            const data = new FormData(chatForm);
            data.set('action', 'node_send');
            const pending = createCaseChatEvent({
                tipo: 'mensaje',
                propio: true,
                autor: <?= json_encode($nombreUsuario, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
                autor_rol: <?= json_encode(rolChatFlujo($rol), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
                avatar: 'imagenPerfil.php?usuario=<?= (int) $idUsuario ?>',
                mensaje: message || `Enviando ${files.length} archivo(s)…`,
                creado_en: new Date().toISOString(),
                estado_envio: 'pendiente'
            });
            pending.classList.add('is-pending');
            chatTimeline?.querySelector('.case-chat-empty')?.remove();
            chatTimeline?.append(pending);
            if (chatTimeline) chatTimeline.scrollTop = chatTimeline.scrollHeight;
            const sendButton = chatForm.querySelector('.case-chat-send');
            chatForm.dataset.sending = 'true';

            if (sendButton) sendButton.disabled = true;
            if (chatTextarea) {
                chatTextarea.value = '';
                resizeChatTextarea();
            }
            if (chatFileStatus) chatFileStatus.textContent = 'Enviando…';

            try {
                await caseChatApi('mensajesApi.php', {method: 'POST', body: data});
                chatForm.reset();
                if (chatFileStatus) chatFileStatus.textContent = '';
                await refreshCaseChat(true);
            } catch (error) {
                pending.remove();
                if (chatTextarea && chatTextarea.value === '') {
                    chatTextarea.value = message;
                    resizeChatTextarea();
                }
                if (chatFileStatus) {
                    chatFileStatus.textContent = error instanceof Error
                        ? error.message
                        : 'No fue posible enviar el mensaje.';
                }
            } finally {
                chatForm.dataset.sending = 'false';
                if (sendButton) sendButton.disabled = false;
                chatTextarea?.focus();
            }
        });

        window.addEventListener('focus', () => void refreshCaseChat(false));
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
                void refreshCaseChat(false);
                void refreshCaseChatCounts();
                scheduleCaseChatRevision();
            } else if (caseChatTimer !== null) {
                window.clearTimeout(caseChatTimer);
                caseChatTimer = null;
            }
        });
        void refreshCaseChatCounts();
        caseChatCountTimer = window.setInterval(() => void refreshCaseChatCounts(), 10000);

        const activatePanel = (name, reveal = false) => {
            const validName = tabs.some((tab) => tab.dataset.caseTab === name)
                ? name
                : 'estructura';

            tabs.forEach((tab) => {
                const active = tab.dataset.caseTab === validName;
                tab.classList.toggle('active', active);
                tab.setAttribute('aria-selected', active ? 'true' : 'false');
            });

            panels.forEach((panel) => {
                const active = panel.dataset.casePanel === validName;
                panel.hidden = !active;
                panel.classList.remove('is-panel-entering');

                if (active && reveal) {
                    void panel.offsetWidth;
                    panel.classList.add('is-panel-entering');
                }
            });

            if (reveal) {
                window.requestAnimationFrame(() => {
                    dialog.querySelector('[data-case-panel="' + validName + '"]')?.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                });
            }
        };

        tabs.forEach((tab) => {
            tab.addEventListener('click', () => activatePanel(tab.dataset.caseTab || 'estructura', true));
        });

        const structureSolutionDialog = document.getElementById('caseStructureSolutionDialog');
        const structureSolutionDragHandle = structureSolutionDialog?.querySelector('[data-case-solution-drag]');
        const structureSolutionTitle = document.getElementById('caseStructureSolutionTitle');
        const structureSolutionContext = document.getElementById('caseStructureSolutionContext');
        const structureSolutionName = document.getElementById('caseStructureSolutionName');
        const structureSolutionDetail = document.getElementById('caseStructureSolutionDetail');
        const openStructureSolution = (trigger) => {
            if (!structureSolutionDialog) return;
            if (structureSolutionTitle) {
                structureSolutionTitle.textContent = trigger.dataset.solutionTitle || 'Solución registrada';
            }
            if (structureSolutionContext) {
                structureSolutionContext.textContent = trigger.dataset.solutionContext || '';
            }
            if (structureSolutionName) {
                structureSolutionName.textContent = trigger.dataset.solutionName || 'Sin solución registrada';
            }
            if (structureSolutionDetail) {
                structureSolutionDetail.textContent = trigger.dataset.solutionDetail
                    || 'El gestor no dejó una descripción adicional.';
            }
            if (typeof structureSolutionDialog.show === 'function') {
                if (!structureSolutionDialog.open) structureSolutionDialog.show();
            } else {
                structureSolutionDialog.setAttribute('open', '');
            }
        };

        let structureSolutionDragState = null;
        structureSolutionDragHandle?.addEventListener('pointerdown', (event) => {
            const origin = event.target instanceof Element ? event.target : null;
            if (event.button !== 0 || origin?.closest('button')) return;

            const rect = structureSolutionDialog.getBoundingClientRect();
            structureSolutionDragState = {
                pointerId: event.pointerId,
                startX: event.clientX,
                startY: event.clientY,
                offsetX: event.clientX - rect.left,
                offsetY: event.clientY - rect.top,
                left: rect.left,
                top: rect.top,
                width: rect.width,
                height: rect.height,
                active: false,
            };
            structureSolutionDragHandle.setPointerCapture?.(event.pointerId);
        });
        structureSolutionDragHandle?.addEventListener('pointermove', (event) => {
            const drag = structureSolutionDragState;
            if (!drag || drag.pointerId !== event.pointerId) return;

            if (!drag.active) {
                const movedX = Math.abs(event.clientX - drag.startX);
                const movedY = Math.abs(event.clientY - drag.startY);
                if (Math.max(movedX, movedY) < 4) return;

                drag.active = true;
                structureSolutionDialog.style.inset = 'auto';
                structureSolutionDialog.style.right = 'auto';
                structureSolutionDialog.style.transform = 'none';
                structureSolutionDialog.style.left = `${drag.left}px`;
                structureSolutionDialog.style.top = `${drag.top}px`;
                structureSolutionDialog.classList.add('is-dragging');
            }

            const left = Math.min(
                Math.max(8, event.clientX - drag.offsetX),
                Math.max(8, window.innerWidth - drag.width - 8)
            );
            const top = Math.min(
                Math.max(8, event.clientY - drag.offsetY),
                Math.max(8, window.innerHeight - drag.height - 8)
            );
            structureSolutionDialog.style.left = `${left}px`;
            structureSolutionDialog.style.top = `${top}px`;
            event.preventDefault();
        });
        const stopStructureSolutionDrag = (event) => {
            if (!structureSolutionDragState || structureSolutionDragState.pointerId !== event.pointerId) return;
            structureSolutionDragState = null;
            structureSolutionDialog.classList.remove('is-dragging');
            structureSolutionDragHandle.releasePointerCapture?.(event.pointerId);
        };
        structureSolutionDragHandle?.addEventListener('pointerup', stopStructureSolutionDrag);
        structureSolutionDragHandle?.addEventListener('pointercancel', stopStructureSolutionDrag);

        document.addEventListener('click', (event) => {
            const origin = event.target instanceof Element ? event.target : null;
            const trigger = origin?.closest('[data-case-solution]');
            if (!trigger) return;
            event.preventDefault();
            event.stopPropagation();
            openStructureSolution(trigger);
        });

        document.querySelectorAll('[data-case-solution-close]').forEach((closeButton) => {
            closeButton.addEventListener('click', () => {
                if (structureSolutionDialog?.open) structureSolutionDialog.close();
                else structureSolutionDialog?.removeAttribute('open');
            });
        });
        structureSolutionDialog?.addEventListener('click', (event) => {
            if (event.target === structureSolutionDialog) structureSolutionDialog.close();
        });

        dialog.addEventListener('click', (event) => {
            if (!embeddedCaseDetail && event.target === dialog) {
                dialog.close();
            }
        });

        dialog.addEventListener('close', () => {
            if (!embeddedCaseDetail) document.body.classList.remove('case-modal-open');
            if (structureSolutionDialog?.open) structureSolutionDialog.close();
            chatWidget?.classList.remove('is-open');
            window.clearTimeout(caseChatTimer);
             window.clearInterval(caseChatPresenceTimer);
            caseChatTimer = null;
             caseChatPresenceTimer = null;
        });

        dialog.addEventListener('cancel', (event) => {
            if (embeddedCaseDetail) {
                event.preventDefault();
                return;
            }
            if (chatWidget?.classList.contains('is-open')) {
                event.preventDefault();
                closeCaseChat();
            }
        });

        activatePanel(dialog.dataset.initialPanel || 'resumen');

        if (embeddedCaseDetail) {
            if (chatWidget?.dataset.autoOpen === 'true') openCaseChat();
        } else if (dialog.dataset.autoOpen === 'true') {
            window.requestAnimationFrame(() => {
                if (!dialog.open) {
                    dialog.showModal();
                    document.body.classList.add('case-modal-open');
                }
                if (chatWidget?.dataset.autoOpen === 'true') {
                    openCaseChat();
                }
            });
        } else if (dialog.open && chatWidget?.dataset.autoOpen === 'true') {
            openCaseChat();
        }

        dialog.querySelectorAll('[data-solution-form]').forEach((form) => {
            const solutionSelect = form.querySelector('[data-solution-select]');
            const solutionObservation = form.querySelector('[data-solution-observation]');
            const solutionTextarea = solutionObservation?.querySelector('textarea');
            const guideTitle = form.querySelector('[data-solution-guide-title]');
            const guideText = form.querySelector('[data-solution-guide-text]');
            const newSolution = form.querySelector('[data-new-solution]');
            const toggleNewSolution = form.querySelector('[data-new-solution-toggle]');
            const cancelNewSolution = form.querySelector('[data-new-solution-cancel]');
            const createSolution = form.querySelector('[data-create-solution]');
            const solutionStatus = form.querySelector('[data-new-solution-status]');
            const newSolutionFields = newSolution
                ? Array.from(newSolution.querySelectorAll('input, textarea'))
                : [];
            const solutionName = newSolution?.querySelector('input[name="nueva_solucion_nombre"]');
            const solutionDescription = newSolution?.querySelector('textarea[name="nueva_solucion_descripcion"]');

            if (!solutionSelect || !solutionObservation || !solutionTextarea) {
                return;
            }

            const refreshSolution = () => {
                const option = solutionSelect.options[solutionSelect.selectedIndex];
                const selected = solutionSelect.value !== '';

                solutionObservation.hidden = !selected;
                solutionTextarea.disabled = !selected;

                if (guideTitle) {
                    guideTitle.textContent = selected
                        ? option.textContent.trim()
                        : 'Seleccione una solución';
                }
                if (guideText) {
                    guideText.textContent = selected
                        ? option.dataset.description || 'Esta solución no tiene una guía registrada.'
                        : 'Aquí verá para qué casos debe utilizarse y podrá elegir la alternativa adecuada.';
                }

                if (selected) {
                    window.requestAnimationFrame(() => solutionTextarea.focus());
                }
            };

            const showNewSolution = (show) => {
                if (!newSolution) return;
                newSolution.hidden = !show;
                newSolutionFields.forEach((field) => {
                    field.disabled = !show;
                    field.required = show;
                });
                if (solutionStatus) {
                    solutionStatus.textContent = '';
                    solutionStatus.className = 'new-solution-status';
                }
                toggleNewSolution?.setAttribute('aria-expanded', show ? 'true' : 'false');
                if (show) window.requestAnimationFrame(() => solutionName?.focus());
            };

            toggleNewSolution?.addEventListener('click', () => {
                showNewSolution(Boolean(newSolution?.hidden));
            });
            cancelNewSolution?.addEventListener('click', () => {
                showNewSolution(false);
            });

            createSolution?.addEventListener('click', async () => {
                const name = solutionName?.value.trim() || '';
                const description = solutionDescription?.value.trim() || '';

                if (!name || !description) {
                    if (solutionStatus) {
                        solutionStatus.textContent = 'Complete el nombre y la descripción de la solución.';
                        solutionStatus.className = 'new-solution-status is-error';
                    }
                    (!name ? solutionName : solutionDescription)?.focus();
                    return;
                }

                const payload = new FormData();
                payload.set('csrf_token', form.querySelector('[name="csrf_token"]')?.value || '');
                payload.set('accion', 'crear_solucion_rapida');
                payload.set('id_ticket', form.querySelector('[name="id_ticket"]')?.value || '');
                payload.set('id_ticket_etapa', form.querySelector('[name="id_ticket_etapa"]')?.value || '');
                payload.set('nueva_solucion_nombre', name);
                payload.set('nueva_solucion_descripcion', description);

                createSolution.disabled = true;
                createSolution.textContent = 'Creando...';
                if (solutionStatus) {
                    solutionStatus.textContent = 'Guardando la solución en la biblioteca...';
                    solutionStatus.className = 'new-solution-status';
                }

                try {
                    const response = await fetch(window.location.href, {
                        method: 'POST',
                        headers: {'X-Requested-With': 'XMLHttpRequest'},
                        body: payload,
                        credentials: 'same-origin',
                        cache: 'no-store'
                    });
                    const result = await response.json();
                    if (!response.ok || !result.ok || !result.solution) {
                        throw new Error(result.message || 'No fue posible crear la solución.');
                    }

                    const created = result.solution;
                    dialog.querySelectorAll('[data-solution-select]').forEach((select) => {
                        let option = Array.from(select.options).find((item) => (
                            String(item.value) === String(created.id_solucion)
                        ));
                        if (!option) {
                            option = document.createElement('option');
                            option.value = String(created.id_solucion);
                            select.appendChild(option);
                        }
                        option.textContent = String(created.nombre || name);
                        option.dataset.description = String(created.descripcion || description);
                    });

                    solutionSelect.value = String(created.id_solucion);
                    solutionName.value = '';
                    solutionDescription.value = '';
                    showNewSolution(false);
                    refreshSolution();
                } catch (error) {
                    if (solutionStatus) {
                        solutionStatus.textContent = error instanceof Error
                            ? error.message
                            : 'No fue posible crear la solución.';
                        solutionStatus.className = 'new-solution-status is-error';
                    }
                } finally {
                    createSolution.disabled = false;
                    createSolution.textContent = 'Crear y seleccionar';
                }
            });

            form.addEventListener('submit', (event) => {
                if (!newSolution || newSolution.hidden) return;
                event.preventDefault();
                if (solutionStatus) {
                    solutionStatus.textContent = 'Primero pulse “Crear y seleccionar” o cancele la nueva solución.';
                    solutionStatus.className = 'new-solution-status is-error';
                }
                createSolution?.focus();
            });

            solutionSelect.addEventListener('change', () => {
                if (solutionSelect.value !== '') {
                    showNewSolution(false);
                }
                refreshSolution();
            });
            showNewSolution(false);
            refreshSolution();
        });
    })();
</script>
<script data-flujo-runtime>
    (() => {
        document.querySelectorAll('.derivation-form').forEach((form) => {
            const list = form.querySelector('[data-derivation-list]');
            const template = form.querySelector('[data-derivation-template]');
            const addButton = form.querySelector('[data-add-derivation]');
            const counter = form.querySelector('[data-derivation-count]');
            const servicesData = form.querySelector('[data-derivation-services-json]');
            const maximum = Number(form.dataset.maxDerivaciones || 20);
            const blockedServices = new Set();
            let nextIndex = 1;
            let comboSequence = 0;
            let services = [];

            if (!list || !template || !addButton || !servicesData) {
                return;
            }

            try {
                services = JSON.parse(servicesData.textContent || '[]');
            } catch (error) {
                services = [];
            }

            try {
                JSON.parse(form.dataset.blockedServices || '[]').forEach((serviceId) => {
                    blockedServices.add(String(serviceId));
                });
            } catch (error) {
                blockedServices.clear();
            }

            services = services.filter((service) =>
                !blockedServices.has(String(service.id_servicio || ''))
            );

            const normalize = (value) => String(value || '')
                .toLocaleLowerCase('es')
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .trim();

            const rows = () => Array.from(list.querySelectorAll('[data-derivation-row]'));
            const selectedInOtherRows = (currentRow) => new Set(
                rows()
                    .filter((row) => row !== currentRow)
                    .map((row) => row.querySelector('[data-service-id]')?.value || '')
                    .filter(Boolean)
            );

            const renderExtraFields = (row, service) => {
                const container = row.querySelector('[data-derivation-extra-fields]');
                const serviceId = row.querySelector('[data-service-id]');
                if (!container || !serviceId) return;
                container.replaceChildren();
                const campos = Array.isArray(service?.campos_extras) ? service.campos_extras : [];
                const name = serviceId.getAttribute('name') || '';
                const match = name.match(/derivaciones\[([^\]]+)\]/);
                const index = match ? match[1] : '0';
                campos.forEach((campo) => {
                    const field = document.createElement('div');
                    field.className = 'derivation-extra-field';
                    const label = document.createElement('label');
                    label.textContent = `${campo.etiqueta || 'Información adicional'}${Number(campo.obligatorio) === 1 ? ' *' : ''}`;
                    const input = document.createElement('textarea');
                    input.rows = 2;
                    input.maxLength = 5000;
                    input.required = Number(campo.obligatorio) === 1;
                    input.name = `derivaciones[${index}][campos_extras][${campo.id}]`;
                    input.placeholder = 'Ingrese la información solicitada';
                    field.append(label, input);
                    container.appendChild(field);
                });
                container.hidden = campos.length === 0;
            };

            const closeServiceMenu = (row) => {
                const input = row.querySelector('[data-service-search]');
                const menu = row.querySelector('[data-service-menu]');
                const toggle = row.querySelector('[data-service-toggle]');

                if (menu) menu.hidden = true;
                if (input) input.setAttribute('aria-expanded', 'false');
                if (toggle) toggle.setAttribute('aria-expanded', 'false');
            };

            const closeOtherServiceMenus = (currentRow = null) => {
                rows().forEach((row) => {
                    if (row !== currentRow) closeServiceMenu(row);
                });
            };

            const selectService = (row, service) => {
                const input = row.querySelector('[data-service-search]');
                const serviceId = row.querySelector('[data-service-id]');
                const help = row.querySelector('[data-service-help]');

                if (!input || !serviceId) return;
                if (selectedInOtherRows(row).has(String(service.id_servicio || ''))) {
                    renderServiceOptions(row, true);
                    return;
                }

                input.value = String(service.nombre || '');
                input.setCustomValidity('');
                serviceId.value = String(service.id_servicio || '');

                if (help) {
                    help.textContent = `Seleccionado · Gestor: ${service.gestor || 'Sin gestor'} · SLA: ${service.sla || 'Sin SLA'}`;
                }

                renderExtraFields(row, service);

                closeServiceMenu(row);
            };

            const renderServiceOptions = (row, showAll = false) => {
                const catalog = row.querySelector('[data-derivation-catalog]');
                const input = row.querySelector('[data-service-search]');
                const menu = row.querySelector('[data-service-menu]');
                const toggle = row.querySelector('[data-service-toggle]');
                const help = row.querySelector('[data-service-help]');

                if (!catalog || !input || !menu || !toggle || !catalog.value) {
                    closeServiceMenu(row);
                    return;
                }

                const catalogId = String(catalog.value);
                const query = showAll ? '' : normalize(input.value);
                const reserved = selectedInOtherRows(row);
                const matches = services.filter((service) =>
                    String(service.id_catalogo) === catalogId
                    && !reserved.has(String(service.id_servicio || ''))
                    && (!query || normalize(service.nombre).startsWith(query))
                );

                menu.replaceChildren();

                if (!matches.length) {
                    const empty = document.createElement('div');
                    empty.className = 'derivation-service-empty';
                    empty.textContent = query
                        ? `No hay servicios que comiencen por “${input.value.trim()}”.`
                        : 'Este proceso no tiene otros servicios disponibles para derivar.';
                    menu.appendChild(empty);
                } else {
                    matches.forEach((service) => {
                        const option = document.createElement('button');
                        const optionName = document.createElement('span');
                        const info = document.createElement('span');
                        const description = document.createElement('span');

                        option.type = 'button';
                        option.className = 'derivation-service-option';
                        option.setAttribute('role', 'option');
                        option.dataset.serviceOption = String(service.id_servicio || '');
                        option.title = String(service.nombre || 'Servicio');
                        option.setAttribute(
                            'aria-label',
                            `${service.nombre || 'Servicio'} · Gestor: ${service.gestor || 'Sin gestor'} · SLA: ${service.sla || 'Sin SLA'}. Pulse el icono de información para ver la descripción.`
                        );

                        optionName.className = 'derivation-service-option-name';
                        optionName.textContent = String(service.nombre || 'Servicio');

                        info.className = 'derivation-service-info';
                        info.setAttribute('role', 'button');
                        info.tabIndex = 0;
                        info.setAttribute('aria-label', `Ver descripción de ${service.nombre || 'servicio'}`);
                        info.setAttribute('aria-expanded', 'false');
                        info.textContent = '?';

                        description.className = 'derivation-service-description';
                        description.textContent = String(
                            service.descripcion || 'Este servicio no tiene una descripción registrada.'
                        );

                        const alternarDescripcion = (event) => {
                            event.preventDefault();
                            event.stopPropagation();
                            const abierta = option.classList.toggle('is-info-open');
                            info.setAttribute('aria-expanded', abierta ? 'true' : 'false');
                        };

                        info.addEventListener('click', alternarDescripcion);
                        info.addEventListener('keydown', (event) => {
                            if (event.key === 'Enter' || event.key === ' ') {
                                alternarDescripcion(event);
                            } else if (event.key === 'Escape') {
                                event.preventDefault();
                                event.stopPropagation();
                                option.classList.remove('is-info-open');
                                info.setAttribute('aria-expanded', 'false');
                            }
                        });

                        option.append(optionName, info, description);
                        option.addEventListener('click', () => selectService(row, service));
                        option.addEventListener('keydown', (event) => {
                            const options = Array.from(
                                menu.querySelectorAll('[data-service-option]')
                            );
                            const index = options.indexOf(option);

                            if (event.key === 'ArrowDown') {
                                event.preventDefault();
                                options[Math.min(index + 1, options.length - 1)]?.focus();
                            } else if (event.key === 'ArrowUp') {
                                event.preventDefault();

                                if (index <= 0) input.focus();
                                else options[index - 1]?.focus();
                            } else if (event.key === 'Escape') {
                                event.preventDefault();
                                closeServiceMenu(row);
                                input.focus();
                            }
                        });
                        menu.appendChild(option);
                    });
                }

                if (help && !row.querySelector('[data-service-id]')?.value) {
                    if (showAll || !query) {
                        help.textContent = matches.length === 1
                            ? '1 servicio disponible. Puede seleccionarlo o escribir para filtrar.'
                            : `${matches.length} servicios disponibles. Puede seleccionar uno o escribir para filtrar.`;
                    } else {
                        help.textContent = matches.length === 1
                            ? '1 servicio coincide con el inicio escrito.'
                            : `${matches.length} servicios coinciden con el inicio escrito.`;
                    }
                }

                closeOtherServiceMenus(row);
                menu.hidden = false;
                input.setAttribute('aria-expanded', 'true');
                toggle.setAttribute('aria-expanded', 'true');
            };

            const resetService = (row) => {
                const catalog = row.querySelector('[data-derivation-catalog]');
                const input = row.querySelector('[data-service-search]');
                const serviceId = row.querySelector('[data-service-id]');
                const toggle = row.querySelector('[data-service-toggle]');
                const help = row.querySelector('[data-service-help]');

                if (!input || !serviceId || !toggle) return;

                input.value = '';
                input.setCustomValidity('');
                serviceId.value = '';
                input.disabled = !catalog?.value;
                toggle.disabled = !catalog?.value;
                input.placeholder = catalog?.value
                    ? 'Seleccione con la flecha o escriba, por ejemplo: cont'
                    : 'Seleccione primero un proceso';

                if (help) {
                    help.textContent = catalog?.value
                        ? 'Use la flecha para ver todos los servicios o escriba para filtrarlos.'
                        : 'Los servicios se habilitan al seleccionar el proceso.';
                }
                const extraFields = row.querySelector('[data-derivation-extra-fields]');
                if (extraFields) {
                    extraFields.replaceChildren();
                    extraFields.hidden = true;
                }

                closeServiceMenu(row);
            };

            const initializeRow = (row) => {
                const catalog = row.querySelector('[data-derivation-catalog]');
                const input = row.querySelector('[data-service-search]');
                const serviceId = row.querySelector('[data-service-id]');
                const menu = row.querySelector('[data-service-menu]');
                const toggle = row.querySelector('[data-service-toggle]');

                if (!catalog || !input || !serviceId || !menu || !toggle) return;

                comboSequence += 1;
                menu.id = `derivation-service-list-${comboSequence}`;
                input.setAttribute('aria-controls', menu.id);
                toggle.setAttribute('aria-controls', menu.id);

                catalog.addEventListener('change', () => {
                    resetService(row);

                    if (catalog.value) {
                        input.focus();
                        renderServiceOptions(row, true);
                    }
                });

                toggle.addEventListener('click', (event) => {
                    event.preventDefault();
                    event.stopPropagation();

                    if (toggle.disabled) return;

                    if (!menu.hidden) {
                        closeServiceMenu(row);
                        return;
                    }

                    input.focus({preventScroll: true});
                    renderServiceOptions(row, true);
                });

                input.addEventListener('focus', () => renderServiceOptions(row));
                input.addEventListener('input', () => {
                    serviceId.value = '';
                    input.setCustomValidity('');
                    renderServiceOptions(row);
                });
                input.addEventListener('keydown', (event) => {
                    if (event.key === 'ArrowDown') {
                        event.preventDefault();
                        renderServiceOptions(row);
                        menu.querySelector('[data-service-option]')?.focus();
                    } else if (event.key === 'Escape') {
                        event.preventDefault();
                        closeServiceMenu(row);
                    }
                });

                resetService(row);
            };

            const refresh = () => {
                const total = rows().length;
                list.querySelectorAll('[data-remove-derivation]').forEach((button) => {
                    button.hidden = total === 1;
                });
                addButton.disabled = total >= maximum;

                if (counter) {
                    counter.textContent = `${total} derivación${total === 1 ? '' : 'es'} preparada${total === 1 ? '' : 's'}`;
                }
            };

            addButton.addEventListener('click', () => {
                if (rows().length >= maximum) {
                    return;
                }

                const wrapper = document.createElement('div');
                wrapper.innerHTML = template.innerHTML.replaceAll('__INDEX__', String(nextIndex++));
                const row = wrapper.firstElementChild;

                if (row) {
                    list.appendChild(row);
                    initializeRow(row);
                    refresh();
                    row.querySelector('[data-derivation-catalog]')?.focus();
                }
            });

            list.addEventListener('click', (event) => {
                const button = event.target.closest('[data-remove-derivation]');

                if (!button || rows().length === 1) {
                    return;
                }

                button.closest('[data-derivation-row]')?.remove();
                refresh();
            });

            document.addEventListener('click', (event) => {
                if (event.target.closest('[data-derivation-catalog]')) {
                    return;
                }

                if (!event.target.closest('[data-service-combobox]')) {
                    closeOtherServiceMenus();
                }
            });

            form.addEventListener('submit', (event) => {
                let firstInvalid = null;
                const selected = rows().map((row) => {
                    const catalog = row.querySelector('[data-derivation-catalog]');
                    const input = row.querySelector('[data-service-search]');
                    const serviceId = row.querySelector('[data-service-id]');
                    const selectedService = services.find((service) =>
                        String(service.id_servicio) === String(serviceId?.value || '')
                        && String(service.id_catalogo) === String(catalog?.value || '')
                    );

                    if (!catalog?.value) {
                        firstInvalid ||= catalog;
                    } else if (!selectedService) {
                        input?.setCustomValidity(
                            'Escriba el inicio y seleccione un servicio de la lista.'
                        );
                        firstInvalid ||= input;
                    } else {
                        input?.setCustomValidity('');
                    }

                    return serviceId?.value || '';
                });

                if (firstInvalid) {
                    event.preventDefault();
                    firstInvalid.reportValidity();
                    firstInvalid.focus();
                    return;
                }

                const repeated = selected.some((value, index) =>
                    value !== '' && selected.indexOf(value) !== index
                );

                if (repeated) {
                    event.preventDefault();
                    window.alert('No repita el mismo servicio en esta derivación múltiple.');
                    return;
                }

                if (!window.confirm(`¿Crear ${selected.length} ticket(s) derivado(s) y pausar el SLA de la etapa actual?`)) {
                    event.preventDefault();
                }
            });

            rows().forEach(initializeRow);
            refresh();
        });
    })();
</script>
<?php if ($rol === 2 && $etapaActual && $puedeGestionar): ?>
<script data-flujo-runtime>
    (() => {
        const checklistForm = document.querySelector('[data-case-checklist-form]');
        const protectedForms = Array.from(document.querySelectorAll('[data-checklist-protected-form]'));
        const requiredChecks = checklistForm
            ? Array.from(checklistForm.querySelectorAll('[data-required-checklist]'))
            : [];
        const initiallyPending = <?= (int) $checklistObligatorioPendiente ?>;
        let checklistWasEdited = false;

        const pendingRows = () => requiredChecks.filter((checkbox) => !checkbox.checked);

        const markMissingRows = () => {
            requiredChecks.forEach((checkbox) => {
                checkbox.closest('[data-required-checklist-row]')?.classList.toggle(
                    'checklist-row-missing',
                    !checkbox.checked
                );
            });
        };

        const blockMessage = () => {
            const pending = pendingRows().length;
            if (checklistWasEdited) {
                return pending > 0
                    ? `Faltan ${pending} ítem(s) obligatorio(s). Márquelos y pulse “Guardar checklist” antes de continuar.`
                    : 'El checklist tiene cambios sin guardar. Pulse “Guardar checklist” antes de continuar.';
            }
            return `Faltan ${Math.max(initiallyPending, pendingRows().length)} ítem(s) obligatorio(s). Complete y guarde el checklist antes de continuar.`;
        };

        const isBlocked = () => initiallyPending > 0 || checklistWasEdited;

        const refreshGate = () => {
            const blocked = isBlocked();
            protectedForms.forEach((form) => {
                const gate = form.querySelector('[data-checklist-gate]');
                const text = form.querySelector('[data-checklist-gate-text]');
                const button = form.querySelector('[data-checklist-action]');
                if (gate) gate.hidden = !blocked;
                if (text && blocked) text.textContent = blockMessage();
                if (button) button.setAttribute('aria-disabled', blocked ? 'true' : 'false');
            });
            markMissingRows();
        };

        requiredChecks.forEach((checkbox) => {
            checkbox.addEventListener('change', () => {
                checklistWasEdited = true;
                refreshGate();
            });
        });

        protectedForms.forEach((form) => {
            form.addEventListener('submit', (event) => {
                if (isBlocked()) {
                    event.preventDefault();
                    window.alert(`⚠ Checklist obligatorio pendiente\n\n${blockMessage()}`);
                    checklistForm?.closest('details')?.setAttribute('open', '');
                    checklistForm?.scrollIntoView({behavior: 'smooth', block: 'center'});
                    pendingRows()[0]?.focus({preventScroll: true});
                    return;
                }

                const confirmation = form.dataset.confirmMessage || '';
                if (confirmation && !window.confirm(confirmation)) {
                    event.preventDefault();
                }
            });
        });

        refreshGate();
    })();
</script>
<?php endif; ?>
<?php if ($rol === 2 && $modoGestor === 'nuevo' && !$ticketSeleccionado): ?>
<script data-flujo-runtime>
    (() => {
        const catalogButtons = Array.from(document.querySelectorAll('.catalog-option'));
        const serviceButtons = Array.from(document.querySelectorAll('.service-option'));
        const serviceEmptyStates = Array.from(document.querySelectorAll('.service-empty'));
        const servicePanel = document.getElementById('servicePanel');
        const servicePanelTitle = document.getElementById('servicePanelTitle');
        const formPanel = document.getElementById('ticketFormPanel');
        const processInput = document.getElementById('id_proceso');
        const selectedServiceName = document.getElementById('selectedServiceName');
        const selectedServiceFlow = document.getElementById('selectedServiceFlow');
        const changeServiceButton = document.getElementById('changeServiceButton');
        const ticketForm = document.getElementById('ticketCreateForm');
        const wizardSteps = Array.from(document.querySelectorAll('[data-wizard-step]'));

        if (!catalogButtons.length || !servicePanel || !formPanel || !processInput) {
            return;
        }

        const activateStep = (step) => {
            wizardSteps.forEach((item) => {
                const current = Number(item.dataset.wizardStep || 0);
                item.classList.toggle('active', current <= step);
            });
        };

        const showServices = (catalogButton) => {
            const catalogId = catalogButton.dataset.catalogo || '';
            const catalogName = catalogButton.dataset.nombre || 'Proceso';

            catalogButtons.forEach((button) => {
                const active = button === catalogButton;
                button.classList.toggle('active', active);
                button.setAttribute('aria-pressed', active ? 'true' : 'false');
            });

            serviceButtons.forEach((button) => {
                button.hidden = button.dataset.catalogo !== catalogId;
                button.classList.remove('active');
            });

            serviceEmptyStates.forEach((emptyState) => {
                emptyState.hidden = emptyState.dataset.catalogo !== catalogId;
            });

            servicePanelTitle.textContent = `Servicios de ${catalogName}`;
            servicePanel.hidden = false;
            formPanel.hidden = true;
            processInput.value = '';
            activateStep(2);

            requestAnimationFrame(() => {
                servicePanel.scrollIntoView({behavior: 'smooth', block: 'nearest'});
            });
        };

        catalogButtons.forEach((button) => {
            button.addEventListener('click', () => showServices(button));
        });

        serviceButtons.forEach((button) => {
            button.addEventListener('click', () => {
                serviceButtons.forEach((item) => item.classList.remove('active'));
                button.classList.add('active');

                processInput.value = button.dataset.proceso || '';
                selectedServiceName.textContent = `${button.dataset.catalogoNombre} · ${button.dataset.servicioNombre}`;
                selectedServiceFlow.textContent = `Flujo de atención: ${button.dataset.flujoNombre}`;
                formPanel.hidden = false;
                activateStep(3);

                requestAnimationFrame(() => {
                    formPanel.scrollIntoView({behavior: 'smooth', block: 'nearest'});
                });
            });
        });

        if (changeServiceButton) {
            changeServiceButton.addEventListener('click', () => {
                formPanel.hidden = true;
                processInput.value = '';
                serviceButtons.forEach((item) => item.classList.remove('active'));
                activateStep(2);
                servicePanel.scrollIntoView({behavior: 'smooth', block: 'nearest'});
            });
        }

        if (ticketForm) {
            ticketForm.addEventListener('submit', (event) => {
                if (processInput.value === '') {
                    event.preventDefault();
                    window.alert('Seleccione primero el proceso y el servicio que desea solicitar.');
                    servicePanel.scrollIntoView({behavior: 'smooth', block: 'nearest'});
                }
            });
        }
    })();
</script>
<?php endif; ?>
<?php if ($ticketSeleccionado && $idTicketSeleccionado > 0): ?>
<script data-flujo-runtime>
    (() => {
        'use strict';

        const ticketId = <?= (int) $idTicketSeleccionado ?>;
        const restoreKey = `mesa-case-live-chat:${ticketId}:${window.location.pathname}`;
        let knownRevision = '';
        let requestRunning = false;
        let pageLeaving = false;

        const restoreChat = () => {
            if (window.sessionStorage.getItem(restoreKey) !== '1') return;
            window.sessionStorage.removeItem(restoreKey);
            window.setTimeout(() => {
                document.querySelector('[data-case-chat-open]')?.click();
            }, 90);
        };

        const saveChatState = () => {
            const chat = document.querySelector('[data-case-chat-widget]');
            if (chat?.classList.contains('is-open')) {
                window.sessionStorage.setItem(restoreKey, '1');
            } else {
                window.sessionStorage.removeItem(restoreKey);
            }
        };

        const checkCaseRevision = async () => {
            if (requestRunning || pageLeaving || document.visibilityState !== 'visible') return;
            requestRunning = true;

            try {
                const params = new URLSearchParams({
                    action: 'case_revision',
                    id_ticket: String(ticketId),
                    _: String(Date.now())
                });
                const response = await fetch(`mensajesApi.php?${params}`, {
                    cache: 'no-store',
                    credentials: 'same-origin',
                    headers: {'Accept': 'application/json'}
                });
                const result = await response.json().catch(() => ({}));
                if (!response.ok || result.ok !== true || !result.revision) return;

                if (knownRevision === '') {
                    knownRevision = result.revision;
                    return;
                }

                if (knownRevision !== result.revision) {
                    pageLeaving = true;
                    saveChatState();
                    if (typeof window.mesaFlujoNavigate === 'function') {
                        await window.mesaFlujoNavigate(window.location.href, {
                            replace: true,
                            preserveScroll: true
                        });
                    } else {
                        window.location.reload();
                    }
                }
            } finally {
                requestRunning = false;
            }
        };

        document.addEventListener('submit', (event) => {
            if (!event.defaultPrevented) pageLeaving = true;
        });
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') void checkCaseRevision();
        });
        restoreChat();
        void checkCaseRevision();
        // La revisión es una salvaguarda para cambios externos. Las acciones
        // locales siguen recargando la vista inmediatamente.
        const timer = window.setInterval(() => void checkCaseRevision(), 10000);
        window.addEventListener('pagehide', () => window.clearInterval(timer), {once: true});
        window.addEventListener('mesa:flujo:dispose', () => {
            pageLeaving = true;
            window.clearInterval(timer);
        }, {once: true});
    })();
</script>
<?php endif; ?>
<script>
    (() => {
        'use strict';

        if (window.__MESA_FLUJO_NAVIGATION_INSTALLED__) return;
        window.__MESA_FLUJO_NAVIGATION_INSTALLED__ = true;

        let navigating = false;

        const sameFlowPage = (url) => {
            const target = new URL(url, window.location.href);
            const currentName = (window.location.pathname.split('/').pop() || '').toLowerCase();
            const targetName = (target.pathname.split('/').pop() || '').toLowerCase();
            return target.origin === window.location.origin
                && targetName === currentName
                && targetName === 'flujoticket.php';
        };

        const runRuntimeScripts = (nextDocument) => {
            nextDocument.querySelectorAll('script[data-flujo-runtime]').forEach((source) => {
                try {
                    const runtime = document.createElement('script');
                    runtime.dataset.flujoRuntime = '';
                    runtime.textContent = source.textContent || '';
                    document.body.appendChild(runtime);
                    runtime.remove();
                } catch (error) {
                    console.error('No fue posible iniciar un componente del caso.', error);
                }
            });
        };

        const showNavigationError = () => {
            const main = document.querySelector('main.shell');
            if (!main || main.querySelector('[data-flujo-navigation-error]')) return;

            const message = document.createElement('div');
            message.className = 'alert danger';
            message.dataset.flujoNavigationError = '';
            message.setAttribute('role', 'alert');
            message.textContent = 'No fue posible abrir la etapa. La pantalla actual se conservó; por favor intente nuevamente.';
            main.prepend(message);
            window.setTimeout(() => message.remove(), 5000);
        };

        const navigate = async (url, options = {}) => {
            if (navigating || !sameFlowPage(url)) {
                return false;
            }

            navigating = true;
            const currentMain = document.querySelector('main.shell');
            currentMain?.setAttribute('aria-busy', 'true');
            document.body.classList.add('mesa-flujo-navigating');

            try {
                const response = await fetch(String(url), {
                    cache: 'no-store',
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'text/html',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });
                if (!response.ok) throw new Error('No fue posible abrir la vista.');
                if (!sameFlowPage(response.url)) {
                    throw new Error('La respuesta no corresponde al flujo solicitado.');
                }

                const html = await response.text();
                const nextDocument = new DOMParser().parseFromString(html, 'text/html');
                const nextMain = nextDocument.querySelector('main.shell');
                if (!nextMain || !currentMain) throw new Error('La respuesta no contiene la vista solicitada.');

                window.dispatchEvent(new Event('mesa:flujo:dispose'));
                currentMain.replaceWith(document.importNode(nextMain, true));
                document.title = nextDocument.title || document.title;

                if (options.replace) window.history.replaceState({mesaFlujo: true}, '', String(url));
                else window.history.pushState({mesaFlujo: true}, '', String(url));

                if (window.parent !== window) {
                    const destino = new URL(String(url), window.location.href);
                    window.parent.postMessage({
                        tipo: 'mesa-historial',
                        url: destino.pathname + destino.search + destino.hash,
                        replace: Boolean(options.replace)
                    }, window.location.origin);
                }

                runRuntimeScripts(nextDocument);
                if (!options.preserveScroll) window.scrollTo({top: 0, behavior: 'auto'});
                return true;
            } catch (error) {
                console.error('Navegación interna del caso:', error);
                showNavigationError();
                return false;
            } finally {
                navigating = false;
                document.body.classList.remove('mesa-flujo-navigating');
                document.querySelector('main.shell')?.removeAttribute('aria-busy');
            }
        };

        window.mesaFlujoNavigate = navigate;

        document.addEventListener('click', (event) => {
            const link = event.target.closest('a[data-flujo-nav]');
            if (!link || event.defaultPrevented || event.button !== 0) return;
            if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
            const ruta = link.dataset.mesaRoute || link.href;
            if (!sameFlowPage(ruta)) return;
            event.preventDefault();
            event.stopPropagation();
            void navigate(ruta);
        }, true);

        window.addEventListener('popstate', () => {
            if (sameFlowPage(window.location.href)) {
                void navigate(window.location.href, {replace: true});
            }
        });
    })();
</script>
<script src="assets/js/controlSesion.js" defer></script>
<script>
    (() => {
        'use strict';

        const accionesRapidas = new Set([
            'marcar_listo',
            'solicitar_cierre_definitivo',
            'cerrar_caso',
            'calificar_cerrar_ticket'
        ]);

        document.addEventListener('submit', (event) => {
            if (event.defaultPrevented) return;
            const form = event.target;
            if (!(form instanceof HTMLFormElement)) return;

            const accion = form.querySelector('input[name="accion"]')?.value || '';
            if (!accionesRapidas.has(accion) || form.dataset.processing === 'true') {
                if (form.dataset.processing === 'true') event.preventDefault();
                return;
            }

            form.dataset.processing = 'true';
            const button = event.submitter instanceof HTMLButtonElement
                ? event.submitter
                : form.querySelector('button[type="submit"]');

            if (button) {
                button.disabled = true;
                button.setAttribute('aria-busy', 'true');
                button.dataset.originalText = button.textContent || '';
                button.textContent = accion === 'marcar_listo'
                    ? 'Enviando a revisión…'
                    : 'Guardando…';
            }
        });
    })();
</script>
</body>
</html>
