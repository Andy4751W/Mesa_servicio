<?php
declare(strict_types=1);

/* La ficha de seguimiento siempre debe reflejar la última estructura y
   estado del caso, incluso cuando el navegador conserve una vista anterior. */
if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

seguridadExigirRol([3]);

$idPaisOperacion = paisExigirContexto();
camposExtrasPrepararEsquema($conn);
camposExtrasSembrarCatalogo($conn, $idPaisOperacion);
$idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
$nombreUsuario = trim((string) ($_SESSION['usuario'] ?? 'Solicitante'));
$esGestorEnModoSolicitante = (int) ($_SESSION['rol_base'] ?? 0) === 2;
$serviciosGestionadosPorUsuario = [];

if ($esGestorEnModoSolicitante) {
    $stmtServiciosGestionados = $conn->prepare(
        "SELECT DISTINCT sg.id_servicio
         FROM servicio_gestores AS sg
         INNER JOIN servicios AS s ON s.id_servicio = sg.id_servicio
         WHERE sg.id_usuario = ?
           AND sg.estado = 'activo'
           AND s.id_pais_operacion = ?
           AND s.estado = 'activo'"
    );
    $stmtServiciosGestionados->bind_param('ii', $idUsuario, $idPaisOperacion);
    $stmtServiciosGestionados->execute();
    $resultadoServiciosGestionados = $stmtServiciosGestionados->get_result();
    while ($servicioGestionado = $resultadoServiciosGestionados->fetch_assoc()) {
        $serviciosGestionadosPorUsuario[(int) $servicioGestionado['id_servicio']] = true;
    }
    $stmtServiciosGestionados->close();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/*
 * Cada formulario de creación tiene un identificador de un solo uso. PHP
 * conserva el bloqueo de la sesión durante el POST, por lo que dos clics
 * consecutivos no pueden crear dos casos con el mismo identificador.
 */
$sesionReabiertaParaCreacion = session_status() !== PHP_SESSION_ACTIVE;
if ($sesionReabiertaParaCreacion) {
    seguridadIniciarSesion();
}
if (empty($_SESSION['solicitud_creacion_token'])) {
    $_SESSION['solicitud_creacion_token'] = bin2hex(random_bytes(32));
}

$tokenCreacionSolicitud = (string) $_SESSION['solicitud_creacion_token'];
if ($sesionReabiertaParaCreacion) {
    session_write_close();
}

function escaparPortalSolicitante($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function nombreCortoPortalSolicitante(string $nombreCompleto): string
{
    $nombreCompleto = trim((string) preg_replace(
        '/\s+/u',
        ' ',
        $nombreCompleto
    ));

    if ($nombreCompleto === '') {
        return 'Pendiente';
    }

    $partes = preg_split('/\s+/u', $nombreCompleto) ?: [];
    $cantidad = count($partes);

    if ($cantidad < 2) {
        $nombreCorto = $partes[0] ?? $nombreCompleto;
    } elseif ($cantidad === 2) {
        $nombreCorto = $partes[0] . ' ' . $partes[1];
    } else {
        /* En nombres corporativos de tres palabras el apellido suele ser la
           segunda; con cuatro o más, normalmente los dos últimos elementos
           corresponden a los apellidos. */
        $indicePrimerApellido = $cantidad >= 4
            ? $cantidad - 2
            : 1;
        $nombreCorto = $partes[0] . ' ' . $partes[$indicePrimerApellido];
    }

    if (function_exists('mb_convert_case')) {
        return mb_convert_case($nombreCorto, MB_CASE_TITLE, 'UTF-8');
    }

    return ucwords(strtolower($nombreCorto));
}

function rolChatPortalSolicitante(int $rolUsuario): string
{
    return (fn ($__mesaMatchValue31) => (($__mesaMatchValue31 === (1)) ? ('Administrador') : ((($__mesaMatchValue31 === (2)) ? ('Gestor') : ((($__mesaMatchValue31 === (3)) ? ('Solicitante') : ('Usuario')))))))($rolUsuario);
}

function fechaPortalSolicitante(?string $fecha): string
{
    if (!$fecha) {
        return 'Pendiente';
    }

    $marca = strtotime($fecha);

    return $marca ? date('d/m/Y H:i', $marca) : $fecha;
}

function textoEstadoPortalSolicitante(string $estado): string
{
    return (fn ($__mesaMatchValue32) => (($__mesaMatchValue32 === ('en_proceso')) ? ('En gestión') : ((($__mesaMatchValue32 === ('pendiente_calificacion')) ? ('Solución lista') : ((($__mesaMatchValue32 === ('cerrado') || $__mesaMatchValue32 === ('cerrada')) ? ('Cerrado') : ((($__mesaMatchValue32 === ('cancelado') || $__mesaMatchValue32 === ('cancelada')) ? ('Cancelado') : ((($__mesaMatchValue32 === ('abierto')) ? ('Abierto') : (ucfirst(str_replace('_', ' ', $estado)))))))))))))($estado);
}

function textoEstadoCasoSolicitante(string $estado): string
{
    return (fn ($__mesaMatchValue33) => (($__mesaMatchValue33 === ('pendiente')) ? ('Pendiente') : ((($__mesaMatchValue33 === ('en_proceso')) ? ('En gestión') : ((($__mesaMatchValue33 === ('en_espera_solicitante')) ? ('En espera') : ((($__mesaMatchValue33 === ('pausada')) ? ('Pausado por dependencia') : ((($__mesaMatchValue33 === ('listo_cierre')) ? ('Solución lista') : ((($__mesaMatchValue33 === ('completada')) ? ('Completado') : ((($__mesaMatchValue33 === ('bloqueada')) ? ('Aún no iniciado') : ((($__mesaMatchValue33 === ('cancelada')) ? ('Cancelado') : (ucfirst(str_replace('_', ' ', $estado)))))))))))))))))))($estado);
}

function redirigirPortalSolicitante(
    string $mensaje,
    string $vista = 'tickets',
    int $idTicket = 0,
    int $idChat = 0,
    string $fragmento = ''
): void {
    $parametros = ['vista' => $vista, 'msg' => $mensaje];

    if ($idTicket > 0) {
        $parametros['id_ticket'] = $idTicket;
    }

    if ($idChat > 0) {
        $parametros['id_chat'] = $idChat;
    }

    $ancla = preg_match('/^[A-Za-z0-9_-]+$/', $fragmento)
        ? '#' . $fragmento
        : '';
    header(
        'Location: panelSolicitante.php?'
            . http_build_query($parametros)
            . $ancla,
        true,
        303
    );
    header('Cache-Control: no-store');
    header('Content-Length: 0');

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    /*
     * Entrega la redirección antes de ejecutar los trabajos diferidos de
     * notificación. El caso ya quedó confirmado en la base de datos.
     */
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        while (ob_get_level() > 0) {
            @ob_end_clean();
        }
        flush();
    }

    exit;
}

function solicitudChatPortalEsAjax(): bool
{
    return strtolower((string) (
        $_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''
    )) === 'xmlhttprequest';
}

function responderChatPortalJson(
    bool $correcto,
    string $mensaje,
    int $codigoHttp = 200
): void {
    http_response_code($codigoHttp);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');
    $cuerpo = json_encode(
        [
            'ok' => $correcto,
            'message' => $mensaje,
            'sent_at' => date('H:i'),
        ],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    $cuerpo = is_string($cuerpo)
        ? $cuerpo
        : '{"ok":false,"message":"Respuesta no disponible."}';
    header('Content-Length: ' . strlen($cuerpo));

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    echo $cuerpo;

    if (ob_get_level() > 0) {
        @ob_flush();
    }
    flush();
    exit;
}

/**
 * Devuelve los casos del solicitante que requieren aprobar o devolver una
 * solución antes de permitir la creación de una nueva solicitud.
 *
 * @return list<int>
 */
function casosPendientesCalificacionSolicitante(
    mysqli $conn,
    int $idUsuario,
    int $idPaisOperacion
): array {
    $ids = [];
    $stmt = $conn->prepare(
        "SELECT DISTINCT t.id_ticket
         FROM tickets AS t
         INNER JOIN ticket_etapas AS te ON te.id_ticket = t.id_ticket
         WHERE t.id_usuario = ?
           AND t.id_pais_operacion = ?
           AND te.id_ticket_etapa_padre IS NULL
           AND te.estado = 'listo_cierre'
         ORDER BY t.id_ticket DESC"
    );
    $stmt->bind_param('ii', $idUsuario, $idPaisOperacion);
    $stmt->execute();
    $resultado = $stmt->get_result();

    while ($fila = $resultado->fetch_assoc()) {
        $idTicket = (int) ($fila['id_ticket'] ?? 0);

        if ($idTicket > 0) {
            $ids[] = $idTicket;
        }
    }

    $stmt->close();

    return $ids;
}

if (
    !flujoModuloInstalado($conn)
    || !flujoModuloAprobacionCasosInstalado($conn)
    || !flujoColumnaExiste($conn, 'servicios', 'tipo_solicitud')
    || !flujoColumnaExiste($conn, 'tickets', 'tipo_solicitud')
) {
    http_response_code(503);
    exit('El módulo de casos necesita las migraciones pendientes, incluida 002_notificaciones_email_tickets.sql. Comuníquese con el administrador.');
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    seguridadExigirOrigenPost();
    $token = $_POST['csrf_token'] ?? '';

    if (!is_string($token) || !hash_equals((string) $_SESSION['csrf_token'], $token)) {
        redirigirPortalSolicitante('solicitud_invalida', 'nueva');
    }

    $accion = (string) ($_POST['accion'] ?? '');

    if ($accion === 'crear_ticket') {
        $pendientesAntesDeCrear = casosPendientesCalificacionSolicitante(
            $conn,
            $idUsuario,
            $idPaisOperacion
        );

        if ($pendientesAntesDeCrear) {
            redirigirPortalSolicitante(
                'calificacion_pendiente_bloquea_creacion',
                'tickets',
                (int) $pendientesAntesDeCrear[0]
            );
        }
    }

    if ($accion === 'configurar_notificaciones') {
        $idTicket = filter_input(
            INPUT_POST,
            'id_ticket',
            FILTER_VALIDATE_INT
        ) ?: 0;
        $valorHabilitada = (string) ($_POST['habilitada'] ?? '');

        if (
            $idTicket < 1
            || !in_array($valorHabilitada, ['0', '1'], true)
        ) {
            redirigirPortalSolicitante(
                'solicitud_invalida',
                'tickets',
                $idTicket
            );
        }

        try {
            paisExigirTicket($conn, $idTicket);
            flujoConfigurarNotificacionesEmail(
                $conn,
                $idTicket,
                $idUsuario,
                3,
                $valorHabilitada === '1'
            );
            redirigirPortalSolicitante(
                $valorHabilitada === '1'
                    ? 'notificaciones_activadas'
                    : 'notificaciones_desactivadas',
                'tickets',
                $idTicket
            );
        } catch (Throwable $e) {
            error_log(
                'Error al configurar correos del solicitante: '
                . $e->getMessage()
            );
            redirigirPortalSolicitante(
                'error_notificaciones',
                'tickets',
                $idTicket
            );
        }
    }

    if ($accion === 'calificar_cerrar') {
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $calificacionArea = filter_input(INPUT_POST, 'calificacion_area', FILTER_VALIDATE_INT) ?: 0;
        $calificacionTiempo = filter_input(INPUT_POST, 'calificacion_tiempo', FILTER_VALIDATE_INT) ?: 0;
        $comentario = trim((string) ($_POST['comentario_calificacion'] ?? ''));

        if (
            $idTicket < 1
            || $idTicketEtapa < 1
            || $calificacionArea < 1
            || $calificacionArea > 5
            || $calificacionTiempo < 1
            || $calificacionTiempo > 5
            || strlen($comentario) > 1000
        ) {
            redirigirPortalSolicitante('calificacion_invalida', 'tickets', $idTicket);
        }

        try {
            paisExigirTicket($conn, $idTicket);

            if (!flujoPuedeVerTicket($conn, $idTicket, $idUsuario, 3)) {
                throw new RuntimeException('La solicitud no pertenece a su usuario.');
            }

            flujoCompletarEtapa(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                3,
                $calificacionArea,
                $calificacionTiempo,
                $comentario
            );

            $ticketActualizado = flujoObtenerTicket($conn, $idTicket);
            $mensaje = (string) ($ticketActualizado['estado_flujo'] ?? '') === 'cerrado'
                ? 'ticket_cerrado'
                : 'caso_calificado';
            redirigirPortalSolicitante($mensaje, 'tickets', $idTicket);
        } catch (Throwable $e) {
            error_log('Error al calificar el caso: ' . $e->getMessage());
            $_SESSION['error_portal_solicitante'] = $e instanceof RuntimeException
                ? $e->getMessage()
                : '';
            redirigirPortalSolicitante('error_calificacion', 'tickets', $idTicket);
        }
    }

    if ($accion === 'reabrir_caso') {
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $motivo = trim((string) ($_POST['motivo_reapertura'] ?? ''));

        if ($idTicket < 1 || $idTicketEtapa < 1 || $motivo === '' || strlen($motivo) > 1000) {
            redirigirPortalSolicitante('reapertura_invalida', 'tickets', $idTicket);
        }

        try {
            paisExigirTicket($conn, $idTicket);

            if (!flujoPuedeVerTicket($conn, $idTicket, $idUsuario, 3)) {
                throw new RuntimeException('La solicitud no pertenece a su usuario.');
            }

            flujoReabrirDerivacion(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                3,
                $motivo
            );
            redirigirPortalSolicitante('caso_reabierto', 'tickets', $idTicket);
        } catch (Throwable $e) {
            error_log('Error al reabrir el caso: ' . $e->getMessage());
            $_SESSION['error_portal_solicitante'] = $e instanceof RuntimeException
                ? $e->getMessage()
                : '';
            redirigirPortalSolicitante('error_reapertura', 'tickets', $idTicket);
        }
    }

    if ($accion === 'enviar_mensaje') {
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $mensaje = trim((string) ($_POST['mensaje'] ?? ''));

        try {
            paisExigirTicket($conn, $idTicket);
            $ticket = flujoObtenerTicket($conn, $idTicket);

            if (
                !$ticket
                || !flujoPuedeVerTicket($conn, $idTicket, $idUsuario, 3)
            ) {
                throw new RuntimeException(
                    'La solicitud no pertenece a su usuario.'
                );
            }

            flujoEnviarConversacion(
                $conn,
                $ticket,
                $idTicketEtapa,
                $idUsuario,
                3,
                $mensaje,
                isset($_FILES['adjuntos'])
                    ? (array) $_FILES['adjuntos']
                    : []
            );

            if (solicitudChatPortalEsAjax()) {
                responderChatPortalJson(true, 'Mensaje enviado.');
            }

            redirigirPortalSolicitante(
                'mensaje_enviado',
                'tickets',
                $idTicket,
                $idTicketEtapa,
                'conversacion-solicitante'
            );
        } catch (Throwable $e) {
            error_log(
                'Error al enviar mensaje del solicitante: '
                . $e->getMessage()
            );

            if (solicitudChatPortalEsAjax()) {
                responderChatPortalJson(
                    false,
                    $e instanceof RuntimeException
                        ? $e->getMessage()
                        : 'No fue posible enviar el mensaje.',
                    422
                );
            }

            $_SESSION['error_portal_solicitante'] = $e instanceof RuntimeException
                ? $e->getMessage()
                : '';
            redirigirPortalSolicitante(
                'error_mensaje',
                'tickets',
                $idTicket,
                $idTicketEtapa,
                'conversacion-solicitante'
            );
        }
    }

    if ($accion !== 'crear_ticket') {
        redirigirPortalSolicitante('accion_no_permitida', 'tickets');
    }

    $tokenCreacionRecibido = (string) (
        $_POST['solicitud_creacion_token'] ?? ''
    );

    if (
        $tokenCreacionRecibido === ''
        || !hash_equals($tokenCreacionSolicitud, $tokenCreacionRecibido)
    ) {
        redirigirPortalSolicitante('solicitud_duplicada', 'tickets');
    }

    // Se consume antes de iniciar la operación para impedir reenvíos.
    unset($_SESSION['solicitud_creacion_token']);

    $idCatalogo = filter_input(INPUT_POST, 'id_catalogo', FILTER_VALIDATE_INT) ?: 0;
    $idProceso = filter_input(INPUT_POST, 'id_proceso', FILTER_VALIDATE_INT) ?: 0;
    $idServicio = filter_input(INPUT_POST, 'id_servicio', FILTER_VALIDATE_INT) ?: 0;
    $usaProceso = (string) ($_POST['usa_proceso'] ?? '') === '1';
    $titulo = trim((string) ($_POST['titulo'] ?? ''));
    $descripcion = trim((string) ($_POST['descripcion'] ?? ''));
    $camposExtrasRecibidos = is_array($_POST['campos_extras'] ?? null)
        ? $_POST['campos_extras']
        : [];

    if (
        $idCatalogo < 1
        || $idProceso < 1
        || $idServicio < 1
        || $titulo === ''
        || $descripcion === ''
        || strlen($titulo) > 180
        || strlen($descripcion) > 15000
    ) {
        redirigirPortalSolicitante('datos_incompletos', 'nueva');
    }

    if (
        $esGestorEnModoSolicitante
        && isset($serviciosGestionadosPorUsuario[$idServicio])
    ) {
        redirigirPortalSolicitante('servicio_no_disponible', 'nueva');
    }

    $stmtServicioCatalogo = $conn->prepare(
        "SELECT 1
         FROM servicios AS s
         INNER JOIN catalogos AS c
            ON c.id_catalogo = s.id_catalogo
           AND c.estado = 'activo'
         WHERE s.id_servicio = ?
           AND s.id_pais_operacion = ?
           AND s.estado = 'activo'
           AND c.id_catalogo = ?
           AND c.id_pais_operacion = ?
         LIMIT 1"
    );
    $stmtServicioCatalogo->bind_param(
        'iiii',
        $idServicio,
        $idPaisOperacion,
        $idCatalogo,
        $idPaisOperacion
    );
    $stmtServicioCatalogo->execute();
    $stmtServicioCatalogo->store_result();
    $servicioPerteneceCatalogo = $stmtServicioCatalogo->num_rows > 0;
    $stmtServicioCatalogo->close();

    if (!$servicioPerteneceCatalogo) {
        redirigirPortalSolicitante('servicio_no_disponible', 'nueva');
    }

    $servicioPerteneceFlujo = false;

    if ($usaProceso) {
        $stmtServicioProceso = $conn->prepare(
            "SELECT 1
             FROM procesos AS p
             INNER JOIN proceso_etapas AS pe
                ON pe.id_proceso = p.id_proceso
             WHERE p.id_proceso = ?
               AND p.id_pais_operacion = ?
               AND p.estado = 'activo'
               AND pe.id_servicio = ?
               AND pe.estado = 'activo'
               AND pe.orden = (
                    SELECT MIN(pe_inicio.orden)
                    FROM proceso_etapas AS pe_inicio
                    WHERE pe_inicio.id_proceso = pe.id_proceso
                      AND pe_inicio.estado = 'activo'
               )
             LIMIT 1"
        );
        $stmtServicioProceso->bind_param('iii', $idProceso, $idPaisOperacion, $idServicio);
        $stmtServicioProceso->execute();
        $stmtServicioProceso->store_result();
        $servicioPerteneceFlujo = $stmtServicioProceso->num_rows === 1;
        $stmtServicioProceso->close();
    } elseif (!$usaProceso && $idProceso === $idServicio) {
        $stmtServicioConProceso = $conn->prepare(
            "SELECT 1
             FROM proceso_etapas AS pe
             INNER JOIN procesos AS p
                ON p.id_proceso = pe.id_proceso
               AND p.estado = 'activo'
               AND p.id_pais_operacion = ?
             WHERE pe.id_servicio = ?
               AND pe.estado = 'activo'
             LIMIT 1"
        );
        $stmtServicioConProceso->bind_param('ii', $idPaisOperacion, $idServicio);
        $stmtServicioConProceso->execute();
        $stmtServicioConProceso->store_result();
        $servicioPerteneceFlujo = $stmtServicioConProceso->num_rows === 0;
        $stmtServicioConProceso->close();
    }

    if (!$servicioPerteneceFlujo) {
        redirigirPortalSolicitante('servicio_no_disponible', 'nueva');
    }

    try {
        $idTicketNuevo = flujoCrearTicket(
            $conn,
            $idProceso,
            $idUsuario,
            $titulo,
            $descripcion,
            'media',
            $idServicio,
            $usaProceso,
            $camposExtrasRecibidos
        );
        $etapaInicial = flujoEtapaActual($conn, $idTicketNuevo);
        $mensaje = 'ticket_creado';

        if ($etapaInicial && isset($_FILES['adjuntos'])) {
            try {
                if (almacenamientoUsaGraph()) {
                    almacenamientoPrepararEsquema($conn);
                }
                $conn->begin_transaction();
                flujoGuardarAdjuntos(
                    $conn,
                    $idTicketNuevo,
                    (int) $etapaInicial['id_ticket_etapa'],
                    $idUsuario,
                    $_FILES['adjuntos']
                );
                $conn->commit();
            } catch (Throwable $errorAdjunto) {
                try { $conn->rollback(); } catch (Throwable $ignorado) {}
                error_log(
                    'Ticket creado sin uno o más adjuntos: '
                    . $errorAdjunto->getMessage()
                );
                $mensaje = 'ticket_creado_sin_adjuntos';
            }
        }

        redirigirPortalSolicitante($mensaje, 'tickets', $idTicketNuevo);
    } catch (Throwable $e) {
        error_log('Error al crear ticket del solicitante: ' . $e->getMessage());
        $_SESSION['error_portal_solicitante'] = $e instanceof RuntimeException
            ? $e->getMessage()
            : '';
        redirigirPortalSolicitante('error_operacion', 'nueva');
    }
}

$vista = (string) ($_GET['vista'] ?? 'tickets');

if (!in_array($vista, ['nueva', 'tickets'], true)) {
    $vista = 'tickets';
}

$busquedaCasos = trim((string) ($_GET['buscar'] ?? ''));

if (strlen($busquedaCasos) > 120) {
    $busquedaCasos = substr($busquedaCasos, 0, 120);
}

$estadoBusquedaCasos = (string) ($_GET['estado_busqueda'] ?? 'activo');
$estadoBusquedaCasos = (fn ($__mesaMatchValue34) => (($__mesaMatchValue34 === ('abierto') || $__mesaMatchValue34 === ('en_proceso')) ? ('activo') : ((($__mesaMatchValue34 === ('pendiente_calificacion')) ? ('pendiente') : ((($__mesaMatchValue34 === ('cancelado')) ? ('cerrado') : ($estadoBusquedaCasos)))))))($estadoBusquedaCasos);
$estadosBusquedaPermitidos = [
    'todos',
    'activo',
    'pendiente',
    'cerrado',
];

if (!in_array($estadoBusquedaCasos, $estadosBusquedaPermitidos, true)) {
    $estadoBusquedaCasos = 'activo';
}

$mensajes = [
    'ticket_creado' => ['ok', 'La solicitud fue creada y asignada correctamente.'],
    'ticket_creado_sin_adjuntos' => ['aviso', 'La solicitud fue creada, pero uno o más archivos no pudieron guardarse.'],
    'caso_calificado' => ['ok', 'La etapa fue aprobada y el mismo caso continúa con la siguiente etapa.'],
    'ticket_cerrado' => ['ok', 'La calificación fue registrada y el caso quedó cerrado completamente.'],
    'calificacion_invalida' => ['error', 'Califique de 1 a 5 la gestión y el tiempo de respuesta.'],
    'error_calificacion' => ['error', 'No fue posible guardar la calificación ni cerrar el caso.'],
    'caso_reabierto' => ['ok', 'La etapa del caso fue reabierta y regresó al gestor asignado.'],
    'mensaje_enviado' => ['ok', 'El mensaje fue enviado al gestor de la etapa.'],
    'error_mensaje' => ['error', 'No fue posible enviar el mensaje.'],
    'notificaciones_activadas' => ['ok', 'Recibirá correos por cada nueva acción pública del caso.'],
    'notificaciones_desactivadas' => ['aviso', 'Las notificaciones por correo de este caso fueron desactivadas.'],
    'error_notificaciones' => ['error', 'No fue posible cambiar las notificaciones por correo.'],
    'reapertura_invalida' => ['error', 'Explique por qué la solución no resolvió la solicitud.'],
    'error_reapertura' => ['error', 'No fue posible reabrir la etapa del caso.'],
    'datos_incompletos' => ['error', 'Complete todos los campos obligatorios.'],
    'servicio_no_disponible' => ['error', 'El servicio seleccionado ya no está disponible.'],
    'solicitud_duplicada' => ['aviso', 'La solicitud ya fue enviada. Se evitó crear un caso duplicado.'],
    'calificacion_pendiente_bloquea_creacion' => [
        'aviso',
        'Debe calificar o devolver las soluciones pendientes antes de crear un caso nuevo.'
    ],
    'solicitud_invalida' => ['error', 'La solicitud no es válida. Actualice la página.'],
    'accion_no_permitida' => ['error', 'Su perfil solo puede crear solicitudes, consultar su estado, conversar con el gestor del flujo y calificar cuando corresponda.'],
    'error_operacion' => ['error', 'No fue posible crear la solicitud. Inténtelo nuevamente.'],
];
$mensajeActual = (string) ($_GET['msg'] ?? '');
$detalleError = trim((string) seguridadConsumirDatoSesion('error_portal_solicitante'));

$catalogosSolicitud = [];
$resultadoCatalogosSolicitud = $conn->query(
    "SELECT id_catalogo, nombre, descripcion, imagen, orden
     FROM catalogos
     WHERE id_pais_operacion = {$idPaisOperacion}
       AND estado = 'activo'
     ORDER BY orden ASC, nombre ASC, id_catalogo ASC"
);

while ($catalogoSolicitud = $resultadoCatalogosSolicitud->fetch_assoc()) {
    $catalogosSolicitud[] = $catalogoSolicitud;
}

$servicios = flujoServiciosDisponibles($conn);
if ($esGestorEnModoSolicitante && $serviciosGestionadosPorUsuario) {
    $servicios = array_values(array_filter(
        $servicios,
        static fn (array $servicio): bool => !isset(
            $serviciosGestionadosPorUsuario[(int) ($servicio['id_servicio'] ?? 0)]
        )
    ));
}
$tickets = flujoTicketsUsuario($conn, $idUsuario, 3);
$proyeccionesTickets = [];
foreach ($tickets as $ticketProyeccion) {
    $idTicketProyeccion = (int) ($ticketProyeccion['id_ticket'] ?? 0);
    if ($idTicketProyeccion > 0) {
        $proyeccionesTickets[$idTicketProyeccion] =
            flujoProyeccionFinalizacionTicket($conn, $idTicketProyeccion);
    }
}
$ticketsConSolucionLista = [];
$idsPendientesCalificacion = casosPendientesCalificacionSolicitante(
    $conn,
    $idUsuario,
    $idPaisOperacion
);

foreach ($idsPendientesCalificacion as $idPendienteCalificacion) {
    $ticketsConSolucionLista[$idPendienteCalificacion] = true;
}

$cantidadPendientesCalificacion = count($idsPendientesCalificacion);
$primerTicketPendienteCalificacion = $idsPendientesCalificacion[0] ?? 0;
$idTicketSeleccionado = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
$idChatSeleccionado = filter_input(INPUT_GET, 'id_chat', FILTER_VALIDATE_INT) ?: 0;
$ticketSeleccionado = null;
$etapasTicket = [];
$etapaPendienteCalificacion = null;
$siguienteEtapaPendienteCalificacion = null;
$conversacionesSolicitante = [];
$conversacionSolicitanteActual = null;
$comunicacionesSolicitante = [];
$adjuntosSolicitante = [];
$eventosConversacionSolicitante = [];
$historialAccionesSolicitante = [];
$puedeEscribirSolicitante = false;
$notificacionesEmailSolicitante = true;

if ($idTicketSeleccionado > 0) {
    paisExigirTicket($conn, $idTicketSeleccionado);

    if (!flujoPuedeVerTicket($conn, $idTicketSeleccionado, $idUsuario, 3)) {
        http_response_code(403);
        exit('La solicitud no existe o no pertenece a su usuario.');
    }

    $ticketSeleccionado = flujoObtenerTicket($conn, $idTicketSeleccionado);
    $notificacionesEmailSolicitante =
        flujoNotificacionesEmailHabilitadas(
            $conn,
            $idTicketSeleccionado,
            $idUsuario
        );
    $todasLasEtapasTicket = flujoObtenerEtapasTicket(
        $conn,
        $idTicketSeleccionado
    );
    $stmtHistorialSolicitante = $conn->prepare(
        "SELECT h.id_historial, h.accion, h.detalle, h.creado_en,
                COALESCE(u.nombre, 'Sistema') AS usuario,
                COALESCE(u.id_rol, 0) AS usuario_rol
         FROM solicitud_historial AS h
         LEFT JOIN usuarios AS u ON u.id_usuario = h.id_usuario
         WHERE h.id_ticket = ?
         ORDER BY h.creado_en, h.id_historial"
    );
    if ($stmtHistorialSolicitante) {
        $stmtHistorialSolicitante->bind_param('i', $idTicketSeleccionado);
        $stmtHistorialSolicitante->execute();
        $resultadoHistorialSolicitante = $stmtHistorialSolicitante->get_result();
        while ($filaHistorialSolicitante = $resultadoHistorialSolicitante->fetch_assoc()) {
            $historialAccionesSolicitante[] = $filaHistorialSolicitante;
        }
        $stmtHistorialSolicitante->close();
    }
    $etapasTicket = array_values(array_filter(
        $todasLasEtapasTicket,
        static fn (array $etapa): bool =>
            (int) ($etapa['id_ticket_etapa_padre'] ?? 0) === 0
    ));

    /*
     * Vista pública de la atención. Incluye las etapas principales y sus
     * derivaciones, pero únicamente expone área, servicio, estado, solución y
     * observación de cierre. Nunca se muestran checklist ni notas internas.
     */
    $trazabilidadSolucionesSolicitante = [];
    $etapasSolicitantePorPadre = [];
    foreach ($todasLasEtapasTicket as $etapaTrazabilidad) {
        $idPadreTrazabilidad = (int) (
            $etapaTrazabilidad['id_ticket_etapa_padre'] ?? 0
        );
        $etapasSolicitantePorPadre[$idPadreTrazabilidad][] = $etapaTrazabilidad;
    }

    $agregarTrazabilidadSolicitante = null;
    $agregarTrazabilidadSolicitante = static function (
        int $idPadre,
        int $nivel,
        string $prefijo,
        int $numeroEtapa
    ) use (
        &$agregarTrazabilidadSolicitante,
        &$trazabilidadSolucionesSolicitante,
        $etapasSolicitantePorPadre
    ): void {
        $hijos = $etapasSolicitantePorPadre[$idPadre] ?? [];
        foreach ($hijos as $indiceHijo => $nodo) {
            $numeroNodo = $indiceHijo + 1;
            $codigoNodo = $prefijo === ''
                ? (string) $numeroNodo
                : $prefijo . '.' . $numeroNodo;
            $nodo['_nivel_trazabilidad'] = $nivel;
            $nodo['_codigo_trazabilidad'] = $codigoNodo;
            $nodo['_numero_etapa_trazabilidad'] = $nivel === 0
                ? $numeroNodo
                : $numeroEtapa;
            $nodo['_es_derivacion_trazabilidad'] = $nivel > 0;
            $nodo['_etiqueta_trazabilidad'] = $nivel === 0
                ? 'Etapa ' . $codigoNodo
                : 'Apoyo de otro proceso · ' . $codigoNodo;
            $trazabilidadSolucionesSolicitante[] = $nodo;

            $idNodo = (int) ($nodo['id_ticket_etapa'] ?? 0);
            if ($idNodo > 0) {
                $agregarTrazabilidadSolicitante(
                    $idNodo,
                    $nivel + 1,
                    $codigoNodo,
                    $nivel === 0 ? $numeroNodo : $numeroEtapa
                );
            }
        }
    };
    $agregarTrazabilidadSolicitante(0, 0, '', 0);

    $solucionFinalSolicitante = null;
    foreach ($etapasTicket as $etapaConSolucion) {
        $nombreSolucionPublica = trim((string) (
            $etapaConSolucion['solucion_nombre'] ?? ''
        ));
        $observacionPublica = trim((string) (
            $etapaConSolucion['comentario_cierre'] ?? ''
        ));
        if ($nombreSolucionPublica !== '' || $observacionPublica !== '') {
            $solucionFinalSolicitante = $etapaConSolucion;
        }
    }

    foreach ($etapasTicket as $etapaTicket) {
        $idCreadorCaso = (int) (
            $etapaTicket['creado_por']
            ?? $ticketSeleccionado['id_usuario']
            ?? 0
        );

        if (
            (string) ($etapaTicket['estado'] ?? '') === 'listo_cierre'
            && (int) ($etapaTicket['id_ticket_etapa_padre'] ?? 0) === 0
            && $idCreadorCaso === $idUsuario
        ) {
            $etapaPendienteCalificacion = $etapaTicket;
            break;
        }
    }

    if ($etapaPendienteCalificacion) {
        $ordenEtapaPendiente = (int) ($etapaPendienteCalificacion['orden'] ?? 0);

        foreach ($etapasTicket as $posibleSiguienteEtapa) {
            if (
                (int) ($posibleSiguienteEtapa['orden'] ?? 0) > $ordenEtapaPendiente
                && (string) ($posibleSiguienteEtapa['estado'] ?? '') === 'bloqueada'
            ) {
                $siguienteEtapaPendienteCalificacion = $posibleSiguienteEtapa;
                break;
            }
        }
    }

    $conversacionesSolicitante = array_values(array_filter(
        flujoConversacionesDisponibles(
            $conn,
            $idTicketSeleccionado,
            $idUsuario,
            3
        ),
        static fn (array $conversacion): bool =>
            (string) ($conversacion['tipo_conversacion'] ?? '') === 'flujo'
    ));

    if ($idChatSeleccionado > 0) {
        foreach ($conversacionesSolicitante as $conversacionSolicitante) {
            if (
                (int) $conversacionSolicitante['id_ticket_etapa']
                === $idChatSeleccionado
            ) {
                $conversacionSolicitanteActual = $conversacionSolicitante;
                break;
            }
        }
    }

    if (!$conversacionSolicitanteActual) {
        foreach ($conversacionesSolicitante as $conversacionSolicitante) {
            if (in_array(
                (string) ($conversacionSolicitante['estado'] ?? ''),
                ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada'],
                true
            )) {
                $conversacionSolicitanteActual = $conversacionSolicitante;
                break;
            }
        }
    }

    if (!$conversacionSolicitanteActual && $conversacionesSolicitante) {
        $conversacionSolicitanteActual = $conversacionesSolicitante[
            count($conversacionesSolicitante) - 1
        ];
    }

    if ($conversacionSolicitanteActual) {
        $idConversacionSolicitante = (int) (
            $conversacionSolicitanteActual['id_ticket_etapa'] ?? 0
        );

        if (!flujoPuedeVerConversacionNodo(
            $conn,
            $idTicketSeleccionado,
            $idConversacionSolicitante,
            $idUsuario,
            3
        )) {
            http_response_code(403);
            exit('No tiene acceso a esta conversación.');
        }

        $comunicacionesSolicitante = flujoComunicacionesNodo(
            $conn,
            $idTicketSeleccionado,
            $idConversacionSolicitante
        );
        $adjuntosSolicitante = flujoAdjuntosNodo(
            $conn,
            $idTicketSeleccionado,
            $idConversacionSolicitante
        );
        $eventosConversacionSolicitante = flujoLineaTiempoConversacion(
            $comunicacionesSolicitante,
            $adjuntosSolicitante
        );
        $puedeEscribirSolicitante = flujoPuedeEscribirNodo(
            $conn,
            $ticketSeleccionado,
            $idConversacionSolicitante,
            $idUsuario,
            3
        );
    }

    flujoMarcarNotificacionesContenidoVisto(
        $conn,
        $idUsuario,
        $idTicketSeleccionado,
        false
    );
}

$resumen = ['total' => count($tickets), 'activos' => 0, 'listos' => 0, 'cerrados' => 0];

foreach ($tickets as $ticketResumen) {
    $estado = strtolower(trim((string) ($ticketResumen['estado_flujo'] ?? 'en_proceso')));
    $idTicketResumen = (int) ($ticketResumen['id_ticket'] ?? 0);

    if (in_array($estado, ['cerrado', 'cerrada', 'cancelado', 'cancelada'], true)) {
        $resumen['cerrados']++;
    } elseif (isset($ticketsConSolucionLista[$idTicketResumen])) {
        $resumen['listos']++;
    } else {
        $resumen['activos']++;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Portal del solicitante | SMARTDESK</title>
    <style>
        :root{--primary:#0f6fec;--primary-dark:#0b4fae;--navy:#102a43;--text:#304b63;--muted:#526d82;--border:#dce6f0;--surface:#fff;--soft:#eef5ff;--bg:#f3f6fb;--ok:#087443;--warn:#9a6500;--danger:#b42318}
        *{box-sizing:border-box}body{margin:0;color:var(--text);background:linear-gradient(135deg,#f7fafe,#edf3f9);font:13px/1.45 Inter,"Segoe UI",Arial,sans-serif}.shell{width:min(1400px,calc(100% - 24px));margin:auto;padding:12px 0 30px;transition:width .25s ease}.topbar,.card,.stat,.alert{border:1px solid var(--border);background:var(--surface);box-shadow:0 8px 24px rgba(16,42,67,.06)}.topbar{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:10px 12px;border-radius:14px}.brand{display:flex;align-items:center;gap:10px}.mark{width:38px;height:38px;display:grid;place-items:center;border-radius:11px;color:#fff;background:linear-gradient(145deg,var(--primary),var(--primary-dark));font-weight:900}.brand strong{display:block;color:var(--navy);font-size:14px}.brand small{color:var(--muted);font-size:10px}.logout,.btn,.tab{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;font-weight:800}.logout{min-height:34px;padding:7px 11px;border:1px solid #eed9d9;border-radius:9px;color:#a73535;background:#fff8f8}.tabs{display:flex;gap:7px;margin-top:10px;padding:7px;border:1px solid var(--border);border-radius:12px;background:#fff}.tab{min-height:36px;padding:8px 13px;border-radius:8px;color:#486985}.tab.active,.tab:hover{color:#fff;background:var(--primary)}.grid-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:10px 0}.stat{padding:12px;border-radius:11px}.stat span{display:block;color:var(--muted);font-size:10px}.stat strong{display:block;margin-top:2px;color:var(--navy);font-size:22px}.card{margin-top:10px;padding:17px;border-radius:14px}.card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:15px}.card h1,.card h2{margin:0;color:var(--navy)}.card h1{font-size:22px}.card h2{font-size:17px}.muted{margin:4px 0 0;color:var(--muted)}.alert{margin-top:10px;padding:10px 12px;border-radius:10px}.alert.ok{border-color:#bfe9d2;color:var(--ok);background:#effbf4}.alert.aviso{border-color:#f1db9b;color:var(--warn);background:#fff9e9}.alert.error{border-color:#f0c4c1;color:var(--danger);background:#fff4f3}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.field{display:grid;gap:6px}.field.full{grid-column:1/-1}.field label{color:var(--navy);font-size:11px;font-weight:850}.field input,.field select,.field textarea{width:100%;padding:10px 11px;border:1px solid #cfddea;border-radius:9px;color:var(--text);background:#fff;outline:none}.field textarea{min-height:130px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--primary);box-shadow:0 0 0 3px color-mix(in srgb,var(--primary) 13%,transparent)}.help{color:var(--muted);font-size:10px}.actions{display:flex;justify-content:flex-end;margin-top:14px}.btn{min-height:38px;padding:9px 15px;border:0;border-radius:9px;cursor:pointer}.btn.primary{color:#fff;background:var(--primary)}.table-wrap{overflow:auto;border:1px solid var(--border);border-radius:11px}table{width:100%;border-collapse:collapse;min-width:760px}th,td{padding:11px 12px;border-bottom:1px solid #edf2f7;text-align:left;vertical-align:middle}th{color:#52708c;background:#f7faff;font-size:10px;text-transform:uppercase;letter-spacing:.05em}td strong{color:var(--navy)}.status{display:inline-flex;padding:4px 8px;border-radius:999px;color:#255a83;background:#eaf4ff;font-size:10px;font-weight:850}.status.cerrado,.status.completada{color:#087443;background:#eaf8f1}.status.cancelado,.status.cancelada{color:#a73535;background:#fff0f0}.view-link{display:inline-flex;padding:6px 9px;border:1px solid #cfe0ef;border-radius:7px;color:var(--primary);text-decoration:none;font-size:10px;font-weight:850}.empty{padding:25px;color:var(--muted);text-align:center}.detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:13px}.detail-item{padding:10px;border:1px solid var(--border);border-radius:9px;background:#f9fbfd}.detail-item span{display:block;color:var(--muted);font-size:9px}.detail-item strong{display:block;margin-top:3px;color:var(--navy);font-size:12px}.case-list{display:grid;gap:7px;margin-top:14px}.case{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr) auto;gap:10px;align-items:center;padding:11px;border:1px solid var(--border);border-radius:10px;background:#fff}.case strong,.case span{display:block}.case small{color:var(--muted)}.case-manager{width:max-content;max-width:100%;display:grid;gap:1px;padding:6px 10px;border:1px solid color-mix(in srgb,var(--primary) 26%,var(--border));border-radius:9px;background:color-mix(in srgb,var(--primary) 7%,var(--surface))}.case-manager span{color:var(--muted);font-size:9px;font-weight:800}.case-manager strong{overflow:hidden;color:var(--navy);font-size:12px;text-overflow:ellipsis;white-space:nowrap}.case-manager-placeholder{min-height:1px}@media(max-width:760px){.topbar,.card-head{align-items:stretch;flex-direction:column}.tabs{overflow:auto}.grid-stats,.detail-grid{grid-template-columns:1fr 1fr}.form-grid{grid-template-columns:1fr}.field.full{grid-column:auto}.case{grid-template-columns:1fr}.case-manager{width:100%}.case-manager-placeholder{display:none}.shell{width:calc(100% - 12px)}}
    </style>
    <style>
        .rating-card{margin-top:15px;padding:15px;border:1px solid color-mix(in srgb,var(--primary) 28%,#dce6f0);border-radius:12px;background:color-mix(in srgb,var(--primary) 5%,#fff)}
        .rating-card h3{margin:0;color:var(--navy);font-size:16px}.rating-card>p{margin:5px 0 12px;color:var(--muted)}.solution-context{display:grid;grid-template-columns:minmax(180px,.85fr) minmax(260px,1.4fr);gap:9px;margin:12px 0}.solution-context-item{padding:11px 12px;border:1px solid color-mix(in srgb,var(--primary) 24%,var(--border));border-radius:10px;background:color-mix(in srgb,var(--primary) 5%,var(--surface))}.solution-context-item span{display:block;color:var(--muted);font-size:9px;font-weight:850;letter-spacing:.05em;text-transform:uppercase}.solution-context-item strong{display:block;margin-top:4px;color:var(--navy);font-size:12px}.solution-context-item p{margin:4px 0 0;color:var(--text);font-size:11px;line-height:1.45}.solution-context-item.outcome{border-left:4px solid var(--primary)}.solution-context-item.outcome.definitive{border-left-color:var(--warn)}.definitive-close-alert{margin:12px 0;padding:14px 15px;border:2px solid color-mix(in srgb,var(--warn) 65%,var(--border));border-radius:11px;color:var(--text);background:color-mix(in srgb,var(--warn) 10%,var(--surface))}.definitive-close-alert strong{display:block;margin-bottom:4px;color:var(--navy);font-size:14px}.definitive-close-alert p{margin:0;font-size:13px;line-height:1.5}.solution-box{margin-bottom:12px;padding:11px;border:1px solid var(--border);border-radius:9px;background:var(--surface)}.solution-box span{display:block;color:var(--muted);font-size:9px;text-transform:uppercase}.solution-box strong{display:block;margin-top:3px;color:var(--navy)}.solution-box p{margin:7px 0 0;white-space:pre-line}.rating-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.rating-grid .field:last-child{grid-column:1/-1}.rating-grid textarea{min-height:82px}.reopen-form{margin-top:13px;padding-top:13px;border-top:1px solid var(--border)}.reopen-form .reopen-title{display:block;color:var(--danger);font-weight:850}.reopen-form p{margin:3px 0 9px;color:var(--muted)}.btn.reopen{border:1px solid #efc4c1;color:var(--danger);background:#fff4f3}@media(max-width:620px){.solution-context,.rating-grid{grid-template-columns:1fr}.rating-grid .field:last-child{grid-column:auto}}
        .public-resolution{margin-top:14px;padding:14px;border:1px solid color-mix(in srgb,var(--ok) 32%,var(--border));border-left:4px solid var(--ok);border-radius:11px;background:color-mix(in srgb,var(--ok) 5%,var(--surface))}.public-resolution-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:10px}.public-resolution-head h3,.public-trace-head h3{margin:0;color:var(--navy);font-size:15px}.public-resolution-head p,.public-trace-head p{margin:3px 0 0;color:var(--muted);font-size:10px}.public-resolution-area{flex:0 0 auto;padding:5px 8px;border-radius:999px;color:var(--ok);background:#eaf8f1;font-size:9px;font-weight:850}.public-resolution-grid{display:grid;grid-template-columns:minmax(180px,.8fr) minmax(0,1.5fr);gap:9px}.public-resolution-item{padding:10px 11px;border:1px solid var(--border);border-radius:9px;background:var(--surface)}.public-resolution-item.observation{grid-column:1/-1}.public-resolution-item span,.public-trace-answer span{display:block;color:var(--muted);font-size:9px;font-weight:850;letter-spacing:.04em;text-transform:uppercase}.public-resolution-item strong{display:block;margin-top:3px;color:var(--navy)}.public-resolution-item p,.public-trace-answer p{margin:4px 0 0;line-height:1.5;overflow-wrap:anywhere;white-space:pre-line}.public-resolution-empty{margin:0;color:var(--muted)}.public-trace{margin-top:14px;padding:14px;border:1px solid var(--border);border-radius:11px;background:#f9fbfd}.public-trace-head{margin-bottom:11px}.public-trace-list{display:grid;gap:8px}.public-trace-node{position:relative;margin-left:min(calc(var(--trace-level,0) * 24px),72px);padding:11px 12px;border:1px solid var(--border);border-radius:10px;background:var(--surface)}.public-trace-node.derived{border-left:4px solid var(--primary);background:color-mix(in srgb,var(--primary) 3%,var(--surface))}.public-trace-node-head{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:start}.public-trace-label{display:flex;flex-wrap:wrap;align-items:center;gap:6px}.public-trace-label strong{color:var(--navy)}.public-trace-kind{padding:3px 6px;border-radius:999px;color:var(--primary);background:color-mix(in srgb,var(--primary) 10%,var(--surface));font-size:8px;font-weight:850;text-transform:uppercase}.public-trace-service{display:block;margin-top:2px;color:var(--muted);font-size:10px}.public-trace-answers{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:9px}.public-trace-answer{padding:9px;border:1px solid #e4edf5;border-radius:8px;background:#fbfdff}.public-trace-answer.pending{grid-column:1/-1;color:var(--muted)}@media(max-width:620px){.public-resolution-head{display:block}.public-resolution-area{display:inline-flex;margin-top:7px}.public-resolution-grid,.public-trace-answers{grid-template-columns:1fr}.public-resolution-item.observation,.public-trace-answer.pending{grid-column:auto}.public-trace-node{margin-left:min(calc(var(--trace-level,0) * 12px),36px)}}
        .solution-context-item.outcome{--context-accent:var(--primary);position:relative;padding-right:48px;border-color:color-mix(in srgb,var(--context-accent) 42%,var(--border));border-left:5px solid var(--context-accent);background:color-mix(in srgb,var(--context-accent) 10%,var(--surface));box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--context-accent) 7%,transparent)}
        .solution-context-item.outcome::after{content:"";position:absolute;top:13px;right:14px;width:18px;height:18px;border:5px solid color-mix(in srgb,var(--context-accent) 22%,var(--surface));border-radius:50%;background:var(--context-accent);box-shadow:0 0 0 1px color-mix(in srgb,var(--context-accent) 72%,var(--border))}
        .solution-context-item.outcome.continue{--context-accent:var(--primary)}
        .solution-context-item.outcome.final{--context-accent:var(--ok)}
        .solution-context-item.outcome.definitive{--context-accent:var(--warn)}
        .solution-context-item.outcome>span,.solution-context-item.outcome>strong{color:var(--context-accent)}
        .rating-card.continue{--rating-accent:var(--primary)}
        .rating-card.final{--rating-accent:var(--ok)}
        .rating-card.definitive{--rating-accent:var(--warn)}
        .rating-card.continue,.rating-card.final,.rating-card.definitive{border-color:color-mix(in srgb,var(--rating-accent) 46%,var(--border));background:color-mix(in srgb,var(--rating-accent) 5%,var(--surface))}
        .rating-card.continue>h3,.rating-card.final>h3,.rating-card.definitive>h3{color:var(--rating-accent)}
    </style>
    <style>
        .catalog-picker{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:9px}.catalog-choice{position:relative;display:block;min-width:0;cursor:pointer}.catalog-choice input{position:absolute;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none}.catalog-choice-body{display:flex;min-height:86px;align-items:flex-start;gap:10px;padding:10px;border:1px solid #cfdeeb;border-radius:11px;background:#fff;box-shadow:0 5px 14px rgba(16,42,67,.04);transition:border-color .16s ease,box-shadow .16s ease,transform .16s ease}.catalog-choice:hover .catalog-choice-body{transform:translateY(-1px);border-color:color-mix(in srgb,var(--primary) 45%,#cfdeeb);box-shadow:0 8px 18px rgba(16,42,67,.08)}.catalog-choice input:focus-visible+.catalog-choice-body{outline:3px solid color-mix(in srgb,var(--primary) 20%,transparent);outline-offset:2px}.catalog-choice input:checked+.catalog-choice-body{border-color:var(--primary);background:color-mix(in srgb,var(--primary) 6%,#fff);box-shadow:0 0 0 2px color-mix(in srgb,var(--primary) 13%,transparent)}.catalog-choice img{width:40px;height:40px;display:block;flex:0 0 auto;border:1px solid #e0e9f2;border-radius:10px;object-fit:cover;background:#f6f9fc}.catalog-choice-text{min-width:0;display:block;padding-top:1px}.catalog-choice strong{display:block;overflow:hidden;color:var(--navy);font-size:12px;text-overflow:ellipsis;white-space:nowrap}.catalog-choice small{display:-webkit-box;margin-top:4px;overflow:hidden;color:var(--muted);font-size:9px;line-height:1.35;-webkit-box-orient:vertical;-webkit-line-clamp:3}.service-feedback{display:block;min-height:15px;margin-top:1px;color:var(--muted);font-size:10px}.service-feedback.warning{color:var(--warn)}@media(max-width:620px){.catalog-picker{grid-template-columns:1fr 1fr}.catalog-choice-body{min-height:82px;padding:8px}.catalog-choice img{width:34px;height:34px}}@media(max-width:410px){.catalog-picker{grid-template-columns:1fr}}
    </style>
    <style>
        .catalog-picker{grid-template-columns:repeat(auto-fit,minmax(175px,1fr));gap:10px}
        .catalog-choice-body{min-height:170px;display:grid;grid-template-rows:auto 98px minmax(26px,auto);gap:7px;align-items:start;padding:9px}
        .catalog-choice-title{display:block;min-width:0}
        .catalog-choice strong{font-size:13px;line-height:1.3}
        .catalog-choice-media{width:100%;height:98px;display:block;overflow:hidden;border:1px solid #e0e9f2;border-radius:9px;background:#f6f9fc}
        .catalog-choice .catalog-choice-media img{width:100%;height:100%;margin:0;border:0;border-radius:0;object-fit:cover;object-position:center;background:transparent}
        .catalog-choice small{margin:0;-webkit-line-clamp:2}
        @media(max-width:620px){
            .catalog-picker{grid-template-columns:1fr 1fr}
            .catalog-choice-body{min-height:158px;grid-template-rows:auto 88px minmax(26px,auto);padding:8px}
            .catalog-choice-media{height:88px}
            .catalog-choice .catalog-choice-media img{width:100%;height:100%}
        }
        @media(max-width:430px){.catalog-picker{grid-template-columns:1fr}}
    </style>
    <style>
        .service-selection-layout{
            grid-column:1/-1;
            width:100%;
            min-width:0;
            display:grid;
            grid-template-columns:var(--service-selector-width,260px) minmax(0,1fr);
            gap:var(--service-column-gap,10px);
            align-items:start;
        }

        .service-selection-layout>.field{
            width:100%;
            min-width:0;
            display:flex;
            flex-direction:column;
            align-content:start;
        }

        .service-combobox{
            position:relative;
            width:100%;
            min-width:0;
        }

        .service-combobox-control{
            position:relative;
            display:flex;
            align-items:center;
        }

        .field .service-combobox-input{
            min-height:40px;
            padding-right:42px;
        }

        .service-combobox-toggle{
            position:absolute;
            top:5px;
            right:5px;
            width:30px;
            height:30px;
            display:grid;
            place-items:center;
            padding:0;
            border:0;
            border-radius:7px;
            color:var(--primary);
            background:color-mix(in srgb,var(--primary) 9%,var(--surface));
            cursor:pointer;
        }

        .service-combobox-toggle::before{
            content:"⌄";
            font-size:15px;
            font-weight:900;
            line-height:1;
            transition:transform .16s ease;
        }

        .service-combobox.is-open .service-combobox-toggle::before{
            transform:rotate(180deg);
        }

        .service-combobox-toggle:disabled{
            color:var(--muted);
            opacity:.55;
            cursor:not-allowed;
        }

        .service-native-select{
            position:absolute!important;
            width:1px!important;
            height:1px!important;
            margin:0!important;
            padding:0!important;
            overflow:hidden!important;
            clip:rect(0 0 0 0)!important;
            clip-path:inset(50%)!important;
            opacity:0!important;
            pointer-events:none!important;
        }

        .service-combobox-list{
            position:absolute;
            z-index:90;
            top:calc(100% + 5px);
            left:0;
            right:auto;
            width:min(
                var(--service-dropdown-width,720px),
                calc(100vw - var(--service-dropdown-left-space,24px) - 16px)
            );
            display:none;
            /* Diez opciones compactas; las restantes se recorren internamente. */
            max-height:var(--service-dropdown-max-height,381px);
            padding:7px;
            overflow-y:auto;
            overflow-x:hidden;
            overscroll-behavior:contain;
            border:1px solid color-mix(in srgb,var(--primary) 34%,var(--border));
            border-radius:10px;
            background:var(--surface);
            box-shadow:0 14px 32px rgba(16,42,67,.18);
            scrollbar-width:thin;
            scrollbar-color:color-mix(in srgb,var(--primary) 45%,var(--border)) var(--surface);
        }

        .service-combobox.is-open .service-combobox-list{
            display:grid;
            grid-template-columns:minmax(0,1fr);
            align-content:start;
            gap:3px;
        }

        .service-combobox-option{
            width:100%;
            min-height:34px;
            padding:7px 10px;
            border:1px solid transparent;
            border-radius:7px;
            color:var(--text);
            background:transparent;
            font:inherit;
            font-size:11px;
            font-weight:750;
            line-height:1.35;
            text-align:left;
            overflow-wrap:anywhere;
            cursor:pointer;
        }

        .service-combobox-option:hover,
        .service-combobox-option.is-active{
            border-color:color-mix(in srgb,var(--primary) 25%,var(--border));
            color:var(--navy);
            background:color-mix(in srgb,var(--primary) 9%,var(--surface));
        }

        .service-combobox-option[aria-selected="true"]{
            color:var(--primary-dark);
            background:color-mix(in srgb,var(--primary) 13%,var(--surface));
        }

        .service-combobox-empty{
            grid-column:1/-1;
            margin:0;
            padding:11px;
            color:var(--muted);
            font-size:10px;
            line-height:1.45;
            text-align:left;
        }

        .service-summary{
            width:var(--service-summary-width,100%);
            min-width:min(100%,600px);
            max-width:100%;
            min-height:72px;
            margin-top:22px;
            justify-self:stretch;
            overflow:hidden;
            border:1px solid color-mix(in srgb,var(--primary) 24%,var(--border));
            border-radius:12px;
            background:color-mix(in srgb,var(--primary) 4%,var(--surface));
            box-shadow:0 8px 20px rgba(16,42,67,.05);
            transition:width .2s ease,height .2s ease;
        }

        .service-summary.empty{
            width:100%;
            min-width:0;
            min-height:52px;
            max-height:52px;
            display:flex;
            align-items:center;
            justify-content:center;
            border-style:dashed;
            background:color-mix(in srgb,var(--primary) 2%,var(--surface));
        }

.service-summary-copy{
    min-width:0;
    min-height:0;
    display:grid;
    grid-template-rows:auto minmax(0,auto) auto;
    align-content:start;
    gap:7px;
    padding:12px 14px;
    overflow:hidden;
}

.service-summary strong{
    display:block;
    margin:0;
    color:var(--navy);
    font-size:13px;
    line-height:1.3;
    flex:0 0 auto;
}

.service-summary p{
    min-height:0;
    max-height:210px;
    margin:0;
    padding:0 7px 0 0;
    overflow:hidden;
    color:var(--text);
    font-size:12px;  /* Cambiado de 10px a 12px */
    line-height:1.55;
    white-space:pre-line;
    overflow-wrap:anywhere;
    scrollbar-width:thin;
    scrollbar-color:color-mix(in srgb,var(--primary) 34%,var(--border)) color-mix(in srgb,var(--primary) 5%,var(--surface));
}

.service-summary p.is-scrollable{
    overflow-y:auto;
    overscroll-behavior:contain;
}

.service-summary p::-webkit-scrollbar{
    width:6px;
}

.service-summary p::-webkit-scrollbar-track{
    border-radius:999px;
    background:color-mix(in srgb,var(--primary) 5%,var(--surface));
}

.service-summary p::-webkit-scrollbar-thumb{
    border-radius:999px;
    background:color-mix(in srgb,var(--primary) 34%,var(--border));
}

.service-summary.empty .service-summary-copy{
    display:flex;
    align-items:center;
    justify-content:center;
    padding:12px 14px;
    overflow:hidden;
}

.service-summary.empty strong{
    margin:0;
    max-width:100%;
    color:var(--muted);
    font-size:11px;
    font-weight:700;
    line-height:1.5;
    text-align:center;
}

.service-summary [hidden]{
    display:none!important;
}

.service-tags{
    display:flex;
    flex-wrap:wrap;
    align-items:center;
    gap:6px;
    min-height:24px;
    padding-top:2px;
    overflow:visible;
}

.service-tag{
    display:inline-flex;
    align-items:center;
    gap:4px;
    min-height:22px;
    padding:3px 8px;
    border:1px solid #cfe0ef;
    border-radius:999px;
    color:#255a83;
    background:#fff;
    font-size:9px;
    font-weight:850;
}

.service-tag.type{
    color:#6542a6;
    border-color:#ddd0f5;
    background:#f7f2ff;
}

.service-tag.priority{
    color:#9a4c00;
    border-color:#f0d5ae;
    background:#fff8eb;
}

.service-tag.urgency{
    color:#a73535;
    border-color:#efc8c8;
    background:#fff4f4;
}

.service-tag.impact{
    color:#087443;
    border-color:#bfe4d0;
    background:#effaf4;
}

.request-support-grid{
    grid-column:1/-1;
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:13px;
    align-items:start;
}

.request-text-column{
    min-width:0;
    display:grid;
    gap:13px;
    align-content:start;
}

.description-field textarea{
    height:64px;
    min-height:64px;
    max-height:360px;
    resize:none;
    overflow-y:hidden;
    line-height:1.45;
}

.description-field textarea.is-scrollable{
    overflow-y:auto;
}

.file-field{
    min-width:0;
    margin-top:0;
}

.file-input{
    position:absolute!important;
    width:1px!important;
    height:1px!important;
    padding:0!important;
    overflow:hidden;
    clip:rect(0,0,0,0);
    white-space:nowrap;
    border:0!important;
}

.file-dropzone{
    min-height:64px;
    display:flex;
    align-items:center;
    gap:10px;
    padding:9px 11px;
    border:1px dashed #a9c6e2;
    border-radius:10px;
    color:#456985;
    background:#f7faff;
    text-align:left;
    cursor:pointer;
    transition:.18s ease;
}

.file-dropzone:hover,.file-dropzone.dragover{
    border-color:var(--primary);
    background:#edf5ff;
    box-shadow:0 0 0 3px rgba(15,111,236,.07);
}

.upload-icon{
    width:34px;
    height:34px;
    display:grid;
    flex:0 0 auto;
    place-items:center;
    border:1px solid #d8e7f5;
    border-radius:9px;
    color:var(--primary);
    background:#fff;
}

.upload-icon svg{
    width:17px;
    height:17px;
    fill:none;
    stroke:currentColor;
    stroke-width:1.9;
    stroke-linecap:round;
    stroke-linejoin:round;
}

.upload-copy{
    min-width:0;
    flex:1;
}

.upload-copy strong{
    display:block;
    color:var(--navy);
    font-size:11px;
}

.upload-copy span{
    display:block;
    margin-top:1px;
    color:var(--muted);
    font-size:9px;
}

.upload-action{
    display:inline-flex;
    min-height:31px;
    align-items:center;
    justify-content:center;
    padding:7px 11px;
    border-radius:8px;
    color:#fff;
    background:var(--primary);
    font-size:9px;
    font-weight:850;
    white-space:nowrap;
    box-shadow:0 4px 10px rgba(15,111,236,.16);
}

.file-dropzone:hover .upload-action,.file-dropzone.dragover .upload-action{
    background:var(--primary-dark);
}

.file-list{
    display:grid;
    gap:6px;
    margin-top:7px;
}

.file-list[hidden]{
    display:none;
}

.file-item{
    display:grid;
    grid-template-columns:minmax(0,1fr) auto;
    gap:10px;
    align-items:center;
    padding:7px 9px;
    border:1px solid #dbe6f0;
    border-radius:9px;
    background:#fff;
}

.file-item strong{
    display:block;
    overflow:hidden;
    color:var(--navy);
    font-size:10px;
    text-overflow:ellipsis;
    white-space:nowrap;
}

.file-item small{
    display:block;
    margin-top:1px;
    color:var(--muted);
    font-size:9px;
}

.file-remove{
    width:27px;
    height:27px;
    display:grid;
    place-items:center;
    border:1px solid #efd0d0;
    border-radius:8px;
    color:#a73535;
    background:#fff6f6;
    cursor:pointer;
}

.file-status{
    display:block;
    min-height:14px;
    margin-top:4px;
    color:var(--muted);
    font-size:9px;
}

.file-status.error{
    color:var(--danger);
}

.detail-grid{
    grid-template-columns:repeat(auto-fit,minmax(145px,1fr));
}

@media(max-width:760px){
    .service-selection-layout,
    .request-support-grid{
        grid-template-columns:1fr;
    }
    
    .service-summary-copy{
        padding:11px 12px;
    }

    .service-summary{width:100%!important;min-width:0;margin-top:0}

    .service-combobox-list{
        width:100%;
        max-height:var(--service-dropdown-max-height,min(52vh,420px));
    }

    .service-combobox.is-open .service-combobox-list{
        grid-template-columns:1fr;
    }

    .service-summary p{max-height:150px}
    
    .file-dropzone{
        min-height:60px;
    }
}

@media(max-width:480px){
    .file-dropzone{
        align-items:flex-start;
        flex-wrap:wrap;
    }
    
    .upload-copy{
        padding-top:1px;
    }
    
    .upload-action{
        width:100%;
        min-height:30px;
    }
    
    .file-status{
        line-height:1.35;
    }
}
    </style>
    <style>
        .service-summary{grid-template-columns:minmax(0,1fr)}
        .service-summary.empty{place-items:center;text-align:center;display:flex;align-items:center;justify-content:center}
        .service-summary.empty .service-summary-copy{display:flex;align-items:center;justify-content:center;padding:12px 14px}
        .service-summary.empty strong{margin:0;max-width:100%;color:var(--muted);font-size:11px;font-weight:700;line-height:1.5}
        .service-summary [hidden]{display:none!important}
    </style>
    <style>
        .chat-widget{position:fixed;inset:0;z-index:30;pointer-events:none}.chat-launcher{position:absolute;right:28px;bottom:24px;display:flex;align-items:center;gap:10px;min-height:52px;padding:10px 16px 10px 11px;border:0;border-radius:999px;color:#fff;background:linear-gradient(145deg,#0f6fec,#0b4fae);box-shadow:0 14px 30px rgba(7,63,126,.34);font:inherit;font-weight:850;cursor:pointer;pointer-events:auto;transition:transform .18s ease,opacity .18s ease}.chat-launcher:hover{transform:translateY(-2px)}.chat-launcher-icon{width:34px;height:34px;display:grid;place-items:center;border-radius:50%;background:rgba(255,255,255,.17)}.chat-launcher-icon svg,.chat-header-avatar svg,.chat-send svg,.chat-attach svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.chat-launcher-copy{display:grid;text-align:left}.chat-launcher-copy small{font-size:9px;font-weight:650;opacity:.82}.chat-panel{position:absolute;right:20px;bottom:18px;width:min(430px,calc(100vw - 32px));height:min(650px,calc(100dvh - 64px));display:flex;flex-direction:column;overflow:hidden;border:1px solid #c7d9ea;border-radius:20px;background:#fff;box-shadow:0 24px 70px rgba(4,30,60,.38);opacity:0;transform:translateY(22px) scale(.96);transform-origin:bottom right;pointer-events:none;transition:opacity .2s ease,transform .2s ease}.chat-widget.is-open .chat-panel{opacity:1;transform:none;pointer-events:auto}.chat-widget.is-open .chat-launcher{opacity:0;transform:translateY(12px);pointer-events:none}.chat-header{display:flex;align-items:center;gap:11px;padding:14px 15px;color:#fff;background:linear-gradient(135deg,#0d355f,#0f6fec)}.chat-header-avatar{width:40px;height:40px;display:grid;flex:0 0 auto;place-items:center;border-radius:50%;background:rgba(255,255,255,.16)}.chat-header-copy{min-width:0;flex:1}.chat-header-copy strong,.chat-header-copy span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-header-copy strong{font-size:14px}.chat-header-copy span{margin-top:2px;font-size:10px;opacity:.82}.chat-close{width:34px;height:34px;display:grid;place-items:center;border:0;border-radius:50%;color:#fff;background:rgba(255,255,255,.12);font-size:22px;cursor:pointer}.chat-stage{padding:10px 12px;border-bottom:1px solid #dce7f1;background:linear-gradient(180deg,#f8fbff,#f3f8fd)}.chat-stage-label{display:block;margin-bottom:5px;color:#526d82;font-size:9px;font-weight:850;text-transform:uppercase;letter-spacing:.07em}.chat-stage-picker{position:relative}.chat-stage-picker summary{display:grid;grid-template-columns:32px minmax(0,1fr) 28px;gap:9px;align-items:center;min-height:48px;padding:7px 8px;border:1px solid #c6d9eb;border-radius:12px;color:#173b5d;background:#fff;box-shadow:0 4px 12px rgba(31,65,94,.06);cursor:pointer;list-style:none;transition:border-color .16s ease,box-shadow .16s ease}.chat-stage-picker summary::-webkit-details-marker{display:none}.chat-stage-picker summary:hover,.chat-stage-picker[open] summary{border-color:#7fb4ea;box-shadow:0 0 0 3px rgba(15,111,236,.09)}.chat-stage-number{width:32px;height:32px;display:grid;place-items:center;border-radius:10px;color:#fff;background:linear-gradient(145deg,#0f6fec,#0b4fae);font-size:11px;font-weight:900}.chat-stage-current{min-width:0}.chat-stage-current strong,.chat-stage-current small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-stage-current strong{color:#173b5d;font-size:11px}.chat-stage-current small{margin-top:1px;color:#637d94;font-size:8px;font-weight:650}.chat-stage-arrow{width:28px;height:28px;display:grid;place-items:center;border-radius:8px;color:#3972a7;background:#edf5fd;transition:transform .18s ease}.chat-stage-arrow svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}.chat-stage-picker[open] .chat-stage-arrow{transform:rotate(180deg)}.chat-stage-options{position:absolute;z-index:4;top:calc(100% + 6px);right:0;left:0;max-height:205px;display:grid;gap:4px;overflow-y:auto;padding:6px;border:1px solid #c6d9eb;border-radius:12px;background:#fff;box-shadow:0 16px 34px rgba(16,42,67,.2)}.chat-stage-option{display:grid;grid-template-columns:29px minmax(0,1fr) 22px;gap:8px;align-items:center;min-height:43px;padding:6px 7px;border-radius:9px;color:#31546f;text-decoration:none;transition:background .15s ease,color .15s ease}.chat-stage-option:hover{color:#0b4fae;background:#eef6ff}.chat-stage-option.is-active{color:#0b4fae;background:#e7f2ff}.chat-stage-option-number{width:29px;height:29px;display:grid;place-items:center;border-radius:8px;color:#3972a7;background:#edf4fb;font-size:9px;font-weight:900}.chat-stage-option.is-active .chat-stage-option-number{color:#fff;background:#0f6fec}.chat-stage-option-copy{min-width:0}.chat-stage-option-copy strong,.chat-stage-option-copy small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-stage-option-copy strong{font-size:10px}.chat-stage-option-copy small{margin-top:1px;color:#71879a;font-size:8px}.chat-stage-check{color:#0f6fec;font-size:15px;font-weight:900;text-align:center}.chat-timeline{min-height:0;flex:1;display:grid;align-content:start;gap:9px;overflow-y:auto;padding:16px 13px;background:linear-gradient(rgba(245,249,253,.94),rgba(245,249,253,.94)),radial-gradient(circle at 12px 12px,#dbe7f1 1px,transparent 1px);background-size:auto,24px 24px;overscroll-behavior:contain}.chat-empty{margin:auto;padding:28px 18px;color:#637b90;text-align:center;font-size:11px}.chat-bubble{position:relative;max-width:84%;justify-self:start;padding:9px 11px 7px;border:1px solid #d4e0eb;border-radius:5px 15px 15px 15px;background:#fff;box-shadow:0 3px 9px rgba(31,65,94,.06)}.chat-bubble.mine{justify-self:end;border-color:#9dc5ef;border-radius:15px 5px 15px 15px;background:#e8f3ff}.chat-author{display:block;margin-bottom:3px;color:#1769aa;font-size:9px;font-weight:900}.chat-text{margin:0;color:#203d58;font-size:12px;line-height:1.48;white-space:pre-wrap;overflow-wrap:anywhere}.chat-time{display:flex;align-items:center;justify-content:flex-end;gap:4px;margin-top:5px;color:#6c8295;font-size:8px}.chat-time .read-mark{color:#0f6fec;font-size:10px;font-weight:900}.chat-bubble.is-file{width:min(310px,84%);padding:7px}.chat-attachment{display:block;color:inherit;text-decoration:none}.chat-image-preview{width:100%;max-height:210px;display:block;border-radius:10px;object-fit:cover;background:#dfe9f2}.chat-file-card{display:grid;grid-template-columns:39px minmax(0,1fr) 25px;gap:9px;align-items:center;padding:8px;border-radius:10px;background:rgba(255,255,255,.72)}.chat-file-icon{width:39px;height:39px;display:grid;place-items:center;border-radius:9px;color:#0f6fec;background:#e8f2ff}.chat-file-icon svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.8}.chat-file-copy{min-width:0}.chat-file-copy strong,.chat-file-copy span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-file-copy strong{color:#173b5d;font-size:10px}.chat-file-copy span{margin-top:2px;color:#6a8093;font-size:8px}.chat-download{color:#0f6fec;font-size:17px;text-align:center}.chat-file-status{min-height:18px;padding:5px 13px 0;color:#526d82;background:#fff;font-size:9px}.chat-file-status:empty{display:none}.chat-compose{flex:0 0 auto;padding:9px 10px 10px;border-top:1px solid #dce7f1;background:#fff}.chat-compose-row{display:grid;grid-template-columns:38px minmax(0,1fr) 40px;gap:7px;align-items:end}.chat-file-input{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}.chat-attach,.chat-send{height:38px;display:grid;place-items:center;border:0;border-radius:50%;cursor:pointer}.chat-attach{color:#315f87;background:#edf3f8}.chat-send{color:#fff;background:#0f6fec;box-shadow:0 5px 12px rgba(15,111,236,.22)}.chat-compose textarea{width:100%;height:38px;min-height:38px;max-height:112px;padding:9px 11px;border:1px solid #cbdbea;border-radius:19px;color:#203d58;background:#f8fbfe;outline:none;resize:none;font:inherit;font-size:11px;line-height:1.45}.chat-compose textarea:focus{border-color:#6ba9eb;box-shadow:0 0 0 3px rgba(15,111,236,.1)}.chat-readonly{margin:0;padding:9px 12px;color:#5e7488;border-top:1px solid #dce7f1;background:#f3f6f9;text-align:center;font-size:9px}@media(max-width:620px){.chat-launcher{right:15px;bottom:14px}.chat-panel{inset:8px;width:auto;height:auto;border-radius:16px}.chat-widget.is-open .chat-launcher{display:none}.chat-bubble{max-width:90%}.chat-bubble.is-file{width:min(310px,90%)}.chat-header{padding:12px}.chat-timeline{padding:13px 10px}.chat-stage-options{max-height:180px}}
        /* El chat abierto debe quedar por encima del encabezado y del distintivo Conectar. */
        .chat-widget{z-index:2147483635}
        .chat-bubble.is-pending{opacity:.68}
        .chat-bubble.is-error{border-color:#e49a9a;background:#fff0f0}
    </style>
    <style>
        [hidden]{display:none!important}
        .case-state-tabs{display:flex;flex-wrap:wrap;gap:7px;margin:0 0 10px}.case-state-tab{--filter-accent:var(--primary);min-height:36px;display:inline-flex;align-items:center;gap:7px;padding:7px 12px;border:1px solid color-mix(in srgb,var(--filter-accent) 30%,var(--border));border-radius:999px;color:var(--text);background:color-mix(in srgb,var(--filter-accent) 4%,var(--surface));font:inherit;font-weight:850;cursor:pointer;transition:border-color .16s ease,background .16s ease,color .16s ease,transform .16s ease}.case-state-tab:hover{transform:translateY(-1px);border-color:var(--filter-accent)}.case-state-tab.is-active{border-color:var(--filter-accent);color:var(--filter-accent);background:color-mix(in srgb,var(--filter-accent) 15%,var(--surface));box-shadow:0 0 0 2px color-mix(in srgb,var(--filter-accent) 9%,transparent)}.case-state-tab[data-case-filter-state="activo"]{--filter-accent:var(--ok)}.case-state-tab[data-case-filter-state="pendiente"]{--filter-accent:var(--warn)}.case-state-tab[data-case-filter-state="cerrado"]{--filter-accent:color-mix(in srgb,var(--primary) 60%,var(--muted))}.case-state-tab-count{min-width:22px;height:22px;display:grid;place-items:center;padding:0 6px;border-radius:999px;color:var(--surface);background:var(--filter-accent);font-size:9px;font-weight:900}.case-state-tab:not(.is-active) .case-state-tab-count{color:var(--filter-accent);background:color-mix(in srgb,var(--filter-accent) 14%,var(--surface))}
        .case-filters{display:grid;grid-template-columns:minmax(240px,1fr) auto;gap:10px;align-items:end;margin:0 0 13px;padding:11px;border:1px solid color-mix(in srgb,var(--primary) 18%,var(--border));border-radius:11px;background:color-mix(in srgb,var(--primary) 4%,var(--surface))}
        .case-filter-field{display:grid;gap:5px}.case-filter-field label{color:var(--navy);font-size:10px;font-weight:850}.case-filter-field input,.case-filter-field select{width:100%;height:38px;padding:8px 10px;border:1px solid #cbdbea;border-radius:9px;color:var(--text);background:#fff;outline:none}.case-filter-field input:focus,.case-filter-field select:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(15,111,236,.11)}
        .case-search-control{position:relative}.case-search-control input{padding-right:38px}.case-filter-clear{position:absolute;top:5px;right:5px;width:28px;height:28px;display:grid;place-items:center;border:0;border-radius:7px;color:#617b91;background:#eef4fa;cursor:pointer;font-size:17px;line-height:1}.case-filter-clear:hover{color:var(--navy);background:#e1ebf5}
        .case-filter-count{min-width:104px;padding:10px 11px;color:#486985;text-align:center;font-size:10px;font-weight:850;white-space:nowrap}.case-filter-empty td{padding:28px;text-align:center;color:var(--muted)}
        body.case-modal-open{overflow:hidden}.case-detail-modal{position:fixed;inset:0;z-index:2147483647;width:100vw;height:100vh;height:100dvh;display:grid;place-items:center;padding:22px;background:rgba(7,25,45,.64);backdrop-filter:blur(4px);isolation:isolate}.case-detail-dialog{width:min(1080px,100%);max-height:calc(100vh - 44px);max-height:calc(100dvh - 44px);display:flex;flex-direction:column;overflow:hidden;border:1px solid #cbdbea;border-radius:16px;background:#fff;box-shadow:0 28px 80px rgba(4,25,48,.3)}.case-detail-modal-bar{position:sticky;top:0;z-index:2;display:flex;flex:0 0 auto;align-items:center;justify-content:space-between;gap:12px;padding:11px 14px;border-bottom:1px solid var(--border);background:#f7faff}.case-detail-modal-bar>strong{color:var(--navy);font-size:13px}.case-detail-modal-actions{display:flex;align-items:center;gap:8px}.case-detail-modal-bar .chat-launcher{position:relative;right:auto;bottom:auto;min-height:36px;padding:5px 10px 5px 6px;border-radius:10px;box-shadow:0 5px 13px color-mix(in srgb,var(--primary) 24%,transparent)}.case-detail-modal-bar .chat-launcher-icon{width:27px;height:27px}.case-detail-modal-bar .chat-launcher-copy small{display:none}.case-detail-modal-bar .chat-launcher[hidden]{display:none!important}.case-detail-close{display:inline-flex;align-items:center;gap:6px;min-height:34px;padding:7px 10px;border:1px solid #cbdbea;border-radius:9px;color:#315b7e;background:#fff;font:inherit;font-weight:850;cursor:pointer}.case-detail-close:hover{border-color:#a9c5df;color:var(--primary);background:#f2f7fc}.case-detail-close span{font-size:18px;line-height:1}.case-detail-scroll{min-height:0;overflow-y:auto;overscroll-behavior:contain}.case-detail-card{margin:0;border:0;border-radius:0;box-shadow:none}.case-detail-card>.card-head{padding-right:2px}.case-detail-card #conversacion-solicitante{scroll-margin-top:12px}
        .request-summary{display:grid;grid-template-columns:minmax(180px,.75fr) minmax(0,2fr);gap:9px;align-items:start;margin:0 0 13px}.request-summary-item{width:100%;height:64px;min-width:0;overflow:hidden;padding:9px 12px;border:1px solid var(--mesa-theme-border,var(--border));border-radius:10px;background:var(--mesa-theme-surface,var(--surface))}.request-summary-item>span{display:block;margin-bottom:3px;color:var(--mesa-theme-muted,var(--muted));font-size:9px;font-weight:850;letter-spacing:.05em;text-transform:uppercase}.request-summary-item strong{display:block;max-height:30px;overflow:hidden;color:var(--mesa-theme-heading,var(--navy));font-size:13px;line-height:1.35;overflow-wrap:anywhere}.request-summary-item p{margin:0;color:var(--mesa-theme-text,var(--text));font-size:11px;line-height:1.4;overflow-wrap:anywhere;white-space:pre-wrap}.request-summary-description p{height:31px;max-height:31px;overflow-x:hidden;overflow-y:auto;padding-right:8px;scrollbar-color:var(--mesa-shell-color,var(--primary)) var(--mesa-theme-soft,var(--soft));scrollbar-gutter:stable;scrollbar-width:thin}.request-summary-description p::-webkit-scrollbar{width:7px}.request-summary-description p::-webkit-scrollbar-track{border-radius:999px;background:var(--mesa-theme-soft,var(--soft))}.request-summary-description p::-webkit-scrollbar-thumb{border-radius:999px;background:var(--mesa-shell-color,var(--primary))}
        @media(max-width:760px){.case-state-tabs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}.case-state-tab{justify-content:space-between}.case-filters{grid-template-columns:1fr}.case-filter-count{text-align:left;padding:0 2px}.case-detail-card{padding:13px}.request-summary{grid-template-columns:1fr}}

        /* Vista integrada: el detalle reemplaza la lista sin crear una capa modal. */
        .case-detail-page{width:100%;max-width:none}
        .case-detail-page .case-detail-modal{position:static;inset:auto;z-index:auto;width:100%;height:auto;display:block;padding:0;background:transparent;backdrop-filter:none;isolation:auto}
        .case-detail-page .case-detail-dialog{width:100%;max-height:none;overflow:visible;border-radius:14px;box-shadow:none}
        .case-detail-page .case-detail-scroll{overflow:visible}
        .case-detail-page .case-detail-modal-bar{top:0;z-index:5}
        .case-detail-page .case-detail-card{min-height:min(760px,calc(100dvh - 60px))}
        @media(max-width:760px){.case-detail-page .case-detail-dialog{border-radius:11px}}
    </style>
    <style>
        .email-preference{display:flex;align-items:center;justify-content:space-between;gap:14px;margin:0 0 13px;padding:10px 12px;border:1px solid #cfe0ef;border-radius:11px;background:#f7faff}.email-preference-copy{min-width:0}.email-preference-copy strong{display:block;color:var(--navy);font-size:12px}.email-preference-copy p{margin:2px 0 0;color:var(--muted);font-size:10px}.email-preference-status{display:inline-flex;margin-top:5px;padding:3px 7px;border-radius:999px;color:#087443;background:#eaf8f1;font-size:9px;font-weight:850}.email-preference-status.off{color:#8a5800;background:#fff4d6}.email-preference form{flex:0 0 auto}.btn.email-toggle{min-height:34px;padding:7px 11px;border:1px solid #bdd2e5;color:#255a83;background:#fff;font-size:10px}.btn.email-toggle:hover{border-color:var(--primary);color:var(--primary)}
        @media(max-width:760px){.email-preference{align-items:stretch;flex-direction:column}.email-preference form,.email-preference button{width:100%}}
    </style>
    <style id="solicitante-detalle-legible">
        .case-detail-page{--case-blue:#0c4f8f;--case-blue-bright:#1478e6;--case-green:#07814c;--case-ink:#17334d;--case-muted:#62788c;--case-line:#d7e3ed;--case-bg:#f3f7fb}
        .case-detail-page .case-detail-dialog{overflow:hidden;border:1px solid #cbdbea;background:var(--case-bg)}
        .case-detail-page .case-detail-scroll{background:var(--case-bg)}
        .case-detail-page>.alert{width:min(1180px,calc(100% - 32px));margin:14px auto -4px;padding:10px 14px;border-radius:9px;font-size:13px;box-shadow:0 5px 14px rgba(24,55,84,.06)}
        .case-detail-card{width:min(1180px,calc(100% - 32px));min-height:0!important;display:flex;flex-direction:column;margin:18px auto 26px!important;padding:0!important;border:0!important;background:transparent!important;font-size:15px!important}
        .case-detail-card>.card-head{order:0}.case-detail-card>.rating-card{order:1;margin:0 0 14px}.case-detail-card>.request-summary{order:2}.case-detail-card>.detail-grid{order:3}.case-detail-card>.public-resolution{order:4}.case-detail-card>.public-trace{order:5}.case-detail-card>.chat-widget{order:6}
        .case-detail-modal-bar{padding:10px clamp(14px,1.4vw,22px);border-bottom:1px solid #d6e2ec;background:rgba(255,255,255,.96);box-shadow:0 4px 14px rgba(24,55,84,.08)}
        .case-detail-modal-bar>strong{color:var(--case-ink);font-size:14px;letter-spacing:.01em}
        .case-detail-modal-actions{display:flex;align-items:center;gap:9px}
        .case-email-toggle{margin:0}
        .case-email-toggle-button{height:40px;display:flex;align-items:center;gap:8px;padding:5px 11px;border:1px solid #b9cede;border-radius:9px;color:#315b7e;background:#fff;font:inherit;cursor:pointer;transition:border-color .16s ease,background .16s ease,transform .16s ease,box-shadow .16s ease}
        .case-email-toggle-button:hover{transform:translateY(-1px);border-color:var(--case-blue-bright);box-shadow:0 5px 12px rgba(15,111,236,.12)}
        .case-email-toggle-button.is-on{border-color:#8bd0ad;color:var(--case-green);background:#f2fbf6}
        .case-email-toggle-button.is-off{color:#697985;background:#f7f9fb}
        .case-email-icon{width:27px;height:27px;display:grid;place-items:center;border-radius:7px;background:color-mix(in srgb,currentColor 11%,transparent)}
        .case-email-icon svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}
        .case-email-copy{display:grid;text-align:left;line-height:1.05}.case-email-copy strong{font-size:11px}.case-email-copy small{margin-top:3px;font-size:9px;font-weight:750}
        .case-detail-modal-bar .chat-launcher{height:40px;min-height:40px;padding:5px 12px 5px 6px;border-radius:9px}

        .case-detail-card>.card-head{position:relative;align-items:center;margin:0 0 14px;padding:20px 22px;overflow:hidden;border:0;border-radius:14px;color:#fff;background:linear-gradient(125deg,#0a3d70 0%,#0d5ea9 58%,#1682ec 100%);box-shadow:0 12px 28px rgba(11,79,142,.2)}
        .case-detail-card>.card-head::after{content:"";position:absolute;right:-35px;bottom:-75px;width:190px;height:190px;border:34px solid rgba(255,255,255,.08);border-radius:50%}
        .case-detail-card>.card-head h2{position:relative;z-index:1;color:#fff;font-size:26px;line-height:1.15;letter-spacing:-.02em}
        .case-detail-card>.card-head h2::after{content:"Consulta el estado, la respuesta y el recorrido de tu solicitud";display:block;margin-top:6px;color:rgba(255,255,255,.8);font-size:12px;font-weight:600;letter-spacing:0}
        .case-detail-card>.card-head .status{position:relative;z-index:1;padding:6px 10px;border:1px solid rgba(255,255,255,.32);color:#fff!important;background:rgba(255,255,255,.14)!important;font-size:11px!important;letter-spacing:.02em}

        .request-summary{display:block;margin:0 0 14px;padding:5px 20px;border:1px solid var(--case-line);border-left:5px solid var(--case-blue-bright);border-radius:12px;background:#fff;box-shadow:0 7px 18px rgba(25,55,83,.06)}
        .request-summary-item{height:auto;min-height:0;overflow:visible;padding:13px 0;border:0;border-radius:0;background:transparent}
        .request-summary-item+.request-summary-item{border-top:1px solid #e4ecf3}
        .request-summary-item>span{display:flex;align-items:center;gap:7px;margin-bottom:5px;color:#52708a;font-size:11px!important;font-weight:850;letter-spacing:.06em;text-transform:uppercase}
        .request-summary-item>span::before{content:"";width:7px;height:7px;border-radius:2px;background:var(--case-blue-bright)}
        .request-summary-item strong{max-height:none;overflow:visible;color:var(--case-ink);font-size:18px!important;line-height:1.4}
        .request-summary-item p{margin:0;color:#36536c;font-size:15px!important;line-height:1.65}
        .request-summary-description p{height:auto;max-height:none;overflow:visible;padding:0;scrollbar-gutter:auto}

        .case-detail-card .detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0;margin:0 0 14px;padding:0;overflow:hidden;border:1px solid var(--case-line);border-radius:12px;background:#fff;box-shadow:0 7px 18px rgba(25,55,83,.05)}
        .case-detail-card .detail-item{min-width:0;padding:12px 14px;border:0;border-right:1px solid #e1e9f1;border-bottom:1px solid #e1e9f1;border-radius:0;background:#fff}
        .case-detail-card .detail-item:nth-child(3),.case-detail-card .detail-item:last-child{border-right:0}.case-detail-card .detail-item:nth-child(n+4){border-bottom:0}
        .case-detail-card .detail-item:first-child{grid-column:span 2}
        .case-detail-card .detail-item span{display:block;color:#667f94;font-size:10px!important;font-weight:800;letter-spacing:.05em;text-transform:uppercase}
        .case-detail-card .detail-item strong{display:block;margin-top:4px;color:var(--case-ink);font-size:13px!important;line-height:1.4}
        .case-detail-card .detail-item small{display:block;margin-top:4px;color:#9a6500;font-size:10px;line-height:1.35}

        .public-resolution{position:relative;margin:0 0 14px;padding:18px 20px;border:1px solid #a9d7bf;border-left:5px solid var(--case-green);border-radius:12px;background:linear-gradient(115deg,#f2fbf6,#f9fdfb);box-shadow:0 8px 20px rgba(7,129,76,.08)}
        .public-resolution-head{align-items:center;margin-bottom:13px}.public-resolution-head>div{position:relative;padding-left:42px}
        .public-resolution-head>div::before{content:"✓";position:absolute;left:0;top:0;width:30px;height:30px;display:grid;place-items:center;border-radius:50%;color:#fff;background:var(--case-green);font-size:17px;font-weight:900;box-shadow:0 5px 12px rgba(7,129,76,.2)}
        .public-resolution-head h3,.public-trace-head h3{margin:0;color:var(--case-ink);font-size:19px!important;line-height:1.25}
        .public-resolution-head p,.public-trace-head p{margin:4px 0 0;color:var(--case-muted);font-size:12px!important}
        .public-resolution-area{padding:5px 9px;border-radius:7px;color:var(--case-green);background:#dff4e8;font-size:10px;font-weight:850}
        .public-resolution-grid{grid-template-columns:minmax(180px,.8fr) minmax(0,1.35fr);gap:0;padding:2px 0 0}
        .public-resolution-item{padding:10px 13px;border:0;border-radius:0;background:transparent}
        .public-resolution-item:nth-child(2){border-left:1px solid #cce4d7}
        .public-resolution-item.observation{grid-column:1/-1;margin-top:5px;padding-top:12px;border-top:1px solid #cce4d7}
        .public-resolution-item span,.public-trace-answer span{display:block;color:#60798e;font-size:10px!important;font-weight:850;letter-spacing:.05em;text-transform:uppercase}
        .public-resolution-item strong{display:block;margin-top:4px;color:var(--case-ink);font-size:14px!important;line-height:1.45}
        .public-resolution-item p,.public-trace-answer p{margin:4px 0 0;color:#2f4d66;font-size:13px!important;line-height:1.55}
        .public-resolution-empty{margin:0 0 0 42px;color:var(--case-muted);font-size:13px}

        .public-trace{margin:0;padding:19px 20px 18px;border:1px solid var(--case-line);border-radius:12px;background:#fff;box-shadow:0 8px 20px rgba(25,55,83,.06)}
        .public-trace-head{position:relative;margin-bottom:18px;padding-left:42px}
        .public-trace-head::before{content:"";position:absolute;left:0;top:1px;width:30px;height:30px;border:7px solid #dcecff;border-radius:50%;background:var(--case-blue-bright);box-shadow:0 0 0 1px #9cc7f3}
        .public-trace-list{position:relative;display:grid;gap:12px;padding-left:28px}
        .public-trace-list::before{content:"";position:absolute;top:8px;bottom:12px;left:18px;width:2px;background:#c8dbec}
        .public-trace-node{position:relative;margin-left:min(calc(var(--trace-level,0) * 32px),96px);padding:14px 16px 14px 42px;border:1px solid #d8e4ee;border-radius:10px;background:#fbfdff;box-shadow:0 4px 12px rgba(24,55,82,.045)}
        .public-trace-node::before{content:"";position:absolute;z-index:1;left:-10px;top:18px;width:13px;height:13px;border:4px solid #ddecfa;border-radius:50%;background:var(--case-blue);transform:translateX(-50%)}
        .public-trace-node.derived{border-color:#bfd7ef;background:#f5f9fe}.public-trace-node.derived::before{background:var(--case-blue-bright)}
        .public-trace-node-head{align-items:center}.public-trace-label{gap:8px}
        .public-trace-label strong{color:var(--case-ink);font-size:15px!important}
        .public-trace-kind{padding:4px 7px;border-radius:6px;color:#0d62b4;background:#e4f1ff;font-size:9px!important;letter-spacing:.04em}
        .public-trace-service{margin-top:4px;color:var(--case-muted);font-size:11px!important}
        .public-trace-node .status{font-size:9px!important}
        .public-trace-answers{grid-template-columns:1fr 1fr;gap:0;margin-top:11px;padding-top:10px;border-top:1px solid #e0e9f1}
        .public-trace-answer{padding:0 12px;border:0;border-radius:0;background:transparent}.public-trace-answer:first-child{padding-left:0}.public-trace-answer+.public-trace-answer{border-left:1px solid #dfe8f0}
        .public-trace-answer.pending{grid-column:1/-1;padding:0;color:var(--case-muted);font-size:12px}

        @media(max-width:900px){
            .case-detail-card{width:min(calc(100% - 20px),1180px);margin-top:12px!important}
            .case-detail-card .detail-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.case-detail-card .detail-item:first-child{grid-column:span 2}.case-detail-card .detail-item{border-right:1px solid #e1e9f1;border-bottom:1px solid #e1e9f1}.case-detail-card .detail-item:nth-child(odd):not(:first-child){border-right:0}.case-detail-card .detail-item:nth-last-child(-n+2){border-bottom:0}
        }
        @media(max-width:760px){
            .case-detail-modal-bar{align-items:center;flex-direction:row;flex-wrap:wrap}.case-detail-modal-bar>strong{flex:1 1 150px}.case-detail-modal-actions{flex:0 0 auto}.case-email-copy{display:none}.case-email-toggle-button{width:40px;padding:5px;justify-content:center}
            .case-detail-card>.card-head{align-items:center;flex-direction:row;padding:17px}.case-detail-card>.card-head h2{font-size:22px}.case-detail-card>.card-head h2::after{max-width:230px;font-size:11px}
            .request-summary{padding:4px 15px}.request-summary-item strong{font-size:16px!important}.request-summary-item p{font-size:14px!important}
            .public-resolution-grid,.public-trace-answers{grid-template-columns:1fr}.public-resolution-item:nth-child(2),.public-trace-answer+.public-trace-answer{border-left:0;border-top:1px solid #d8e5df}.public-resolution-item.observation{grid-column:auto}.public-trace-answer{padding:9px 0}.public-trace-answer:first-child{padding-top:0}
            .public-trace-node{margin-left:min(calc(var(--trace-level,0) * 16px),48px);padding-left:28px}
        }
        @media(max-width:480px){
            .case-detail-modal-bar>strong{flex-basis:100%}.case-detail-modal-actions{width:100%;justify-content:flex-end}.case-detail-card{width:calc(100% - 12px)}
            .case-detail-card .detail-grid{grid-template-columns:1fr}.case-detail-card .detail-item:first-child{grid-column:auto}.case-detail-card .detail-item{border-right:0!important}
            .public-resolution,.public-trace{padding:16px 14px}.public-resolution-head{align-items:flex-start;display:block}.public-resolution-area{display:inline-flex;margin:9px 0 0 42px}.public-trace-list{padding-left:22px}.public-trace-list::before{left:12px}.public-trace-node{margin-left:min(calc(var(--trace-level,0) * 10px),30px)}
        }

        /* El detalle se integra al módulo y usa todo el ancho disponible. */
        .case-detail-page .case-detail-modal,
        .case-detail-page .case-detail-dialog,
        .case-detail-page .case-detail-scroll{width:100%!important;max-width:none!important;border:0!important;border-radius:0!important;background:#fff!important;box-shadow:none!important}
        .case-detail-page .case-detail-card{width:100%!important;max-width:none!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:#fff!important;box-shadow:none!important}
        .case-detail-page .case-detail-card>.card-head{margin:0!important;padding:22px 28px!important;border-radius:0!important;background:linear-gradient(125deg,#0a3d70 0%,#0d5ea9 58%,#1682ec 100%)!important;box-shadow:none!important}
        .case-detail-page .request-summary{margin:0!important;padding:8px 28px!important;border:0!important;border-left:5px solid var(--case-blue-bright)!important;border-bottom:1px solid var(--case-line)!important;border-radius:0!important;background:#fff!important;box-shadow:none!important}
        .case-detail-page .case-detail-card .detail-grid{margin:0!important;border:0!important;border-bottom:1px solid var(--case-line)!important;border-radius:0!important;background:#f7fafd!important;box-shadow:none!important}
        .case-detail-page .case-detail-card .detail-item{padding:13px 18px!important;background:#f7fafd!important}
        .case-detail-page .public-resolution{margin:0!important;padding:20px 28px!important;border:0!important;border-left:5px solid var(--case-green)!important;border-bottom:1px solid #b9dac8!important;border-radius:0!important;background:linear-gradient(115deg,#effaf4,#f8fcfa)!important;box-shadow:none!important}
        .case-detail-page .public-trace{margin:0!important;padding:22px 28px 26px!important;border:0!important;border-radius:0!important;background:#fff!important;box-shadow:none!important}
        .case-detail-page .public-trace-node{box-shadow:none!important}
        @media(max-width:760px){
            .case-detail-page .case-detail-card>.card-head{padding:18px!important}
            .case-detail-page .request-summary{padding:6px 18px!important}
            .case-detail-page .public-resolution,.case-detail-page .public-trace{padding:18px!important}
        }
        @media(max-width:480px){
            .case-detail-page .case-detail-card{width:100%!important}
            .case-detail-page .case-detail-card>.card-head,.case-detail-page .request-summary,.case-detail-page .public-resolution,.case-detail-page .public-trace{padding-right:14px!important;padding-left:14px!important}
        }

        /* La ficha hereda la paleta activa y conserva contraste en temas claros u oscuros. */
        .case-detail-page{
            --case-blue:var(--mesa-shell-color,var(--primary));
            --case-blue-bright:var(--mesa-theme-link,var(--primary));
            --case-green:var(--ok,#087443);
            --case-ink:var(--mesa-theme-heading,var(--navy));
            --case-muted:var(--mesa-theme-muted,var(--muted));
            --case-line:var(--mesa-theme-border,var(--border));
            --case-bg:var(--mesa-theme-soft,var(--bg));
            color:var(--mesa-theme-text,var(--text))!important;
            background:var(--mesa-theme-surface,var(--surface))!important;
        }
        .case-detail-page .case-detail-modal,
        .case-detail-page .case-detail-dialog,
        .case-detail-page .case-detail-scroll,
        .case-detail-page .case-detail-card{color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .case-detail-modal-bar{border-color:var(--case-line)!important;color:var(--case-ink)!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .case-detail-modal-bar>strong{color:var(--case-ink)!important}
        .case-detail-page .case-email-toggle-button{border-color:var(--case-line)!important;color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .case-email-toggle-button.is-on{border-color:color-mix(in srgb,var(--case-green) 55%,var(--case-line))!important;color:var(--case-green)!important;background:color-mix(in srgb,var(--mesa-theme-surface,var(--surface)) 90%,var(--case-green))!important}
        .case-detail-page .case-detail-card>.card-head{color:var(--mesa-theme-on-primary,#fff)!important;background:linear-gradient(120deg,var(--case-blue),color-mix(in srgb,var(--case-blue) 78%,var(--case-blue-bright)))!important}
        .case-detail-page .case-detail-card>.card-head h2,
        .case-detail-page .case-detail-card>.card-head h2::after{color:var(--mesa-theme-on-primary,#fff)!important}
        .case-detail-page .request-summary{border-color:var(--case-line)!important;border-left-color:var(--case-blue-bright)!important;color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .request-summary-item+.request-summary-item{border-color:var(--case-line)!important}
        .case-detail-page .request-summary-item>span{color:var(--case-muted)!important}
        .case-detail-page .request-summary-item>span::before{background:var(--case-blue-bright)!important}
        .case-detail-page .request-summary-item strong{color:var(--case-ink)!important}
        .case-detail-page .request-summary-item p{color:var(--mesa-theme-text,var(--text))!important}
        .case-detail-page .case-detail-card .detail-grid{border-color:var(--case-line)!important;background:var(--case-bg)!important}
        .case-detail-page .case-detail-card .detail-item{border-color:var(--case-line)!important;color:var(--mesa-theme-text,var(--text))!important;background:var(--case-bg)!important}
        .case-detail-page .case-detail-card .detail-item span{color:var(--case-muted)!important}
        .case-detail-page .case-detail-card .detail-item strong{color:var(--case-ink)!important}
        .case-detail-page .public-resolution{border-color:color-mix(in srgb,var(--case-green) 48%,var(--case-line))!important;border-left-color:var(--case-green)!important;color:var(--mesa-theme-text,var(--text))!important;background:color-mix(in srgb,var(--mesa-theme-surface,var(--surface)) 91%,var(--case-green))!important}
        .case-detail-page .public-resolution-head h3,
        .case-detail-page .public-resolution-item strong{color:var(--case-ink)!important}
        .case-detail-page .public-resolution-head p,
        .case-detail-page .public-resolution-item span,
        .case-detail-page .public-resolution-empty{color:var(--case-muted)!important}
        .case-detail-page .public-resolution-item p{color:var(--mesa-theme-text,var(--text))!important}
        .case-detail-page .public-resolution-item:nth-child(2),
        .case-detail-page .public-resolution-item.observation{border-color:color-mix(in srgb,var(--case-green) 30%,var(--case-line))!important}
        .case-detail-page .public-resolution-area{color:var(--case-green)!important;background:color-mix(in srgb,var(--mesa-theme-surface,var(--surface)) 82%,var(--case-green))!important}
        .case-detail-page .public-trace{color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .public-trace-head h3,
        .case-detail-page .public-trace-label strong{color:var(--case-ink)!important}
        .case-detail-page .public-trace-head p,
        .case-detail-page .public-trace-service,
        .case-detail-page .public-trace-answer span,
        .case-detail-page .public-trace-answer.pending{color:var(--case-muted)!important}
        .case-detail-page .public-trace-answer p{color:var(--mesa-theme-text,var(--text))!important}
        .case-detail-page .public-trace-list::before{background:color-mix(in srgb,var(--case-blue-bright) 35%,var(--case-line))!important}
        .case-detail-page .public-trace-node{border-color:var(--case-line)!important;color:var(--mesa-theme-text,var(--text))!important;background:color-mix(in srgb,var(--mesa-theme-surface,var(--surface)) 96%,var(--case-blue-bright))!important}
        .case-detail-page .public-trace-node.derived{border-color:color-mix(in srgb,var(--case-blue-bright) 45%,var(--case-line))!important;background:color-mix(in srgb,var(--mesa-theme-surface,var(--surface)) 91%,var(--case-blue-bright))!important}
        .case-detail-page .public-trace-kind{color:var(--case-blue-bright)!important;background:color-mix(in srgb,var(--mesa-theme-surface,var(--surface)) 82%,var(--case-blue-bright))!important}
        .case-detail-page .public-trace-answers,
        .case-detail-page .public-trace-answer+.public-trace-answer{border-color:var(--case-line)!important}
    </style>

<style id="chat-identidad-participantes">
.chat-author-row{
    display:flex;
    align-items:center;
    gap:8px;
    margin-bottom:6px;
}
.chat-profile-image,
.chat-profile-fallback{
    width:30px;
    height:30px;
    flex:0 0 30px;
    border-radius:50%;
}
.chat-profile-image{
    display:block;
    object-fit:cover;
    border:2px solid var(--mesa-theme-border,#d4e0eb);
    background:var(--mesa-theme-soft,#dfe9f2);
}
.chat-profile-fallback{
    display:grid;
    place-items:center;
    color:var(--mesa-theme-on-primary,#fff);
    background:var(--mesa-shell-color,#315f87);
    font-size:8px;
    font-weight:900;
}
.chat-author-copy{
    min-width:0;
    display:grid;
    line-height:1.15;
}
.chat-author-copy strong{
    overflow:hidden;
    color:var(--mesa-theme-heading,#1769aa);
    font-size:10px;
    font-weight:900;
    text-overflow:ellipsis;
    white-space:nowrap;
}
.chat-author-copy small{
    margin-top:2px;
    color:var(--mesa-theme-muted,#72879a);
    font-size:8px;
    font-weight:750;
}
.chat-bubble.mine .chat-author-row{
    justify-content:flex-end;
}
.chat-bubble.mine .chat-author-copy{
    text-align:right;
}
.chat-bubble.mine,
.chat-bubble[data-mesa-own-message="1"]{
    border-color:var(--mesa-theme-border,#d4e0eb)!important;
    border-color:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 55%,var(--mesa-theme-border,#d4e0eb))!important;
    color:var(--mesa-theme-text,#203d58)!important;
    background:var(--mesa-theme-soft,#edf6ff)!important;
    background:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 16%,var(--mesa-theme-surface,#fff))!important;
}
.chat-bubble.mine .chat-author-copy,
.chat-bubble.mine .chat-author-copy strong,
.chat-bubble.mine .chat-text,
.chat-bubble[data-mesa-own-message="1"] .chat-author-copy,
.chat-bubble[data-mesa-own-message="1"] .chat-author-copy strong,
.chat-bubble[data-mesa-own-message="1"] .chat-text{color:var(--mesa-theme-heading,#173b5d)!important}
.chat-bubble.mine .chat-author-copy small,
.chat-bubble.mine .chat-time,
.chat-bubble[data-mesa-own-message="1"] .chat-author-copy small,
.chat-bubble[data-mesa-own-message="1"] .chat-time{color:var(--mesa-theme-meta,var(--mesa-theme-muted,#637d94))!important}
.chat-bubble.mine .read-mark,
.chat-bubble[data-mesa-own-message="1"] .read-mark{color:var(--mesa-theme-link,var(--mesa-shell-color,#0f6fec))!important}
.chat-bubble.mine .chat-profile-image{
    order:2;
    border-color:var(--mesa-theme-border,#d4e0eb);
}
.chat-files{flex:0 0 auto;border-bottom:1px solid var(--mesa-theme-border,#dce7f1);background:var(--mesa-theme-soft,#f3f8fd)}
.chat-files summary{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;color:var(--mesa-theme-heading,#173b5d);font-size:10px;font-weight:850;cursor:pointer;list-style:none}.chat-files summary::-webkit-details-marker{display:none}.chat-files summary span{padding:2px 7px;border-radius:999px;color:var(--mesa-theme-link,#0f6fec);background:var(--mesa-theme-surface,#fff)}
.chat-files-list{max-height:170px;display:grid;gap:6px;overflow:auto;padding:0 10px 10px}.chat-files-list a{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;padding:8px;border:1px solid var(--mesa-theme-border,#d4e0eb);border-radius:9px;color:var(--mesa-theme-text,#203d58);background:var(--mesa-theme-surface,#fff);text-decoration:none}.chat-files-list strong,.chat-files-list small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-files-list strong{font-size:9px}.chat-files-list small{color:var(--mesa-theme-muted,#637d94);font-size:8px}.chat-files-empty{padding:0 12px 10px;color:var(--mesa-theme-muted,#637d94);font-size:9px}
</style>

<style id="bloqueo-calificacion-pendiente">
.tab.disabled{
    border:1px solid var(--border);
    color:var(--muted);
    background:var(--soft);
    cursor:not-allowed;
    opacity:.78;
}
.pending-rating-gate{
    display:grid;
    grid-template-columns:42px minmax(0,1fr) auto;
    gap:12px;
    align-items:center;
    margin-top:10px;
    padding:12px 14px;
    border:1px solid color-mix(in srgb,var(--warn) 48%,var(--border));
    border-left:5px solid var(--warn);
    border-radius:12px;
    color:var(--text);
    background:color-mix(in srgb,var(--warn) 9%,var(--surface));
    box-shadow:0 8px 22px color-mix(in srgb,var(--warn) 10%,transparent);
}
.pending-rating-icon{
    width:42px;
    height:42px;
    display:grid;
    place-items:center;
    border-radius:12px;
    color:var(--surface);
    background:var(--warn);
    font-size:19px;
    font-weight:900;
}
.pending-rating-copy strong{
    display:block;
    color:var(--navy);
    font-size:13px;
}
.pending-rating-copy p{
    margin:3px 0 0;
    color:var(--text);
    font-size:11px;
}
.pending-rating-actions{
    display:flex;
    flex-wrap:wrap;
    justify-content:flex-end;
    gap:7px;
}
.pending-rating-action{
    min-height:34px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:7px 11px;
    border:1px solid color-mix(in srgb,var(--warn) 44%,var(--border));
    border-radius:9px;
    color:var(--navy);
    background:var(--surface);
    text-decoration:none;
    font-size:10px;
    font-weight:850;
}
.pending-rating-action.primary{
    border-color:var(--warn);
    color:var(--surface);
    background:var(--warn);
}
.creation-blocked{
    padding:22px;
    border:1px dashed color-mix(in srgb,var(--warn) 55%,var(--border));
    border-radius:12px;
    color:var(--text);
    background:color-mix(in srgb,var(--warn) 7%,var(--surface));
    text-align:center;
}
.creation-blocked strong{display:block;color:var(--navy);font-size:15px}
.creation-blocked p{margin:6px auto 13px;max-width:620px}
@media(max-width:720px){
    .pending-rating-gate{grid-template-columns:38px minmax(0,1fr)}
    .pending-rating-icon{width:38px;height:38px}
    .pending-rating-actions{grid-column:1/-1;justify-content:stretch}
    .pending-rating-action{flex:1 1 130px}
}
</style>

<style id="solicitante-homologacion-casos-gestor">
    /* Homologación visual con .case-detail-page de flujoTicket.php. */
    .case-detail-page{
        --case-family-blue:var(--mesa-shell-color,var(--primary));
        --case-family-blue-strong:color-mix(in srgb,var(--case-family-blue) 72%,#082f57);
        --case-family-line:var(--mesa-theme-border,var(--border));
        --case-family-surface:var(--mesa-theme-surface,var(--surface));
        --case-family-soft:var(--mesa-theme-soft,var(--soft));
        --case-family-text:var(--mesa-theme-text,var(--text));
        --case-family-muted:var(--mesa-theme-muted,var(--muted));
        background:var(--mesa-theme-bg,var(--bg))!important;
    }
    .case-detail-page .case-detail-dialog{
        width:100%;
        max-width:none;
        overflow:hidden;
        border:1px solid var(--case-family-line);
        border-radius:18px;
        background:var(--case-family-surface);
        box-shadow:0 14px 36px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 13%,transparent);
    }
    .case-detail-page .case-detail-modal-bar{
        padding:12px clamp(18px,2.2vw,30px);
        border-color:var(--case-family-line);
        color:var(--case-family-text);
        background:var(--case-family-surface);
        box-shadow:0 5px 14px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 8%,transparent);
    }
    .case-detail-page .case-detail-modal-bar>strong{color:var(--case-family-text);font-size:13px}
    .case-detail-page .case-detail-card{
        width:100%;
        max-width:none;
        margin:0!important;
        padding:0!important;
        background:var(--case-family-surface)!important;
    }
    .case-detail-page .case-detail-card>.card-head{
        min-height:104px;
        margin:0!important;
        padding:22px clamp(20px,2.4vw,36px)!important;
        border:0;
        border-radius:0;
        color:var(--mesa-theme-on-primary,#fff);
        background:linear-gradient(120deg,var(--case-family-blue-strong),var(--case-family-blue));
        box-shadow:none;
    }
    .case-detail-page .case-detail-card>.card-head h2{
        color:var(--mesa-theme-on-primary,#fff);
        font-size:clamp(21px,1.75vw,27px);
        line-height:1.16;
    }
    .case-detail-page .case-detail-card>.card-head h2::after{color:color-mix(in srgb,var(--mesa-theme-on-primary,#fff) 82%,transparent)}
    .case-detail-page .case-detail-card>.card-head .status{
        border-color:rgba(255,255,255,.42);
        color:var(--mesa-theme-on-primary,#fff)!important;
        background:rgba(255,255,255,.14)!important;
    }
    .case-detail-page .request-summary{
        gap:0;
        margin:16px 18px 12px!important;
        padding:0!important;
        overflow:hidden;
        border:1px solid var(--case-family-line)!important;
        border-left:5px solid var(--case-family-blue)!important;
        border-radius:12px!important;
        background:var(--case-family-surface)!important;
        box-shadow:0 6px 18px rgba(25,55,83,.055);
    }
    .case-detail-page .request-summary-item{padding:15px 17px!important}
    .case-detail-page .request-summary-item+.request-summary-item{border-color:var(--case-family-line)}
    .case-detail-page .request-summary-item>span,
    .case-detail-page .detail-item span,
    .case-detail-page .public-resolution-item span,
    .case-detail-page .public-trace-answer span{
        color:var(--case-family-muted)!important;
    }
    .case-detail-page .request-summary-item>span::before{background:var(--case-family-blue)!important}
    .case-detail-page .request-summary-item strong{color:var(--case-family-text)!important;font-size:15px!important}
    .case-detail-page .request-summary-item p{color:var(--case-family-text)!important;font-size:13px!important}
    .case-detail-page .case-detail-card .detail-grid{
        margin:0 18px 14px!important;
        border:1px solid var(--case-family-line)!important;
        border-radius:12px!important;
        background:var(--case-family-soft)!important;
        box-shadow:0 6px 18px rgba(25,55,83,.05);
    }
    .case-detail-page .case-detail-card .detail-item{
        padding:12px 14px!important;
        border-color:var(--case-family-line)!important;
        background:var(--case-family-soft)!important;
    }
    .case-detail-page .case-detail-card .detail-item strong{color:var(--case-family-text)!important;font-size:12px!important}
    .case-detail-page .public-resolution{
        margin:12px 18px!important;
        padding:16px!important;
        border:1px solid color-mix(in srgb,var(--case-family-blue) 30%,var(--case-family-line))!important;
        border-left:5px solid var(--case-family-blue)!important;
        border-radius:12px!important;
        background:linear-gradient(115deg,color-mix(in srgb,var(--case-family-blue) 8%,var(--case-family-surface)),var(--case-family-surface))!important;
        box-shadow:0 7px 18px rgba(25,55,83,.055);
    }
    .case-detail-page .public-resolution-head h3,
    .case-detail-page .public-trace-head h3{color:var(--case-family-text)!important;font-size:16px!important}
    .case-detail-page .public-resolution-head p,
    .case-detail-page .public-trace-head p{color:var(--case-family-muted)!important;font-size:11px!important}
    .case-detail-page .public-resolution-item strong{color:var(--case-family-text)!important;font-size:13px!important}
    .case-detail-page .public-resolution-item p,
    .case-detail-page .public-trace-answer p{color:var(--case-family-text)!important;font-size:12px!important}
    .case-detail-page .public-trace{
        margin:12px 18px 18px!important;
        padding:16px!important;
        border:1px solid var(--case-family-line)!important;
        border-radius:12px!important;
        background:var(--case-family-surface)!important;
        box-shadow:0 7px 18px rgba(25,55,83,.055);
    }
    .case-detail-page .public-trace-node{
        border-color:var(--case-family-line)!important;
        border-radius:10px;
        background:color-mix(in srgb,var(--case-family-surface) 96%,var(--case-family-blue))!important;
        box-shadow:none;
    }
    .case-detail-page .public-trace-node.derived{border-color:color-mix(in srgb,var(--case-family-blue) 45%,var(--case-family-line))!important;background:color-mix(in srgb,var(--case-family-surface) 91%,var(--case-family-blue))!important}
    .case-detail-page .public-trace-label strong{color:var(--case-family-text)!important;font-size:13px!important}
    .case-detail-page .public-trace-kind{color:var(--case-family-blue)!important;background:color-mix(in srgb,var(--case-family-surface) 82%,var(--case-family-blue))!important}
    .case-detail-page .public-trace-list::before{background:color-mix(in srgb,var(--case-family-blue) 35%,var(--case-family-line))!important}
    @media(max-width:900px){
        .case-detail-page .request-summary,
        .case-detail-page .case-detail-card .detail-grid,
        .case-detail-page .public-resolution,
        .case-detail-page .public-trace{margin-right:14px!important;margin-left:14px!important}
    }
    @media(max-width:480px){
        .case-detail-page .case-detail-card>.card-head{padding:18px 14px!important}
        .case-detail-page .request-summary,
        .case-detail-page .public-resolution,
        .case-detail-page .public-trace{margin-right:0!important;margin-left:0!important}
    }
</style>

<style id="solicitante-casos-asignados-paridad">
    /* El listado y el detalle del solicitante comparten la misma paleta y
       densidad visual de Casos asignados, conservando acciones de solo consulta. */
    main.shell:not(.case-detail-page)>.card{
        border-color:var(--mesa-theme-border,var(--border));
        color:var(--mesa-theme-text,var(--text));
        background:var(--mesa-theme-surface,var(--surface));
        box-shadow:0 10px 26px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 9%,transparent);
    }
    main.shell:not(.case-detail-page)>.card .card-head h1,
    main.shell:not(.case-detail-page)>.card .card-head h2{
        color:var(--mesa-theme-heading,var(--navy));
    }
    .case-state-tabs{gap:8px;margin-bottom:13px}
    .case-state-tab{
        min-height:40px;
        padding:8px 13px;
        border-color:color-mix(in srgb,var(--filter-accent) 34%,var(--mesa-theme-border,var(--border)));
        color:var(--mesa-theme-text,var(--text));
        background:color-mix(in srgb,var(--filter-accent) 5%,var(--mesa-theme-surface,var(--surface)));
    }
    .case-state-tab.is-active{
        color:var(--filter-accent);
        background:color-mix(in srgb,var(--filter-accent) 14%,var(--mesa-theme-surface,var(--surface)));
    }
    .case-filters{
        padding:13px;
        border-color:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 22%,var(--mesa-theme-border,var(--border)));
        background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 5%,var(--mesa-theme-surface,var(--surface)));
    }
    .case-filter-field label{color:var(--mesa-theme-heading,var(--navy))}
    .case-filter-field input{
        height:42px;
        border-color:var(--mesa-theme-border,var(--border));
        color:var(--mesa-theme-text,var(--text));
        background:var(--mesa-theme-surface,var(--surface));
    }
    .case-filter-clear{
        color:var(--mesa-theme-muted,var(--muted));
        background:var(--mesa-theme-soft,var(--soft));
    }
    .case-filter-count{color:var(--mesa-theme-muted,var(--muted));font-size:12px}
    .table-wrap{
        border-color:var(--mesa-theme-border,var(--border));
        background:var(--mesa-theme-surface,var(--surface));
    }
    .table-wrap th{
        color:var(--mesa-theme-muted,var(--muted));
        background:var(--mesa-theme-soft,var(--soft));
    }
    .table-wrap td{
        border-color:var(--mesa-theme-border,var(--border));
        color:var(--mesa-theme-text,var(--text));
        background:var(--mesa-theme-surface,var(--surface));
    }
    .table-wrap tbody tr:hover td{
        background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 5%,var(--mesa-theme-surface,var(--surface)));
    }
    .case-number{
        display:inline-flex;
        padding:4px 8px;
        border-radius:999px;
        color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));
        background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 10%,var(--mesa-theme-surface,var(--surface)));
        font-size:10px;
        font-weight:900;
        white-space:nowrap;
    }
    .view-link{
        min-height:34px;
        align-items:center;
        border-color:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 34%,var(--mesa-theme-border,var(--border)));
        color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));
        background:var(--mesa-theme-surface,var(--surface));
    }
    .view-link:hover{
        color:var(--mesa-theme-on-primary,#fff);
        background:var(--mesa-shell-color,var(--primary));
    }
    .status{
        color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));
        background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 11%,var(--mesa-theme-surface,var(--surface)));
    }
    .status.cerrado,.status.completada{
        color:var(--mesa-state-success,var(--ok));
        background:color-mix(in srgb,var(--mesa-state-success,var(--ok)) 12%,var(--mesa-theme-surface,var(--surface)));
    }
    .status.cancelado,.status.cancelada{
        color:var(--mesa-state-danger,var(--danger));
        background:color-mix(in srgb,var(--mesa-state-danger,var(--danger)) 10%,var(--mesa-theme-surface,var(--surface)));
    }
    .case-detail-nav{display:flex;min-width:0;align-items:center;gap:10px}
    .case-detail-nav>strong{color:var(--case-family-text,var(--mesa-theme-heading,var(--navy)))}
    .case-detail-back{
        min-height:36px;
        display:inline-flex;
        align-items:center;
        padding:7px 11px;
        border:1px solid color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 30%,var(--mesa-theme-border,var(--border)));
        border-radius:9px;
        color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));
        background:var(--mesa-theme-soft,var(--soft));
        text-decoration:none;
        font-weight:850;
    }
    .case-detail-back:hover{border-color:var(--mesa-shell-color,var(--primary))}
    @media(max-width:620px){
        .case-detail-nav{width:100%;justify-content:space-between}
        .case-detail-nav>strong{font-size:12px}
    }
</style>

<!-- Base visual compartida del portal del solicitante: escala y densidad operativa. -->
<style id="solicitante-ui-compacta">
    :root{
        --font-base:clamp(14px,.78rem + .16vw,15px);
        --font-small:clamp(12px,.7rem + .12vw,13px);
        --font-title:clamp(22px,1.05rem + .62vw,26px);
        --card-radius:12px;
        --spacing-base:clamp(10px,.55rem + .32vw,14px);
        --button-size:36px;
    }
    body{font-size:var(--font-base);line-height:1.42}
    .shell{width:min(1440px,calc(100% - 28px));padding:10px 0 24px}
    .topbar{padding:9px 12px;border-radius:var(--card-radius)}
    .mark{width:34px;height:34px;border-radius:9px}.brand strong{font-size:var(--font-base)}.brand small,.muted,.help{font-size:var(--font-small)}
    .tabs{margin-top:8px;padding:5px}.tab{min-height:var(--button-size);padding:7px 12px;font-size:var(--font-small)}
    .grid-stats{gap:7px;margin:8px 0}.stat{padding:10px;border-radius:10px}.stat span{font-size:var(--font-small)}.stat strong{font-size:clamp(20px,1rem + .55vw,25px)}
    .card{margin-top:8px;padding:var(--spacing-base);border-radius:var(--card-radius)}
    .card-head{margin-bottom:10px}.card h1{font-size:var(--font-title);line-height:1.18}.card h2{font-size:clamp(17px,.9rem + .35vw,20px)}
    .form-grid{gap:10px}.field{gap:4px}.field label,.case-filter-field label{font-size:var(--font-small)}
    .field input,.field select,.field textarea{padding:8px 10px;font-size:var(--font-base)}
    .field textarea{min-height:96px}.actions{margin-top:10px}.btn{min-height:var(--button-size);padding:8px 13px;font-size:var(--font-small)}

    /* Áreas: se revierte la tarjeta alta posterior y se prioriza nombre + descripción. */
    .catalog-picker{grid-template-columns:repeat(auto-fit,minmax(100px,1fr));gap:5px 8px;align-items:start}
    .catalog-choice-body{height:auto!important;min-height:0!important;max-height:none!important;display:grid!important;grid-template-columns:1fr!important;grid-template-rows:18px 35px auto!important;gap:2px;padding:2px!important;align-items:center;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important}
    .catalog-choice-title{grid-column:1;grid-row:1;min-width:0;align-self:start;text-align:center}
    .catalog-choice-media{grid-column:1;grid-row:2;width:35px!important;height:35px!important;justify-self:center;overflow:hidden;border:0!important;border-radius:0!important;background:transparent!important}
    .catalog-choice .catalog-choice-media img{width:100%!important;height:100%!important;object-fit:contain}
    .catalog-choice strong{display:block;overflow:hidden;font-size:12px;font-weight:850;line-height:1.2;text-overflow:ellipsis;white-space:nowrap}
    .catalog-choice small{grid-column:1;grid-row:3;display:-webkit-box!important;min-width:0;max-width:100%;margin:0!important;overflow:hidden;color:var(--muted);font-size:11px;line-height:1.15;text-align:center;text-overflow:ellipsis;-webkit-box-orient:vertical;-webkit-line-clamp:2}
    .catalog-choice:hover .catalog-choice-body{transform:none;border-color:transparent;box-shadow:none;background:transparent}
    .catalog-choice input:checked+.catalog-choice-body{border:0!important;background:transparent!important;box-shadow:none!important;border-radius:0!important;color:var(--primary)}
    /* Catálogo de áreas: el label conserva la selección, pero no presenta una card. */
    .catalog-picker{display:flex;flex-wrap:wrap;justify-content:flex-start;align-content:flex-start;gap:8px;width:100%;max-width:none;align-items:flex-start}
    .area-selector-item{width:130px;min-width:130px;max-width:130px;display:flex!important;flex-direction:column;align-items:center;justify-content:center;min-height:0!important;padding:3px!important;border:0!important;border-radius:0!important;background:none!important;box-shadow:none!important}
    .area-selector-item .catalog-choice-body{display:contents!important}
    .area-name{width:100%;min-width:0;order:0;text-align:center}
    .area-name strong{display:block;width:100%;overflow:hidden;color:var(--navy);font-size:13px;font-weight:700;line-height:1.2;text-overflow:ellipsis;white-space:nowrap}
    .area-selector-item .catalog-choice-media{order:1;width:50px!important;height:50px!important;margin:3px 0 2px;display:grid;place-items:center;border:0!important;background:none!important}
    .area-icon{width:50px!important;height:50px!important;display:block;object-fit:contain;border:0!important;background:none!important}
    .area-description{order:2;width:100%;min-width:0;display:-webkit-box!important;overflow:hidden;color:var(--muted);font-size:13px;line-height:1.15;text-align:center;text-overflow:ellipsis;-webkit-box-orient:vertical;-webkit-line-clamp:2}
    .area-selector-item:hover,.area-selector-item:focus-within{background:none!important;box-shadow:none!important}
    .catalog-choice input:checked+.catalog-choice-body .area-name strong,.catalog-choice input:checked+.catalog-choice-body .area-description{color:var(--primary)}
    .area-selector-item:has(input:checked) .area-name strong,.area-selector-item:has(input:checked) .area-description{color:var(--primary)}
    .service-selection-layout{grid-template-columns:minmax(230px,.72fr) minmax(0,1.28fr);gap:10px}
    .field .service-combobox-input{min-height:var(--button-size)}.service-combobox-toggle{top:3px;right:3px;height:30px}.service-summary{min-height:var(--button-size)}
    .request-support-grid{gap:10px}.description-field textarea{min-height:92px}.file-dropzone{min-height:84px!important;padding:10px!important}.upload-icon{width:34px!important;height:34px!important}.file-status{font-size:var(--font-small)!important}

    /* Bandeja de solicitudes: densidad de tabla propia de una mesa operativa. */
    .case-state-tabs{gap:6px;margin-bottom:9px}.case-state-tab{min-height:34px!important;padding:6px 10px!important;font-size:var(--font-small)}.case-state-tab-count{min-width:19px;height:19px;font-size:11px}
    .case-filters{gap:8px;margin-bottom:9px;padding:9px!important}.case-filter-field input{height:36px!important;font-size:var(--font-base)}.case-filter-count{padding:7px 2px;font-size:var(--font-small)}
    th,td{padding:9px 10px;font-size:var(--font-base)}th{font-size:var(--font-small)}.status{padding:3px 7px;font-size:12px;line-height:1.35}.case-number{padding:3px 7px;font-size:12px}.view-link{min-height:32px;padding:6px 9px;font-size:12px}

    /* Detalle: bloques breves, información clave en una cuadrícula legible. */
    .case-detail-page .case-detail-card>.card-head{min-height:82px;padding:16px clamp(16px,1.8vw,26px)!important}.case-detail-page .case-detail-card>.card-head h2{font-size:var(--font-title)}
    .case-detail-page .request-summary{margin:12px 14px 10px!important}.case-detail-page .request-summary-item{height:auto;min-height:56px;padding:10px 12px!important}.case-detail-page .request-summary-item strong{font-size:var(--font-base)!important}.case-detail-page .request-summary-item p{font-size:var(--font-small)!important}
    .case-detail-page .case-detail-card .detail-grid{margin:0 14px 10px!important;gap:0}.case-detail-page .case-detail-card .detail-item{min-height:62px;padding:9px 11px!important}.case-detail-page .case-detail-card .detail-item strong{font-size:var(--font-small)!important}
    .case-detail-page .public-resolution,.case-detail-page .public-trace{margin:10px 14px!important;padding:12px!important}.case-detail-page .public-resolution-head h3,.case-detail-page .public-trace-head h3{font-size:16px!important}.public-trace-node{padding:9px 10px}.public-trace-answers{margin-top:7px;gap:6px}.public-trace-answer{padding:7px}

    /* Conversación contextual del detalle. */
    .chat-launcher{right:18px;bottom:16px;min-height:44px;padding:7px 12px 7px 8px;font-size:var(--font-small)}.chat-launcher-icon{width:29px;height:29px}.chat-panel{width:min(410px,calc(100vw - 24px));height:min(610px,calc(100dvh - 42px));border-radius:15px}.chat-header{padding:11px 12px}.chat-header-avatar{width:34px;height:34px}.chat-stage{padding:8px 10px}.chat-timeline{gap:7px;padding:11px}.chat-profile-image,.chat-profile-fallback{width:26px;height:26px;flex-basis:26px}.chat-author-row{gap:6px;margin-bottom:4px}.chat-bubble{padding:8px 10px 6px}.chat-text{font-size:var(--font-small)}.chat-compose{padding:8px}.chat-compose textarea{font-size:var(--font-small)}
    @media(max-width:760px){.shell{width:calc(100% - 16px)}.catalog-picker{grid-template-columns:1fr 1fr}.service-selection-layout{grid-template-columns:1fr}.case-detail-page .request-summary,.case-detail-page .case-detail-card .detail-grid,.case-detail-page .public-resolution,.case-detail-page .public-trace{margin-right:10px!important;margin-left:10px!important}}
    @media(max-width:480px){.catalog-picker{grid-template-columns:1fr}.grid-stats,.detail-grid{grid-template-columns:1fr 1fr}.card{padding:10px}.case-detail-page .request-summary,.case-detail-page .public-resolution,.case-detail-page .public-trace{margin-right:0!important;margin-left:0!important}}
    </style>
    <style id="solicitante-detalle-corporativo">
        /* Ficha de caso: jerarquía visual corporativa sin modificar su flujo. */
        .case-detail-page{
            padding:clamp(8px,1vw,16px) 0 22px;
            background:
                radial-gradient(circle at 100% 0,rgba(36,132,232,.10),transparent 30%),
                linear-gradient(180deg,#edf5fc 0%,#f7fafc 58%,#edf4fa 100%)!important;
        }
        .case-detail-page .case-detail-modal{
            padding:0 clamp(8px,1.15vw,18px)!important;
            background:transparent!important;
        }
        .case-detail-page .case-detail-dialog{
            border:1px solid #c9d9e8!important;
            border-radius:16px!important;
            background:#f8fbff!important;
            box-shadow:0 18px 46px rgba(18,58,95,.16)!important;
        }
        .case-detail-page .case-detail-modal-bar{
            min-height:52px;
            padding:9px clamp(14px,1.8vw,26px)!important;
            border-bottom:1px solid #d5e2ee!important;
            background:linear-gradient(180deg,#fff 0%,#f3f8fc 100%)!important;
            box-shadow:0 4px 12px rgba(18,58,95,.08)!important;
        }
        .case-detail-page .case-detail-nav>strong{
            color:#153d60!important;
            font-size:13px!important;
            letter-spacing:.01em;
        }
        .case-detail-page .case-detail-back{
            min-height:32px;
            padding:6px 10px;
            border:1px solid #a9c5df;
            border-radius:8px;
            color:#0b5fae;
            background:#fff;
            font-size:11px;
            font-weight:850;
            transition:background .16s ease,border-color .16s ease,transform .16s ease;
        }
        .case-detail-page .case-detail-back:hover{border-color:#0f6fec;background:#eef6ff;transform:translateY(-1px)}
        .case-detail-page .case-detail-card>.card-head{
            min-height:96px!important;
            padding:19px clamp(18px,2.2vw,32px)!important;
            background:linear-gradient(120deg,#0a3865 0%,#0d5ea8 57%,#197fe2 100%)!important;
            box-shadow:inset 0 -1px 0 rgba(255,255,255,.15),0 8px 18px rgba(9,67,123,.16)!important;
        }
        .case-detail-page .case-detail-card>.card-head h2{font-size:clamp(22px,1.55vw,27px)!important}
        .case-detail-page .case-detail-card>.card-head h2::after{display:none!important}
        .case-detail-page .case-detail-subtitle{position:relative;z-index:1;margin:5px 0 0;color:rgba(255,255,255,.82);font-size:12px;line-height:1.35}
        .case-detail-page .case-detail-card>.card-head .status{
            padding:6px 11px!important;
            border-color:rgba(255,255,255,.46)!important;
            background:rgba(255,255,255,.16)!important;
            box-shadow:0 3px 9px rgba(4,32,61,.16);
        }
        .case-detail-page .request-summary{
            display:grid!important;
            grid-template-columns:minmax(180px,.75fr) minmax(0,2fr);
            margin:15px 18px 12px!important;
            padding:0 16px!important;
            border:1px solid #c7d9e8!important;
            border-left:5px solid #1478e6!important;
            border-radius:12px!important;
            background:linear-gradient(180deg,#fff,#fbfdff)!important;
            box-shadow:0 7px 18px rgba(22,65,101,.07)!important;
        }
        .case-detail-page .request-summary-item{padding:12px 0!important}
        .case-detail-page .request-summary-item+.request-summary-item{border-top:0!important;border-left:1px solid #d8e5ef;padding-left:18px!important}
        .case-detail-page .request-summary-item>span{color:#416985!important;font-size:10px!important;letter-spacing:.08em}
        .case-detail-page .request-summary-item strong{color:#143b5d!important;font-size:15px!important}
        .case-detail-page .request-summary-item p{color:#355873!important;font-size:13px!important;line-height:1.55}
        .case-detail-page .request-summary-meta{grid-column:1/-1;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));margin:0 -16px;border-top:1px solid #d8e5ef;background:#eef6fd}
        .case-detail-page .request-summary-meta>div{min-width:0;padding:11px 17px}
        .case-detail-page .request-summary-meta>div+div{border-left:1px solid #d8e5ef}
        .case-detail-page .request-summary-meta span{display:block;color:#52718a;font-size:9px;font-weight:850;letter-spacing:.07em;text-transform:uppercase}
        .case-detail-page .request-summary-meta strong{display:block;margin-top:3px;overflow:hidden;color:#173d5e;font-size:12px;text-overflow:ellipsis;white-space:nowrap}
        .case-detail-page .request-summary-meta small{display:block;margin-top:2px;overflow:hidden;color:#62788c;font-size:9px;text-overflow:ellipsis;white-space:nowrap}
        .case-detail-page .case-detail-card .detail-grid{
            grid-template-columns:repeat(4,minmax(0,1fr));
            gap:8px;
            margin:0 18px 14px!important;
            overflow:visible!important;
            border:0!important;
            background:transparent!important;
            box-shadow:none!important;
        }
        .case-detail-page .case-detail-card .detail-item{
            min-height:66px!important;
            padding:11px 13px!important;
            border:1px solid #cadbea!important;
            border-radius:10px!important;
            background:linear-gradient(145deg,#f7fbff,#edf5fc)!important;
            box-shadow:0 4px 11px rgba(22,65,101,.045);
        }
        .case-detail-page .case-detail-card .detail-item:first-child{grid-column:span 2}
        .case-detail-page .case-detail-card .detail-item span{color:#52718a!important;font-size:9px!important;letter-spacing:.07em}
        .case-detail-page .case-detail-card .detail-item strong{margin-top:4px;color:#173d5e!important;font-size:12px!important;line-height:1.35}
        .request-flow-summary{margin:0 18px 14px;padding:15px 16px 14px;border:1px solid #c7d9e8;border-radius:12px;background:linear-gradient(180deg,#fff,#f7fbff);box-shadow:0 7px 18px rgba(22,65,101,.06)}
        .case-detail-page .request-flow-summary{order:4}
        .case-detail-page .requester-case-tabs{order:5}
        .case-detail-page .public-resolution{order:6}
        .case-detail-page .public-trace{order:7}
        .request-flow-summary-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:13px;padding-bottom:10px;border-bottom:1px solid #dce8f1}
        .request-flow-summary-head span{display:block;color:#54718a;font-size:10px;font-weight:850;letter-spacing:.07em;text-transform:uppercase}
        .request-flow-summary-head h3{margin:3px 0 0;color:#153d60;font-size:16px}
        .request-flow-summary-head>strong{padding:5px 9px;border-radius:999px;color:#0b5fae;background:#eaf4ff;font-size:10px;white-space:nowrap}
        .request-flow-line{display:flex;align-items:stretch;gap:0;overflow-x:auto;padding:2px 0 3px;scrollbar-width:thin}
        .request-flow-step{position:relative;display:grid;grid-template-columns:30px minmax(150px,1fr);gap:8px;min-width:190px;flex:1;padding:0 12px 0 0}
        .request-flow-step:not(:last-child)::after{content:"";position:absolute;top:14px;left:30px;right:10px;height:2px;background:#cbddea}
        .request-flow-step.is-complete:not(:last-child)::after{background:#0b8a58}
        .request-flow-marker{position:relative;z-index:1;width:28px;height:28px;display:grid;place-items:center;border:2px solid #1478e6;border-radius:50%;color:#fff;background:#1478e6;font-size:12px;font-weight:900;box-shadow:0 0 0 3px #fff}
        .request-flow-step.is-complete .request-flow-marker{border-color:#0b8a58;background:#0b8a58}
        .request-flow-step-copy{min-width:0;padding-top:1px}
        .request-flow-step-copy strong{display:block;overflow:hidden;color:#153d60;font-size:12px;text-overflow:ellipsis;white-space:nowrap}
        .request-flow-step-copy small{display:block;margin-top:2px;overflow:hidden;color:#627b91;font-size:10px;text-overflow:ellipsis;white-space:nowrap}
        .request-flow-step-copy .request-flow-assignee{color:#45657e;font-size:9px}
        .request-flow-step-copy em{display:block;margin-top:4px;color:#1478e6;font-size:9px;font-style:normal;font-weight:800}
        .request-flow-step.is-complete .request-flow-step-copy em{color:#087443}
        .case-detail-page .public-resolution.is-pending{border-color:#b9d7ef!important;border-left-color:#1478e6!important;background:linear-gradient(120deg,#eff7ff,#fbfdff)!important;box-shadow:0 8px 19px rgba(20,120,230,.08)!important}
        .case-detail-page .public-resolution.is-pending .public-resolution-head h3{color:#173d5e!important}
        @media(max-width:760px){
            .case-detail-page .request-summary{grid-template-columns:1fr}
            .case-detail-page .request-summary-item+.request-summary-item{border-top:1px solid #d8e5ef!important;border-left:0;padding-left:0!important}
            .case-detail-page .request-summary-meta{grid-template-columns:repeat(2,minmax(0,1fr));margin-right:-12px;margin-left:-12px}
            .case-detail-page .request-summary-meta>div+div{border-left:1px solid #d8e5ef}
            .case-detail-page .request-summary-meta>div:nth-child(n+3){border-top:1px solid #d8e5ef}
            .request-flow-summary{margin-right:10px;margin-left:10px}
            .request-flow-line{display:grid;grid-template-columns:1fr;gap:10px;overflow:visible}
            .request-flow-step{min-width:0;grid-template-columns:30px minmax(0,1fr);padding:0}
            .request-flow-step:not(:last-child)::after{top:28px;bottom:-10px;left:13px;right:auto;width:2px;height:auto}
        }
        .case-detail-page .public-resolution{
            margin:2px 18px 14px!important;
            padding:15px 17px!important;
            border:1px solid #a7d9c0!important;
            border-left:5px solid #07814c!important;
            border-radius:12px!important;
            background:linear-gradient(120deg,#effaf4,#fbfefc)!important;
            box-shadow:0 8px 19px rgba(7,129,76,.08)!important;
        }
        .case-detail-page .public-resolution-head h3,.case-detail-page .public-trace-head h3{color:#173d5e!important;font-size:16px!important}
        .case-detail-page .public-resolution-head p,.case-detail-page .public-trace-head p{color:#607b91!important;font-size:11px!important}
        .case-detail-page .public-resolution-area{border:1px solid #b5dfc9;color:#087443!important;background:#e2f6ea!important}
        .case-detail-page .public-trace{
            margin:0 18px 18px!important;
            padding:16px 17px 18px!important;
            border:1px solid #c7d9e8!important;
            border-radius:12px!important;
            background:linear-gradient(180deg,#fff,#f8fbfe)!important;
            box-shadow:0 8px 20px rgba(22,65,101,.07)!important;
        }
        .case-detail-page .public-trace-head{margin-bottom:14px}
        .case-detail-page .public-trace-node{
            padding:12px 14px 12px 38px!important;
            border:1px solid #c9dbea!important;
            border-radius:10px!important;
            background:linear-gradient(145deg,#fbfdff,#f1f7fc)!important;
            box-shadow:0 4px 10px rgba(22,65,101,.045)!important;
            transition:border-color .16s ease,box-shadow .16s ease,transform .16s ease;
        }
        .case-detail-page .public-trace-node:hover{border-color:#8ebbe4!important;box-shadow:0 8px 17px rgba(22,65,101,.10)!important;transform:translateY(-1px)}
        .case-detail-page .public-trace-label strong{color:#173d5e!important;font-size:13px!important}
        .case-detail-page .public-trace-service{color:#627f95!important;font-size:11px!important}
        .case-detail-page .public-trace-kind{color:#0b65b8!important;background:#e7f3ff!important;border:1px solid #c3def6}
        .case-detail-page .public-trace-node .status{box-shadow:0 2px 6px rgba(17,80,137,.10)}
        @media(max-width:900px){
            .case-detail-page .case-detail-card .detail-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
            .case-detail-page .case-detail-card .detail-item:first-child{grid-column:span 2}
        }
        @media(max-width:760px){
            .case-detail-page{padding-top:0}
            .case-detail-page .case-detail-modal{padding:0!important}
            .case-detail-page .case-detail-dialog{border-radius:0!important;box-shadow:none!important}
            .case-detail-page .case-detail-card>.card-head{min-height:84px!important;padding:16px 18px!important}
            .case-detail-page .request-summary,.case-detail-page .case-detail-card .detail-grid,.case-detail-page .public-resolution,.case-detail-page .public-trace{margin-right:10px!important;margin-left:10px!important}
            .case-detail-page .case-detail-card .detail-grid{gap:6px}
        }
        @media(max-width:480px){
            .case-detail-page .case-detail-card .detail-grid{grid-template-columns:1fr}
            .case-detail-page .case-detail-card .detail-item:first-child{grid-column:auto}
            .case-detail-page .request-summary,.case-detail-page .public-resolution,.case-detail-page .public-trace{margin-right:0!important;margin-left:0!important}
        }
    </style>
    <style id="solicitante-remove-trace-dots">
        /* La trazabilidad conserva la línea de recorrido, sin círculos/puntos. */
        .case-detail-page .public-trace-node::before{display:none!important;content:none!important}
    </style>
    <style id="solicitante-service-layout-wide">
        /* En Crear solicitud el buscador queda compacto y el resumen aprovecha
           todo el ancho restante para evitar descripciones innecesariamente
           largas en vertical. */
        @media(min-width:761px){
            .service-selection-layout{
                grid-template-columns:minmax(210px,240px) minmax(0,1fr)!important;
                gap:10px!important;
            }
            .service-selection-layout .service-summary{
                width:100%!important;
                min-width:0!important;
                max-width:none!important;
            }
        }
    </style>
    <style id="solicitante-description-responsive">
        /* El asunto y la descripción aprovechan la mayor parte del formulario;
           los adjuntos conservan una columna útil sin forzar saltos estrechos. */
        .request-support-grid{
            grid-template-columns:minmax(0,1.55fr) minmax(250px,.8fr)!important;
            gap:12px!important;
        }
        .request-text-column,
        .description-field,
        .description-field textarea{
            width:100%;
            min-width:0;
            box-sizing:border-box;
        }
        .description-field textarea{
            min-height:64px!important;
            max-height:360px!important;
            resize:vertical;
            overflow-y:hidden;
        }
        @media(max-width:980px) and (min-width:761px){
            .request-support-grid{
                grid-template-columns:minmax(0,1.25fr) minmax(220px,.75fr)!important;
            }
        }
        @media(max-width:760px){
            .request-support-grid{grid-template-columns:1fr!important;}
        }
    </style>
    <style id="solicitante-summary-content-width">
        /* El resumen no debe estirarse hasta el borde por defecto: su ancho
           se calcula por el contenido y queda limitado por la columna disponible. */
        @media(min-width:761px){
            .service-selection-layout .service-summary:not(.empty){
                width:fit-content!important;
                min-width:0!important;
                max-width:100%!important;
                justify-self:start!important;
            }
            .service-selection-layout .service-summary:not(.empty) .service-summary-copy{
                width:fit-content;
                max-width:100%;
            }
        }
        @media(max-width:760px){
            .service-selection-layout .service-summary:not(.empty){
                width:100%!important;
                min-width:0!important;
                max-width:100%!important;
            }
        }
    </style>
    <style id="solicitante-plain-page-heading">
        /* La cabecera de Crear solicitud se integra con la tarjeta blanca; no
           debe mostrarse como una franja azul independiente. */
        body.mesa-php-shell main.shell:not(.case-detail-page)>section.card>.card-head{
            background:transparent!important;
            border-bottom-color:transparent!important;
        }
    </style>
    <style id="solicitante-manager-visual">
        /* La ficha pública conserva sus permisos, pero comparte la misma
           composición visual de la ficha que usa el gestor. */
        .case-detail-page .case-detail-card>.card-head{min-height:104px!important;padding:22px clamp(20px,2.4vw,36px)!important}
        .case-detail-page .case-detail-card .detail-grid{grid-template-columns:repeat(6,minmax(0,1fr))!important;gap:0!important;margin:0 18px 14px!important;overflow:hidden!important;border:1px solid #d5e2ec!important;border-radius:12px!important;background:#fff!important;box-shadow:0 6px 18px rgba(25,55,83,.055)!important}
        .case-detail-page .case-detail-card .detail-item{min-height:70px!important;padding:13px 14px!important;border:0!important;border-right:1px solid #d5e2ec!important;border-radius:0!important;background:#fff!important;box-shadow:none!important}
        .case-detail-page .case-detail-card .detail-item:last-child{border-right:0!important}
        .case-detail-page .case-detail-card .detail-item:first-child{grid-column:auto!important}
        .case-detail-page .request-flow-summary{margin:0!important;padding:18px clamp(20px,2.4vw,36px) 20px!important;border:0!important;border-top:1px solid #d5e2ec!important;border-bottom:1px solid #d5e2ec!important;border-radius:0!important;background:#fff!important;box-shadow:none!important}
        .case-detail-page .request-flow-summary-head{margin-bottom:15px;padding-bottom:10px}
        .case-detail-page .request-flow-line{display:flex;overflow:visible;padding:4px 0 0}
        .case-detail-page .request-flow-step{display:grid;grid-template-columns:1fr;justify-items:center;gap:6px;min-width:0;padding:0;text-align:center}
        .case-detail-page .request-flow-step:not(:last-child)::after{top:15px;left:calc(50% + 16px);right:calc(-50% + 16px);width:auto;height:2px}
        .case-detail-page .request-flow-marker{width:30px;height:30px}
        .case-detail-page .request-flow-step-copy{width:100%;padding-top:0}
        .case-detail-page .request-flow-step-copy strong,.case-detail-page .request-flow-step-copy small,.case-detail-page .request-flow-step-copy em{white-space:nowrap;text-align:center}
        .case-detail-page .request-flow-step-copy strong{font-size:11px}
        .case-detail-page .request-flow-step-copy small{font-size:9px}
        .case-detail-page .request-flow-step-copy .request-flow-assignee{font-size:8px}
        .case-detail-page .request-flow-step-copy em{font-size:9px}
        .case-detail-page .request-flow-step.is-done .request-flow-marker{border-color:#07814c;background:#07814c}
        .case-detail-page .request-flow-step.is-done:not(:last-child)::after{background:#07814c}
        .case-detail-page .request-flow-step.is-current:not(:last-child)::after{background:#1478e6}
        .case-detail-page .request-flow-step.is-pending .request-flow-marker{border-color:#cbd8e3;color:#fff;background:#cbd8e3}
        .case-detail-page .request-flow-step.is-pending .request-flow-step-copy em{color:#6f8496}
        .case-detail-page .public-resolution,.case-detail-page .public-trace{margin-right:18px!important;margin-left:18px!important}
        .case-detail-page .requester-case-tabs{display:flex;align-items:center;gap:4px;padding:8px clamp(20px,2.4vw,36px);border-top:1px solid #d5e2ec;border-bottom:1px solid #d5e2ec;background:#fff}
        .case-detail-page .requester-case-tab{display:inline-flex;align-items:center;gap:6px;min-height:34px;padding:7px 12px;border:1px solid transparent;border-radius:8px;color:#5e7890;background:transparent;text-decoration:none;font-size:11px;font-weight:850;white-space:nowrap}
        .case-detail-page .requester-case-tab:hover{border-color:#c6dbea;color:#0b5fae;background:#f2f8fe}
        .case-detail-page .requester-case-tab.is-active{border-color:#1478e6;color:#fff;background:#1478e6;box-shadow:0 4px 10px rgba(20,120,230,.18)}
        @media(max-width:1100px){.case-detail-page .case-detail-card .detail-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important}.case-detail-page .case-detail-card .detail-item:nth-child(3n){border-right:0!important}.case-detail-page .case-detail-card .detail-item:nth-child(n+4){border-top:1px solid #d5e2ec!important}}
        @media(max-width:760px){
            .case-detail-page .case-detail-card .detail-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important;margin-right:10px!important;margin-left:10px!important}
            .case-detail-page .case-detail-card .detail-item{min-height:62px!important}
            .case-detail-page .request-flow-summary{padding-right:14px!important;padding-left:14px!important}
            .case-detail-page .requester-case-tabs{gap:2px;overflow-x:auto;padding-right:14px;padding-left:14px}
            .case-detail-page .requester-case-tab{padding-right:9px;padding-left:9px;font-size:10px}
            .case-detail-page .request-flow-line{display:grid;gap:10px;overflow:visible}
            .case-detail-page .request-flow-step{grid-template-columns:30px minmax(0,1fr);justify-items:initial;text-align:left}
            .case-detail-page .request-flow-step:not(:last-child)::after{top:30px;bottom:-10px;left:14px;right:auto;width:2px;height:auto}
            .case-detail-page .request-flow-step-copy strong,.case-detail-page .request-flow-step-copy small,.case-detail-page .request-flow-step-copy em{text-align:left}
        }
        @media(max-width:480px){.case-detail-page .case-detail-card .detail-grid{grid-template-columns:1fr!important;margin-right:0!important;margin-left:0!important}.case-detail-page .case-detail-card .detail-item{border-right:0!important;border-top:1px solid #d5e2ec!important}.case-detail-page .case-detail-card .detail-item:first-child{border-top:0!important}.case-detail-page .request-summary-meta{grid-template-columns:1fr}.case-detail-page .request-summary-meta>div+div{border-left:0;border-top:1px solid #d8e5ef!important}}
        .case-detail-page .case-detail-card>.card-head{color:#17334d!important;background:#fff!important;box-shadow:none!important;border-bottom:1px solid #d5e2ec!important}
        .case-detail-page .case-detail-card>.card-head h2{color:#17334d!important}
        .case-detail-page .case-detail-card>.card-head .case-detail-subtitle{color:#62788c!important}
        .case-detail-page .case-detail-card>.card-head .status{border:1px solid #c5dbea!important;color:#1769aa!important;background:#edf6ff!important;box-shadow:none!important}
        .case-detail-page .requester-case-title-line{display:flex;align-items:center;gap:7px;margin-bottom:7px}
        .case-detail-page .requester-case-code{display:inline-flex;align-items:center;min-height:25px;padding:4px 8px;border:1px solid #8ab9e9;border-radius:7px;color:#0b5fae;background:#f1f8ff;font-size:11px;font-weight:850}
        .case-detail-page .requester-case-title-line .status{min-height:25px;padding:4px 8px!important;font-size:10px!important}
        .case-detail-page .requester-header-metadata{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));margin:0;border-bottom:1px solid #d5e2ec;background:#fff}
        .case-detail-page .requester-header-metadata>div{min-width:0;padding:14px 16px;border-right:1px solid #d5e2ec}
        .case-detail-page .requester-header-metadata>div:last-child{border-right:0}
        .case-detail-page .requester-header-metadata span{display:block;color:#62788c;font-size:9px;font-weight:850;letter-spacing:.06em;text-transform:uppercase}
        .case-detail-page .requester-header-metadata strong{display:block;margin-top:4px;overflow:hidden;color:#17334d;font-size:12px;line-height:1.3;text-overflow:ellipsis;white-space:nowrap}
        .case-detail-page .requester-header-metadata small{display:block;margin-top:2px;overflow:hidden;color:#62788c;font-size:9px;text-overflow:ellipsis;white-space:nowrap}
        .case-detail-page .requester-header-metadata .due strong{color:#d12a2a}
        .case-detail-page .requester-secondary-overview{order:6;width:100%}
        .case-detail-page .requester-extra-info{margin:14px 0 0;padding:15px 17px;border:1px solid #c7d9e8;border-left:4px solid #1478e6;border-radius:12px;background:linear-gradient(180deg,#fff,#f8fbfe);box-shadow:0 8px 20px rgba(22,65,101,.07)}
        .case-detail-page .requester-extra-info-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:10px;border-bottom:1px solid #d9e6ef}
        .case-detail-page .requester-extra-info-head span{display:block;color:#52718a;font-size:10px;font-weight:850;letter-spacing:.07em;text-transform:uppercase}
        .case-detail-page .requester-extra-info-head h3{margin:3px 0 0;color:#173d5e;font-size:16px}
        .case-detail-page .requester-extra-info-head>strong{padding:5px 9px;border-radius:999px;color:#0b5fae;background:#eaf4ff;font-size:10px;white-space:nowrap}
        .case-detail-page .requester-extra-info-list{display:grid;gap:10px;margin-top:11px}
        .case-detail-page .requester-extra-info-group{padding:11px 12px;border:1px solid #d5e2ec;border-radius:9px;background:#fff}
        .case-detail-page .requester-extra-info-group-head{display:flex;align-items:baseline;justify-content:space-between;gap:10px;margin-bottom:8px;padding-bottom:7px;border-bottom:1px solid #e0eaf2}
        .case-detail-page .requester-extra-info-group-head strong{color:#173d5e;font-size:12px}
        .case-detail-page .requester-extra-info-group-head span{color:#62788c;font-size:10px;text-align:right}
        .case-detail-page .requester-extra-info-group dl{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin:0}
        .case-detail-page .requester-extra-info-group dl>div{min-width:0;padding:7px 8px;border-radius:7px;background:#f7fbff}
        .case-detail-page .requester-extra-info-group dt{color:#62788c;font-size:9px;font-weight:850;letter-spacing:.04em;text-transform:uppercase}
        .case-detail-page .requester-extra-info-group dd{margin:3px 0 0;color:#173d5e;font-size:11px;line-height:1.4;overflow-wrap:anywhere;white-space:pre-line}
        .case-detail-page .requester-tab-panel[hidden]{display:none!important}
        .case-detail-page .requester-tab-panel{order:6}
        .case-detail-page .requester-structure-panel,.case-detail-page .requester-attachments-panel{margin:14px 18px!important;padding:16px 17px 18px;border:1px solid #c7d9e8;border-radius:12px;background:linear-gradient(180deg,#fff,#f8fbfe);box-shadow:0 8px 20px rgba(22,65,101,.07)}
        .case-detail-page .requester-structure-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:11px;border-bottom:1px solid #d9e6ef}
        .case-detail-page .requester-structure-head span{display:block;color:#52718a;font-size:10px;font-weight:850;letter-spacing:.07em;text-transform:uppercase}
        .case-detail-page .requester-structure-head h3{margin:3px 0 0;color:#173d5e;font-size:16px}
        .case-detail-page .requester-structure-head>strong{padding:5px 9px;border-radius:999px;color:#0b5fae;background:#eaf4ff;font-size:10px;white-space:nowrap}
        .case-detail-page .requester-structure-list{display:grid;gap:9px;margin-top:12px;max-height:520px;overflow:auto;padding:2px 5px 4px 1px}
        .case-detail-page .requester-structure-node{position:relative;display:grid;grid-template-columns:30px minmax(0,1fr);gap:10px;margin-left:calc(var(--structure-level,0) * 20px);padding:12px 13px;border:1px solid #c9dbea;border-radius:10px;background:#fff;box-shadow:0 3px 10px rgba(31,65,94,.05)}
        .case-detail-page .requester-structure-node.is-derived{border-left:3px solid #1478e6;background:#f7fbff}
        .case-detail-page .requester-structure-number{width:27px;height:27px;display:grid;place-items:center;border-radius:50%;color:#fff;background:#1478e6;font-size:11px;font-weight:900}
        .case-detail-page .requester-structure-copy{min-width:0}.case-detail-page .requester-structure-top{display:flex;align-items:center;justify-content:space-between;gap:8px}.case-detail-page .requester-structure-top span{color:#52718a;font-size:9px;font-weight:850;letter-spacing:.06em;text-transform:uppercase}.case-detail-page .requester-structure-top b{padding:4px 7px;border-radius:999px;color:#087443;background:#e5f7ed;font-size:9px;white-space:nowrap}.case-detail-page .requester-structure-copy>strong{display:block;margin-top:4px;color:#173d5e;font-size:13px}.case-detail-page .requester-structure-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:9px;padding-top:8px;border-top:1px solid #e0eaf2}.case-detail-page .requester-structure-meta span{display:block;color:#173d5e;font-size:10px}.case-detail-page .requester-structure-meta b{display:block;margin-bottom:2px;color:#6a8194;font-size:8px;letter-spacing:.05em;text-transform:uppercase}.case-detail-page .requester-attachments-list{display:grid;gap:7px;margin-top:12px}.case-detail-page .requester-attachments-list a{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;border:1px solid #d5e2ec;border-radius:9px;color:#173d5e;background:#fff;text-decoration:none}.case-detail-page .requester-attachments-list a:hover{border-color:#7fb4ea;background:#f3f8fe}.case-detail-page .requester-attachments-list b,.case-detail-page .requester-attachments-list small{display:block}.case-detail-page .requester-attachments-list b{font-size:11px}.case-detail-page .requester-attachments-list small{margin-top:2px;color:#6b8193;font-size:9px}.case-detail-page .requester-attachments-list>a>strong{color:#1478e6;font-size:18px}.case-detail-page .requester-panel-empty{margin:13px 0 0;color:#62788c;font-size:12px}
        @media(max-width:760px){.case-detail-page .requester-structure-panel,.case-detail-page .requester-attachments-panel{margin-right:10px!important;margin-left:10px!important}.case-detail-page .requester-structure-list{max-height:430px}.case-detail-page .requester-structure-node{margin-left:calc(var(--structure-level,0) * 10px)}.case-detail-page .requester-structure-meta{grid-template-columns:1fr}.case-detail-page .requester-structure-head{display:block}.case-detail-page .requester-structure-head>strong{display:inline-flex;margin-top:8px}.case-detail-page .requester-extra-info-group dl{grid-template-columns:1fr}.case-detail-page .requester-extra-info-head,.case-detail-page .requester-extra-info-group-head{display:block}.case-detail-page .requester-extra-info-head>strong{display:inline-flex;margin-top:8px}.case-detail-page .requester-extra-info-group-head span{display:block;margin-top:3px;text-align:left}}
        .case-detail-page .requester-history-panel{margin:14px 18px!important;padding:16px 17px 18px;border:1px solid #c7d9e8;border-radius:12px;background:linear-gradient(180deg,#fff,#f8fbfe);box-shadow:0 8px 20px rgba(22,65,101,.07)}
        .case-detail-page .requester-history-panel .requester-structure-head p{margin:4px 0 0;color:#62788c;font-size:11px}
        .case-detail-page .requester-history-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-top:12px;max-height:560px;overflow:auto;padding:2px 5px 4px 1px}
        .case-detail-page .requester-history-item{display:grid;grid-template-columns:30px minmax(0,1fr);gap:10px;min-width:0;padding:12px 13px;border:1px solid #c9dbea;border-radius:10px;background:#fff;box-shadow:0 3px 10px rgba(31,65,94,.05)}
        .case-detail-page .requester-history-number{width:27px;height:27px;display:grid;place-items:center;border-radius:50%;color:#fff;background:#1478e6;font-size:11px;font-weight:900}
        .case-detail-page .requester-history-copy{min-width:0}.case-detail-page .requester-history-top{display:flex;align-items:flex-start;justify-content:space-between;gap:8px}.case-detail-page .requester-history-top span,.case-detail-page .requester-history-label{display:block;color:#52718a;font-size:9px;font-weight:850;letter-spacing:.06em;text-transform:uppercase}.case-detail-page .requester-history-top time{color:#62788c;font-size:9px;white-space:nowrap}.case-detail-page .requester-history-copy>strong{display:block;margin-top:4px;color:#173d5e;font-size:13px}.case-detail-page .requester-history-label{margin-top:9px}.case-detail-page .requester-history-copy p{margin:4px 0 0;color:#355873;font-size:11px;line-height:1.45;white-space:pre-line;overflow-wrap:anywhere}.case-detail-page .requester-history-actor{margin-top:9px;padding-top:7px;border-top:1px solid #dce7ef;color:#62788c;font-size:9px}.case-detail-page .requester-history-actor b{color:#173d5e}
        @media(max-width:760px){.case-detail-page .requester-header-metadata{grid-template-columns:repeat(2,minmax(0,1fr))}.case-detail-page .requester-header-metadata>div:nth-child(2n){border-right:0}.case-detail-page .requester-header-metadata>div:nth-child(n+3){border-top:1px solid #d5e2ec}.case-detail-page .requester-structure-panel,.case-detail-page .requester-attachments-panel,.case-detail-page .requester-history-panel{margin-right:10px!important;margin-left:10px!important}.case-detail-page .requester-structure-list{max-height:430px}.case-detail-page .requester-structure-node{margin-left:calc(var(--structure-level,0) * 10px)}.case-detail-page .requester-structure-meta{grid-template-columns:1fr}.case-detail-page .requester-structure-head{display:block}.case-detail-page .requester-structure-head>strong{display:inline-flex;margin-top:8px}.case-detail-page .requester-history-list{grid-template-columns:1fr;max-height:430px}}
        @media(max-width:480px){.case-detail-page .requester-header-metadata{grid-template-columns:1fr}.case-detail-page .requester-header-metadata>div{border-right:0!important;border-top:1px solid #d5e2ec}.case-detail-page .requester-header-metadata>div:first-child{border-top:0}.case-detail-page .requester-structure-panel,.case-detail-page .requester-attachments-panel,.case-detail-page .requester-history-panel{margin-right:0!important;margin-left:0!important}}
        .case-detail-page .requester-structure-actions{display:flex;justify-content:flex-end;margin-top:9px;padding-top:8px;border-top:1px solid #e0eaf2}.case-detail-page .requester-solution-button{min-height:30px;padding:6px 10px;border:1px solid #8ab9e9;border-radius:7px;color:#0b5fae;background:#f4f9ff;font:inherit;font-size:10px;font-weight:850;cursor:pointer}.case-detail-page .requester-solution-button:hover{border-color:#1478e6;background:#e7f2ff}
        .case-detail-page .requester-solution-modal{position:fixed;inset:0;z-index:2147483500;display:grid;place-items:center;padding:20px;background:rgba(11,43,75,.58);backdrop-filter:blur(3px)}.case-detail-page .requester-solution-modal[hidden]{display:none!important}.case-detail-page .requester-solution-dialog{position:relative;width:min(430px,calc(100vw - 30px));padding:20px;border:1px solid #c8dbea;border-radius:14px;background:#fff;box-shadow:0 24px 60px rgba(4,30,60,.32)}.case-detail-page .requester-solution-close{position:absolute;top:12px;right:12px;width:28px;height:28px;border:1px solid #cbdbea;border-radius:7px;color:#315b7e;background:#fff;font-size:18px;line-height:1;cursor:pointer}.case-detail-page .requester-solution-close:hover{border-color:#7fb4ea;color:#0b5fae;background:#eef6ff}.case-detail-page .requester-solution-kicker{display:block;color:#52718a;font-size:9px;font-weight:850;letter-spacing:.07em;text-transform:uppercase}.case-detail-page .requester-solution-dialog h3{margin:4px 38px 0 0;color:#173d5e;font-size:17px;line-height:1.25}.case-detail-page .requester-solution-context{margin:4px 0 14px;color:#62788c;font-size:10px}.case-detail-page .requester-solution-field{margin-top:9px;padding:10px;border:1px solid #d5e2ec;border-radius:9px;background:#f8fbfe}.case-detail-page .requester-solution-field span{display:block;color:#52718a;font-size:9px;font-weight:850;letter-spacing:.06em;text-transform:uppercase}.case-detail-page .requester-solution-field strong,.case-detail-page .requester-solution-field p{display:block;margin:4px 0 0;color:#173d5e;font-size:12px;line-height:1.45;white-space:pre-line;overflow-wrap:anywhere}.case-detail-page .requester-solution-field p{color:#355873;font-size:11px}
    </style>
    <style id="solicitante-estructura-paleta">
        .case-detail-page .requester-structure-panel,
        .case-detail-page .requester-attachments-panel,
        .case-detail-page .requester-history-panel{
            border-color:var(--mesa-theme-border,var(--border));
            color:var(--mesa-theme-text,var(--text));
            background:linear-gradient(180deg,var(--mesa-theme-surface,var(--surface)),var(--mesa-theme-soft,var(--soft)));
            box-shadow:0 8px 20px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 8%,transparent);
        }
        .case-detail-page .requester-structure-head{border-bottom-color:var(--mesa-theme-border,var(--border))}
        .case-detail-page .requester-structure-head span,
        .case-detail-page .requester-history-panel .requester-structure-head p,
        .case-detail-page .requester-panel-empty{color:var(--mesa-theme-muted,var(--muted))}
        .case-detail-page .requester-structure-head h3{color:var(--mesa-theme-heading,var(--navy))}
        .case-detail-page .requester-structure-head>strong{color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 10%,var(--mesa-theme-surface,var(--surface)))}
        .case-detail-page .requester-structure-node,
        .case-detail-page .requester-history-item{border-color:var(--mesa-theme-border,var(--border));color:var(--mesa-theme-text,var(--text));background:var(--mesa-theme-surface,var(--surface));box-shadow:0 3px 10px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 6%,transparent)}
        .case-detail-page .requester-structure-node.is-derived{border-left-color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 5%,var(--mesa-theme-surface,var(--surface)))}
        .case-detail-page .requester-structure-number,
        .case-detail-page .requester-history-number{color:var(--mesa-theme-on-primary,#fff);background:var(--mesa-shell-color,var(--primary))}
        .case-detail-page .requester-structure-top{color:var(--mesa-theme-text,var(--text))}
        .case-detail-page .requester-structure-top span,
        .case-detail-page .requester-history-top span,
        .case-detail-page .requester-history-label{color:var(--mesa-theme-muted,var(--muted))}
        .case-detail-page .requester-structure-code{color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))!important;font-weight:900!important;letter-spacing:.04em}
        .case-detail-page .requester-structure-top b{color:var(--mesa-state-success,var(--ok));background:color-mix(in srgb,var(--mesa-state-success,var(--ok)) 12%,var(--mesa-theme-surface,var(--surface)))}
        .case-detail-page .requester-structure-copy>strong,
        .case-detail-page .requester-structure-meta span,
        .case-detail-page .requester-history-copy>strong,
        .case-detail-page .requester-history-actor b{color:var(--mesa-theme-heading,var(--navy))}
        .case-detail-page .requester-structure-meta{border-top-color:var(--mesa-theme-border,var(--border))}
        .case-detail-page .requester-structure-meta b,
        .case-detail-page .requester-history-top time,
        .case-detail-page .requester-history-actor{color:var(--mesa-theme-muted,var(--muted))}
        .case-detail-page .requester-structure-actions{border-top-color:var(--mesa-theme-border,var(--border))}
        .case-detail-page .requester-solution-button{border-color:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 38%,var(--mesa-theme-border,var(--border)));color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));background:var(--mesa-theme-soft,var(--soft))}
        .case-detail-page .requester-solution-button:hover{border-color:var(--mesa-shell-color,var(--primary));color:var(--mesa-theme-on-primary,#fff);background:var(--mesa-shell-color,var(--primary))}
        .case-detail-page .requester-attachments-list a{border-color:var(--mesa-theme-border,var(--border));color:var(--mesa-theme-heading,var(--navy));background:var(--mesa-theme-surface,var(--surface))}
        .case-detail-page .requester-attachments-list a:hover{border-color:var(--mesa-shell-color,var(--primary));background:var(--mesa-theme-soft,var(--soft))}
        .case-detail-page .requester-attachments-list small{color:var(--mesa-theme-muted,var(--muted))}
        .case-detail-page .requester-attachments-list>a>strong{color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))}
        .case-detail-page .requester-solution-modal{background:color-mix(in srgb,var(--mesa-shell-dark,#102a43) 64%,transparent)}
        .case-detail-page .requester-solution-dialog{border-color:var(--mesa-theme-border,var(--border));color:var(--mesa-theme-text,var(--text));background:var(--mesa-theme-surface,var(--surface));box-shadow:0 24px 60px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 32%,transparent)}
        .case-detail-page .requester-solution-close{border-color:var(--mesa-theme-border,var(--border));color:var(--mesa-theme-heading,var(--navy));background:var(--mesa-theme-surface,var(--surface))}
        .case-detail-page .requester-solution-close:hover{border-color:var(--mesa-shell-color,var(--primary));color:var(--mesa-theme-on-primary,#fff);background:var(--mesa-shell-color,var(--primary))}
        .case-detail-page .requester-solution-kicker,.case-detail-page .requester-solution-context,.case-detail-page .requester-solution-field span{color:var(--mesa-theme-muted,var(--muted))}
        .case-detail-page .requester-solution-dialog h3,.case-detail-page .requester-solution-field strong{color:var(--mesa-theme-heading,var(--navy))}
        .case-detail-page .requester-solution-field{border-color:var(--mesa-theme-border,var(--border));background:color-mix(in srgb,var(--mesa-theme-soft,var(--soft)) 56%,var(--mesa-theme-surface,var(--surface)))}
        .case-detail-page .requester-solution-field p{color:var(--mesa-theme-text,var(--text))}
    </style>
    <style id="solicitante-detalle-paleta-final">
        .case-detail-page{
            --case-blue:var(--mesa-shell-color,var(--primary))!important;
            --case-blue-bright:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))!important;
            --case-green:var(--mesa-state-success,var(--ok))!important;
            --case-ink:var(--mesa-theme-heading,var(--navy))!important;
            --case-muted:var(--mesa-theme-muted,var(--muted))!important;
            --case-line:var(--mesa-theme-border,var(--border))!important;
            --case-bg:var(--mesa-theme-bg,var(--bg))!important;
            color:var(--mesa-theme-text,var(--text))!important;
            background:var(--mesa-theme-bg,var(--bg))!important;
        }
        .case-detail-page .case-detail-modal,
        .case-detail-page .case-detail-dialog,
        .case-detail-page .case-detail-scroll,
        .case-detail-page .case-detail-card{color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .case-detail-modal-bar{border-color:var(--mesa-theme-border,var(--border))!important;color:var(--mesa-theme-heading,var(--navy))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .case-detail-card>.card-head{color:var(--mesa-theme-on-primary,#fff)!important;background:linear-gradient(120deg,var(--mesa-shell-color,var(--primary)),color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 72%,var(--mesa-theme-accent,var(--primary))))!important}
        .case-detail-page .case-detail-card>.card-head h2,
        .case-detail-page .case-detail-card>.card-head h2::after{color:var(--mesa-theme-on-primary,#fff)!important}
        .case-detail-page .request-summary,
        .case-detail-page .case-detail-card .detail-grid,
        .case-detail-page .request-flow-summary,
        .case-detail-page .requester-case-tabs,
        .case-detail-page .public-resolution,
        .case-detail-page .public-trace{border-color:var(--mesa-theme-border,var(--border))!important;color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-surface,var(--surface))!important;box-shadow:0 8px 20px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 8%,transparent)!important}
        .case-detail-page .request-summary-item,
        .case-detail-page .case-detail-card .detail-item{border-color:var(--mesa-theme-border,var(--border))!important;color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-soft,var(--soft))!important}
        .case-detail-page .request-summary-item>span,
        .case-detail-page .case-detail-card .detail-item span,
        .case-detail-page .request-flow-summary-head span,
        .case-detail-page .request-flow-step-copy small,
        .case-detail-page .public-resolution-head p,
        .case-detail-page .public-resolution-item span,
        .case-detail-page .public-trace-head p{color:var(--mesa-theme-muted,var(--muted))!important}
        .case-detail-page .request-summary-item strong,
        .case-detail-page .request-summary-item p,
        .case-detail-page .case-detail-card .detail-item strong,
        .case-detail-page .request-flow-summary-head h3,
        .case-detail-page .request-flow-step-copy strong,
        .case-detail-page .public-resolution-head h3,
        .case-detail-page .public-resolution-item strong,
        .case-detail-page .public-resolution-item p,
        .case-detail-page .public-trace-head h3{color:var(--mesa-theme-heading,var(--navy))!important}
        .case-detail-page .request-flow-summary-head{border-bottom-color:var(--mesa-theme-border,var(--border))}
        .case-detail-page .request-flow-summary-head>strong{color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));background:var(--mesa-theme-soft,var(--soft))}
        .case-detail-page .request-flow-step:not(:last-child)::after{background:var(--mesa-theme-border,var(--border))}
        .case-detail-page .request-flow-step.is-complete:not(:last-child)::after{background:var(--mesa-state-success,var(--ok))}
        .case-detail-page .request-flow-marker{border-color:var(--mesa-shell-color,var(--primary));color:var(--mesa-theme-on-primary,#fff);background:var(--mesa-shell-color,var(--primary));box-shadow:0 0 0 3px var(--mesa-theme-surface,var(--surface))}
        .case-detail-page .request-flow-step.is-complete .request-flow-marker{border-color:var(--mesa-state-success,var(--ok));background:var(--mesa-state-success,var(--ok))}
        .case-detail-page .request-flow-step-copy em{color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))}
        .case-detail-page .request-flow-step.is-complete .request-flow-step-copy em{color:var(--mesa-state-success,var(--ok))}
        .case-detail-page .requester-case-tabs{border-top-color:var(--mesa-theme-border,var(--border))!important;border-bottom-color:var(--mesa-theme-border,var(--border))!important}
        .case-detail-page .requester-case-tab{border-color:transparent;color:var(--mesa-theme-muted,var(--muted));background:transparent}
        .case-detail-page .requester-case-tab:hover{border-color:var(--mesa-theme-border,var(--border));color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)));background:var(--mesa-theme-soft,var(--soft))}
        .case-detail-page .requester-case-tab.is-active{border-color:var(--mesa-shell-color,var(--primary));color:var(--mesa-theme-on-primary,#fff);background:var(--mesa-shell-color,var(--primary));box-shadow:0 4px 10px color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 22%,transparent)}
        .case-detail-page .public-resolution.is-pending{border-color:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 42%,var(--mesa-theme-border))!important;border-left-color:var(--mesa-shell-color,var(--primary))!important;background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 8%,var(--mesa-theme-surface,var(--surface)))!important}
        .case-detail-page .public-resolution.is-pending .public-resolution-head h3{color:var(--mesa-theme-heading,var(--navy))!important}
        .case-detail-page .public-resolution-area{border-color:var(--mesa-theme-border,var(--border));color:var(--mesa-state-success,var(--ok))!important;background:var(--mesa-theme-soft,var(--soft))!important}
        .case-detail-page .public-trace-node{border-color:var(--mesa-theme-border,var(--border))!important;color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-soft,var(--soft))!important;box-shadow:none!important}
        .case-detail-page .public-trace-node.derived{border-left-color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))!important;background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 7%,var(--mesa-theme-surface,var(--surface)))!important}
        .case-detail-page .public-trace-label strong{color:var(--mesa-theme-heading,var(--navy))!important}
        .case-detail-page .public-trace-service{color:var(--mesa-theme-muted,var(--muted))!important}
        .case-detail-page .public-trace-kind{color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))!important;background:var(--mesa-theme-soft,var(--soft))!important;border-color:var(--mesa-theme-border,var(--border))!important}
        .case-detail-page .requester-header-metadata{border-bottom-color:var(--mesa-theme-border,var(--border))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .requester-header-metadata>div{border-color:var(--mesa-theme-border,var(--border))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .requester-header-metadata span{color:var(--mesa-theme-muted,var(--muted))!important}
        .case-detail-page .requester-header-metadata strong{color:var(--mesa-theme-heading,var(--navy))!important}
        .case-detail-page .requester-header-metadata small{color:var(--mesa-theme-muted,var(--muted))!important}
        .case-detail-page .requester-header-metadata .due strong{color:var(--mesa-state-danger,var(--danger))!important}
        .case-detail-page .requester-secondary-overview{color:var(--mesa-theme-text,var(--text))!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .request-summary-meta{border-top-color:var(--mesa-theme-border,var(--border))!important;background:var(--mesa-theme-soft,var(--soft))!important}
        .case-detail-page .request-summary-meta>div{color:var(--mesa-theme-text,var(--text))!important;background:transparent!important}
        .case-detail-page .request-summary-meta>div+div{border-left-color:var(--mesa-theme-border,var(--border))!important}
        .case-detail-page .request-summary-meta span{color:var(--mesa-theme-muted,var(--muted))!important}
        .case-detail-page .request-summary-meta strong{color:var(--mesa-theme-heading,var(--navy))!important}
        .case-detail-page .request-summary-meta small{color:var(--mesa-theme-muted,var(--muted))!important}
        .case-detail-page .case-detail-nav>strong{color:var(--mesa-theme-muted,var(--muted))!important}
        .case-detail-page .case-detail-back{border-color:var(--mesa-theme-border,var(--border))!important;color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))!important;background:var(--mesa-theme-soft,var(--soft))!important}
        .case-detail-page .case-detail-back:hover{border-color:var(--mesa-shell-color,var(--primary))!important;color:var(--mesa-theme-on-primary,#fff)!important;background:var(--mesa-shell-color,var(--primary))!important}
        .case-detail-page .case-detail-subtitle,
        .case-detail-page .case-detail-card>.card-head .case-detail-subtitle{color:color-mix(in srgb,var(--mesa-theme-on-primary,#fff) 78%,transparent)!important}
        /* Homologación con la ficha del gestor: cabecera plana y metadatos sin cuadrícula. */
        .case-detail-page .case-detail-card>.card-head{min-height:0!important;margin:0!important;padding:20px 28px!important;border:0!important;border-bottom:1px solid var(--mesa-theme-border,var(--border))!important;border-radius:0!important;color:var(--mesa-theme-heading,var(--navy))!important;background:var(--mesa-theme-surface,var(--surface))!important;box-shadow:none!important}
        .case-detail-page .case-detail-card>.card-head::after{display:none!important;content:none!important}
        .case-detail-page .case-detail-card>.card-head h2,
        .case-detail-page .case-detail-card>.card-head h2::after{color:var(--mesa-theme-heading,var(--navy))!important}
        .case-detail-page .case-detail-card>.card-head h2::after{opacity:.78}
        .case-detail-page .requester-case-code{border-color:var(--mesa-theme-border,var(--border))!important;color:var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))!important;background:var(--mesa-theme-soft,var(--soft))!important}
        .case-detail-page .requester-header-metadata{grid-template-columns:repeat(5,minmax(0,1fr));gap:24px;padding:0 28px;border:0!important;background:var(--mesa-theme-surface,var(--surface))!important}
        .case-detail-page .requester-header-metadata>div{padding:14px 0;border:0!important;background:transparent!important}
        .case-detail-page .requester-secondary-overview .request-summary-meta{border:0!important;background:var(--mesa-theme-soft,var(--soft))!important}
        .case-detail-page .requester-secondary-overview .request-summary-meta>div{padding:11px 14px;border:0!important;background:transparent!important}
        .case-detail-page .requester-secondary-overview .detail-grid{gap:8px!important;border:0!important;background:transparent!important;box-shadow:none!important}
        .case-detail-page .requester-secondary-overview .detail-item{border:0!important;border-radius:9px!important;background:var(--mesa-theme-soft,var(--soft))!important}
        .case-detail-page .case-detail-card>.card-head .case-detail-subtitle{color:var(--mesa-theme-heading,#fff)!important;opacity:.82!important}
        .case-detail-page .requester-history-panel .requester-structure-head p,
        .case-detail-page .requester-history-top span,
        .case-detail-page .requester-history-label,
        .case-detail-page .requester-history-top time,
        .case-detail-page .requester-history-actor{color:var(--mesa-theme-muted,var(--muted))!important}
        .case-detail-page .requester-history-copy>strong,
        .case-detail-page .requester-history-copy p,
        .case-detail-page .requester-history-actor b{color:var(--mesa-theme-heading,var(--navy))!important}
        .case-detail-page .requester-history-copy p{color:var(--mesa-theme-text,var(--text))!important}
        .case-detail-page .requester-history-actor{border-top-color:var(--mesa-theme-border,var(--border))!important}
        /* Tipografía fluida para el seguimiento: se adapta al ancho/resolución sin quedar diminuta. */
        .case-detail-page .request-flow-summary-head span{font-size:clamp(9px,.68vw,12px)!important}
        .case-detail-page .request-flow-summary-head h3{font-size:clamp(15px,1.05vw,19px)!important}
        .case-detail-page .request-flow-marker{font-size:clamp(11px,.78vw,14px)!important}
        .case-detail-page .request-flow-step-copy strong{font-size:clamp(10px,.78vw,14px)!important}
        .case-detail-page .request-flow-step-copy small{font-size:clamp(9px,.62vw,12px)!important}
        .case-detail-page .request-flow-step-copy .request-flow-assignee,
        .case-detail-page .request-flow-step-copy em{font-size:clamp(8px,.56vw,11px)!important}
        .case-detail-page .requester-header-metadata span,
        .case-detail-page .request-summary-meta span{font-size:clamp(9px,.64vw,11px)!important}
        .case-detail-page .requester-header-metadata strong,
        .case-detail-page .request-summary-meta strong{font-size:clamp(11px,.78vw,14px)!important;line-height:1.3!important}
        .case-detail-page .requester-header-metadata small,
        .case-detail-page .request-summary-meta small{font-size:clamp(8px,.56vw,11px)!important;line-height:1.3!important}
        /* Alineación uniforme de los recuadros de Información. */
        .case-detail-page .requester-secondary-overview .request-summary{
            grid-template-columns:minmax(0,.85fr) minmax(0,1.15fr)!important;
            gap:0!important;
            margin:14px 18px 12px!important;
            padding:0!important;
            overflow:hidden!important;
            border:1px solid var(--mesa-theme-border,var(--border))!important;
            border-radius:10px!important;
            background:var(--mesa-theme-surface,var(--surface))!important;
            box-shadow:none!important;
        }
        .case-detail-page .requester-secondary-overview .request-summary-item{
            min-width:0!important;
            min-height:76px!important;
            margin:0!important;
            padding:14px 16px!important;
            border:0!important;
            border-radius:0!important;
            background:var(--mesa-theme-surface,var(--surface))!important;
        }
        .case-detail-page .requester-secondary-overview .request-summary-item+.request-summary-item{border-left:1px solid var(--mesa-theme-border,var(--border))!important;padding-left:16px!important}
        .case-detail-page .requester-secondary-overview .request-summary-meta{grid-column:1/-1!important;margin:0!important;padding:0!important;border-top:1px solid var(--mesa-theme-border,var(--border))!important;border-radius:0!important}
        .case-detail-page .requester-secondary-overview .request-summary-meta>div{min-width:0!important;margin:0!important;padding:12px 16px!important;border-left:0!important}
        .case-detail-page .requester-secondary-overview .request-summary-meta>div+div{border-left:1px solid var(--mesa-theme-border,var(--border))!important}
        .case-detail-page .requester-secondary-overview .detail-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:10px!important;margin:0 18px 14px!important;padding:0!important}
        .case-detail-page .requester-secondary-overview .detail-grid .detail-item{grid-column:auto!important;min-width:0!important;margin:0!important}
        @media(max-width:760px){
            .case-detail-page .requester-secondary-overview .request-summary{grid-template-columns:1fr!important}
            .case-detail-page .requester-secondary-overview .request-summary-item+.request-summary-item{border-left:0!important;border-top:1px solid var(--mesa-theme-border,var(--border))!important}
            .case-detail-page .requester-secondary-overview .request-summary-meta{grid-template-columns:repeat(2,minmax(0,1fr))!important}
            .case-detail-page .requester-secondary-overview .request-summary-meta>div+div{border-left:0!important}
            .case-detail-page .requester-secondary-overview .request-summary-meta>div:nth-child(even){border-left:1px solid var(--mesa-theme-border,var(--border))!important}
            .case-detail-page .requester-secondary-overview .request-summary-meta>div:nth-child(n+3){border-top:1px solid var(--mesa-theme-border,var(--border))!important}
            .case-detail-page .requester-secondary-overview .detail-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
        }
        @media(max-width:480px){
            .case-detail-page .requester-secondary-overview .request-summary-meta{grid-template-columns:1fr!important}
            .case-detail-page .requester-secondary-overview .request-summary-meta>div:nth-child(even){border-left:0!important}
            .case-detail-page .requester-secondary-overview .request-summary-meta>div+div{border-top:1px solid var(--mesa-theme-border,var(--border))!important}
            .case-detail-page .requester-secondary-overview .detail-grid{grid-template-columns:1fr!important}
        }
        /* Tipografía fluida del historial y ajuste de la línea del responsable. */
        .case-detail-page .requester-history-panel .requester-structure-head h3{font-size:clamp(15px,1.05vw,19px)!important}
        .case-detail-page .requester-history-panel .requester-structure-head p{font-size:clamp(9px,.62vw,12px)!important;line-height:1.4!important}
        .case-detail-page .requester-history-top span,
        .case-detail-page .requester-history-label{font-size:clamp(9px,.62vw,11px)!important}
        .case-detail-page .requester-history-top time{font-size:clamp(9px,.6vw,11px)!important}
        .case-detail-page .requester-history-copy>strong{font-size:clamp(12px,.88vw,16px)!important;line-height:1.3!important}
        .case-detail-page .requester-history-copy p{font-size:clamp(10px,.72vw,13px)!important;line-height:1.45!important}
        .case-detail-page .requester-history-actor{font-size:clamp(9px,.64vw,11px)!important;line-height:1.4!important;white-space:normal!important;overflow-wrap:anywhere!important}
        /* Estructura compacta: sin separadores largos y con la acción integrada arriba. */
        .case-detail-page .requester-structure-node{
            padding:12px 13px!important;
            border:0!important;
            border-left:0!important;
            border-radius:9px!important;
            background:color-mix(in srgb,var(--mesa-theme-surface,var(--surface)) 94%,var(--mesa-shell-color,var(--primary)))!important;
            box-shadow:none!important;
        }
        .case-detail-page .requester-structure-node.is-derived{border-left:0!important}
        .case-detail-page .requester-structure-copy>strong{padding-right:112px!important}
        .case-detail-page .requester-structure-meta{margin-top:7px!important;padding-top:3px!important;border-top:0!important}
        .case-detail-page .requester-structure-actions{position:absolute;top:39px;right:13px;margin:0!important;padding:0!important;border-top:0!important}
        .case-detail-page .requester-solution-button{min-height:28px!important;padding:5px 9px!important;font-size:clamp(9px,.62vw,11px)!important}
        .case-detail-page .requester-structure-number{font-size:clamp(10px,.74vw,14px)!important}
        .case-detail-page .requester-structure-top span{font-size:clamp(9px,.64vw,11px)!important}
        .case-detail-page .requester-structure-top b{font-size:clamp(9px,.62vw,11px)!important}
        .case-detail-page .requester-structure-copy>strong{font-size:clamp(12px,.9vw,16px)!important;line-height:1.35!important}
        .case-detail-page .requester-structure-meta span{font-size:clamp(10px,.7vw,13px)!important;line-height:1.3!important}
        .case-detail-page .requester-structure-meta b{font-size:clamp(8px,.56vw,10px)!important}
        @media(max-width:760px){
            .case-detail-page .requester-structure-copy>strong{padding-right:0!important}
            .case-detail-page .requester-structure-actions{position:static;margin-top:7px!important;padding-top:0!important}
        }
        /* Modal de solución homologado con el gestor: panel flotante, backdrop y cabecera arrastrable. */
        .case-detail-page .requester-solution-modal{
            position:fixed;
            inset:104px 28px auto auto;
            z-index:2147483500;
            width:min(440px,calc(100% - 28px));
            max-width:none;
            max-height:min(80vh,620px);
            margin:0;
            padding:0;
            border:1px solid var(--mesa-theme-border,var(--border));
            border-radius:15px;
            color:var(--mesa-theme-text,var(--text));
            background:var(--mesa-theme-surface,var(--surface));
            box-shadow:0 18px 46px color-mix(in srgb,var(--mesa-shell-dark,#102a43) 26%,transparent);
        }
        .case-detail-page .requester-solution-modal:not([open]){display:none!important}
        .case-detail-page .requester-solution-modal::backdrop{background:transparent!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
        .case-detail-page .requester-solution-dialog{position:static;width:auto;max-width:none;margin:0;padding:0;border:0;border-radius:inherit;background:transparent;box-shadow:none}
        .case-detail-page .requester-solution-shell{overflow:hidden;border-radius:inherit}
        .case-detail-page .requester-solution-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding:16px 18px 13px;border-bottom:1px solid var(--mesa-theme-border,var(--border));background:linear-gradient(135deg,var(--mesa-theme-soft,var(--soft)),var(--mesa-theme-surface,var(--surface)));cursor:grab;touch-action:none;user-select:none}
        .case-detail-page .requester-solution-head.is-dragging{cursor:grabbing}
        .case-detail-page .requester-solution-kicker{display:block;margin-bottom:4px;color:var(--mesa-theme-muted,var(--muted))!important;font-size:clamp(9px,.6vw,10px)!important;font-weight:900;letter-spacing:.08em;text-transform:uppercase}
        .case-detail-page .requester-solution-dialog h3{margin:0;color:var(--mesa-theme-heading,var(--navy))!important;font-size:clamp(16px,1.2vw,19px)!important;line-height:1.25}
        .case-detail-page .requester-solution-context{margin:4px 0 0;color:var(--mesa-theme-muted,var(--muted))!important;font-size:clamp(10px,.72vw,12px)!important;line-height:1.35}
        .case-detail-page .requester-solution-close{position:static;display:grid;width:32px;height:32px;flex:0 0 auto;place-items:center;border:1px solid var(--mesa-theme-border,var(--border));border-radius:8px;color:var(--mesa-theme-heading,var(--navy));background:var(--mesa-theme-surface,var(--surface));font-size:22px;line-height:1;cursor:pointer}
        .case-detail-page .requester-solution-close:hover{color:var(--mesa-theme-on-primary,#fff);background:var(--mesa-shell-color,var(--primary))}
        .case-detail-page .requester-solution-body{display:grid;gap:12px;padding:18px}
        .case-detail-page .requester-solution-body .requester-solution-field{margin:0;padding:10px;border:1px solid var(--mesa-theme-border,var(--border));border-radius:9px;background:var(--mesa-theme-soft,var(--soft))}
        .case-detail-page .requester-solution-body .requester-solution-field span{display:block;margin-bottom:4px;color:var(--mesa-theme-muted,var(--muted))!important;font-size:clamp(9px,.6vw,10px)!important;font-weight:900;letter-spacing:.08em;text-transform:uppercase}
        .case-detail-page .requester-solution-body .requester-solution-field strong,
        .case-detail-page .requester-solution-body .requester-solution-field p{display:block;margin:4px 0 0;color:var(--mesa-theme-heading,var(--navy))!important;font-size:clamp(11px,.75vw,13px)!important;line-height:1.45;white-space:pre-line;overflow-wrap:anywhere}
        .case-detail-page .requester-solution-body .requester-solution-field p{color:var(--mesa-theme-text,var(--text))!important}
        /* Apariencia de Estructura igual a la ficha del gestor. */
        .case-detail-page .requester-structure-node{
            padding:12px 13px!important;
            border:1px solid var(--mesa-theme-border,var(--border))!important;
            border-radius:10px!important;
            background:var(--mesa-theme-surface,var(--surface))!important;
            box-shadow:none!important;
        }
        .case-detail-page .requester-structure-node.is-derived{border-left:3px solid var(--mesa-theme-link,var(--mesa-shell-color,var(--primary)))!important;background:color-mix(in srgb,var(--mesa-shell-color,var(--primary)) 5%,var(--mesa-theme-surface,var(--surface)))!important}
        .case-detail-page .requester-structure-copy>strong{padding-right:0!important}
        .case-detail-page .requester-structure-meta{margin-top:9px!important;padding-top:8px!important;border-top:1px solid var(--mesa-theme-border,var(--border))!important}
        .case-detail-page .requester-structure-actions{position:static!important;display:flex;justify-content:flex-end;margin-top:9px!important;padding-top:8px!important;border-top:1px solid var(--mesa-theme-border,var(--border))!important}
        .case-detail-page .requester-solution-button{min-height:30px!important;padding:6px 10px!important}
        @media(max-width:600px){.case-detail-page .requester-solution-modal{inset:74px 14px auto;width:calc(100% - 28px)}}
        @media(max-width:900px){.case-detail-page .requester-header-metadata{grid-template-columns:repeat(2,minmax(0,1fr));gap:0}.case-detail-page .requester-header-metadata>div{padding:12px 14px}.case-detail-page .requester-header-metadata>div:nth-child(odd){padding-left:0}.case-detail-page .requester-header-metadata>div:nth-child(even){padding-right:0}}
    </style>
</head>
<body>
<main class="shell<?= $ticketSeleccionado ? ' case-detail-page' : '' ?>">
    <?php if (!$ticketSeleccionado): ?>
    <header class="topbar">
        <div class="brand">
            <span class="mark">MS</span>
            <div>
                <strong class="smartdesk-wordmark"><span class="smart">SMART</span><span class="desk">DESK</span> · <?= escaparPortalSolicitante(paisContextoNombre()) ?></strong>
                <small>Solicitante · <?= escaparPortalSolicitante($nombreUsuario) ?></small>
            </div>
        </div>
    </header>

    <nav class="tabs" aria-label="Opciones del solicitante">
        <?php if ($cantidadPendientesCalificacion > 0): ?>
            <span class="tab disabled" aria-disabled="true" title="Califique o devuelva los casos pendientes para crear uno nuevo">＋ Crear caso</span>
        <?php else: ?>
            <a class="tab <?= $vista === 'nueva' ? 'active' : '' ?>" href="panelSolicitante.php?vista=nueva">＋ Crear caso</a>
        <?php endif; ?>
        <a class="tab <?= $vista === 'tickets' ? 'active' : '' ?>" href="panelSolicitante.php?vista=tickets">Mis solicitudes · <?= $resumen['total'] ?></a>
    </nav>
    <?php endif; ?>

    <?php if ($cantidadPendientesCalificacion > 0 && !$ticketSeleccionado): ?>
        <section class="pending-rating-gate" role="alert" aria-live="assertive">
            <span class="pending-rating-icon" aria-hidden="true">!</span>
            <div class="pending-rating-copy">
                <strong>
                    Tiene <?= (int) $cantidadPendientesCalificacion ?>
                    <?= $cantidadPendientesCalificacion === 1 ? 'caso pendiente' : 'casos pendientes' ?> por calificar
                </strong>
                <p>Debe aprobar la solución o devolver el caso al gestor antes de crear una nueva solicitud.</p>
            </div>
            <div class="pending-rating-actions">
                <a class="pending-rating-action primary" href="panelSolicitante.php?vista=tickets&amp;id_ticket=<?= (int) $primerTicketPendienteCalificacion ?>">Revisar ahora</a>
                <a class="pending-rating-action" href="panelSolicitante.php?vista=tickets&amp;estado_busqueda=pendiente">Ver pendientes</a>
            </div>
        </section>
    <?php endif; ?>

    <?php if (isset($mensajes[$mensajeActual])): ?>
        <div class="alert <?= escaparPortalSolicitante($mensajes[$mensajeActual][0]) ?>">
            <?= escaparPortalSolicitante($mensajes[$mensajeActual][1]) ?>
            <?php if (in_array($mensajeActual, ['error_operacion', 'error_calificacion', 'error_reapertura', 'error_mensaje'], true) && $detalleError !== ''): ?>
                <?= escaparPortalSolicitante($detalleError) ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if ($vista === 'nueva'): ?>
        <section class="card">
            <div class="card-head">
                <div>
                    <h1>Crear una solicitud</h1>
            <p class="muted">Elija primero el proceso y después el servicio que necesita.</p>
                </div>
            </div>

            <?php if ($cantidadPendientesCalificacion > 0): ?>
                <div class="creation-blocked" role="alert">
                    <strong>No puede crear una solicitud nueva todavía</strong>
                    <p>Primero debe calificar o devolver <?= $cantidadPendientesCalificacion === 1 ? 'el caso pendiente' : 'los casos pendientes' ?>. La creación se habilitará automáticamente cuando no quede ninguno.</p>
                    <a class="pending-rating-action primary" href="panelSolicitante.php?vista=tickets&amp;id_ticket=<?= (int) $primerTicketPendienteCalificacion ?>">Revisar caso pendiente</a>
                </div>
            <?php elseif (!$catalogosSolicitud): ?>
                <div class="empty">No hay procesos disponibles en este momento.</div>
            <?php else: ?>
                <form id="form-nueva-solicitud" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="accion" value="crear_ticket">
                    <input type="hidden" name="solicitud_creacion_token" value="<?= escaparPortalSolicitante($tokenCreacionSolicitud) ?>">
                    <div class="form-grid">
                        <div class="field full">
                            <label id="etiqueta-catalogo">Proceso *</label>
                            <small class="help">Estructura de atención: Proceso → Subproceso → Servicio.</small>
                            <div class="catalog-picker" role="radiogroup" aria-labelledby="etiqueta-catalogo">
                                <?php foreach ($catalogosSolicitud as $catalogoSolicitud): ?>
                                    <?php
                                        $idCatalogoSolicitud = (int) $catalogoSolicitud['id_catalogo'];
                                        $descripcionCatalogoSolicitud = trim((string) ($catalogoSolicitud['descripcion'] ?? ''));
                                    ?>
                                    <label class="catalog-choice area-selector-item">
                                        <input
                                            type="radio"
                                            name="id_catalogo"
                                            value="<?= $idCatalogoSolicitud ?>"
                                            required
                                            data-catalogo-solicitud
                                        >
                                        <span class="catalog-choice-body">
                                            <span class="catalog-choice-title area-name">
                                                <strong><?= escaparPortalSolicitante($catalogoSolicitud['nombre']) ?></strong>
                                            </span>
                                            <span class="catalog-choice-media">
                                                <img class="area-icon"
                                                    src="<?= escaparPortalSolicitante(seguridadUrlImagenCatalogo($idCatalogoSolicitud, $catalogoSolicitud['imagen'] ?? null)) ?>"
                                                    alt="Imagen del proceso <?= escaparPortalSolicitante($catalogoSolicitud['nombre']) ?>"
                                                    loading="lazy"
                                                    decoding="async"
                                                    fetchpriority="low"
                                                >
                                            </span>
                                            <small class="area-description" title="<?= escaparPortalSolicitante($descripcionCatalogoSolicitud) ?>"><?= escaparPortalSolicitante($descripcionCatalogoSolicitud !== '' ? $descripcionCatalogoSolicitud : 'Sin descripción registrada.') ?></small>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="service-selection-layout">
                            <div class="field">
                                <label for="buscador-servicio">Servicio *</label>
                                <div id="selector-servicio-buscable" class="service-combobox">
                                    <div class="service-combobox-control">
                                        <input
                                            id="buscador-servicio"
                                            class="service-combobox-input"
                                            type="text"
                                            placeholder="Seleccione primero un proceso"
                                            autocomplete="off"
                                            role="combobox"
                                            aria-autocomplete="list"
                                            aria-controls="opciones-servicio"
                                            aria-expanded="false"
                                            required
                                            disabled
                                        >
                                        <button
                                            id="alternar-opciones-servicio"
                                            class="service-combobox-toggle"
                                            type="button"
                                            aria-label="Mostrar servicios"
                                            tabindex="-1"
                                            disabled
                                        ></button>
                                    </div>
                                    <div
                                        id="opciones-servicio"
                                        class="service-combobox-list"
                                        role="listbox"
                                        aria-label="Servicios disponibles"
                                    ></div>
                                    <select id="id_proceso" name="id_proceso" class="service-native-select" disabled aria-hidden="true">
                                        <option value="">Seleccione primero un proceso</option>
                                    </select>
                                    <input id="id_servicio" name="id_servicio" type="hidden" value="">
                                    <input id="usa_proceso" name="usa_proceso" type="hidden" value="">
                                </div>
                                <span id="estado-servicios-catalogo" class="service-feedback" aria-live="polite">Los servicios se cargarán según el proceso seleccionado.</span>
                            </div>
                            <aside id="resumen-servicio" class="service-summary empty" aria-live="polite">
                                <div class="service-summary-copy">
                                    <strong id="resumen-servicio-nombre">Seleccione un servicio para que aparezca la información de él en este apartado.</strong>
                                    <p id="resumen-servicio-descripcion" hidden></p>
                                    <div class="service-tags" id="resumen-servicio-etiquetas" hidden>
                                        <span class="service-tag type" id="resumen-servicio-tipo"></span>
                                        <span class="service-tag priority" id="resumen-servicio-prioridad"></span>
                                        <span class="service-tag urgency" id="resumen-servicio-urgencia"></span>
                                        <span class="service-tag impact" id="resumen-servicio-impacto"></span>
                                    </div>
                                </div>
                            </aside>
                        </div>
                        <div class="request-support-grid">
                            <div class="request-text-column">
                                <div class="field">
                                    <label for="titulo">Asunto *</label>
                                    <input id="titulo" name="titulo" maxlength="180" required placeholder="Ejemplo: No puedo ingresar al correo corporativo">
                                </div>
                                <div class="field description-field">
                                    <label for="descripcion">Descripción *</label>
                                    <textarea id="descripcion" name="descripcion" maxlength="15000" rows="2" required placeholder="Explique qué sucede y desde cuándo."></textarea>
                                </div>
                                <div class="field campos-extra-solicitud" id="campos-extra-solicitud" hidden>
                                    <div class="campos-extra-solicitud-head">
                                        <strong>Información adicional del servicio</strong>
                                        <span>Complete todos los campos obligatorios para continuar.</span>
                                    </div>
                                    <div class="campos-extra-solicitud-grid" data-campos-extra-fields></div>
                                </div>
                            </div>
                            <div class="field file-field">
                                <label for="adjuntos">Archivos opcionales</label>
                                <input class="file-input" id="adjuntos" type="file" name="adjuntos[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.txt,.csv,.zip,.doc,.docx,.xls,.xlsx">
                                <label class="file-dropzone" id="zona-adjuntos" for="adjuntos">
                                    <span class="upload-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24"><path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M5 14v4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-4"/></svg>
                                    </span>
                                    <span class="upload-copy">
                                        <strong>Adjuntar archivos</strong>
                                        <span>Arrástrelos aquí o búsquelos en su equipo.</span>
                                    </span>
                                    <span class="upload-action">Seleccionar</span>
                                </label>
                                <div class="file-list" id="lista-adjuntos" hidden></div>
                                <span class="file-status" id="estado-adjuntos">Máximo cinco archivos de 5 MB cada uno.</span>
                            </div>
                        </div>
                    </div>
                    <div class="actions">
                        <button class="btn primary" type="submit" data-create-request-button>
                            Crear solicitud
                        </button>
                        <span class="muted" data-create-request-status role="status" aria-live="polite"></span>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    <?php else: ?>
        <?php if (!$ticketSeleccionado): ?>
        <section class="card">
            <div class="card-head"><div><h1>Estado de mis solicitudes</h1><p class="muted">Aquí solo aparecen los casos creados por su usuario en <?= escaparPortalSolicitante(paisContextoNombre()) ?>.</p></div></div>
            <?php if (!$tickets): ?>
                <div class="empty">Todavía no ha creado solicitudes.</div>
            <?php else: ?>
                <nav class="case-state-tabs" aria-label="Filtrar solicitudes por estado">
                    <?php
                        $filtrosEstadoSolicitante = [
                            'activo' => ['Activos', $resumen['activos']],
                            'pendiente' => ['Pendientes', $resumen['listos']],
                            'cerrado' => ['Cerrados', $resumen['cerrados']],
                            'todos' => ['Todos', $resumen['total']],
                        ];
                    ?>
                    <?php foreach ($filtrosEstadoSolicitante as $valorFiltro => [$etiquetaFiltro, $cantidadFiltro]): ?>
                        <button
                            class="case-state-tab <?= $estadoBusquedaCasos === $valorFiltro ? 'is-active' : '' ?>"
                            type="button"
                            data-case-filter-state="<?= escaparPortalSolicitante($valorFiltro) ?>"
                            aria-pressed="<?= $estadoBusquedaCasos === $valorFiltro ? 'true' : 'false' ?>"
                        >
                            <span><?= escaparPortalSolicitante($etiquetaFiltro) ?></span>
                            <span class="case-state-tab-count"><?= (int) $cantidadFiltro ?></span>
                        </button>
                    <?php endforeach; ?>
                </nav>
                <div class="case-filters" aria-label="Filtros de casos">
                    <div class="case-filter-field">
                        <label for="buscar-casos">Buscar casos</label>
                        <div class="case-search-control">
                            <input
                                id="buscar-casos"
                                type="search"
                                value="<?= escaparPortalSolicitante($busquedaCasos) ?>"
                                maxlength="120"
                                autocomplete="off"
                                placeholder="Número exacto, asunto, servicio, estado o fecha"
                            >
                            <button class="case-filter-clear" id="limpiar-filtro-casos" type="button" aria-label="Limpiar búsqueda" hidden>×</button>
                        </div>
                    </div>
                    <input id="estado-casos" type="hidden" value="<?= escaparPortalSolicitante($estadoBusquedaCasos) ?>">
                    <span class="case-filter-count" id="contador-casos" aria-live="polite"><?= count($tickets) ?> caso(s)</span>
                </div>
                <div class="table-wrap">
                    <table>
                        <thead><tr><th>Caso</th><th>Asunto</th><th>Servicio</th><th>Estado</th><th>Creado</th><th>Finalización prevista</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ($tickets as $ticket): ?>
                            <?php
                                $estadoTicket = isset($ticketsConSolucionLista[(int) $ticket['id_ticket']])
                                    ? 'pendiente_calificacion'
                                    : (string) ($ticket['estado_flujo'] ?? $ticket['estado'] ?? 'en_proceso');
                                $estadoFiltroTicket = (fn ($__mesaMatchValue35) => (($__mesaMatchValue35 === ('cerrada')) ? ('cerrado') : ((($__mesaMatchValue35 === ('cancelada')) ? ('cancelado') : ($estadoTicket)))))($estadoTicket);
                                $categoriaFiltroTicket = (fn ($__mesaMatchValue36) => (($__mesaMatchValue36 === ($estadoFiltroTicket === 'pendiente_calificacion')) ? ('pendiente') : ((($__mesaMatchValue36 === (in_array($estadoFiltroTicket, ['cerrado', 'cancelado'], true))) ? ('cerrado') : ('activo')))))(true);
                                $parametrosDetalle = [
                                    'vista' => 'tickets',
                                    'id_ticket' => (int) $ticket['id_ticket'],
                                ];

                                if ($busquedaCasos !== '') {
                                    $parametrosDetalle['buscar'] = $busquedaCasos;
                                }

                                if ($estadoBusquedaCasos !== 'todos') {
                                    $parametrosDetalle['estado_busqueda'] = $estadoBusquedaCasos;
                                }
                            ?>
                            <tr
                                data-case-row
                                data-ticket-id="<?= (int) $ticket['id_ticket'] ?>"
                                data-case-state="<?= escaparPortalSolicitante($estadoFiltroTicket) ?>"
                                data-case-category="<?= escaparPortalSolicitante($categoriaFiltroTicket) ?>"
                            >
                                <td><span class="case-number">Caso <?= (int) $ticket['id_ticket'] ?></span></td>
                                <td><?= escaparPortalSolicitante($ticket['titulo']) ?></td>
                                <td><?= escaparPortalSolicitante($ticket['proceso_nombre'] ?? 'Solicitud') ?></td>
                                <td><span class="status <?= escaparPortalSolicitante($estadoTicket) ?>"><?= escaparPortalSolicitante(textoEstadoPortalSolicitante($estadoTicket)) ?></span></td>
                                <td><?= escaparPortalSolicitante(fechaPortalSolicitante($ticket['fecha_creacion'] ?? null)) ?></td>
                                <td>
                                    <?php $proyeccionFila = $proyeccionesTickets[(int) $ticket['id_ticket']] ?? []; ?>
                                    <strong><?= escaparPortalSolicitante(fechaPortalSolicitante($proyeccionFila['fecha'] ?? null)) ?></strong>
                                    <?php if (!empty($proyeccionFila['pausado_por_derivacion'])): ?><small>SLA pausado por derivación</small><?php endif; ?>
                                </td>
                                <td><a class="view-link" data-case-view href="panelSolicitante.php?<?= escaparPortalSolicitante(http_build_query($parametrosDetalle)) ?>">Ver estado</a></td>
                            </tr>
                        <?php endforeach; ?>
                            <tr class="case-filter-empty" id="sin-resultados-casos" hidden>
                                <td colspan="7">No se encontraron casos con los filtros seleccionados.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
        <?php endif; ?>

        <?php if ($ticketSeleccionado): ?>
            <div class="case-detail-page" data-requester-case-detail>
            <section class="case-detail-modal" id="modal-estado-caso" role="region" aria-labelledby="titulo-modal-estado-caso">
                <div class="case-detail-dialog">
                    <div class="case-detail-modal-bar">
                        <div class="case-detail-nav">
                            <?php
                                $parametrosVolverCasos = ['vista' => 'tickets'];
                                if ($busquedaCasos !== '') {
                                    $parametrosVolverCasos['buscar'] = $busquedaCasos;
                                }
                                if ($estadoBusquedaCasos !== 'todos') {
                                    $parametrosVolverCasos['estado_busqueda'] = $estadoBusquedaCasos;
                                }
                            ?>
                            <a class="case-detail-back" href="panelSolicitante.php?<?= escaparPortalSolicitante(http_build_query($parametrosVolverCasos)) ?>">← Atrás</a>
                            <strong>Detalle y seguimiento del caso</strong>
                        </div>
                        <div class="case-detail-modal-actions">
                            <form class="case-email-toggle" method="post">
                                <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                                <input type="hidden" name="accion" value="configurar_notificaciones">
                                <input type="hidden" name="id_ticket" value="<?= (int) $ticketSeleccionado['id_ticket'] ?>">
                                <input type="hidden" name="habilitada" value="<?= $notificacionesEmailSolicitante ? '0' : '1' ?>">
                                <button
                                    class="case-email-toggle-button <?= $notificacionesEmailSolicitante ? 'is-on' : 'is-off' ?>"
                                    type="submit"
                                    title="<?= $notificacionesEmailSolicitante ? 'Desactivar correos de este caso' : 'Activar correos de este caso' ?>"
                                    aria-label="<?= $notificacionesEmailSolicitante ? 'Notificaciones por correo activadas. Pulsar para desactivar' : 'Notificaciones por correo desactivadas. Pulsar para activar' ?>"
                                    aria-pressed="<?= $notificacionesEmailSolicitante ? 'true' : 'false' ?>"
                                >
                                    <span class="case-email-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24">
                                            <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/>
                                            <path d="M10 21h4"/>
                                            <?php if (!$notificacionesEmailSolicitante): ?><path d="M3 3l18 18"/><?php endif; ?>
                                        </svg>
                                    </span>
                                    <span class="case-email-copy">
                                        <strong>Correo</strong>
                                        <small><?= $notificacionesEmailSolicitante ? 'Activado' : 'Desactivado' ?></small>
                                    </span>
                                </button>
                            </form>
                            <button
                                class="chat-launcher"
                                type="button"
                                data-chat-open
                                aria-controls="panel-chat-solicitante"
                                aria-expanded="false"
                            >
                                <span class="chat-launcher-icon" aria-hidden="true">
                                    <svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 9h8M8 13h5"/></svg>
                                </span>
                                <span class="chat-launcher-copy"><strong>Conversación</strong><small>Hablar con el gestor</small></span>
                            </button>
                        </div>
                    </div>
                    <div class="case-detail-scroll">
            <section class="card case-detail-card">
                <div class="card-head">
                    <?php
                        $cabeceraProcesoSolicitante = trim((string) ($trazabilidadSolucionesSolicitante[0]['catalogo_nombre'] ?? $ticketSeleccionado['proceso_nombre'] ?? 'Solicitud'));
                        $cabeceraServicioSolicitante = trim((string) ($trazabilidadSolucionesSolicitante[0]['servicio_nombre'] ?? ''));
                        $cabeceraCasoSolicitante = $cabeceraProcesoSolicitante;
                        if ($cabeceraServicioSolicitante !== '' && stripos($cabeceraProcesoSolicitante, $cabeceraServicioSolicitante) === false) {
                            $cabeceraCasoSolicitante .= ' · ' . $cabeceraServicioSolicitante;
                        }
                        $estadoSeleccionado = $etapaPendienteCalificacion
                            ? 'pendiente_calificacion'
                            : (string) (($etapasTicket[0]['estado'] ?? null) ?: ($ticketSeleccionado['estado_flujo'] ?? 'en_proceso'));
                    ?>
                    <div>
                        <div class="requester-case-title-line">
                            <span class="requester-case-code">Caso <?= (int) $ticketSeleccionado['id_ticket'] ?></span>
                            <span class="status <?= escaparPortalSolicitante($estadoSeleccionado) ?>"><?= escaparPortalSolicitante(in_array($estadoSeleccionado, ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada', 'listo_cierre', 'completada', 'cancelada'], true) ? textoEstadoCasoSolicitante($estadoSeleccionado) : textoEstadoPortalSolicitante($estadoSeleccionado)) ?></span>
                        </div>
                        <h2 id="titulo-modal-estado-caso"><?= escaparPortalSolicitante($cabeceraCasoSolicitante) ?></h2>
                        <p class="case-detail-subtitle">Revise la etapa actual y la información completa del mismo caso.</p>
                    </div>
                </div>
                <?php $proyeccionSeleccionada = $proyeccionesTickets[(int) $ticketSeleccionado['id_ticket']] ?? []; ?>
                <section class="requester-header-metadata" aria-label="Información principal del caso">
                    <div><span>Solicitante</span><strong><?= escaparPortalSolicitante($ticketSeleccionado['solicitante_nombre'] ?? 'Solicitante') ?></strong><small><?= escaparPortalSolicitante($ticketSeleccionado['solicitante_email'] ?? '') ?></small></div>
                    <div><span>Proceso</span><strong><?= escaparPortalSolicitante($cabeceraProcesoSolicitante) ?></strong><small><?= escaparPortalSolicitante($cabeceraServicioSolicitante !== '' ? $cabeceraServicioSolicitante : 'Solicitud') ?></small></div>
                    <div><span>Fecha creación</span><strong><?= escaparPortalSolicitante(fechaPortalSolicitante($ticketSeleccionado['fecha_creacion'] ?? null)) ?></strong></div>
                    <div><span>Prioridad</span><strong><?= escaparPortalSolicitante(ucfirst((string) ($ticketSeleccionado['prioridad'] ?? 'Media'))) ?></strong></div>
                    <div class="due"><span>Fecha estimada de vencimiento</span><strong><?= escaparPortalSolicitante(fechaPortalSolicitante($proyeccionSeleccionada['fecha'] ?? null)) ?></strong></div>
                </section>
                <div class="requester-secondary-overview requester-tab-panel" data-requester-panel="solucion" hidden>
                <section class="request-summary" aria-label="Información de la solicitud">
                    <?php
                        $etapaPrincipalSolicitante = $etapasTicket[0] ?? [];
                        $slaPrincipalSolicitante = trim(trim((string) ($etapaPrincipalSolicitante['sla_tiempo'] ?? '')) . ' ' . trim((string) ($etapaPrincipalSolicitante['sla_unidad'] ?? '')));
                    ?>
                    <div class="request-summary-item">
                        <span>Asunto</span>
                        <strong><?= escaparPortalSolicitante($ticketSeleccionado['titulo'] ?? 'Sin asunto') ?></strong>
                    </div>
                    <div class="request-summary-item request-summary-description">
                        <span>Descripción de la solicitud</span>
                        <p><?= escaparPortalSolicitante(trim((string) ($ticketSeleccionado['descripcion'] ?? '')) ?: 'Sin descripción registrada.') ?></p>
                    </div>
                    <div class="request-summary-meta">
                        <div>
                            <span>Solicitante</span>
                            <strong><?= escaparPortalSolicitante($ticketSeleccionado['solicitante_nombre'] ?? 'Solicitante') ?></strong>
                            <small><?= escaparPortalSolicitante($ticketSeleccionado['solicitante_email'] ?? '') ?></small>
                        </div>
                        <div>
                            <span>Proceso</span>
                            <strong><?= escaparPortalSolicitante($cabeceraProcesoSolicitante) ?></strong>
                        </div>
                        <div>
                            <span>Gestor</span>
                            <strong><?= escaparPortalSolicitante($etapaPrincipalSolicitante['gestor_nombre'] ?? 'Pendiente') ?></strong>
                        </div>
                        <div>
                            <span>SLA</span>
                            <strong><?= escaparPortalSolicitante($slaPrincipalSolicitante !== '' ? $slaPrincipalSolicitante : 'Pendiente') ?></strong>
                        </div>
                    </div>
                </section>
                <div class="detail-grid">
                    <div class="detail-item"><span>Clasificación</span><strong><?= escaparPortalSolicitante(ucfirst((string) ($ticketSeleccionado['tipo_solicitud'] ?? 'Requerimiento'))) ?></strong></div>
                    <div class="detail-item"><span>Prioridad</span><strong><?= escaparPortalSolicitante(ucfirst((string) ($ticketSeleccionado['prioridad'] ?? 'Media'))) ?></strong></div>
                    <div class="detail-item"><span>Urgencia</span><strong><?= escaparPortalSolicitante(ucfirst((string) $ticketSeleccionado['urgencia'])) ?></strong></div>
                    <div class="detail-item"><span>Fecha de creación</span><strong><?= escaparPortalSolicitante(fechaPortalSolicitante($ticketSeleccionado['fecha_creacion'] ?? null)) ?></strong></div>
                    <div class="detail-item"><span><?= ($proyeccionSeleccionada['estado'] ?? '') === 'finalizado' ? 'Fecha real de finalización' : 'Fecha estimada de vencimiento' ?></span><strong><?= escaparPortalSolicitante(fechaPortalSolicitante($proyeccionSeleccionada['fecha'] ?? null)) ?></strong><?php if (!empty($proyeccionSeleccionada['pausado_por_derivacion'])): ?><small>SLA pausado mientras finalizan las derivaciones</small><?php endif; ?></div>
                    <div class="detail-item"><span>Estado general</span><strong><?= escaparPortalSolicitante(textoEstadoPortalSolicitante($estadoSeleccionado)) ?></strong></div>
                </div>
                <?php
                    $camposExtrasInformacionSolicitante = [];
                    foreach ($todasLasEtapasTicket as $indiceEtapaExtrasSolicitante => $etapaExtrasSolicitante) {
                        $idEtapaExtrasSolicitante = (int) ($etapaExtrasSolicitante['id_ticket_etapa'] ?? 0);
                        if ($idEtapaExtrasSolicitante < 1) {
                            continue;
                        }
                        $valoresExtrasSolicitante = camposExtrasValoresEtapa(
                            $conn,
                            $idEtapaExtrasSolicitante
                        );
                        if (!$valoresExtrasSolicitante) {
                            continue;
                        }
                        $esDerivacionExtrasSolicitante = (int) ($etapaExtrasSolicitante['id_ticket_etapa_padre'] ?? 0) > 0;
                        $camposExtrasInformacionSolicitante[] = [
                            'titulo' => $esDerivacionExtrasSolicitante
                                ? 'Derivación ' . ((int) $indiceEtapaExtrasSolicitante + 1)
                                : 'Solicitud inicial',
                            'servicio' => trim((string) ($etapaExtrasSolicitante['servicio_nombre'] ?? 'Servicio')),
                            'valores' => $valoresExtrasSolicitante,
                        ];
                    }
                ?>
                <?php if ($camposExtrasInformacionSolicitante): ?>
                    <section class="requester-extra-info" aria-label="Campos extras diligenciados">
                        <div class="requester-extra-info-head">
                            <div>
                                <span>Información adicional</span>
                                <h3>Campos extras diligenciados</h3>
                            </div>
                            <strong><?= count($camposExtrasInformacionSolicitante) ?> etapa<?= count($camposExtrasInformacionSolicitante) === 1 ? '' : 's' ?></strong>
                        </div>
                        <div class="requester-extra-info-list">
                            <?php foreach ($camposExtrasInformacionSolicitante as $grupoExtrasSolicitante): ?>
                                <article class="requester-extra-info-group">
                                    <div class="requester-extra-info-group-head">
                                        <strong><?= escaparPortalSolicitante($grupoExtrasSolicitante['titulo']) ?></strong>
                                        <span><?= escaparPortalSolicitante($grupoExtrasSolicitante['servicio']) ?></span>
                                    </div>
                                    <dl>
                                        <?php foreach ($grupoExtrasSolicitante['valores'] as $valorExtraSolicitante): ?>
                                            <div>
                                                <dt><?= escaparPortalSolicitante($valorExtraSolicitante['etiqueta'] ?? 'Información adicional') ?></dt>
                                                <dd><?= escaparPortalSolicitante($valorExtraSolicitante['valor'] ?? '') ?></dd>
                                            </div>
                                        <?php endforeach; ?>
                                    </dl>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </section>
                <?php endif; ?>
                </div>
                <?php
                    $etapasResumenSolicitante = array_values(array_filter(
                        $trazabilidadSolucionesSolicitante,
                        static function (array $nodo): bool {
                            return (int) ($nodo['_nivel_trazabilidad'] ?? 0) === 0;
                        }
                    ));
                ?>
                <?php
                    $estadoFlujoLineaSolicitante = (string) ($ticketSeleccionado['estado_flujo'] ?? 'en_proceso');
                    $estadoEtapaLineaSolicitante = (string) ($etapaPrincipalSolicitante['estado'] ?? 'pendiente');
                    $casoCerradoLineaSolicitante = in_array($estadoFlujoLineaSolicitante, ['cerrado', 'cancelado', 'cancelada'], true);
                    $etapaCerradaLineaSolicitante = in_array($estadoEtapaLineaSolicitante, ['completada', 'cancelada'], true);
                    $pendienteCalificacionLineaSolicitante = $estadoFlujoLineaSolicitante === 'pendiente_calificacion'
                        || $estadoEtapaLineaSolicitante === 'listo_cierre';
                    $pasoActualLineaSolicitante = $casoCerradoLineaSolicitante
                        ? 4
                        : (($pendienteCalificacionLineaSolicitante || $etapaCerradaLineaSolicitante) ? 3 : 2);
                    $pasosLineaSolicitante = [
                        ['titulo' => 'Recepción', 'detalle' => 'Caso recibido', 'fecha' => $ticketSeleccionado['fecha_creacion'] ?? null, 'estado' => 'is-done'],
                        ['titulo' => 'Revisión', 'detalle' => $pasoActualLineaSolicitante > 2 || $etapaCerradaLineaSolicitante ? 'Gestión completada' : 'En curso', 'fecha' => $etapaPrincipalSolicitante['fecha_activacion'] ?? $etapaPrincipalSolicitante['creado_en'] ?? null, 'estado' => $pasoActualLineaSolicitante > 2 || $etapaCerradaLineaSolicitante ? 'is-done' : 'is-current'],
                        ['titulo' => 'Pendiente de calificación', 'detalle' => $pasoActualLineaSolicitante > 3 ? 'Calificado' : ($pasoActualLineaSolicitante === 3 ? 'Pendiente' : 'Pendiente'), 'fecha' => $etapaPrincipalSolicitante['fecha_marcado_listo'] ?? null, 'estado' => $pasoActualLineaSolicitante > 3 ? 'is-done' : ($pasoActualLineaSolicitante === 3 ? 'is-current' : 'is-pending')],
                        ['titulo' => 'Cierre', 'detalle' => $pasoActualLineaSolicitante === 4 ? 'Caso cerrado' : 'Pendiente', 'fecha' => $ticketSeleccionado['fecha_finalizacion'] ?? $etapaPrincipalSolicitante['fecha_finalizacion'] ?? null, 'estado' => $pasoActualLineaSolicitante === 4 ? 'is-done' : 'is-pending'],
                    ];
                ?>
                <section class="request-flow-summary requester-fixed-progress" aria-label="Etapas del proceso">
                    <div class="request-flow-summary-head">
                        <div><span>Seguimiento del caso</span><h3>Etapas del proceso</h3></div>
                        <strong><?= $pasoActualLineaSolicitante ?> de 4</strong>
                    </div>
                    <div class="request-flow-line" role="list">
                        <?php foreach ($pasosLineaSolicitante as $indicePasoLineaSolicitante => $pasoLineaSolicitante): ?>
                            <article class="request-flow-step <?= escaparPortalSolicitante($pasoLineaSolicitante['estado']) ?>" role="listitem">
                                <span class="request-flow-marker"><?= $pasoLineaSolicitante['estado'] === 'is-done' ? '✓' : (int) ($indicePasoLineaSolicitante + 1) ?></span>
                                <div class="request-flow-step-copy">
                                    <strong><?= escaparPortalSolicitante($pasoLineaSolicitante['titulo']) ?></strong>
                                    <small><?= escaparPortalSolicitante($pasoLineaSolicitante['detalle']) ?></small>
                                    <em><?= escaparPortalSolicitante(fechaPortalSolicitante($pasoLineaSolicitante['fecha'])) ?></em>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </section>
                <nav class="requester-case-tabs" aria-label="Secciones del caso">
                    <button class="requester-case-tab is-active" type="button" data-requester-tab="estructura" aria-selected="true">⌘ <span>Estructura</span></button>
                    <button class="requester-case-tab" type="button" data-requester-tab="solucion" aria-selected="false">✓ <span><?= $solucionFinalSolicitante ? 'Solución' : 'Información' ?></span></button>
                    <button class="requester-case-tab" type="button" data-requester-tab="historial" aria-selected="false">↻ <span>Historial (<?= count($historialAccionesSolicitante) ?>)</span></button>
                    <button class="requester-case-tab" type="button" data-requester-tab="adjuntos" aria-selected="false">↑ <span>Adjuntos (<?= count($adjuntosSolicitante) ?>)</span></button>
                </nav>
                <section id="requester-estructura" class="requester-tab-panel requester-structure-panel" data-requester-panel="estructura">
                    <div class="requester-structure-head">
                        <div><span>Flujo completo</span><h3>Todas las etapas y derivaciones</h3></div>
                        <strong><?= count($trazabilidadSolucionesSolicitante) ?> elementos</strong>
                    </div>
                    <div class="requester-structure-list">
                        <?php foreach ($trazabilidadSolucionesSolicitante as $indiceEstructuraSolicitante => $nodoEstructuraSolicitante): ?>
                            <?php
                                $nivelEstructuraSolicitante = min(3, (int) ($nodoEstructuraSolicitante['_nivel_trazabilidad'] ?? 0));
                                $estadoEstructuraSolicitante = (string) ($nodoEstructuraSolicitante['estado'] ?? 'pendiente');
                                $codigoEstructuraSolicitante = (string) ($nodoEstructuraSolicitante['_codigo_trazabilidad'] ?? ($indiceEstructuraSolicitante + 1));
                                $numeroEtapaEstructuraSolicitante = (int) ($nodoEstructuraSolicitante['_numero_etapa_trazabilidad'] ?? ($indiceEstructuraSolicitante + 1));
                                $esDerivacionEstructuraSolicitante = !empty($nodoEstructuraSolicitante['_es_derivacion_trazabilidad']);
                                $etiquetaNumeroEstructuraSolicitante = $esDerivacionEstructuraSolicitante
                                    ? 'Derivación ' . $codigoEstructuraSolicitante . ' · Etapa ' . $numeroEtapaEstructuraSolicitante
                                    : 'Caso ' . $idTicketSeleccionado . ' · Etapa ' . $numeroEtapaEstructuraSolicitante . ' de ' . count($etapasTicket);
                            ?>
                            <article class="requester-structure-node <?= $nivelEstructuraSolicitante > 0 ? 'is-derived' : '' ?>" style="--structure-level:<?= $nivelEstructuraSolicitante ?>">
                                <span class="requester-structure-number"><?= (int) ($indiceEstructuraSolicitante + 1) ?></span>
                                <div class="requester-structure-copy">
                                    <div class="requester-structure-top"><span class="requester-structure-code"><?= escaparPortalSolicitante($etiquetaNumeroEstructuraSolicitante) ?></span><b><?= escaparPortalSolicitante(textoEstadoCasoSolicitante($estadoEstructuraSolicitante)) ?></b></div>
                                    <strong><?= escaparPortalSolicitante(($nodoEstructuraSolicitante['catalogo_nombre'] ?? 'Proceso') . ' · ' . ($nodoEstructuraSolicitante['servicio_nombre'] ?? 'Servicio')) ?></strong>
                                    <div class="requester-structure-meta"><span><b>Gestor</b><?= escaparPortalSolicitante($nodoEstructuraSolicitante['gestor_nombre'] ?? 'Pendiente') ?></span><span><b>Activación</b><?= escaparPortalSolicitante(fechaPortalSolicitante($nodoEstructuraSolicitante['fecha_activacion'] ?? $nodoEstructuraSolicitante['creado_en'] ?? null)) ?></span><span><b>Vencimiento</b><?= escaparPortalSolicitante(fechaPortalSolicitante($nodoEstructuraSolicitante['fecha_vencimiento'] ?? null)) ?></span></div>
                                    <?php if (in_array($estadoEstructuraSolicitante, ['completada', 'cancelada'], true)): ?>
                                        <div class="requester-structure-actions"><button type="button" class="requester-solution-button" data-requester-solution data-solution-title="<?= escaparPortalSolicitante(($nodoEstructuraSolicitante['_etiqueta_trazabilidad'] ?? 'Etapa') . ' · ' . ($nodoEstructuraSolicitante['catalogo_nombre'] ?? 'Proceso') . ' · ' . ($nodoEstructuraSolicitante['servicio_nombre'] ?? 'Servicio')) ?>" data-solution-context="<?= escaparPortalSolicitante($esDerivacionEstructuraSolicitante ? ('Caso ' . $idTicketSeleccionado . ' · Derivación ' . $codigoEstructuraSolicitante) : ('Caso ' . $idTicketSeleccionado . ' · Etapa ' . $numeroEtapaEstructuraSolicitante . ' de ' . count($etapasTicket))) ?>" data-solution-name="<?= escaparPortalSolicitante(trim((string) ($nodoEstructuraSolicitante['solucion_nombre'] ?? '')) ?: 'Sin solución registrada') ?>" data-solution-detail="<?= escaparPortalSolicitante(trim((string) ($nodoEstructuraSolicitante['comentario_cierre'] ?? '')) ?: 'El gestor no dejó una descripción adicional.') ?>">Ver solución</button></div>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </section>
                <dialog class="requester-solution-modal" data-requester-solution-modal aria-labelledby="requester-solution-title">
                    <div class="requester-solution-dialog">
                        <div class="requester-solution-shell">
                            <header class="requester-solution-head">
                                <div>
                                    <span class="requester-solution-kicker">Detalle del elemento</span>
                                    <h3 id="requester-solution-title" data-requester-solution-title>Solución registrada</h3>
                                    <p class="requester-solution-context" data-requester-solution-context></p>
                                </div>
                                <button type="button" class="requester-solution-close" data-requester-solution-close aria-label="Cerrar">×</button>
                            </header>
                            <div class="requester-solution-body">
                                <div class="requester-solution-field"><span>Solución seleccionada</span><strong data-requester-solution-name>Sin solución registrada</strong></div>
                                <div class="requester-solution-field requester-solution-observation"><span>Descripción del gestor</span><p data-requester-solution-detail>El gestor no dejó una descripción adicional.</p></div>
                            </div>
                        </div>
                    </div>
                </dialog>
                <section id="requester-solucion" class="requester-tab-panel public-resolution <?= $solucionFinalSolicitante ? 'has-solution' : 'is-pending' ?>" data-requester-panel="solucion" aria-labelledby="titulo-solucion-solicitud" hidden>
                    <div class="public-resolution-head">
                        <div>
                            <h3 id="titulo-solucion-solicitud"><?= $solucionFinalSolicitante ? 'Resultado de tu solicitud' : 'Estado de tu solicitud' ?></h3>
                            <p><?= $solucionFinalSolicitante ? 'Esta es la respuesta final que dejó el proceso responsable.' : 'El proceso responsable continúa gestionando tu solicitud.' ?></p>
                        </div>
                        <?php if ($solucionFinalSolicitante): ?>
                            <span class="public-resolution-area">
                                <?= escaparPortalSolicitante($solucionFinalSolicitante['catalogo_nombre'] ?? 'Proceso responsable') ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <?php if ($solucionFinalSolicitante): ?>
                        <?php
                            $solucionPublica = trim((string) ($solucionFinalSolicitante['solucion_nombre'] ?? ''));
                            $observacionPublica = trim((string) ($solucionFinalSolicitante['comentario_cierre'] ?? ''));
                        ?>
                        <div class="public-resolution-grid">
                            <div class="public-resolution-item">
                                <span>Servicio atendido</span>
                                <strong><?= escaparPortalSolicitante($solucionFinalSolicitante['servicio_nombre'] ?? 'Solicitud') ?></strong>
                            </div>
                            <div class="public-resolution-item">
                                <span>Solución brindada</span>
                                <strong><?= escaparPortalSolicitante($solucionPublica !== '' ? $solucionPublica : 'Solución registrada') ?></strong>
                            </div>
                            <div class="public-resolution-item observation">
                                <span>Observación de la solución</span>
                                <p><?= escaparPortalSolicitante($observacionPublica !== '' ? $observacionPublica : 'El proceso no agregó una observación adicional.') ?></p>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="public-resolution-empty">Tu solicitud todavía está siendo atendida. El proceso responsable mostrará el resultado cuando termine.</p>
                    <?php endif; ?>
                </section>

                <section id="requester-historial" class="requester-tab-panel requester-history-panel" data-requester-panel="historial" aria-labelledby="titulo-historial-solicitante" hidden>
                    <div class="requester-structure-head">
                        <div><span>Seguimiento del caso</span><h3 id="titulo-historial-solicitante">Acciones del caso</h3><p>Consulta las acciones registradas durante la atención de esta solicitud.</p></div>
                        <strong><?= count($historialAccionesSolicitante) ?> eventos</strong>
                    </div>
                    <div class="requester-history-list">
                        <?php if (!$historialAccionesSolicitante): ?><p class="requester-panel-empty">Este caso todavía no tiene acciones registradas.</p><?php endif; ?>
                        <?php foreach ($historialAccionesSolicitante as $indiceHistorialSolicitante => $eventoHistorialSolicitante): ?>
                            <article class="requester-history-item">
                                <span class="requester-history-number"><?= (int) ($indiceHistorialSolicitante + 1) ?></span>
                                <div class="requester-history-copy">
                                    <div class="requester-history-top"><span>Acción realizada</span><time><?= escaparPortalSolicitante(fechaPortalSolicitante($eventoHistorialSolicitante['creado_en'] ?? null)) ?></time></div>
                                    <strong><?= escaparPortalSolicitante($eventoHistorialSolicitante['accion'] ?? 'Actualización del caso') ?></strong>
                                    <span class="requester-history-label">Qué se hizo</span>
                                    <p><?= escaparPortalSolicitante($eventoHistorialSolicitante['detalle'] ?? 'Sin detalle adicional.') ?></p>
                                    <div class="requester-history-actor">Realizado por <b><?= escaparPortalSolicitante($eventoHistorialSolicitante['usuario'] ?? 'Sistema') ?></b> · <?= escaparPortalSolicitante(rolChatPortalSolicitante((int) ($eventoHistorialSolicitante['usuario_rol'] ?? 0))) ?></div>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </section>
                <section id="requester-adjuntos" class="requester-tab-panel requester-attachments-panel" data-requester-panel="adjuntos" hidden>
                    <div class="requester-structure-head"><div><span>Archivos del caso</span><h3>Adjuntos registrados</h3></div><strong><?= count($adjuntosSolicitante) ?> archivos</strong></div>
                    <?php if ($adjuntosSolicitante): ?>
                        <div class="requester-attachments-list">
                            <?php foreach ($adjuntosSolicitante as $archivoSolicitante): ?><a href="descargarAdjunto.php?id=<?= (int) ($archivoSolicitante['id_adjunto'] ?? 0) ?>"><span><b><?= escaparPortalSolicitante($archivoSolicitante['nombre_original'] ?? 'Archivo adjunto') ?></b><small><?= escaparPortalSolicitante(fechaPortalSolicitante($archivoSolicitante['creado_en'] ?? null)) ?></small></span><strong>↓</strong></a><?php endforeach; ?>
                        </div>
                    <?php else: ?><p class="requester-panel-empty">Este caso no tiene archivos adjuntos.</p><?php endif; ?>
                </section>

                <?php
                    $abrirChatSolicitante = $idChatSeleccionado > 0
                        || in_array(
                            $mensajeActual,
                            ['mensaje_enviado', 'error_mensaje'],
                            true
                        );
                ?>
                <div
                    class="chat-widget"
                    id="conversacion-solicitante"
                    data-chat-widget
                    data-chat-theme-version="2026-08-20.6"
                    data-ticket-id="<?= $idTicketSeleccionado ?>"
                    data-stage-id="<?= (int) ($conversacionSolicitanteActual['id_ticket_etapa'] ?? 0) ?>"
                    data-auto-open="<?= $abrirChatSolicitante ? 'true' : 'false' ?>"
                >
                    <section
                        class="chat-panel"
                        id="panel-chat-solicitante"
                        aria-label="Conversación del caso"
                        aria-hidden="true"
                    >
                        <header class="chat-header">
                            <span class="chat-header-avatar" aria-hidden="true">
                                <svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 9h8M8 13h5"/></svg>
                            </span>
                            <div class="chat-header-copy">
                                <strong class="smartdesk-wordmark"><span class="smart">SMART</span><span class="desk">DESK</span> · Caso <?= $idTicketSeleccionado ?></strong>
                                <span><?= $conversacionSolicitanteActual
                                    ? escaparPortalSolicitante(
                                        ($conversacionSolicitanteActual['catalogo_nombre'] ?? 'Proceso')
                                        . ' · '
                                        . ($conversacionSolicitanteActual['gestor_destino'] ?: 'Gestor por asignar')
                                    )
                                    : 'Conversación pendiente de habilitación' ?></span>
                            </div>
                            <button class="chat-close" type="button" data-chat-close aria-label="Cerrar conversación">×</button>
                        </header>

                        <?php if ($conversacionesSolicitante): ?>
                            <?php
                                $indiceConversacionActiva = 0;
                                foreach ($conversacionesSolicitante as $indiceConversacion => $conversacionSolicitante) {
                                    if (
                                        $conversacionSolicitanteActual
                                        && (int) $conversacionSolicitanteActual['id_ticket_etapa']
                                            === (int) $conversacionSolicitante['id_ticket_etapa']
                                    ) {
                                        $indiceConversacionActiva = $indiceConversacion;
                                        break;
                                    }
                                }

                                $totalMensajesConversacionActiva = (int) (
                                    $conversacionSolicitanteActual['total_mensajes'] ?? 0
                                );
                            ?>
                            <div class="chat-stage">
                                <span class="chat-stage-label">Conversación por etapa</span>
                                <details class="chat-stage-picker" data-chat-stage-picker>
                                    <summary aria-label="Seleccionar otra etapa de la conversación">
                                        <span class="chat-stage-number"><?= $indiceConversacionActiva + 1 ?></span>
                                        <span class="chat-stage-current">
                                            <strong>Etapa <?= $indiceConversacionActiva + 1 ?> · <?= escaparPortalSolicitante($conversacionSolicitanteActual['catalogo_nombre'] ?? 'Proceso') ?></strong>
                                            <small data-chat-active-message-count data-count="<?= $totalMensajesConversacionActiva ?>"><?= $totalMensajesConversacionActiva ?> <?= $totalMensajesConversacionActiva === 1 ? 'mensaje' : 'mensajes' ?> · Seleccionar otra etapa</small>
                                        </span>
                                        <span class="chat-stage-arrow" aria-hidden="true">
                                            <svg viewBox="0 0 24 24"><path d="m7 9 5 5 5-5"/></svg>
                                        </span>
                                    </summary>
                                    <nav class="chat-stage-options" aria-label="Etapas disponibles">
                                        <?php foreach ($conversacionesSolicitante as $indiceConversacion => $conversacionSolicitante): ?>
                                            <?php
                                                $idConversacion = (int) $conversacionSolicitante['id_ticket_etapa'];
                                                $esConversacionActual = $conversacionSolicitanteActual
                                                    && (int) $conversacionSolicitanteActual['id_ticket_etapa'] === $idConversacion;
                                                $totalMensajesConversacion = (int) ($conversacionSolicitante['total_mensajes'] ?? 0);
                                                $parametrosConversacion = [
                                                    'vista' => 'tickets',
                                                    'id_ticket' => $idTicketSeleccionado,
                                                    'id_chat' => $idConversacion,
                                                ];

                                                if ($busquedaCasos !== '') {
                                                    $parametrosConversacion['buscar'] = $busquedaCasos;
                                                }

                                                if ($estadoBusquedaCasos !== 'todos') {
                                                    $parametrosConversacion['estado_busqueda'] = $estadoBusquedaCasos;
                                                }

                                                $urlConversacion = 'panelSolicitante.php?'
                                                    . http_build_query($parametrosConversacion)
                                                    . '#conversacion-solicitante';
                                            ?>
                                            <a
                                                class="chat-stage-option <?= $esConversacionActual ? 'is-active' : '' ?>"
                                                href="<?= escaparPortalSolicitante($urlConversacion) ?>"
                                                <?= $esConversacionActual ? 'aria-current="page"' : '' ?>
                                            >
                                                <span class="chat-stage-option-number"><?= $indiceConversacion + 1 ?></span>
                                                <span class="chat-stage-option-copy">
                                                    <strong>Etapa <?= $indiceConversacion + 1 ?> · <?= escaparPortalSolicitante($conversacionSolicitante['catalogo_nombre']) ?></strong>
                                                    <small <?= $esConversacionActual ? 'data-chat-option-message-count' : '' ?> data-count="<?= $totalMensajesConversacion ?>"><?= $totalMensajesConversacion ?> <?= $totalMensajesConversacion === 1 ? 'mensaje' : 'mensajes' ?></small>
                                                </span>
                                                <span class="chat-stage-check" aria-hidden="true"><?= $esConversacionActual ? '✓' : '' ?></span>
                                            </a>
                                        <?php endforeach; ?>
                                    </nav>
                                </details>
                            </div>
                        <?php endif; ?>

                        <?php if ($conversacionSolicitanteActual): ?>
                            <details class="chat-files">
                                <summary>Archivos adjuntos <span><?= count($adjuntosSolicitante) ?></span></summary>
                                <?php if ($adjuntosSolicitante): ?>
                                    <div class="chat-files-list">
                                        <?php foreach ($adjuntosSolicitante as $archivoChat): ?>
                                            <a href="descargarAdjunto.php?id=<?= (int) $archivoChat['id_adjunto'] ?>">
                                                <span><strong><?= escaparPortalSolicitante($archivoChat['nombre_original'] ?? 'Archivo adjunto') ?></strong><small><?= escaparPortalSolicitante(fechaPortalSolicitante($archivoChat['creado_en'] ?? null)) ?></small></span><span aria-hidden="true">↓</span>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?><div class="chat-files-empty">Esta conversación no tiene archivos adjuntos.</div><?php endif; ?>
                            </details>
                        <?php endif; ?>

                        <div class="chat-timeline" data-chat-timeline aria-live="polite">
                            <?php if (!$conversacionSolicitanteActual): ?>
                                <div class="chat-empty">La conversación se habilitará cuando el proceso inicie la atención del caso.</div>
                            <?php elseif (!$eventosConversacionSolicitante): ?>
                                <div class="chat-empty">Todavía no hay mensajes. Puede iniciar la conversación desde el campo inferior.</div>
                            <?php endif; ?>

                            <?php foreach ($eventosConversacionSolicitante as $eventoConversacion): ?>
                                <?php
                                    $idAutorChat = (int) ($eventoConversacion['id_autor'] ?? 0);
                                    $nombreAutorChat = trim((string) ($eventoConversacion['autor'] ?? 'Usuario'));
                                    $rolAutorChat = (int) ($eventoConversacion['autor_rol'] ?? 0);
                                    $esEventoPropio = $idAutorChat === $idUsuario;
                                    $esAdjunto = (string) ($eventoConversacion['tipo_evento'] ?? '') === 'adjunto';
                                ?>
                                <?php if (!$esAdjunto): ?>
                                    <article class="chat-bubble <?= $esEventoPropio ? 'mine' : '' ?>" <?= $esEventoPropio ? 'data-mesa-own-message="1"' : '' ?>>
                                        <span class="chat-author-row">
                                            <?php if ($idAutorChat > 0): ?>
                                                <img class="chat-profile-image" src="imagenPerfil.php?usuario=<?= $idAutorChat ?>" alt="Foto de <?= escaparPortalSolicitante($nombreAutorChat) ?>" loading="lazy">
                                            <?php else: ?>
                                                <span class="chat-profile-fallback" aria-hidden="true">US</span>
                                            <?php endif; ?>
                                            <span class="chat-author-copy">
                                                <strong><?= escaparPortalSolicitante($nombreAutorChat !== '' ? $nombreAutorChat : 'Usuario') ?></strong>
                                                <small><?= escaparPortalSolicitante(rolChatPortalSolicitante($rolAutorChat)) ?></small>
                                            </span>
                                        </span>
                                        <p class="chat-text"><?= escaparPortalSolicitante($eventoConversacion['mensaje']) ?></p>
                                        <span class="chat-time">
                                            <?= escaparPortalSolicitante(fechaPortalSolicitante($eventoConversacion['creado_en'])) ?>
                                            <?= $esEventoPropio ? '<span class="read-mark" aria-label="Enviado">✓✓</span>' : '' ?>
                                        </span>
                                    </article>
                                <?php else: ?>
                                    <?php
                                        $idAdjuntoChat = (int) $eventoConversacion['id_adjunto'];
                                        $nombreAdjuntoChat = (string) $eventoConversacion['nombre_original'];
                                        $tipoAdjuntoChat = (string) ($eventoConversacion['tipo_mime'] ?? '');
                                        $esImagenChat = mesaStrStartsWith($tipoAdjuntoChat, 'image/');
                                    ?>
                                    <article class="chat-bubble is-file <?= $esEventoPropio ? 'mine' : '' ?>" <?= $esEventoPropio ? 'data-mesa-own-message="1"' : '' ?>>
                                        <span class="chat-author-row">
                                            <?php if ($idAutorChat > 0): ?>
                                                <img class="chat-profile-image" src="imagenPerfil.php?usuario=<?= $idAutorChat ?>" alt="Foto de <?= escaparPortalSolicitante($nombreAutorChat) ?>" loading="lazy">
                                            <?php else: ?>
                                                <span class="chat-profile-fallback" aria-hidden="true">US</span>
                                            <?php endif; ?>
                                            <span class="chat-author-copy">
                                                <strong><?= escaparPortalSolicitante($nombreAutorChat !== '' ? $nombreAutorChat : 'Usuario') ?></strong>
                                                <small><?= escaparPortalSolicitante(rolChatPortalSolicitante($rolAutorChat)) ?></small>
                                            </span>
                                        </span>
                                        <a class="chat-attachment" href="descargarAdjunto.php?id=<?= $idAdjuntoChat ?>" title="Descargar <?= escaparPortalSolicitante($nombreAdjuntoChat) ?>">
                                            <?php if ($esImagenChat): ?>
                                                <img class="chat-image-preview" src="descargarAdjunto.php?id=<?= $idAdjuntoChat ?>&amp;inline=1" alt="Vista previa de <?= escaparPortalSolicitante($nombreAdjuntoChat) ?>" loading="lazy">
                                            <?php endif; ?>
                                            <span class="chat-file-card">
                                                <span class="chat-file-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7Z"/><path d="M14 3v6h5M10 14h6M10 17h5"/></svg></span>
                                                <span class="chat-file-copy">
                                                    <strong><?= escaparPortalSolicitante($nombreAdjuntoChat) ?></strong>
                                                    <span><?= escaparPortalSolicitante(flujoFormatoTamanoArchivo((int) ($eventoConversacion['tamano'] ?? 0))) ?> · Pulse para descargar</span>
                                                </span>
                                                <span class="chat-download" aria-hidden="true">↓</span>
                                            </span>
                                        </a>
                                        <span class="chat-time">
                                            <?= escaparPortalSolicitante(fechaPortalSolicitante($eventoConversacion['creado_en'])) ?>
                                            <?= $esEventoPropio ? '<span class="read-mark" aria-label="Enviado">✓✓</span>' : '' ?>
                                        </span>
                                    </article>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>

                        <?php if ($puedeEscribirSolicitante && $conversacionSolicitanteActual): ?>
                            <form class="chat-compose" method="post" enctype="multipart/form-data" data-chat-compose>
                                <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                                <input type="hidden" name="accion" value="enviar_mensaje">
                                <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                <input type="hidden" name="id_ticket_etapa" value="<?= (int) $conversacionSolicitanteActual['id_ticket_etapa'] ?>">
                                <div class="chat-file-status" data-chat-file-status aria-live="polite"></div>
                                <div class="chat-compose-row">
                                    <input class="chat-file-input" id="adjuntos_solicitante" type="file" name="adjuntos[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.txt,.csv,.zip,.doc,.docx,.xls,.xlsx" data-chat-file-input>
                                    <label class="chat-attach" for="adjuntos_solicitante" title="Adjuntar archivos" aria-label="Adjuntar archivos">
                                        <svg viewBox="0 0 24 24"><path d="m20.5 11.5-8.8 8.8a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 1 1-2.8-2.8l8.5-8.5"/></svg>
                                    </label>
                                    <textarea id="mensaje_solicitante" name="mensaje" maxlength="10000" rows="1" placeholder="Escriba un mensaje" aria-label="Mensaje"></textarea>
                                    <button class="chat-send" type="submit" title="Enviar mensaje" aria-label="Enviar mensaje">
                                        <svg viewBox="0 0 24 24"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                                    </button>
                                </div>
                            </form>
                        <?php elseif ($conversacionSolicitanteActual): ?>
                            <p class="chat-readonly">Esta conversación está cerrada y permanece disponible para consulta.</p>
                        <?php endif; ?>
                    </section>
                </div>

                <?php if ($etapaPendienteCalificacion): ?>
                    <?php
                        $esCierreDefinitivoPrimerContacto = !empty($etapaPendienteCalificacion['solicita_cierre_definitivo']);
                        $numeroEtapaSolucion = (int) ($etapaPendienteCalificacion['numero_etapa'] ?? $etapaPendienteCalificacion['orden'] ?? 1);
                        $nombreEtapaSolucion = 'Etapa ' . $numeroEtapaSolucion . ' · '
                            . trim((string) ($etapaPendienteCalificacion['catalogo_nombre'] ?? '') . ' / '
                                . (string) ($etapaPendienteCalificacion['servicio_nombre'] ?? ''), ' /');

                        if ($esCierreDefinitivoPrimerContacto) {
                            $claseResultadoAprobacion = 'definitive';
                            $tipoSolucionPendiente = 'Solución definitiva del caso';
                            $resultadoAprobacion = 'Al aprobar, el caso se cerrará por completo y no se ejecutarán las etapas siguientes.';
                            $textoBotonAprobacion = 'Calificar y aprobar cierre definitivo';
                            $confirmacionAprobacion = '¿Confirma el cierre definitivo del ticket? Al aprobar, no continuará a otra etapa.';
                        } elseif ($siguienteEtapaPendienteCalificacion) {
                            $claseResultadoAprobacion = 'continue';
                            $tipoSolucionPendiente = 'Solución de una etapa del flujo';
                            $numeroSiguienteEtapa = (int) ($siguienteEtapaPendienteCalificacion['numero_etapa'] ?? $siguienteEtapaPendienteCalificacion['orden'] ?? ($numeroEtapaSolucion + 1));
                            $resultadoAprobacion = 'Al aprobar, esta etapa quedará completada y continuará la Etapa '
                                . $numeroSiguienteEtapa . ' · '
                                . trim((string) ($siguienteEtapaPendienteCalificacion['catalogo_nombre'] ?? '') . ' / '
                                    . (string) ($siguienteEtapaPendienteCalificacion['servicio_nombre'] ?? ''), ' /') . '.';
                            $textoBotonAprobacion = 'Calificar y continuar el flujo';
                            $confirmacionAprobacion = '¿Confirma la calificación? Esta etapa se completará y se habilitará la siguiente.';
                        } else {
                            $claseResultadoAprobacion = 'final';
                            $tipoSolucionPendiente = 'Solución de la etapa final';
                            $resultadoAprobacion = 'Al aprobar, esta última etapa quedará completada y el caso se cerrará.';
                            $textoBotonAprobacion = 'Calificar y finalizar el caso';
                            $confirmacionAprobacion = '¿Confirma la calificación y el cierre del caso al completar su última etapa?';
                        }
                    ?>
                    <div class="rating-card <?= escaparPortalSolicitante($claseResultadoAprobacion) ?>">
                        <h3><?= $esCierreDefinitivoPrimerContacto ? 'Solicitud de cierre definitivo por solución en primer contacto' : 'La solución está lista para su aprobación' ?></h3>
                        <div class="solution-context" aria-label="Contexto de la solución pendiente">
                            <div class="solution-context-item">
                                <span>Etapa que presenta la solución</span>
                                <strong><?= escaparPortalSolicitante($nombreEtapaSolucion) ?></strong>
                            </div>
                            <div class="solution-context-item outcome <?= escaparPortalSolicitante($claseResultadoAprobacion) ?>">
                                <span><?= escaparPortalSolicitante($tipoSolucionPendiente) ?></span>
                                <strong><?= $esCierreDefinitivoPrimerContacto ? 'Cierra todo el caso' : ($siguienteEtapaPendienteCalificacion ? 'Continúa el flujo' : 'Finaliza el flujo') ?></strong>
                                <p><?= escaparPortalSolicitante($resultadoAprobacion) ?></p>
                            </div>
                        </div>
                        <?php if ($esCierreDefinitivoPrimerContacto): ?>
                            <div class="definitive-close-alert" role="alert">
                                <strong>Importante: esta aprobación cerrará completamente el ticket.</strong>
                                <p>El gestor informó que resolvió toda la solicitud en el primer contacto. Si usted aprueba, el caso no pasará a otra etapa ni a otro proceso y las etapas futuras que no hayan iniciado quedarán canceladas.</p>
                            </div>
                            <p>Revise la solución aplicada y califique la gestión antes de confirmar el cierre definitivo.</p>
                        <?php else: ?>
                            <p>Para aprobar esta etapa del mismo caso, califique la gestión del proceso y el tiempo de respuesta.</p>
                        <?php endif; ?>
                        <div class="solution-box">
                            <span>Solución aplicada</span>
                            <strong><?= escaparPortalSolicitante($etapaPendienteCalificacion['solucion_nombre'] ?? 'Solución registrada') ?></strong>
                            <?php if (trim((string) ($etapaPendienteCalificacion['comentario_cierre'] ?? '')) !== ''): ?>
                                <p><?= escaparPortalSolicitante($etapaPendienteCalificacion['comentario_cierre']) ?></p>
                            <?php endif; ?>
                        </div>
                        <form method="post" onsubmit="return confirm('<?= escaparPortalSolicitante($confirmacionAprobacion) ?>')">
                            <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                            <input type="hidden" name="accion" value="calificar_cerrar">
                            <input type="hidden" name="id_ticket" value="<?= (int) $ticketSeleccionado['id_ticket'] ?>">
                            <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaPendienteCalificacion['id_ticket_etapa'] ?>">
                            <div class="rating-grid">
                                <div class="field">
                                    <label for="calificacion_area">Gestión del proceso *</label>
                                    <select id="calificacion_area" name="calificacion_area" required>
                                        <option value="">Seleccione</option>
                                        <?php for ($nota = 5; $nota >= 1; $nota--): ?>
                                            <option value="<?= $nota ?>"><?= $nota ?> - <?= ['','Muy deficiente','Deficiente','Aceptable','Muy buena','Excelente'][$nota] ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="field">
                                    <label for="calificacion_tiempo">Tiempo de respuesta *</label>
                                    <select id="calificacion_tiempo" name="calificacion_tiempo" required>
                                        <option value="">Seleccione</option>
                                        <?php for ($nota = 5; $nota >= 1; $nota--): ?>
                                            <option value="<?= $nota ?>"><?= $nota ?> - <?= ['','Muy deficiente','Deficiente','Aceptable','Muy buena','Excelente'][$nota] ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="field">
                                    <label for="comentario_calificacion">Comentario opcional</label>
                                    <textarea id="comentario_calificacion" name="comentario_calificacion" maxlength="1000" placeholder="Cuéntenos qué estuvo bien o qué debe mejorar."></textarea>
                                </div>
                            </div>
                            <div class="actions"><button class="btn primary" type="submit"><?= escaparPortalSolicitante($textoBotonAprobacion) ?></button></div>
                        </form>
                        <form class="reopen-form" method="post" onsubmit="return confirm('¿Desea devolver esta etapa? El mismo caso volverá al gestor asignado y el SLA se reanudará.')">
                            <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                            <input type="hidden" name="accion" value="reabrir_caso">
                            <input type="hidden" name="id_ticket" value="<?= (int) $ticketSeleccionado['id_ticket'] ?>">
                            <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaPendienteCalificacion['id_ticket_etapa'] ?>">
                            <span class="reopen-title">¿La solución no resolvió su solicitud?</span>
                            <p>Explique el motivo para devolver esta etapa del caso al gestor asignado.</p>
                            <div class="field">
                                <label for="motivo_reapertura">Motivo de reapertura *</label>
                                <textarea id="motivo_reapertura" name="motivo_reapertura" maxlength="1000" required placeholder="Indique qué continúa fallando o por qué la solución no fue suficiente."></textarea>
                            </div>
                            <div class="actions"><button class="btn reopen" type="submit">Devolver etapa</button></div>
                        </form>
                    </div>
                <?php endif; ?>
            </section>
                    </div>
                </div>
            </section>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</main>
<script type="application/json" id="datos-servicios-solicitud"><?=
    json_encode(
        array_map(
            static function (array $servicio): array {
                $urgenciaValor = max(1, min(3, (int) ($servicio['urgencia_valor'] ?? 2)));
                $impactoValor = max(1, min(3, (int) ($servicio['impacto_valor'] ?? 2)));

                if (function_exists('matrizPrioridadCalcular')) {
                    $matriz = matrizPrioridadCalcular($urgenciaValor, $impactoValor);
                } else {
                    $urgencias = [1 => 'Más tarde', 2 => 'Pronto', 3 => 'Inmediato'];
                    $impactos = [1 => 'Bajo', 2 => 'Moderado', 3 => 'Urgente'];
                    $prioridades = [
                        1 => [1 => 'Bajo', 2 => 'Bajo moderado', 3 => 'Bajo urgente'],
                        2 => [1 => 'Moderado bajo', 2 => 'Moderado', 3 => 'Moderado urgente'],
                        3 => [1 => 'Urgente bajo', 2 => 'Urgente moderado', 3 => 'Urgente'],
                    ];
                    $matriz = [
                        'urgencia_valor' => $urgenciaValor,
                        'urgencia_nombre' => $urgencias[$urgenciaValor],
                        'impacto_valor' => $impactoValor,
                        'impacto_nombre' => $impactos[$impactoValor],
                        'prioridad_valor' => $urgenciaValor + $impactoValor - 1,
                        'prioridad_nombre' => $prioridades[$urgenciaValor][$impactoValor],
                    ];
                }

                return [
                'id_catalogo' => (int) ($servicio['id_catalogo'] ?? 0),
                'id_servicio' => (int) ($servicio['id_servicio'] ?? 0),
                'id_proceso' => (int) ($servicio['id_proceso'] ?? 0),
                'usa_proceso' => (int) ($servicio['id_proceso_etapa'] ?? 0) > 0,
                'codigo' => (string) ($servicio['codigo_servicio'] ?? ''),
                'nombre' => (string) ($servicio['servicio_nombre'] ?? 'Servicio'),
                'descripcion' => (string) ($servicio['servicio_descripcion'] ?? ''),
                'tipo_solicitud' => (string) ($servicio['tipo_solicitud'] ?? 'requerimiento'),
                'prioridad' => $matriz['prioridad_valor'] . ' · ' . $matriz['prioridad_nombre'],
                'urgencia' => $matriz['urgencia_valor'] . ' · ' . $matriz['urgencia_nombre'],
                'impacto' => $matriz['impacto_valor'] . ' · ' . $matriz['impacto_nombre'],
                'sla' => (string) ($servicio['sla_nombre'] ?? ''),
                'campos_extras' => array_map(
                    static fn (array $campo): array => [
                        'id' => (int) ($campo['id_campo_extra'] ?? 0),
                        'etiqueta' => (string) ($campo['etiqueta'] ?? ''),
                        'obligatorio' => (int) ($campo['obligatorio'] ?? 1),
                    ],
                    camposExtrasListarServicio($GLOBALS['conn'], (int) ($servicio['id_servicio'] ?? 0))
                ),
                ];
            },
            $servicios
        ),
        JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
        | JSON_HEX_TAG
        | JSON_HEX_AMP
        | JSON_HEX_APOS
        | JSON_HEX_QUOT
    )
?></script>
<script>
    (function () {
        'use strict';

        var selectorServicio = document.getElementById('id_proceso');
        var idServicioSeleccionado = document.getElementById('id_servicio');
        var usaProcesoSeleccionado = document.getElementById('usa_proceso');
        var buscadorServicio = document.getElementById('buscador-servicio');
        var contenedorSelectorServicio = document.getElementById('selector-servicio-buscable');
        var listaOpcionesServicio = document.getElementById('opciones-servicio');
        var botonOpcionesServicio = document.getElementById('alternar-opciones-servicio');
        var datosElemento = document.getElementById('datos-servicios-solicitud');
        var estadoServicios = document.getElementById('estado-servicios-catalogo');
        var selectorAreas = document.querySelector('.catalog-picker');
        var catalogos = document.querySelectorAll('[data-catalogo-solicitud]');
        var disposicionServicio = document.querySelector('.service-selection-layout');
        var resumenServicio = document.getElementById('resumen-servicio');
        var resumenNombre = document.getElementById('resumen-servicio-nombre');
        var resumenDescripcion = document.getElementById('resumen-servicio-descripcion');
        var resumenEtiquetas = document.getElementById('resumen-servicio-etiquetas');
        var resumenTipo = document.getElementById('resumen-servicio-tipo');
        var resumenPrioridad = document.getElementById('resumen-servicio-prioridad');
        var resumenUrgencia = document.getElementById('resumen-servicio-urgencia');
        var resumenImpacto = document.getElementById('resumen-servicio-impacto');
        var entradaDescripcion = document.getElementById('descripcion');
        var entradaAdjuntos = document.getElementById('adjuntos');
        var zonaAdjuntos = document.getElementById('zona-adjuntos');
        var listaAdjuntos = document.getElementById('lista-adjuntos');
        var estadoAdjuntos = document.getElementById('estado-adjuntos');
        var formularioSolicitud = document.getElementById('form-nueva-solicitud');
        var botonCrearSolicitud = document.querySelector('[data-create-request-button]');
        var estadoCrearSolicitud = document.querySelector('[data-create-request-status]');
        var contenedorCamposExtras = document.getElementById('campos-extra-solicitud');
        var listaCamposExtras = contenedorCamposExtras?.querySelector('[data-campos-extra-fields]');
        var servicios = [];
        var serviciosDisponiblesActuales = [];
        var indiceOpcionServicioActiva = -1;
        var archivosSeleccionados = [];
        var caracteresResumenActual = 0;
        var ajusteResumenPendiente = false;

        if (
            !selectorServicio
            || !idServicioSeleccionado
            || !usaProcesoSeleccionado
            || !buscadorServicio
            || !contenedorSelectorServicio
            || !listaOpcionesServicio
            || !botonOpcionesServicio
            || !datosElemento
            || !estadoServicios
            || !catalogos.length
        ) {
            return;
        }

        try {
            servicios = JSON.parse(datosElemento.textContent || '[]');
        } catch (error) {
            servicios = [];
        }

        function agregarOpcion(valor, texto) {
            var opcion = document.createElement('option');
            opcion.value = String(valor || '');
            opcion.textContent = texto;
            selectorServicio.appendChild(opcion);
        }

        function normalizarNombreServicio(valor) {
            return String(valor || '')
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .toLocaleLowerCase('es')
                .trim()
                .replace(/\s+/g, ' ');
        }

        function etiquetaServicio(servicio) {
            var codigo = String((servicio && servicio.codigo) || '').trim();
            var nombre = String((servicio && servicio.nombre) || 'Servicio').trim();
            return codigo ? codigo + ' · ' + nombre : nombre;
        }

        function compararCodigoServicio(primero, segundo) {
            var partesPrimero = String((primero && primero.codigo) || '')
                .split('.').map(function (parte) { return Number(parte) || 0; });
            var partesSegundo = String((segundo && segundo.codigo) || '')
                .split('.').map(function (parte) { return Number(parte) || 0; });
            var longitud = Math.max(partesPrimero.length, partesSegundo.length);

            for (var indice = 0; indice < longitud; indice += 1) {
                var diferencia = (partesPrimero[indice] || 0) - (partesSegundo[indice] || 0);
                if (diferencia !== 0) return diferencia;
            }

            return etiquetaServicio(primero).localeCompare(etiquetaServicio(segundo), 'es', {sensitivity:'base'});
        }

        function puntuarNombreServicio(nombre, consulta) {
            var nombreNormalizado = normalizarNombreServicio(nombre);
            var consultaNormalizada = normalizarNombreServicio(consulta);

            if (!consultaNormalizada) return 50;
            if (nombreNormalizado === consultaNormalizada) return 0;
            if (nombreNormalizado.indexOf(consultaNormalizada) === 0) return 10;

            var palabrasNombre = nombreNormalizado.split(' ');
            if (palabrasNombre.some(function (palabra) {
                return palabra.indexOf(consultaNormalizada) === 0;
            })) {
                return 20;
            }

            if (nombreNormalizado.indexOf(consultaNormalizada) !== -1) return 30;

            var palabrasConsulta = consultaNormalizada.split(' ').filter(Boolean);
            var todasCoinciden = palabrasConsulta.every(function (palabraConsulta) {
                return palabrasNombre.some(function (palabraNombre) {
                    return palabraNombre.indexOf(palabraConsulta) === 0
                        || palabraNombre.indexOf(palabraConsulta) !== -1;
                });
            });

            return todasCoinciden ? 40 : Number.POSITIVE_INFINITY;
        }

        function abrirOpcionesServicio() {
            if (buscadorServicio.disabled) return;
            sincronizarColumnasConAreas();
            ajustarVentanaOpcionesServicio();
            contenedorSelectorServicio.classList.add('is-open');
            buscadorServicio.setAttribute('aria-expanded', 'true');
        }

        function cerrarOpcionesServicio() {
            contenedorSelectorServicio.classList.remove('is-open');
            contenedorSelectorServicio.classList.remove('opens-up');
            buscadorServicio.setAttribute('aria-expanded', 'false');
            indiceOpcionServicioActiva = -1;
        }

        function actualizarOpcionServicioActiva(opciones) {
            opciones.forEach(function (opcion, indice) {
                opcion.classList.toggle('is-active', indice === indiceOpcionServicioActiva);
            });

            if (indiceOpcionServicioActiva >= 0 && opciones[indiceOpcionServicioActiva]) {
                opciones[indiceOpcionServicioActiva].scrollIntoView({block:'nearest'});
            }
        }

        function seleccionarServicio(servicio) {
            if (!servicio) return;

            selectorServicio.value = String(servicio.id_proceso);
            idServicioSeleccionado.value = String(servicio.id_servicio);
            usaProcesoSeleccionado.value = servicio.usa_proceso ? '1' : '0';
            buscadorServicio.value = etiquetaServicio(servicio);
            buscadorServicio.setCustomValidity('');
            selectorServicio.dispatchEvent(new Event('change', {bubbles:true}));
            cerrarOpcionesServicio();
        }

        function renderizarOpcionesServicio(consulta) {
            var consultaNormalizada = normalizarNombreServicio(consulta);
            var resultados = serviciosDisponiblesActuales
                .map(function (servicio, posicionOriginal) {
                    return {
                        servicio: servicio,
                        puntuacion: puntuarNombreServicio(etiquetaServicio(servicio), consultaNormalizada),
                        posicionOriginal: posicionOriginal
                    };
                })
                .filter(function (resultado) {
                    return Number.isFinite(resultado.puntuacion);
                })
                .sort(function (a, b) {
                    var comparacionCodigo = compararCodigoServicio(a.servicio, b.servicio);
                    return comparacionCodigo !== 0
                        ? comparacionCodigo
                        : a.posicionOriginal - b.posicionOriginal;
                });

            listaOpcionesServicio.innerHTML = '';
            indiceOpcionServicioActiva = -1;

            if (!resultados.length) {
                var vacio = document.createElement('p');
                vacio.className = 'service-combobox-empty';
                vacio.textContent = 'No hay servicios cuyo nombre coincida con “' + String(consulta || '').trim() + '”.';
                listaOpcionesServicio.appendChild(vacio);
                return;
            }

            resultados.forEach(function (resultado) {
                var opcion = document.createElement('button');
                var servicio = resultado.servicio;
                opcion.type = 'button';
                opcion.className = 'service-combobox-option';
                opcion.setAttribute('role', 'option');
                opcion.setAttribute(
                    'aria-selected',
                    String(
                        Number(selectorServicio.value) === Number(servicio.id_proceso)
                        && Number(idServicioSeleccionado.value) === Number(servicio.id_servicio)
                    )
                );
                opcion.dataset.idProceso = String(servicio.id_proceso);
                opcion.dataset.idServicio = String(servicio.id_servicio);
                opcion.textContent = etiquetaServicio(servicio);
                opcion.addEventListener('mousedown', function (evento) {
                    evento.preventDefault();
                });
                opcion.addEventListener('click', function () {
                    seleccionarServicio(servicio);
                    buscadorServicio.focus();
                });
                listaOpcionesServicio.appendChild(opcion);
            });
        }

        function etiquetaTipo(valor) {
            var texto = String(valor || '').trim().replace(/[_-]+/g, ' ');
            return texto ? texto.charAt(0).toUpperCase() + texto.slice(1) : 'Sin clasificación';
        }

        function sincronizarColumnasConAreas() {
            if (!disposicionServicio || !selectorAreas || window.innerWidth <= 760) {
                if (disposicionServicio) {
                    disposicionServicio.style.removeProperty('--service-selector-width');
                    disposicionServicio.style.removeProperty('--service-column-gap');
                    disposicionServicio.style.removeProperty('--service-dropdown-width');
                }
                return;
            }

            var primeraArea = selectorAreas.querySelector('.catalog-choice');
            if (!primeraArea) return;

            var estiloAreas = window.getComputedStyle(selectorAreas);
            var separacionAreas = parseFloat(estiloAreas.columnGap || estiloAreas.gap) || 10;
            var anchoPrimeraArea = primeraArea.getBoundingClientRect().width;
            var limiteDerechoAreas = selectorAreas.getBoundingClientRect().right;
            var inicioSelector = contenedorSelectorServicio.getBoundingClientRect().left;

            if (anchoPrimeraArea > 0) {
                var anchoTresAreas = (anchoPrimeraArea * 3) + (separacionAreas * 2);
                var anchoDisponible = Math.max(
                    anchoPrimeraArea,
                    limiteDerechoAreas - inicioSelector
                );

                disposicionServicio.style.setProperty(
                    '--service-selector-width',
                    Math.round(anchoPrimeraArea) + 'px'
                );
                disposicionServicio.style.setProperty(
                    '--service-column-gap',
                    separacionAreas + 'px'
                );
                disposicionServicio.style.setProperty(
                    '--service-dropdown-width',
                    Math.round(Math.min(anchoTresAreas, anchoDisponible)) + 'px'
                );
            }
        }

        function ajustarVentanaOpcionesServicio() {
            if (!contenedorSelectorServicio || !listaOpcionesServicio) {
                return;
            }

            var rectanguloSelector = contenedorSelectorServicio.getBoundingClientRect();
            var margenVentana = 14;
            var espacioDebajo = Math.max(
                60,
                window.innerHeight - rectanguloSelector.bottom - margenVentana - 5
            );
            // El catálogo siempre se abre debajo del control, incluso cerca del borde inferior.
            contenedorSelectorServicio.classList.remove('opens-up');
            contenedorSelectorServicio.style.setProperty(
                '--service-dropdown-left-space',
                Math.max(8, Math.round(rectanguloSelector.left)) + 'px'
            );
            contenedorSelectorServicio.style.setProperty(
                '--service-dropdown-max-height',
                Math.round(Math.min(381, espacioDebajo)) + 'px'
            );
        }

        function ajustarTamanoResumen() {
            if (!resumenServicio || resumenServicio.classList.contains('empty')) {
                return;
            }

            var contenedor = resumenServicio.parentElement;
            var campoSelector = selectorServicio ? selectorServicio.closest('.field') : null;

            if (!contenedor || !campoSelector || window.innerWidth <= 760) {
                resumenServicio.style.setProperty('--service-summary-width', '100%');
                return;
            }

            var estiloContenedor = window.getComputedStyle(contenedor);
            var separacion = parseFloat(estiloContenedor.columnGap || estiloContenedor.gap) || 12;
            var anchoDisponible = Math.max(
                0,
                contenedor.clientWidth - campoSelector.getBoundingClientRect().width - separacion
            );
            var anchoMinimo = Math.min(anchoDisponible, 600);

            /*
             * Entre 90 y 610 caracteres la tarjeta crece proporcionalmente.
             * Desde 610 caracteres ocupa toda la segunda columna, alineándose
             * exactamente con el borde derecho de las tarjetas de áreas.
             */
            var proporcion = Math.max(0, Math.min(1, (caracteresResumenActual - 90) / 520));
            var anchoCalculado = Math.round(
                anchoMinimo + ((anchoDisponible - anchoMinimo) * proporcion)
            );

            resumenServicio.style.setProperty(
                '--service-summary-width',
                Math.max(anchoMinimo, anchoCalculado) + 'px'
            );
        }

        function mostrarResumen(servicio) {
            if (!resumenServicio || !resumenNombre || !resumenDescripcion) {
                return;
            }

            resumenServicio.style.removeProperty('--service-summary-width');
            resumenServicio.style.removeProperty('height');
            resumenDescripcion.classList.remove('is-scrollable');

            if (!servicio) {
                caracteresResumenActual = 0;
                resumenServicio.classList.add('empty');
                resumenNombre.textContent = 'Seleccione un servicio para que aparezca la información de él en este apartado.';
                resumenDescripcion.textContent = '';
                resumenDescripcion.hidden = true;
                if (resumenEtiquetas) resumenEtiquetas.hidden = true;
                if (contenedorCamposExtras) contenedorCamposExtras.hidden = true;
                if (listaCamposExtras) listaCamposExtras.replaceChildren();
                return;
            }

            var descripcion = String(servicio.descripcion || '').trim()
                || 'El administrador no registró una descripción para este servicio.';
            var caracteres = descripcion.length;
            caracteresResumenActual = caracteres;

            resumenServicio.classList.remove('empty');
            resumenNombre.textContent = etiquetaServicio(servicio);
            resumenDescripcion.textContent = descripcion;
            resumenDescripcion.hidden = false;
            resumenTipo.textContent = etiquetaTipo(servicio.tipo_solicitud);
            resumenPrioridad.textContent = 'Prioridad: ' + (servicio.prioridad_nombre || 'Moderado');
            resumenUrgencia.textContent = 'Urgencia: ' + (servicio.urgencia_nombre || 'Pronto');
            if (resumenImpacto) {
                resumenImpacto.textContent = 'Impacto: ' + (servicio.impacto_nombre || 'Moderado');
            }
            resumenEtiquetas.hidden = false;
            if (listaCamposExtras && contenedorCamposExtras) {
                listaCamposExtras.replaceChildren();
                (Array.isArray(servicio.campos_extras) ? servicio.campos_extras : []).forEach(function (campo) {
                    var envoltura = document.createElement('div');
                    envoltura.className = 'field';
                    var etiqueta = document.createElement('label');
                    var idCampo = String(campo.id || '');
                    etiqueta.htmlFor = 'campo-extra-' + idCampo;
                    etiqueta.textContent = String(campo.etiqueta || 'Información adicional') + (Number(campo.obligatorio) === 1 ? ' *' : '');
                    var entrada = document.createElement('textarea');
                    entrada.id = 'campo-extra-' + idCampo;
                    entrada.name = 'campos_extras[' + idCampo + ']';
                    entrada.rows = 2;
                    entrada.maxLength = 5000;
                    entrada.required = Number(campo.obligatorio) === 1;
                    entrada.placeholder = 'Ingrese ' + String(campo.etiqueta || 'la información').toLocaleLowerCase('es');
                    envoltura.append(etiqueta, entrada);
                    listaCamposExtras.appendChild(envoltura);
                });
                contenedorCamposExtras.hidden = listaCamposExtras.children.length === 0;
            }

            requestAnimationFrame(function () {
                sincronizarColumnasConAreas();
                ajustarTamanoResumen();
                resumenDescripcion.classList.toggle(
                    'is-scrollable',
                    resumenDescripcion.scrollHeight > resumenDescripcion.clientHeight + 1
                );
            });
        }

        window.addEventListener('resize', function () {
            if (ajusteResumenPendiente) return;
            ajusteResumenPendiente = true;
            requestAnimationFrame(function () {
                ajusteResumenPendiente = false;
                sincronizarColumnasConAreas();
                ajustarTamanoResumen();
                if (contenedorSelectorServicio.classList.contains('is-open')) {
                    ajustarVentanaOpcionesServicio();
                }
            });
        });

        function cargarServicios(idCatalogo) {
            var disponibles = servicios.filter(function (servicio) {
                return Number(servicio.id_catalogo) === Number(idCatalogo)
                    && Number(servicio.id_proceso) > 0;
            });

            serviciosDisponiblesActuales = disponibles;
            selectorServicio.innerHTML = '';
            idServicioSeleccionado.value = '';
            usaProcesoSeleccionado.value = '';
            selectorServicio.disabled = disponibles.length === 0;
            buscadorServicio.disabled = disponibles.length === 0;
            botonOpcionesServicio.disabled = disponibles.length === 0;
            buscadorServicio.value = '';
            buscadorServicio.setCustomValidity('');
            buscadorServicio.placeholder = disponibles.length
                ? 'Escriba o seleccione un servicio'
                : 'No hay servicios disponibles';
            listaOpcionesServicio.innerHTML = '';
            cerrarOpcionesServicio();
            estadoServicios.classList.toggle('warning', disponibles.length === 0);
            mostrarResumen(null);

            if (!disponibles.length) {
                agregarOpcion('', 'No hay servicios disponibles en este proceso');
                estadoServicios.textContent = 'Este proceso todavía no tiene servicios con subproceso, gestor y SLA activos.';
                return;
            }

            agregarOpcion('', 'Seleccione un servicio');
            disponibles.forEach(function (servicio) {
                agregarOpcion(servicio.id_proceso, servicio.nombre);
            });
            renderizarOpcionesServicio('');
            estadoServicios.textContent = disponibles.length === 1
                ? 'Se encontró 1 servicio disponible.'
                : 'Se encontraron ' + disponibles.length + ' servicios disponibles.';
        }

        selectorServicio.addEventListener('change', function () {
            var seleccionado = servicios.find(function (servicio) {
                return Number(servicio.id_proceso) === Number(selectorServicio.value)
                    && Number(servicio.id_servicio) === Number(idServicioSeleccionado.value);
            });
            mostrarResumen(seleccionado || null);
        });

        function abrirSelectorParaCambiarServicio() {
            var hayServicioSeleccionado = selectorServicio.value !== '';

            /*
             * El nombre ya elegido no debe convertirse en un filtro al
             * reabrir el selector. En ese caso se muestra nuevamente todo el
             * catálogo del área y se marca el texto para reemplazarlo al
             * escribir.
             */
            renderizarOpcionesServicio(
                hayServicioSeleccionado ? '' : buscadorServicio.value
            );
            abrirOpcionesServicio();

            if (hayServicioSeleccionado) {
                requestAnimationFrame(function () {
                    buscadorServicio.select();
                });
            }
        }

        buscadorServicio.addEventListener('focus', function () {
            abrirSelectorParaCambiarServicio();
        });

        buscadorServicio.addEventListener('click', function () {
            abrirSelectorParaCambiarServicio();
        });

        buscadorServicio.addEventListener('input', function () {
            selectorServicio.value = '';
            idServicioSeleccionado.value = '';
            usaProcesoSeleccionado.value = '';
            selectorServicio.dispatchEvent(new Event('change', {bubbles:true}));
            buscadorServicio.setCustomValidity(
                buscadorServicio.value.trim() === ''
                    ? 'Seleccione un servicio de la lista.'
                    : 'Seleccione una de las coincidencias mostradas.'
            );
            renderizarOpcionesServicio(buscadorServicio.value);
            abrirOpcionesServicio();
        });

        buscadorServicio.addEventListener('keydown', function (evento) {
            if (evento.key === 'ArrowDown' || evento.key === 'ArrowUp') {
                evento.preventDefault();
                if (!contenedorSelectorServicio.classList.contains('is-open')) {
                    abrirSelectorParaCambiarServicio();
                }

                var opciones = Array.from(
                    listaOpcionesServicio.querySelectorAll('.service-combobox-option')
                );
                if (!opciones.length) return;

                var incremento = evento.key === 'ArrowDown' ? 1 : -1;
                indiceOpcionServicioActiva = indiceOpcionServicioActiva < 0
                    ? (incremento > 0 ? 0 : opciones.length - 1)
                    : (indiceOpcionServicioActiva + incremento + opciones.length) % opciones.length;
                actualizarOpcionServicioActiva(opciones);
                return;
            }

            if (evento.key === 'Enter' && contenedorSelectorServicio.classList.contains('is-open')) {
                var opciones = Array.from(
                    listaOpcionesServicio.querySelectorAll('.service-combobox-option')
                );
                if (indiceOpcionServicioActiva >= 0 && opciones[indiceOpcionServicioActiva]) {
                    evento.preventDefault();
                    opciones[indiceOpcionServicioActiva].click();
                }
                return;
            }

            if (evento.key === 'Escape') {
                cerrarOpcionesServicio();
            }
        });

        botonOpcionesServicio.addEventListener('click', function () {
            if (contenedorSelectorServicio.classList.contains('is-open')) {
                cerrarOpcionesServicio();
                return;
            }

            abrirSelectorParaCambiarServicio();
            buscadorServicio.focus();
        });

        document.addEventListener('click', function (evento) {
            if (!contenedorSelectorServicio.contains(evento.target)) {
                cerrarOpcionesServicio();
            }
        });

        if (formularioSolicitud) {
            formularioSolicitud.addEventListener('submit', function (evento) {
                if (!selectorServicio.value || !idServicioSeleccionado.value) {
                    evento.preventDefault();
                    buscadorServicio.setCustomValidity('Seleccione un servicio de la lista.');
                    buscadorServicio.reportValidity();
                    buscadorServicio.focus();
                    renderizarOpcionesServicio(buscadorServicio.value);
                    abrirOpcionesServicio();
                }
            });
        }

        catalogos.forEach(function (catalogo) {
            catalogo.addEventListener('change', function () {
                if (catalogo.checked) {
                    cargarServicios(catalogo.value);
                    buscadorServicio.focus();
                }
            });
        });

        for (var indice = 0; indice < catalogos.length; indice += 1) {
            if (catalogos[indice].checked) {
                cargarServicios(catalogos[indice].value);
                break;
            }
        }

        sincronizarColumnasConAreas();

        function ajustarAlturaDescripcion() {
            if (!entradaDescripcion) return;
            /* Reiniciar a auto permite reducir el campo al borrar texto y
               volver a medir correctamente cuando cambia el ancho responsive. */
            entradaDescripcion.style.height = 'auto';
            var alturaNecesaria = Math.min(entradaDescripcion.scrollHeight, 360);
            entradaDescripcion.style.height = Math.max(64, alturaNecesaria) + 'px';
            entradaDescripcion.classList.toggle('is-scrollable', entradaDescripcion.scrollHeight > 360);
        }

        if (entradaDescripcion) {
            entradaDescripcion.addEventListener('input', ajustarAlturaDescripcion);
            window.addEventListener('resize', ajustarAlturaDescripcion);
            ajustarAlturaDescripcion();
        }

        function formatoTamano(bytes) {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
            return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
        }

        function sincronizarAdjuntos() {
            if (!entradaAdjuntos || !listaAdjuntos || !estadoAdjuntos) return;

            if (typeof DataTransfer !== 'undefined') {
                var transferencia = new DataTransfer();
                archivosSeleccionados.forEach(function (archivo) {
                    transferencia.items.add(archivo);
                });
                entradaAdjuntos.files = transferencia.files;
            }

            listaAdjuntos.innerHTML = '';
            listaAdjuntos.hidden = archivosSeleccionados.length === 0;

            archivosSeleccionados.forEach(function (archivo, indiceArchivo) {
                var item = document.createElement('div');
                item.className = 'file-item';
                var datos = document.createElement('span');
                var nombre = document.createElement('strong');
                var tamano = document.createElement('small');
                var quitar = document.createElement('button');
                nombre.textContent = archivo.name;
                tamano.textContent = formatoTamano(archivo.size);
                quitar.type = 'button';
                quitar.className = 'file-remove';
                quitar.setAttribute('aria-label', 'Quitar ' + archivo.name);
                quitar.textContent = '×';
                quitar.addEventListener('click', function () {
                    archivosSeleccionados.splice(indiceArchivo, 1);
                    sincronizarAdjuntos();
                });
                datos.appendChild(nombre);
                datos.appendChild(tamano);
                item.appendChild(datos);
                item.appendChild(quitar);
                listaAdjuntos.appendChild(item);
            });

            estadoAdjuntos.classList.remove('error');
            estadoAdjuntos.textContent = archivosSeleccionados.length
                ? archivosSeleccionados.length + ' de 5 archivos seleccionados.'
                : 'Máximo cinco archivos de 5 MB cada uno.';
        }

        function agregarArchivos(archivos) {
            if (!estadoAdjuntos) return;
            var rechazados = [];
            var extensionesPermitidas = [
                'pdf', 'jpg', 'jpeg', 'png', 'webp', 'txt', 'csv', 'zip',
                'doc', 'docx', 'xls', 'xlsx'
            ];

            Array.from(archivos || []).forEach(function (archivo) {
                var partesNombre = archivo.name.toLowerCase().split('.');
                var extension = partesNombre.length > 1 ? partesNombre.pop() : '';
                var repetido = archivosSeleccionados.some(function (actual) {
                    return actual.name === archivo.name
                        && actual.size === archivo.size
                        && actual.lastModified === archivo.lastModified;
                });

                if (repetido) return;
                if (!extensionesPermitidas.includes(extension)) {
                    rechazados.push(archivo.name + ' no tiene un formato permitido');
                    return;
                }
                if (archivo.size > 5 * 1024 * 1024) {
                    rechazados.push(archivo.name + ' supera 5 MB');
                    return;
                }
                if (archivosSeleccionados.length >= 5) {
                    rechazados.push('Solo se permiten cinco archivos');
                    return;
                }
                archivosSeleccionados.push(archivo);
            });

            sincronizarAdjuntos();
            if (rechazados.length) {
                estadoAdjuntos.classList.add('error');
                estadoAdjuntos.textContent = rechazados.join('. ') + '.';
            }
        }

        if (entradaAdjuntos && zonaAdjuntos) {
            entradaAdjuntos.addEventListener('change', function () {
                agregarArchivos(entradaAdjuntos.files);
            });
            ['dragenter', 'dragover'].forEach(function (evento) {
                zonaAdjuntos.addEventListener(evento, function (event) {
                    event.preventDefault();
                    zonaAdjuntos.classList.add('dragover');
                });
            });
            ['dragleave', 'drop'].forEach(function (evento) {
                zonaAdjuntos.addEventListener(evento, function (event) {
                    event.preventDefault();
                    zonaAdjuntos.classList.remove('dragover');
                });
            });
            zonaAdjuntos.addEventListener('drop', function (event) {
                agregarArchivos(event.dataTransfer ? event.dataTransfer.files : []);
            });
        }

        formularioSolicitud?.addEventListener('submit', function (event) {
            if (formularioSolicitud.dataset.sending === 'true') {
                event.preventDefault();
                return;
            }

            if (!formularioSolicitud.checkValidity()) {
                return;
            }

            formularioSolicitud.dataset.sending = 'true';
            formularioSolicitud.setAttribute('aria-busy', 'true');

            if (botonCrearSolicitud) {
                botonCrearSolicitud.disabled = true;
                botonCrearSolicitud.textContent = 'Creando solicitud…';
            }

            if (estadoCrearSolicitud) {
                estadoCrearSolicitud.textContent = 'Espere un momento. No cierre ni vuelva a enviar el formulario.';
            }
        });
    }());
</script>
<script>
    (function () {
        'use strict';

        window.__MESA_SOLICITANTE_ESTADO_MODAL_VERSION__ = '2026-08-21.1';

        var entradaBusqueda = document.getElementById('buscar-casos');
        var selectorEstado = document.getElementById('estado-casos');
        var botonesEstado = Array.from(document.querySelectorAll('[data-case-filter-state]'));
        var botonLimpiar = document.getElementById('limpiar-filtro-casos');
        var contadorCasos = document.getElementById('contador-casos');
        var filaSinResultados = document.getElementById('sin-resultados-casos');
        var filasCasos = Array.from(document.querySelectorAll('[data-case-row]'));
        var tareaFiltro = 0;

        function normalizarTexto(valor) {
            return String(valor || '')
                .toLocaleLowerCase('es')
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .trim();
        }

        function guardarFiltrosEnUrl() {
            if (window.top !== window.self) {
                return;
            }
            if (!window.history || typeof window.history.replaceState !== 'function') {
                return;
            }

            var url = new URL(window.location.href);
            var busqueda = entradaBusqueda ? entradaBusqueda.value.trim() : '';
            var estado = selectorEstado ? selectorEstado.value : 'todos';

            if (busqueda) {
                url.searchParams.set('buscar', busqueda);
            } else {
                url.searchParams.delete('buscar');
            }

            if (estado && estado !== 'todos') {
                url.searchParams.set('estado_busqueda', estado);
            } else {
                url.searchParams.delete('estado_busqueda');
            }

            window.history.replaceState({}, '', url.toString());
        }

        function aplicarFiltros(persistir) {
            if (!entradaBusqueda || !selectorEstado || !filasCasos.length) {
                return;
            }

            var texto = normalizarTexto(entradaBusqueda.value);
            var numeroCaso = texto
                .replace(/^caso\s*/u, '')
                .replace(/^#/u, '')
                .trim();
            var buscarCasoExacto = texto !== '' && /^\d+$/.test(numeroCaso);
            var estado = selectorEstado.value || 'todos';
            var visibles = 0;

            filasCasos.forEach(function (fila) {
                var coincideTexto = !texto;

                if (!coincideTexto && buscarCasoExacto) {
                    coincideTexto = String(fila.dataset.ticketId || '') === numeroCaso;
                } else if (!coincideTexto) {
                    coincideTexto = normalizarTexto(fila.textContent).includes(texto);
                }
                var coincideEstado = estado === 'todos'
                    || fila.dataset.caseCategory === estado;
                var visible = coincideTexto && coincideEstado;
                fila.hidden = !visible;

                if (visible) {
                    visibles += 1;
                }
            });

            if (contadorCasos) {
                contadorCasos.textContent = visibles === 1
                    ? '1 caso encontrado'
                    : visibles + ' casos encontrados';
            }

            if (filaSinResultados) {
                filaSinResultados.hidden = visibles !== 0;
            }

            if (botonLimpiar) {
                botonLimpiar.hidden = entradaBusqueda.value.length === 0;
            }

            botonesEstado.forEach(function (botonEstado) {
                var activo = botonEstado.dataset.caseFilterState === estado;
                botonEstado.classList.toggle('is-active', activo);
                botonEstado.setAttribute('aria-pressed', activo ? 'true' : 'false');
            });

            if (persistir) {
                guardarFiltrosEnUrl();
            }
        }

        function programarFiltro() {
            if (tareaFiltro) {
                window.cancelAnimationFrame(tareaFiltro);
            }

            tareaFiltro = window.requestAnimationFrame(function () {
                tareaFiltro = 0;
                aplicarFiltros(true);
            });
        }

        if (entradaBusqueda && selectorEstado && filasCasos.length) {
            entradaBusqueda.addEventListener('input', programarFiltro);
            selectorEstado.addEventListener('change', function () {
                aplicarFiltros(true);
            });
            botonesEstado.forEach(function (botonEstado) {
                botonEstado.addEventListener('click', function () {
                    selectorEstado.value = botonEstado.dataset.caseFilterState || 'todos';
                    aplicarFiltros(true);
                });
            });

            if (botonLimpiar) {
                botonLimpiar.addEventListener('click', function () {
                    entradaBusqueda.value = '';
                    aplicarFiltros(true);
                    entradaBusqueda.focus();
                });
            }

            document.querySelectorAll('[data-case-view]').forEach(function (enlace) {
                enlace.addEventListener('click', function () {
                    var url = new URL(enlace.dataset.mesaRoute || enlace.href, window.location.href);
                    var busqueda = entradaBusqueda.value.trim();
                    var estado = selectorEstado.value || 'todos';

                    if (busqueda) {
                        url.searchParams.set('buscar', busqueda);
                    } else {
                        url.searchParams.delete('buscar');
                    }

                    if (estado !== 'todos') {
                        url.searchParams.set('estado_busqueda', estado);
                    } else {
                        url.searchParams.delete('estado_busqueda');
                    }

                    enlace.dataset.mesaRoute = url.toString();
                    enlace.href = url.toString();
                });
            });

            aplicarFiltros(false);
        }

        var modalCaso = document.getElementById('modal-estado-caso');

        if (!modalCaso) {
            return;
        }

        var requesterTabs = Array.from(modalCaso.querySelectorAll('[data-requester-tab]'));
        var requesterPanels = Array.from(modalCaso.querySelectorAll('[data-requester-panel]'));
        function activarPanelSolicitante(nombrePanel) {
            requesterTabs.forEach(function (tab) {
                var activo = tab.dataset.requesterTab === nombrePanel;
                tab.classList.toggle('is-active', activo);
                tab.setAttribute('aria-selected', activo ? 'true' : 'false');
            });
            requesterPanels.forEach(function (panel) {
                panel.hidden = panel.dataset.requesterPanel !== nombrePanel;
            });
        }
        requesterTabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                activarPanelSolicitante(tab.dataset.requesterTab || 'estructura');
            });
        });
        activarPanelSolicitante('estructura');

        var requesterSolutionModal = modalCaso.querySelector('[data-requester-solution-modal]');
        var requesterSolutionDragHandle = requesterSolutionModal?.querySelector('.requester-solution-head');
        var requesterSolutionTitle = requesterSolutionModal?.querySelector('[data-requester-solution-title]');
        var requesterSolutionContext = requesterSolutionModal?.querySelector('[data-requester-solution-context]');
        var requesterSolutionName = requesterSolutionModal?.querySelector('[data-requester-solution-name]');
        var requesterSolutionDetail = requesterSolutionModal?.querySelector('[data-requester-solution-detail]');
        function cerrarSolucionSolicitante() {
            if (!requesterSolutionModal) return;
            if (typeof requesterSolutionModal.close === 'function' && requesterSolutionModal.open) {
                requesterSolutionModal.close();
            } else {
                requesterSolutionModal.removeAttribute('open');
            }
            document.body.classList.remove('requester-solution-open');
        }
        modalCaso.querySelectorAll('[data-requester-solution]').forEach(function (botonSolucion) {
            botonSolucion.addEventListener('click', function () {
                if (!requesterSolutionModal) return;
                if (requesterSolutionTitle) requesterSolutionTitle.textContent = botonSolucion.dataset.solutionTitle || 'Solución registrada';
                if (requesterSolutionContext) requesterSolutionContext.textContent = botonSolucion.dataset.solutionContext || '';
                if (requesterSolutionName) requesterSolutionName.textContent = botonSolucion.dataset.solutionName || 'Sin solución registrada';
                if (requesterSolutionDetail) requesterSolutionDetail.textContent = botonSolucion.dataset.solutionDetail || 'El gestor no dejó una descripción adicional.';
                if (typeof requesterSolutionModal.showModal === 'function') {
                    if (!requesterSolutionModal.open) requesterSolutionModal.showModal();
                } else if (typeof requesterSolutionModal.show === 'function') {
                    if (!requesterSolutionModal.open) requesterSolutionModal.show();
                } else {
                    requesterSolutionModal.setAttribute('open', '');
                }
                document.body.classList.add('requester-solution-open');
                requesterSolutionModal.querySelector('[data-requester-solution-close]')?.focus();
            });
        });
        requesterSolutionModal?.querySelector('[data-requester-solution-close]')?.addEventListener('click', cerrarSolucionSolicitante);
        requesterSolutionModal?.addEventListener('click', function (event) {
            if (event.target === requesterSolutionModal) cerrarSolucionSolicitante();
        });
        requesterSolutionModal?.addEventListener('cancel', function (event) {
            event.preventDefault();
            cerrarSolucionSolicitante();
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') cerrarSolucionSolicitante();
        });

        var requesterSolutionDragState = null;
        requesterSolutionDragHandle?.addEventListener('pointerdown', function (event) {
            var origin = event.target instanceof Element ? event.target : null;
            if (event.button !== 0 || origin?.closest('button')) return;
            var rect = requesterSolutionModal.getBoundingClientRect();
            requesterSolutionDragState = {
                pointerId: event.pointerId,
                startX: event.clientX,
                startY: event.clientY,
                offsetX: event.clientX - rect.left,
                offsetY: event.clientY - rect.top,
                left: rect.left,
                top: rect.top,
                width: rect.width,
                height: rect.height,
                active: false
            };
            requesterSolutionDragHandle.setPointerCapture?.(event.pointerId);
        });
        requesterSolutionDragHandle?.addEventListener('pointermove', function (event) {
            var drag = requesterSolutionDragState;
            if (!drag || drag.pointerId !== event.pointerId) return;
            if (!drag.active) {
                var movedX = Math.abs(event.clientX - drag.startX);
                var movedY = Math.abs(event.clientY - drag.startY);
                if (Math.max(movedX, movedY) < 4) return;
                drag.active = true;
                requesterSolutionModal.style.inset = 'auto';
                requesterSolutionModal.style.right = 'auto';
                requesterSolutionModal.style.left = drag.left + 'px';
                requesterSolutionModal.style.top = drag.top + 'px';
                requesterSolutionDragHandle.classList.add('is-dragging');
            }
            var left = Math.min(Math.max(8, event.clientX - drag.offsetX), Math.max(8, window.innerWidth - drag.width - 8));
            var top = Math.min(Math.max(8, event.clientY - drag.offsetY), Math.max(8, window.innerHeight - drag.height - 8));
            requesterSolutionModal.style.left = left + 'px';
            requesterSolutionModal.style.top = top + 'px';
            event.preventDefault();
        });
        var detenerArrastreSolucionSolicitante = function (event) {
            if (!requesterSolutionDragState || requesterSolutionDragState.pointerId !== event.pointerId) return;
            requesterSolutionDragState = null;
            requesterSolutionDragHandle?.classList.remove('is-dragging');
            requesterSolutionDragHandle?.releasePointerCapture?.(event.pointerId);
        };
        requesterSolutionDragHandle?.addEventListener('pointerup', detenerArrastreSolucionSolicitante);
        requesterSolutionDragHandle?.addEventListener('pointercancel', detenerArrastreSolucionSolicitante);

        var chatWidget = modalCaso.querySelector('[data-chat-widget]');
        var botonAbrirChat = modalCaso.querySelector('[data-chat-open]');
        var botonCerrarChat = chatWidget?.querySelector('[data-chat-close]');
        var panelChat = chatWidget?.querySelector('.chat-panel');
        var lineaTiempoChat = chatWidget?.querySelector('[data-chat-timeline]');
        var formularioChat = chatWidget?.querySelector('[data-chat-compose]');
        var textoChat = formularioChat?.querySelector('textarea');
        var entradaArchivosChat = formularioChat?.querySelector('[data-chat-file-input]');
        var estadoArchivosChat = formularioChat?.querySelector('[data-chat-file-status]');
        var idTicketChat = Number(chatWidget?.dataset.ticketId || 0);
        var idEtapaChat = Number(chatWidget?.dataset.stageId || 0);
        var revisionChat = '';
        var firmaChat = '';
        var temporizadorChat = null;
        var comprobandoChat = false;
        var comprobandoRevisionChat = false;
        var solicitanteChatActivo = false;

        function tiempoChat(valor) {
            var fecha = new Date(String(valor || '').replace(' ', 'T'));
            if (Number.isNaN(fecha.getTime())) {
                return String(valor || '');
            }
            return fecha.toLocaleString('es-CO', {
                day: '2-digit',
                month: 'short',
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function autorEventoChat(evento) {
            var fila = document.createElement('span');
            fila.className = 'chat-author-row';
            if (evento.avatar) {
                var imagen = document.createElement('img');
                imagen.className = 'chat-profile-image';
                imagen.src = evento.avatar;
                imagen.alt = 'Foto de ' + (evento.autor || 'Usuario');
                imagen.loading = 'lazy';
                fila.appendChild(imagen);
            }
            var copia = document.createElement('span');
            copia.className = 'chat-author-copy';
            var nombre = document.createElement('strong');
            nombre.textContent = evento.autor || 'Usuario';
            var rol = document.createElement('small');
            rol.textContent = evento.autor_rol || 'Usuario';
            copia.append(nombre, rol);
            fila.appendChild(copia);
            return fila;
        }

        function eventoChat(evento) {
            var esAdjunto = evento.tipo === 'adjunto';
            var articulo = document.createElement('article');
            articulo.className = 'chat-bubble' + (evento.propio ? ' mine' : '')
                + (esAdjunto ? ' is-file' : '');
            if (evento.propio) {
                articulo.dataset.mesaOwnMessage = '1';
            }
            articulo.appendChild(autorEventoChat(evento));

            if (esAdjunto) {
                var enlace = document.createElement('a');
                enlace.className = 'chat-attachment';
                enlace.href = evento.url || '#';
                enlace.target = '_blank';
                enlace.rel = 'noopener';
                if (evento.preview) {
                    var vista = document.createElement('img');
                    vista.className = 'chat-image-preview';
                    vista.src = evento.preview;
                    vista.alt = evento.nombre || 'Vista previa';
                    vista.loading = 'lazy';
                    enlace.appendChild(vista);
                }
                var tarjeta = document.createElement('span');
                tarjeta.className = 'chat-file-card';
                var icono = document.createElement('span');
                icono.className = 'chat-file-icon';
                icono.textContent = '📎';
                var copiaArchivo = document.createElement('span');
                copiaArchivo.className = 'chat-file-copy';
                var nombreArchivo = document.createElement('strong');
                nombreArchivo.textContent = evento.nombre || 'Archivo adjunto';
                var tipoArchivo = document.createElement('span');
                tipoArchivo.textContent = evento.mime || 'Pulse para descargar';
                copiaArchivo.append(nombreArchivo, tipoArchivo);
                tarjeta.append(icono, copiaArchivo);
                enlace.appendChild(tarjeta);
                articulo.appendChild(enlace);
            } else {
                var texto = document.createElement('p');
                texto.className = 'chat-text';
                texto.textContent = evento.mensaje || '';
                articulo.appendChild(texto);
            }

            var hora = document.createElement('span');
            hora.className = 'chat-time';
            hora.appendChild(document.createTextNode(tiempoChat(evento.creado_en)));
            if (evento.propio && !esAdjunto) {
                var marca = document.createElement('span');
                var estado = evento.estado_envio || 'enviado';
                marca.className = 'read-mark' + (estado === 'leido' ? ' is-read' : '');
                marca.textContent = ['entregado', 'leido'].indexOf(estado) !== -1 ? '✓✓' : '✓';
                marca.title = estado === 'leido'
                    ? 'Leído'
                    : (estado === 'entregado' ? 'Entregado' : 'Enviado');
                marca.setAttribute('aria-label', marca.title);
                hora.appendChild(marca);
            }
            articulo.appendChild(hora);
            return articulo;
        }

        function dibujarEventosChat(eventos, forzarAbajo) {
            if (!lineaTiempoChat) return;
            var firma = (eventos || []).map(function (evento) {
                return [evento.tipo, evento.id_evento, evento.estado_envio || ''].join(':');
            }).join('|');
            if (firma === firmaChat) return;
            var posicionAnterior = lineaTiempoChat.scrollTop;
            var cercaDelFinal = forzarAbajo
                || lineaTiempoChat.scrollHeight - posicionAnterior - lineaTiempoChat.clientHeight < 90;
            lineaTiempoChat.replaceChildren();
            if (!eventos || !eventos.length) {
                var vacio = document.createElement('div');
                vacio.className = 'chat-empty';
                vacio.textContent = 'Todavía no hay mensajes. Puede iniciar la conversación desde el campo inferior.';
                lineaTiempoChat.appendChild(vacio);
            } else {
                eventos.forEach(function (evento) {
                    lineaTiempoChat.appendChild(eventoChat(evento));
                });
            }
            firmaChat = firma;
            window.requestAnimationFrame(function () {
                lineaTiempoChat.scrollTop = cercaDelFinal
                    ? lineaTiempoChat.scrollHeight
                    : posicionAnterior;
            });
        }

        async function actualizarChatSolicitante(forzarAbajo) {
            if (
                !solicitanteChatActivo || document.visibilityState !== 'visible'
                || !idTicketChat || !idEtapaChat || comprobandoChat
            ) return;
            comprobandoChat = true;
            try {
                var parametros = new URLSearchParams({
                    action: 'node_thread',
                    id_ticket: String(idTicketChat),
                    id_ticket_etapa: String(idEtapaChat),
                    mark_read: '1',
                    _: String(Date.now())
                });
                var respuesta = await fetch('mensajesApi.php?' + parametros.toString(), {
                    cache: 'no-store',
                    credentials: 'same-origin',
                    headers: {'Accept': 'application/json'}
                });
                var datos = await respuesta.json().catch(function () { return {}; });
                if (!respuesta.ok || datos.ok !== true) return;
                if (datos.revision && datos.revision !== revisionChat) {
                    revisionChat = datos.revision;
                    dibujarEventosChat(datos.hilo?.eventos || [], Boolean(forzarAbajo));
                }
            } finally {
                comprobandoChat = false;
            }
        }

        async function comprobarRevisionChat() {
            if (
                !solicitanteChatActivo || document.visibilityState !== 'visible'
                || !idTicketChat || !idEtapaChat || comprobandoRevisionChat
            ) return;
            comprobandoRevisionChat = true;
            try {
                var parametros = new URLSearchParams({
                    action: 'node_revision',
                    id_ticket: String(idTicketChat),
                    id_ticket_etapa: String(idEtapaChat),
                    _: String(Date.now())
                });
                var respuesta = await fetch('mensajesApi.php?' + parametros.toString(), {
                    cache: 'no-store',
                    credentials: 'same-origin',
                    headers: {'Accept': 'application/json'}
                });
                var datos = await respuesta.json().catch(function () { return {}; });
                if (!respuesta.ok || datos.ok !== true || !datos.revision) return;
                if (revisionChat === '') {
                    revisionChat = datos.revision;
                } else if (revisionChat !== datos.revision) {
                    await actualizarChatSolicitante(false);
                }
            } finally {
                comprobandoRevisionChat = false;
            }
        }

        function programarActualizacionChat() {
            window.clearTimeout(temporizadorChat);
            if (!solicitanteChatActivo) return;
            temporizadorChat = window.setTimeout(async function () {
                await comprobarRevisionChat();
                programarActualizacionChat();
            }, 2000);
        }

        function ajustarTextoChat() {
            if (!textoChat) {
                return;
            }

            textoChat.style.height = '38px';
            textoChat.style.height = Math.min(textoChat.scrollHeight, 112) + 'px';
        }

        function abrirChat() {
            if (!chatWidget || !panelChat) {
                return;
            }

            chatWidget.classList.add('is-open');
            panelChat.setAttribute('aria-hidden', 'false');
            solicitanteChatActivo = true;
            revisionChat = '';
            void actualizarChatSolicitante(true);
            programarActualizacionChat();
            botonAbrirChat?.setAttribute('aria-expanded', 'true');
            if (botonAbrirChat) {
                botonAbrirChat.hidden = true;
            }
            window.requestAnimationFrame(function () {
                if (lineaTiempoChat) {
                    lineaTiempoChat.scrollTop = lineaTiempoChat.scrollHeight;
                }
                (textoChat || botonCerrarChat)?.focus();
            });
        }

        function cerrarChat() {
            if (!chatWidget || !panelChat) {
                return;
            }

            chatWidget.classList.remove('is-open');
            panelChat.setAttribute('aria-hidden', 'true');
            solicitanteChatActivo = false;
            window.clearTimeout(temporizadorChat);
            temporizadorChat = null;
            botonAbrirChat?.setAttribute('aria-expanded', 'false');
            if (botonAbrirChat) {
                botonAbrirChat.hidden = false;
            }
            botonAbrirChat?.focus();
        }

        botonAbrirChat?.addEventListener('click', abrirChat);
        botonCerrarChat?.addEventListener('click', cerrarChat);
        textoChat?.addEventListener('input', ajustarTextoChat);
        textoChat?.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                formularioChat?.requestSubmit();
            }
        });
        entradaArchivosChat?.addEventListener('change', function () {
            if (!estadoArchivosChat) {
                return;
            }

            var nombres = Array.from(entradaArchivosChat.files || [])
                .map(function (archivo) { return archivo.name; });
            estadoArchivosChat.textContent = nombres.length
                ? nombres.length + ' archivo(s): ' + nombres.join(', ')
                : '';
        });
        var usuarioActualChat = {
            id: <?= (int) $idUsuario ?>,
            nombre: <?= json_encode($nombreUsuario, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
            rol: 'Solicitante'
        };

        function crearAutorActualChat() {
            var fila = document.createElement('span');
            fila.className = 'chat-author-row';

            var imagen = document.createElement('img');
            imagen.className = 'chat-profile-image';
            imagen.src = 'imagenPerfil.php?usuario=' + usuarioActualChat.id;
            imagen.alt = 'Foto de ' + usuarioActualChat.nombre;

            var copia = document.createElement('span');
            copia.className = 'chat-author-copy';

            var nombre = document.createElement('strong');
            nombre.textContent = usuarioActualChat.nombre || 'Solicitante';

            var rol = document.createElement('small');
            rol.textContent = usuarioActualChat.rol;

            copia.append(nombre, rol);
            fila.append(imagen, copia);
            return fila;
        }

        function agregarEnvioOptimistaChat(mensaje, archivos) {
            if (!lineaTiempoChat) {
                return [];
            }

            lineaTiempoChat.querySelector('.chat-empty')?.remove();
            var burbujas = [];
            var crearHora = function (articulo) {
                var hora = document.createElement('span');
                hora.className = 'chat-time';
                hora.textContent = 'Enviando…';
                articulo.appendChild(hora);
            };

            if (mensaje) {
                var burbujaMensaje = document.createElement('article');
                burbujaMensaje.className = 'chat-bubble mine is-pending';
                burbujaMensaje.dataset.mesaOwnMessage = '1';
                var autor = crearAutorActualChat();
                var texto = document.createElement('p');
                texto.className = 'chat-text';
                texto.textContent = mensaje;
                burbujaMensaje.append(autor, texto);
                crearHora(burbujaMensaje);
                lineaTiempoChat.appendChild(burbujaMensaje);
                burbujas.push(burbujaMensaje);
            }

            archivos.forEach(function (archivo) {
                var burbujaArchivo = document.createElement('article');
                burbujaArchivo.className = 'chat-bubble is-file mine is-pending';
                burbujaArchivo.dataset.mesaOwnMessage = '1';
                var autor = crearAutorActualChat();
                var tarjeta = document.createElement('span');
                tarjeta.className = 'chat-file-card';
                var icono = document.createElement('span');
                icono.className = 'chat-file-icon';
                icono.textContent = '📎';
                var copia = document.createElement('span');
                copia.className = 'chat-file-copy';
                var nombre = document.createElement('strong');
                nombre.textContent = archivo.name;
                var tipo = document.createElement('span');
                tipo.textContent = 'Archivo adjunto';
                copia.append(nombre, tipo);
                tarjeta.append(icono, copia);
                burbujaArchivo.append(autor, tarjeta);
                crearHora(burbujaArchivo);
                lineaTiempoChat.appendChild(burbujaArchivo);
                burbujas.push(burbujaArchivo);
            });

            lineaTiempoChat.scrollTop = lineaTiempoChat.scrollHeight;
            return burbujas;
        }

        formularioChat?.addEventListener('submit', async function (event) {
            event.preventDefault();

            if (formularioChat.dataset.sending === 'true') {
                return;
            }

            var mensaje = (textoChat?.value || '').trim();
            var archivos = Array.from(entradaArchivosChat?.files || []);

            if (!mensaje && archivos.length === 0) {
                textoChat?.focus();
                return;
            }

            var datos = new FormData(formularioChat);
            var burbujas = agregarEnvioOptimistaChat(mensaje, archivos);
            var botonEnviar = formularioChat.querySelector('.chat-send');
            formularioChat.dataset.sending = 'true';

            if (botonEnviar) {
                botonEnviar.disabled = true;
            }
            if (textoChat) {
                textoChat.value = '';
                ajustarTextoChat();
            }
            if (estadoArchivosChat) {
                estadoArchivosChat.textContent = 'Enviando…';
            }

            try {
                var respuesta = await fetch(formularioChat.action || window.location.href, {
                    method: 'POST',
                    body: datos,
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    credentials: 'same-origin'
                });
                var resultado = await respuesta.json().catch(function () {
                    return {};
                });

                if (!respuesta.ok || resultado.ok !== true) {
                    throw new Error(resultado.message || 'No fue posible enviar el mensaje.');
                }

                burbujas.forEach(function (burbuja) {
                    burbuja.classList.remove('is-pending');
                    var hora = burbuja.querySelector('.chat-time');
                    if (hora) {
                        hora.textContent = resultado.sent_at || 'Ahora';
                        var marca = document.createElement('span');
                        marca.className = 'read-mark';
                        marca.setAttribute('aria-label', 'Enviado');
                        marca.textContent = '✓';
                        hora.appendChild(marca);
                    }
                });
                formularioChat.reset();
                if (mensaje) {
                    var contadoresMensaje = modalCaso.querySelectorAll(
                        '[data-chat-active-message-count], [data-chat-option-message-count]'
                    );
                    contadoresMensaje.forEach(function (contador) {
                        var total = Number(contador.dataset.count || 0) + 1;
                        contador.dataset.count = String(total);
                        contador.textContent = total + ' '
                            + (total === 1 ? 'mensaje' : 'mensajes')
                            + (contador.hasAttribute('data-chat-active-message-count')
                                ? ' · Seleccionar otra etapa'
                                : '');
                    });
                }
                if (estadoArchivosChat) {
                    estadoArchivosChat.textContent = '';
                }
            } catch (error) {
                burbujas.forEach(function (burbuja) { burbuja.remove(); });
                if (textoChat && textoChat.value === '') {
                    textoChat.value = mensaje;
                    ajustarTextoChat();
                }
                if (estadoArchivosChat) {
                    estadoArchivosChat.textContent = error instanceof Error
                        ? error.message
                        : 'No fue posible enviar el mensaje.';
                }
            } finally {
                formularioChat.dataset.sending = 'false';
                if (botonEnviar) {
                    botonEnviar.disabled = false;
                }
                textoChat?.focus();
            }
        });

        if (chatWidget?.dataset.autoOpen === 'true') {
            abrirChat();
        }

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                if (chatWidget?.classList.contains('is-open')) {
                    event.preventDefault();
                    cerrarChat();
                }
            }
        });
    }());
</script>
<script src="assets/js/controlSesion.js" defer></script>
<script>
    (function () {
        'use strict';

        document.addEventListener('submit', function (event) {
            if (event.defaultPrevented) return;
            var form = event.target;
            if (!(form instanceof HTMLFormElement)) return;

            var accion = form.querySelector('input[name="accion"]');
            if (!accion || accion.value !== 'calificar_cerrar') return;

            if (form.dataset.processing === 'true') {
                event.preventDefault();
                return;
            }

            form.dataset.processing = 'true';
            var button = event.submitter instanceof HTMLButtonElement
                ? event.submitter
                : form.querySelector('button[type="submit"]');
            if (button) {
                button.disabled = true;
                button.setAttribute('aria-busy', 'true');
                button.textContent = 'Guardando calificación…';
            }
        });
    }());
</script>
</body>
</html>
