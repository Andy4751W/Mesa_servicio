<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

seguridadExigirRol([3]);

$idPaisOperacion = paisExigirContexto();
$idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
$nombreUsuario = trim((string) ($_SESSION['usuario'] ?? 'Solicitante'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/*
 * Cada formulario de creación tiene un identificador de un solo uso. PHP
 * conserva el bloqueo de la sesión durante el POST, por lo que dos clics
 * consecutivos no pueden crear dos casos con el mismo identificador.
 */
if (empty($_SESSION['solicitud_creacion_token'])) {
    $_SESSION['solicitud_creacion_token'] = bin2hex(random_bytes(32));
}

$tokenCreacionSolicitud = (string) $_SESSION['solicitud_creacion_token'];

function escaparPortalSolicitante($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function nombreCortoPortalSolicitante(string $nombreCompleto): string
{
    $nombreCompleto = trim((string) preg_replace(
        '/\s+/u',
        ' ',
        $nombreCompleto
    ));

    if ($nombreCompleto === '') {
        return 'Pendiente';
    }

    $partes = preg_split('/\s+/u', $nombreCompleto) ?: [];
    $cantidad = count($partes);

    if ($cantidad < 2) {
        $nombreCorto = $partes[0] ?? $nombreCompleto;
    } elseif ($cantidad === 2) {
        $nombreCorto = $partes[0] . ' ' . $partes[1];
    } else {
        /* En nombres corporativos de tres palabras el apellido suele ser la
           segunda; con cuatro o más, normalmente los dos últimos elementos
           corresponden a los apellidos. */
        $indicePrimerApellido = $cantidad >= 4
            ? $cantidad - 2
            : 1;
        $nombreCorto = $partes[0] . ' ' . $partes[$indicePrimerApellido];
    }

    if (function_exists('mb_convert_case')) {
        return mb_convert_case($nombreCorto, MB_CASE_TITLE, 'UTF-8');
    }

    return ucwords(strtolower($nombreCorto));
}

function rolChatPortalSolicitante(int $rolUsuario): string
{
    return (fn ($__mesaMatchValue31) => (($__mesaMatchValue31 === (1)) ? ('Administrador') : ((($__mesaMatchValue31 === (2)) ? ('Gestor') : ((($__mesaMatchValue31 === (3)) ? ('Solicitante') : ('Usuario')))))))($rolUsuario);
}

function fechaPortalSolicitante(?string $fecha): string
{
    if (!$fecha) {
        return 'Pendiente';
    }

    $marca = strtotime($fecha);

    return $marca ? date('d/m/Y H:i', $marca) : $fecha;
}

function textoEstadoPortalSolicitante(string $estado): string
{
    return (fn ($__mesaMatchValue32) => (($__mesaMatchValue32 === ('en_proceso')) ? ('En gestión') : ((($__mesaMatchValue32 === ('pendiente_calificacion')) ? ('Solución lista') : ((($__mesaMatchValue32 === ('cerrado') || $__mesaMatchValue32 === ('cerrada')) ? ('Cerrado') : ((($__mesaMatchValue32 === ('cancelado') || $__mesaMatchValue32 === ('cancelada')) ? ('Cancelado') : ((($__mesaMatchValue32 === ('abierto')) ? ('Abierto') : (ucfirst(str_replace('_', ' ', $estado)))))))))))))($estado);
}

function textoEstadoCasoSolicitante(string $estado): string
{
    return (fn ($__mesaMatchValue33) => (($__mesaMatchValue33 === ('pendiente')) ? ('Pendiente') : ((($__mesaMatchValue33 === ('en_proceso')) ? ('En gestión') : ((($__mesaMatchValue33 === ('en_espera_solicitante')) ? ('En espera') : ((($__mesaMatchValue33 === ('pausada')) ? ('Pausado por dependencia') : ((($__mesaMatchValue33 === ('listo_cierre')) ? ('Solución lista') : ((($__mesaMatchValue33 === ('completada')) ? ('Completado') : ((($__mesaMatchValue33 === ('bloqueada')) ? ('Aún no iniciado') : ((($__mesaMatchValue33 === ('cancelada')) ? ('Cancelado') : (ucfirst(str_replace('_', ' ', $estado)))))))))))))))))))($estado);
}

function redirigirPortalSolicitante(
    string $mensaje,
    string $vista = 'tickets',
    int $idTicket = 0,
    int $idChat = 0,
    string $fragmento = ''
): void {
    $parametros = ['vista' => $vista, 'msg' => $mensaje];

    if ($idTicket > 0) {
        $parametros['id_ticket'] = $idTicket;
    }

    if ($idChat > 0) {
        $parametros['id_chat'] = $idChat;
    }

    $ancla = preg_match('/^[A-Za-z0-9_-]+$/', $fragmento)
        ? '#' . $fragmento
        : '';
    header(
        'Location: panelSolicitante.php?'
            . http_build_query($parametros)
            . $ancla,
        true,
        303
    );
    header('Cache-Control: no-store');
    header('Content-Length: 0');

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    /*
     * Entrega la redirección antes de ejecutar los trabajos diferidos de
     * notificación. El caso ya quedó confirmado en la base de datos.
     */
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        while (ob_get_level() > 0) {
            @ob_end_clean();
        }
        flush();
    }

    exit;
}

function solicitudChatPortalEsAjax(): bool
{
    return strtolower((string) (
        $_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''
    )) === 'xmlhttprequest';
}

function responderChatPortalJson(
    bool $correcto,
    string $mensaje,
    int $codigoHttp = 200
): void {
    http_response_code($codigoHttp);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');
    $cuerpo = json_encode(
        [
            'ok' => $correcto,
            'message' => $mensaje,
            'sent_at' => date('H:i'),
        ],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    $cuerpo = is_string($cuerpo)
        ? $cuerpo
        : '{"ok":false,"message":"Respuesta no disponible."}';
    header('Content-Length: ' . strlen($cuerpo));

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }

    echo $cuerpo;

    if (ob_get_level() > 0) {
        @ob_flush();
    }
    flush();
    exit;
}

/**
 * Devuelve los casos del solicitante que requieren aprobar o devolver una
 * solución antes de permitir la creación de una nueva solicitud.
 *
 * @return list<int>
 */
function casosPendientesCalificacionSolicitante(
    mysqli $conn,
    int $idUsuario,
    int $idPaisOperacion
): array {
    $ids = [];
    $stmt = $conn->prepare(
        "SELECT DISTINCT t.id_ticket
         FROM tickets AS t
         INNER JOIN ticket_etapas AS te ON te.id_ticket = t.id_ticket
         WHERE t.id_usuario = ?
           AND t.id_pais_operacion = ?
           AND te.id_ticket_etapa_padre IS NULL
           AND te.estado = 'listo_cierre'
         ORDER BY t.id_ticket DESC"
    );
    $stmt->bind_param('ii', $idUsuario, $idPaisOperacion);
    $stmt->execute();
    $resultado = $stmt->get_result();

    while ($fila = $resultado->fetch_assoc()) {
        $idTicket = (int) ($fila['id_ticket'] ?? 0);

        if ($idTicket > 0) {
            $ids[] = $idTicket;
        }
    }

    $stmt->close();

    return $ids;
}

if (
    !flujoModuloInstalado($conn)
    || !flujoModuloAprobacionCasosInstalado($conn)
    || !flujoColumnaExiste($conn, 'servicios', 'tipo_solicitud')
    || !flujoColumnaExiste($conn, 'tickets', 'tipo_solicitud')
) {
    http_response_code(503);
    exit('El módulo de casos necesita las migraciones pendientes, incluida 002_notificaciones_email_tickets.sql. Comuníquese con el administrador.');
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    seguridadExigirOrigenPost();
    $token = $_POST['csrf_token'] ?? '';

    if (!is_string($token) || !hash_equals((string) $_SESSION['csrf_token'], $token)) {
        redirigirPortalSolicitante('solicitud_invalida', 'nueva');
    }

    $accion = (string) ($_POST['accion'] ?? '');

    if ($accion === 'crear_ticket') {
        $pendientesAntesDeCrear = casosPendientesCalificacionSolicitante(
            $conn,
            $idUsuario,
            $idPaisOperacion
        );

        if ($pendientesAntesDeCrear) {
            redirigirPortalSolicitante(
                'calificacion_pendiente_bloquea_creacion',
                'tickets',
                (int) $pendientesAntesDeCrear[0]
            );
        }
    }

    if ($accion === 'configurar_notificaciones') {
        $idTicket = filter_input(
            INPUT_POST,
            'id_ticket',
            FILTER_VALIDATE_INT
        ) ?: 0;
        $valorHabilitada = (string) ($_POST['habilitada'] ?? '');

        if (
            $idTicket < 1
            || !in_array($valorHabilitada, ['0', '1'], true)
        ) {
            redirigirPortalSolicitante(
                'solicitud_invalida',
                'tickets',
                $idTicket
            );
        }

        try {
            paisExigirTicket($conn, $idTicket);
            flujoConfigurarNotificacionesEmail(
                $conn,
                $idTicket,
                $idUsuario,
                3,
                $valorHabilitada === '1'
            );
            redirigirPortalSolicitante(
                $valorHabilitada === '1'
                    ? 'notificaciones_activadas'
                    : 'notificaciones_desactivadas',
                'tickets',
                $idTicket
            );
        } catch (Throwable $e) {
            error_log(
                'Error al configurar correos del solicitante: '
                . $e->getMessage()
            );
            redirigirPortalSolicitante(
                'error_notificaciones',
                'tickets',
                $idTicket
            );
        }
    }

    if ($accion === 'calificar_cerrar') {
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $calificacionArea = filter_input(INPUT_POST, 'calificacion_area', FILTER_VALIDATE_INT) ?: 0;
        $calificacionTiempo = filter_input(INPUT_POST, 'calificacion_tiempo', FILTER_VALIDATE_INT) ?: 0;
        $comentario = trim((string) ($_POST['comentario_calificacion'] ?? ''));

        if (
            $idTicket < 1
            || $idTicketEtapa < 1
            || $calificacionArea < 1
            || $calificacionArea > 5
            || $calificacionTiempo < 1
            || $calificacionTiempo > 5
            || strlen($comentario) > 1000
        ) {
            redirigirPortalSolicitante('calificacion_invalida', 'tickets', $idTicket);
        }

        try {
            paisExigirTicket($conn, $idTicket);

            if (!flujoPuedeVerTicket($conn, $idTicket, $idUsuario, 3)) {
                throw new RuntimeException('La solicitud no pertenece a su usuario.');
            }

            flujoCompletarEtapa(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                3,
                $calificacionArea,
                $calificacionTiempo,
                $comentario
            );

            $ticketActualizado = flujoObtenerTicket($conn, $idTicket);
            $mensaje = (string) ($ticketActualizado['estado_flujo'] ?? '') === 'cerrado'
                ? 'ticket_cerrado'
                : 'caso_calificado';
            redirigirPortalSolicitante($mensaje, 'tickets', $idTicket);
        } catch (Throwable $e) {
            error_log('Error al calificar el caso: ' . $e->getMessage());
            $_SESSION['error_portal_solicitante'] = $e instanceof RuntimeException
                ? $e->getMessage()
                : '';
            redirigirPortalSolicitante('error_calificacion', 'tickets', $idTicket);
        }
    }

    if ($accion === 'reabrir_caso') {
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $motivo = trim((string) ($_POST['motivo_reapertura'] ?? ''));

        if ($idTicket < 1 || $idTicketEtapa < 1 || $motivo === '' || strlen($motivo) > 1000) {
            redirigirPortalSolicitante('reapertura_invalida', 'tickets', $idTicket);
        }

        try {
            paisExigirTicket($conn, $idTicket);

            if (!flujoPuedeVerTicket($conn, $idTicket, $idUsuario, 3)) {
                throw new RuntimeException('La solicitud no pertenece a su usuario.');
            }

            flujoReabrirDerivacion(
                $conn,
                $idTicket,
                $idTicketEtapa,
                $idUsuario,
                3,
                $motivo
            );
            redirigirPortalSolicitante('caso_reabierto', 'tickets', $idTicket);
        } catch (Throwable $e) {
            error_log('Error al reabrir el caso: ' . $e->getMessage());
            $_SESSION['error_portal_solicitante'] = $e instanceof RuntimeException
                ? $e->getMessage()
                : '';
            redirigirPortalSolicitante('error_reapertura', 'tickets', $idTicket);
        }
    }

    if ($accion === 'enviar_mensaje') {
        $idTicket = filter_input(INPUT_POST, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
        $idTicketEtapa = filter_input(INPUT_POST, 'id_ticket_etapa', FILTER_VALIDATE_INT) ?: 0;
        $mensaje = trim((string) ($_POST['mensaje'] ?? ''));

        try {
            paisExigirTicket($conn, $idTicket);
            $ticket = flujoObtenerTicket($conn, $idTicket);

            if (
                !$ticket
                || !flujoPuedeVerTicket($conn, $idTicket, $idUsuario, 3)
            ) {
                throw new RuntimeException(
                    'La solicitud no pertenece a su usuario.'
                );
            }

            flujoEnviarConversacion(
                $conn,
                $ticket,
                $idTicketEtapa,
                $idUsuario,
                3,
                $mensaje,
                isset($_FILES['adjuntos'])
                    ? (array) $_FILES['adjuntos']
                    : []
            );

            if (solicitudChatPortalEsAjax()) {
                responderChatPortalJson(true, 'Mensaje enviado.');
            }

            redirigirPortalSolicitante(
                'mensaje_enviado',
                'tickets',
                $idTicket,
                $idTicketEtapa,
                'conversacion-solicitante'
            );
        } catch (Throwable $e) {
            error_log(
                'Error al enviar mensaje del solicitante: '
                . $e->getMessage()
            );

            if (solicitudChatPortalEsAjax()) {
                responderChatPortalJson(
                    false,
                    $e instanceof RuntimeException
                        ? $e->getMessage()
                        : 'No fue posible enviar el mensaje.',
                    422
                );
            }

            $_SESSION['error_portal_solicitante'] = $e instanceof RuntimeException
                ? $e->getMessage()
                : '';
            redirigirPortalSolicitante(
                'error_mensaje',
                'tickets',
                $idTicket,
                $idTicketEtapa,
                'conversacion-solicitante'
            );
        }
    }

    if ($accion !== 'crear_ticket') {
        redirigirPortalSolicitante('accion_no_permitida', 'tickets');
    }

    $tokenCreacionRecibido = (string) (
        $_POST['solicitud_creacion_token'] ?? ''
    );

    if (
        $tokenCreacionRecibido === ''
        || !hash_equals($tokenCreacionSolicitud, $tokenCreacionRecibido)
    ) {
        redirigirPortalSolicitante('solicitud_duplicada', 'tickets');
    }

    // Se consume antes de iniciar la operación para impedir reenvíos.
    unset($_SESSION['solicitud_creacion_token']);

    $idCatalogo = filter_input(INPUT_POST, 'id_catalogo', FILTER_VALIDATE_INT) ?: 0;
    $idProceso = filter_input(INPUT_POST, 'id_proceso', FILTER_VALIDATE_INT) ?: 0;
    $idServicio = filter_input(INPUT_POST, 'id_servicio', FILTER_VALIDATE_INT) ?: 0;
    $usaProceso = (string) ($_POST['usa_proceso'] ?? '') === '1';
    $titulo = trim((string) ($_POST['titulo'] ?? ''));
    $descripcion = trim((string) ($_POST['descripcion'] ?? ''));

    if (
        $idCatalogo < 1
        || $idProceso < 1
        || $idServicio < 1
        || $titulo === ''
        || $descripcion === ''
        || strlen($titulo) > 180
        || strlen($descripcion) > 15000
    ) {
        redirigirPortalSolicitante('datos_incompletos', 'nueva');
    }

    $stmtServicioCatalogo = $conn->prepare(
        "SELECT 1
         FROM servicios AS s
         INNER JOIN catalogos AS c
            ON c.id_catalogo = s.id_catalogo
           AND c.estado = 'activo'
         WHERE s.id_servicio = ?
           AND s.id_pais_operacion = ?
           AND s.estado = 'activo'
           AND c.id_catalogo = ?
           AND c.id_pais_operacion = ?
         LIMIT 1"
    );
    $stmtServicioCatalogo->bind_param(
        'iiii',
        $idServicio,
        $idPaisOperacion,
        $idCatalogo,
        $idPaisOperacion
    );
    $stmtServicioCatalogo->execute();
    $stmtServicioCatalogo->store_result();
    $servicioPerteneceCatalogo = $stmtServicioCatalogo->num_rows > 0;
    $stmtServicioCatalogo->close();

    if (!$servicioPerteneceCatalogo) {
        redirigirPortalSolicitante('servicio_no_disponible', 'nueva');
    }

    /*
     * El selector envía dos identificadores diferentes: el servicio que el
     * solicitante escogió y el proceso que debe construir sus etapas. Para
     * servicios directos ambos valores coinciden. Si existe un proceso, el
     * servicio debe ser exactamente su primera etapa activa.
     */
    $stmtProcesoActivo = $conn->prepare(
        "SELECT 1
         FROM procesos
         WHERE id_proceso = ?
           AND id_pais_operacion = ?
           AND estado = 'activo'
         LIMIT 1"
    );
    $stmtProcesoActivo->bind_param('ii', $idProceso, $idPaisOperacion);
    $stmtProcesoActivo->execute();
    $stmtProcesoActivo->store_result();
    $esProcesoActivo = $stmtProcesoActivo->num_rows === 1;
    $stmtProcesoActivo->close();

    $servicioPerteneceFlujo = false;

    if ($usaProceso && $esProcesoActivo) {
        $stmtServicioProceso = $conn->prepare(
            "SELECT 1
             FROM proceso_etapas AS pe
             WHERE pe.id_proceso = ?
               AND pe.id_servicio = ?
               AND pe.estado = 'activo'
               AND pe.orden = (
                    SELECT MIN(pe_inicio.orden)
                    FROM proceso_etapas AS pe_inicio
                    WHERE pe_inicio.id_proceso = pe.id_proceso
                      AND pe_inicio.estado = 'activo'
               )
             LIMIT 1"
        );
        $stmtServicioProceso->bind_param('ii', $idProceso, $idServicio);
        $stmtServicioProceso->execute();
        $stmtServicioProceso->store_result();
        $servicioPerteneceFlujo = $stmtServicioProceso->num_rows === 1;
        $stmtServicioProceso->close();
    } elseif (!$usaProceso && $idProceso === $idServicio) {
        $stmtServicioConProceso = $conn->prepare(
            "SELECT 1
             FROM proceso_etapas AS pe
             INNER JOIN procesos AS p
                ON p.id_proceso = pe.id_proceso
               AND p.estado = 'activo'
               AND p.id_pais_operacion = ?
             WHERE pe.id_servicio = ?
               AND pe.estado = 'activo'
             LIMIT 1"
        );
        $stmtServicioConProceso->bind_param('ii', $idPaisOperacion, $idServicio);
        $stmtServicioConProceso->execute();
        $stmtServicioConProceso->store_result();
        $servicioPerteneceFlujo = $stmtServicioConProceso->num_rows === 0;
        $stmtServicioConProceso->close();
    }

    if (!$servicioPerteneceFlujo) {
        redirigirPortalSolicitante('servicio_no_disponible', 'nueva');
    }

    try {
        $idTicketNuevo = flujoCrearTicket(
            $conn,
            $idProceso,
            $idUsuario,
            $titulo,
            $descripcion,
            'media'
        );
        $etapaInicial = flujoEtapaActual($conn, $idTicketNuevo);
        $mensaje = 'ticket_creado';

        if ($etapaInicial && isset($_FILES['adjuntos'])) {
            try {
                flujoGuardarAdjuntos(
                    $conn,
                    $idTicketNuevo,
                    (int) $etapaInicial['id_ticket_etapa'],
                    $idUsuario,
                    $_FILES['adjuntos']
                );
            } catch (Throwable $errorAdjunto) {
                error_log(
                    'Ticket creado sin uno o más adjuntos: '
                    . $errorAdjunto->getMessage()
                );
                $mensaje = 'ticket_creado_sin_adjuntos';
            }
        }

        redirigirPortalSolicitante($mensaje, 'tickets', $idTicketNuevo);
    } catch (Throwable $e) {
        error_log('Error al crear ticket del solicitante: ' . $e->getMessage());
        $_SESSION['error_portal_solicitante'] = $e instanceof RuntimeException
            ? $e->getMessage()
            : '';
        redirigirPortalSolicitante('error_operacion', 'nueva');
    }
}

$vista = (string) ($_GET['vista'] ?? 'tickets');

if (!in_array($vista, ['nueva', 'tickets'], true)) {
    $vista = 'tickets';
}

$busquedaCasos = trim((string) ($_GET['buscar'] ?? ''));

if (strlen($busquedaCasos) > 120) {
    $busquedaCasos = substr($busquedaCasos, 0, 120);
}

$estadoBusquedaCasos = (string) ($_GET['estado_busqueda'] ?? 'pendiente');
$estadoBusquedaCasos = (fn ($__mesaMatchValue34) => (($__mesaMatchValue34 === ('abierto') || $__mesaMatchValue34 === ('en_proceso')) ? ('activo') : ((($__mesaMatchValue34 === ('pendiente_calificacion')) ? ('pendiente') : ((($__mesaMatchValue34 === ('cancelado')) ? ('cerrado') : ($estadoBusquedaCasos)))))))($estadoBusquedaCasos);
$estadosBusquedaPermitidos = [
    'todos',
    'activo',
    'pendiente',
    'cerrado',
];

if (!in_array($estadoBusquedaCasos, $estadosBusquedaPermitidos, true)) {
    $estadoBusquedaCasos = 'pendiente';
}

$mensajes = [
    'ticket_creado' => ['ok', 'La solicitud fue creada y asignada correctamente.'],
    'ticket_creado_sin_adjuntos' => ['aviso', 'La solicitud fue creada, pero uno o más archivos no pudieron guardarse.'],
    'caso_calificado' => ['ok', 'La etapa fue aprobada y el mismo caso continúa con la siguiente etapa.'],
    'ticket_cerrado' => ['ok', 'La calificación fue registrada y el caso quedó cerrado completamente.'],
    'calificacion_invalida' => ['error', 'Califique de 1 a 5 la gestión y el tiempo de respuesta.'],
    'error_calificacion' => ['error', 'No fue posible guardar la calificación ni cerrar el caso.'],
    'caso_reabierto' => ['ok', 'La etapa del caso fue reabierta y regresó al gestor asignado.'],
    'mensaje_enviado' => ['ok', 'El mensaje fue enviado al gestor de la etapa.'],
    'error_mensaje' => ['error', 'No fue posible enviar el mensaje.'],
    'notificaciones_activadas' => ['ok', 'Recibirá correos por cada nueva acción pública del caso.'],
    'notificaciones_desactivadas' => ['aviso', 'Las notificaciones por correo de este caso fueron desactivadas.'],
    'error_notificaciones' => ['error', 'No fue posible cambiar las notificaciones por correo.'],
    'reapertura_invalida' => ['error', 'Explique por qué la solución no resolvió la solicitud.'],
    'error_reapertura' => ['error', 'No fue posible reabrir la etapa del caso.'],
    'datos_incompletos' => ['error', 'Complete todos los campos obligatorios.'],
    'servicio_no_disponible' => ['error', 'El servicio seleccionado ya no está disponible.'],
    'solicitud_duplicada' => ['aviso', 'La solicitud ya fue enviada. Se evitó crear un caso duplicado.'],
    'calificacion_pendiente_bloquea_creacion' => [
        'aviso',
        'Debe calificar o devolver las soluciones pendientes antes de crear un caso nuevo.'
    ],
    'solicitud_invalida' => ['error', 'La solicitud no es válida. Actualice la página.'],
    'accion_no_permitida' => ['error', 'Su perfil solo puede crear solicitudes, consultar su estado, conversar con el gestor del flujo y calificar cuando corresponda.'],
    'error_operacion' => ['error', 'No fue posible crear la solicitud. Inténtelo nuevamente.'],
];
$mensajeActual = (string) ($_GET['msg'] ?? '');
$detalleError = trim((string) ($_SESSION['error_portal_solicitante'] ?? ''));
unset($_SESSION['error_portal_solicitante']);

$catalogosSolicitud = [];
$resultadoCatalogosSolicitud = $conn->query(
    "SELECT id_catalogo, nombre, descripcion, imagen, orden
     FROM catalogos
     WHERE id_pais_operacion = {$idPaisOperacion}
       AND estado = 'activo'
     ORDER BY orden ASC, nombre ASC, id_catalogo ASC"
);

while ($catalogoSolicitud = $resultadoCatalogosSolicitud->fetch_assoc()) {
    $catalogosSolicitud[] = $catalogoSolicitud;
}

$servicios = flujoServiciosDisponibles($conn);
$tickets = flujoTicketsUsuario($conn, $idUsuario, 3);
$proyeccionesTickets = [];
foreach ($tickets as $ticketProyeccion) {
    $idTicketProyeccion = (int) ($ticketProyeccion['id_ticket'] ?? 0);
    if ($idTicketProyeccion > 0) {
        $proyeccionesTickets[$idTicketProyeccion] =
            flujoProyeccionFinalizacionTicket($conn, $idTicketProyeccion);
    }
}
$ticketsConSolucionLista = [];
$idsPendientesCalificacion = casosPendientesCalificacionSolicitante(
    $conn,
    $idUsuario,
    $idPaisOperacion
);

foreach ($idsPendientesCalificacion as $idPendienteCalificacion) {
    $ticketsConSolucionLista[$idPendienteCalificacion] = true;
}

$cantidadPendientesCalificacion = count($idsPendientesCalificacion);
$primerTicketPendienteCalificacion = $idsPendientesCalificacion[0] ?? 0;
$idTicketSeleccionado = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
$idChatSeleccionado = filter_input(INPUT_GET, 'id_chat', FILTER_VALIDATE_INT) ?: 0;
$ticketSeleccionado = null;
$etapasTicket = [];
$etapaPendienteCalificacion = null;
$siguienteEtapaPendienteCalificacion = null;
$conversacionesSolicitante = [];
$conversacionSolicitanteActual = null;
$comunicacionesSolicitante = [];
$adjuntosSolicitante = [];
$eventosConversacionSolicitante = [];
$puedeEscribirSolicitante = false;
$notificacionesEmailSolicitante = true;

if ($idTicketSeleccionado > 0) {
    paisExigirTicket($conn, $idTicketSeleccionado);

    if (!flujoPuedeVerTicket($conn, $idTicketSeleccionado, $idUsuario, 3)) {
        http_response_code(403);
        exit('La solicitud no existe o no pertenece a su usuario.');
    }

    $ticketSeleccionado = flujoObtenerTicket($conn, $idTicketSeleccionado);
    $notificacionesEmailSolicitante =
        flujoNotificacionesEmailHabilitadas(
            $conn,
            $idTicketSeleccionado,
            $idUsuario
        );
    $todasLasEtapasTicket = flujoObtenerEtapasTicket(
        $conn,
        $idTicketSeleccionado
    );
    $etapasTicket = array_values(array_filter(
        $todasLasEtapasTicket,
        static fn (array $etapa): bool =>
            (int) ($etapa['id_ticket_etapa_padre'] ?? 0) === 0
    ));

    foreach ($etapasTicket as $etapaTicket) {
        $idCreadorCaso = (int) (
            $etapaTicket['creado_por']
            ?? $ticketSeleccionado['id_usuario']
            ?? 0
        );

        if (
            (string) ($etapaTicket['estado'] ?? '') === 'listo_cierre'
            && (int) ($etapaTicket['id_ticket_etapa_padre'] ?? 0) === 0
            && $idCreadorCaso === $idUsuario
        ) {
            $etapaPendienteCalificacion = $etapaTicket;
            break;
        }
    }

    if ($etapaPendienteCalificacion) {
        $ordenEtapaPendiente = (int) ($etapaPendienteCalificacion['orden'] ?? 0);

        foreach ($etapasTicket as $posibleSiguienteEtapa) {
            if (
                (int) ($posibleSiguienteEtapa['orden'] ?? 0) > $ordenEtapaPendiente
                && (string) ($posibleSiguienteEtapa['estado'] ?? '') === 'bloqueada'
            ) {
                $siguienteEtapaPendienteCalificacion = $posibleSiguienteEtapa;
                break;
            }
        }
    }

    $conversacionesSolicitante = array_values(array_filter(
        flujoConversacionesDisponibles(
            $conn,
            $idTicketSeleccionado,
            $idUsuario,
            3
        ),
        static fn (array $conversacion): bool =>
            (string) ($conversacion['tipo_conversacion'] ?? '') === 'flujo'
    ));

    if ($idChatSeleccionado > 0) {
        foreach ($conversacionesSolicitante as $conversacionSolicitante) {
            if (
                (int) $conversacionSolicitante['id_ticket_etapa']
                === $idChatSeleccionado
            ) {
                $conversacionSolicitanteActual = $conversacionSolicitante;
                break;
            }
        }
    }

    if (!$conversacionSolicitanteActual) {
        foreach ($conversacionesSolicitante as $conversacionSolicitante) {
            if (in_array(
                (string) ($conversacionSolicitante['estado'] ?? ''),
                ['pendiente', 'en_proceso', 'en_espera_solicitante', 'pausada'],
                true
            )) {
                $conversacionSolicitanteActual = $conversacionSolicitante;
                break;
            }
        }
    }

    if (!$conversacionSolicitanteActual && $conversacionesSolicitante) {
        $conversacionSolicitanteActual = $conversacionesSolicitante[
            count($conversacionesSolicitante) - 1
        ];
    }

    if ($conversacionSolicitanteActual) {
        $idConversacionSolicitante = (int) (
            $conversacionSolicitanteActual['id_ticket_etapa'] ?? 0
        );

        if (!flujoPuedeVerConversacionNodo(
            $conn,
            $idTicketSeleccionado,
            $idConversacionSolicitante,
            $idUsuario,
            3
        )) {
            http_response_code(403);
            exit('No tiene acceso a esta conversación.');
        }

        $comunicacionesSolicitante = flujoComunicacionesNodo(
            $conn,
            $idTicketSeleccionado,
            $idConversacionSolicitante
        );
        $adjuntosSolicitante = flujoAdjuntosNodo(
            $conn,
            $idTicketSeleccionado,
            $idConversacionSolicitante
        );
        $eventosConversacionSolicitante = flujoLineaTiempoConversacion(
            $comunicacionesSolicitante,
            $adjuntosSolicitante
        );
        $puedeEscribirSolicitante = flujoPuedeEscribirNodo(
            $conn,
            $ticketSeleccionado,
            $idConversacionSolicitante,
            $idUsuario,
            3
        );
    }

    flujoMarcarNotificacionesContenidoVisto(
        $conn,
        $idUsuario,
        $idTicketSeleccionado,
        false
    );
}

$resumen = ['total' => count($tickets), 'activos' => 0, 'listos' => 0, 'cerrados' => 0];

foreach ($tickets as $ticketResumen) {
    $estado = strtolower(trim((string) ($ticketResumen['estado_flujo'] ?? 'en_proceso')));
    $idTicketResumen = (int) ($ticketResumen['id_ticket'] ?? 0);

    if (in_array($estado, ['cerrado', 'cerrada', 'cancelado', 'cancelada'], true)) {
        $resumen['cerrados']++;
    } elseif (isset($ticketsConSolucionLista[$idTicketResumen])) {
        $resumen['listos']++;
    } else {
        $resumen['activos']++;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Portal del solicitante | Mesa de Servicio</title>
    <style>
        :root{--primary:#0f6fec;--primary-dark:#0b4fae;--navy:#102a43;--text:#304b63;--muted:#526d82;--border:#dce6f0;--surface:#fff;--soft:#eef5ff;--bg:#f3f6fb;--ok:#087443;--warn:#9a6500;--danger:#b42318}
        *{box-sizing:border-box}body{margin:0;color:var(--text);background:linear-gradient(135deg,#f7fafe,#edf3f9);font:13px/1.45 Inter,"Segoe UI",Arial,sans-serif}.shell{width:min(1400px,calc(100% - 24px));margin:auto;padding:12px 0 30px;transition:width .25s ease}.topbar,.card,.stat,.alert{border:1px solid var(--border);background:var(--surface);box-shadow:0 8px 24px rgba(16,42,67,.06)}.topbar{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:10px 12px;border-radius:14px}.brand{display:flex;align-items:center;gap:10px}.mark{width:38px;height:38px;display:grid;place-items:center;border-radius:11px;color:#fff;background:linear-gradient(145deg,var(--primary),var(--primary-dark));font-weight:900}.brand strong{display:block;color:var(--navy);font-size:14px}.brand small{color:var(--muted);font-size:10px}.logout,.btn,.tab{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;font-weight:800}.logout{min-height:34px;padding:7px 11px;border:1px solid #eed9d9;border-radius:9px;color:#a73535;background:#fff8f8}.tabs{display:flex;gap:7px;margin-top:10px;padding:7px;border:1px solid var(--border);border-radius:12px;background:#fff}.tab{min-height:36px;padding:8px 13px;border-radius:8px;color:#486985}.tab.active,.tab:hover{color:#fff;background:var(--primary)}.grid-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:10px 0}.stat{padding:12px;border-radius:11px}.stat span{display:block;color:var(--muted);font-size:10px}.stat strong{display:block;margin-top:2px;color:var(--navy);font-size:22px}.card{margin-top:10px;padding:17px;border-radius:14px}.card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:15px}.card h1,.card h2{margin:0;color:var(--navy)}.card h1{font-size:22px}.card h2{font-size:17px}.muted{margin:4px 0 0;color:var(--muted)}.alert{margin-top:10px;padding:10px 12px;border-radius:10px}.alert.ok{border-color:#bfe9d2;color:var(--ok);background:#effbf4}.alert.aviso{border-color:#f1db9b;color:var(--warn);background:#fff9e9}.alert.error{border-color:#f0c4c1;color:var(--danger);background:#fff4f3}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.field{display:grid;gap:6px}.field.full{grid-column:1/-1}.field label{color:var(--navy);font-size:11px;font-weight:850}.field input,.field select,.field textarea{width:100%;padding:10px 11px;border:1px solid #cfddea;border-radius:9px;color:var(--text);background:#fff;outline:none}.field textarea{min-height:130px;resize:vertical}.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--primary);box-shadow:0 0 0 3px color-mix(in srgb,var(--primary) 13%,transparent)}.help{color:var(--muted);font-size:10px}.actions{display:flex;justify-content:flex-end;margin-top:14px}.btn{min-height:38px;padding:9px 15px;border:0;border-radius:9px;cursor:pointer}.btn.primary{color:#fff;background:var(--primary)}.table-wrap{overflow:auto;border:1px solid var(--border);border-radius:11px}table{width:100%;border-collapse:collapse;min-width:760px}th,td{padding:11px 12px;border-bottom:1px solid #edf2f7;text-align:left;vertical-align:middle}th{color:#52708c;background:#f7faff;font-size:10px;text-transform:uppercase;letter-spacing:.05em}td strong{color:var(--navy)}.status{display:inline-flex;padding:4px 8px;border-radius:999px;color:#255a83;background:#eaf4ff;font-size:10px;font-weight:850}.status.cerrado,.status.completada{color:#087443;background:#eaf8f1}.status.cancelado,.status.cancelada{color:#a73535;background:#fff0f0}.view-link{display:inline-flex;padding:6px 9px;border:1px solid #cfe0ef;border-radius:7px;color:var(--primary);text-decoration:none;font-size:10px;font-weight:850}.empty{padding:25px;color:var(--muted);text-align:center}.detail-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:13px}.detail-item{padding:10px;border:1px solid var(--border);border-radius:9px;background:#f9fbfd}.detail-item span{display:block;color:var(--muted);font-size:9px}.detail-item strong{display:block;margin-top:3px;color:var(--navy);font-size:12px}.case-list{display:grid;gap:7px;margin-top:14px}.case{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,1fr) auto;gap:10px;align-items:center;padding:11px;border:1px solid var(--border);border-radius:10px;background:#fff}.case strong,.case span{display:block}.case small{color:var(--muted)}.case-manager{width:max-content;max-width:100%;display:grid;gap:1px;padding:6px 10px;border:1px solid color-mix(in srgb,var(--primary) 26%,var(--border));border-radius:9px;background:color-mix(in srgb,var(--primary) 7%,var(--surface))}.case-manager span{color:var(--muted);font-size:9px;font-weight:800}.case-manager strong{overflow:hidden;color:var(--navy);font-size:12px;text-overflow:ellipsis;white-space:nowrap}.case-manager-placeholder{min-height:1px}@media(max-width:760px){.topbar,.card-head{align-items:stretch;flex-direction:column}.tabs{overflow:auto}.grid-stats,.detail-grid{grid-template-columns:1fr 1fr}.form-grid{grid-template-columns:1fr}.field.full{grid-column:auto}.case{grid-template-columns:1fr}.case-manager{width:100%}.case-manager-placeholder{display:none}.shell{width:calc(100% - 12px)}}
    </style>
    <style>
        .rating-card{margin-top:15px;padding:15px;border:1px solid color-mix(in srgb,var(--primary) 28%,#dce6f0);border-radius:12px;background:color-mix(in srgb,var(--primary) 5%,#fff)}
        .rating-card h3{margin:0;color:var(--navy);font-size:16px}.rating-card>p{margin:5px 0 12px;color:var(--muted)}.solution-context{display:grid;grid-template-columns:minmax(180px,.85fr) minmax(260px,1.4fr);gap:9px;margin:12px 0}.solution-context-item{padding:11px 12px;border:1px solid color-mix(in srgb,var(--primary) 24%,var(--border));border-radius:10px;background:color-mix(in srgb,var(--primary) 5%,var(--surface))}.solution-context-item span{display:block;color:var(--muted);font-size:9px;font-weight:850;letter-spacing:.05em;text-transform:uppercase}.solution-context-item strong{display:block;margin-top:4px;color:var(--navy);font-size:12px}.solution-context-item p{margin:4px 0 0;color:var(--text);font-size:11px;line-height:1.45}.solution-context-item.outcome{border-left:4px solid var(--primary)}.solution-context-item.outcome.definitive{border-left-color:var(--warn)}.definitive-close-alert{margin:12px 0;padding:14px 15px;border:2px solid color-mix(in srgb,var(--warn) 65%,var(--border));border-radius:11px;color:var(--text);background:color-mix(in srgb,var(--warn) 10%,var(--surface))}.definitive-close-alert strong{display:block;margin-bottom:4px;color:var(--navy);font-size:14px}.definitive-close-alert p{margin:0;font-size:13px;line-height:1.5}.solution-box{margin-bottom:12px;padding:11px;border:1px solid var(--border);border-radius:9px;background:var(--surface)}.solution-box span{display:block;color:var(--muted);font-size:9px;text-transform:uppercase}.solution-box strong{display:block;margin-top:3px;color:var(--navy)}.solution-box p{margin:7px 0 0;white-space:pre-line}.rating-grid{display:grid;grid-template-columns:1fr 1fr;gap:11px}.rating-grid .field:last-child{grid-column:1/-1}.rating-grid textarea{min-height:82px}.reopen-form{margin-top:13px;padding-top:13px;border-top:1px solid var(--border)}.reopen-form .reopen-title{display:block;color:var(--danger);font-weight:850}.reopen-form p{margin:3px 0 9px;color:var(--muted)}.btn.reopen{border:1px solid #efc4c1;color:var(--danger);background:#fff4f3}@media(max-width:620px){.solution-context,.rating-grid{grid-template-columns:1fr}.rating-grid .field:last-child{grid-column:auto}}
        .solution-context-item.outcome{--context-accent:var(--primary);position:relative;padding-right:48px;border-color:color-mix(in srgb,var(--context-accent) 42%,var(--border));border-left:5px solid var(--context-accent);background:color-mix(in srgb,var(--context-accent) 10%,var(--surface));box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--context-accent) 7%,transparent)}
        .solution-context-item.outcome::after{content:"";position:absolute;top:13px;right:14px;width:18px;height:18px;border:5px solid color-mix(in srgb,var(--context-accent) 22%,var(--surface));border-radius:50%;background:var(--context-accent);box-shadow:0 0 0 1px color-mix(in srgb,var(--context-accent) 72%,var(--border))}
        .solution-context-item.outcome.continue{--context-accent:var(--primary)}
        .solution-context-item.outcome.final{--context-accent:var(--ok)}
        .solution-context-item.outcome.definitive{--context-accent:var(--warn)}
        .solution-context-item.outcome>span,.solution-context-item.outcome>strong{color:var(--context-accent)}
        .rating-card.continue{--rating-accent:var(--primary)}
        .rating-card.final{--rating-accent:var(--ok)}
        .rating-card.definitive{--rating-accent:var(--warn)}
        .rating-card.continue,.rating-card.final,.rating-card.definitive{border-color:color-mix(in srgb,var(--rating-accent) 46%,var(--border));background:color-mix(in srgb,var(--rating-accent) 5%,var(--surface))}
        .rating-card.continue>h3,.rating-card.final>h3,.rating-card.definitive>h3{color:var(--rating-accent)}
    </style>
    <style>
        .catalog-picker{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:9px}.catalog-choice{position:relative;display:block;min-width:0;cursor:pointer}.catalog-choice input{position:absolute;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none}.catalog-choice-body{display:flex;min-height:86px;align-items:flex-start;gap:10px;padding:10px;border:1px solid #cfdeeb;border-radius:11px;background:#fff;box-shadow:0 5px 14px rgba(16,42,67,.04);transition:border-color .16s ease,box-shadow .16s ease,transform .16s ease}.catalog-choice:hover .catalog-choice-body{transform:translateY(-1px);border-color:color-mix(in srgb,var(--primary) 45%,#cfdeeb);box-shadow:0 8px 18px rgba(16,42,67,.08)}.catalog-choice input:focus-visible+.catalog-choice-body{outline:3px solid color-mix(in srgb,var(--primary) 20%,transparent);outline-offset:2px}.catalog-choice input:checked+.catalog-choice-body{border-color:var(--primary);background:color-mix(in srgb,var(--primary) 6%,#fff);box-shadow:0 0 0 2px color-mix(in srgb,var(--primary) 13%,transparent)}.catalog-choice img{width:40px;height:40px;display:block;flex:0 0 auto;border:1px solid #e0e9f2;border-radius:10px;object-fit:cover;background:#f6f9fc}.catalog-choice-text{min-width:0;display:block;padding-top:1px}.catalog-choice strong{display:block;overflow:hidden;color:var(--navy);font-size:12px;text-overflow:ellipsis;white-space:nowrap}.catalog-choice small{display:-webkit-box;margin-top:4px;overflow:hidden;color:var(--muted);font-size:9px;line-height:1.35;-webkit-box-orient:vertical;-webkit-line-clamp:3}.service-feedback{display:block;min-height:15px;margin-top:1px;color:var(--muted);font-size:10px}.service-feedback.warning{color:var(--warn)}@media(max-width:620px){.catalog-picker{grid-template-columns:1fr 1fr}.catalog-choice-body{min-height:82px;padding:8px}.catalog-choice img{width:34px;height:34px}}@media(max-width:410px){.catalog-picker{grid-template-columns:1fr}}
    </style>
    <style>
        .catalog-picker{grid-template-columns:repeat(auto-fit,minmax(175px,1fr));gap:10px}
        .catalog-choice-body{min-height:170px;display:grid;grid-template-rows:auto 98px minmax(26px,auto);gap:7px;align-items:start;padding:9px}
        .catalog-choice-title{display:block;min-width:0}
        .catalog-choice strong{font-size:13px;line-height:1.3}
        .catalog-choice-media{width:100%;height:98px;display:block;overflow:hidden;border:1px solid #e0e9f2;border-radius:9px;background:#f6f9fc}
        .catalog-choice .catalog-choice-media img{width:100%;height:100%;margin:0;border:0;border-radius:0;object-fit:cover;object-position:center;background:transparent}
        .catalog-choice small{margin:0;-webkit-line-clamp:2}
        @media(max-width:620px){
            .catalog-picker{grid-template-columns:1fr 1fr}
            .catalog-choice-body{min-height:158px;grid-template-rows:auto 88px minmax(26px,auto);padding:8px}
            .catalog-choice-media{height:88px}
            .catalog-choice .catalog-choice-media img{width:100%;height:100%}
        }
        @media(max-width:430px){.catalog-picker{grid-template-columns:1fr}}
    </style>
    <style>
        .service-selection-layout{
            grid-column:1/-1;
            width:100%;
            min-width:0;
            display:grid;
            grid-template-columns:var(--service-selector-width,260px) minmax(0,1fr);
            gap:var(--service-column-gap,10px);
            align-items:start;
        }

        .service-selection-layout>.field{
            width:100%;
            min-width:0;
            display:flex;
            flex-direction:column;
            align-content:start;
        }

        .service-combobox{
            position:relative;
            width:100%;
            min-width:0;
        }

        .service-combobox-control{
            position:relative;
            display:flex;
            align-items:center;
        }

        .field .service-combobox-input{
            min-height:40px;
            padding-right:42px;
        }

        .service-combobox-toggle{
            position:absolute;
            top:5px;
            right:5px;
            width:30px;
            height:30px;
            display:grid;
            place-items:center;
            padding:0;
            border:0;
            border-radius:7px;
            color:var(--primary);
            background:color-mix(in srgb,var(--primary) 9%,var(--surface));
            cursor:pointer;
        }

        .service-combobox-toggle::before{
            content:"⌄";
            font-size:15px;
            font-weight:900;
            line-height:1;
            transition:transform .16s ease;
        }

        .service-combobox.is-open .service-combobox-toggle::before{
            transform:rotate(180deg);
        }

        .service-combobox-toggle:disabled{
            color:var(--muted);
            opacity:.55;
            cursor:not-allowed;
        }

        .service-native-select{
            position:absolute!important;
            width:1px!important;
            height:1px!important;
            margin:0!important;
            padding:0!important;
            overflow:hidden!important;
            clip:rect(0 0 0 0)!important;
            clip-path:inset(50%)!important;
            opacity:0!important;
            pointer-events:none!important;
        }

        .service-combobox-list{
            position:absolute;
            z-index:90;
            top:calc(100% + 5px);
            left:0;
            right:auto;
            width:min(
                var(--service-dropdown-width,720px),
                calc(100vw - var(--service-dropdown-left-space,24px) - 16px)
            );
            display:none;
            max-height:var(--service-dropdown-max-height,min(58vh,520px));
            padding:7px;
            overflow-y:auto;
            overflow-x:hidden;
            overscroll-behavior:contain;
            border:1px solid color-mix(in srgb,var(--primary) 34%,var(--border));
            border-radius:10px;
            background:var(--surface);
            box-shadow:0 14px 32px rgba(16,42,67,.18);
            scrollbar-width:thin;
            scrollbar-color:color-mix(in srgb,var(--primary) 45%,var(--border)) var(--surface);
        }

        .service-combobox.is-open .service-combobox-list{
            display:grid;
            grid-template-columns:minmax(0,1fr);
            align-content:start;
            gap:3px;
        }

        .service-combobox.opens-up .service-combobox-list{
            top:auto;
            bottom:calc(100% + 5px);
        }

        .service-combobox-option{
            width:100%;
            min-height:34px;
            padding:7px 10px;
            border:1px solid transparent;
            border-radius:7px;
            color:var(--text);
            background:transparent;
            font:inherit;
            font-size:11px;
            font-weight:750;
            line-height:1.35;
            text-align:left;
            overflow-wrap:anywhere;
            cursor:pointer;
        }

        .service-combobox-option:hover,
        .service-combobox-option.is-active{
            border-color:color-mix(in srgb,var(--primary) 25%,var(--border));
            color:var(--navy);
            background:color-mix(in srgb,var(--primary) 9%,var(--surface));
        }

        .service-combobox-option[aria-selected="true"]{
            color:var(--primary-dark);
            background:color-mix(in srgb,var(--primary) 13%,var(--surface));
        }

        .service-combobox-empty{
            grid-column:1/-1;
            margin:0;
            padding:11px;
            color:var(--muted);
            font-size:10px;
            line-height:1.45;
            text-align:left;
        }

        .service-summary{
            width:var(--service-summary-width,100%);
            min-width:min(100%,600px);
            max-width:100%;
            min-height:72px;
            margin-top:22px;
            justify-self:stretch;
            overflow:hidden;
            border:1px solid color-mix(in srgb,var(--primary) 24%,var(--border));
            border-radius:12px;
            background:color-mix(in srgb,var(--primary) 4%,var(--surface));
            box-shadow:0 8px 20px rgba(16,42,67,.05);
            transition:width .2s ease,height .2s ease;
        }

        .service-summary.empty{
            width:100%;
            min-width:0;
            min-height:52px;
            max-height:52px;
            display:flex;
            align-items:center;
            justify-content:center;
            border-style:dashed;
            background:color-mix(in srgb,var(--primary) 2%,var(--surface));
        }

.service-summary-copy{
    min-width:0;
    min-height:0;
    display:grid;
    grid-template-rows:auto minmax(0,auto) auto;
    align-content:start;
    gap:7px;
    padding:12px 14px;
    overflow:hidden;
}

.service-summary strong{
    display:block;
    margin:0;
    color:var(--navy);
    font-size:13px;
    line-height:1.3;
    flex:0 0 auto;
}

.service-summary p{
    min-height:0;
    max-height:210px;
    margin:0;
    padding:0 7px 0 0;
    overflow:hidden;
    color:var(--text);
    font-size:12px;  /* Cambiado de 10px a 12px */
    line-height:1.55;
    white-space:pre-line;
    overflow-wrap:anywhere;
    scrollbar-width:thin;
    scrollbar-color:color-mix(in srgb,var(--primary) 34%,var(--border)) color-mix(in srgb,var(--primary) 5%,var(--surface));
}

.service-summary p.is-scrollable{
    overflow-y:auto;
    overscroll-behavior:contain;
}

.service-summary p::-webkit-scrollbar{
    width:6px;
}

.service-summary p::-webkit-scrollbar-track{
    border-radius:999px;
    background:color-mix(in srgb,var(--primary) 5%,var(--surface));
}

.service-summary p::-webkit-scrollbar-thumb{
    border-radius:999px;
    background:color-mix(in srgb,var(--primary) 34%,var(--border));
}

.service-summary.empty .service-summary-copy{
    display:flex;
    align-items:center;
    justify-content:center;
    padding:12px 14px;
    overflow:hidden;
}

.service-summary.empty strong{
    margin:0;
    max-width:100%;
    color:var(--muted);
    font-size:11px;
    font-weight:700;
    line-height:1.5;
    text-align:center;
}

.service-summary [hidden]{
    display:none!important;
}

.service-tags{
    display:flex;
    flex-wrap:wrap;
    align-items:center;
    gap:6px;
    min-height:24px;
    padding-top:2px;
    overflow:visible;
}

.service-tag{
    display:inline-flex;
    align-items:center;
    gap:4px;
    min-height:22px;
    padding:3px 8px;
    border:1px solid #cfe0ef;
    border-radius:999px;
    color:#255a83;
    background:#fff;
    font-size:9px;
    font-weight:850;
}

.service-tag.type{
    color:#6542a6;
    border-color:#ddd0f5;
    background:#f7f2ff;
}

.service-tag.priority{
    color:#9a4c00;
    border-color:#f0d5ae;
    background:#fff8eb;
}

.service-tag.urgency{
    color:#a73535;
    border-color:#efc8c8;
    background:#fff4f4;
}

.service-tag.impact{
    color:#087443;
    border-color:#bfe4d0;
    background:#effaf4;
}

.request-support-grid{
    grid-column:1/-1;
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:13px;
    align-items:start;
}

.request-text-column{
    min-width:0;
    display:grid;
    gap:13px;
    align-content:start;
}

.description-field textarea{
    height:64px;
    min-height:64px;
    max-height:360px;
    resize:none;
    overflow-y:hidden;
    line-height:1.45;
}

.description-field textarea.is-scrollable{
    overflow-y:auto;
}

.file-field{
    min-width:0;
    margin-top:0;
}

.file-input{
    position:absolute!important;
    width:1px!important;
    height:1px!important;
    padding:0!important;
    overflow:hidden;
    clip:rect(0,0,0,0);
    white-space:nowrap;
    border:0!important;
}

.file-dropzone{
    min-height:64px;
    display:flex;
    align-items:center;
    gap:10px;
    padding:9px 11px;
    border:1px dashed #a9c6e2;
    border-radius:10px;
    color:#456985;
    background:#f7faff;
    text-align:left;
    cursor:pointer;
    transition:.18s ease;
}

.file-dropzone:hover,.file-dropzone.dragover{
    border-color:var(--primary);
    background:#edf5ff;
    box-shadow:0 0 0 3px rgba(15,111,236,.07);
}

.upload-icon{
    width:34px;
    height:34px;
    display:grid;
    flex:0 0 auto;
    place-items:center;
    border:1px solid #d8e7f5;
    border-radius:9px;
    color:var(--primary);
    background:#fff;
}

.upload-icon svg{
    width:17px;
    height:17px;
    fill:none;
    stroke:currentColor;
    stroke-width:1.9;
    stroke-linecap:round;
    stroke-linejoin:round;
}

.upload-copy{
    min-width:0;
    flex:1;
}

.upload-copy strong{
    display:block;
    color:var(--navy);
    font-size:11px;
}

.upload-copy span{
    display:block;
    margin-top:1px;
    color:var(--muted);
    font-size:9px;
}

.upload-action{
    display:inline-flex;
    min-height:31px;
    align-items:center;
    justify-content:center;
    padding:7px 11px;
    border-radius:8px;
    color:#fff;
    background:var(--primary);
    font-size:9px;
    font-weight:850;
    white-space:nowrap;
    box-shadow:0 4px 10px rgba(15,111,236,.16);
}

.file-dropzone:hover .upload-action,.file-dropzone.dragover .upload-action{
    background:var(--primary-dark);
}

.file-list{
    display:grid;
    gap:6px;
    margin-top:7px;
}

.file-list[hidden]{
    display:none;
}

.file-item{
    display:grid;
    grid-template-columns:minmax(0,1fr) auto;
    gap:10px;
    align-items:center;
    padding:7px 9px;
    border:1px solid #dbe6f0;
    border-radius:9px;
    background:#fff;
}

.file-item strong{
    display:block;
    overflow:hidden;
    color:var(--navy);
    font-size:10px;
    text-overflow:ellipsis;
    white-space:nowrap;
}

.file-item small{
    display:block;
    margin-top:1px;
    color:var(--muted);
    font-size:9px;
}

.file-remove{
    width:27px;
    height:27px;
    display:grid;
    place-items:center;
    border:1px solid #efd0d0;
    border-radius:8px;
    color:#a73535;
    background:#fff6f6;
    cursor:pointer;
}

.file-status{
    display:block;
    min-height:14px;
    margin-top:4px;
    color:var(--muted);
    font-size:9px;
}

.file-status.error{
    color:var(--danger);
}

.detail-grid{
    grid-template-columns:repeat(auto-fit,minmax(145px,1fr));
}

@media(max-width:760px){
    .service-selection-layout,
    .request-support-grid{
        grid-template-columns:1fr;
    }
    
    .service-summary-copy{
        padding:11px 12px;
    }

    .service-summary{width:100%!important;min-width:0;margin-top:0}

    .service-combobox-list{
        width:100%;
        max-height:var(--service-dropdown-max-height,min(52vh,420px));
    }

    .service-combobox.is-open .service-combobox-list{
        grid-template-columns:1fr;
    }

    .service-summary p{max-height:150px}
    
    .file-dropzone{
        min-height:60px;
    }
}

@media(max-width:480px){
    .file-dropzone{
        align-items:flex-start;
        flex-wrap:wrap;
    }
    
    .upload-copy{
        padding-top:1px;
    }
    
    .upload-action{
        width:100%;
        min-height:30px;
    }
    
    .file-status{
        line-height:1.35;
    }
}
    </style>
    <style>
        .service-summary{grid-template-columns:minmax(0,1fr)}
        .service-summary.empty{place-items:center;text-align:center;display:flex;align-items:center;justify-content:center}
        .service-summary.empty .service-summary-copy{display:flex;align-items:center;justify-content:center;padding:12px 14px}
        .service-summary.empty strong{margin:0;max-width:100%;color:var(--muted);font-size:11px;font-weight:700;line-height:1.5}
        .service-summary [hidden]{display:none!important}
    </style>
    <style>
        .chat-widget{position:fixed;inset:0;z-index:30;pointer-events:none}.chat-launcher{position:absolute;right:28px;bottom:24px;display:flex;align-items:center;gap:10px;min-height:52px;padding:10px 16px 10px 11px;border:0;border-radius:999px;color:#fff;background:linear-gradient(145deg,#0f6fec,#0b4fae);box-shadow:0 14px 30px rgba(7,63,126,.34);font:inherit;font-weight:850;cursor:pointer;pointer-events:auto;transition:transform .18s ease,opacity .18s ease}.chat-launcher:hover{transform:translateY(-2px)}.chat-launcher-icon{width:34px;height:34px;display:grid;place-items:center;border-radius:50%;background:rgba(255,255,255,.17)}.chat-launcher-icon svg,.chat-header-avatar svg,.chat-send svg,.chat-attach svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round}.chat-launcher-copy{display:grid;text-align:left}.chat-launcher-copy small{font-size:9px;font-weight:650;opacity:.82}.chat-panel{position:absolute;right:20px;bottom:18px;width:min(430px,calc(100vw - 32px));height:min(650px,calc(100dvh - 64px));display:flex;flex-direction:column;overflow:hidden;border:1px solid #c7d9ea;border-radius:20px;background:#fff;box-shadow:0 24px 70px rgba(4,30,60,.38);opacity:0;transform:translateY(22px) scale(.96);transform-origin:bottom right;pointer-events:none;transition:opacity .2s ease,transform .2s ease}.chat-widget.is-open .chat-panel{opacity:1;transform:none;pointer-events:auto}.chat-widget.is-open .chat-launcher{opacity:0;transform:translateY(12px);pointer-events:none}.chat-header{display:flex;align-items:center;gap:11px;padding:14px 15px;color:#fff;background:linear-gradient(135deg,#0d355f,#0f6fec)}.chat-header-avatar{width:40px;height:40px;display:grid;flex:0 0 auto;place-items:center;border-radius:50%;background:rgba(255,255,255,.16)}.chat-header-copy{min-width:0;flex:1}.chat-header-copy strong,.chat-header-copy span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-header-copy strong{font-size:14px}.chat-header-copy span{margin-top:2px;font-size:10px;opacity:.82}.chat-close{width:34px;height:34px;display:grid;place-items:center;border:0;border-radius:50%;color:#fff;background:rgba(255,255,255,.12);font-size:22px;cursor:pointer}.chat-stage{padding:10px 12px;border-bottom:1px solid #dce7f1;background:linear-gradient(180deg,#f8fbff,#f3f8fd)}.chat-stage-label{display:block;margin-bottom:5px;color:#526d82;font-size:9px;font-weight:850;text-transform:uppercase;letter-spacing:.07em}.chat-stage-picker{position:relative}.chat-stage-picker summary{display:grid;grid-template-columns:32px minmax(0,1fr) 28px;gap:9px;align-items:center;min-height:48px;padding:7px 8px;border:1px solid #c6d9eb;border-radius:12px;color:#173b5d;background:#fff;box-shadow:0 4px 12px rgba(31,65,94,.06);cursor:pointer;list-style:none;transition:border-color .16s ease,box-shadow .16s ease}.chat-stage-picker summary::-webkit-details-marker{display:none}.chat-stage-picker summary:hover,.chat-stage-picker[open] summary{border-color:#7fb4ea;box-shadow:0 0 0 3px rgba(15,111,236,.09)}.chat-stage-number{width:32px;height:32px;display:grid;place-items:center;border-radius:10px;color:#fff;background:linear-gradient(145deg,#0f6fec,#0b4fae);font-size:11px;font-weight:900}.chat-stage-current{min-width:0}.chat-stage-current strong,.chat-stage-current small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-stage-current strong{color:#173b5d;font-size:11px}.chat-stage-current small{margin-top:1px;color:#637d94;font-size:8px;font-weight:650}.chat-stage-arrow{width:28px;height:28px;display:grid;place-items:center;border-radius:8px;color:#3972a7;background:#edf5fd;transition:transform .18s ease}.chat-stage-arrow svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}.chat-stage-picker[open] .chat-stage-arrow{transform:rotate(180deg)}.chat-stage-options{position:absolute;z-index:4;top:calc(100% + 6px);right:0;left:0;max-height:205px;display:grid;gap:4px;overflow-y:auto;padding:6px;border:1px solid #c6d9eb;border-radius:12px;background:#fff;box-shadow:0 16px 34px rgba(16,42,67,.2)}.chat-stage-option{display:grid;grid-template-columns:29px minmax(0,1fr) 22px;gap:8px;align-items:center;min-height:43px;padding:6px 7px;border-radius:9px;color:#31546f;text-decoration:none;transition:background .15s ease,color .15s ease}.chat-stage-option:hover{color:#0b4fae;background:#eef6ff}.chat-stage-option.is-active{color:#0b4fae;background:#e7f2ff}.chat-stage-option-number{width:29px;height:29px;display:grid;place-items:center;border-radius:8px;color:#3972a7;background:#edf4fb;font-size:9px;font-weight:900}.chat-stage-option.is-active .chat-stage-option-number{color:#fff;background:#0f6fec}.chat-stage-option-copy{min-width:0}.chat-stage-option-copy strong,.chat-stage-option-copy small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-stage-option-copy strong{font-size:10px}.chat-stage-option-copy small{margin-top:1px;color:#71879a;font-size:8px}.chat-stage-check{color:#0f6fec;font-size:15px;font-weight:900;text-align:center}.chat-timeline{min-height:0;flex:1;display:grid;align-content:start;gap:9px;overflow-y:auto;padding:16px 13px;background:linear-gradient(rgba(245,249,253,.94),rgba(245,249,253,.94)),radial-gradient(circle at 12px 12px,#dbe7f1 1px,transparent 1px);background-size:auto,24px 24px;overscroll-behavior:contain}.chat-empty{margin:auto;padding:28px 18px;color:#637b90;text-align:center;font-size:11px}.chat-bubble{position:relative;max-width:84%;justify-self:start;padding:9px 11px 7px;border:1px solid #d4e0eb;border-radius:5px 15px 15px 15px;background:#fff;box-shadow:0 3px 9px rgba(31,65,94,.06)}.chat-bubble.mine{justify-self:end;border-color:#9dc5ef;border-radius:15px 5px 15px 15px;background:#e8f3ff}.chat-author{display:block;margin-bottom:3px;color:#1769aa;font-size:9px;font-weight:900}.chat-text{margin:0;color:#203d58;font-size:12px;line-height:1.48;white-space:pre-wrap;overflow-wrap:anywhere}.chat-time{display:flex;align-items:center;justify-content:flex-end;gap:4px;margin-top:5px;color:#6c8295;font-size:8px}.chat-time .read-mark{color:#0f6fec;font-size:10px;font-weight:900}.chat-bubble.is-file{width:min(310px,84%);padding:7px}.chat-attachment{display:block;color:inherit;text-decoration:none}.chat-image-preview{width:100%;max-height:210px;display:block;border-radius:10px;object-fit:cover;background:#dfe9f2}.chat-file-card{display:grid;grid-template-columns:39px minmax(0,1fr) 25px;gap:9px;align-items:center;padding:8px;border-radius:10px;background:rgba(255,255,255,.72)}.chat-file-icon{width:39px;height:39px;display:grid;place-items:center;border-radius:9px;color:#0f6fec;background:#e8f2ff}.chat-file-icon svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.8}.chat-file-copy{min-width:0}.chat-file-copy strong,.chat-file-copy span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-file-copy strong{color:#173b5d;font-size:10px}.chat-file-copy span{margin-top:2px;color:#6a8093;font-size:8px}.chat-download{color:#0f6fec;font-size:17px;text-align:center}.chat-file-status{min-height:18px;padding:5px 13px 0;color:#526d82;background:#fff;font-size:9px}.chat-file-status:empty{display:none}.chat-compose{flex:0 0 auto;padding:9px 10px 10px;border-top:1px solid #dce7f1;background:#fff}.chat-compose-row{display:grid;grid-template-columns:38px minmax(0,1fr) 40px;gap:7px;align-items:end}.chat-file-input{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}.chat-attach,.chat-send{height:38px;display:grid;place-items:center;border:0;border-radius:50%;cursor:pointer}.chat-attach{color:#315f87;background:#edf3f8}.chat-send{color:#fff;background:#0f6fec;box-shadow:0 5px 12px rgba(15,111,236,.22)}.chat-compose textarea{width:100%;height:38px;min-height:38px;max-height:112px;padding:9px 11px;border:1px solid #cbdbea;border-radius:19px;color:#203d58;background:#f8fbfe;outline:none;resize:none;font:inherit;font-size:11px;line-height:1.45}.chat-compose textarea:focus{border-color:#6ba9eb;box-shadow:0 0 0 3px rgba(15,111,236,.1)}.chat-readonly{margin:0;padding:9px 12px;color:#5e7488;border-top:1px solid #dce7f1;background:#f3f6f9;text-align:center;font-size:9px}@media(max-width:620px){.chat-launcher{right:15px;bottom:14px}.chat-panel{inset:8px;width:auto;height:auto;border-radius:16px}.chat-widget.is-open .chat-launcher{display:none}.chat-bubble{max-width:90%}.chat-bubble.is-file{width:min(310px,90%)}.chat-header{padding:12px}.chat-timeline{padding:13px 10px}.chat-stage-options{max-height:180px}}
        /* El chat abierto debe quedar por encima del encabezado y del distintivo Conectar. */
        .chat-widget{z-index:2147483635}
        .chat-bubble.is-pending{opacity:.68}
        .chat-bubble.is-error{border-color:#e49a9a;background:#fff0f0}
    </style>
    <style>
        [hidden]{display:none!important}
        .case-state-tabs{display:flex;flex-wrap:wrap;gap:7px;margin:0 0 10px}.case-state-tab{--filter-accent:var(--primary);min-height:36px;display:inline-flex;align-items:center;gap:7px;padding:7px 12px;border:1px solid color-mix(in srgb,var(--filter-accent) 30%,var(--border));border-radius:999px;color:var(--text);background:color-mix(in srgb,var(--filter-accent) 4%,var(--surface));font:inherit;font-weight:850;cursor:pointer;transition:border-color .16s ease,background .16s ease,color .16s ease,transform .16s ease}.case-state-tab:hover{transform:translateY(-1px);border-color:var(--filter-accent)}.case-state-tab.is-active{border-color:var(--filter-accent);color:var(--filter-accent);background:color-mix(in srgb,var(--filter-accent) 15%,var(--surface));box-shadow:0 0 0 2px color-mix(in srgb,var(--filter-accent) 9%,transparent)}.case-state-tab[data-case-filter-state="activo"]{--filter-accent:var(--ok)}.case-state-tab[data-case-filter-state="pendiente"]{--filter-accent:var(--warn)}.case-state-tab[data-case-filter-state="cerrado"]{--filter-accent:color-mix(in srgb,var(--primary) 60%,var(--muted))}.case-state-tab-count{min-width:22px;height:22px;display:grid;place-items:center;padding:0 6px;border-radius:999px;color:var(--surface);background:var(--filter-accent);font-size:9px;font-weight:900}.case-state-tab:not(.is-active) .case-state-tab-count{color:var(--filter-accent);background:color-mix(in srgb,var(--filter-accent) 14%,var(--surface))}
        .case-filters{display:grid;grid-template-columns:minmax(240px,1fr) auto;gap:10px;align-items:end;margin:0 0 13px;padding:11px;border:1px solid color-mix(in srgb,var(--primary) 18%,var(--border));border-radius:11px;background:color-mix(in srgb,var(--primary) 4%,var(--surface))}
        .case-filter-field{display:grid;gap:5px}.case-filter-field label{color:var(--navy);font-size:10px;font-weight:850}.case-filter-field input,.case-filter-field select{width:100%;height:38px;padding:8px 10px;border:1px solid #cbdbea;border-radius:9px;color:var(--text);background:#fff;outline:none}.case-filter-field input:focus,.case-filter-field select:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(15,111,236,.11)}
        .case-search-control{position:relative}.case-search-control input{padding-right:38px}.case-filter-clear{position:absolute;top:5px;right:5px;width:28px;height:28px;display:grid;place-items:center;border:0;border-radius:7px;color:#617b91;background:#eef4fa;cursor:pointer;font-size:17px;line-height:1}.case-filter-clear:hover{color:var(--navy);background:#e1ebf5}
        .case-filter-count{min-width:104px;padding:10px 11px;color:#486985;text-align:center;font-size:10px;font-weight:850;white-space:nowrap}.case-filter-empty td{padding:28px;text-align:center;color:var(--muted)}
        body.case-modal-open{overflow:hidden}.case-detail-modal{position:fixed;inset:0;z-index:2147483647;width:100vw;height:100vh;height:100dvh;display:grid;place-items:center;padding:22px;background:rgba(7,25,45,.64);backdrop-filter:blur(4px);isolation:isolate}.case-detail-dialog{width:min(1080px,100%);max-height:calc(100vh - 44px);max-height:calc(100dvh - 44px);display:flex;flex-direction:column;overflow:hidden;border:1px solid #cbdbea;border-radius:16px;background:#fff;box-shadow:0 28px 80px rgba(4,25,48,.3)}.case-detail-modal-bar{position:sticky;top:0;z-index:2;display:flex;flex:0 0 auto;align-items:center;justify-content:space-between;gap:12px;padding:11px 14px;border-bottom:1px solid var(--border);background:#f7faff}.case-detail-modal-bar>strong{color:var(--navy);font-size:13px}.case-detail-modal-actions{display:flex;align-items:center;gap:8px}.case-detail-modal-bar .chat-launcher{position:relative;right:auto;bottom:auto;min-height:36px;padding:5px 10px 5px 6px;border-radius:10px;box-shadow:0 5px 13px color-mix(in srgb,var(--primary) 24%,transparent)}.case-detail-modal-bar .chat-launcher-icon{width:27px;height:27px}.case-detail-modal-bar .chat-launcher-copy small{display:none}.case-detail-modal-bar .chat-launcher[hidden]{display:none!important}.case-detail-close{display:inline-flex;align-items:center;gap:6px;min-height:34px;padding:7px 10px;border:1px solid #cbdbea;border-radius:9px;color:#315b7e;background:#fff;font:inherit;font-weight:850;cursor:pointer}.case-detail-close:hover{border-color:#a9c5df;color:var(--primary);background:#f2f7fc}.case-detail-close span{font-size:18px;line-height:1}.case-detail-scroll{min-height:0;overflow-y:auto;overscroll-behavior:contain}.case-detail-card{margin:0;border:0;border-radius:0;box-shadow:none}.case-detail-card>.card-head{padding-right:2px}.case-detail-card #conversacion-solicitante{scroll-margin-top:12px}
        .request-summary{display:grid;grid-template-columns:minmax(180px,.75fr) minmax(0,2fr);gap:9px;align-items:start;margin:0 0 13px}.request-summary-item{width:100%;height:64px;min-width:0;overflow:hidden;padding:9px 12px;border:1px solid var(--mesa-theme-border,var(--border));border-radius:10px;background:var(--mesa-theme-surface,var(--surface))}.request-summary-item>span{display:block;margin-bottom:3px;color:var(--mesa-theme-muted,var(--muted));font-size:9px;font-weight:850;letter-spacing:.05em;text-transform:uppercase}.request-summary-item strong{display:block;max-height:30px;overflow:hidden;color:var(--mesa-theme-heading,var(--navy));font-size:13px;line-height:1.35;overflow-wrap:anywhere}.request-summary-item p{margin:0;color:var(--mesa-theme-text,var(--text));font-size:11px;line-height:1.4;overflow-wrap:anywhere;white-space:pre-wrap}.request-summary-description p{height:31px;max-height:31px;overflow-x:hidden;overflow-y:auto;padding-right:8px;scrollbar-color:var(--mesa-shell-color,var(--primary)) var(--mesa-theme-soft,var(--soft));scrollbar-gutter:stable;scrollbar-width:thin}.request-summary-description p::-webkit-scrollbar{width:7px}.request-summary-description p::-webkit-scrollbar-track{border-radius:999px;background:var(--mesa-theme-soft,var(--soft))}.request-summary-description p::-webkit-scrollbar-thumb{border-radius:999px;background:var(--mesa-shell-color,var(--primary))}
        @media(max-width:760px){.case-state-tabs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr))}.case-state-tab{justify-content:space-between}.case-filters{grid-template-columns:1fr}.case-filter-count{text-align:left;padding:0 2px}.case-detail-card{padding:13px}.request-summary{grid-template-columns:1fr}}

        /* Vista integrada: el detalle reemplaza la lista sin crear una capa modal. */
        .case-detail-page{width:100%;max-width:none}
        .case-detail-page .case-detail-modal{position:static;inset:auto;z-index:auto;width:100%;height:auto;display:block;padding:0;background:transparent;backdrop-filter:none;isolation:auto}
        .case-detail-page .case-detail-dialog{width:100%;max-height:none;overflow:visible;border-radius:14px;box-shadow:none}
        .case-detail-page .case-detail-scroll{overflow:visible}
        .case-detail-page .case-detail-modal-bar{top:0;z-index:5}
        .case-detail-page .case-detail-card{min-height:min(760px,calc(100dvh - 60px))}
        @media(max-width:760px){.case-detail-page .case-detail-dialog{border-radius:11px}}
    </style>
    <style>
        .email-preference{display:flex;align-items:center;justify-content:space-between;gap:14px;margin:0 0 13px;padding:10px 12px;border:1px solid #cfe0ef;border-radius:11px;background:#f7faff}.email-preference-copy{min-width:0}.email-preference-copy strong{display:block;color:var(--navy);font-size:12px}.email-preference-copy p{margin:2px 0 0;color:var(--muted);font-size:10px}.email-preference-status{display:inline-flex;margin-top:5px;padding:3px 7px;border-radius:999px;color:#087443;background:#eaf8f1;font-size:9px;font-weight:850}.email-preference-status.off{color:#8a5800;background:#fff4d6}.email-preference form{flex:0 0 auto}.btn.email-toggle{min-height:34px;padding:7px 11px;border:1px solid #bdd2e5;color:#255a83;background:#fff;font-size:10px}.btn.email-toggle:hover{border-color:var(--primary);color:var(--primary)}
        @media(max-width:760px){.email-preference{align-items:stretch;flex-direction:column}.email-preference form,.email-preference button{width:100%}}
    </style>

<style id="chat-identidad-participantes">
.chat-author-row{
    display:flex;
    align-items:center;
    gap:8px;
    margin-bottom:6px;
}
.chat-profile-image,
.chat-profile-fallback{
    width:30px;
    height:30px;
    flex:0 0 30px;
    border-radius:50%;
}
.chat-profile-image{
    display:block;
    object-fit:cover;
    border:2px solid var(--mesa-theme-border,#d4e0eb);
    background:var(--mesa-theme-soft,#dfe9f2);
}
.chat-profile-fallback{
    display:grid;
    place-items:center;
    color:var(--mesa-theme-on-primary,#fff);
    background:var(--mesa-shell-color,#315f87);
    font-size:8px;
    font-weight:900;
}
.chat-author-copy{
    min-width:0;
    display:grid;
    line-height:1.15;
}
.chat-author-copy strong{
    overflow:hidden;
    color:var(--mesa-theme-heading,#1769aa);
    font-size:10px;
    font-weight:900;
    text-overflow:ellipsis;
    white-space:nowrap;
}
.chat-author-copy small{
    margin-top:2px;
    color:var(--mesa-theme-muted,#72879a);
    font-size:8px;
    font-weight:750;
}
.chat-bubble.mine .chat-author-row{
    justify-content:flex-end;
}
.chat-bubble.mine .chat-author-copy{
    text-align:right;
}
.chat-bubble.mine,
.chat-bubble[data-mesa-own-message="1"]{
    border-color:var(--mesa-theme-border,#d4e0eb)!important;
    border-color:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 55%,var(--mesa-theme-border,#d4e0eb))!important;
    color:var(--mesa-theme-text,#203d58)!important;
    background:var(--mesa-theme-soft,#edf6ff)!important;
    background:color-mix(in srgb,var(--mesa-shell-color,#0f6fec) 16%,var(--mesa-theme-surface,#fff))!important;
}
.chat-bubble.mine .chat-author-copy,
.chat-bubble.mine .chat-author-copy strong,
.chat-bubble.mine .chat-text,
.chat-bubble[data-mesa-own-message="1"] .chat-author-copy,
.chat-bubble[data-mesa-own-message="1"] .chat-author-copy strong,
.chat-bubble[data-mesa-own-message="1"] .chat-text{color:var(--mesa-theme-heading,#173b5d)!important}
.chat-bubble.mine .chat-author-copy small,
.chat-bubble.mine .chat-time,
.chat-bubble[data-mesa-own-message="1"] .chat-author-copy small,
.chat-bubble[data-mesa-own-message="1"] .chat-time{color:var(--mesa-theme-meta,var(--mesa-theme-muted,#637d94))!important}
.chat-bubble.mine .read-mark,
.chat-bubble[data-mesa-own-message="1"] .read-mark{color:var(--mesa-theme-link,var(--mesa-shell-color,#0f6fec))!important}
.chat-bubble.mine .chat-profile-image{
    order:2;
    border-color:var(--mesa-theme-border,#d4e0eb);
}
.chat-files{flex:0 0 auto;border-bottom:1px solid var(--mesa-theme-border,#dce7f1);background:var(--mesa-theme-soft,#f3f8fd)}
.chat-files summary{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;color:var(--mesa-theme-heading,#173b5d);font-size:10px;font-weight:850;cursor:pointer;list-style:none}.chat-files summary::-webkit-details-marker{display:none}.chat-files summary span{padding:2px 7px;border-radius:999px;color:var(--mesa-theme-link,#0f6fec);background:var(--mesa-theme-surface,#fff)}
.chat-files-list{max-height:170px;display:grid;gap:6px;overflow:auto;padding:0 10px 10px}.chat-files-list a{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;padding:8px;border:1px solid var(--mesa-theme-border,#d4e0eb);border-radius:9px;color:var(--mesa-theme-text,#203d58);background:var(--mesa-theme-surface,#fff);text-decoration:none}.chat-files-list strong,.chat-files-list small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chat-files-list strong{font-size:9px}.chat-files-list small{color:var(--mesa-theme-muted,#637d94);font-size:8px}.chat-files-empty{padding:0 12px 10px;color:var(--mesa-theme-muted,#637d94);font-size:9px}
</style>

<style id="bloqueo-calificacion-pendiente">
.tab.disabled{
    border:1px solid var(--border);
    color:var(--muted);
    background:var(--soft);
    cursor:not-allowed;
    opacity:.78;
}
.pending-rating-gate{
    display:grid;
    grid-template-columns:42px minmax(0,1fr) auto;
    gap:12px;
    align-items:center;
    margin-top:10px;
    padding:12px 14px;
    border:1px solid color-mix(in srgb,var(--warn) 48%,var(--border));
    border-left:5px solid var(--warn);
    border-radius:12px;
    color:var(--text);
    background:color-mix(in srgb,var(--warn) 9%,var(--surface));
    box-shadow:0 8px 22px color-mix(in srgb,var(--warn) 10%,transparent);
}
.pending-rating-icon{
    width:42px;
    height:42px;
    display:grid;
    place-items:center;
    border-radius:12px;
    color:var(--surface);
    background:var(--warn);
    font-size:19px;
    font-weight:900;
}
.pending-rating-copy strong{
    display:block;
    color:var(--navy);
    font-size:13px;
}
.pending-rating-copy p{
    margin:3px 0 0;
    color:var(--text);
    font-size:11px;
}
.pending-rating-actions{
    display:flex;
    flex-wrap:wrap;
    justify-content:flex-end;
    gap:7px;
}
.pending-rating-action{
    min-height:34px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:7px 11px;
    border:1px solid color-mix(in srgb,var(--warn) 44%,var(--border));
    border-radius:9px;
    color:var(--navy);
    background:var(--surface);
    text-decoration:none;
    font-size:10px;
    font-weight:850;
}
.pending-rating-action.primary{
    border-color:var(--warn);
    color:var(--surface);
    background:var(--warn);
}
.creation-blocked{
    padding:22px;
    border:1px dashed color-mix(in srgb,var(--warn) 55%,var(--border));
    border-radius:12px;
    color:var(--text);
    background:color-mix(in srgb,var(--warn) 7%,var(--surface));
    text-align:center;
}
.creation-blocked strong{display:block;color:var(--navy);font-size:15px}
.creation-blocked p{margin:6px auto 13px;max-width:620px}
@media(max-width:720px){
    .pending-rating-gate{grid-template-columns:38px minmax(0,1fr)}
    .pending-rating-icon{width:38px;height:38px}
    .pending-rating-actions{grid-column:1/-1;justify-content:stretch}
    .pending-rating-action{flex:1 1 130px}
}
</style>

</head>
<body>
<main class="shell<?= $ticketSeleccionado ? ' case-detail-page' : '' ?>">
    <?php if (!$ticketSeleccionado): ?>
    <header class="topbar">
        <div class="brand">
            <span class="mark">MS</span>
            <div>
                <strong>Mesa de Servicio · <?= escaparPortalSolicitante(paisContextoNombre()) ?></strong>
                <small>Solicitante · <?= escaparPortalSolicitante($nombreUsuario) ?></small>
            </div>
        </div>
    </header>

    <nav class="tabs" aria-label="Opciones del solicitante">
        <?php if ($cantidadPendientesCalificacion > 0): ?>
            <span class="tab disabled" aria-disabled="true" title="Califique o devuelva los casos pendientes para crear uno nuevo">＋ Crear caso</span>
        <?php else: ?>
            <a class="tab <?= $vista === 'nueva' ? 'active' : '' ?>" href="panelSolicitante.php?vista=nueva">＋ Crear caso</a>
        <?php endif; ?>
        <a class="tab <?= $vista === 'tickets' ? 'active' : '' ?>" href="panelSolicitante.php?vista=tickets">Mis solicitudes · <?= $resumen['total'] ?></a>
    </nav>
    <?php endif; ?>

    <?php if ($cantidadPendientesCalificacion > 0 && !$ticketSeleccionado): ?>
        <section class="pending-rating-gate" role="alert" aria-live="assertive">
            <span class="pending-rating-icon" aria-hidden="true">!</span>
            <div class="pending-rating-copy">
                <strong>
                    Tiene <?= (int) $cantidadPendientesCalificacion ?>
                    <?= $cantidadPendientesCalificacion === 1 ? 'caso pendiente' : 'casos pendientes' ?> por calificar
                </strong>
                <p>Debe aprobar la solución o devolver el caso al gestor antes de crear una nueva solicitud.</p>
            </div>
            <div class="pending-rating-actions">
                <a class="pending-rating-action primary" href="panelSolicitante.php?vista=tickets&amp;id_ticket=<?= (int) $primerTicketPendienteCalificacion ?>">Revisar ahora</a>
                <a class="pending-rating-action" href="panelSolicitante.php?vista=tickets&amp;estado_busqueda=pendiente">Ver pendientes</a>
            </div>
        </section>
    <?php endif; ?>

    <?php if (isset($mensajes[$mensajeActual])): ?>
        <div class="alert <?= escaparPortalSolicitante($mensajes[$mensajeActual][0]) ?>">
            <?= escaparPortalSolicitante($mensajes[$mensajeActual][1]) ?>
            <?php if (in_array($mensajeActual, ['error_operacion', 'error_calificacion', 'error_reapertura', 'error_mensaje'], true) && $detalleError !== ''): ?>
                <?= escaparPortalSolicitante($detalleError) ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if ($vista === 'nueva'): ?>
        <section class="card">
            <div class="card-head">
                <div>
                    <h1>Crear una solicitud</h1>
                    <p class="muted">Elija primero el área y después el servicio que necesita.</p>
                </div>
            </div>

            <?php if ($cantidadPendientesCalificacion > 0): ?>
                <div class="creation-blocked" role="alert">
                    <strong>No puede crear una solicitud nueva todavía</strong>
                    <p>Primero debe calificar o devolver <?= $cantidadPendientesCalificacion === 1 ? 'el caso pendiente' : 'los casos pendientes' ?>. La creación se habilitará automáticamente cuando no quede ninguno.</p>
                    <a class="pending-rating-action primary" href="panelSolicitante.php?vista=tickets&amp;id_ticket=<?= (int) $primerTicketPendienteCalificacion ?>">Revisar caso pendiente</a>
                </div>
            <?php elseif (!$catalogosSolicitud): ?>
                <div class="empty">No hay áreas disponibles en este momento.</div>
            <?php else: ?>
                <form id="form-nueva-solicitud" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="accion" value="crear_ticket">
                    <input type="hidden" name="solicitud_creacion_token" value="<?= escaparPortalSolicitante($tokenCreacionSolicitud) ?>">
                    <div class="form-grid">
                        <div class="field full">
                            <label id="etiqueta-catalogo">Área *</label>
                            <div class="catalog-picker" role="radiogroup" aria-labelledby="etiqueta-catalogo">
                                <?php foreach ($catalogosSolicitud as $catalogoSolicitud): ?>
                                    <?php
                                        $idCatalogoSolicitud = (int) $catalogoSolicitud['id_catalogo'];
                                        $descripcionCatalogoSolicitud = trim((string) ($catalogoSolicitud['descripcion'] ?? ''));
                                    ?>
                                    <label class="catalog-choice">
                                        <input
                                            type="radio"
                                            name="id_catalogo"
                                            value="<?= $idCatalogoSolicitud ?>"
                                            required
                                            data-catalogo-solicitud
                                        >
                                        <span class="catalog-choice-body">
                                            <span class="catalog-choice-title">
                                                <strong><?= escaparPortalSolicitante($catalogoSolicitud['nombre']) ?></strong>
                                            </span>
                                            <span class="catalog-choice-media">
                                                <img
                                                    src="<?= escaparPortalSolicitante(seguridadUrlImagenCatalogo($idCatalogoSolicitud, $catalogoSolicitud['imagen'] ?? null)) ?>"
                                                    alt="Imagen del área <?= escaparPortalSolicitante($catalogoSolicitud['nombre']) ?>"
                                                >
                                            </span>
                                            <small title="<?= escaparPortalSolicitante($descripcionCatalogoSolicitud) ?>"><?= escaparPortalSolicitante($descripcionCatalogoSolicitud !== '' ? $descripcionCatalogoSolicitud : 'Sin descripción registrada.') ?></small>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="service-selection-layout">
                            <div class="field">
                                <label for="buscador-servicio">Servicio *</label>
                                <div id="selector-servicio-buscable" class="service-combobox">
                                    <div class="service-combobox-control">
                                        <input
                                            id="buscador-servicio"
                                            class="service-combobox-input"
                                            type="text"
                                            placeholder="Seleccione primero un área"
                                            autocomplete="off"
                                            role="combobox"
                                            aria-autocomplete="list"
                                            aria-controls="opciones-servicio"
                                            aria-expanded="false"
                                            required
                                            disabled
                                        >
                                        <button
                                            id="alternar-opciones-servicio"
                                            class="service-combobox-toggle"
                                            type="button"
                                            aria-label="Mostrar servicios"
                                            tabindex="-1"
                                            disabled
                                        ></button>
                                    </div>
                                    <div
                                        id="opciones-servicio"
                                        class="service-combobox-list"
                                        role="listbox"
                                        aria-label="Servicios disponibles"
                                    ></div>
                                    <select id="id_proceso" name="id_proceso" class="service-native-select" disabled aria-hidden="true">
                                        <option value="">Seleccione primero un área</option>
                                    </select>
                                    <input id="id_servicio" name="id_servicio" type="hidden" value="">
                                    <input id="usa_proceso" name="usa_proceso" type="hidden" value="">
                                </div>
                                <span id="estado-servicios-catalogo" class="service-feedback" aria-live="polite">Los servicios se cargarán según el área seleccionada.</span>
                            </div>
                            <aside id="resumen-servicio" class="service-summary empty" aria-live="polite">
                                <div class="service-summary-copy">
                                    <strong id="resumen-servicio-nombre">Seleccione un servicio para que aparezca la información de él en este apartado.</strong>
                                    <p id="resumen-servicio-descripcion" hidden></p>
                                    <div class="service-tags" id="resumen-servicio-etiquetas" hidden>
                                        <span class="service-tag type" id="resumen-servicio-tipo"></span>
                                        <span class="service-tag priority" id="resumen-servicio-prioridad"></span>
                                        <span class="service-tag urgency" id="resumen-servicio-urgencia"></span>
                                        <span class="service-tag impact" id="resumen-servicio-impacto"></span>
                                    </div>
                                </div>
                            </aside>
                        </div>
                        <div class="request-support-grid">
                            <div class="request-text-column">
                                <div class="field">
                                    <label for="titulo">Asunto *</label>
                                    <input id="titulo" name="titulo" maxlength="180" required placeholder="Ejemplo: No puedo ingresar al correo corporativo">
                                </div>
                                <div class="field description-field">
                                    <label for="descripcion">Descripción *</label>
                                    <textarea id="descripcion" name="descripcion" maxlength="15000" rows="2" required placeholder="Explique qué sucede y desde cuándo."></textarea>
                                </div>
                            </div>
                            <div class="field file-field">
                                <label for="adjuntos">Archivos opcionales</label>
                                <input class="file-input" id="adjuntos" type="file" name="adjuntos[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.txt,.csv,.zip,.doc,.docx,.xls,.xlsx">
                                <label class="file-dropzone" id="zona-adjuntos" for="adjuntos">
                                    <span class="upload-icon" aria-hidden="true">
                                        <svg viewBox="0 0 24 24"><path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M5 14v4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-4"/></svg>
                                    </span>
                                    <span class="upload-copy">
                                        <strong>Adjuntar archivos</strong>
                                        <span>Arrástrelos aquí o búsquelos en su equipo.</span>
                                    </span>
                                    <span class="upload-action">Seleccionar</span>
                                </label>
                                <div class="file-list" id="lista-adjuntos" hidden></div>
                                <span class="file-status" id="estado-adjuntos">Máximo cinco archivos de 5 MB cada uno.</span>
                            </div>
                        </div>
                    </div>
                    <div class="actions">
                        <button class="btn primary" type="submit" data-create-request-button>
                            Crear solicitud
                        </button>
                        <span class="muted" data-create-request-status role="status" aria-live="polite"></span>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    <?php else: ?>
        <?php if (!$ticketSeleccionado): ?>
        <section class="card">
            <div class="card-head"><div><h1>Estado de mis solicitudes</h1><p class="muted">Aquí solo aparecen los casos creados por su usuario en <?= escaparPortalSolicitante(paisContextoNombre()) ?>.</p></div></div>
            <?php if (!$tickets): ?>
                <div class="empty">Todavía no ha creado solicitudes.</div>
            <?php else: ?>
                <nav class="case-state-tabs" aria-label="Filtrar solicitudes por estado">
                    <?php
                        $filtrosEstadoSolicitante = [
                            'activo' => ['Activos', $resumen['activos']],
                            'pendiente' => ['Pendientes', $resumen['listos']],
                            'cerrado' => ['Cerrados', $resumen['cerrados']],
                            'todos' => ['Todos', $resumen['total']],
                        ];
                    ?>
                    <?php foreach ($filtrosEstadoSolicitante as $valorFiltro => [$etiquetaFiltro, $cantidadFiltro]): ?>
                        <button
                            class="case-state-tab <?= $estadoBusquedaCasos === $valorFiltro ? 'is-active' : '' ?>"
                            type="button"
                            data-case-filter-state="<?= escaparPortalSolicitante($valorFiltro) ?>"
                            aria-pressed="<?= $estadoBusquedaCasos === $valorFiltro ? 'true' : 'false' ?>"
                        >
                            <span><?= escaparPortalSolicitante($etiquetaFiltro) ?></span>
                            <span class="case-state-tab-count"><?= (int) $cantidadFiltro ?></span>
                        </button>
                    <?php endforeach; ?>
                </nav>
                <div class="case-filters" aria-label="Filtros de casos">
                    <div class="case-filter-field">
                        <label for="buscar-casos">Buscar casos</label>
                        <div class="case-search-control">
                            <input
                                id="buscar-casos"
                                type="search"
                                value="<?= escaparPortalSolicitante($busquedaCasos) ?>"
                                maxlength="120"
                                autocomplete="off"
                                placeholder="Número exacto, asunto, servicio, estado o fecha"
                            >
                            <button class="case-filter-clear" id="limpiar-filtro-casos" type="button" aria-label="Limpiar búsqueda" hidden>×</button>
                        </div>
                    </div>
                    <input id="estado-casos" type="hidden" value="<?= escaparPortalSolicitante($estadoBusquedaCasos) ?>">
                    <span class="case-filter-count" id="contador-casos" aria-live="polite"><?= count($tickets) ?> caso(s)</span>
                </div>
                <div class="table-wrap">
                    <table>
                        <thead><tr><th>Caso</th><th>Asunto</th><th>Servicio</th><th>Estado</th><th>Creado</th><th>Finalización prevista</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ($tickets as $ticket): ?>
                            <?php
                                $estadoTicket = isset($ticketsConSolucionLista[(int) $ticket['id_ticket']])
                                    ? 'pendiente_calificacion'
                                    : (string) ($ticket['estado_flujo'] ?? $ticket['estado'] ?? 'en_proceso');
                                $estadoFiltroTicket = (fn ($__mesaMatchValue35) => (($__mesaMatchValue35 === ('cerrada')) ? ('cerrado') : ((($__mesaMatchValue35 === ('cancelada')) ? ('cancelado') : ($estadoTicket)))))($estadoTicket);
                                $categoriaFiltroTicket = (fn ($__mesaMatchValue36) => (($__mesaMatchValue36 === ($estadoFiltroTicket === 'pendiente_calificacion')) ? ('pendiente') : ((($__mesaMatchValue36 === (in_array($estadoFiltroTicket, ['cerrado', 'cancelado'], true))) ? ('cerrado') : ('activo')))))(true);
                                $parametrosDetalle = [
                                    'vista' => 'tickets',
                                    'id_ticket' => (int) $ticket['id_ticket'],
                                ];

                                if ($busquedaCasos !== '') {
                                    $parametrosDetalle['buscar'] = $busquedaCasos;
                                }

                                if ($estadoBusquedaCasos !== 'todos') {
                                    $parametrosDetalle['estado_busqueda'] = $estadoBusquedaCasos;
                                }
                            ?>
                            <tr
                                data-case-row
                                data-ticket-id="<?= (int) $ticket['id_ticket'] ?>"
                                data-case-state="<?= escaparPortalSolicitante($estadoFiltroTicket) ?>"
                                data-case-category="<?= escaparPortalSolicitante($categoriaFiltroTicket) ?>"
                            >
                                <td><strong><?= (int) $ticket['id_ticket'] ?></strong></td>
                                <td><?= escaparPortalSolicitante($ticket['titulo']) ?></td>
                                <td><?= escaparPortalSolicitante($ticket['proceso_nombre'] ?? 'Solicitud') ?></td>
                                <td><span class="status <?= escaparPortalSolicitante($estadoTicket) ?>"><?= escaparPortalSolicitante(textoEstadoPortalSolicitante($estadoTicket)) ?></span></td>
                                <td><?= escaparPortalSolicitante(fechaPortalSolicitante($ticket['fecha_creacion'] ?? null)) ?></td>
                                <td>
                                    <?php $proyeccionFila = $proyeccionesTickets[(int) $ticket['id_ticket']] ?? []; ?>
                                    <strong><?= escaparPortalSolicitante(fechaPortalSolicitante($proyeccionFila['fecha'] ?? null)) ?></strong>
                                    <?php if (!empty($proyeccionFila['pausado_por_derivacion'])): ?><small>SLA pausado por derivación</small><?php endif; ?>
                                </td>
                                <td><a class="view-link" data-case-view href="panelSolicitante.php?<?= escaparPortalSolicitante(http_build_query($parametrosDetalle)) ?>">Ver estado</a></td>
                            </tr>
                        <?php endforeach; ?>
                            <tr class="case-filter-empty" id="sin-resultados-casos" hidden>
                                <td colspan="7">No se encontraron casos con los filtros seleccionados.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
        <?php endif; ?>

        <?php if ($ticketSeleccionado): ?>
            <section class="case-detail-modal" id="modal-estado-caso" role="region" aria-labelledby="titulo-modal-estado-caso">
                <div class="case-detail-dialog">
                    <div class="case-detail-modal-bar">
                        <strong>Detalle y seguimiento del caso</strong>
                        <div class="case-detail-modal-actions">
                            <button
                                class="chat-launcher"
                                type="button"
                                data-chat-open
                                aria-controls="panel-chat-solicitante"
                                aria-expanded="false"
                            >
                                <span class="chat-launcher-icon" aria-hidden="true">
                                    <svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 9h8M8 13h5"/></svg>
                                </span>
                                <span class="chat-launcher-copy"><strong>Conversación</strong><small>Hablar con el gestor</small></span>
                            </button>
                        </div>
                    </div>
                    <div class="case-detail-scroll">
            <section class="card case-detail-card">
                <div class="card-head">
                    <div><h2 id="titulo-modal-estado-caso">Caso <?= (int) $ticketSeleccionado['id_ticket'] ?></h2></div>
                    <?php
                        $estadoSeleccionado = $etapaPendienteCalificacion
                            ? 'pendiente_calificacion'
                            : (string) ($ticketSeleccionado['estado_flujo'] ?? 'en_proceso');
                    ?>
                    <span class="status <?= escaparPortalSolicitante($estadoSeleccionado) ?>"><?= escaparPortalSolicitante(textoEstadoPortalSolicitante($estadoSeleccionado)) ?></span>
                </div>
                <section class="request-summary" aria-label="Información de la solicitud">
                    <div class="request-summary-item">
                        <span>Asunto</span>
                        <strong><?= escaparPortalSolicitante($ticketSeleccionado['titulo'] ?? 'Sin asunto') ?></strong>
                    </div>
                    <div class="request-summary-item request-summary-description">
                        <span>Descripción de la solicitud</span>
                        <p><?= escaparPortalSolicitante(trim((string) ($ticketSeleccionado['descripcion'] ?? '')) ?: 'Sin descripción registrada.') ?></p>
                    </div>
                </section>
                <div class="email-preference">
                    <div class="email-preference-copy">
                        <strong>¿Desea recibir notificaciones del caso?</strong>
                        <p>Por defecto recibirá un correo por cada nueva acción pública. Puede cambiarlo cuando quiera.</p>
                        <span class="email-preference-status <?= $notificacionesEmailSolicitante ? '' : 'off' ?>">
                            <?= $notificacionesEmailSolicitante ? 'Notificaciones activadas' : 'Notificaciones desactivadas' ?>
                        </span>
                    </div>
                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                        <input type="hidden" name="accion" value="configurar_notificaciones">
                        <input type="hidden" name="id_ticket" value="<?= (int) $ticketSeleccionado['id_ticket'] ?>">
                        <input type="hidden" name="habilitada" value="<?= $notificacionesEmailSolicitante ? '0' : '1' ?>">
                        <button class="btn email-toggle" type="submit">
                            <?= $notificacionesEmailSolicitante ? 'No recibir notificaciones' : 'Recibir notificaciones' ?>
                        </button>
                    </form>
                </div>
                <div class="detail-grid">
                    <div class="detail-item"><span>Proceso</span><strong><?= escaparPortalSolicitante($ticketSeleccionado['proceso_nombre'] ?? 'Solicitud') ?></strong></div>
                    <div class="detail-item"><span>Clasificación</span><strong><?= escaparPortalSolicitante(ucfirst((string) ($ticketSeleccionado['tipo_solicitud'] ?? 'Requerimiento'))) ?></strong></div>
                    <div class="detail-item"><span>Prioridad</span><strong><?= escaparPortalSolicitante(ucfirst((string) ($ticketSeleccionado['prioridad'] ?? 'Media'))) ?></strong></div>
                    <div class="detail-item"><span>Urgencia</span><strong><?= escaparPortalSolicitante(ucfirst((string) $ticketSeleccionado['urgencia'])) ?></strong></div>
                    <div class="detail-item"><span>Fecha de creación</span><strong><?= escaparPortalSolicitante(fechaPortalSolicitante($ticketSeleccionado['fecha_creacion'] ?? null)) ?></strong></div>
                    <?php $proyeccionSeleccionada = $proyeccionesTickets[(int) $ticketSeleccionado['id_ticket']] ?? []; ?>
                    <div class="detail-item"><span><?= ($proyeccionSeleccionada['estado'] ?? '') === 'finalizado' ? 'Fecha real de finalización' : 'Finalización prevista' ?></span><strong><?= escaparPortalSolicitante(fechaPortalSolicitante($proyeccionSeleccionada['fecha'] ?? null)) ?></strong><?php if (!empty($proyeccionSeleccionada['pausado_por_derivacion'])): ?><small>SLA pausado mientras finalizan las derivaciones</small><?php endif; ?></div>
                    <div class="detail-item"><span>Estado general</span><strong><?= escaparPortalSolicitante(textoEstadoPortalSolicitante($estadoSeleccionado)) ?></strong></div>
                </div>
                <div class="case-list">
                    <?php foreach ($etapasTicket as $indiceEtapa => $etapa): ?>
                        <?php $estadoCaso = (string) ($etapa['estado'] ?? 'pendiente'); ?>
                        <?php
                            $esEtapaSinIniciar = $estadoCaso === 'bloqueada';
                            $mostrarGestorActual = !$esEtapaSinIniciar
                                && !in_array(
                                    $estadoCaso,
                                    ['completada', 'cancelada'],
                                    true
                                );
                            $nombreGestorVisible =
                                nombreCortoPortalSolicitante((string) (
                                    $etapa['gestor_nombre'] ?? 'Pendiente'
                                ));
                        ?>
                        <article class="case">
                            <div><strong>Etapa <?= $indiceEtapa + 1 ?> · <?= escaparPortalSolicitante($etapa['catalogo_nombre'] ?? 'Área') ?></strong><small><?= escaparPortalSolicitante($etapa['servicio_nombre'] ?? 'Servicio') ?></small></div>
                            <?php if ($mostrarGestorActual): ?>
                                <div class="case-manager">
                                    <span>Gestor actual</span>
                                    <strong><?= escaparPortalSolicitante($nombreGestorVisible) ?></strong>
                                </div>
                            <?php else: ?>
                                <div class="case-manager-placeholder" aria-hidden="true"></div>
                            <?php endif; ?>
                            <span class="status <?= escaparPortalSolicitante($estadoCaso) ?>"><?= escaparPortalSolicitante(textoEstadoCasoSolicitante($estadoCaso)) ?></span>
                        </article>
                    <?php endforeach; ?>
                </div>

                <?php
                    $abrirChatSolicitante = $idChatSeleccionado > 0
                        || in_array(
                            $mensajeActual,
                            ['mensaje_enviado', 'error_mensaje'],
                            true
                        );
                ?>
                <div
                    class="chat-widget"
                    id="conversacion-solicitante"
                    data-chat-widget
                    data-chat-theme-version="2026-08-20.6"
                    data-auto-open="<?= $abrirChatSolicitante ? 'true' : 'false' ?>"
                >
                    <section
                        class="chat-panel"
                        id="panel-chat-solicitante"
                        aria-label="Conversación del caso"
                        aria-hidden="true"
                    >
                        <header class="chat-header">
                            <span class="chat-header-avatar" aria-hidden="true">
                                <svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 9h8M8 13h5"/></svg>
                            </span>
                            <div class="chat-header-copy">
                                <strong>Mesa de Servicio · Caso <?= $idTicketSeleccionado ?></strong>
                                <span><?= $conversacionSolicitanteActual
                                    ? escaparPortalSolicitante(
                                        ($conversacionSolicitanteActual['catalogo_nombre'] ?? 'Área')
                                        . ' · '
                                        . ($conversacionSolicitanteActual['gestor_destino'] ?: 'Gestor por asignar')
                                    )
                                    : 'Conversación pendiente de habilitación' ?></span>
                            </div>
                            <button class="chat-close" type="button" data-chat-close aria-label="Cerrar conversación">×</button>
                        </header>

                        <?php if ($conversacionesSolicitante): ?>
                            <?php
                                $indiceConversacionActiva = 0;
                                foreach ($conversacionesSolicitante as $indiceConversacion => $conversacionSolicitante) {
                                    if (
                                        $conversacionSolicitanteActual
                                        && (int) $conversacionSolicitanteActual['id_ticket_etapa']
                                            === (int) $conversacionSolicitante['id_ticket_etapa']
                                    ) {
                                        $indiceConversacionActiva = $indiceConversacion;
                                        break;
                                    }
                                }

                                $totalMensajesConversacionActiva = (int) (
                                    $conversacionSolicitanteActual['total_mensajes'] ?? 0
                                );
                            ?>
                            <div class="chat-stage">
                                <span class="chat-stage-label">Conversación por etapa</span>
                                <details class="chat-stage-picker" data-chat-stage-picker>
                                    <summary aria-label="Seleccionar otra etapa de la conversación">
                                        <span class="chat-stage-number"><?= $indiceConversacionActiva + 1 ?></span>
                                        <span class="chat-stage-current">
                                            <strong>Etapa <?= $indiceConversacionActiva + 1 ?> · <?= escaparPortalSolicitante($conversacionSolicitanteActual['catalogo_nombre'] ?? 'Área') ?></strong>
                                            <small><?= $totalMensajesConversacionActiva ?> <?= $totalMensajesConversacionActiva === 1 ? 'mensaje' : 'mensajes' ?> · Seleccionar otra etapa</small>
                                        </span>
                                        <span class="chat-stage-arrow" aria-hidden="true">
                                            <svg viewBox="0 0 24 24"><path d="m7 9 5 5 5-5"/></svg>
                                        </span>
                                    </summary>
                                    <nav class="chat-stage-options" aria-label="Etapas disponibles">
                                        <?php foreach ($conversacionesSolicitante as $indiceConversacion => $conversacionSolicitante): ?>
                                            <?php
                                                $idConversacion = (int) $conversacionSolicitante['id_ticket_etapa'];
                                                $esConversacionActual = $conversacionSolicitanteActual
                                                    && (int) $conversacionSolicitanteActual['id_ticket_etapa'] === $idConversacion;
                                                $totalMensajesConversacion = (int) ($conversacionSolicitante['total_mensajes'] ?? 0);
                                                $parametrosConversacion = [
                                                    'vista' => 'tickets',
                                                    'id_ticket' => $idTicketSeleccionado,
                                                    'id_chat' => $idConversacion,
                                                ];

                                                if ($busquedaCasos !== '') {
                                                    $parametrosConversacion['buscar'] = $busquedaCasos;
                                                }

                                                if ($estadoBusquedaCasos !== 'todos') {
                                                    $parametrosConversacion['estado_busqueda'] = $estadoBusquedaCasos;
                                                }

                                                $urlConversacion = 'panelSolicitante.php?'
                                                    . http_build_query($parametrosConversacion)
                                                    . '#conversacion-solicitante';
                                            ?>
                                            <a
                                                class="chat-stage-option <?= $esConversacionActual ? 'is-active' : '' ?>"
                                                href="<?= escaparPortalSolicitante($urlConversacion) ?>"
                                                <?= $esConversacionActual ? 'aria-current="page"' : '' ?>
                                            >
                                                <span class="chat-stage-option-number"><?= $indiceConversacion + 1 ?></span>
                                                <span class="chat-stage-option-copy">
                                                    <strong>Etapa <?= $indiceConversacion + 1 ?> · <?= escaparPortalSolicitante($conversacionSolicitante['catalogo_nombre']) ?></strong>
                                                    <small><?= $totalMensajesConversacion ?> <?= $totalMensajesConversacion === 1 ? 'mensaje' : 'mensajes' ?></small>
                                                </span>
                                                <span class="chat-stage-check" aria-hidden="true"><?= $esConversacionActual ? '✓' : '' ?></span>
                                            </a>
                                        <?php endforeach; ?>
                                    </nav>
                                </details>
                            </div>
                        <?php endif; ?>

                        <?php if ($conversacionSolicitanteActual): ?>
                            <details class="chat-files">
                                <summary>Archivos adjuntos <span><?= count($adjuntosSolicitante) ?></span></summary>
                                <?php if ($adjuntosSolicitante): ?>
                                    <div class="chat-files-list">
                                        <?php foreach ($adjuntosSolicitante as $archivoChat): ?>
                                            <a href="descargarAdjunto.php?id=<?= (int) $archivoChat['id_adjunto'] ?>">
                                                <span><strong><?= escaparPortalSolicitante($archivoChat['nombre_original'] ?? 'Archivo adjunto') ?></strong><small><?= escaparPortalSolicitante(fechaPortalSolicitante($archivoChat['creado_en'] ?? null)) ?></small></span><span aria-hidden="true">↓</span>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?><div class="chat-files-empty">Esta conversación no tiene archivos adjuntos.</div><?php endif; ?>
                            </details>
                        <?php endif; ?>

                        <div class="chat-timeline" data-chat-timeline aria-live="polite">
                            <?php if (!$conversacionSolicitanteActual): ?>
                                <div class="chat-empty">La conversación se habilitará cuando el área inicie la atención del caso.</div>
                            <?php elseif (!$eventosConversacionSolicitante): ?>
                                <div class="chat-empty">Todavía no hay mensajes. Puede iniciar la conversación desde el campo inferior.</div>
                            <?php endif; ?>

                            <?php foreach ($eventosConversacionSolicitante as $eventoConversacion): ?>
                                <?php
                                    $idAutorChat = (int) ($eventoConversacion['id_autor'] ?? 0);
                                    $nombreAutorChat = trim((string) ($eventoConversacion['autor'] ?? 'Usuario'));
                                    $rolAutorChat = (int) ($eventoConversacion['autor_rol'] ?? 0);
                                    $esEventoPropio = $idAutorChat === $idUsuario;
                                    $esAdjunto = (string) ($eventoConversacion['tipo_evento'] ?? '') === 'adjunto';
                                ?>
                                <?php if (!$esAdjunto): ?>
                                    <article class="chat-bubble <?= $esEventoPropio ? 'mine' : '' ?>" <?= $esEventoPropio ? 'data-mesa-own-message="1"' : '' ?>>
                                        <span class="chat-author-row">
                                            <?php if ($idAutorChat > 0): ?>
                                                <img class="chat-profile-image" src="imagenPerfil.php?usuario=<?= $idAutorChat ?>" alt="Foto de <?= escaparPortalSolicitante($nombreAutorChat) ?>" loading="lazy">
                                            <?php else: ?>
                                                <span class="chat-profile-fallback" aria-hidden="true">US</span>
                                            <?php endif; ?>
                                            <span class="chat-author-copy">
                                                <strong><?= escaparPortalSolicitante($nombreAutorChat !== '' ? $nombreAutorChat : 'Usuario') ?></strong>
                                                <small><?= escaparPortalSolicitante(rolChatPortalSolicitante($rolAutorChat)) ?></small>
                                            </span>
                                        </span>
                                        <p class="chat-text"><?= escaparPortalSolicitante($eventoConversacion['mensaje']) ?></p>
                                        <span class="chat-time">
                                            <?= escaparPortalSolicitante(fechaPortalSolicitante($eventoConversacion['creado_en'])) ?>
                                            <?= $esEventoPropio ? '<span class="read-mark" aria-label="Enviado">✓✓</span>' : '' ?>
                                        </span>
                                    </article>
                                <?php else: ?>
                                    <?php
                                        $idAdjuntoChat = (int) $eventoConversacion['id_adjunto'];
                                        $nombreAdjuntoChat = (string) $eventoConversacion['nombre_original'];
                                        $tipoAdjuntoChat = (string) ($eventoConversacion['tipo_mime'] ?? '');
                                        $esImagenChat = str_starts_with($tipoAdjuntoChat, 'image/');
                                    ?>
                                    <article class="chat-bubble is-file <?= $esEventoPropio ? 'mine' : '' ?>" <?= $esEventoPropio ? 'data-mesa-own-message="1"' : '' ?>>
                                        <span class="chat-author-row">
                                            <?php if ($idAutorChat > 0): ?>
                                                <img class="chat-profile-image" src="imagenPerfil.php?usuario=<?= $idAutorChat ?>" alt="Foto de <?= escaparPortalSolicitante($nombreAutorChat) ?>" loading="lazy">
                                            <?php else: ?>
                                                <span class="chat-profile-fallback" aria-hidden="true">US</span>
                                            <?php endif; ?>
                                            <span class="chat-author-copy">
                                                <strong><?= escaparPortalSolicitante($nombreAutorChat !== '' ? $nombreAutorChat : 'Usuario') ?></strong>
                                                <small><?= escaparPortalSolicitante(rolChatPortalSolicitante($rolAutorChat)) ?></small>
                                            </span>
                                        </span>
                                        <a class="chat-attachment" href="descargarAdjunto.php?id=<?= $idAdjuntoChat ?>" title="Descargar <?= escaparPortalSolicitante($nombreAdjuntoChat) ?>">
                                            <?php if ($esImagenChat): ?>
                                                <img class="chat-image-preview" src="descargarAdjunto.php?id=<?= $idAdjuntoChat ?>&amp;inline=1" alt="Vista previa de <?= escaparPortalSolicitante($nombreAdjuntoChat) ?>" loading="lazy">
                                            <?php endif; ?>
                                            <span class="chat-file-card">
                                                <span class="chat-file-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M7 3h7l5 5v13H7Z"/><path d="M14 3v6h5M10 14h6M10 17h5"/></svg></span>
                                                <span class="chat-file-copy">
                                                    <strong><?= escaparPortalSolicitante($nombreAdjuntoChat) ?></strong>
                                                    <span><?= escaparPortalSolicitante(flujoFormatoTamanoArchivo((int) ($eventoConversacion['tamano'] ?? 0))) ?> · Pulse para descargar</span>
                                                </span>
                                                <span class="chat-download" aria-hidden="true">↓</span>
                                            </span>
                                        </a>
                                        <span class="chat-time">
                                            <?= escaparPortalSolicitante(fechaPortalSolicitante($eventoConversacion['creado_en'])) ?>
                                            <?= $esEventoPropio ? '<span class="read-mark" aria-label="Enviado">✓✓</span>' : '' ?>
                                        </span>
                                    </article>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>

                        <?php if ($puedeEscribirSolicitante && $conversacionSolicitanteActual): ?>
                            <form class="chat-compose" method="post" enctype="multipart/form-data" data-chat-compose>
                                <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                                <input type="hidden" name="accion" value="enviar_mensaje">
                                <input type="hidden" name="id_ticket" value="<?= $idTicketSeleccionado ?>">
                                <input type="hidden" name="id_ticket_etapa" value="<?= (int) $conversacionSolicitanteActual['id_ticket_etapa'] ?>">
                                <div class="chat-file-status" data-chat-file-status aria-live="polite"></div>
                                <div class="chat-compose-row">
                                    <input class="chat-file-input" id="adjuntos_solicitante" type="file" name="adjuntos[]" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.txt,.csv,.zip,.doc,.docx,.xls,.xlsx" data-chat-file-input>
                                    <label class="chat-attach" for="adjuntos_solicitante" title="Adjuntar archivos" aria-label="Adjuntar archivos">
                                        <svg viewBox="0 0 24 24"><path d="m20.5 11.5-8.8 8.8a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 1 1-2.8-2.8l8.5-8.5"/></svg>
                                    </label>
                                    <textarea id="mensaje_solicitante" name="mensaje" maxlength="10000" rows="1" placeholder="Escriba un mensaje" aria-label="Mensaje"></textarea>
                                    <button class="chat-send" type="submit" title="Enviar mensaje" aria-label="Enviar mensaje">
                                        <svg viewBox="0 0 24 24"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
                                    </button>
                                </div>
                            </form>
                        <?php elseif ($conversacionSolicitanteActual): ?>
                            <p class="chat-readonly">Esta conversación está cerrada y permanece disponible para consulta.</p>
                        <?php endif; ?>
                    </section>
                </div>

                <?php if ($etapaPendienteCalificacion): ?>
                    <?php
                        $esCierreDefinitivoPrimerContacto = !empty($etapaPendienteCalificacion['solicita_cierre_definitivo']);
                        $numeroEtapaSolucion = (int) ($etapaPendienteCalificacion['numero_etapa'] ?? $etapaPendienteCalificacion['orden'] ?? 1);
                        $nombreEtapaSolucion = 'Etapa ' . $numeroEtapaSolucion . ' · '
                            . trim((string) ($etapaPendienteCalificacion['catalogo_nombre'] ?? '') . ' / '
                                . (string) ($etapaPendienteCalificacion['servicio_nombre'] ?? ''), ' /');

                        if ($esCierreDefinitivoPrimerContacto) {
                            $claseResultadoAprobacion = 'definitive';
                            $tipoSolucionPendiente = 'Solución definitiva del caso';
                            $resultadoAprobacion = 'Al aprobar, el caso se cerrará por completo y no se ejecutarán las etapas siguientes.';
                            $textoBotonAprobacion = 'Calificar y aprobar cierre definitivo';
                            $confirmacionAprobacion = '¿Confirma el cierre definitivo del ticket? Al aprobar, no continuará a otra etapa.';
                        } elseif ($siguienteEtapaPendienteCalificacion) {
                            $claseResultadoAprobacion = 'continue';
                            $tipoSolucionPendiente = 'Solución de una etapa del flujo';
                            $numeroSiguienteEtapa = (int) ($siguienteEtapaPendienteCalificacion['numero_etapa'] ?? $siguienteEtapaPendienteCalificacion['orden'] ?? ($numeroEtapaSolucion + 1));
                            $resultadoAprobacion = 'Al aprobar, esta etapa quedará completada y continuará la Etapa '
                                . $numeroSiguienteEtapa . ' · '
                                . trim((string) ($siguienteEtapaPendienteCalificacion['catalogo_nombre'] ?? '') . ' / '
                                    . (string) ($siguienteEtapaPendienteCalificacion['servicio_nombre'] ?? ''), ' /') . '.';
                            $textoBotonAprobacion = 'Calificar y continuar el flujo';
                            $confirmacionAprobacion = '¿Confirma la calificación? Esta etapa se completará y se habilitará la siguiente.';
                        } else {
                            $claseResultadoAprobacion = 'final';
                            $tipoSolucionPendiente = 'Solución de la etapa final';
                            $resultadoAprobacion = 'Al aprobar, esta última etapa quedará completada y el caso se cerrará.';
                            $textoBotonAprobacion = 'Calificar y finalizar el caso';
                            $confirmacionAprobacion = '¿Confirma la calificación y el cierre del caso al completar su última etapa?';
                        }
                    ?>
                    <div class="rating-card <?= escaparPortalSolicitante($claseResultadoAprobacion) ?>">
                        <h3><?= $esCierreDefinitivoPrimerContacto ? 'Solicitud de cierre definitivo por solución en primer contacto' : 'La solución está lista para su aprobación' ?></h3>
                        <div class="solution-context" aria-label="Contexto de la solución pendiente">
                            <div class="solution-context-item">
                                <span>Etapa que presenta la solución</span>
                                <strong><?= escaparPortalSolicitante($nombreEtapaSolucion) ?></strong>
                            </div>
                            <div class="solution-context-item outcome <?= escaparPortalSolicitante($claseResultadoAprobacion) ?>">
                                <span><?= escaparPortalSolicitante($tipoSolucionPendiente) ?></span>
                                <strong><?= $esCierreDefinitivoPrimerContacto ? 'Cierra todo el caso' : ($siguienteEtapaPendienteCalificacion ? 'Continúa el flujo' : 'Finaliza el flujo') ?></strong>
                                <p><?= escaparPortalSolicitante($resultadoAprobacion) ?></p>
                            </div>
                        </div>
                        <?php if ($esCierreDefinitivoPrimerContacto): ?>
                            <div class="definitive-close-alert" role="alert">
                                <strong>Importante: esta aprobación cerrará completamente el ticket.</strong>
                                <p>El gestor informó que resolvió toda la solicitud en el primer contacto. Si usted aprueba, el caso no pasará a otra etapa ni a otra área y las etapas futuras que no hayan iniciado quedarán canceladas.</p>
                            </div>
                            <p>Revise la solución aplicada y califique la gestión antes de confirmar el cierre definitivo.</p>
                        <?php else: ?>
                            <p>Para aprobar esta etapa del mismo caso, califique la gestión del área y el tiempo de respuesta.</p>
                        <?php endif; ?>
                        <div class="solution-box">
                            <span>Solución aplicada</span>
                            <strong><?= escaparPortalSolicitante($etapaPendienteCalificacion['solucion_nombre'] ?? 'Solución registrada') ?></strong>
                            <?php if (trim((string) ($etapaPendienteCalificacion['comentario_cierre'] ?? '')) !== ''): ?>
                                <p><?= escaparPortalSolicitante($etapaPendienteCalificacion['comentario_cierre']) ?></p>
                            <?php endif; ?>
                        </div>
                        <form method="post" onsubmit="return confirm('<?= escaparPortalSolicitante($confirmacionAprobacion) ?>')">
                            <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                            <input type="hidden" name="accion" value="calificar_cerrar">
                            <input type="hidden" name="id_ticket" value="<?= (int) $ticketSeleccionado['id_ticket'] ?>">
                            <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaPendienteCalificacion['id_ticket_etapa'] ?>">
                            <div class="rating-grid">
                                <div class="field">
                                    <label for="calificacion_area">Gestión del área *</label>
                                    <select id="calificacion_area" name="calificacion_area" required>
                                        <option value="">Seleccione</option>
                                        <?php for ($nota = 5; $nota >= 1; $nota--): ?>
                                            <option value="<?= $nota ?>"><?= $nota ?> - <?= ['','Muy deficiente','Deficiente','Aceptable','Muy buena','Excelente'][$nota] ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="field">
                                    <label for="calificacion_tiempo">Tiempo de respuesta *</label>
                                    <select id="calificacion_tiempo" name="calificacion_tiempo" required>
                                        <option value="">Seleccione</option>
                                        <?php for ($nota = 5; $nota >= 1; $nota--): ?>
                                            <option value="<?= $nota ?>"><?= $nota ?> - <?= ['','Muy deficiente','Deficiente','Aceptable','Muy buena','Excelente'][$nota] ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="field">
                                    <label for="comentario_calificacion">Comentario opcional</label>
                                    <textarea id="comentario_calificacion" name="comentario_calificacion" maxlength="1000" placeholder="Cuéntenos qué estuvo bien o qué debe mejorar."></textarea>
                                </div>
                            </div>
                            <div class="actions"><button class="btn primary" type="submit"><?= escaparPortalSolicitante($textoBotonAprobacion) ?></button></div>
                        </form>
                        <form class="reopen-form" method="post" onsubmit="return confirm('¿Desea devolver esta etapa? El mismo caso volverá al gestor asignado y el SLA se reanudará.')">
                            <input type="hidden" name="csrf_token" value="<?= escaparPortalSolicitante($_SESSION['csrf_token']) ?>">
                            <input type="hidden" name="accion" value="reabrir_caso">
                            <input type="hidden" name="id_ticket" value="<?= (int) $ticketSeleccionado['id_ticket'] ?>">
                            <input type="hidden" name="id_ticket_etapa" value="<?= (int) $etapaPendienteCalificacion['id_ticket_etapa'] ?>">
                            <span class="reopen-title">¿La solución no resolvió su solicitud?</span>
                            <p>Explique el motivo para devolver esta etapa del caso al gestor asignado.</p>
                            <div class="field">
                                <label for="motivo_reapertura">Motivo de reapertura *</label>
                                <textarea id="motivo_reapertura" name="motivo_reapertura" maxlength="1000" required placeholder="Indique qué continúa fallando o por qué la solución no fue suficiente."></textarea>
                            </div>
                            <div class="actions"><button class="btn reopen" type="submit">Devolver etapa</button></div>
                        </form>
                    </div>
                <?php endif; ?>
            </section>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>
</main>
<script type="application/json" id="datos-servicios-solicitud"><?=
    json_encode(
        array_map(
            static function (array $servicio): array {
                $urgenciaValor = max(1, min(3, (int) ($servicio['urgencia_valor'] ?? 2)));
                $impactoValor = max(1, min(3, (int) ($servicio['impacto_valor'] ?? 2)));

                if (function_exists('matrizPrioridadCalcular')) {
                    $matriz = matrizPrioridadCalcular($urgenciaValor, $impactoValor);
                } else {
                    $urgencias = [1 => 'Más tarde', 2 => 'Pronto', 3 => 'Inmediato'];
                    $impactos = [1 => 'Bajo', 2 => 'Moderado', 3 => 'Urgente'];
                    $prioridades = [
                        1 => [1 => 'Bajo', 2 => 'Bajo moderado', 3 => 'Bajo urgente'],
                        2 => [1 => 'Moderado bajo', 2 => 'Moderado', 3 => 'Moderado urgente'],
                        3 => [1 => 'Urgente bajo', 2 => 'Urgente moderado', 3 => 'Urgente'],
                    ];
                    $matriz = [
                        'urgencia_valor' => $urgenciaValor,
                        'urgencia_nombre' => $urgencias[$urgenciaValor],
                        'impacto_valor' => $impactoValor,
                        'impacto_nombre' => $impactos[$impactoValor],
                        'prioridad_valor' => $urgenciaValor + $impactoValor - 1,
                        'prioridad_nombre' => $prioridades[$urgenciaValor][$impactoValor],
                    ];
                }

                return [
                'id_catalogo' => (int) ($servicio['id_catalogo'] ?? 0),
                'id_servicio' => (int) ($servicio['id_servicio'] ?? 0),
                'id_proceso' => (int) ($servicio['id_proceso'] ?? 0),
                'usa_proceso' => (int) ($servicio['id_proceso_etapa'] ?? 0) > 0,
                'nombre' => (string) ($servicio['servicio_nombre'] ?? 'Servicio'),
                'descripcion' => (string) ($servicio['servicio_descripcion'] ?? ''),
                'tipo_solicitud' => (string) ($servicio['tipo_solicitud'] ?? 'requerimiento'),
                'prioridad' => $matriz['prioridad_valor'] . ' · ' . $matriz['prioridad_nombre'],
                'urgencia' => $matriz['urgencia_valor'] . ' · ' . $matriz['urgencia_nombre'],
                'impacto' => $matriz['impacto_valor'] . ' · ' . $matriz['impacto_nombre'],
                'sla' => (string) ($servicio['sla_nombre'] ?? ''),
                ];
            },
            $servicios
        ),
        JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
        | JSON_HEX_TAG
        | JSON_HEX_AMP
        | JSON_HEX_APOS
        | JSON_HEX_QUOT
    )
?></script>
<script>
    (function () {
        'use strict';

        var selectorServicio = document.getElementById('id_proceso');
        var idServicioSeleccionado = document.getElementById('id_servicio');
        var usaProcesoSeleccionado = document.getElementById('usa_proceso');
        var buscadorServicio = document.getElementById('buscador-servicio');
        var contenedorSelectorServicio = document.getElementById('selector-servicio-buscable');
        var listaOpcionesServicio = document.getElementById('opciones-servicio');
        var botonOpcionesServicio = document.getElementById('alternar-opciones-servicio');
        var datosElemento = document.getElementById('datos-servicios-solicitud');
        var estadoServicios = document.getElementById('estado-servicios-catalogo');
        var selectorAreas = document.querySelector('.catalog-picker');
        var catalogos = document.querySelectorAll('[data-catalogo-solicitud]');
        var disposicionServicio = document.querySelector('.service-selection-layout');
        var resumenServicio = document.getElementById('resumen-servicio');
        var resumenNombre = document.getElementById('resumen-servicio-nombre');
        var resumenDescripcion = document.getElementById('resumen-servicio-descripcion');
        var resumenEtiquetas = document.getElementById('resumen-servicio-etiquetas');
        var resumenTipo = document.getElementById('resumen-servicio-tipo');
        var resumenPrioridad = document.getElementById('resumen-servicio-prioridad');
        var resumenUrgencia = document.getElementById('resumen-servicio-urgencia');
        var resumenImpacto = document.getElementById('resumen-servicio-impacto');
        var entradaDescripcion = document.getElementById('descripcion');
        var entradaAdjuntos = document.getElementById('adjuntos');
        var zonaAdjuntos = document.getElementById('zona-adjuntos');
        var listaAdjuntos = document.getElementById('lista-adjuntos');
        var estadoAdjuntos = document.getElementById('estado-adjuntos');
        var formularioSolicitud = document.getElementById('form-nueva-solicitud');
        var botonCrearSolicitud = document.querySelector('[data-create-request-button]');
        var estadoCrearSolicitud = document.querySelector('[data-create-request-status]');
        var servicios = [];
        var serviciosDisponiblesActuales = [];
        var indiceOpcionServicioActiva = -1;
        var archivosSeleccionados = [];
        var caracteresResumenActual = 0;
        var ajusteResumenPendiente = false;

        if (
            !selectorServicio
            || !idServicioSeleccionado
            || !usaProcesoSeleccionado
            || !buscadorServicio
            || !contenedorSelectorServicio
            || !listaOpcionesServicio
            || !botonOpcionesServicio
            || !datosElemento
            || !estadoServicios
            || !catalogos.length
        ) {
            return;
        }

        try {
            servicios = JSON.parse(datosElemento.textContent || '[]');
        } catch (error) {
            servicios = [];
        }

        function agregarOpcion(valor, texto) {
            var opcion = document.createElement('option');
            opcion.value = String(valor || '');
            opcion.textContent = texto;
            selectorServicio.appendChild(opcion);
        }

        function normalizarNombreServicio(valor) {
            return String(valor || '')
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .toLocaleLowerCase('es')
                .trim()
                .replace(/\s+/g, ' ');
        }

        function puntuarNombreServicio(nombre, consulta) {
            var nombreNormalizado = normalizarNombreServicio(nombre);
            var consultaNormalizada = normalizarNombreServicio(consulta);

            if (!consultaNormalizada) return 50;
            if (nombreNormalizado === consultaNormalizada) return 0;
            if (nombreNormalizado.indexOf(consultaNormalizada) === 0) return 10;

            var palabrasNombre = nombreNormalizado.split(' ');
            if (palabrasNombre.some(function (palabra) {
                return palabra.indexOf(consultaNormalizada) === 0;
            })) {
                return 20;
            }

            if (nombreNormalizado.indexOf(consultaNormalizada) !== -1) return 30;

            var palabrasConsulta = consultaNormalizada.split(' ').filter(Boolean);
            var todasCoinciden = palabrasConsulta.every(function (palabraConsulta) {
                return palabrasNombre.some(function (palabraNombre) {
                    return palabraNombre.indexOf(palabraConsulta) === 0
                        || palabraNombre.indexOf(palabraConsulta) !== -1;
                });
            });

            return todasCoinciden ? 40 : Number.POSITIVE_INFINITY;
        }

        function abrirOpcionesServicio() {
            if (buscadorServicio.disabled) return;
            sincronizarColumnasConAreas();
            ajustarVentanaOpcionesServicio();
            contenedorSelectorServicio.classList.add('is-open');
            buscadorServicio.setAttribute('aria-expanded', 'true');
        }

        function cerrarOpcionesServicio() {
            contenedorSelectorServicio.classList.remove('is-open');
            contenedorSelectorServicio.classList.remove('opens-up');
            buscadorServicio.setAttribute('aria-expanded', 'false');
            indiceOpcionServicioActiva = -1;
        }

        function actualizarOpcionServicioActiva(opciones) {
            opciones.forEach(function (opcion, indice) {
                opcion.classList.toggle('is-active', indice === indiceOpcionServicioActiva);
            });

            if (indiceOpcionServicioActiva >= 0 && opciones[indiceOpcionServicioActiva]) {
                opciones[indiceOpcionServicioActiva].scrollIntoView({block:'nearest'});
            }
        }

        function seleccionarServicio(servicio) {
            if (!servicio) return;

            selectorServicio.value = String(servicio.id_proceso);
            idServicioSeleccionado.value = String(servicio.id_servicio);
            usaProcesoSeleccionado.value = servicio.usa_proceso ? '1' : '0';
            buscadorServicio.value = servicio.nombre || '';
            buscadorServicio.setCustomValidity('');
            selectorServicio.dispatchEvent(new Event('change', {bubbles:true}));
            cerrarOpcionesServicio();
        }

        function renderizarOpcionesServicio(consulta) {
            var consultaNormalizada = normalizarNombreServicio(consulta);
            var resultados = serviciosDisponiblesActuales
                .map(function (servicio, posicionOriginal) {
                    return {
                        servicio: servicio,
                        puntuacion: puntuarNombreServicio(servicio.nombre, consultaNormalizada),
                        posicionOriginal: posicionOriginal
                    };
                })
                .filter(function (resultado) {
                    return Number.isFinite(resultado.puntuacion);
                })
                .sort(function (a, b) {
                    if (a.puntuacion !== b.puntuacion) {
                        return a.puntuacion - b.puntuacion;
                    }
                    /*
                     * Sin una búsqueda, presenta todo el catálogo por nombre
                     * para que sea fácil recorrerlo. Cuando existe una
                     * consulta, conserva primero las coincidencias más
                     * relevantes y usa el nombre como segundo criterio.
                     */
                    var comparacionNombre = String(a.servicio.nombre || '').localeCompare(
                        String(b.servicio.nombre || ''),
                        'es',
                        {sensitivity:'base'}
                    );

                    return comparacionNombre !== 0
                        ? comparacionNombre
                        : a.posicionOriginal - b.posicionOriginal;
                });

            listaOpcionesServicio.innerHTML = '';
            indiceOpcionServicioActiva = -1;

            if (!resultados.length) {
                var vacio = document.createElement('p');
                vacio.className = 'service-combobox-empty';
                vacio.textContent = 'No hay servicios cuyo nombre coincida con “' + String(consulta || '').trim() + '”.';
                listaOpcionesServicio.appendChild(vacio);
                return;
            }

            resultados.forEach(function (resultado) {
                var opcion = document.createElement('button');
                var servicio = resultado.servicio;
                opcion.type = 'button';
                opcion.className = 'service-combobox-option';
                opcion.setAttribute('role', 'option');
                opcion.setAttribute(
                    'aria-selected',
                    String(
                        Number(selectorServicio.value) === Number(servicio.id_proceso)
                        && Number(idServicioSeleccionado.value) === Number(servicio.id_servicio)
                    )
                );
                opcion.dataset.idProceso = String(servicio.id_proceso);
                opcion.dataset.idServicio = String(servicio.id_servicio);
                opcion.textContent = servicio.nombre;
                opcion.addEventListener('mousedown', function (evento) {
                    evento.preventDefault();
                });
                opcion.addEventListener('click', function () {
                    seleccionarServicio(servicio);
                    buscadorServicio.focus();
                });
                listaOpcionesServicio.appendChild(opcion);
            });
        }

        function etiquetaTipo(valor) {
            var texto = String(valor || '').trim().replace(/[_-]+/g, ' ');
            return texto ? texto.charAt(0).toUpperCase() + texto.slice(1) : 'Sin clasificación';
        }

        function sincronizarColumnasConAreas() {
            if (!disposicionServicio || !selectorAreas || window.innerWidth <= 760) {
                if (disposicionServicio) {
                    disposicionServicio.style.removeProperty('--service-selector-width');
                    disposicionServicio.style.removeProperty('--service-column-gap');
                    disposicionServicio.style.removeProperty('--service-dropdown-width');
                }
                return;
            }

            var primeraArea = selectorAreas.querySelector('.catalog-choice');
            if (!primeraArea) return;

            var estiloAreas = window.getComputedStyle(selectorAreas);
            var separacionAreas = parseFloat(estiloAreas.columnGap || estiloAreas.gap) || 10;
            var anchoPrimeraArea = primeraArea.getBoundingClientRect().width;
            var limiteDerechoAreas = selectorAreas.getBoundingClientRect().right;
            var inicioSelector = contenedorSelectorServicio.getBoundingClientRect().left;

            if (anchoPrimeraArea > 0) {
                var anchoTresAreas = (anchoPrimeraArea * 3) + (separacionAreas * 2);
                var anchoDisponible = Math.max(
                    anchoPrimeraArea,
                    limiteDerechoAreas - inicioSelector
                );

                disposicionServicio.style.setProperty(
                    '--service-selector-width',
                    Math.round(anchoPrimeraArea) + 'px'
                );
                disposicionServicio.style.setProperty(
                    '--service-column-gap',
                    separacionAreas + 'px'
                );
                disposicionServicio.style.setProperty(
                    '--service-dropdown-width',
                    Math.round(Math.min(anchoTresAreas, anchoDisponible)) + 'px'
                );
            }
        }

        function ajustarVentanaOpcionesServicio() {
            if (!contenedorSelectorServicio || !listaOpcionesServicio) {
                return;
            }

            var rectanguloSelector = contenedorSelectorServicio.getBoundingClientRect();
            var margenVentana = 14;
            var espacioDebajo = Math.max(
                60,
                window.innerHeight - rectanguloSelector.bottom - margenVentana - 5
            );
            var espacioEncima = Math.max(
                60,
                rectanguloSelector.top - margenVentana - 5
            );
            var abrirHaciaArriba = espacioDebajo < 190 && espacioEncima > espacioDebajo;
            var espacioElegido = abrirHaciaArriba ? espacioEncima : espacioDebajo;

            contenedorSelectorServicio.classList.toggle('opens-up', abrirHaciaArriba);
            contenedorSelectorServicio.style.setProperty(
                '--service-dropdown-left-space',
                Math.max(8, Math.round(rectanguloSelector.left)) + 'px'
            );
            contenedorSelectorServicio.style.setProperty(
                '--service-dropdown-max-height',
                Math.round(Math.min(520, espacioElegido)) + 'px'
            );
        }

        function ajustarTamanoResumen() {
            if (!resumenServicio || resumenServicio.classList.contains('empty')) {
                return;
            }

            var contenedor = resumenServicio.parentElement;
            var campoSelector = selectorServicio ? selectorServicio.closest('.field') : null;

            if (!contenedor || !campoSelector || window.innerWidth <= 760) {
                resumenServicio.style.setProperty('--service-summary-width', '100%');
                return;
            }

            var estiloContenedor = window.getComputedStyle(contenedor);
            var separacion = parseFloat(estiloContenedor.columnGap || estiloContenedor.gap) || 12;
            var anchoDisponible = Math.max(
                0,
                contenedor.clientWidth - campoSelector.getBoundingClientRect().width - separacion
            );
            var anchoMinimo = Math.min(anchoDisponible, 600);

            /*
             * Entre 90 y 610 caracteres la tarjeta crece proporcionalmente.
             * Desde 610 caracteres ocupa toda la segunda columna, alineándose
             * exactamente con el borde derecho de las tarjetas de áreas.
             */
            var proporcion = Math.max(0, Math.min(1, (caracteresResumenActual - 90) / 520));
            var anchoCalculado = Math.round(
                anchoMinimo + ((anchoDisponible - anchoMinimo) * proporcion)
            );

            resumenServicio.style.setProperty(
                '--service-summary-width',
                Math.max(anchoMinimo, anchoCalculado) + 'px'
            );
        }

        function mostrarResumen(servicio) {
            if (!resumenServicio || !resumenNombre || !resumenDescripcion) {
                return;
            }

            resumenServicio.style.removeProperty('--service-summary-width');
            resumenServicio.style.removeProperty('height');
            resumenDescripcion.classList.remove('is-scrollable');

            if (!servicio) {
                caracteresResumenActual = 0;
                resumenServicio.classList.add('empty');
                resumenNombre.textContent = 'Seleccione un servicio para que aparezca la información de él en este apartado.';
                resumenDescripcion.textContent = '';
                resumenDescripcion.hidden = true;
                if (resumenEtiquetas) resumenEtiquetas.hidden = true;
                return;
            }

            var descripcion = String(servicio.descripcion || '').trim()
                || 'El administrador no registró una descripción para este servicio.';
            var caracteres = descripcion.length;
            caracteresResumenActual = caracteres;

            resumenServicio.classList.remove('empty');
            resumenNombre.textContent = servicio.nombre || 'Servicio';
            resumenDescripcion.textContent = descripcion;
            resumenDescripcion.hidden = false;
            resumenTipo.textContent = etiquetaTipo(servicio.tipo_solicitud);
            resumenPrioridad.textContent = 'Prioridad: ' + (servicio.prioridad_nombre || 'Moderado');
            resumenUrgencia.textContent = 'Urgencia: ' + (servicio.urgencia_nombre || 'Pronto');
            if (resumenImpacto) {
                resumenImpacto.textContent = 'Impacto: ' + (servicio.impacto_nombre || 'Moderado');
            }
            resumenEtiquetas.hidden = false;

            requestAnimationFrame(function () {
                sincronizarColumnasConAreas();
                ajustarTamanoResumen();
                resumenDescripcion.classList.toggle(
                    'is-scrollable',
                    resumenDescripcion.scrollHeight > resumenDescripcion.clientHeight + 1
                );
            });
        }

        window.addEventListener('resize', function () {
            if (ajusteResumenPendiente) return;
            ajusteResumenPendiente = true;
            requestAnimationFrame(function () {
                ajusteResumenPendiente = false;
                sincronizarColumnasConAreas();
                ajustarTamanoResumen();
                if (contenedorSelectorServicio.classList.contains('is-open')) {
                    ajustarVentanaOpcionesServicio();
                }
            });
        });

        function cargarServicios(idCatalogo) {
            var disponibles = servicios.filter(function (servicio) {
                return Number(servicio.id_catalogo) === Number(idCatalogo)
                    && Number(servicio.id_proceso) > 0;
            });

            serviciosDisponiblesActuales = disponibles;
            selectorServicio.innerHTML = '';
            idServicioSeleccionado.value = '';
            usaProcesoSeleccionado.value = '';
            selectorServicio.disabled = disponibles.length === 0;
            buscadorServicio.disabled = disponibles.length === 0;
            botonOpcionesServicio.disabled = disponibles.length === 0;
            buscadorServicio.value = '';
            buscadorServicio.setCustomValidity('');
            buscadorServicio.placeholder = disponibles.length
                ? 'Escriba o seleccione un servicio'
                : 'No hay servicios disponibles';
            listaOpcionesServicio.innerHTML = '';
            cerrarOpcionesServicio();
            estadoServicios.classList.toggle('warning', disponibles.length === 0);
            mostrarResumen(null);

            if (!disponibles.length) {
                agregarOpcion('', 'No hay servicios disponibles en esta área');
                estadoServicios.textContent = 'Esta área todavía no tiene servicios habilitados con flujo, gestor y SLA.';
                return;
            }

            agregarOpcion('', 'Seleccione un servicio');
            disponibles.forEach(function (servicio) {
                agregarOpcion(servicio.id_proceso, servicio.nombre);
            });
            renderizarOpcionesServicio('');
            estadoServicios.textContent = disponibles.length === 1
                ? 'Se encontró 1 servicio disponible.'
                : 'Se encontraron ' + disponibles.length + ' servicios disponibles.';
        }

        selectorServicio.addEventListener('change', function () {
            var seleccionado = servicios.find(function (servicio) {
                return Number(servicio.id_proceso) === Number(selectorServicio.value)
                    && Number(servicio.id_servicio) === Number(idServicioSeleccionado.value);
            });
            mostrarResumen(seleccionado || null);
        });

        function abrirSelectorParaCambiarServicio() {
            var hayServicioSeleccionado = selectorServicio.value !== '';

            /*
             * El nombre ya elegido no debe convertirse en un filtro al
             * reabrir el selector. En ese caso se muestra nuevamente todo el
             * catálogo del área y se marca el texto para reemplazarlo al
             * escribir.
             */
            renderizarOpcionesServicio(
                hayServicioSeleccionado ? '' : buscadorServicio.value
            );
            abrirOpcionesServicio();

            if (hayServicioSeleccionado) {
                requestAnimationFrame(function () {
                    buscadorServicio.select();
                });
            }
        }

        buscadorServicio.addEventListener('focus', function () {
            abrirSelectorParaCambiarServicio();
        });

        buscadorServicio.addEventListener('click', function () {
            abrirSelectorParaCambiarServicio();
        });

        buscadorServicio.addEventListener('input', function () {
            selectorServicio.value = '';
            idServicioSeleccionado.value = '';
            usaProcesoSeleccionado.value = '';
            selectorServicio.dispatchEvent(new Event('change', {bubbles:true}));
            buscadorServicio.setCustomValidity(
                buscadorServicio.value.trim() === ''
                    ? 'Seleccione un servicio de la lista.'
                    : 'Seleccione una de las coincidencias mostradas.'
            );
            renderizarOpcionesServicio(buscadorServicio.value);
            abrirOpcionesServicio();
        });

        buscadorServicio.addEventListener('keydown', function (evento) {
            if (evento.key === 'ArrowDown' || evento.key === 'ArrowUp') {
                evento.preventDefault();
                if (!contenedorSelectorServicio.classList.contains('is-open')) {
                    abrirSelectorParaCambiarServicio();
                }

                var opciones = Array.from(
                    listaOpcionesServicio.querySelectorAll('.service-combobox-option')
                );
                if (!opciones.length) return;

                var incremento = evento.key === 'ArrowDown' ? 1 : -1;
                indiceOpcionServicioActiva = indiceOpcionServicioActiva < 0
                    ? (incremento > 0 ? 0 : opciones.length - 1)
                    : (indiceOpcionServicioActiva + incremento + opciones.length) % opciones.length;
                actualizarOpcionServicioActiva(opciones);
                return;
            }

            if (evento.key === 'Enter' && contenedorSelectorServicio.classList.contains('is-open')) {
                var opciones = Array.from(
                    listaOpcionesServicio.querySelectorAll('.service-combobox-option')
                );
                if (indiceOpcionServicioActiva >= 0 && opciones[indiceOpcionServicioActiva]) {
                    evento.preventDefault();
                    opciones[indiceOpcionServicioActiva].click();
                }
                return;
            }

            if (evento.key === 'Escape') {
                cerrarOpcionesServicio();
            }
        });

        botonOpcionesServicio.addEventListener('click', function () {
            if (contenedorSelectorServicio.classList.contains('is-open')) {
                cerrarOpcionesServicio();
                return;
            }

            abrirSelectorParaCambiarServicio();
            buscadorServicio.focus();
        });

        document.addEventListener('click', function (evento) {
            if (!contenedorSelectorServicio.contains(evento.target)) {
                cerrarOpcionesServicio();
            }
        });

        if (formularioSolicitud) {
            formularioSolicitud.addEventListener('submit', function (evento) {
                if (!selectorServicio.value || !idServicioSeleccionado.value) {
                    evento.preventDefault();
                    buscadorServicio.setCustomValidity('Seleccione un servicio de la lista.');
                    buscadorServicio.reportValidity();
                    buscadorServicio.focus();
                    renderizarOpcionesServicio(buscadorServicio.value);
                    abrirOpcionesServicio();
                }
            });
        }

        catalogos.forEach(function (catalogo) {
            catalogo.addEventListener('change', function () {
                if (catalogo.checked) {
                    cargarServicios(catalogo.value);
                    buscadorServicio.focus();
                }
            });
        });

        for (var indice = 0; indice < catalogos.length; indice += 1) {
            if (catalogos[indice].checked) {
                cargarServicios(catalogos[indice].value);
                break;
            }
        }

        sincronizarColumnasConAreas();

        function ajustarAlturaDescripcion() {
            if (!entradaDescripcion) return;
            entradaDescripcion.style.height = '64px';
            var alturaNecesaria = Math.min(entradaDescripcion.scrollHeight, 360);
            entradaDescripcion.style.height = Math.max(64, alturaNecesaria) + 'px';
            entradaDescripcion.classList.toggle('is-scrollable', entradaDescripcion.scrollHeight > 360);
        }

        if (entradaDescripcion) {
            entradaDescripcion.addEventListener('input', ajustarAlturaDescripcion);
            ajustarAlturaDescripcion();
        }

        function formatoTamano(bytes) {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
            return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
        }

        function sincronizarAdjuntos() {
            if (!entradaAdjuntos || !listaAdjuntos || !estadoAdjuntos) return;

            if (typeof DataTransfer !== 'undefined') {
                var transferencia = new DataTransfer();
                archivosSeleccionados.forEach(function (archivo) {
                    transferencia.items.add(archivo);
                });
                entradaAdjuntos.files = transferencia.files;
            }

            listaAdjuntos.innerHTML = '';
            listaAdjuntos.hidden = archivosSeleccionados.length === 0;

            archivosSeleccionados.forEach(function (archivo, indiceArchivo) {
                var item = document.createElement('div');
                item.className = 'file-item';
                var datos = document.createElement('span');
                var nombre = document.createElement('strong');
                var tamano = document.createElement('small');
                var quitar = document.createElement('button');
                nombre.textContent = archivo.name;
                tamano.textContent = formatoTamano(archivo.size);
                quitar.type = 'button';
                quitar.className = 'file-remove';
                quitar.setAttribute('aria-label', 'Quitar ' + archivo.name);
                quitar.textContent = '×';
                quitar.addEventListener('click', function () {
                    archivosSeleccionados.splice(indiceArchivo, 1);
                    sincronizarAdjuntos();
                });
                datos.appendChild(nombre);
                datos.appendChild(tamano);
                item.appendChild(datos);
                item.appendChild(quitar);
                listaAdjuntos.appendChild(item);
            });

            estadoAdjuntos.classList.remove('error');
            estadoAdjuntos.textContent = archivosSeleccionados.length
                ? archivosSeleccionados.length + ' de 5 archivos seleccionados.'
                : 'Máximo cinco archivos de 5 MB cada uno.';
        }

        function agregarArchivos(archivos) {
            if (!estadoAdjuntos) return;
            var rechazados = [];
            var extensionesPermitidas = [
                'pdf', 'jpg', 'jpeg', 'png', 'webp', 'txt', 'csv', 'zip',
                'doc', 'docx', 'xls', 'xlsx'
            ];

            Array.from(archivos || []).forEach(function (archivo) {
                var partesNombre = archivo.name.toLowerCase().split('.');
                var extension = partesNombre.length > 1 ? partesNombre.pop() : '';
                var repetido = archivosSeleccionados.some(function (actual) {
                    return actual.name === archivo.name
                        && actual.size === archivo.size
                        && actual.lastModified === archivo.lastModified;
                });

                if (repetido) return;
                if (!extensionesPermitidas.includes(extension)) {
                    rechazados.push(archivo.name + ' no tiene un formato permitido');
                    return;
                }
                if (archivo.size > 5 * 1024 * 1024) {
                    rechazados.push(archivo.name + ' supera 5 MB');
                    return;
                }
                if (archivosSeleccionados.length >= 5) {
                    rechazados.push('Solo se permiten cinco archivos');
                    return;
                }
                archivosSeleccionados.push(archivo);
            });

            sincronizarAdjuntos();
            if (rechazados.length) {
                estadoAdjuntos.classList.add('error');
                estadoAdjuntos.textContent = rechazados.join('. ') + '.';
            }
        }

        if (entradaAdjuntos && zonaAdjuntos) {
            entradaAdjuntos.addEventListener('change', function () {
                agregarArchivos(entradaAdjuntos.files);
            });
            ['dragenter', 'dragover'].forEach(function (evento) {
                zonaAdjuntos.addEventListener(evento, function (event) {
                    event.preventDefault();
                    zonaAdjuntos.classList.add('dragover');
                });
            });
            ['dragleave', 'drop'].forEach(function (evento) {
                zonaAdjuntos.addEventListener(evento, function (event) {
                    event.preventDefault();
                    zonaAdjuntos.classList.remove('dragover');
                });
            });
            zonaAdjuntos.addEventListener('drop', function (event) {
                agregarArchivos(event.dataTransfer ? event.dataTransfer.files : []);
            });
        }

        formularioSolicitud?.addEventListener('submit', function (event) {
            if (formularioSolicitud.dataset.sending === 'true') {
                event.preventDefault();
                return;
            }

            if (!formularioSolicitud.checkValidity()) {
                return;
            }

            formularioSolicitud.dataset.sending = 'true';
            formularioSolicitud.setAttribute('aria-busy', 'true');

            if (botonCrearSolicitud) {
                botonCrearSolicitud.disabled = true;
                botonCrearSolicitud.textContent = 'Creando solicitud…';
            }

            if (estadoCrearSolicitud) {
                estadoCrearSolicitud.textContent = 'Espere un momento. No cierre ni vuelva a enviar el formulario.';
            }
        });
    }());
</script>
<script>
    (function () {
        'use strict';

        window.__MESA_SOLICITANTE_ESTADO_MODAL_VERSION__ = '2026-08-21.1';

        var entradaBusqueda = document.getElementById('buscar-casos');
        var selectorEstado = document.getElementById('estado-casos');
        var botonesEstado = Array.from(document.querySelectorAll('[data-case-filter-state]'));
        var botonLimpiar = document.getElementById('limpiar-filtro-casos');
        var contadorCasos = document.getElementById('contador-casos');
        var filaSinResultados = document.getElementById('sin-resultados-casos');
        var filasCasos = Array.from(document.querySelectorAll('[data-case-row]'));
        var tareaFiltro = 0;

        function normalizarTexto(valor) {
            return String(valor || '')
                .toLocaleLowerCase('es')
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .trim();
        }

        function guardarFiltrosEnUrl() {
            if (window.top !== window.self) {
                return;
            }
            if (!window.history || typeof window.history.replaceState !== 'function') {
                return;
            }

            var url = new URL(window.location.href);
            var busqueda = entradaBusqueda ? entradaBusqueda.value.trim() : '';
            var estado = selectorEstado ? selectorEstado.value : 'todos';

            if (busqueda) {
                url.searchParams.set('buscar', busqueda);
            } else {
                url.searchParams.delete('buscar');
            }

            if (estado && estado !== 'todos') {
                url.searchParams.set('estado_busqueda', estado);
            } else {
                url.searchParams.delete('estado_busqueda');
            }

            window.history.replaceState({}, '', url.toString());
        }

        function aplicarFiltros(persistir) {
            if (!entradaBusqueda || !selectorEstado || !filasCasos.length) {
                return;
            }

            var texto = normalizarTexto(entradaBusqueda.value);
            var numeroCaso = texto
                .replace(/^caso\s*/u, '')
                .replace(/^#/u, '')
                .trim();
            var buscarCasoExacto = texto !== '' && /^\d+$/.test(numeroCaso);
            var estado = selectorEstado.value || 'todos';
            var visibles = 0;

            filasCasos.forEach(function (fila) {
                var coincideTexto = !texto;

                if (!coincideTexto && buscarCasoExacto) {
                    coincideTexto = String(fila.dataset.ticketId || '') === numeroCaso;
                } else if (!coincideTexto) {
                    coincideTexto = normalizarTexto(fila.textContent).includes(texto);
                }
                var coincideEstado = estado === 'todos'
                    || fila.dataset.caseCategory === estado;
                var visible = coincideTexto && coincideEstado;
                fila.hidden = !visible;

                if (visible) {
                    visibles += 1;
                }
            });

            if (contadorCasos) {
                contadorCasos.textContent = visibles === 1
                    ? '1 caso encontrado'
                    : visibles + ' casos encontrados';
            }

            if (filaSinResultados) {
                filaSinResultados.hidden = visibles !== 0;
            }

            if (botonLimpiar) {
                botonLimpiar.hidden = entradaBusqueda.value.length === 0;
            }

            botonesEstado.forEach(function (botonEstado) {
                var activo = botonEstado.dataset.caseFilterState === estado;
                botonEstado.classList.toggle('is-active', activo);
                botonEstado.setAttribute('aria-pressed', activo ? 'true' : 'false');
            });

            if (persistir) {
                guardarFiltrosEnUrl();
            }
        }

        function programarFiltro() {
            if (tareaFiltro) {
                window.cancelAnimationFrame(tareaFiltro);
            }

            tareaFiltro = window.requestAnimationFrame(function () {
                tareaFiltro = 0;
                aplicarFiltros(true);
            });
        }

        if (entradaBusqueda && selectorEstado && filasCasos.length) {
            entradaBusqueda.addEventListener('input', programarFiltro);
            selectorEstado.addEventListener('change', function () {
                aplicarFiltros(true);
            });
            botonesEstado.forEach(function (botonEstado) {
                botonEstado.addEventListener('click', function () {
                    selectorEstado.value = botonEstado.dataset.caseFilterState || 'todos';
                    aplicarFiltros(true);
                });
            });

            if (botonLimpiar) {
                botonLimpiar.addEventListener('click', function () {
                    entradaBusqueda.value = '';
                    aplicarFiltros(true);
                    entradaBusqueda.focus();
                });
            }

            document.querySelectorAll('[data-case-view]').forEach(function (enlace) {
                enlace.addEventListener('click', function () {
                    var url = new URL(enlace.dataset.mesaRoute || enlace.href, window.location.href);
                    var busqueda = entradaBusqueda.value.trim();
                    var estado = selectorEstado.value || 'todos';

                    if (busqueda) {
                        url.searchParams.set('buscar', busqueda);
                    } else {
                        url.searchParams.delete('buscar');
                    }

                    if (estado !== 'todos') {
                        url.searchParams.set('estado_busqueda', estado);
                    } else {
                        url.searchParams.delete('estado_busqueda');
                    }

                    enlace.dataset.mesaRoute = url.toString();
                    enlace.href = url.toString();
                });
            });

            aplicarFiltros(false);
        }

        var modalCaso = document.getElementById('modal-estado-caso');

        if (!modalCaso) {
            return;
        }

        var chatWidget = modalCaso.querySelector('[data-chat-widget]');
        var botonAbrirChat = modalCaso.querySelector('[data-chat-open]');
        var botonCerrarChat = chatWidget?.querySelector('[data-chat-close]');
        var panelChat = chatWidget?.querySelector('.chat-panel');
        var lineaTiempoChat = chatWidget?.querySelector('[data-chat-timeline]');
        var formularioChat = chatWidget?.querySelector('[data-chat-compose]');
        var textoChat = formularioChat?.querySelector('textarea');
        var entradaArchivosChat = formularioChat?.querySelector('[data-chat-file-input]');
        var estadoArchivosChat = formularioChat?.querySelector('[data-chat-file-status]');

        function ajustarTextoChat() {
            if (!textoChat) {
                return;
            }

            textoChat.style.height = '38px';
            textoChat.style.height = Math.min(textoChat.scrollHeight, 112) + 'px';
        }

        function abrirChat() {
            if (!chatWidget || !panelChat) {
                return;
            }

            chatWidget.classList.add('is-open');
            panelChat.setAttribute('aria-hidden', 'false');
            botonAbrirChat?.setAttribute('aria-expanded', 'true');
            if (botonAbrirChat) {
                botonAbrirChat.hidden = true;
            }
            window.requestAnimationFrame(function () {
                if (lineaTiempoChat) {
                    lineaTiempoChat.scrollTop = lineaTiempoChat.scrollHeight;
                }
                (textoChat || botonCerrarChat)?.focus();
            });
        }

        function cerrarChat() {
            if (!chatWidget || !panelChat) {
                return;
            }

            chatWidget.classList.remove('is-open');
            panelChat.setAttribute('aria-hidden', 'true');
            botonAbrirChat?.setAttribute('aria-expanded', 'false');
            if (botonAbrirChat) {
                botonAbrirChat.hidden = false;
            }
            botonAbrirChat?.focus();
        }

        botonAbrirChat?.addEventListener('click', abrirChat);
        botonCerrarChat?.addEventListener('click', cerrarChat);
        textoChat?.addEventListener('input', ajustarTextoChat);
        textoChat?.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                formularioChat?.requestSubmit();
            }
        });
        entradaArchivosChat?.addEventListener('change', function () {
            if (!estadoArchivosChat) {
                return;
            }

            var nombres = Array.from(entradaArchivosChat.files || [])
                .map(function (archivo) { return archivo.name; });
            estadoArchivosChat.textContent = nombres.length
                ? nombres.length + ' archivo(s): ' + nombres.join(', ')
                : '';
        });
        var usuarioActualChat = {
            id: <?= (int) $idUsuario ?>,
            nombre: <?= json_encode($nombreUsuario, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
            rol: 'Solicitante'
        };

        function crearAutorActualChat() {
            var fila = document.createElement('span');
            fila.className = 'chat-author-row';

            var imagen = document.createElement('img');
            imagen.className = 'chat-profile-image';
            imagen.src = 'imagenPerfil.php?usuario=' + usuarioActualChat.id;
            imagen.alt = 'Foto de ' + usuarioActualChat.nombre;

            var copia = document.createElement('span');
            copia.className = 'chat-author-copy';

            var nombre = document.createElement('strong');
            nombre.textContent = usuarioActualChat.nombre || 'Solicitante';

            var rol = document.createElement('small');
            rol.textContent = usuarioActualChat.rol;

            copia.append(nombre, rol);
            fila.append(imagen, copia);
            return fila;
        }

        function agregarEnvioOptimistaChat(mensaje, archivos) {
            if (!lineaTiempoChat) {
                return [];
            }

            lineaTiempoChat.querySelector('.chat-empty')?.remove();
            var burbujas = [];
            var crearHora = function (articulo) {
                var hora = document.createElement('span');
                hora.className = 'chat-time';
                hora.textContent = 'Enviando…';
                articulo.appendChild(hora);
            };

            if (mensaje) {
                var burbujaMensaje = document.createElement('article');
                burbujaMensaje.className = 'chat-bubble mine is-pending';
                burbujaMensaje.dataset.mesaOwnMessage = '1';
                var autor = crearAutorActualChat();
                var texto = document.createElement('p');
                texto.className = 'chat-text';
                texto.textContent = mensaje;
                burbujaMensaje.append(autor, texto);
                crearHora(burbujaMensaje);
                lineaTiempoChat.appendChild(burbujaMensaje);
                burbujas.push(burbujaMensaje);
            }

            archivos.forEach(function (archivo) {
                var burbujaArchivo = document.createElement('article');
                burbujaArchivo.className = 'chat-bubble is-file mine is-pending';
                burbujaArchivo.dataset.mesaOwnMessage = '1';
                var autor = crearAutorActualChat();
                var tarjeta = document.createElement('span');
                tarjeta.className = 'chat-file-card';
                var icono = document.createElement('span');
                icono.className = 'chat-file-icon';
                icono.textContent = '📎';
                var copia = document.createElement('span');
                copia.className = 'chat-file-copy';
                var nombre = document.createElement('strong');
                nombre.textContent = archivo.name;
                var tipo = document.createElement('span');
                tipo.textContent = 'Archivo adjunto';
                copia.append(nombre, tipo);
                tarjeta.append(icono, copia);
                burbujaArchivo.append(autor, tarjeta);
                crearHora(burbujaArchivo);
                lineaTiempoChat.appendChild(burbujaArchivo);
                burbujas.push(burbujaArchivo);
            });

            lineaTiempoChat.scrollTop = lineaTiempoChat.scrollHeight;
            return burbujas;
        }

        formularioChat?.addEventListener('submit', async function (event) {
            event.preventDefault();

            if (formularioChat.dataset.sending === 'true') {
                return;
            }

            var mensaje = (textoChat?.value || '').trim();
            var archivos = Array.from(entradaArchivosChat?.files || []);

            if (!mensaje && archivos.length === 0) {
                textoChat?.focus();
                return;
            }

            var datos = new FormData(formularioChat);
            var burbujas = agregarEnvioOptimistaChat(mensaje, archivos);
            var botonEnviar = formularioChat.querySelector('.chat-send');
            formularioChat.dataset.sending = 'true';

            if (botonEnviar) {
                botonEnviar.disabled = true;
            }
            if (textoChat) {
                textoChat.value = '';
                ajustarTextoChat();
            }
            if (estadoArchivosChat) {
                estadoArchivosChat.textContent = 'Enviando…';
            }

            try {
                var respuesta = await fetch(formularioChat.action || window.location.href, {
                    method: 'POST',
                    body: datos,
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    credentials: 'same-origin'
                });
                var resultado = await respuesta.json().catch(function () {
                    return {};
                });

                if (!respuesta.ok || resultado.ok !== true) {
                    throw new Error(resultado.message || 'No fue posible enviar el mensaje.');
                }

                burbujas.forEach(function (burbuja) {
                    burbuja.classList.remove('is-pending');
                    var hora = burbuja.querySelector('.chat-time');
                    if (hora) {
                        hora.textContent = resultado.sent_at || 'Ahora';
                        var marca = document.createElement('span');
                        marca.className = 'read-mark';
                        marca.setAttribute('aria-label', 'Enviado');
                        marca.textContent = '✓';
                        hora.appendChild(marca);
                    }
                });
                formularioChat.reset();
                if (estadoArchivosChat) {
                    estadoArchivosChat.textContent = '';
                }
            } catch (error) {
                burbujas.forEach(function (burbuja) { burbuja.remove(); });
                if (textoChat && textoChat.value === '') {
                    textoChat.value = mensaje;
                    ajustarTextoChat();
                }
                if (estadoArchivosChat) {
                    estadoArchivosChat.textContent = error instanceof Error
                        ? error.message
                        : 'No fue posible enviar el mensaje.';
                }
            } finally {
                formularioChat.dataset.sending = 'false';
                if (botonEnviar) {
                    botonEnviar.disabled = false;
                }
                textoChat?.focus();
            }
        });

        if (chatWidget?.dataset.autoOpen === 'true') {
            abrirChat();
        }

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                if (chatWidget?.classList.contains('is-open')) {
                    event.preventDefault();
                    cerrarChat();
                }
            }
        });
    }());
</script>
<?php if ($ticketSeleccionado): ?>
<script>
    (function () {
        'use strict';

        var ticketId = <?= (int) $ticketSeleccionado['id_ticket'] ?>;
        var restoreKey = 'mesa-case-live-chat:' + ticketId + ':' + window.location.pathname;
        var knownRevision = '';
        var requestRunning = false;
        var pageLeaving = false;

        function restoreChat() {
            if (window.sessionStorage.getItem(restoreKey) !== '1') {
                return;
            }
            window.sessionStorage.removeItem(restoreKey);
            window.setTimeout(function () {
                document.querySelector('[data-chat-open]')?.click();
            }, 90);
        }

        function saveChatState() {
            var chat = document.querySelector('[data-chat-widget]');
            if (chat && chat.classList.contains('is-open')) {
                window.sessionStorage.setItem(restoreKey, '1');
            } else {
                window.sessionStorage.removeItem(restoreKey);
            }
        }

        async function checkCaseRevision() {
            if (requestRunning || pageLeaving || document.visibilityState !== 'visible') {
                return;
            }
            requestRunning = true;

            try {
                var params = new URLSearchParams({
                    action: 'case_revision',
                    id_ticket: String(ticketId),
                    _: String(Date.now())
                });
                var response = await fetch('mensajesApi.php?' + params.toString(), {
                    cache: 'no-store',
                    credentials: 'same-origin',
                    headers: {'Accept': 'application/json'}
                });
                var result = await response.json().catch(function () { return {}; });
                if (!response.ok || result.ok !== true || !result.revision) {
                    return;
                }

                if (knownRevision === '') {
                    knownRevision = result.revision;
                    return;
                }

                if (knownRevision !== result.revision) {
                    pageLeaving = true;
                    saveChatState();
                    window.location.reload();
                }
            } finally {
                requestRunning = false;
            }
        }

        document.addEventListener('submit', function () { pageLeaving = true; }, true);
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'visible') {
                void checkCaseRevision();
            }
        });
        restoreChat();
        void checkCaseRevision();
        var timer = window.setInterval(function () { void checkCaseRevision(); }, 3000);
        window.addEventListener('pagehide', function () { window.clearInterval(timer); }, {once: true});
    })();
</script>
<?php endif; ?>
<script src="assets/js/controlSesion.js" defer></script>
<script>
    (function () {
        'use strict';

        document.addEventListener('submit', function (event) {
            if (event.defaultPrevented) return;
            var form = event.target;
            if (!(form instanceof HTMLFormElement)) return;

            var accion = form.querySelector('input[name="accion"]');
            if (!accion || accion.value !== 'calificar_cerrar') return;

            if (form.dataset.processing === 'true') {
                event.preventDefault();
                return;
            }

            form.dataset.processing = 'true';
            var button = event.submitter instanceof HTMLButtonElement
                ? event.submitter
                : form.querySelector('button[type="submit"]');
            if (button) {
                button.disabled = true;
                button.setAttribute('aria-busy', 'true');
                button.textContent = 'Guardando calificación…';
            }
        });
    }());
</script>
</body>
</html>
