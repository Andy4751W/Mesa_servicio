<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';


$idTicket = filter_input(INPUT_GET, 'id_ticket', FILTER_VALIDATE_INT) ?: 0;
$destino = 'flujoTicket.php';

if ($idTicket > 0) {
    $destino .= '?id_ticket=' . $idTicket;
}

header('Location: ' . $destino, true, 302);
exit;
