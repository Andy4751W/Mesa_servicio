<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

seguridadExigirRol([1, 2, 3]);

$idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
$rol = (int) ($_SESSION['rol'] ?? 0);
$idPais = paisExigirContexto();
$idNotificacion = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
) ?: 0;

function notificacionJson(array $datos, int $estado = 200): void
{
    http_response_code($estado);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode(
        $datos,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

function notificacionTiempo(?string $fecha): string
{
    $marca = $fecha ? strtotime($fecha) : false;
    if ($marca === false) {
        return '';
    }
    $segundos = max(0, time() - $marca);
    if ($segundos < 60) {
        return 'Ahora';
    }
    if ($segundos < 3600) {
        return 'Hace ' . max(1, intdiv($segundos, 60)) . ' min';
    }
    if ($segundos < 86400) {
        return 'Hace ' . max(1, intdiv($segundos, 3600)) . ' h';
    }
    if ($segundos < 604800) {
        return 'Hace ' . max(1, intdiv($segundos, 86400)) . ' d';
    }
    return date('d/m/Y H:i', $marca);
}

function notificacionRutaInicial(int $rol): string
{
    return (fn ($__mesaMatchValue15) => (($__mesaMatchValue15 === (1)) ? ('solicitudes.php') : ((($__mesaMatchValue15 === (2)) ? ('flujoTicket.php?modo=mis_tickets') : ('panelSolicitante.php?vista=tickets')))))($rol);
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    notificacionJson([
        'ok' => false,
        'message' => 'Las notificaciones se marcan al visualizar su contenido.',
    ], 405);
}

if (
    ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET'
    && strtolower((string) ($_GET['accion'] ?? '')) === 'listar'
) {
    $stmt = $conn->prepare(
        "SELECT
            n.id_notificacion,
            n.titulo,
            n.mensaje,
            n.leida,
            n.creada_en
         FROM notificaciones AS n
         LEFT JOIN tickets AS t ON t.id_ticket = n.id_ticket
         WHERE n.id_usuario = ?
           AND n.leida = 0
           AND (n.id_ticket IS NULL OR t.id_pais_operacion = ?)
         ORDER BY n.creada_en DESC, n.id_notificacion DESC
         LIMIT 15"
    );
    $stmt->bind_param('ii', $idUsuario, $idPais);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $items = [];
    $noLeidas = 0;

    while ($fila = $resultado->fetch_assoc()) {
        $esNoLeida = (int) ($fila['leida'] ?? 0) === 0;
        if ($esNoLeida) {
            $noLeidas++;
        }
        $id = (int) ($fila['id_notificacion'] ?? 0);
        $creadaEn = (string) ($fila['creada_en'] ?? '');
        $items[] = [
            'id' => $id,
            'titulo' => (string) ($fila['titulo'] ?? 'Nueva actividad'),
            'mensaje' => (string) ($fila['mensaje'] ?? ''),
            'leida' => !$esNoLeida,
            'creada_en' => $creadaEn,
            'tiempo' => notificacionTiempo($creadaEn),
            'url' => 'abrirNotificacion.php?id=' . $id,
        ];
    }
    $stmt->close();

    // El contador real no queda limitado a los quince elementos del panel.
    $stmt = $conn->prepare(
        "SELECT COUNT(*) AS total
         FROM notificaciones AS n
         LEFT JOIN tickets AS t ON t.id_ticket = n.id_ticket
         WHERE n.id_usuario = ?
           AND n.leida = 0
           AND (n.id_ticket IS NULL OR t.id_pais_operacion = ?)"
    );
    $stmt->bind_param('ii', $idUsuario, $idPais);
    $stmt->execute();
    $filaConteo = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    notificacionJson([
        'ok' => true,
        'unread' => (int) ($filaConteo['total'] ?? $noLeidas),
        'items' => $items,
        'server_time' => date('c'),
    ]);
}

if ($idNotificacion < 1 || $idUsuario < 1) {
    header('Location: ' . notificacionRutaInicial($rol), true, 303);
    exit;
}

$stmt = $conn->prepare(
    "SELECT
        n.id_ticket,
        n.id_ticket_etapa,
        n.titulo,
        n.mensaje,
        t.estado_flujo
     FROM notificaciones AS n
     LEFT JOIN tickets AS t ON t.id_ticket = n.id_ticket
     WHERE n.id_notificacion = ?
       AND n.id_usuario = ?
       AND (n.id_ticket IS NULL OR t.id_pais_operacion = ?)
     LIMIT 1"
);
$stmt->bind_param('iii', $idNotificacion, $idUsuario, $idPais);
$stmt->execute();
$notificacion = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$notificacion) {
    header('Location: ' . notificacionRutaInicial($rol), true, 303);
    exit;
}

$idTicket = (int) ($notificacion['id_ticket'] ?? 0);
$idEtapa = (int) ($notificacion['id_ticket_etapa'] ?? 0);
$esConversacion = flujoEsNotificacionConversacion(
    (string) ($notificacion['titulo'] ?? ''),
    (string) ($notificacion['mensaje'] ?? '')
);

if ($idTicket < 1) {
    $stmt = $conn->prepare(
        "UPDATE notificaciones
         SET leida = 1,
             leida_en = COALESCE(leida_en, NOW())
         WHERE id_notificacion = ? AND id_usuario = ?"
    );
    $stmt->bind_param('ii', $idNotificacion, $idUsuario);
    $stmt->execute();
    $stmt->close();

    header('Location: ' . notificacionRutaInicial($rol), true, 303);
    exit;
}

if ($esConversacion && in_array($rol, [2, 3], true)) {
    $parametros = ['id_ticket' => $idTicket];

    if ($idEtapa > 0) {
        $parametros['id_ticket_etapa'] = $idEtapa;
    }

    $ruta = 'mensajes.php?' . http_build_query($parametros);
} elseif ($rol === 1) {
    $ruta = 'solicitudes.php?' . http_build_query([
        'id_ticket' => $idTicket,
    ]);
} elseif ($rol === 2) {
    $parametros = [
        'modo' => 'mis_tickets',
        'bandeja' => (string) ($notificacion['estado_flujo'] ?? '') === 'cerrado'
            ? 'cerrados'
            : 'abiertos',
        'id_ticket' => $idTicket,
    ];

    if ($idEtapa > 0) {
        $parametros['id_nodo'] = $idEtapa;
        $parametros['id_chat'] = $idEtapa;
    }

    $ruta = 'flujoTicket.php?' . http_build_query($parametros);
} else {
    $parametros = [
        'vista' => 'tickets',
        'id_ticket' => $idTicket,
    ];

    if ($idEtapa > 0) {
        $parametros['id_chat'] = $idEtapa;
    }

    $ruta = 'panelSolicitante.php?' . http_build_query($parametros);
}

header('Location: ' . $ruta, true, 303);
exit;
