<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

if ((int) ($_SESSION['rol'] ?? 0) !== 1) {
    http_response_code(403);
    exit('Acceso denegado.');
}
$idPaisOperacion = paisExigirContexto();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function escaparSolucion($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function redirigirSoluciones(string $mensaje, int $idServicio = 0): void
{
    $parametros = ['msg' => $mensaje];

    if ($idServicio > 0) {
        $parametros['id_servicio'] = $idServicio;
    }

    header('Location: soluciones.php?' . http_build_query($parametros));
    exit;
}

$moduloInstalado = flujoModuloSolucionesInstalado($conn);
$idServicioFiltro = filter_input(INPUT_GET, 'id_servicio', FILTER_VALIDATE_INT) ?: 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token)
        || !hash_equals((string) $_SESSION['csrf_token'], $token)
    ) {
        redirigirSoluciones('solicitud_invalida', $idServicioFiltro);
    }

    if (!$moduloInstalado) {
        redirigirSoluciones('instalacion_pendiente', $idServicioFiltro);
    }

    $accion = (string) ($_POST['accion'] ?? '');
    $idSolucion = filter_input(INPUT_POST, 'id_solucion', FILTER_VALIDATE_INT) ?: 0;
    $idServicio = filter_input(INPUT_POST, 'id_servicio', FILTER_VALIDATE_INT) ?: 0;
    $idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);

    if ($idSolucion > 0) {
        $stmtPais = $conn->prepare(
            "SELECT 1
             FROM soluciones_servicio AS ss
             INNER JOIN servicios AS s ON s.id_servicio = ss.id_servicio
             WHERE ss.id_solucion = ? AND s.id_pais_operacion = ?
             LIMIT 1"
        );
        $stmtPais->bind_param('ii', $idSolucion, $idPaisOperacion);
        $stmtPais->execute();
        $stmtPais->store_result();
        $solucionDelPais = $stmtPais->num_rows === 1;
        $stmtPais->close();

        if (!$solucionDelPais) {
            redirigirSoluciones('solicitud_invalida');
        }
    }

    try {
        if (in_array($accion, ['crear', 'editar'], true)) {
            $nombre = trim((string) ($_POST['nombre'] ?? ''));
            $descripcion = trim((string) ($_POST['descripcion'] ?? ''));
            $orden = filter_input(INPUT_POST, 'orden', FILTER_VALIDATE_INT);

            if (
                $idServicio < 1
                || $nombre === ''
                || strlen($nombre) > 180
                || strlen($descripcion) > 500
            ) {
                redirigirSoluciones('datos_incompletos', $idServicio);
            }

            if ($orden === false || $orden === null || $orden < 0) {
                $orden = 0;
            }

            $stmt = $conn->prepare(
                "SELECT id_servicio
                 FROM servicios
                 WHERE id_servicio = ?
                   AND id_pais_operacion = ?
                 LIMIT 1"
            );
            $stmt->bind_param('ii', $idServicio, $idPaisOperacion);
            $stmt->execute();
            $stmt->store_result();
            $servicioValido = $stmt->num_rows > 0;
            $stmt->close();

            if (!$servicioValido) {
                redirigirSoluciones('servicio_invalido');
            }

            $stmt = $conn->prepare(
                "SELECT id_solucion
                 FROM soluciones_servicio
                 WHERE id_servicio = ?
                   AND nombre = ?
                   AND id_solucion <> ?
                 LIMIT 1"
            );
            $stmt->bind_param('isi', $idServicio, $nombre, $idSolucion);
            $stmt->execute();
            $stmt->store_result();
            $duplicada = $stmt->num_rows > 0;
            $stmt->close();

            if ($duplicada) {
                redirigirSoluciones('solucion_duplicada', $idServicio);
            }

            if ($orden === 0) {
                $stmt = $conn->prepare(
                    "SELECT COALESCE(MAX(orden), 0) + 1 AS siguiente
                     FROM soluciones_servicio
                     WHERE id_servicio = ?"
                );
                $stmt->bind_param('i', $idServicio);
                $stmt->execute();
                $orden = (int) ($stmt->get_result()->fetch_assoc()['siguiente'] ?? 1);
                $stmt->close();
            }

            if ($accion === 'crear') {
                $stmt = $conn->prepare(
                    "INSERT INTO soluciones_servicio
                        (id_servicio, nombre, descripcion, estado, orden, creado_por, actualizado_por)
                     VALUES (?, ?, NULLIF(?, ''), 'activo', ?, ?, ?)"
                );
                $stmt->bind_param(
                    'issiii',
                    $idServicio,
                    $nombre,
                    $descripcion,
                    $orden,
                    $idUsuario,
                    $idUsuario
                );
                $stmt->execute();
                $stmt->close();
                redirigirSoluciones('creada', $idServicio);
            }

            if ($idSolucion < 1) {
                redirigirSoluciones('solicitud_invalida', $idServicio);
            }

            $stmt = $conn->prepare(
                "UPDATE soluciones_servicio
                 SET id_servicio = ?,
                     nombre = ?,
                     descripcion = NULLIF(?, ''),
                     orden = ?,
                     actualizado_por = ?
                 WHERE id_solucion = ?"
            );
            $stmt->bind_param(
                'issiii',
                $idServicio,
                $nombre,
                $descripcion,
                $orden,
                $idUsuario,
                $idSolucion
            );
            $stmt->execute();
            $stmt->close();
            redirigirSoluciones('actualizada', $idServicio);
        }

        if (in_array($accion, ['eliminar', 'reactivar'], true) && $idSolucion > 0) {
            $nuevoEstado = $accion === 'eliminar' ? 'inhabilitado' : 'activo';
            $stmt = $conn->prepare(
                "UPDATE soluciones_servicio
                 SET estado = ?, actualizado_por = ?
                 WHERE id_solucion = ?"
            );
            $stmt->bind_param('sii', $nuevoEstado, $idUsuario, $idSolucion);
            $stmt->execute();
            $stmt->close();

            if (
                strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''))
                === 'xmlhttprequest'
            ) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'ok' => true,
                    'id_solucion' => $idSolucion,
                    'estado' => $nuevoEstado,
                ], JSON_THROW_ON_ERROR);
                exit;
            }

            redirigirSoluciones(
                $accion === 'eliminar' ? 'eliminada' : 'reactivada',
                $idServicio
            );
        }

        redirigirSoluciones('solicitud_invalida', $idServicio);
    } catch (Throwable $e) {
        error_log('Soluciones por servicio: ' . $e->getMessage());
        redirigirSoluciones('error_operacion', $idServicio);
    }
}

$catalogos = [];
$servicios = [];
$serviciosPorCatalogo = [];

$resultadoCatalogos = $conn->query(
    "SELECT DISTINCT c.id_catalogo, c.nombre
     FROM catalogos AS c
     INNER JOIN servicios AS s ON s.id_catalogo = c.id_catalogo
     WHERE s.id_pais_operacion = {$idPaisOperacion}
     ORDER BY c.nombre"
);

if ($resultadoCatalogos !== false) {
    $catalogos = $resultadoCatalogos->fetch_all(MYSQLI_ASSOC);
}

$resultadoServicios = $conn->query(
    "SELECT
        s.id_servicio,
        s.nombre AS servicio,
        s.estado,
        c.id_catalogo,
        c.nombre AS catalogo
     FROM servicios AS s
     INNER JOIN catalogos AS c ON c.id_catalogo = s.id_catalogo
     WHERE s.id_pais_operacion = {$idPaisOperacion}
     ORDER BY c.nombre, s.nombre, s.id_servicio"
);

if ($resultadoServicios !== false) {
    $servicios = $resultadoServicios->fetch_all(MYSQLI_ASSOC);

    // Agrupar servicios por catálogo
    foreach ($servicios as $servicio) {
        $idCatalogo = (int) $servicio['id_catalogo'];
        if (!isset($serviciosPorCatalogo[$idCatalogo])) {
            $serviciosPorCatalogo[$idCatalogo] = [];
        }
        $serviciosPorCatalogo[$idCatalogo][] = $servicio;
    }
}

$idsServicios = array_map(
    static fn (array $servicio): int => (int) $servicio['id_servicio'],
    $servicios
);

if ($idServicioFiltro < 1 || !in_array($idServicioFiltro, $idsServicios, true)) {
    $idServicioFiltro = $idsServicios[0] ?? 0;
}

$soluciones = [];
$servicioActual = null;

foreach ($servicios as $servicio) {
    if ((int) $servicio['id_servicio'] === $idServicioFiltro) {
        $servicioActual = $servicio;
        break;
    }
}

if ($moduloInstalado && $idServicioFiltro > 0) {
    $stmt = $conn->prepare(
        "SELECT
            ss.*,
            (SELECT COUNT(*)
             FROM ticket_etapas AS te
             WHERE te.id_solucion = ss.id_solucion) AS total_usos
         FROM soluciones_servicio AS ss
         WHERE ss.id_servicio = ?
         ORDER BY ss.estado = 'activo' DESC, ss.orden, ss.nombre"
    );
    $stmt->bind_param('i', $idServicioFiltro);
    $stmt->execute();
    $soluciones = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

$mensajes = [
    'creada' => ['ok', 'La solución se creó correctamente.'],
    'actualizada' => ['ok', 'La solución se actualizó para cierres futuros. Los casos históricos conservaron el nombre aplicado.'],
    'eliminada' => ['ok', 'La solución se retiró de las opciones disponibles. El histórico se conserva.'],
    'reactivada' => ['ok', 'La solución volvió a estar disponible.'],
    'solucion_duplicada' => ['error', 'Ya existe una solución con ese nombre para el servicio.'],
    'datos_incompletos' => ['error', 'Complete correctamente el nombre, el servicio y la descripción.'],
    'servicio_invalido' => ['error', 'El servicio seleccionado no existe.'],
    'instalacion_pendiente' => ['error', 'Primero debe ejecutar la migración del módulo de soluciones.'],
    'solicitud_invalida' => ['error', 'La solicitud no es válida. Recargue la página e inténtelo nuevamente.'],
    'error_operacion' => ['error', 'No fue posible completar la operación. Revise el registro del servidor.'],
];
$mensajeActual = $mensajes[(string) ($_GET['msg'] ?? '')] ?? null;
$activas = count(array_filter(
    $soluciones,
    static fn (array $solucion): bool => $solucion['estado'] === 'activo'
));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soluciones por servicio | Mesa de Servicio</title>
    <style>
        :root{--primary:#0f6fec;--green:#0f8b72;--navy:#102a43;--text:#243b53;--muted:#6b7f93;--border:#dce6f0;--bg:#f3f6fb;--surface:#fff;--red:#a83b33}
        *{box-sizing:border-box}body{min-height:100vh;margin:0;color:var(--text);background:var(--bg);font:12px/1.45 Inter,"Segoe UI",Arial,sans-serif}.shell{width:calc(100% - 24px);max-width:none;margin:auto;padding:12px 0 28px}.topbar,.panel,.form-card{border:1px solid var(--border);border-radius:13px;background:var(--surface);box-shadow:0 7px 24px rgba(16,42,67,.055)}.topbar{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 14px}.brand{display:flex;align-items:center;gap:10px}.mark{width:36px;height:36px;display:grid;place-items:center;border-radius:10px;color:#fff;background:linear-gradient(145deg,#17a180,#0b6e5a);font-weight:850}.brand h1{margin:0;color:var(--navy);font-size:17px}.brand p{margin:2px 0 0;color:var(--muted);font-size:10px}.actions{display:flex;gap:7px;flex-wrap:wrap}.btn,button{min-height:34px;display:inline-flex;align-items:center;justify-content:center;padding:7px 11px;border:1px solid #d6e3ef;border-radius:9px;color:#24577f;background:#f7fbff;text-decoration:none;font:inherit;font-weight:750;cursor:pointer}.btn.primary,button.primary{color:#fff;border-color:var(--primary);background:var(--primary)}button.danger{color:var(--red);border-color:#efd4d1;background:#fff7f6}button.success{color:#087458;border-color:#bfe7db;background:#effaf6}.grid{display:grid;grid-template-columns:minmax(270px,360px) minmax(0,1fr);gap:10px;margin-top:10px}.form-card,.panel{overflow:hidden}.card-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;border-bottom:1px solid var(--border)}.card-head h2{margin:0;color:var(--navy);font-size:14px}.card-head p{margin:2px 0 0;color:var(--muted);font-size:10px}.card-body{padding:14px}.field{margin-bottom:11px}.field label{display:block;margin-bottom:4px;color:#526c83;font-size:10px;font-weight:800}.field input,.field select,.field textarea{width:100%;padding:8px 10px;border:1px solid #cfdbe7;border-radius:8px;color:var(--text);background:#fff;font:inherit}.field textarea{min-height:100px;resize:vertical}.field small{display:block;margin-top:4px;color:var(--muted)}.form-actions{display:flex;justify-content:flex-end;gap:7px}.service-filter{display:flex;align-items:flex-end;gap:8px;padding:10px 14px;border-bottom:1px solid var(--border);background:#f8fbfd}.service-filter .field{flex:1;margin:0}.service-filter button{min-width:84px}.alert{margin-top:10px;padding:10px 12px;border-radius:9px}.alert.ok{color:#087458;background:#eaf8f2}.alert.error{color:#9d3d32;background:#fff0ee}.install{margin-top:10px;padding:14px;border:1px solid #efd89b;border-radius:10px;color:#7e5900;background:#fff8df}.summary{display:flex;gap:6px;flex-wrap:wrap}.chip{padding:4px 8px;border-radius:999px;color:#276086;background:#edf5fd;font-size:9px;font-weight:800}.table-wrap{overflow:auto}table{width:100%;min-width:720px;border-collapse:collapse}th{padding:8px 10px;text-align:left;color:#687d90;background:#f7f9fc;border-bottom:1px solid var(--border);font-size:9px;text-transform:uppercase}td{padding:9px 10px;border-bottom:1px solid #edf2f6;vertical-align:top}.solution-name{color:var(--navy);font-weight:800}.status{display:inline-flex;padding:3px 7px;border-radius:999px;font-size:9px;font-weight:800}.status.active{color:#087458;background:#e9f8f1}.status.inactive{color:#8b5b00;background:#fff4d5}.row-actions{display:flex;gap:5px;justify-content:flex-end}.empty{padding:28px;text-align:center;color:var(--muted)}details summary{cursor:pointer;color:#29628e;font-weight:750}dialog{width:min(570px,calc(100% - 24px));padding:0;border:0;border-radius:14px;box-shadow:0 25px 70px rgba(16,42,67,.28)}dialog::backdrop{background:rgba(15,35,55,.52)}.dialog-head{display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid var(--border)}.dialog-head h2{margin:0;font-size:14px}.dialog-body{padding:14px}.close{width:34px;padding:0;font-size:18px}.notice{margin:0 0 10px;color:var(--muted);font-size:10px}@media(max-width:820px){.shell{width:calc(100% - 14px);padding-top:7px}.topbar{align-items:flex-start;flex-direction:column}.actions{width:100%}.actions .btn{flex:1}.grid{grid-template-columns:1fr}}
        .service-filter{display:grid;grid-template-columns:minmax(170px,.8fr) minmax(250px,1.35fr) auto;align-items:end}
        .service-filter .field{min-width:0}
        .solution-service-combobox{position:relative}
        .solution-service-control{position:relative}
        .solution-service-search{padding-right:42px!important}
        .solution-service-toggle{position:absolute;z-index:2;top:1px;right:1px;bottom:1px;width:36px;min-width:36px;min-height:0;padding:0;border:0;border-left:1px solid var(--border);border-radius:0 7px 7px 0;background:var(--surface);color:var(--navy);box-shadow:none}
        .solution-service-toggle::before{content:"▾"}
        .solution-service-toggle[aria-expanded="true"]::before{content:"▴"}
        .solution-service-menu{position:absolute;z-index:1100;top:calc(100% + 4px);right:0;left:0;max-height:min(230px,42vh);overflow-y:auto;padding:4px 0;border:1px solid var(--border);border-radius:8px;background:var(--surface);box-shadow:0 14px 30px rgba(16,42,67,.18)}
        .solution-service-option{display:block;width:100%;min-height:32px;padding:7px 10px;border:0;border-radius:0;color:var(--text);background:transparent;text-align:left;font-weight:700;box-shadow:none}
        .solution-service-option:hover,.solution-service-option:focus,.solution-service-option[aria-selected="true"]{color:var(--navy);background:var(--bg);outline:0}
        .solution-service-option small{display:block;margin:1px 0 0;color:var(--muted);font-weight:500}
        .solution-service-empty{padding:10px;color:var(--muted);text-align:center}
        .solution-service-help{display:block;margin-top:4px;color:var(--muted);font-size:9px;line-height:1.35}
        .solution-service-search:disabled,.solution-service-toggle:disabled{cursor:not-allowed;opacity:.65}
        @media(max-width:820px){.service-filter{grid-template-columns:1fr}.service-filter button{width:100%}}
    </style>
</head>
<body>
<main class="shell">
    <header class="topbar">
        <div class="brand"><div class="mark">SO</div><div><h1>Soluciones por servicio</h1><p>Configuración por área y servicio para cerrar casos padres e hijos</p></div></div>
        <nav class="actions"><a class="btn" href="servicios.php">Ver servicios</a><a class="btn" href="panelAdmin.php">Volver al panel</a></nav>
    </header>

    <?php if ($mensajeActual): ?><div class="alert <?= escaparSolucion($mensajeActual[0]) ?>"><?= escaparSolucion($mensajeActual[1]) ?></div><?php endif; ?>
    <?php if (!$moduloInstalado): ?><div class="install"><strong>Instalación pendiente.</strong> Importe <code>migracion_soluciones_por_servicio.sql</code> en la base <code>mesa_servicio</code>.</div><?php endif; ?>

    <div class="grid">
        <section class="form-card">
            <div class="card-head"><div><h2>Nueva solución</h2><p>La opción quedará disponible únicamente para el servicio elegido.</p></div></div>
            <div class="card-body">
                <form method="post">
                    <input type="hidden" name="csrf_token" value="<?= escaparSolucion($_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="accion" value="crear">
                    <div class="field"><label for="create_catalog">Área *</label><select id="create_catalog" required <?= !$moduloInstalado ? 'disabled' : '' ?>><option value="">Seleccione un área</option><?php foreach ($catalogos as $catalogo): ?><option value="<?= (int) $catalogo['id_catalogo'] ?>"><?= escaparSolucion($catalogo['nombre']) ?></option><?php endforeach; ?></select></div>
                    <div class="field">
                        <label for="create_service_search">Servicio *</label>
                        <div class="solution-service-combobox" data-solution-service-combobox data-catalog="create_catalog" data-active-only="1">
                            <div class="solution-service-control">
                                <input class="solution-service-search" id="create_service_search" type="text" role="combobox" aria-autocomplete="list" aria-expanded="false" autocomplete="off" required placeholder="Primero seleccione un área" disabled>
                                <button class="solution-service-toggle" type="button" aria-label="Mostrar servicios" aria-expanded="false" disabled></button>
                            </div>
                            <input type="hidden" id="create_service" name="id_servicio" value="">
                            <div class="solution-service-menu" role="listbox" hidden></div>
                        </div>
                        <small class="solution-service-help">Seleccione con la flecha o escriba para filtrar los servicios del área.</small>
                    </div>
                    <div class="field"><label for="create_name">Nombre de la solución *</label><input id="create_name" name="nombre" maxlength="180" required placeholder="Ej. Reinicio de computador" <?= !$moduloInstalado ? 'disabled' : '' ?>></div>
                    <div class="field"><label for="create_description">Descripción o guía</label><textarea id="create_description" name="descripcion" maxlength="500" placeholder="Indique cuándo debe seleccionarse esta solución" <?= !$moduloInstalado ? 'disabled' : '' ?>></textarea><small>Esta guía se mostrará al gestor cuando seleccione la solución.</small></div>
                    <div class="field"><label for="create_order">Orden</label><input id="create_order" type="number" min="0" name="orden" value="0" <?= !$moduloInstalado ? 'disabled' : '' ?>><small>Use 0 para asignar automáticamente la siguiente posición.</small></div>
                    <div class="form-actions"><button class="primary" type="submit" <?= !$moduloInstalado ? 'disabled' : '' ?>>Crear solución</button></div>
                </form>
            </div>
        </section>

        <section class="panel">
            <div class="card-head"><div><h2><?= escaparSolucion($servicioActual ? $servicioActual['catalogo'] . ' / ' . $servicioActual['servicio'] : 'Soluciones configuradas') ?></h2><p>Editar o eliminar afecta las opciones futuras; los casos cerrados conservan su histórico.</p></div><div class="summary"><span class="chip"><?= count($soluciones) ?> registradas</span><span class="chip"><?= $activas ?> activas</span></div></div>
            <form class="service-filter" method="get">
                <div class="field"><label for="query_catalog">Área</label><select id="query_catalog" required><option value="">Seleccione un área</option><?php foreach ($catalogos as $catalogo): ?><option value="<?= (int) $catalogo['id_catalogo'] ?>" <?= (int) $catalogo['id_catalogo'] === (int) ($servicioActual['id_catalogo'] ?? 0) ? 'selected' : '' ?>><?= escaparSolucion($catalogo['nombre']) ?></option><?php endforeach; ?></select></div>
                <div class="field">
                    <label for="query_service_search">Servicio</label>
                    <div class="solution-service-combobox" data-solution-service-combobox data-catalog="query_catalog" data-initial-service="<?= $idServicioFiltro ?>">
                        <div class="solution-service-control">
                            <input class="solution-service-search" id="query_service_search" type="text" role="combobox" aria-autocomplete="list" aria-expanded="false" autocomplete="off" required placeholder="Escriba para filtrar...">
                            <button class="solution-service-toggle" type="button" aria-label="Mostrar servicios" aria-expanded="false"></button>
                        </div>
                        <input type="hidden" id="service_filter" name="id_servicio" value="<?= $idServicioFiltro ?>">
                        <div class="solution-service-menu" role="listbox" hidden></div>
                    </div>
                </div>
                <button type="submit">Consultar</button>
            </form>
            <?php if (!$soluciones): ?><div class="empty">Este servicio todavía no tiene soluciones configuradas.</div><?php else: ?>
            <div class="table-wrap"><table><thead><tr><th>Orden</th><th>Solución</th><th>Descripción</th><th>Estado</th><th>Usos</th><th></th></tr></thead><tbody>
            <?php foreach ($soluciones as $solucion): ?>
                <tr>
                    <td><?= (int) $solucion['orden'] ?></td>
                    <td class="solution-name"><?= escaparSolucion($solucion['nombre']) ?></td>
                    <td><?php if (trim((string) ($solucion['descripcion'] ?? '')) !== ''): ?><details><summary>Ver guía</summary><p><?= nl2br(escaparSolucion($solucion['descripcion'])) ?></p></details><?php else: ?><span class="notice">Sin descripción</span><?php endif; ?></td>
                    <td><span class="status <?= $solucion['estado'] === 'activo' ? 'active' : 'inactive' ?>" data-solution-status><?= $solucion['estado'] === 'activo' ? 'Activa' : 'Retirada' ?></span></td>
                    <td><?= (int) $solucion['total_usos'] ?></td>
                    <td><div class="row-actions"><button type="button" data-edit-solution data-id="<?= (int) $solucion['id_solucion'] ?>" data-service="<?= (int) $solucion['id_servicio'] ?>" data-name="<?= escaparSolucion($solucion['nombre']) ?>" data-description="<?= escaparSolucion($solucion['descripcion'] ?? '') ?>" data-order="<?= (int) $solucion['orden'] ?>">Editar</button><form data-solution-status-form method="post" onsubmit="return confirm('<?= $solucion['estado'] === 'activo' ? '¿Eliminar esta solución de las opciones futuras? El histórico no se borrará.' : '¿Reactivar esta solución?' ?>')"><input type="hidden" name="csrf_token" value="<?= escaparSolucion($_SESSION['csrf_token']) ?>"><input type="hidden" name="accion" value="<?= $solucion['estado'] === 'activo' ? 'eliminar' : 'reactivar' ?>"><input type="hidden" name="id_solucion" value="<?= (int) $solucion['id_solucion'] ?>"><input type="hidden" name="id_servicio" value="<?= (int) $solucion['id_servicio'] ?>"><button class="<?= $solucion['estado'] === 'activo' ? 'danger' : 'success' ?>" type="submit" data-solution-status-button><?= $solucion['estado'] === 'activo' ? 'Eliminar' : 'Reactivar' ?></button></form></div></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table></div>
            <?php endif; ?>
        </section>
    </div>
</main>

<dialog id="editDialog">
    <div class="dialog-head"><h2>Editar solución</h2><button class="close" type="button" data-close-dialog aria-label="Cerrar">×</button></div>
    <div class="dialog-body">
        <p class="notice">El nuevo nombre se usará en cierres futuros. Los registros históricos conservarán el nombre seleccionado originalmente.</p>
        <form method="post" id="editForm">
            <input type="hidden" name="csrf_token" value="<?= escaparSolucion($_SESSION['csrf_token']) ?>"><input type="hidden" name="accion" value="editar"><input type="hidden" name="id_solucion" id="edit_id">
            <div class="field"><label for="edit_catalog">Área *</label><select id="edit_catalog" required><option value="">Seleccione un área</option><?php foreach ($catalogos as $catalogo): ?><option value="<?= (int) $catalogo['id_catalogo'] ?>"><?= escaparSolucion($catalogo['nombre']) ?></option><?php endforeach; ?></select></div>
            <div class="field">
                <label for="edit_service_search">Servicio *</label>
                <div class="solution-service-combobox" data-solution-service-combobox data-catalog="edit_catalog">
                    <div class="solution-service-control">
                        <input class="solution-service-search" id="edit_service_search" type="text" role="combobox" aria-autocomplete="list" aria-expanded="false" autocomplete="off" required placeholder="Primero seleccione un área" disabled>
                        <button class="solution-service-toggle" type="button" aria-label="Mostrar servicios" aria-expanded="false" disabled></button>
                    </div>
                    <input type="hidden" id="edit_service" name="id_servicio" value="">
                    <div class="solution-service-menu" role="listbox" hidden></div>
                </div>
                <small class="solution-service-help">Puede conservar el servicio actual o buscar otro dentro del área.</small>
            </div>
            <div class="field"><label for="edit_name">Nombre *</label><input id="edit_name" name="nombre" maxlength="180" required></div>
            <div class="field"><label for="edit_description">Descripción o guía</label><textarea id="edit_description" name="descripcion" maxlength="500"></textarea></div>
            <div class="field"><label for="edit_order">Orden</label><input id="edit_order" type="number" min="0" name="orden" required></div>
            <div class="form-actions"><button type="button" data-close-dialog>Cancelar</button><button class="primary" type="submit">Guardar cambios</button></div>
        </form>
    </div>
</dialog>
<script>
(() => {
    const serviciosPorCatalogo = <?= json_encode($serviciosPorCatalogo, JSON_THROW_ON_ERROR) ?>;
    const allServicios = <?= json_encode($servicios, JSON_THROW_ON_ERROR) ?>;

    const normalize = (value) => String(value || '')
        .toLocaleLowerCase('es')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .trim();

    const close = (root) => {
        const menu = root.querySelector('.solution-service-menu');
        const input = root.querySelector('.solution-service-search');
        const toggle = root.querySelector('.solution-service-toggle');
        menu.hidden = true;
        input.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-expanded', 'false');
    };

    const closeOthers = (current) => {
        document.querySelectorAll('[data-solution-service-combobox]').forEach((root) => {
            if (root !== current) close(root);
        });
    };

    document.querySelectorAll('[data-solution-service-combobox]').forEach((root) => {
        const catalog = document.getElementById(root.dataset.catalog || '');
        const input = root.querySelector('.solution-service-search');
        const hidden = root.querySelector('input[type="hidden"]');
        const toggle = root.querySelector('.solution-service-toggle');
        const menu = root.querySelector('.solution-service-menu');
        const activeOnly = root.dataset.activeOnly === '1';

        if (!catalog || !input || !hidden || !toggle || !menu) return;

        const available = () => {
            const catalogId = String(parseInt(catalog.value, 10) || 0);
            if (catalogId === '0') return [];
            return (serviciosPorCatalogo[catalogId] || []).filter((service) => (
                !activeOnly || service.estado === 'activo'
            ));
        };

        const select = (service, focus = true) => {
            hidden.value = String(service.id_servicio);
            input.value = String(service.servicio || '');
            input.setCustomValidity('');
            close(root);
            if (focus) input.focus();
        };

        const render = (showAll = false) => {
            const term = showAll ? '' : normalize(input.value);
            const matches = available().filter((service) => (
                !term || normalize(service.servicio).includes(term)
            ));

            menu.replaceChildren();
            if (!matches.length) {
                const empty = document.createElement('div');
                empty.className = 'solution-service-empty';
                empty.textContent = available().length
                    ? 'No hay servicios que coincidan.'
                    : 'Esta área no tiene servicios disponibles.';
                menu.appendChild(empty);
            } else {
                matches.forEach((service) => {
                    const option = document.createElement('button');
                    option.type = 'button';
                    option.className = 'solution-service-option';
                    option.setAttribute('role', 'option');
                    option.setAttribute('aria-selected', String(hidden.value) === String(service.id_servicio) ? 'true' : 'false');
                    option.textContent = String(service.servicio || 'Servicio');
                    if (service.estado !== 'activo') {
                        const state = document.createElement('small');
                        state.textContent = 'Servicio inhabilitado · disponible solo para consulta';
                        option.appendChild(state);
                    }
                    option.addEventListener('click', () => select(service));
                    menu.appendChild(option);
                });
            }
            closeOthers(root);
            menu.hidden = false;
            input.setAttribute('aria-expanded', 'true');
            toggle.setAttribute('aria-expanded', 'true');
        };

        const reset = () => {
            hidden.value = '';
            input.value = '';
            const enabled = Boolean(parseInt(catalog.value, 10));
            input.disabled = !enabled;
            toggle.disabled = !enabled;
            input.placeholder = enabled ? 'Escriba para filtrar...' : 'Primero seleccione un área';
            input.setCustomValidity('');
            close(root);
        };

        catalog.addEventListener('change', reset);
        input.addEventListener('input', () => {
            hidden.value = '';
            input.setCustomValidity('');
            render(false);
        });
        input.addEventListener('focus', () => render(input.value === ''));
        input.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') close(root);
            if (event.key === 'ArrowDown') {
                event.preventDefault();
                if (menu.hidden) render(false);
                menu.querySelector('.solution-service-option')?.focus();
            }
        });
        toggle.addEventListener('click', () => menu.hidden ? render(true) : close(root));

        const form = root.closest('form');
        form?.addEventListener('submit', (event) => {
            if (hidden.value) return;
            event.preventDefault();
            input.setCustomValidity('Seleccione un servicio de la lista.');
            input.reportValidity();
            render(false);
        });

        const initialId = String(root.dataset.initialService || hidden.value || '');
        const initial = allServicios.find((service) => String(service.id_servicio) === initialId);
        if (initial) select(initial, false); else reset();

        root.addEventListener('solution-service:set', (event) => {
            const serviceId = String(event.detail?.id || '');
            const service = allServicios.find((item) => String(item.id_servicio) === serviceId);
            if (!service) {
                reset();
                return;
            }
            catalog.value = String(service.id_catalogo);
            input.disabled = false;
            toggle.disabled = false;
            input.placeholder = 'Escriba para filtrar...';
            select(service, false);
        });
    });

    document.addEventListener('click', (event) => {
        document.querySelectorAll('[data-solution-service-combobox]').forEach((root) => {
            if (!root.contains(event.target)) close(root);
        });
    });
})();
</script>
<script>
(() => {
    const dialog = document.getElementById('editDialog');
    if (!dialog) return;
    document.querySelectorAll('[data-edit-solution]').forEach((button) => {
        button.addEventListener('click', () => {
            document.getElementById('edit_id').value = button.dataset.id || '';
            document.querySelector('[data-solution-service-combobox][data-catalog="edit_catalog"]')?.dispatchEvent(new CustomEvent('solution-service:set', {
                detail: { id: button.dataset.service || '' }
            }));
            document.getElementById('edit_name').value = button.dataset.name || '';
            document.getElementById('edit_description').value = button.dataset.description || '';
            document.getElementById('edit_order').value = button.dataset.order || '0';
            dialog.showModal();
        });
    });
    document.querySelectorAll('[data-close-dialog]').forEach((button) => button.addEventListener('click', () => dialog.close()));
    dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); });
})();
</script>
<script>
(() => {
    const mensajesError = new Set([
        'solicitud_invalida',
        'instalacion_pendiente',
        'datos_incompletos',
        'servicio_invalido',
        'solucion_duplicada',
        'error_operacion'
    ]);

    document.querySelectorAll('[data-solution-status-form]').forEach((form) => {
        form.addEventListener('submit', async (event) => {
            event.preventDefault();

            const button = form.querySelector('[data-solution-status-button]');
            const solutionId = form.elements.namedItem('id_solucion')?.value || '';
            const action = form.elements.namedItem('accion')?.value || '';
            const row = form.closest('tr');

            if (!button || !row || !solutionId || form.dataset.busy === '1') {
                return;
            }

            form.dataset.busy = '1';
            button.disabled = true;

            try {
                const response = await fetch(form.action || window.location.href, {
                    method: 'POST',
                    body: new FormData(form),
                    credentials: 'same-origin',
                    cache: 'no-store',
                    redirect: 'follow'
                });

                if (!response.ok) {
                    throw new Error('No fue posible actualizar la solución.');
                }

                const mensaje = new URL(response.url, window.location.href).searchParams.get('msg');
                if (mensajesError.has(mensaje)) {
                    throw new Error('No fue posible actualizar la solución.');
                }

                const activa = action === 'reactivar';
                const estado = row.querySelector('[data-solution-status]');
                estado.className = 'status ' + (activa ? 'active' : 'inactive');
                estado.textContent = activa ? 'Activa' : 'Retirada';
                button.className = activa ? 'danger' : 'success';
                button.textContent = activa ? 'Eliminar' : 'Reactivar';
                form.elements.namedItem('accion').value = activa ? 'eliminar' : 'reactivar';
                form.setAttribute(
                    'onsubmit',
                    "return confirm('" + (activa
                        ? '¿Eliminar esta solución de las opciones futuras? El histórico no se borrará.'
                        : '¿Reactivar esta solución?') + "')"
                );
            } catch (error) {
                window.alert(error instanceof Error ? error.message : 'No fue posible actualizar la solución.');
            } finally {
                form.dataset.busy = '0';
                button.disabled = false;
            }
        });
    });
})();
</script>
<script src="assets/js/controlSesion.js" defer></script>
</body>
</html>
