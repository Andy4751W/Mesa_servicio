<?php
declare(strict_types=1);

/*
 * Administración exclusiva de catálogos.
 * Los servicios se gestionan de forma independiente en servicios.php.
 */
require_once APP_ROOT . '/security/validarSesion.php';
seguridadExigirRol([1]);
$idPaisOperacion = paisExigirContexto();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function escaparCatalogo($valor)
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

// Guardar el orden de los catálogos mediante arrastrar y soltar.
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['guardar_orden_catalogos'])
) {
    seguridadExigirOrigenPost();
    header('Content-Type: application/json; charset=UTF-8');

    $token = $_POST['csrf_token'] ?? '';
    $ordenRecibido = $_POST['orden'] ?? [];

    if (
        !is_string($token)
        || !hash_equals((string) $_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        echo json_encode([
            'ok' => false,
            'mensaje' => 'La solicitud no es válida. Actualice la página.',
        ]);
        exit;
    }

    if (!is_array($ordenRecibido)) {
        http_response_code(422);
        echo json_encode([
            'ok' => false,
            'mensaje' => 'El orden recibido no es válido.',
        ]);
        exit;
    }

    $idsOrdenados = array_values(array_unique(array_filter(
        array_map('intval', $ordenRecibido),
        function ($id) {
            return $id > 0;
        }
    )));

    try {
        $resultadoActivos = $conn->query(
            "SELECT id_catalogo
             FROM catalogos
             WHERE estado = 'activo'
               AND id_pais_operacion = {$idPaisOperacion}"
        );
        $idsActivos = [];

        while ($fila = $resultadoActivos->fetch_assoc()) {
            $idsActivos[] = (int) $fila['id_catalogo'];
        }

        $idsValidacion = $idsOrdenados;
        sort($idsValidacion);
        sort($idsActivos);

        if ($idsValidacion !== $idsActivos) {
            http_response_code(409);
            echo json_encode([
                'ok' => false,
                'mensaje' => 'La lista cambió. Actualice la página.',
            ]);
            exit;
        }

        $conn->begin_transaction();
        $stmtOrden = $conn->prepare(
            "UPDATE catalogos
             SET orden = ?
             WHERE id_catalogo = ? AND id_pais_operacion = ?"
        );

        foreach ($idsOrdenados as $posicion => $idCatalogo) {
            $orden = $posicion + 1;
            $stmtOrden->bind_param("iii", $orden, $idCatalogo, $idPaisOperacion);

            if (!$stmtOrden->execute()) {
                throw new RuntimeException(
                    'No fue posible actualizar el orden.'
                );
            }
        }

        $stmtOrden->close();
        // El primer segmento del código del servicio representa la posición
        // actual del área. Mantenerlo sincronizado evita códigos obsoletos
        // después de reordenar el catálogo mediante arrastrar y soltar.
        $stmtCodigos = $conn->prepare(
            "UPDATE servicios AS s
             INNER JOIN catalogos AS c ON c.id_catalogo = s.id_catalogo
             INNER JOIN catalogo_procesos_servicio AS p
                 ON p.id_proceso_catalogo = s.id_proceso_catalogo
             SET s.codigo_servicio = CONCAT(
                 c.orden, '.',
                 COALESCE(
                     NULLIF(SUBSTRING_INDEX(SUBSTRING_INDEX(s.codigo_servicio, '.', 2), '.', -1), ''),
                     p.orden
                 ),
                 '.', s.orden_catalogo
             )
             WHERE c.id_pais_operacion = ?
               AND s.orden_catalogo IS NOT NULL"
        );
        $stmtCodigos->bind_param('i', $idPaisOperacion);
        $stmtCodigos->execute();
        $stmtCodigos->close();
        $conn->commit();

        echo json_encode([
            'ok' => true,
            'mensaje' => 'Orden guardado.',
        ]);
        exit;
    } catch (Throwable $e) {
        try {
            $conn->rollback();
        } catch (Throwable $rollbackError) {
            // La transacción pudo no haberse iniciado.
        }

        error_log(
            'Error al ordenar catálogos: ' . $e->getMessage()
        );
        http_response_code(500);
        echo json_encode([
            'ok' => false,
            'mensaje' => 'No fue posible guardar el orden.',
        ]);
        exit;
    }
}

$catalogos = $conn->query(
    "SELECT
        id_catalogo,
        nombre,
        descripcion,
        imagen,
        orden
     FROM catalogos
     WHERE estado = 'activo'
       AND id_pais_operacion = {$idPaisOperacion}
     ORDER BY orden ASC, nombre ASC"
);

$totalCatalogos = $catalogos ? $catalogos->num_rows : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Procesos | SMARTDESK</title>
    <style>
        :root {
            --primary: #0e9f9a;
            --primary-dark: #08736f;
            --blue: #0f6fec;
            --navy: #102a43;
            --text: #243b53;
            --muted: #526d82;
            --surface: #ffffff;
            --background: #f3f6fb;
            --border: #dfe8f3;
            --success: #087443;
            --danger: #b42318;
            --shadow: 0 18px 46px rgba(16, 42, 67, 0.10);
        }

        * {
            box-sizing: border-box;
        }

        html {
            min-height: 100%;
        }

        body {
            min-height: 100vh;
            margin: 0;
            color: var(--text);
            background:
                radial-gradient(
                    circle at 8% 0%,
                    rgba(15, 111, 236, 0.10),
                    transparent 28%
                ),
                radial-gradient(
                    circle at 96% 92%,
                    rgba(14, 159, 154, 0.10),
                    transparent 25%
                ),
                var(--background);
            font-family: Inter, "Segoe UI", Roboto, Arial, sans-serif;
            line-height: 1.5;
        }

        button,
        a {
            font: inherit;
        }

        .page-shell {
            width: min(1180px, calc(100% - 40px));
            margin: 0 auto;
            padding: 28px 0 38px;
        }

        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 24px;
            padding: 14px 18px;
            border: 1px solid rgba(223, 232, 243, 0.92);
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.94);
            box-shadow: 0 8px 24px rgba(15, 45, 75, 0.06);
            backdrop-filter: blur(10px);
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 0;
        }

        .brand-mark {
            display: grid;
            flex: 0 0 auto;
            width: 42px;
            height: 42px;
            place-items: center;
            border-radius: 12px;
            color: #fff;
            background: linear-gradient(145deg, #12aaa5, #08736f);
            box-shadow: 0 8px 18px rgba(14, 159, 154, 0.25);
            font-size: 15px;
            font-weight: 850;
        }

        .brand p {
            margin: 0;
        }

        .brand-name {
            color: var(--navy);
            font-size: 16px;
            font-weight: 780;
        }

        .brand-subtitle {
            color: var(--muted);
            font-size: 12px;
        }

        .top-actions {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 9px;
            flex-wrap: wrap;
        }

        .button {
            display: inline-flex;
            min-height: 40px;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 9px 14px;
            border: 1px solid transparent;
            border-radius: 10px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 750;
            transition:
                transform 0.18s ease,
                box-shadow 0.18s ease,
                background 0.18s ease;
        }

        .button:hover {
            transform: translateY(-1px);
        }

        .button.secondary {
            border-color: #dce6f1;
            color: #486581;
            background: #f8fafc;
        }

        .button.primary {
            color: #fff;
            background: var(--primary);
            box-shadow: 0 7px 17px rgba(14, 159, 154, 0.22);
        }

        .hero {
            position: relative;
            overflow: hidden;
            min-height: 58px;
            padding: 9px 14px;
            border-radius: 12px;
            color: #fff;
            background:
                linear-gradient(
                    120deg,
                    #08736f 0%,
                    #0e9f9a 58%,
                    #18b9b2 100%
                );
            box-shadow: 0 8px 20px rgba(15, 45, 75, 0.10);
        }

        .hero::before,
        .hero::after {
            position: absolute;
            border-radius: 50%;
            content: "";
            pointer-events: none;
        }

        .hero::before {
            top: -45px;
            right: -18px;
            width: 112px;
            height: 112px;
            border: 16px solid rgba(255, 255, 255, 0.07);
        }

        .hero::after {
            right: 84px;
            bottom: -67px;
            width: 98px;
            height: 98px;
            background: rgba(255, 255, 255, 0.055);
        }

        .hero-content {
            position: relative;
            z-index: 1;
            max-width: 760px;
        }

        .eyebrow {
            display: none;
        }

        .hero h1 {
            margin: 0;
            font-size: 17px;
            line-height: 1.18;
            letter-spacing: -0.2px;
        }

        .hero p {
            max-width: 720px;
            margin: 2px 0 0;
            color: rgba(255, 255, 255, 0.86);
            overflow: hidden;
            font-size: 11px;
            line-height: 1.3;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .content {
            margin-top: 14px;
        }

        .section-heading {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 17px;
        }

        .section-heading h2,
        .section-heading p {
            margin: 0;
        }

        .section-heading h2 {
            color: var(--navy);
            font-size: 22px;
            letter-spacing: -0.4px;
        }

        .section-heading p {
            margin-top: 4px;
            color: var(--muted);
            font-size: 13px;
        }

        .total-chip {
            flex: 0 0 auto;
            padding: 7px 11px;
            border: 1px solid #dce7f3;
            border-radius: 9px;
            color: #486581;
            background: rgba(255, 255, 255, 0.84);
            font-size: 12px;
            font-weight: 750;
        }

        .catalogos {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(175px, 1fr));
            gap: 12px;
            transition: opacity 0.16s ease;
        }

        .catalogos.guardando {
            opacity: 0.68;
            pointer-events: none;
        }

        .catalogo {
            position: relative;
            display: flex;
            min-width: 0;
            min-height: 174px;
            align-items: stretch;
            justify-content: flex-start;
            flex-direction: column;
            padding: 11px;
            border: 1px solid var(--border);
            border-radius: 17px;
            color: var(--text);
            background: var(--surface);
            box-shadow: 0 9px 24px rgba(31, 62, 93, 0.07);
            text-align: left;
            cursor: grab;
            touch-action: none;
            user-select: none;
            transition:
                transform 0.18s ease,
                opacity 0.16s ease,
                border-color 0.18s ease,
                box-shadow 0.18s ease;
        }

        .catalogo::before {
            position: absolute;
            top: 13px;
            right: 13px;
            color: #9bb0c4;
            content: "⋮⋮";
            font-size: 16px;
            font-weight: 800;
            letter-spacing: -4px;
        }

        .catalogo:hover {
            transform: translateY(-3px);
            border-color: #a8d7d4;
            box-shadow: 0 15px 30px rgba(31, 62, 93, 0.12);
        }

        .catalogo:active {
            cursor: grabbing;
        }

        .catalogo.arrastrando {
            opacity: 0.34;
            transform: scale(0.96);
            cursor: grabbing;
        }

        .catalogo img {
            width: 100%;
            height: 105px;
            display: block;
            margin: 7px 0 0;
            padding: 0;
            border: 1px solid #dce6f0;
            border-radius: 12px;
            background: #f7faff;
            object-fit: cover;
            object-position: center;
            pointer-events: none;
            -webkit-user-drag: none;
        }

        .catalogo strong {
            display: block;
            padding-right: 28px;
            overflow-wrap: anywhere;
            color: var(--navy);
            font-size: 14px;
            line-height: 1.3;
        }

        .catalogo small {
            margin-top: 7px;
            color: var(--muted);
            font-size: 11px;
        }

        .order-status {
            display: inline-flex;
            min-height: 20px;
            align-items: center;
            margin-left: 6px;
            font-size: 12px;
            font-weight: 750;
        }

        .order-status.success {
            color: var(--success);
        }

        .order-status.error {
            color: var(--danger);
        }

        .empty {
            padding: 34px 22px;
            border: 1px dashed #cbd8e5;
            border-radius: 16px;
            color: var(--muted);
            background: rgba(255, 255, 255, 0.74);
            text-align: center;
        }

        .footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            margin-top: 28px;
            padding: 0 4px;
            color: #829ab1;
            font-size: 12px;
        }

        @media (max-width: 720px) {
            .page-shell {
                width: min(100% - 24px, 1180px);
                padding-top: 12px;
            }

            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }

            .top-actions {
                justify-content: flex-start;
                width: 100%;
            }

            .hero {
                min-height: 58px;
                padding: 9px 14px;
            }

            .section-heading {
                align-items: flex-start;
                flex-direction: column;
            }

            .total-chip {
                display: none;
            }

            .catalogos {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .footer {
                align-items: flex-start;
                flex-direction: column;
                gap: 4px;
            }
        }

        @media (max-width: 430px) {
            .catalogos {
                grid-template-columns: 1fr;
            }

            .button {
                flex: 1 1 140px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>
<body>
<main class="page-shell">
    <header class="topbar">
        <div class="brand">
            <div class="brand-mark" aria-hidden="true">MS</div>
            <div>
                <p class="brand-name smartdesk-wordmark"><span class="smart">SMART</span><span class="desk">DESK</span></p>
                <p class="brand-subtitle">Administración de procesos</p>
            </div>
        </div>

        <nav class="top-actions" aria-label="Acciones de procesos">
            <a class="button secondary" href="panelAdmin.php">
                ← Volver al panel
            </a>
            <a class="button primary" href="editarcatalogos.php">
                Administrar procesos
            </a>
        </nav>
    </header>

    <section class="hero" aria-labelledby="titulo-catalogos">
        <div class="hero-content">
            <span class="eyebrow">Módulo administrativo</span>
            <h1 id="titulo-catalogos">Procesos</h1>
            <p>
                Organice los procesos de servicio. Puede arrastrarlos para definir
                el orden en que aparecerán dentro de la plataforma.
            </p>
        </div>
    </section>

    <section class="content" aria-labelledby="titulo-listado">
        <div class="section-heading">
            <div>
            <h2 id="titulo-listado">Procesos disponibles</h2>
                <p>
                    Arrastre una tarjeta para cambiar su posición.
                    <span
                        id="estadoOrden"
                        class="order-status"
                        aria-live="polite"
                    ></span>
                </p>
            </div>
            <span class="total-chip">
                <?php echo (int) $totalCatalogos; ?>
                <?php echo $totalCatalogos === 1 ? 'proceso' : 'procesos'; ?>
            </span>
        </div>

        <?php if ($catalogos && $totalCatalogos > 0): ?>
            <div
                id="listaCatalogos"
                class="catalogos"
                role="list"
                data-csrf="<?php echo escaparCatalogo($_SESSION['csrf_token']); ?>"
            >
                    <?php $posicionCatalogo = 0; ?>
                <?php while ($catalogo = $catalogos->fetch_assoc()): ?>
                    <article
                        class="catalogo"
                        role="listitem"
                        data-id="<?php echo (int) $catalogo['id_catalogo']; ?>"
                        title="<?php echo escaparCatalogo($catalogo['descripcion']); ?>"
                    >
                        <strong>
                            <?php echo escaparCatalogo($catalogo['nombre']); ?>
                        </strong>
                        <img
                            src="<?php echo escaparCatalogo(
                                seguridadUrlImagenCatalogo(
                                    (int) $catalogo['id_catalogo'],
                                    $catalogo['imagen']
                                )
                            ); ?>"
                            alt="Imagen del proceso <?php echo escaparCatalogo($catalogo['nombre']); ?>"
                            loading="lazy"
                            decoding="async"
                            draggable="false"
                        >
                        <small>
                                Posición <?php echo ++$posicionCatalogo; ?>
                        </small>
                    </article>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty">
                No hay procesos activos. Use “Administrar procesos” para crear
                o habilitar una.
            </div>
        <?php endif; ?>
    </section>

    <footer class="footer">
        <span class="smartdesk-wordmark"><span class="smart">SMART</span><span class="desk">DESK</span> · Procesos</span>
        <span>Ordenamiento y administración de procesos de servicio</span>
    </footer>
</main>

<script>
    /*
     * El módulo puede abrirse varias veces dentro del mismo contenedor.
     * Un ámbito propio permite reinicializar el ordenamiento sin volver a
     * declarar variables globales const/let de una visita anterior.
     */
    (function iniciarOrdenamientoAreas() {
    const listaCatalogos = document.getElementById('listaCatalogos');
    const estadoOrden = document.getElementById('estadoOrden');
    let catalogoArrastrado = null;
    let punteroArrastre = null;
    let ordenModificado = false;
    let guardandoOrden = false;
    let solicitudOrden = null;
    let secuenciaSolicitud = 0;

    function restablecerEstadoArrastre() {
        if (solicitudOrden) {
            solicitudOrden.abort();
        }
        solicitudOrden = null;
        guardandoOrden = false;
        secuenciaSolicitud += 1;

        punteroArrastre = null;
        catalogoArrastrado = null;
        ordenModificado = false;

        if (!listaCatalogos) {
            return;
        }

        listaCatalogos.classList.remove('guardando');
        listaCatalogos.querySelectorAll('.arrastrando').forEach(function (catalogo) {
            catalogo.classList.remove('arrastrando');
        });
    }

    function finalizarArrastre(event) {
        if (
            !catalogoArrastrado
            || !punteroArrastre
            || punteroArrastre.id !== event.pointerId
        ) {
            return;
        }

        if (punteroArrastre.activo) {
            const elementoDestino = document.elementFromPoint(
                event.clientX,
                event.clientY
            );
            const destino = elementoDestino
                ? elementoDestino.closest('.catalogo')
                : null;

            if (destino && destino !== catalogoArrastrado) {
                const catalogosActuales = Array.from(
                    listaCatalogos.querySelectorAll('.catalogo')
                );
                const indiceOrigen = catalogosActuales.indexOf(catalogoArrastrado);
                const indiceDestino = catalogosActuales.indexOf(destino);

                listaCatalogos.insertBefore(
                    catalogoArrastrado,
                    indiceOrigen < indiceDestino
                        ? destino.nextElementSibling
                        : destino
                );
                ordenModificado = true;
            }
        }

        catalogoArrastrado.classList.remove('arrastrando');
        const debeGuardar = ordenModificado;
        punteroArrastre = null;
        catalogoArrastrado = null;
        ordenModificado = false;

        if (debeGuardar) {
            guardarOrdenCatalogos();
        }
    }

    if (listaCatalogos) {
        listaCatalogos.querySelectorAll('.catalogo').forEach(function (catalogo) {
            catalogo.addEventListener('pointerdown', function (event) {
                if (event.button !== 0 || guardandoOrden) {
                    return;
                }

                catalogoArrastrado = catalogo;
                punteroArrastre = {
                    id: event.pointerId,
                    inicioX: event.clientX,
                    inicioY: event.clientY,
                    activo: false
                };
                ordenModificado = false;
                catalogo.setPointerCapture(event.pointerId);
            });

            catalogo.addEventListener('pointermove', function (event) {
                if (
                    catalogoArrastrado !== catalogo
                    || !punteroArrastre
                    || punteroArrastre.id !== event.pointerId
                ) {
                    return;
                }

                const distanciaX = event.clientX - punteroArrastre.inicioX;
                const distanciaY = event.clientY - punteroArrastre.inicioY;

                if (!punteroArrastre.activo && Math.hypot(distanciaX, distanciaY) < 6) {
                    return;
                }

                punteroArrastre.activo = true;
                catalogo.classList.add('arrastrando');
                event.preventDefault();
            });

        });
    }

    window.addEventListener('pointerup', finalizarArrastre);
    window.addEventListener('pointercancel', restablecerEstadoArrastre);

    window.addEventListener('pagehide', restablecerEstadoArrastre);

    window.addEventListener('pageshow', function () {
        restablecerEstadoArrastre();
    });

    async function guardarOrdenCatalogos() {
        if (!listaCatalogos || guardandoOrden) {
            return;
        }

        const datos = new URLSearchParams();
        datos.append('guardar_orden_catalogos', '1');
        datos.append('csrf_token', listaCatalogos.dataset.csrf);

        listaCatalogos.querySelectorAll('.catalogo').forEach(function (
            catalogo,
            indice
        ) {
            datos.append('orden[]', catalogo.dataset.id);

            const posicion = catalogo.querySelector('small');
            if (posicion) {
                posicion.textContent = 'Posición ' + (indice + 1);
            }
        });

        listaCatalogos.classList.add('guardando');
        estadoOrden.className = 'order-status';
        estadoOrden.textContent = 'Guardando...';
        guardandoOrden = true;
        const secuenciaActual = ++secuenciaSolicitud;
        solicitudOrden = window.AbortController
            ? new AbortController()
            : null;

        try {
            const respuesta = await fetch('catalogos.php', {
                method: 'POST',
                headers: {
                    'Content-Type':
                        'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: datos.toString(),
                signal: solicitudOrden ? solicitudOrden.signal : undefined
            });
            const resultado = await respuesta.json();

            if (!respuesta.ok || !resultado.ok) {
                throw new Error(
                    resultado.mensaje
                    || 'No fue posible guardar el orden.'
                );
            }

            estadoOrden.className = 'order-status success';
            estadoOrden.textContent = '✓ Orden guardado';
        } catch (error) {
            estadoOrden.className = 'order-status error';
            estadoOrden.textContent = '✕ ' + error.message;
        } finally {
            if (secuenciaActual !== secuenciaSolicitud) {
                return;
            }
            solicitudOrden = null;
            guardandoOrden = false;
            listaCatalogos.classList.remove('guardando');
        }
    }
    }());
</script>
<script src="assets/js/controlSesion.js" defer></script>
</body>
</html>
