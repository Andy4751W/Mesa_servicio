<?php
declare(strict_types=1);

/*
 * Administración de servicios.
 * Los catálogos se muestran únicamente como selector de lectura.
 */
require_once APP_ROOT . '/security/validarSesion.php';

$archivoMatrizPrioridad = APP_ROOT . '/core/matrizPrioridad.php';

if (!is_file($archivoMatrizPrioridad)) {
    http_response_code(503);
    exit(
        'Falta instalar app/core/matrizPrioridad.php. '
        . 'Copie ese archivo antes de administrar servicios.'
    );
}

require_once $archivoMatrizPrioridad;
seguridadExigirRol([1]);
$idPaisOperacion = paisExigirContexto();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function escapar($valor)
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function mostrarGuiaMatrizPrioridad(): void
{
    ?>
    <section class="priority-matrix-guide form-span-full" aria-label="Guía de la matriz de prioridades">
        <div class="priority-guide-heading">
            <div>
                <span class="priority-guide-kicker">Matriz corporativa predeterminada</span>
                <strong>¿Cómo se calcula la prioridad?</strong>
            </div>
            <p>Seleccione únicamente un número de urgencia y uno de impacto. El sistema calcula la prioridad; no se crean opciones manuales.</p>
        </div>
        <div class="priority-guide-scales">
            <div>
                <span>Urgencia</span>
                <ol>
                    <li><b>1</b> Más tarde</li>
                    <li><b>2</b> Pronto</li>
                    <li><b>3</b> Inmediato</li>
                </ol>
            </div>
            <div>
                <span>Impacto</span>
                <ol>
                    <li><b>1</b> Bajo</li>
                    <li><b>2</b> Moderado</li>
                    <li><b>3</b> Urgente</li>
                </ol>
            </div>
            <div class="priority-guide-formula">
                <span>Resultado automático</span>
                <strong>Urgencia + Impacto − 1</strong>
                <small>Prioridad final de 1 a 5</small>
            </div>
        </div>
        <div class="priority-guide-results" aria-label="Escala de prioridad resultante">
            <span class="priority-result p1"><b>1</b> Baja</span>
            <span class="priority-result p2"><b>2</b> Baja moderada</span>
            <span class="priority-result p3"><b>3</b> Moderada</span>
            <span class="priority-result p4"><b>4</b> Moderada urgente</span>
            <span class="priority-result p5"><b>5</b> Urgente</span>
        </div>
    </section>
    <?php
}

function redirigirServicio($idCatalogo, $mensaje)
{
    $esSolicitudAjax = strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''))
        === 'xmlhttprequest';

    if ($esSolicitudAjax) {
        $codigosExitosos = [
            'servicio_creado',
            'servicio_actualizado',
            'servicio_inhabilitado',
            'servicio_habilitado',
        ];
        $operacionExitosa = in_array($mensaje, $codigosExitosos, true);

        http_response_code($operacionExitosa ? 200 : 422);
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode(
            [
                'ok' => $operacionExitosa,
                'codigo' => (string) $mensaje,
            ],
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
        exit;
    }

    $url = 'servicios.php?msg=' . urlencode($mensaje);

    if ($idCatalogo) {
        $url = 'servicios.php?id_catalogo=' . (int) $idCatalogo
            . '&msg=' . urlencode($mensaje);
    }

    header('Location: ' . $url);
    exit;
}

function slaActivoDisponible($conn, $idSla)
{
    if (!$idSla) {
        return false;
    }

    $stmt = $conn->prepare(
        "SELECT id_sla
         FROM sla
         WHERE id_sla = ?
           AND id_pais_operacion = ?
           AND estado = 'activo'"
    );
    $idPais = paisExigirContexto();
    $stmt->bind_param("ii", $idSla, $idPais);
    $stmt->execute();
    $stmt->store_result();
    $disponible = $stmt->num_rows > 0;
    $stmt->close();

    return $disponible;
}

function gestorActivoDisponibleParaProceso(
    mysqli $conn,
    int $idGestor,
    string $proceso
): bool {
    $proceso = trim($proceso);

    if ($idGestor < 1 || $proceso === '') {
        return false;
    }

    $idPais = paisExigirContexto();
    $stmt = $conn->prepare(
        "SELECT id_usuario
         FROM usuarios
         WHERE id_usuario = ?
           AND id_rol = 2
           AND id_pais_operacion = ?
           AND estado = 'activo'
           AND TRIM(proceso) = ?
         LIMIT 1"
    );
    $stmt->bind_param('iis', $idGestor, $idPais, $proceso);
    $stmt->execute();
    $stmt->store_result();
    $disponible = $stmt->num_rows === 1;
    $stmt->close();

    return $disponible;
}

function moduloOpcionesServicioDisponible($conn)
{
    try {
        $resultado = $conn->query(
            "SHOW TABLES LIKE 'configuraciones_servicio'"
        );

        if (!$resultado || $resultado->num_rows === 0) {
            return false;
        }

        foreach (['id_prioridad', 'urgencia_valor', 'impacto_valor', 'prioridad_valor'] as $columna) {
            $columnas = $conn->query(
                "SHOW COLUMNS FROM servicios LIKE '" . $conn->real_escape_string($columna) . "'"
            );

            if (!$columnas || $columnas->num_rows === 0) {
                return false;
            }
        }

        return true;
    } catch (Throwable $e) {
        return false;
    }
}

function opcionRiesgoPorValor(
    mysqli $conn,
    string $tipo,
    int $valor
): ?int {
    if (!in_array($tipo, ['urgencia', 'impacto', 'prioridad'], true)) {
        return null;
    }

    $idPais = paisExigirContexto();
    $stmt = $conn->prepare(
        "SELECT id_opcion
         FROM configuraciones_servicio
         WHERE id_pais_operacion = ?
           AND tipo = ?
           AND estado_registro = 'activo'
           AND orden = ?
         ORDER BY id_opcion
         LIMIT 1"
    );
    $stmt->bind_param('isi', $idPais, $tipo, $valor);
    $stmt->execute();
    $fila = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $fila ? (int) $fila['id_opcion'] : null;
}

function clasificacionServicioDisponible($conn): bool
{
    try {
        $columnas = $conn->query(
            "SHOW COLUMNS FROM servicios LIKE 'tipo_solicitud'"
        );

        return $columnas !== false && $columnas->num_rows > 0;
    } catch (Throwable $e) {
        return false;
    }
}

function clasificacionServicioActiva(mysqli $conn, string $nombre): bool
{
    $nombre = trim($nombre);
    if ($nombre === '') {
        return false;
    }

    $stmt = $conn->prepare(
        "SELECT id_opcion
         FROM configuraciones_servicio
         WHERE tipo = 'clasificacion'
           AND nombre = ?
           AND id_pais_operacion = ?
           AND estado_registro = 'activo'
         LIMIT 1"
    );
    $idPais = paisExigirContexto();
    $stmt->bind_param('si', $nombre, $idPais);
    $stmt->execute();
    $stmt->store_result();
    $activa = $stmt->num_rows > 0;
    $stmt->close();

    return $activa;
}

function opcionServicioDisponible($conn, $idOpcion, $tipo)
{
    if (!$idOpcion) {
        return false;
    }

    $stmt = $conn->prepare(
        "SELECT id_opcion
         FROM configuraciones_servicio
         WHERE id_opcion = ?
           AND tipo = ?
           AND id_pais_operacion = ?
           AND estado_registro = 'activo'
         LIMIT 1"
    );
    $idPais = paisExigirContexto();
    $stmt->bind_param("isi", $idOpcion, $tipo, $idPais);
    $stmt->execute();
    $stmt->store_result();
    $disponible = $stmt->num_rows > 0;
    $stmt->close();

    return $disponible;
}

function relacionOpcionesServicioValida(
    $conn,
    $idHijo,
    $tipoHijo,
    $idPadre
) {
    if (!$idHijo || !$idPadre) {
        return false;
    }

    $stmt = $conn->prepare(
        "SELECT id_opcion
         FROM configuraciones_servicio
         WHERE id_opcion = ?
           AND tipo = ?
           AND id_padre = ?
           AND id_pais_operacion = ?
           AND estado_registro = 'activo'
         LIMIT 1"
    );
    $idPais = paisExigirContexto();
    $stmt->bind_param("isii", $idHijo, $tipoHijo, $idPadre, $idPais);
    $stmt->execute();
    $stmt->store_result();
    $valida = $stmt->num_rows > 0;
    $stmt->close();

    return $valida;
}

function leerOpcionesServicio(
    $conn,
    $camposConfiguracion,
    $camposObligatorios
) {
    $valores = [];

    foreach ($camposConfiguracion as $campo => $tipo) {
        $valor = filter_input(INPUT_POST, $campo, FILTER_VALIDATE_INT);
        $idOpcion = $valor !== false && $valor !== null
            ? (int) $valor
            : 0;

        if (
            in_array($campo, $camposObligatorios, true)
            && $idOpcion <= 0
        ) {
            return null;
        }

        if (
            $idOpcion > 0
            && !opcionServicioDisponible($conn, $idOpcion, $tipo)
        ) {
            return null;
        }

        $valores[$campo] = $idOpcion;
    }

    $relaciones = [];

    foreach ($relaciones as [$campoHijo, $tipoHijo, $campoPadre]) {
        $idHijo = $valores[$campoHijo] ?? 0;
        $idPadre = $valores[$campoPadre] ?? 0;

        if (
            $idHijo > 0
            && !relacionOpcionesServicioValida(
                $conn,
                $idHijo,
                $tipoHijo,
                $idPadre
            )
        ) {
            return null;
        }
    }

    return $valores;
}

$camposConfiguracionServicio = [
    'id_prioridad' => 'prioridad',
    'id_urgencia' => 'urgencia',
    'id_nivel' => 'nivel',
    'id_impacto' => 'impacto',
];

$camposConfiguracionObligatorios = [
    'id_nivel',
];

$moduloOpcionesInstalado = moduloOpcionesServicioDisponible($conn);

if (!$moduloOpcionesInstalado) {
    http_response_code(503);
    exit('Ejecute la migración 010_matriz_prioridad_servicios.sql antes de administrar servicios.');
}

if (!clasificacionServicioDisponible($conn)) {
    http_response_code(503);
    exit('Ejecute la migración 007_clasificacion_y_atencion_servicio.sql antes de administrar servicios.');
}

// Crear, editar e inhabilitar/habilitar servicios.
// Los servicios no se eliminan para conservar la trazabilidad de casos existentes.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    seguridadExigirOrigenPost();
    $token = $_POST['csrf_token'] ?? '';
    $idCatalogo = filter_input(INPUT_POST, 'id_catalogo', FILTER_VALIDATE_INT);

    if (!is_string($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        redirigirServicio($idCatalogo, 'solicitud_invalida');
    }

    if (!$idCatalogo) {
        redirigirServicio(null, 'datos_incompletos');
    }

    try {
        if (isset($_POST['nuevo_servicio'])) {
            $nombre = trim($_POST['nombre'] ?? '');
            $descripcion = trim($_POST['descripcion'] ?? '');
            $tipoSolicitud = (string) ($_POST['tipo_solicitud'] ?? '');
            $idSla = filter_input(INPUT_POST, 'id_sla', FILTER_VALIDATE_INT);
            $idGestor = filter_input(INPUT_POST, 'id_gestor', FILTER_VALIDATE_INT);
            $proceso = trim((string) ($_POST['proceso'] ?? ''));
            $urgenciaValor = matrizPrioridadValorValido($_POST['urgencia_valor'] ?? null);
            $impactoValor = matrizPrioridadValorValido($_POST['impacto_valor'] ?? null);

            if (
                $nombre === ''
                || $descripcion === ''
                || !$idSla
                || !$idGestor
                || $proceso === ''
                || $urgenciaValor === null
                || $impactoValor === null
                || !clasificacionServicioActiva($conn, $tipoSolicitud)
            ) {
                redirigirServicio($idCatalogo, 'datos_incompletos');
            }

            if (!$moduloOpcionesInstalado) {
                redirigirServicio($idCatalogo, 'configuracion_pendiente');
            }

            $opcionesServicio = leerOpcionesServicio(
                $conn,
                $camposConfiguracionServicio,
                $camposConfiguracionObligatorios
            );

            if ($opcionesServicio === null) {
                redirigirServicio(
                    $idCatalogo,
                    'configuracion_no_disponible'
                );
            }

            if (!slaActivoDisponible($conn, $idSla)) {
                redirigirServicio($idCatalogo, 'sla_no_disponible');
            }

            if (!gestorActivoDisponibleParaProceso(
                $conn,
                (int) $idGestor,
                $proceso
            )) {
                redirigirServicio($idCatalogo, 'gestor_no_disponible');
            }

            $matriz = matrizPrioridadCalcular($urgenciaValor, $impactoValor);
            $opcionesServicio['id_prioridad'] = opcionRiesgoPorValor(
                $conn,
                'prioridad',
                $matriz['prioridad_valor']
            ) ?? 0;
            $opcionesServicio['id_urgencia'] = opcionRiesgoPorValor(
                $conn,
                'urgencia',
                $urgenciaValor
            ) ?? 0;
            $opcionesServicio['id_impacto'] = opcionRiesgoPorValor(
                $conn,
                'impacto',
                $impactoValor
            ) ?? 0;

            $stmtCatalogo = $conn->prepare(
                "SELECT id_catalogo
                 FROM catalogos
                 WHERE id_catalogo = ?
                   AND id_pais_operacion = ?
                   AND estado = 'activo'"
            );
            $stmtCatalogo->bind_param("ii", $idCatalogo, $idPaisOperacion);
            $stmtCatalogo->execute();
            $stmtCatalogo->store_result();

            if ($stmtCatalogo->num_rows === 0) {
                $stmtCatalogo->close();
                redirigirServicio($idCatalogo, 'catalogo_no_disponible');
            }
            $stmtCatalogo->close();

$stmt = $conn->prepare(
    "INSERT INTO servicios
        (
            id_pais_operacion,
            id_catalogo,
            proceso,
            id_sla,
            id_gestor,
            nombre,
            descripcion,
            tipo_solicitud,
            estado,
            id_prioridad,
            prioridad_valor,
            id_urgencia,
            urgencia_valor,
            id_nivel,
            id_impacto,
            impacto_valor
        )
     VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, 'activo',
        NULLIF(?, 0), ?, NULLIF(?, 0), ?, ?, NULLIF(?, 0), ?
     )"
);
$stmt->bind_param(
    "iisiiissiiiiiii",
    $idPaisOperacion,
    $idCatalogo,
    $proceso,
    $idSla,
    $idGestor,
    $nombre,
    $descripcion,
    $tipoSolicitud,
    $opcionesServicio['id_prioridad'],
    $matriz['prioridad_valor'],
    $opcionesServicio['id_urgencia'],
    $urgenciaValor,
    $opcionesServicio['id_nivel'],
    $opcionesServicio['id_impacto'],
    $impactoValor
);

            if (!$stmt->execute()) {
                throw new RuntimeException('No fue posible crear el servicio.');
            }

            $stmt->close();
            redirigirServicio($idCatalogo, 'servicio_creado');
        }

        if (isset($_POST['editar_servicio'])) {
            $idServicio = filter_input(INPUT_POST, 'id_servicio', FILTER_VALIDATE_INT);
            $nombre = trim($_POST['nombre'] ?? '');
            $descripcion = trim($_POST['descripcion'] ?? '');
            $tipoSolicitud = (string) ($_POST['tipo_solicitud'] ?? '');
            $idSla = filter_input(INPUT_POST, 'id_sla', FILTER_VALIDATE_INT);
            $idGestor = filter_input(INPUT_POST, 'id_gestor', FILTER_VALIDATE_INT);
            $proceso = trim((string) ($_POST['proceso'] ?? ''));
            $urgenciaValor = matrizPrioridadValorValido($_POST['urgencia_valor'] ?? null);
            $impactoValor = matrizPrioridadValorValido($_POST['impacto_valor'] ?? null);

            $clasificacionActual = '';
            if ($idServicio) {
                $stmtClasificacionActual = $conn->prepare(
                    "SELECT tipo_solicitud
                     FROM servicios
                     WHERE id_servicio = ?
                       AND id_catalogo = ?
                       AND id_pais_operacion = ?
                     LIMIT 1"
                );
                $stmtClasificacionActual->bind_param(
                    'iii',
                    $idServicio,
                    $idCatalogo,
                    $idPaisOperacion
                );
                $stmtClasificacionActual->execute();
                $clasificacionActual = (string) (
                    $stmtClasificacionActual->get_result()->fetch_assoc()['tipo_solicitud'] ?? ''
                );
                $stmtClasificacionActual->close();
            }

            if (
                !$idServicio
                || $nombre === ''
                || $descripcion === ''
                || !$idSla
                || !$idGestor
                || $proceso === ''
                || $urgenciaValor === null
                || $impactoValor === null
                || (
                    $tipoSolicitud !== $clasificacionActual
                    && !clasificacionServicioActiva($conn, $tipoSolicitud)
                )
            ) {
                redirigirServicio($idCatalogo, 'datos_incompletos');
            }

            if (!$moduloOpcionesInstalado) {
                redirigirServicio($idCatalogo, 'configuracion_pendiente');
            }

            $opcionesServicio = leerOpcionesServicio(
                $conn,
                $camposConfiguracionServicio,
                $camposConfiguracionObligatorios
            );

            if ($opcionesServicio === null) {
                redirigirServicio(
                    $idCatalogo,
                    'configuracion_no_disponible'
                );
            }

            if (!slaActivoDisponible($conn, $idSla)) {
                redirigirServicio($idCatalogo, 'sla_no_disponible');
            }

            if (!gestorActivoDisponibleParaProceso(
                $conn,
                (int) $idGestor,
                $proceso
            )) {
                redirigirServicio($idCatalogo, 'gestor_no_disponible');
            }

            $matriz = matrizPrioridadCalcular($urgenciaValor, $impactoValor);
            $opcionesServicio['id_prioridad'] = opcionRiesgoPorValor(
                $conn,
                'prioridad',
                $matriz['prioridad_valor']
            ) ?? 0;
            $opcionesServicio['id_urgencia'] = opcionRiesgoPorValor(
                $conn,
                'urgencia',
                $urgenciaValor
            ) ?? 0;
            $opcionesServicio['id_impacto'] = opcionRiesgoPorValor(
                $conn,
                'impacto',
                $impactoValor
            ) ?? 0;

$stmt = $conn->prepare(
    "UPDATE servicios
     SET
        nombre = ?,
        descripcion = ?,
        tipo_solicitud = ?,
        id_sla = ?,
        id_gestor = ?,
        proceso = ?,
        id_prioridad = NULLIF(?, 0),
        prioridad_valor = ?,
        id_urgencia = NULLIF(?, 0),
        urgencia_valor = ?,
        id_nivel = ?,
        id_impacto = NULLIF(?, 0),
        impacto_valor = ?
     WHERE id_servicio = ?
       AND id_catalogo = ?
       AND id_pais_operacion = ?"
);
$stmt->bind_param(
    "sssiisiiiiiii",
    $nombre,
    $descripcion,
    $tipoSolicitud,
    $idSla,
    $idGestor,
    $proceso,
    $opcionesServicio['id_prioridad'],
    $matriz['prioridad_valor'],
    $opcionesServicio['id_urgencia'],
    $urgenciaValor,
    $opcionesServicio['id_nivel'],
    $opcionesServicio['id_impacto'],
    $impactoValor,
    $idServicio,
    $idCatalogo,
    $idPaisOperacion
);

            if (!$stmt->execute()) {
                throw new RuntimeException('No fue posible editar el servicio.');
            }

            $stmt->close();
            redirigirServicio($idCatalogo, 'servicio_actualizado');
        }

        if (isset($_POST['cambiar_estado_servicio'])) {
            $idServicio = filter_input(INPUT_POST, 'id_servicio', FILTER_VALIDATE_INT);
            $nuevoEstado = $_POST['nuevo_estado'] ?? '';

            if (
                !$idServicio ||
                !in_array($nuevoEstado, ['activo', 'inhabilitado'], true)
            ) {
                redirigirServicio($idCatalogo, 'solicitud_invalida');
            }

            $stmt = $conn->prepare(
                "UPDATE servicios
                 SET estado = ?
                 WHERE id_servicio = ?
                   AND id_catalogo = ?
                   AND id_pais_operacion = ?"
            );
            $stmt->bind_param("siii", $nuevoEstado, $idServicio, $idCatalogo, $idPaisOperacion);

            if (!$stmt->execute()) {
                throw new RuntimeException('No fue posible cambiar el estado del servicio.');
            }

            $stmt->close();
            redirigirServicio(
                $idCatalogo,
                $nuevoEstado === 'activo'
                    ? 'servicio_habilitado'
                    : 'servicio_inhabilitado'
            );
        }

        if (isset($_POST['eliminar_servicio'])) {
            redirigirServicio($idCatalogo, 'eliminacion_no_permitida');
        }
    } catch (Throwable $e) {
        error_log('Error en servicios.php: ' . $e->getMessage());
        redirigirServicio($idCatalogo, 'error_servicio');
    }
}

// En esta pantalla solo se muestran los catálogos activos.
$catalogos = $conn->query(
    "SELECT id_catalogo, nombre, descripcion, imagen, orden
     FROM catalogos
     WHERE estado = 'activo'
       AND id_pais_operacion = {$idPaisOperacion}
     ORDER BY orden ASC, nombre ASC"
);

$slasTodos = [];
$slasActivos = [];
$resultadoSlas = $conn->query(
    "SELECT id_sla, nombre, tiempo_respuesta, unidad, estado
     FROM sla
     WHERE id_pais_operacion = {$idPaisOperacion}
     ORDER BY estado ASC, tiempo_respuesta ASC, nombre ASC"
);

while ($sla = $resultadoSlas->fetch_assoc()) {
    $sla['id_sla'] = (int) $sla['id_sla'];
    $sla['tiempo_respuesta'] = (int) $sla['tiempo_respuesta'];
    $slasTodos[] = $sla;

    if ($sla['estado'] === 'activo') {
        $slasActivos[] = $sla;
    }
}

$gestoresActivos = [];
$resultadoGestores = $conn->query(
    "SELECT id_usuario, nombre, email, proceso
     FROM usuarios
     WHERE id_rol = 2
       AND id_pais_operacion = {$idPaisOperacion}
       AND estado = 'activo'
     ORDER BY nombre, email"
);

while ($gestor = $resultadoGestores->fetch_assoc()) {
    $gestor['id_usuario'] = (int) $gestor['id_usuario'];
    $gestor['proceso'] = (string) ($gestor['proceso'] ?? ''); // Guardamos el NOMBRE del proceso
    $gestoresActivos[] = $gestor;
}

$procesosActivos = [];
$resultadoProcesos = $conn->query(
    "SELECT DISTINCT proceso
     FROM usuarios
     WHERE id_rol = 2
       AND id_pais_operacion = {$idPaisOperacion}
       AND estado = 'activo'
       AND TRIM(proceso) <> ''
     ORDER BY proceso ASC"
);

while ($proceso = $resultadoProcesos->fetch_assoc()) {
    $proceso['proceso'] = (string) $proceso['proceso'];
    $procesosActivos[] = $proceso;
}

$opcionesConfiguracionActivas = array_fill_keys(
    array_values($camposConfiguracionServicio),
    []
);
$opcionesConfiguracionTodas = $opcionesConfiguracionActivas;
$clasificacionesServicioActivas = [];

if ($moduloOpcionesInstalado) {
    $resultadoOpciones = $conn->query(
        "SELECT
            id_opcion,
            tipo,
            id_padre,
            nombre,
            descripcion,
            color,
            estado_registro,
            orden
         FROM configuraciones_servicio
         WHERE id_pais_operacion = {$idPaisOperacion}
         ORDER BY
            tipo,
            FIELD(estado_registro, 'activo', 'inhabilitado'),
            orden,
            nombre"
    );

    while ($opcion = $resultadoOpciones->fetch_assoc()) {
        $tipoOpcion = $opcion['tipo'];

        if ($tipoOpcion === 'clasificacion') {
            if ($opcion['estado_registro'] === 'activo') {
                $clasificacionesServicioActivas[] = $opcion;
            }
            continue;
        }

        if (!array_key_exists($tipoOpcion, $opcionesConfiguracionTodas)) {
            continue;
        }

        $opcion['id_opcion'] = (int) $opcion['id_opcion'];
        $opcion['id_padre'] = (int) ($opcion['id_padre'] ?? 0);
        $opcionesConfiguracionTodas[$tipoOpcion][] = $opcion;

        if ($opcion['estado_registro'] === 'activo') {
            $opcionesConfiguracionActivas[$tipoOpcion][] = $opcion;
        }
    }
}

$configuracionesObligatoriasDisponibles = $moduloOpcionesInstalado;

if (!$clasificacionesServicioActivas) {
    $configuracionesObligatoriasDisponibles = false;
}

foreach (['nivel'] as $tipoObligatorio) {
    if (empty($opcionesConfiguracionActivas[$tipoObligatorio])) {
        $configuracionesObligatoriasDisponibles = false;
        break;
    }
}

$nombresOpcionesServicio = [];

foreach (['prioridad', 'urgencia'] as $tipoResumen) {
    foreach ($opcionesConfiguracionTodas[$tipoResumen] ?? [] as $opcionResumen) {
        $nombresOpcionesServicio[(int) $opcionResumen['id_opcion']] = [
            'nombre' => (string) $opcionResumen['nombre'],
            'color' => (string) ($opcionResumen['color'] ?? '#64748b'),
        ];
    }
}

$etiquetasConfiguracionServicio = [
    'id_prioridad' => 'Prioridad',
    'id_urgencia' => 'Urgencia',
    'id_nivel' => 'Nivel',
    'id_impacto' => 'Impacto',
];

$padresConfiguracionServicio = [];

$unidadesSla = [
    'minutos' => 'minuto(s)',
    'horas' => 'hora(s)',
    'dias' => 'día(s)',
];

$servicios = null;
$idCatalogoSeleccionado = filter_input(INPUT_GET, 'id_catalogo', FILTER_VALIDATE_INT);
$catalogoSeleccionado = null;
$camposSeleccionConfiguracion = $moduloOpcionesInstalado
    ? "
        s.id_prioridad,
        s.prioridad_valor,
        s.id_urgencia,
        s.urgencia_valor,
        s.id_nivel,
        s.id_impacto,
        s.impacto_valor,
        s.id_estado,"
    : "
        NULL AS id_prioridad,
        NULL AS prioridad_valor,
        NULL AS id_urgencia,
        NULL AS urgencia_valor,
        NULL AS id_nivel,
        NULL AS id_impacto,
        NULL AS impacto_valor,
        NULL AS id_estado,";

if ($idCatalogoSeleccionado) {
    $stmt = $conn->prepare(
        "SELECT id_catalogo, nombre
         FROM catalogos
         WHERE id_catalogo = ?
           AND id_pais_operacion = ?
           AND estado = 'activo'"
    );
    $stmt->bind_param("ii", $idCatalogoSeleccionado, $idPaisOperacion);
    $stmt->execute();
    $resultadoCatalogo = $stmt->get_result();
    $catalogoSeleccionado = $resultadoCatalogo->fetch_assoc();
    $stmt->close();

    if ($catalogoSeleccionado) {
        $stmtServicios = $conn->prepare(
    "SELECT
        s.id_servicio,
        s.nombre,
        s.descripcion,
        s.tipo_solicitud,
        s.id_sla,
        s.id_gestor,
        s.proceso,
        {$camposSeleccionConfiguracion}
        s.estado,
        u.nombre AS gestor_nombre,
        u.estado AS gestor_estado,
        sl.nombre AS sla_nombre,
        sl.tiempo_respuesta AS sla_tiempo,
        sl.unidad AS sla_unidad,
        sl.estado AS sla_estado
     FROM servicios AS s
     LEFT JOIN usuarios AS u ON u.id_usuario = s.id_gestor
     LEFT JOIN sla AS sl ON sl.id_sla = s.id_sla
     WHERE s.id_catalogo = ?
       AND s.id_pais_operacion = ?
     ORDER BY s.id_servicio DESC"
);
        $stmtServicios->bind_param("ii", $idCatalogoSeleccionado, $idPaisOperacion);
        $stmtServicios->execute();
        $servicios = $stmtServicios->get_result();
    }
}

$filtrosClasificacionServicio = [];
$filtrosProcesoServicio = [];
$filtrosGestorServicio = [];
$filtrosEstadoServicio = [];

if ($servicios && $servicios->num_rows > 0) {
    while ($servicioFiltro = $servicios->fetch_assoc()) {
        $clasificacionFiltro = trim((string) ($servicioFiltro['tipo_solicitud'] ?? ''));
        $procesoFiltro = trim((string) ($servicioFiltro['proceso'] ?? ''));
        $gestorFiltro = trim((string) ($servicioFiltro['gestor_nombre'] ?? ''));
        $estadoFiltro = trim((string) ($servicioFiltro['estado'] ?? ''));

        if ($clasificacionFiltro !== '') {
            $filtrosClasificacionServicio[$clasificacionFiltro] = $clasificacionFiltro;
        }
        if ($procesoFiltro !== '') {
            $filtrosProcesoServicio[$procesoFiltro] = $procesoFiltro;
        }
        if ($gestorFiltro !== '') {
            $filtrosGestorServicio[$gestorFiltro] = $gestorFiltro;
        }
        if ($estadoFiltro !== '') {
            $filtrosEstadoServicio[$estadoFiltro] = $estadoFiltro;
        }
    }

    natcasesort($filtrosClasificacionServicio);
    natcasesort($filtrosProcesoServicio);
    natcasesort($filtrosGestorServicio);
    natcasesort($filtrosEstadoServicio);
    $servicios->data_seek(0);
}

$mensajes = [
    'servicio_creado' => ['exito', '✅ Servicio creado correctamente.'],
    'servicio_actualizado' => ['exito', '✏️ Servicio actualizado correctamente.'],
    'servicio_inhabilitado' => ['aviso', '⚠️ Servicio inhabilitado correctamente.'],
    'servicio_habilitado' => ['exito', '✅ Servicio habilitado correctamente.'],
    'servicio_no_encontrado' => ['error', '❌ El servicio seleccionado no existe.'],
    'error_servicio' => ['error', '❌ No fue posible procesar la operación del servicio.'],
    'eliminacion_no_permitida' => [
        'aviso',
        'Los servicios no se pueden eliminar. Puede inhabilitarlos para conservar el historial.'
    ],
    'solicitud_invalida' => ['error', '❌ La solicitud no es válida. Inténtelo nuevamente.'],
    'datos_incompletos' => ['error', '❌ Complete los campos obligatorios.'],
    'catalogo_no_disponible' => ['error', '❌ El área seleccionada no está disponible.'],
    'sla_no_disponible' => [
        'error',
        '❌ Seleccione un SLA activo y disponible para el servicio.'
    ],
    'gestor_no_disponible' => [
        'error',
        '❌ El gestor seleccionado no está activo o no pertenece al proceso elegido.'
    ],
    'configuracion_pendiente' => [
        'aviso',
        '⚠️ Instale los módulos de opciones antes de administrar servicios.'
    ],
    'configuracion_no_disponible' => [
        'error',
        '❌ Seleccione opciones activas y complete los parámetros obligatorios del servicio.'
    ],
];

$mensajeActual = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="catalogos-version" content="sla-1.3-interfaz">
    <title>Servicios | Mesa de Servicio</title>
    <style>
        :root {
            --primary: #1f5f99;
            --primary-dark: #163f65;
            --navy: #132f4c;
            --text: #263b50;
            --muted: #64788b;
            --surface: #ffffff;
            --background: #f3f6fb;
            --border: #dfe7f1;
            --danger: #a72836;
            --shadow: 0 16px 40px rgba(15, 45, 75, 0.09);
        }
        * {
            box-sizing: border-box;
        }
        html {
            min-height: 100%;
        }
        body {
            min-height: 100vh;
            margin: 0;
            color: var(--text);
            background:
                radial-gradient(circle at 6% 0%, rgba(31, 95, 153, 0.09), transparent 25%),
                var(--background);
            font-family: Inter, "Segoe UI", Roboto, Arial, sans-serif;
            line-height: 1.45;
        }
        button,
        input,
        textarea,
        select {
            font: inherit;
        }
        .page-shell {
            width: calc(100% - 24px);
            max-width: none;
            min-width: 0;
            margin: 0 auto;
            padding: 28px 0 40px;
        }
        .topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            margin-bottom: 22px;
            padding: 13px 17px;
            border: 1px solid rgba(223, 231, 241, 0.9);
            border-radius: 16px;
            background: rgba(255, 255, 255, 0.94);
            box-shadow: 0 8px 24px rgba(15, 45, 75, 0.06);
        }
        .brand {
            display: flex;
            align-items: center;
            gap: 11px;
            flex: 0 0 auto;
        }
        .brand-mark {
            display: grid;
            width: 40px;
            height: 40px;
            place-items: center;
            border-radius: 11px;
            color: #fff;
            background: linear-gradient(145deg, #2b73ad, #163f65);
            box-shadow: 0 8px 18px rgba(22, 63, 101, 0.24);
            font-size: 14px;
            font-weight: 800;
        }
        .brand-name,
        .brand-subtitle {
            margin: 0;
        }
        .brand-name {
            color: var(--navy);
            font-size: 15px;
            font-weight: 750;
        }
        .brand-subtitle {
            color: var(--muted);
            font-size: 11px;
        }
        .barra-acciones {
            display: flex;
            flex-wrap: wrap;
            justify-content: flex-end;
            gap: 7px;
        }
        .btn-volver,
        .open-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            min-height: 38px;
            padding: 9px 12px;
            border: 1px solid #dce6f1;
            border-radius: 9px;
            color: #315779;
            background: #f7faff;
            text-decoration: none;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            transition:
                color 0.18s ease,
                border-color 0.18s ease,
                background 0.18s ease,
                transform 0.18s ease;
        }
        .btn-volver:hover,
        .open-btn:hover {
            color: var(--primary-dark);
            border-color: #bfd2e5;
            background: #edf5ff;
        }
        .hero {
            position: relative;
            z-index: 1;
            min-height: 58px;
            padding: 9px 14px;
            overflow: hidden;
            border-radius: 12px;
            color: #fff;
            background: linear-gradient(120deg, #132f4c 0%, #1f5f99 62%, #2b76aa 100%);
            box-shadow: 0 8px 20px rgba(15, 45, 75, 0.10);
        }
        .hero::after {
            position: absolute;
            top: -45px;
            right: -18px;
            width: 112px;
            height: 112px;
            border: 16px solid rgba(255, 255, 255, 0.07);
            border-radius: 50%;
            content: "";
        }
        .hero-copy {
            position: relative;
            z-index: 1;
            max-width: 720px;
        }
        .eyebrow {
            display: none;
        }
        .hero h1,
        .hero p {
            margin: 0;
        }
        .hero h1 {
            font-size: 17px;
            line-height: 1.18;
            letter-spacing: -0.2px;
        }
        .hero p {
            max-width: 650px;
            margin-top: 2px;
            color: rgba(255, 255, 255, 0.83);
            overflow: hidden;
            font-size: 11px;
            line-height: 1.3;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .content-section {
            width: 100%;
            max-width: none;
            min-width: 0;
            margin-top: 14px;
        }
        .section-heading {
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 14px;
        }
        .section-heading h2,
        .section-heading p {
            margin: 0;
        }
        .section-heading h2 {
            color: var(--navy);
            font-size: 21px;
            letter-spacing: -0.3px;
        }
        .section-heading p {
            margin-top: 3px;
            color: var(--muted);
            font-size: 12px;
        }
        .seleccion-chip {
            flex: 0 0 auto;
            padding: 7px 11px;
            border: 1px solid #dce7f3;
            border-radius: 9px;
            color: #486581;
            background: rgba(255, 255, 255, 0.84);
            font-size: 11px;
            font-weight: 700;
        }
        .catalogos {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(175px, 1fr));
            gap: 12px;
            margin: 0;
        }
        .catalogo {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: stretch;
            justify-content: flex-start;
            min-width: 0;
            min-height: 165px;
            padding: 11px;
            border: 1px solid var(--border);
            border-radius: 16px;
            color: var(--text);
            background: var(--surface);
            box-shadow: 0 8px 22px rgba(31, 62, 93, 0.065);
            text-decoration: none;
            text-align: left;
            cursor: pointer;
            user-select: none;
            transition:
                transform 0.18s ease,
                opacity 0.15s ease,
                border-color 0.18s ease,
                box-shadow 0.18s ease,
                color 0.18s ease;
        }
        .catalogo:hover {
            transform: translateY(-3px);
            border-color: #a9c2db;
            box-shadow: 0 13px 28px rgba(31, 62, 93, 0.12);
        }
        .catalogo.seleccionado {
            color: #fff;
            border-color: var(--primary);
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            box-shadow: 0 13px 28px rgba(22, 63, 101, 0.24);
        }
        .catalogo img {
            width: 100%;
            height: 105px;
            display: block;
            margin-top: 7px;
            padding: 0;
            border: 1px solid #dce5ef;
            border-radius: 11px;
            background: #f7faff;
            object-fit: cover;
            object-position: center;
        }
        .catalogo span {
            display: block;
            overflow-wrap: anywhere;
            font-size: 13px;
            font-weight: 750;
            line-height: 1.3;
        }
        .ayuda-orden {
            display: flex;
            align-items: center;
            gap: 8px;
            margin: 0;
            color: var(--muted);
            font-size: 11px;
        }
        .estado-orden {
            display: inline-block;
            min-height: 18px;
            font-weight: 750;
        }
        .estado-orden.exito { color: #15703b; }
        .estado-orden.error { color: #922b36; }
        .servicios-panel {
            width: 100%;
            max-width: none;
            min-width: 0;
            margin-top: 29px;
        }
        .servicios-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            margin-bottom: 14px;
        }
        .servicios-toolbar h2,
        .servicios-toolbar p {
            margin: 0;
        }
        .servicios-toolbar h2 {
            color: var(--navy);
            font-size: 21px;
            letter-spacing: -0.3px;
        }
        .servicios-toolbar p {
            margin-top: 3px;
            color: var(--muted);
            font-size: 12px;
        }
        .btn-nuevo {
            flex: 0 0 auto;
            color: #fff;
            border-color: var(--primary);
            background: var(--primary);
            box-shadow: 0 7px 16px rgba(31, 95, 153, 0.22);
        }
        .btn-nuevo:hover {
            color: #fff;
            border-color: var(--primary-dark);
            background: var(--primary-dark);
            transform: translateY(-1px);
        }
        .service-name-filter {
            display: grid;
            grid-template-columns: minmax(220px, 1.35fr) repeat(4, minmax(150px, 1fr)) auto;
            align-items: end;
            gap: 12px;
            margin: 0 0 14px;
        }
        .service-name-filter label {
            display: block;
            margin-bottom: 5px;
            color: var(--navy);
            font-size: 11px;
            font-weight: 800;
        }
        .service-name-filter-control {
            position: relative;
        }
        .service-name-filter input,
        .service-name-filter select {
            width: 100%;
            min-height: 42px;
            border: 1px solid var(--border);
            border-radius: 11px;
            outline: none;
            color: var(--text);
            background: var(--surface);
            font: inherit;
            font-size: 13px;
            transition: border-color .16s ease, box-shadow .16s ease;
        }
        .service-name-filter input {
            padding: 9px 42px 9px 13px;
        }
        .service-name-filter select {
            padding: 9px 34px 9px 11px;
            cursor: pointer;
        }
        .service-name-filter input:focus,
        .service-name-filter select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px color-mix(in srgb, var(--primary) 18%, transparent);
        }
        .service-name-filter-clear {
            position: absolute;
            top: 50%;
            right: 7px;
            display: grid;
            width: 29px;
            height: 29px;
            padding: 0;
            place-items: center;
            border: 0;
            border-radius: 8px;
            color: var(--muted);
            background: transparent;
            cursor: pointer;
            transform: translateY(-50%);
        }
        .service-name-filter-clear:hover {
            color: var(--text);
            background: color-mix(in srgb, var(--primary) 9%, var(--surface));
        }
        .service-name-filter-result {
            min-width: 105px;
            padding-bottom: 11px;
            color: var(--muted);
            font-size: 12px;
            font-weight: 750;
            white-space: nowrap;
        }
        .service-filter-actions {
            display: flex;
            align-items: center;
            gap: 9px;
            padding-bottom: 1px;
        }
        .service-filter-reset {
            min-height: 42px;
            padding: 8px 13px;
            border: 1px solid var(--border);
            border-radius: 11px;
            color: var(--text);
            background: var(--surface);
            font: inherit;
            font-size: 12px;
            font-weight: 800;
            cursor: pointer;
        }
        .service-filter-reset:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: color-mix(in srgb, var(--primary) 7%, var(--surface));
        }
        .service-ajax-feedback {
            position: fixed;
            z-index: 99999;
            top: 18px;
            right: 18px;
            width: min(390px, calc(100vw - 36px));
            padding: 13px 16px;
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text);
            background: var(--surface);
            box-shadow: 0 18px 45px rgba(15, 23, 42, .22);
            font-size: 13px;
            font-weight: 800;
            transform: translateY(-12px);
            opacity: 0;
            pointer-events: none;
            transition: opacity .18s ease, transform .18s ease;
        }
        .service-ajax-feedback.visible {
            transform: translateY(0);
            opacity: 1;
        }
        .service-ajax-feedback.exito {
            border-color: color-mix(in srgb, #16a34a 45%, var(--border));
            color: color-mix(in srgb, #15803d 80%, var(--text));
            background: color-mix(in srgb, #dcfce7 72%, var(--surface));
        }
        .service-ajax-feedback.error {
            border-color: color-mix(in srgb, #dc2626 45%, var(--border));
            color: color-mix(in srgb, #b91c1c 80%, var(--text));
            background: color-mix(in srgb, #fee2e2 72%, var(--surface));
        }
        .fila-servicio[hidden],
        .fila-edicion[hidden],
        .service-filter-empty[hidden] {
            display: none !important;
        }
        .service-filter-empty td {
            padding: 30px 18px;
            color: var(--muted);
            background: var(--surface);
            text-align: center;
        }
        .tabla-contenedor {
            position: relative;
            width: 100%;
            max-width: 100%;
            min-width: 0;
            overflow-x: auto;
            overflow-y: visible;
            border: 1px solid var(--border);
            border-radius: 16px;
            background: var(--surface);
            box-shadow: 0 10px 28px rgba(31, 62, 93, 0.07);
            scrollbar-width: none;
        }
        .tabla-contenedor::-webkit-scrollbar {
            display: none;
        }
        #servicios-area {
            scroll-margin-top: 88px;
        }
        .tabla-scroll-superior {
            width: 100%;
            height: 12px;
            overflow-x: auto;
            overflow-y: hidden;
            margin-bottom: 5px;
            border-radius: 999px;
            scrollbar-color: var(--primary) var(--surface-soft);
            scrollbar-width: thin;
        }
        .tabla-scroll-superior > div {
            height: 1px;
        }
        .tabla-scroll-superior::-webkit-scrollbar {
            height: 9px;
        }
        .tabla-scroll-superior::-webkit-scrollbar-track {
            border-radius: 999px;
            background: var(--surface-soft);
        }
        .tabla-scroll-superior::-webkit-scrollbar-thumb {
            border: 2px solid var(--surface-soft);
            border-radius: 999px;
            background: var(--primary);
        }
        table {
            width: 100%;
            min-width: 1320px;
            border-collapse: collapse;
            table-layout: fixed;
            background: var(--surface);
            font-size: 12px;
        }
        #tablaServicios th:nth-child(1),
        #tablaServicios td:nth-child(1) { width: 170px; }
        #tablaServicios th:nth-child(2),
        #tablaServicios td:nth-child(2) { width: 260px; }
        #tablaServicios th:nth-child(3),
        #tablaServicios td:nth-child(3) { width: 125px; }
        #tablaServicios th:nth-child(4),
        #tablaServicios td:nth-child(4) { width: 145px; }
        #tablaServicios th:nth-child(5),
        #tablaServicios td:nth-child(5) { width: 155px; }
        #tablaServicios th:nth-child(6),
        #tablaServicios td:nth-child(6) { width: 135px; }
        #tablaServicios th:nth-child(7),
        #tablaServicios td:nth-child(7),
        #tablaServicios th:nth-child(8),
        #tablaServicios td:nth-child(8),
        #tablaServicios th:nth-child(9),
        #tablaServicios td:nth-child(9) { width: 125px; }
        #tablaServicios th:nth-child(10),
        #tablaServicios td:nth-child(10) { width: 105px; }
        #tablaServicios th:nth-child(11),
        #tablaServicios td:nth-child(11) { width: 120px; }
        th, td {
            padding: 11px 9px;
            border-right: 1px solid #e6edf5;
            border-bottom: 1px solid #e6edf5;
            text-align: center;
            vertical-align: middle;
            overflow-wrap: break-word;
            word-break: normal;
        }
        th:last-child,
        td:last-child {
            border-right: none;
        }
        tbody tr:last-child td {
            border-bottom: none;
        }
        th {
            color: #fff;
            background: var(--primary);
            font-size: 10px;
            letter-spacing: 0.03em;
            text-transform: uppercase;
        }
        tbody .fila-servicio:nth-of-type(4n + 3) {
            background: #f9fbfe;
        }
        tbody .fila-servicio:hover {
            background: #f1f6fc;
        }
        .fila-servicio > td {
            height: 68px;
            padding-top: 8px;
            padding-bottom: 8px;
        }
        th:nth-child(1) { width: 13%; }
        th:nth-child(2) { width: 22%; }
        th:nth-child(3) { width: 9%; }
        th:nth-child(4) { width: 9%; }
        th:nth-child(5) { width: 11%; }
        th:nth-child(6) { width: 9%; }
        th:nth-child(7) { width: 11%; }
        th:nth-child(8) { width: 7%; }
        th:nth-child(9) { width: 9%; }
        .service-name-cell {
            font-weight: 750;
            line-height: 1.35;
            text-align: left;
        }
        .service-description-cell {
            text-align: left;
            vertical-align: middle;
        }
        .service-description-text {
            max-height: 34px;
            overflow: hidden;
            color: var(--text);
            font-size: 11px;
            line-height: 17px;
            text-align: left;
            white-space: pre-wrap;
            overflow-wrap: anywhere;
            transition: max-height .2s ease;
        }
        .service-description-text.expanded {
            max-height: 150px;
            padding-right: 5px;
            overflow-y: auto;
            scrollbar-color: var(--primary) color-mix(in srgb, var(--surface) 88%, var(--border));
            scrollbar-width: thin;
        }
        .service-description-toggle {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-top: 5px;
            padding: 2px 0;
            border: 0;
            color: var(--primary);
            background: transparent;
            font: inherit;
            font-size: 10px;
            font-weight: 800;
            cursor: pointer;
        }
        .service-description-toggle[hidden] {
            display: none !important;
        }
        .service-description-toggle::after {
            content: "⌄";
            font-size: 12px;
            transition: transform .18s ease;
        }
        .service-description-toggle[aria-expanded="true"]::after {
            transform: rotate(180deg);
        }
        .service-description-toggle:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }
        .sla-info {
            display: inline-flex;
            flex-direction: column;
            gap: 2px;
            padding: 6px 9px;
            border-radius: 9px;
            color: #315779;
            background: #edf5fc;
        }
        .sla-info strong {
            font-size: 11px;
        }
        .sla-info small {
            color: var(--muted);
            font-size: 10px;
        }
        .service-classification,
        .attention-tag {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 25px;
            padding: 5px 8px;
            border: 1px solid #d8e4ef;
            border-radius: 999px;
            color: #315779;
            background: #f5f9fd;
            font-size: 9px;
            font-weight: 800;
        }
        .service-classification.incidente {
            color: #a73535;
            border-color: #efcaca;
            background: #fff3f3;
        }
        .attention-summary {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 4px;
        }
        .attention-summary .attention-tag {
            max-width: 100%;
            padding-inline: 6px;
            line-height: 1.2;
        }
        .attention-tag.priority-score {
            border-color: color-mix(in srgb, var(--priority-color) 55%, var(--border));
            color: var(--priority-color);
            background: color-mix(in srgb, var(--priority-color) 10%, var(--surface));
        }
        .estado-servicio {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-width: 68px;
            padding: 5px 8px;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 750;
            text-transform: capitalize;
        }
        .estado-servicio::before {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: currentColor;
            content: "";
        }
        .estado-servicio.activo {
            color: #15703b;
            background: #e5f6eb;
        }
        .estado-servicio.inhabilitado {
            color: #755a14;
            background: #fff3cf;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 35px;
            padding: 8px 12px;
            border: none;
            border-radius: 8px;
            color: #fff;
            text-decoration: none;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
        }
        .btn-edit { background: var(--primary); }
        .btn-cancel {
            color: #486581;
            border: 1px solid #d4dfe9;
            background: #fff;
        }
        .celda-acciones {
            position: relative;
            overflow: visible;
            white-space: nowrap;
        }
        .acciones-menu {
            position: relative;
            display: inline-block;
        }
        .acciones-menu summary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-width: 86px;
            padding: 7px 10px;
            border: 1px solid #cad8e8;
            border-radius: 8px;
            color: #315779;
            background: #f7faff;
            font-size: 10px;
            font-weight: 750;
            list-style: none;
            white-space: nowrap;
            cursor: pointer;
        }
        .acciones-menu summary::-webkit-details-marker {
            display: none;
        }
        .acciones-menu summary::after {
            content: "⌄";
            font-size: 12px;
            transition: transform 0.18s ease;
        }
        .acciones-menu[open] summary {
            color: #fff;
            border-color: var(--primary);
            background: var(--primary);
        }
        .acciones-menu[open] summary::after {
            transform: rotate(180deg);
        }
        .acciones-desplegable {
            position: absolute;
            top: calc(100% + 7px);
            right: 0;
            z-index: 60;
            width: 165px;
            padding: 6px;
            border: 1px solid #dce5ef;
            border-radius: 11px;
            background: #fff;
            box-shadow: 0 16px 34px rgba(15, 45, 75, 0.2);
            text-align: left;
        }
        .fila-servicio:nth-last-child(-n + 2) .acciones-desplegable {
            top: auto;
            bottom: calc(100% + 7px);
        }
        .acciones-desplegable form {
            margin: 0;
        }
        .accion-item {
            display: flex;
            align-items: center;
            gap: 9px;
            width: 100%;
            padding: 9px 10px;
            border: none;
            border-radius: 7px;
            color: #334e68;
            background: transparent;
            text-decoration: none;
            font-size: 11px;
            font-weight: 700;
            text-align: left;
            cursor: pointer;
        }
        .accion-item::before {
            display: grid;
            flex: 0 0 auto;
            width: 20px;
            height: 20px;
            place-items: center;
            border-radius: 6px;
            font-size: 11px;
        }
        .accion-editar::before {
            color: #0b5ec2;
            background: #eaf2ff;
            content: "✎";
        }
        .accion-estado::before {
            color: #526d82;
            background: #edf2f7;
            content: "◐";
        }
        .accion-habilitar::before {
            color: #0b5ec2;
            background: #eaf2ff;
            content: "✓";
        }
        .accion-item:hover {
            background: #f1f6fc;
        }
        .fila-edicion {
            display: none;
            background: #f6f9fd;
        }
        .fila-edicion td {
            width: 100%;
            padding: 12px;
            text-align: left;
        }
        .fila-edicion .config-service-form {
            width: 100%;
            max-width: none;
            max-height: min(76vh, 760px);
            padding: 18px;
            overflow-y: auto;
            overflow-x: hidden;
            overscroll-behavior: contain;
            border: 1px solid var(--border);
            border-radius: 13px;
            background: var(--surface);
            box-shadow: inset 0 1px 0 color-mix(in srgb, var(--surface) 85%, white);
            scrollbar-color: var(--primary) color-mix(in srgb, var(--surface) 88%, var(--border));
            scrollbar-width: thin;
        }
        .form-edicion {
            display: grid;
            grid-template-columns: 1fr 2fr 1fr;
            gap: 15px;
            align-items: start;
        }
        .form-edicion > div {
            min-width: 0;
        }
        .service-description-editor {
            min-height: 120px;
            max-height: 190px;
            overflow-y: auto;
            line-height: 1.45;
            text-align: left;
            white-space: pre-wrap;
            resize: vertical;
        }
        .form-edicion .acciones-edicion {
            grid-column: 1 / -1;
            display: flex;
            justify-content: flex-end;
            gap: 8px;
            position: sticky;
            bottom: -18px;
            z-index: 3;
            margin: 4px -18px -18px;
            padding: 12px 18px;
            border-top: 1px solid var(--border);
            background: color-mix(in srgb, var(--surface) 94%, transparent);
            backdrop-filter: blur(8px);
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 2147483647;
            inset: 0;
            padding: 24px;
            overflow-y: auto;
            background: rgba(9, 30, 54, 0.62);
            backdrop-filter: blur(4px);
        }
        .modal-content {
            position: relative;
            z-index: 1;
            width: min(820px, 100%);
            max-height: calc(100vh - 48px);
            margin: 0 auto;
            overflow-y: auto;
            border: 1px solid rgba(255, 255, 255, 0.6);
            border-radius: 18px;
            background: #fff;
            box-shadow: 0 28px 65px rgba(2, 20, 42, 0.32);
        }
        .modal-header {
            position: sticky;
            top: 0;
            z-index: 2;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            padding: 20px 22px;
            border-bottom: 1px solid var(--border);
            background: rgba(255, 255, 255, 0.96);
            backdrop-filter: blur(8px);
        }
        .modal-header h3,
        .modal-header p {
            margin: 0;
        }
        .modal-header h3 {
            color: var(--navy);
            font-size: 20px;
        }
        .modal-header p {
            margin-top: 3px;
            color: var(--muted);
            font-size: 11px;
        }
        .modal-body {
            padding: 21px 22px 24px;
        }
        .close {
            display: grid;
            flex: 0 0 auto;
            width: 36px;
            height: 36px;
            padding: 0;
            place-items: center;
            border: 1px solid #dce5ef;
            border-radius: 10px;
            color: #486581;
            background: #f7f9fc;
            font-size: 24px;
            line-height: 1;
            cursor: pointer;
        }
        .close:hover {
            color: var(--danger);
            background: #fff0f2;
        }
        label {
            display: block;
            margin: 0 0 6px;
            color: #334e68;
            font-size: 11px;
            font-weight: 750;
        }
        .modal-form-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 15px;
        }
        .form-span-full,
        .config-section,
        .config-helper {
            grid-column: 1 / -1;
        }
        .config-section {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            margin-top: 5px;
            padding-top: 16px;
            border-top: 1px solid var(--border);
        }
        .config-section strong {
            color: var(--navy);
            font-size: 13px;
        }
        .config-section a {
            color: var(--primary);
            font-size: 11px;
            font-weight: 750;
            text-decoration: none;
        }
        .config-section a:hover {
            text-decoration: underline;
        }
        .config-helper {
            margin: -7px 0 0;
            color: var(--muted);
            font-size: 11px;
        }
        .config-helper.required {
            color: #775a14;
        }
        .priority-matrix-guide {
            display: grid;
            gap: 12px;
            margin-top: 5px;
            padding: 15px;
            border: 1px solid color-mix(in srgb, var(--primary) 38%, var(--border));
            border-left: 5px solid var(--primary);
            border-radius: 12px;
            color: var(--text);
            background: color-mix(in srgb, var(--primary) 6%, var(--surface));
        }
        .priority-guide-heading {
            display: grid;
            grid-template-columns: minmax(220px, .75fr) minmax(280px, 1.25fr);
            align-items: center;
            gap: 16px;
        }
        .priority-guide-heading strong,
        .priority-guide-heading span {
            display: block;
        }
        .priority-guide-heading strong {
            margin-top: 2px;
            color: var(--navy);
            font-size: 14px;
        }
        .priority-guide-kicker {
            color: var(--primary);
            font-size: 9px;
            font-weight: 850;
            letter-spacing: .08em;
            text-transform: uppercase;
        }
        .priority-guide-heading p {
            margin: 0;
            color: var(--muted);
            font-size: 11px;
        }
        .priority-guide-scales {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 8px;
        }
        .priority-guide-scales > div {
            padding: 10px;
            border: 1px solid var(--border);
            border-radius: 9px;
            background: var(--surface);
        }
        .priority-guide-scales span {
            display: block;
            margin-bottom: 6px;
            color: var(--navy);
            font-size: 10px;
            font-weight: 850;
            text-transform: uppercase;
        }
        .priority-guide-scales ol {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin: 0;
            padding: 0;
            list-style: none;
        }
        .priority-guide-scales li {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            color: var(--muted);
            font-size: 10px;
        }
        .priority-guide-scales li b {
            display: grid;
            width: 21px;
            height: 21px;
            place-items: center;
            border-radius: 6px;
            color: #fff;
            background: var(--primary);
        }
        .priority-guide-formula {
            display: grid;
            align-content: center;
        }
        .priority-guide-formula strong {
            color: var(--text);
            font-size: 13px;
        }
        .priority-guide-formula small {
            color: var(--muted);
            font-size: 10px;
        }
        .priority-guide-results {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: 6px;
        }
        .priority-result {
            display: flex;
            align-items: center;
            gap: 6px;
            min-height: 34px;
            padding: 6px 8px;
            border: 1px solid color-mix(in srgb, var(--risk-color) 42%, var(--border));
            border-radius: 8px;
            color: var(--text);
            background: color-mix(in srgb, var(--risk-color) 10%, var(--surface));
            font-size: 9px;
            font-weight: 750;
        }
        .priority-result b {
            display: grid;
            width: 21px;
            height: 21px;
            flex: 0 0 auto;
            place-items: center;
            border-radius: 6px;
            color: #fff;
            background: var(--risk-color);
        }
        .priority-result.p1 { --risk-color: #16a34a; }
        .priority-result.p2 { --risk-color: #65a30d; }
        .priority-result.p3 { --risk-color: #ca8a04; }
        .priority-result.p4 { --risk-color: #ea580c; }
        .priority-result.p5 { --risk-color: #dc2626; }
        .priority-preview {
            display: grid;
            align-content: center;
            gap: 3px;
            min-height: 78px;
            padding: 12px 14px;
            border: 1px solid color-mix(in srgb, var(--priority-color, var(--primary)) 45%, var(--border));
            border-left: 5px solid var(--priority-color, var(--primary));
            border-radius: 10px;
            background: color-mix(in srgb, var(--priority-color, var(--primary)) 8%, var(--surface));
        }
        .priority-preview span,
        .priority-preview small {
            color: var(--muted);
            font-size: 10px;
        }
        .priority-preview strong {
            color: var(--text);
            font-size: 14px;
        }
        @media (max-width: 760px) {
            .priority-guide-heading,
            .priority-guide-scales {
                grid-template-columns: 1fr;
            }
            .priority-guide-results {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }
        .config-service-form select:disabled {
            color: var(--muted);
            background: color-mix(in srgb, var(--surface) 78%, var(--border));
            cursor: not-allowed;
            opacity: .72;
        }
        input, textarea, select {
            width: 100%;
            margin: 0;
            padding: 10px 11px;
            border: 1px solid #cfdbe8;
            border-radius: 9px;
            color: var(--text);
            outline: none;
            background: #fff;
            font-size: 12px;
            transition:
                border-color 0.18s ease,
                box-shadow 0.18s ease;
        }
        input:focus,
        textarea:focus,
        select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(31, 95, 153, 0.13);
        }
        textarea { min-height: 90px; resize: vertical; }
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 9px;
            margin-top: 19px;
            padding-top: 17px;
            border-top: 1px solid var(--border);
        }
        .btn-guardar {
            min-height: 39px;
            padding: 9px 15px;
            border: 1px solid var(--primary);
            border-radius: 9px;
            color: #fff;
            background: var(--primary);
            box-shadow: 0 7px 16px rgba(31, 95, 153, 0.22);
            font-size: 12px;
            font-weight: 750;
            cursor: pointer;
        }
        .alerta {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 47px;
            padding: 11px 15px;
            margin: 0 0 18px;
            border: 1px solid transparent;
            border-radius: 11px;
            font-size: 12px;
            font-weight: 700;
            text-align: center;
        }
        .alerta.exito {
            border-color: #bde7cc;
            color: #17673a;
            background: #eaf8ef;
        }
        .alerta.aviso {
            border-color: #f1dda5;
            color: #7c5a06;
            background: #fff8df;
        }
        .alerta.error {
            border-color: #f1c3c8;
            color: #922b36;
            background: #fdecee;
        }
        td .alerta {
            display: inline-flex;
            min-height: 0;
            margin: 0;
            padding: 5px 8px;
            font-size: 10px;
        }
        .sin-registros {
            margin: 0;
            padding: 22px;
            border: 1px dashed #cbd8e5;
            border-radius: 13px;
            color: var(--muted);
            background: rgba(255, 255, 255, 0.72);
            font-size: 13px;
            text-align: center;
        }
        @media (max-width: 850px) {
            .topbar {
                align-items: flex-start;
                flex-direction: column;
            }
            .barra-acciones {
                justify-content: flex-start;
                width: 100%;
            }
            .hero {
                min-height: 58px;
                padding: 9px 14px;
            }
            .catalogos {
                grid-template-columns: repeat(3, minmax(145px, 1fr));
            }
            .servicios-toolbar {
                align-items: flex-start;
                flex-direction: column;
            }
            .service-name-filter {
                grid-template-columns: 1fr;
            }
            .service-filter-actions {
                justify-content: space-between;
            }
            .service-name-filter-result {
                padding-bottom: 0;
            }
            .tabla-contenedor {
                overflow-x: auto;
            }
            table {
                min-width: 1320px;
            }
            .form-edicion { grid-template-columns: 1fr; }
            .form-edicion .acciones-edicion { grid-column: auto; }
        }
        @media (max-width: 560px) {
            .page-shell {
                width: calc(100% - 16px);
                padding-top: 12px;
            }
            .brand-subtitle {
                display: none;
            }
            .barra-acciones a {
                flex: 1 1 130px;
            }
            .catalogos {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
            .modal-form-grid {
                grid-template-columns: 1fr;
            }
            .form-span-full,
            .config-section,
            .config-helper {
                grid-column: auto;
            }
            .catalogo {
                min-height: 116px;
            }
            .section-heading {
                align-items: flex-start;
                flex-direction: column;
            }
            .seleccion-chip {
                display: none;
            }
            .modal {
                padding: 12px;
            }
            .modal-content {
                max-height: calc(100vh - 24px);
            }
        }
        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                transition-duration: 0.01ms !important;
            }
        }
        .area-loading-overlay {
            position: fixed;
            z-index: 99999;
            inset: 0;
            display: grid;
            place-items: center;
            padding: 20px;
            background: rgba(8, 18, 29, .72);
            backdrop-filter: blur(4px);
        }
        .area-loading-overlay[hidden] { display: none; }
        .area-loading-card {
            min-width: min(360px, calc(100vw - 32px));
            padding: 22px 24px;
            border: 1px solid var(--border);
            border-radius: 15px;
            color: var(--text);
            background: var(--surface);
            box-shadow: 0 24px 70px rgba(0, 0, 0, .28);
            text-align: center;
        }
        .area-loading-spinner {
            width: 38px;
            height: 38px;
            margin: 0 auto 12px;
            border: 4px solid color-mix(in srgb, var(--primary) 20%, var(--border));
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: area-loading-spin .7s linear infinite;
        }
        .area-loading-card strong { display: block; font-size: 16px; }
        .area-loading-card span { display: block; margin-top: 4px; color: var(--muted); font-size: 12px; }
        @keyframes area-loading-spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div id="areaLoadingOverlay" class="area-loading-overlay" role="status" aria-live="polite" hidden>
        <div class="area-loading-card">
            <div class="area-loading-spinner" aria-hidden="true"></div>
            <strong>Cargando servicios…</strong>
            <span id="areaLoadingText">Consultando el área seleccionada.</span>
        </div>
    </div>
    <main class="page-shell">
        <header class="topbar">
            <div class="brand">
                <div class="brand-mark" aria-hidden="true">MS</div>
                <div>
                    <p class="brand-name">Mesa de Servicio</p>
                    <p class="brand-subtitle">Administración de servicios</p>
                </div>
            </div>

            <nav class="barra-acciones" aria-label="Acciones de administración">
                <a href="panelAdmin.php" class="btn-volver">← Volver al panel</a>
                <a href="catalogos.php" class="open-btn">Ver áreas</a>
                <a href="sla.php" class="open-btn">Administrar SLA</a>
            </nav>
        </header>

        <?php if (isset($mensajes[$mensajeActual])): ?>
            <div class="alerta <?php echo escapar($mensajes[$mensajeActual][0]); ?>">
                <?php echo escapar($mensajes[$mensajeActual][1]); ?>
            </div>
        <?php endif; ?>

        <section class="hero">
            <div class="hero-copy">
                <span class="eyebrow">Administración</span>
                <h1>Servicios</h1>
                <p>
                    Seleccione un área y gestione sus servicios, parámetros,
                    estados y tiempos de respuesta.
                </p>
            </div>
        </section>

        <section class="content-section" aria-labelledby="titulo-catalogos">
            <div class="section-heading">
                <div>
                    <h2 id="titulo-catalogos">Seleccione un área</h2>
                    <p class="ayuda-orden">
                        Las áreas funcionan únicamente como selector de servicios.
                    </p>
                </div>
                <span class="seleccion-chip">Selector de área</span>
            </div>

            <div
                id="listaCatalogos"
                class="catalogos"
            >
        <?php while ($cat = $catalogos->fetch_assoc()): ?>
            <a
                href="servicios.php?id_catalogo=<?php echo (int) $cat['id_catalogo']; ?>#servicios-area"
                class="catalogo <?php echo $idCatalogoSeleccionado === (int) $cat['id_catalogo'] ? 'seleccionado' : ''; ?>"
                title="<?php echo escapar($cat['descripcion']); ?>"
                data-area-name="<?php echo escapar($cat['nombre']); ?>"
            >
                <span><?php echo escapar($cat['nombre']); ?></span>
                <img
                    src="<?php echo escapar(seguridadUrlImagenCatalogo(
                        (int) $cat['id_catalogo'],
                        $cat['imagen']
                    )); ?>"
                    alt="Imagen del área <?php echo escapar($cat['nombre']); ?>"
                >
            </a>
        <?php endwhile; ?>
            </div>
        </section>

        <div class="tabla-scroll-superior" id="tablaServiciosScrollSuperior" aria-label="Desplazamiento horizontal de servicios" tabindex="0"><div></div></div>
        <div id="serviciosAreaContainer">
        <?php if ($idCatalogoSeleccionado && !$catalogoSeleccionado): ?>
            <div class="alerta error">El área seleccionada no existe o está inhabilitada.</div>
        <?php endif; ?>

        <?php if ($catalogoSeleccionado): ?>
            <section id="servicios-area" class="servicios-panel" aria-labelledby="titulo-servicios">
                <div class="servicios-toolbar">
                    <div>
                        <h2 id="titulo-servicios">
                            Servicios de <?php echo escapar($catalogoSeleccionado['nombre']); ?>
                        </h2>
                        <p>Consulte y administre los servicios asociados a esta clase.</p>
                    </div>

                    <?php if ($slasActivos && $gestoresActivos && $configuracionesObligatoriasDisponibles): ?>
                        <button
                            type="button"
                            class="open-btn btn-nuevo"
                            onclick="abrirModal('modalServicio')"
                        >
                            Añadir servicio
                        </button>
                    <?php endif; ?>
                </div>

                <?php if (!$slasActivos): ?>
                    <div class="alerta aviso">
                        Debe crear o habilitar al menos un SLA antes de añadir servicios.
                        <a href="sla.php">Administrar SLA</a>
                    </div>
                <?php endif; ?>

                <?php if (!$gestoresActivos): ?>
                    <div class="alerta aviso">
                        Debe crear o habilitar al menos un gestor antes de añadir servicios.
                        <a href="crearUsuarios.php">Administrar usuarios</a>
                    </div>
                <?php endif; ?>

                <?php if (!$moduloOpcionesInstalado): ?>
                    <div class="alerta aviso">
                        Ejecute <strong>crear_modulo_configuraciones.sql</strong>
                        antes de añadir o editar servicios.
                    </div>
                <?php elseif (!$configuracionesObligatoriasDisponibles): ?>
                    <div class="alerta aviso">
                        Cree o habilite al menos una clasificación y un nivel de
                        atención antes de añadir servicios. La urgencia, el impacto
                        y la prioridad se controlan directamente con la matriz numérica.
                        <a href="panelAdmin.php">Ir a los módulos</a>
                    </div>
                <?php endif; ?>

                <div id="modalServicio" class="modal">
                    <div class="modal-content" role="dialog" aria-modal="true" aria-labelledby="titulo-modal-servicio">
                        <div class="modal-header">
                            <div>
                                <h3 id="titulo-modal-servicio">Añadir servicio</h3>
                                <p>Complete la información y asigne su gestor responsable y SLA.</p>
                            </div>
                            <button
                                type="button"
                                class="close"
                                aria-label="Cerrar"
                                onclick="cerrarModal('modalServicio')"
                            >&times;</button>
                        </div>

                        <div class="modal-body">
                            <form
                                method="POST"
                                action="servicios.php"
                                class="config-service-form"
                            >
                                <input type="hidden" name="csrf_token" value="<?php echo escapar($_SESSION['csrf_token']); ?>">
                                <input type="hidden" name="nuevo_servicio" value="1">
                                <input
                                    type="hidden"
                                    name="id_catalogo"
                                    value="<?php echo (int) $idCatalogoSeleccionado; ?>"
                                >

                                <div class="modal-form-grid">
                                    <div>
                                        <label for="nombre-servicio">Nombre</label>
                                        <input id="nombre-servicio" type="text" name="nombre" maxlength="150" required>
                                    </div>

                                    <div class="form-span-full">
                                        <label for="descripcion-servicio">Descripción</label>
                                        <textarea id="descripcion-servicio" name="descripcion" maxlength="2000" required></textarea>
                                    </div>

                                    <div>
                                        <label for="tipo-solicitud-servicio">Clasificación del servicio</label>
                                        <select id="tipo-solicitud-servicio" name="tipo_solicitud" required>
                                            <option value="">Seleccione una clasificación</option>
                                            <?php foreach ($clasificacionesServicioActivas as $clasificacion): ?>
                                                <option value="<?php echo escapar($clasificacion['nombre']); ?>">
                                                    <?php echo escapar($clasificacion['nombre']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <div>
                                        <label for="sla-servicio">SLA de respuesta</label>
                                        <select id="sla-servicio" name="id_sla" required>
                                            <option value="">Seleccione un SLA</option>
                                            <?php foreach ($slasActivos as $slaActivo): ?>
                                                <option value="<?php echo (int) $slaActivo['id_sla']; ?>">
                                                    <?php
                                                    echo escapar(
                                                        $slaActivo['nombre']
                                                        . ' - '
                                                        . $slaActivo['tiempo_respuesta']
                                                        . ' '
                                                        . ($unidadesSla[$slaActivo['unidad']]
                                                            ?? $slaActivo['unidad'])
                                                    );
                                                    ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <div>
    <label for="proceso-servicio">Proceso</label>
    <select id="proceso-servicio" name="proceso" required>
        <option value="">Seleccione un proceso</option>
        <?php foreach ($procesosActivos as $procesoActivo): ?>
            <option value="<?php echo escapar($procesoActivo['proceso']); ?>">
                <?php echo escapar($procesoActivo['proceso']); ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

<div>
    <label for="gestor-servicio">Gestor responsable</label>
    <select id="gestor-servicio" name="id_gestor" required disabled>
        <option value="">Primero seleccione un proceso</option>
        <?php foreach ($gestoresActivos as $gestorActivo): ?>
            <option value="<?php echo (int) $gestorActivo['id_usuario']; ?>" data-proceso="<?php echo escapar($gestorActivo['proceso']); ?>">
                <?php echo escapar($gestorActivo['nombre'] . ' · ' . $gestorActivo['email']); ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

                                    <?php mostrarGuiaMatrizPrioridad(); ?>

                                    <div>
                                        <label for="urgencia-valor-servicio">Urgencia (número del 1 al 3)</label>
                                        <select id="urgencia-valor-servicio" name="urgencia_valor" data-matriz-urgencia required>
                                            <option value="">Seleccione un número</option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="impacto-valor-servicio">Impacto (número del 1 al 3)</label>
                                        <select id="impacto-valor-servicio" name="impacto_valor" data-matriz-impacto required>
                                            <option value="">Seleccione un número</option>
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="id_nivel-servicio">Nivel de atención</label>
                                        <select id="id_nivel-servicio" name="id_nivel" required>
                                            <option value="">Seleccione una opción</option>
                                            <?php foreach ($opcionesConfiguracionActivas['nivel'] as $opcionConfiguracion): ?>
                                                <option value="<?php echo (int) $opcionConfiguracion['id_opcion']; ?>">
                                                    <?php echo escapar($opcionConfiguracion['nombre']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="priority-preview" data-matriz-resultado aria-live="polite">
                                        <span>Prioridad calculada</span>
                                        <strong>Seleccione urgencia e impacto</strong>
                                        <small>El sistema aplicará automáticamente la matriz corporativa.</small>
                                    </div>
                                </div>

                                <div class="modal-actions">
                                    <button type="submit" class="btn-guardar">Guardar servicio</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

        <?php if ($servicios && $servicios->num_rows > 0): ?>
            <div class="service-name-filter" role="search" aria-label="Filtrar servicios">
                <div>
                    <label for="filtroNombreServicio">Buscar servicio por nombre</label>
                    <div class="service-name-filter-control">
                        <input
                            id="filtroNombreServicio"
                            type="search"
                            placeholder="Escriba el nombre del servicio"
                            autocomplete="off"
                            aria-controls="tablaServicios"
                        >
                        <button
                            id="limpiarFiltroServicio"
                            class="service-name-filter-clear"
                            type="button"
                            aria-label="Limpiar búsqueda de servicios"
                            title="Limpiar búsqueda"
                            hidden
                        >×</button>
                    </div>
                </div>
                <div>
                    <label for="filtroClasificacionServicio">Clasificación</label>
                    <select id="filtroClasificacionServicio" aria-controls="tablaServicios">
                        <option value="">Todas</option>
                        <?php foreach ($filtrosClasificacionServicio as $clasificacionFiltro): ?>
                            <option value="<?php echo escapar($clasificacionFiltro); ?>">
                                <?php echo escapar($clasificacionFiltro); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="filtroProcesoServicio">Proceso</label>
                    <select id="filtroProcesoServicio" aria-controls="tablaServicios">
                        <option value="">Todos</option>
                        <?php foreach ($filtrosProcesoServicio as $procesoFiltro): ?>
                            <option value="<?php echo escapar($procesoFiltro); ?>">
                                <?php echo escapar($procesoFiltro); ?>
                            </option>
                        <?php endforeach; ?>
                        <option value="__sin_valor__">Sin proceso</option>
                    </select>
                </div>
                <div>
                    <label for="filtroGestorServicio">Gestor responsable</label>
                    <select id="filtroGestorServicio" aria-controls="tablaServicios">
                        <option value="">Todos</option>
                        <?php foreach ($filtrosGestorServicio as $gestorFiltro): ?>
                            <option value="<?php echo escapar($gestorFiltro); ?>">
                                <?php echo escapar($gestorFiltro); ?>
                            </option>
                        <?php endforeach; ?>
                        <option value="__sin_valor__">Sin gestor</option>
                    </select>
                </div>
                <div>
                    <label for="filtroEstadoServicio">Estado</label>
                    <select id="filtroEstadoServicio" aria-controls="tablaServicios">
                        <option value="">Todos</option>
                        <?php foreach ($filtrosEstadoServicio as $estadoFiltro): ?>
                            <option value="<?php echo escapar($estadoFiltro); ?>">
                                <?php echo escapar(ucfirst($estadoFiltro)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="service-filter-actions">
                    <button id="limpiarFiltrosServicio" class="service-filter-reset" type="button" hidden>
                        Limpiar filtros
                    </button>
                    <span id="resultadoFiltroServicio" class="service-name-filter-result" aria-live="polite">
                        <?php echo (int) $servicios->num_rows; ?> disponibles
                    </span>
                </div>
            </div>
            <div class="tabla-contenedor" id="tablaServiciosContenedor">
                <table id="tablaServicios">
                    <thead>
    <tr>
        <th>Nombre</th>
        <th>Descripción</th>
        <th>Clasificación</th>
        <th>Proceso</th>
        <th>Gestor responsable</th>
        <th>SLA</th>
        <th>Urgencia</th>
        <th>Impacto</th>
        <th>Prioridad</th>
        <th>Estado</th>
        <th>Acciones</th>
    </tr>
</thead>
                    <tbody>
                        <?php while ($srv = $servicios->fetch_assoc()): ?>
                            <tr
                                class="fila-servicio"
                                data-service-id="<?php echo (int) $srv['id_servicio']; ?>"
                                data-filter-name="<?php echo escapar($srv['nombre']); ?>"
                                data-filter-classification="<?php echo escapar((string) ($srv['tipo_solicitud'] ?? '')); ?>"
                                data-filter-process="<?php echo escapar((string) ($srv['proceso'] ?? '')); ?>"
                                data-filter-manager="<?php echo escapar((string) ($srv['gestor_nombre'] ?? '')); ?>"
                                data-filter-status="<?php echo escapar((string) ($srv['estado'] ?? '')); ?>"
                            >
                                <td class="service-name-cell"><?php echo escapar($srv['nombre']); ?></td>
                                <td class="service-description-cell">
                                    <div
                                        id="descripcion-resumen-<?php echo (int) $srv['id_servicio']; ?>"
                                        class="service-description-text"
                                    ><?php echo escapar($srv['descripcion']); ?></div>
                                    <button
                                        type="button"
                                        class="service-description-toggle"
                                        aria-expanded="false"
                                        aria-controls="descripcion-resumen-<?php echo (int) $srv['id_servicio']; ?>"
                                        onclick="alternarDescripcionServicio(this)"
                                        hidden
                                    >Ver más</button>
                                </td>
                                <td>
                                    <?php $tipoSolicitudServicio = (string) ($srv['tipo_solicitud'] ?? 'requerimiento'); ?>
                                    <span class="service-classification">
                                        <?php echo escapar(ucfirst($tipoSolicitudServicio)); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $procesoServicio = trim((string) ($srv['proceso'] ?? ''));
                                    echo escapar($procesoServicio !== '' ? $procesoServicio : 'Sin proceso');
                                    ?>
                                </td>
                                <td>
    <?php if ($srv['gestor_nombre']): ?>
        <span class="sla-info">
            <strong><?php echo escapar($srv['gestor_nombre']); ?></strong>
            <?php if ($srv['gestor_estado'] !== 'activo'): ?>
                <small>Gestor inhabilitado</small>
            <?php endif; ?>
        </span>
    <?php else: ?>
        <span class="alerta error">Sin gestor</span>
    <?php endif; ?>
</td>
                                <td>
                                    <?php if ($srv['sla_nombre']): ?>
                                        <span class="sla-info">
                                            <strong><?php echo escapar($srv['sla_nombre']); ?></strong>
                                            <small>
                                                <?php
                                                echo (int) $srv['sla_tiempo'];
                                                echo ' ';
                                                echo escapar(
                                                    $unidadesSla[$srv['sla_unidad']]
                                                    ?? $srv['sla_unidad']
                                                );
                                                ?>
                                            </small>
                                        </span>
                                    <?php else: ?>
                                        <span class="alerta error">Sin SLA</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $urgenciaValorServicio = max(1, min(3, (int) ($srv['urgencia_valor'] ?? 2)));
                                    $impactoValorServicio = max(1, min(3, (int) ($srv['impacto_valor'] ?? 2)));
                                    $matrizServicio = matrizPrioridadCalcular(
                                        $urgenciaValorServicio,
                                        $impactoValorServicio
                                    );
                                    ?>
                                    <span class="attention-tag">U: <?= (int) $matrizServicio['urgencia_valor'] ?> · <?= escapar($matrizServicio['urgencia_nombre']) ?></span>
                                </td>
                                <td>
                                    <span class="attention-tag">I: <?= (int) $matrizServicio['impacto_valor'] ?> · <?= escapar($matrizServicio['impacto_nombre']) ?></span>
                                </td>
                                <td>
                                    <span class="attention-tag priority-score" style="--priority-color: <?= escapar(matrizPrioridadColor((int) $matrizServicio['prioridad_valor'])) ?>">
                                        P: <?= (int) $matrizServicio['prioridad_valor'] ?> · <?= escapar($matrizServicio['prioridad_nombre']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $estadoServicio = $srv['estado'] === 'inhabilitado'
                                        ? 'inhabilitado'
                                        : 'activo';
                                    ?>
                                    <span class="estado-servicio <?php echo escapar($estadoServicio); ?>">
                                        <?php echo escapar(ucfirst($estadoServicio)); ?>
                                    </span>
                                </td>
                                <td class="celda-acciones">
                                    <details class="acciones-menu">
                                        <summary>Acciones</summary>
                                        <div class="acciones-desplegable">
                                        <button
                                            type="button"
                                            class="accion-item accion-editar"
                                            onclick="mostrarEdicionServicio(<?php echo (int) $srv['id_servicio']; ?>)"
                                        >Editar</button>

                                        <form method="POST" action="servicios.php">
                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?php echo escapar($_SESSION['csrf_token']); ?>"
                                            >
                                            <input
                                                type="hidden"
                                                name="id_catalogo"
                                                value="<?php echo (int) $idCatalogoSeleccionado; ?>"
                                            >
                                            <input
                                                type="hidden"
                                                name="id_servicio"
                                                value="<?php echo (int) $srv['id_servicio']; ?>"
                                            >
                                            <input type="hidden" name="cambiar_estado_servicio" value="1">

                                            <?php if ($srv['estado'] === 'activo'): ?>
                                                <input type="hidden" name="nuevo_estado" value="inhabilitado">
                                                <button type="submit" class="accion-item accion-estado">
                                                    Inhabilitar
                                                </button>
                                            <?php else: ?>
                                                <input type="hidden" name="nuevo_estado" value="activo">
                                                <button type="submit" class="accion-item accion-habilitar">
                                                    Habilitar
                                                </button>
                                            <?php endif; ?>
                                        </form>

                                        </div>
                                    </details>
                                </td>
                            </tr>

                            <tr
                                id="edicion-servicio-<?php echo (int) $srv['id_servicio']; ?>"
                                class="fila-edicion"
                                data-service-edit-id="<?php echo (int) $srv['id_servicio']; ?>"
                            >
                                <td colspan="11">
                                    <form
                                        method="POST"
                                        action="servicios.php"
                                        class="config-service-form"
                                    >
                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?php echo escapar($_SESSION['csrf_token']); ?>"
                                        >
                                        <input type="hidden" name="editar_servicio" value="1">
                                        <input
                                            type="hidden"
                                            name="id_catalogo"
                                            value="<?php echo (int) $idCatalogoSeleccionado; ?>"
                                        >
                                        <input
                                            type="hidden"
                                            name="id_servicio"
                                            value="<?php echo (int) $srv['id_servicio']; ?>"
                                        >

                                        <div class="form-edicion">
                                            <div>
                                                <label for="nombre-servicio-<?php echo (int) $srv['id_servicio']; ?>">
                                                    Nombre
                                                </label>
                                                <input
                                                    id="nombre-servicio-<?php echo (int) $srv['id_servicio']; ?>"
                                                    type="text"
                                                    name="nombre"
                                                    maxlength="150"
                                                    value="<?php echo escapar($srv['nombre']); ?>"
                                                    required
                                                >
                                            </div>

                                            <div>
                                                <label for="descripcion-servicio-<?php echo (int) $srv['id_servicio']; ?>">
                                                    Descripción
                                                </label>
                                                <textarea
                                                    id="descripcion-servicio-<?php echo (int) $srv['id_servicio']; ?>"
                                                    class="service-description-editor"
                                                    name="descripcion"
                                                    maxlength="2000"
                                                    required
                                                ><?php echo escapar($srv['descripcion']); ?></textarea>
                                            </div>

                                            <div>
                                                <label for="tipo-solicitud-<?php echo (int) $srv['id_servicio']; ?>">
                                                    Clasificación del servicio
                                                </label>
                                                <select
                                                    id="tipo-solicitud-<?php echo (int) $srv['id_servicio']; ?>"
                                                    name="tipo_solicitud"
                                                    required
                                                >
                                                    <?php
                                                    $clasificacionActualServicio = (string) ($srv['tipo_solicitud'] ?? '');
                                                    $clasificacionActualDisponible = false;
                                                    foreach ($clasificacionesServicioActivas as $clasificacion) {
                                                        $nombreClasificacion = (string) $clasificacion['nombre'];
                                                        $seleccionada = strcasecmp($nombreClasificacion, $clasificacionActualServicio) === 0;
                                                        $clasificacionActualDisponible = $clasificacionActualDisponible || $seleccionada;
                                                        ?>
                                                        <option value="<?php echo escapar($nombreClasificacion); ?>" <?php echo $seleccionada ? 'selected' : ''; ?>>
                                                            <?php echo escapar($nombreClasificacion); ?>
                                                        </option>
                                                    <?php } ?>
                                                    <?php if (!$clasificacionActualDisponible && $clasificacionActualServicio !== ''): ?>
                                                        <option value="<?php echo escapar($clasificacionActualServicio); ?>" selected>
                                                            <?php echo escapar($clasificacionActualServicio); ?> (inhabilitada)
                                                        </option>
                                                    <?php endif; ?>
                                                </select>
                                            </div>

                                            <div>
                                                <label for="sla-servicio-<?php echo (int) $srv['id_servicio']; ?>">
                                                    SLA de respuesta
                                                </label>
                                                <select
                                                    id="sla-servicio-<?php echo (int) $srv['id_servicio']; ?>"
                                                    name="id_sla"
                                                    required
                                                >
                                                    <?php if ($srv['sla_estado'] !== 'activo'): ?>
                                                        <option value="" selected>
                                                            <?php
                                                            echo escapar(
                                                                ($srv['sla_nombre'] ?: 'SLA no disponible')
                                                                . ' - seleccione otro SLA'
                                                            );
                                                            ?>
                                                        </option>
                                                    <?php else: ?>
                                                        <option value="">Seleccione un SLA</option>
                                                    <?php endif; ?>

                                                    <?php foreach ($slasActivos as $slaActivo): ?>
                                                        <option
                                                            value="<?php echo (int) $slaActivo['id_sla']; ?>"
                                                            <?php
                                                            echo (int) $srv['id_sla']
                                                                === (int) $slaActivo['id_sla']
                                                                    ? 'selected'
                                                                    : '';
                                                            ?>
                                                        >
                                                            <?php
                                                            echo escapar(
                                                                $slaActivo['nombre']
                                                                . ' - '
                                                                . $slaActivo['tiempo_respuesta']
                                                                . ' '
                                                                . ($unidadesSla[$slaActivo['unidad']]
                                                                    ?? $slaActivo['unidad'])
                                                            );
                                                            ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>

                                            <!-- SELECCIONAR PROCESO EN EDICIÓN -->
<!-- SELECCIONAR PROCESO EN EDICIÓN -->
<div>
    <label for="proceso-<?php echo (int) $srv['id_servicio']; ?>">Proceso</label>
    <select id="proceso-<?php echo (int) $srv['id_servicio']; ?>" name="proceso" required>
        <option value="">Seleccione un proceso</option>
        <?php foreach ($procesosActivos as $procesoActivo): ?>
            <?php $procesoSeleccionado = (string) ($srv['proceso'] ?? '') === (string) $procesoActivo['proceso']; ?>
            <option value="<?php echo escapar($procesoActivo['proceso']); ?>" <?php echo $procesoSeleccionado ? 'selected' : ''; ?>>
                <?php echo escapar($procesoActivo['proceso']); ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

<!-- SELECCIONAR GESTOR EN EDICIÓN -->
<div>
    <label for="gestor-<?php echo (int) $srv['id_servicio']; ?>">Gestor responsable</label>
    <select
        id="gestor-<?php echo (int) $srv['id_servicio']; ?>"
        name="id_gestor"
        required
        <?php echo trim((string) ($srv['proceso'] ?? '')) === '' ? 'disabled' : ''; ?>
    >
        <option value="">Seleccione un gestor</option>
        <?php foreach ($gestoresActivos as $gestorActivo): ?>
            <?php 
                $gestorSeleccionado = (int) $srv['id_gestor'] === (int) $gestorActivo['id_usuario'];
                // Aquí es clave: data-proceso debe tener el NOMBRE del proceso del gestor
            ?>
            <option 
                value="<?php echo (int) $gestorActivo['id_usuario']; ?>" 
                data-proceso="<?php echo escapar($gestorActivo['proceso']); ?>" 
                <?php echo $gestorSeleccionado ? 'selected' : ''; ?>
            >
                <?php echo escapar($gestorActivo['nombre'] . ' · ' . $gestorActivo['email']); ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

                                            <?php mostrarGuiaMatrizPrioridad(); ?>

                                            <?php
                                                $urgenciaActual = (int) ($srv['urgencia_valor'] ?? 2);
                                                $impactoActual = (int) ($srv['impacto_valor'] ?? 2);
                                                $matrizActual = matrizPrioridadCalcular(
                                                    max(1, min(3, $urgenciaActual)),
                                                    max(1, min(3, $impactoActual))
                                                );
                                            ?>
                                            <div>
                                                <label for="urgencia-valor-<?php echo (int) $srv['id_servicio']; ?>">Urgencia (número del 1 al 3)</label>
                                                <select id="urgencia-valor-<?php echo (int) $srv['id_servicio']; ?>" name="urgencia_valor" data-matriz-urgencia required>
                                                    <option value="1" <?= $urgenciaActual === 1 ? 'selected' : '' ?>>1</option>
                                                    <option value="2" <?= $urgenciaActual === 2 ? 'selected' : '' ?>>2</option>
                                                    <option value="3" <?= $urgenciaActual === 3 ? 'selected' : '' ?>>3</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label for="impacto-valor-<?php echo (int) $srv['id_servicio']; ?>">Impacto (número del 1 al 3)</label>
                                                <select id="impacto-valor-<?php echo (int) $srv['id_servicio']; ?>" name="impacto_valor" data-matriz-impacto required>
                                                    <option value="1" <?= $impactoActual === 1 ? 'selected' : '' ?>>1</option>
                                                    <option value="2" <?= $impactoActual === 2 ? 'selected' : '' ?>>2</option>
                                                    <option value="3" <?= $impactoActual === 3 ? 'selected' : '' ?>>3</option>
                                                </select>
                                            </div>
                                            <div>
                                                <label for="id_nivel-<?php echo (int) $srv['id_servicio']; ?>">Nivel de atención</label>
                                                <select id="id_nivel-<?php echo (int) $srv['id_servicio']; ?>" name="id_nivel" required>
                                                    <option value="">Seleccione una opción</option>
                                                    <?php foreach ($opcionesConfiguracionTodas['nivel'] as $opcionConfiguracion): ?>
                                                        <?php $nivelSeleccionado = (int) ($srv['id_nivel'] ?? 0) === (int) $opcionConfiguracion['id_opcion']; ?>
                                                        <?php if ($opcionConfiguracion['estado_registro'] === 'activo' || $nivelSeleccionado): ?>
                                                            <option value="<?= (int) $opcionConfiguracion['id_opcion'] ?>" <?= $nivelSeleccionado ? 'selected' : '' ?>>
                                                                <?= escapar($opcionConfiguracion['nombre']) ?>
                                                            </option>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="priority-preview" data-matriz-resultado aria-live="polite">
                                                <span>Prioridad calculada</span>
                                                <strong><?= (int) $matrizActual['prioridad_valor'] ?> · <?= escapar($matrizActual['prioridad_nombre']) ?></strong>
                                                <small>Código <?= escapar($matrizActual['codigo']) ?> de la matriz corporativa.</small>
                                            </div>

                                            <div class="acciones-edicion">
                                                <button type="submit" class="btn btn-edit">
                                                    Guardar cambios
                                                </button>
                                                <button
                                                    type="button"
                                                    class="btn btn-cancel"
                                                    onclick="mostrarEdicionServicio(<?php echo (int) $srv['id_servicio']; ?>)"
                                                >Cancelar</button>
                                            </div>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        <tr id="sinResultadosServicio" class="service-filter-empty" hidden>
                            <td colspan="11">No se encontraron servicios con los filtros seleccionados.</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="sin-registros">Esta área todavía no tiene servicios registrados.</p>
        <?php endif; ?>
            </section>
        <?php endif; ?>
        </div>
    </main>

    <script>
        const areaLoadingOverlay = document.getElementById('areaLoadingOverlay');
        const areaLoadingText = document.getElementById('areaLoadingText');
        const respuestasAreas = new Map();

        function cargarRespuestaArea(destino) {
            const clave = destino.pathname + destino.search;
            if (!respuestasAreas.has(clave)) {
                const respuestaPendiente = fetch(clave, {
                    method: 'GET',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    headers: {'X-Requested-With': 'XMLHttpRequest'}
                }).then(function (respuesta) {
                    if (!respuesta.ok) {
                        throw new Error('No fue posible consultar los servicios.');
                    }
                    return respuesta.text();
                }).catch(function (error) {
                    respuestasAreas.delete(clave);
                    throw error;
                });
                respuestasAreas.set(clave, respuestaPendiente);
            }
            return respuestasAreas.get(clave);
        }

        function precargarArea(enlaceArea) {
            const destino = new URL(enlaceArea.dataset.mesaRoute || enlaceArea.href, window.location.href);
            const seleccionada = document.querySelector('.catalogo.seleccionado');
            if (seleccionada === enlaceArea) return;
            cargarRespuestaArea(destino).catch(function () {});
        }

        async function cargarAreaSinRecarga(destino, enlaceArea) {
            const nombreArea = String(enlaceArea.dataset.areaName || '').trim();
            enlaceArea.setAttribute('aria-busy', 'true');
            if (areaLoadingText) {
                areaLoadingText.textContent = nombreArea
                    ? 'Consultando los servicios de ' + nombreArea + '.'
                    : 'Consultando el área seleccionada.';
            }
            if (areaLoadingOverlay) {
                areaLoadingOverlay.hidden = false;
            }

            try {
                const documento = new DOMParser().parseFromString(
                    await cargarRespuestaArea(destino),
                    'text/html'
                );
                const contenidoNuevo = documento.getElementById('serviciosAreaContainer');
                const contenidoActual = document.getElementById('serviciosAreaContainer');
                if (!contenidoNuevo || !contenidoActual) {
                    throw new Error('La respuesta del servidor está incompleta.');
                }

                contenidoActual.replaceChildren(...Array.from(contenidoNuevo.childNodes).map(function (nodo) {
                    return document.importNode(nodo, true);
                }));

                document.querySelectorAll('.catalogo').forEach(function (catalogo) {
                    const urlCatalogo = new URL(catalogo.dataset.mesaRoute || catalogo.href, window.location.href);
                    catalogo.classList.toggle('seleccionado', urlCatalogo.search === destino.search);
                    catalogo.removeAttribute('aria-busy');
                });

                if (window.parent !== window) {
                    window.parent.postMessage({
                        tipo: 'mesa-historial',
                        url: destino.pathname + destino.search + '#servicios-area'
                    }, window.location.origin);
                } else {
                    window.history.pushState({areaServicios: true}, '', destino.pathname + destino.search + '#servicios-area');
                }
                actualizarReferenciasFiltroServicio();
                vincularFiltrosServicios();
                inicializarOpcionesDeServicio();
                inicializarEdicionServicioAjax();
                inicializarFiltroGestores();
                actualizarControlesDescripcion();

                document.querySelectorAll('.service-description-editor').forEach(function (textarea) {
                    textarea.addEventListener('input', function () {
                        ajustarEditorDescripcion(textarea);
                    });
                });

                const panelServicios = document.getElementById('servicios-area');
                if (panelServicios) {
                    panelServicios.scrollIntoView({behavior: 'smooth', block: 'start'});
                }
            } catch (error) {
                if (window.parent !== window) {
                    window.parent.postMessage({tipo: 'mesa-navegar', url: destino.href}, window.location.origin);
                } else {
                    window.location.assign(destino.href);
                }
                return;
            } finally {
                if (areaLoadingOverlay) {
                    areaLoadingOverlay.hidden = true;
                }
                enlaceArea.removeAttribute('aria-busy');
            }
        }

        document.querySelectorAll('.catalogo[href]').forEach(function (enlaceArea) {
            enlaceArea.addEventListener('pointerenter', function () {
                precargarArea(enlaceArea);
            }, {once: true});
            enlaceArea.addEventListener('focus', function () {
                precargarArea(enlaceArea);
            }, {once: true});
            enlaceArea.addEventListener('click', function (event) {
                if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) {
                    return;
                }

                const destino = new URL(enlaceArea.dataset.mesaRoute || enlaceArea.href, window.location.href);
                const areaSeleccionada = document.querySelector('.catalogo.seleccionado');
                const rutaAreaSeleccionada = areaSeleccionada
                    ? new URL(areaSeleccionada.dataset.mesaRoute || areaSeleccionada.href, window.location.href)
                    : null;
                const mismaArea = Boolean(rutaAreaSeleccionada)
                    && destino.pathname === rutaAreaSeleccionada.pathname
                    && destino.search === rutaAreaSeleccionada.search;

                if (mismaArea) {
                    event.preventDefault();
                    const panelServicios = document.getElementById('servicios-area');
                    if (areaLoadingOverlay) {
                        areaLoadingOverlay.hidden = true;
                    }
                    enlaceArea.removeAttribute('aria-busy');
                    if (panelServicios) {
                        panelServicios.scrollIntoView({behavior: 'smooth', block: 'start'});
                        if (window.parent !== window) {
                            window.parent.postMessage({
                                tipo: 'mesa-historial',
                                url: destino.pathname + destino.search + '#servicios-area',
                                replace: true
                            }, window.location.origin);
                        } else {
                            window.history.replaceState(null, '', destino.pathname + destino.search + '#servicios-area');
                        }
                    }
                    return;
                }

                event.preventDefault();
                cargarAreaSinRecarga(destino, enlaceArea);
            });
        });

        window.addEventListener('pageshow', function () {
            if (areaLoadingOverlay) {
                areaLoadingOverlay.hidden = true;
            }
            document.querySelectorAll('.catalogo[aria-busy="true"]').forEach(function (enlaceArea) {
                enlaceArea.removeAttribute('aria-busy');
            });
        });

        let filtroNombreServicio;
        let limpiarFiltroServicio;
        let filtroClasificacionServicio;
        let filtroProcesoServicio;
        let filtroGestorServicio;
        let filtroEstadoServicio;
        let limpiarFiltrosServicio;
        let resultadoFiltroServicio;
        let sinResultadosServicio;

        function actualizarReferenciasFiltroServicio() {
            filtroNombreServicio = document.getElementById('filtroNombreServicio');
            limpiarFiltroServicio = document.getElementById('limpiarFiltroServicio');
            filtroClasificacionServicio = document.getElementById('filtroClasificacionServicio');
            filtroProcesoServicio = document.getElementById('filtroProcesoServicio');
            filtroGestorServicio = document.getElementById('filtroGestorServicio');
            filtroEstadoServicio = document.getElementById('filtroEstadoServicio');
            limpiarFiltrosServicio = document.getElementById('limpiarFiltrosServicio');
            resultadoFiltroServicio = document.getElementById('resultadoFiltroServicio');
            sinResultadosServicio = document.getElementById('sinResultadosServicio');
        }

        function vincularScrollSuperiorServicios() {
            const scrollSuperior = document.getElementById('tablaServiciosScrollSuperior');
            const contenedorTabla = document.getElementById('tablaServiciosContenedor');
            const tabla = document.getElementById('tablaServicios');
            if (!scrollSuperior || !contenedorTabla || !tabla) {
                if (scrollSuperior) scrollSuperior.hidden = true;
                return;
            }

            const ajustarAncho = function () {
                scrollSuperior.firstElementChild.style.width = tabla.scrollWidth + 'px';
                scrollSuperior.hidden = false;
            };

            ajustarAncho();
            window.requestAnimationFrame(ajustarAncho);
            window.setTimeout(ajustarAncho, 80);
            if (scrollSuperior.dataset.scrollReady !== '1') {
                scrollSuperior.dataset.scrollReady = '1';
                scrollSuperior.addEventListener('scroll', function () {
                    const tablaActual = document.getElementById('tablaServiciosContenedor');
                    if (tablaActual) tablaActual.scrollLeft = scrollSuperior.scrollLeft;
                });
            }
            contenedorTabla.addEventListener('scroll', function () {
                if (scrollSuperior.scrollLeft !== contenedorTabla.scrollLeft) {
                    scrollSuperior.scrollLeft = contenedorTabla.scrollLeft;
                }
            });
            window.addEventListener('resize', ajustarAncho);
        }

        actualizarReferenciasFiltroServicio();
        vincularScrollSuperiorServicios();

        function normalizarTextoServicio(texto) {
            return String(texto || '')
                .normalize('NFD')
                .replace(/[\u0300-\u036f]/g, '')
                .toLocaleLowerCase('es')
                .trim();
        }

        function valorFiltroServicio(select) {
            if (!select) {
                return '';
            }

            return select.value === '__sin_valor__'
                ? '__sin_valor__'
                : normalizarTextoServicio(select.value);
        }

        const mensajesOperacionServicio = {
            servicio_actualizado: 'Servicio actualizado correctamente.',
            datos_incompletos: 'Complete todos los campos obligatorios.',
            configuracion_pendiente: 'Falta instalar la configuración requerida.',
            configuracion_no_disponible: 'Revise las opciones seleccionadas del servicio.',
            sla_no_disponible: 'Seleccione un SLA activo y disponible.',
            gestor_no_disponible: 'El gestor no está activo o no pertenece al proceso seleccionado.',
            solicitud_invalida: 'La solicitud no es válida. Inténtelo nuevamente.',
            error_servicio: 'No fue posible actualizar el servicio.'
        };

        let temporizadorFeedbackServicio = null;

        function mostrarFeedbackServicio(mensaje, tipo) {
            let aviso = document.getElementById('serviceAjaxFeedback');

            if (!aviso) {
                aviso = document.createElement('div');
                aviso.id = 'serviceAjaxFeedback';
                aviso.className = 'service-ajax-feedback';
                aviso.setAttribute('role', 'status');
                aviso.setAttribute('aria-live', 'polite');
                document.body.appendChild(aviso);
            }

            window.clearTimeout(temporizadorFeedbackServicio);
            aviso.textContent = mensaje;
            aviso.className = 'service-ajax-feedback ' + tipo;
            window.requestAnimationFrame(function () {
                aviso.classList.add('visible');
            });

            temporizadorFeedbackServicio = window.setTimeout(function () {
                aviso.classList.remove('visible');
            }, 3600);
        }

        function asegurarOpcionFiltroServicio(select, valor) {
            const texto = String(valor || '').trim();
            if (!select || texto === '') {
                return;
            }

            const existe = Array.from(select.options).some(function (opcion) {
                return normalizarTextoServicio(opcion.value) === normalizarTextoServicio(texto);
            });

            if (!existe) {
                const opcion = document.createElement('option');
                opcion.value = texto;
                opcion.textContent = texto;
                select.appendChild(opcion);
            }
        }

        function actualizarFilaServicioDesdeFormulario(formulario) {
            const datos = new FormData(formulario);
            const idServicio = datos.get('id_servicio');
            const fila = document.querySelector(
                '.fila-servicio[data-service-id="' + idServicio + '"]'
            );

            if (!fila) {
                return;
            }

            const celdas = fila.cells;
            const nombre = String(datos.get('nombre') || '').trim();
            const descripcion = String(datos.get('descripcion') || '').trim();
            const clasificacion = String(datos.get('tipo_solicitud') || '').trim();
            const proceso = String(datos.get('proceso') || '').trim();
            const selectGestor = formulario.querySelector('[name="id_gestor"]');
            const selectSla = formulario.querySelector('[name="id_sla"]');
            const gestorTextoCompleto = selectGestor && selectGestor.selectedOptions[0]
                ? selectGestor.selectedOptions[0].textContent.trim()
                : '';
            const gestorNombre = gestorTextoCompleto.split('·')[0].trim();
            const slaTexto = selectSla && selectSla.selectedOptions[0]
                ? selectSla.selectedOptions[0].textContent.trim()
                : '';
            const partesSla = slaTexto.split(' - ');
            const slaNombre = partesSla.shift() || '';
            const slaDetalle = partesSla.join(' - ');

            fila.dataset.filterName = nombre;
            fila.dataset.filterClassification = clasificacion;
            fila.dataset.filterProcess = proceso;
            fila.dataset.filterManager = gestorNombre;

            celdas[0].textContent = nombre;

            const resumenDescripcion = celdas[1].querySelector('.service-description-text');
            const botonDescripcion = celdas[1].querySelector('.service-description-toggle');
            if (resumenDescripcion) {
                resumenDescripcion.textContent = descripcion;
                resumenDescripcion.classList.remove('expanded');
            }
            if (botonDescripcion) {
                botonDescripcion.setAttribute('aria-expanded', 'false');
                botonDescripcion.textContent = 'Ver más';
            }

            const etiquetaClasificacion = celdas[2].querySelector('.service-classification');
            if (etiquetaClasificacion) {
                etiquetaClasificacion.textContent = clasificacion;
            }
            celdas[3].textContent = proceso || 'Sin proceso';

            celdas[4].replaceChildren();
            const gestorInfo = document.createElement('span');
            gestorInfo.className = 'sla-info';
            const gestorStrong = document.createElement('strong');
            gestorStrong.textContent = gestorNombre || 'Sin gestor';
            gestorInfo.appendChild(gestorStrong);
            celdas[4].appendChild(gestorInfo);

            celdas[5].replaceChildren();
            const slaInfo = document.createElement('span');
            slaInfo.className = 'sla-info';
            const slaStrong = document.createElement('strong');
            slaStrong.textContent = slaNombre;
            slaInfo.appendChild(slaStrong);
            if (slaDetalle !== '') {
                const slaSmall = document.createElement('small');
                slaSmall.textContent = slaDetalle;
                slaInfo.appendChild(slaSmall);
            }
            celdas[5].appendChild(slaInfo);

            const urgencia = Number(datos.get('urgencia_valor'));
            const impacto = Number(datos.get('impacto_valor'));
            const prioridad = urgencia + impacto - 1;
            const nombresUrgencia = {1: 'Más tarde', 2: 'Pronto', 3: 'Inmediato'};
            const nombresImpacto = {1: 'Bajo', 2: 'Moderado', 3: 'Urgente'};
            const nombresPrioridad = {
                1: 'Baja',
                2: 'Baja moderada',
                3: 'Moderada',
                4: 'Moderada urgente',
                5: 'Urgente'
            };
            const coloresPrioridad = {
                1: '#16a34a',
                2: '#65a30d',
                3: '#ca8a04',
                4: '#ea580c',
                5: '#dc2626'
            };
            const etiquetaUrgencia = celdas[6].querySelector('.attention-tag');
            const etiquetaImpacto = celdas[7].querySelector('.attention-tag');
            const etiquetaPrioridad = celdas[8].querySelector('.attention-tag');
            if (etiquetaUrgencia) {
                etiquetaUrgencia.textContent = 'U: ' + urgencia + ' · ' + nombresUrgencia[urgencia];
            }
            if (etiquetaImpacto) {
                etiquetaImpacto.textContent = 'I: ' + impacto + ' · ' + nombresImpacto[impacto];
            }
            if (etiquetaPrioridad) {
                etiquetaPrioridad.textContent = 'P: ' + prioridad + ' · ' + nombresPrioridad[prioridad];
                etiquetaPrioridad.style.setProperty('--priority-color', coloresPrioridad[prioridad]);
            }

            asegurarOpcionFiltroServicio(filtroClasificacionServicio, clasificacion);
            asegurarOpcionFiltroServicio(filtroProcesoServicio, proceso);
            asegurarOpcionFiltroServicio(filtroGestorServicio, gestorNombre);

            const filaEdicion = formulario.closest('.fila-edicion');
            if (filaEdicion) {
                filaEdicion.style.display = 'none';
            }

            actualizarControlesDescripcion();
            filtrarServicios();
        }

        function inicializarEdicionServicioAjax() {
            document.querySelectorAll('.config-service-form').forEach(function (formulario) {
                if (!formulario.querySelector('[name="editar_servicio"]') || formulario.dataset.ajaxReady === '1') {
                    return;
                }

                formulario.dataset.ajaxReady = '1';
                formulario.addEventListener('submit', async function (event) {
                    event.preventDefault();

                    if (formulario.dataset.sending === '1') {
                        return;
                    }

                    if (!formulario.reportValidity()) {
                        return;
                    }

                    const botonGuardar = formulario.querySelector('button[type="submit"]');
                    const textoBoton = botonGuardar ? botonGuardar.textContent : '';
                    formulario.dataset.sending = '1';
                    formulario.setAttribute('aria-busy', 'true');
                    if (botonGuardar) {
                        botonGuardar.disabled = true;
                        botonGuardar.textContent = 'Guardando…';
                    }

                    try {
                        const respuesta = await fetch(formulario.action || window.location.href, {
                            method: 'POST',
                            body: new FormData(formulario),
                            credentials: 'same-origin',
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                                'Accept': 'application/json'
                            }
                        });
                        const resultado = await respuesta.json();

                        if (!respuesta.ok || !resultado.ok) {
                            throw new Error(
                                mensajesOperacionServicio[resultado.codigo]
                                || 'No fue posible actualizar el servicio.'
                            );
                        }

                        actualizarFilaServicioDesdeFormulario(formulario);
                        mostrarFeedbackServicio(
                            mensajesOperacionServicio[resultado.codigo]
                            || 'Servicio actualizado correctamente.',
                            'exito'
                        );
                    } catch (error) {
                        mostrarFeedbackServicio(
                            error && error.message
                                ? error.message
                                : 'No fue posible actualizar el servicio.',
                            'error'
                        );
                    } finally {
                        formulario.dataset.sending = '0';
                        formulario.removeAttribute('aria-busy');
                        if (botonGuardar) {
                            botonGuardar.disabled = false;
                            botonGuardar.textContent = textoBoton;
                        }
                    }
                });
            });
        }

        function coincideFiltroServicio(valorFila, valorFiltro) {
            if (valorFiltro === '') {
                return true;
            }

            const valorNormalizado = normalizarTextoServicio(valorFila);
            return valorFiltro === '__sin_valor__'
                ? valorNormalizado === ''
                : valorNormalizado === valorFiltro;
        }

        function filtrarServicios() {
            if (!filtroNombreServicio) {
                return;
            }

            const consulta = normalizarTextoServicio(filtroNombreServicio.value);
            const clasificacion = valorFiltroServicio(filtroClasificacionServicio);
            const proceso = valorFiltroServicio(filtroProcesoServicio);
            const gestor = valorFiltroServicio(filtroGestorServicio);
            const estado = valorFiltroServicio(filtroEstadoServicio);
            const filas = Array.from(document.querySelectorAll('.fila-servicio'));
            let visibles = 0;

            filas.forEach(function (fila) {
                const coincideNombre = consulta === ''
                    || normalizarTextoServicio(fila.dataset.filterName).includes(consulta);
                const coincide = coincideNombre
                    && coincideFiltroServicio(fila.dataset.filterClassification, clasificacion)
                    && coincideFiltroServicio(fila.dataset.filterProcess, proceso)
                    && coincideFiltroServicio(fila.dataset.filterManager, gestor)
                    && coincideFiltroServicio(fila.dataset.filterStatus, estado);
                const idServicio = fila.dataset.serviceId;
                const filaEdicion = document.querySelector(
                    '[data-service-edit-id="' + idServicio + '"]'
                );

                fila.hidden = !coincide;
                if (filaEdicion) {
                    filaEdicion.hidden = !coincide;
                    if (!coincide) {
                        filaEdicion.style.display = 'none';
                    }
                }
                if (coincide) {
                    visibles += 1;
                }
            });

            if (limpiarFiltroServicio) {
                limpiarFiltroServicio.hidden = consulta === '';
            }
            if (limpiarFiltrosServicio) {
                limpiarFiltrosServicio.hidden = consulta === ''
                && clasificacion === ''
                && proceso === ''
                && gestor === ''
                && estado === '';
            }
            if (sinResultadosServicio) {
                sinResultadosServicio.hidden = visibles !== 0;
            }
            if (resultadoFiltroServicio) {
                resultadoFiltroServicio.textContent = visibles + (visibles === 1 ? ' disponible' : ' disponibles');
            }

            document.querySelectorAll('.acciones-menu[open]').forEach(function (menu) {
                menu.removeAttribute('open');
            });
        }

        function vincularFiltrosServicios() {
            if (!filtroNombreServicio || filtroNombreServicio.dataset.filterReady === '1') {
                return;
            }
            filtroNombreServicio.dataset.filterReady = '1';
            filtroNombreServicio.addEventListener('input', filtrarServicios);
            if (limpiarFiltroServicio) {
                limpiarFiltroServicio.addEventListener('click', function () {
                    filtroNombreServicio.value = '';
                    filtrarServicios();
                    filtroNombreServicio.focus();
                });
            }

            [
                filtroClasificacionServicio,
                filtroProcesoServicio,
                filtroGestorServicio,
                filtroEstadoServicio
            ].forEach(function (select) {
                if (select) {
                    select.addEventListener('change', filtrarServicios);
                }
            });

            if (limpiarFiltrosServicio) {
                limpiarFiltrosServicio.addEventListener('click', function () {
                    filtroNombreServicio.value = '';
                    if (filtroClasificacionServicio) filtroClasificacionServicio.value = '';
                    if (filtroProcesoServicio) filtroProcesoServicio.value = '';
                    if (filtroGestorServicio) filtroGestorServicio.value = '';
                    if (filtroEstadoServicio) filtroEstadoServicio.value = '';
                    filtrarServicios();
                    filtroNombreServicio.focus();
                });
            }
        }

                vincularScrollSuperiorServicios();
        vincularFiltrosServicios();

        function abrirModal(id) {
            document.getElementById(id).style.display = 'block';
        }

        function cerrarModal(id) {
            document.getElementById(id).style.display = 'none';
        }

        function alternarDescripcionServicio(boton) {
            const descripcion = document.getElementById(
                boton.getAttribute('aria-controls')
            );

            if (!descripcion) {
                return;
            }

            const expandida = boton.getAttribute('aria-expanded') === 'true';
            descripcion.classList.toggle('expanded', !expandida);
            boton.setAttribute('aria-expanded', String(!expandida));
            boton.textContent = expandida ? 'Ver más' : 'Ver menos';
        }

        function actualizarControlesDescripcion() {
            document.querySelectorAll('.service-description-toggle').forEach(function (boton) {
                const descripcion = document.getElementById(
                    boton.getAttribute('aria-controls')
                );

                if (!descripcion || descripcion.classList.contains('expanded')) {
                    return;
                }

                boton.hidden = descripcion.scrollHeight <= descripcion.clientHeight + 1;
            });
        }

        function ajustarEditorDescripcion(textarea) {
            if (!textarea) {
                return;
            }

            textarea.style.height = 'auto';
            textarea.style.height = Math.min(
                Math.max(textarea.scrollHeight, 120),
                190
            ) + 'px';
        }

        function mostrarEdicionServicio(id) {
            const fila = document.getElementById('edicion-servicio-' + id);
            const estaVisible = fila.style.display === 'table-row';

            document.querySelectorAll('.fila-edicion').forEach(function (otraFila) {
                if (otraFila !== fila) {
                    otraFila.style.display = 'none';
                }
            });

            fila.style.display = estaVisible ? 'none' : 'table-row';

            if (!estaVisible) {
                const formularioEdicion = fila.querySelector('.config-service-form');
                if (formularioEdicion) {
                    formularioEdicion.scrollTop = 0;
                }
                ajustarEditorDescripcion(
                    fila.querySelector('.service-description-editor')
                );
            }

            document.querySelectorAll('.acciones-menu[open]').forEach(function (menu) {
                menu.removeAttribute('open');
            });
        }

        function inicializarOpcionesDeServicio() {
            const dependencias = {
                departamento: 'pais',
                ciudad: 'departamento'
            };

            document.querySelectorAll('.config-service-form').forEach(function (formulario) {
                const selects = {};
                const urgencia = formulario.querySelector('[data-matriz-urgencia]');
                const impacto = formulario.querySelector('[data-matriz-impacto]');
                const resultado = formulario.querySelector('[data-matriz-resultado]');

                formulario
                    .querySelectorAll('select[data-config-tipo]')
                    .forEach(function (select) {
                        selects[select.dataset.configTipo] = select;
                    });

                function filtrarSelect(tipoHijo) {
                    const tipoPadre = dependencias[tipoHijo];
                    const selectPadre = selects[tipoPadre];
                    const selectHijo = selects[tipoHijo];

                    if (!selectPadre || !selectHijo) {
                        return;
                    }

                    const idPadre = selectPadre.value;
                    let seleccionValida = selectHijo.value === '';

                    Array.from(selectHijo.options).forEach(function (opcion) {
                        if (opcion.value === '') {
                            opcion.hidden = false;
                            opcion.disabled = false;
                            return;
                        }

                        const coincide = idPadre !== ''
                            && opcion.dataset.padre === idPadre;

                        opcion.hidden = !coincide;
                        opcion.disabled = !coincide;

                        if (coincide && opcion.selected) {
                            seleccionValida = true;
                        }
                    });

                    if (!seleccionValida) {
                        selectHijo.value = '';
                    }

                    selectHijo.disabled = idPadre === '';
                }

                function actualizarDesde(tipoPadre) {
                    if (tipoPadre === 'pais') {
                        filtrarSelect('departamento');
                        filtrarSelect('ciudad');
                    } else if (tipoPadre === 'departamento') {
                        filtrarSelect('ciudad');
                    }
                }

                ['pais', 'departamento'].forEach(function (tipoPadre) {
                    if (!selects[tipoPadre]) {
                        return;
                    }

                    selects[tipoPadre].addEventListener('change', function () {
                        actualizarDesde(tipoPadre);
                    });
                });

                filtrarSelect('departamento');
                filtrarSelect('ciudad');

                function actualizarMatriz() {
                    if (!urgencia || !impacto || !resultado) {
                        return;
                    }

                    const u = Number(urgencia.value);
                    const i = Number(impacto.value);
                    const nombres = {
                        '1-1': 'Bajo',
                        '1-2': 'Bajo moderado',
                        '1-3': 'Bajo urgente',
                        '2-1': 'Moderado bajo',
                        '2-2': 'Moderado',
                        '2-3': 'Moderado urgente',
                        '3-1': 'Urgente bajo',
                        '3-2': 'Urgente moderado',
                        '3-3': 'Urgente'
                    };

                    if (!nombres[u + '-' + i]) {
                        resultado.style.removeProperty('--priority-color');
                        resultado.querySelector('strong').textContent = 'Seleccione urgencia e impacto';
                        resultado.querySelector('small').textContent = 'El sistema aplicará automáticamente la matriz corporativa.';
                        return;
                    }

                    const puntaje = u + i - 1;
                    const colores = ['#16a34a', '#65a30d', '#ca8a04', '#ea580c', '#dc2626'];
                    resultado.style.setProperty('--priority-color', colores[puntaje - 1]);
                    resultado.querySelector('strong').textContent = puntaje + ' · ' + nombres[u + '-' + i];
                    resultado.querySelector('small').textContent = 'Código ' + u + '-' + i + ' de la matriz corporativa.';
                }

                [urgencia, impacto].forEach(function (selector) {
                    if (selector) {
                        selector.addEventListener('change', actualizarMatriz);
                    }
                });
                actualizarMatriz();
            });
        }

        inicializarOpcionesDeServicio();
        inicializarEdicionServicioAjax();
        actualizarControlesDescripcion();

        document.querySelectorAll('.service-description-editor').forEach(function (textarea) {
            textarea.addEventListener('input', function () {
                ajustarEditorDescripcion(textarea);
            });
        });

        window.addEventListener('resize', actualizarControlesDescripcion);

        window.addEventListener('click', function (event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }

            const menuSeleccionado = event.target.closest('.acciones-menu');

            document.querySelectorAll('.acciones-menu[open]').forEach(function (menu) {
                if (menu !== menuSeleccionado) {
                    menu.removeAttribute('open');
                }
            });
        });

        window.addEventListener('keydown', function (event) {
            if (event.key !== 'Escape') {
                return;
            }

            document.querySelectorAll('.modal').forEach(function (modal) {
                modal.style.display = 'none';
            });

            document.querySelectorAll('.acciones-menu[open]').forEach(function (menu) {
                menu.removeAttribute('open');
            });
        });
        function inicializarFiltroGestores() {
            function normalizarProceso(valor) {
                return String(valor || '')
                    .normalize('NFD')
                    .replace(/[\u0300-\u036f]/g, '')
                    .toLocaleLowerCase('es')
                    .trim()
                    .replace(/\s+/g, ' ');
            }

            document.querySelectorAll('.config-service-form').forEach(function (formulario) {
                const selectorProceso = formulario.querySelector('select[name="proceso"]');
                const selectorGestor = formulario.querySelector('select[name="id_gestor"]');

                if (!selectorProceso || !selectorGestor) {
                    return;
                }

                const opcionesGestor = Array.from(selectorGestor.options)
                    .filter(function (opcion) {
                        return opcion.value !== '' && opcion.dataset.proceso;
                    })
                    .map(function (opcion) {
                        return opcion.cloneNode(true);
                    });
                const gestorGuardado = selectorGestor.value;

                function agregarMensaje(texto) {
                    const opcion = document.createElement('option');
                    opcion.value = '';
                    opcion.textContent = texto;
                    selectorGestor.appendChild(opcion);
                }

                function filtrarGestores(conservarGestor) {
                    const procesoSeleccionado = normalizarProceso(selectorProceso.value);
                    const seleccionAnterior = conservarGestor
                        ? (selectorGestor.value || gestorGuardado)
                        : '';

                    selectorGestor.innerHTML = '';

                    if (procesoSeleccionado === '') {
                        agregarMensaje('Primero seleccione un proceso');
                        selectorGestor.disabled = true;
                        selectorGestor.value = '';
                        return;
                    }

                    const coincidencias = opcionesGestor.filter(function (opcion) {
                        return normalizarProceso(opcion.dataset.proceso)
                            === procesoSeleccionado;
                    });

                    if (!coincidencias.length) {
                        agregarMensaje('No hay gestores activos para este proceso');
                        selectorGestor.disabled = true;
                        selectorGestor.value = '';
                        return;
                    }

                    agregarMensaje('Seleccione un gestor');
                    coincidencias.forEach(function (opcion) {
                        selectorGestor.appendChild(opcion.cloneNode(true));
                    });
                    selectorGestor.disabled = false;

                    const seleccionSigueDisponible = coincidencias.some(function (opcion) {
                        return opcion.value === String(seleccionAnterior);
                    });
                    selectorGestor.value = seleccionSigueDisponible
                        ? String(seleccionAnterior)
                        : '';
                }

                selectorProceso.addEventListener('change', function () {
                    filtrarGestores(false);
                });
                filtrarGestores(true);
            });
        }

        inicializarFiltroGestores();
    </script>
    <script src="assets/js/controlSesion.js" defer></script>
</body>
</html>
