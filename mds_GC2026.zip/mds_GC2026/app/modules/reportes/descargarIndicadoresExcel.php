<?php
declare(strict_types=1);

/* Reutiliza las mismas consultas del panel para que Excel y la pantalla nunca
   presenten cifras calculadas con reglas diferentes. */
define('MESA_INDICADORES_SOLO_DATOS', true);
require APP_ROOT . '/modules/reportes/indicadores.php';

if (!class_exists('ZipArchive')) {
    http_response_code(503);
    exit('El servidor no tiene habilitado el soporte necesario para generar Excel.');
}

function excelIndicadoresXml($valor): string
{
    return htmlspecialchars(
        (string) $valor,
        ENT_XML1 | ENT_QUOTES,
        'UTF-8'
    );
}

function excelIndicadoresColumna(int $numero): string
{
    $salida = '';
    while ($numero > 0) {
        $numero--;
        $salida = chr(65 + ($numero % 26)) . $salida;
        $numero = intdiv($numero, 26);
    }
    return $salida;
}

function excelIndicadoresCelda(
    int $columna,
    int $fila,
    $valor,
    int $estilo = 8
): string {
    $referencia = excelIndicadoresColumna($columna) . $fila;
    if (is_int($valor) || is_float($valor)) {
        return '<c r="' . $referencia . '" s="' . $estilo . '"><v>'
            . excelIndicadoresXml((string) $valor)
            . '</v></c>';
    }
    if ($valor === null) {
        $valor = '';
    }
    return '<c r="' . $referencia . '" s="' . $estilo
        . '" t="inlineStr"><is><t xml:space="preserve">'
        . excelIndicadoresXml((string) $valor)
        . '</t></is></c>';
}

function excelIndicadoresEtiqueta(string $clave): string
{
    $etiquetas = [
        'id_ticket' => 'Ticket',
        'id_ticket_etapa' => 'Etapa',
        'id_usuario' => 'Usuario',
        'nombre' => 'Nombre',
        'clave' => 'Periodo',
        'etiqueta' => 'Etiqueta',
        'cumplimiento_sla' => 'Cumplimiento SLA (%)',
        'promedio_minutos' => 'Tiempo promedio (min)',
        'promedio_primer_contacto' => 'Primer contacto (min)',
        'promedio_respuesta_mensajes' => 'Respuesta mensajes (min)',
        'promedio_calificacion' => 'Calificación general',
        'calificacion' => 'Calificación general',
        'calificacion_area' => 'Gestión del proceso',
        'calificacion_tiempo' => 'Tiempo de respuesta',
        'fecha_creacion' => 'Fecha de creación',
        'fecha_finalizacion' => 'Fecha de finalización',
    ];
    return $etiquetas[$clave]
        ?? ucwords(str_replace('_', ' ', $clave));
}

/** @param array<int,array<string,mixed>> $filas */
function excelIndicadoresHojaDatos(array $filas, string $mensajeVacio): string
{
    $claves = $filas ? array_keys($filas[0]) : ['informacion'];
    $encabezados = array_map('excelIndicadoresEtiqueta', $claves);
    $filasXml = [];
    $encabezadoXml = '';
    foreach ($encabezados as $indice => $encabezado) {
        $encabezadoXml .= excelIndicadoresCelda($indice + 1, 1, $encabezado, 7);
    }
    $filasXml[] = '<row r="1" ht="26" customHeight="1">'
        . $encabezadoXml . '</row>';

    if (!$filas) {
        $filas = [['informacion' => $mensajeVacio]];
    }
    foreach ($filas as $indiceFila => $fila) {
        $numeroFila = $indiceFila + 2;
        $celdas = '';
        foreach ($claves as $indiceColumna => $clave) {
            $valor = $fila[$clave] ?? '';
            $estilo = is_numeric($valor) && $valor !== '' ? 9 : 8;
            $celdas .= excelIndicadoresCelda(
                $indiceColumna + 1,
                $numeroFila,
                is_numeric($valor) && $valor !== '' ? (float) $valor : $valor,
                $estilo
            );
        }
        $filasXml[] = '<row r="' . $numeroFila . '">' . $celdas . '</row>';
    }

    $anchos = [];
    foreach ($claves as $indice => $clave) {
        $maximo = strlen((string) ($encabezados[$indice] ?? ''));
        foreach (array_slice($filas, 0, 200) as $fila) {
            $maximo = max($maximo, strlen((string) ($fila[$clave] ?? '')));
        }
        $anchos[] = min(42, max(11, $maximo + 2));
    }
    $columnasXml = '';
    foreach ($anchos as $indice => $ancho) {
        $numero = $indice + 1;
        $columnasXml .= '<col min="' . $numero . '" max="' . $numero
            . '" width="' . $ancho . '" customWidth="1"/>';
    }
    $ultimaFila = count($filasXml);
    $ultimaColumna = excelIndicadoresColumna(count($claves));

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<dimension ref="A1:' . $ultimaColumna . $ultimaFila . '"/>'
        . '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
        . '<sheetFormatPr defaultRowHeight="18"/>'
        . '<cols>' . $columnasXml . '</cols>'
        . '<sheetData>' . implode('', $filasXml) . '</sheetData>'
        . '<autoFilter ref="A1:' . $ultimaColumna . $ultimaFila . '"/>'
        . '</worksheet>';
}

/** @param array<int,array{label:string,value:string,note:string}> $metricas */
function excelIndicadoresHojaDashboard(
    array $metricas,
    string $periodo,
    string $area,
    string $servicio,
    bool $conGraficos
): string {
    $filas = [];
    $filas[1] = excelIndicadoresCelda(1, 1, 'DASHBOARD DE INDICADORES', 1);
    $filas[3] = excelIndicadoresCelda(1, 3, 'SMARTDESK · Reporte ejecutivo tipo Power BI', 2);
    $filas[4] = excelIndicadoresCelda(1, 4, 'Periodo', 3)
        . excelIndicadoresCelda(3, 4, $periodo, 8)
        . excelIndicadoresCelda(6, 4, 'Proceso', 3)
        . excelIndicadoresCelda(8, 4, $area, 8)
        . excelIndicadoresCelda(10, 4, 'Servicio', 3)
        . excelIndicadoresCelda(12, 4, $servicio, 8);
    $filas[5] = excelIndicadoresCelda(1, 5, 'Actualizado', 3)
        . excelIndicadoresCelda(3, 5, date('d/m/Y H:i'), 8);
    $filas[7] = excelIndicadoresCelda(1, 7, 'INDICADORES CLAVE', 3);

    $filaBase = 8;
    foreach ($metricas as $indice => $metrica) {
        $grupo = intdiv($indice, 6);
        $posicion = $indice % 6;
        $columna = 1 + ($posicion * 2);
        $fila = $filaBase + ($grupo * 4);
        $filas[$fila] = ($filas[$fila] ?? '')
            . excelIndicadoresCelda($columna, $fila, $metrica['label'], 4);
        $filas[$fila + 1] = ($filas[$fila + 1] ?? '')
            . excelIndicadoresCelda($columna, $fila + 1, $metrica['value'], 5);
        $filas[$fila + 2] = ($filas[$fila + 2] ?? '')
            . excelIndicadoresCelda($columna, $fila + 2, $metrica['note'], 6);
    }

    ksort($filas);
    $filasXml = [];
    foreach ($filas as $numero => $celdas) {
        $alto = in_array($numero, [1, 2], true) ? 28 : 21;
        $filasXml[] = '<row r="' . $numero . '" ht="' . $alto
            . '" customHeight="1">' . $celdas . '</row>';
    }
    $uniones = ['A1:L2', 'A3:L3', 'A7:L7'];
    for ($indice = 0; $indice < count($metricas); $indice++) {
        $grupo = intdiv($indice, 6);
        $posicion = $indice % 6;
        $columna = 1 + ($posicion * 2);
        $letraInicio = excelIndicadoresColumna($columna);
        $letraFin = excelIndicadoresColumna($columna + 1);
        $fila = $filaBase + ($grupo * 4);
        $uniones[] = $letraInicio . $fila . ':' . $letraFin . $fila;
        $uniones[] = $letraInicio . ($fila + 1) . ':' . $letraFin . ($fila + 1);
        $uniones[] = $letraInicio . ($fila + 2) . ':' . $letraFin . ($fila + 2);
    }
    $unionesXml = '<mergeCells count="' . count($uniones) . '">';
    foreach ($uniones as $union) {
        $unionesXml .= '<mergeCell ref="' . $union . '"/>';
    }
    $unionesXml .= '</mergeCells>';
    $columnas = '';
    for ($columna = 1; $columna <= 12; $columna++) {
        $columnas .= '<col min="' . $columna . '" max="' . $columna
            . '" width="14" customWidth="1"/>';
    }

    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<dimension ref="A1:L55"/><sheetViews><sheetView workbookViewId="0" showGridLines="0"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
        . '<sheetFormatPr defaultRowHeight="20"/><cols>' . $columnas . '</cols>'
        . '<sheetData>' . implode('', $filasXml) . '</sheetData>'
        . $unionesXml
        . '<pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.2" footer="0.2"/>'
        . '<pageSetup orientation="landscape" paperSize="9" fitToWidth="1" fitToHeight="0"/>'
        . ($conGraficos ? '<drawing r:id="rId1"/>' : '')
        . '</worksheet>';
}

/** @param array<int,string> $categorias @param array<int,array{name:string,values:array<int,float|int>,color:string}> $series */
function excelIndicadoresGrafico(
    string $titulo,
    string $tipo,
    string $hoja,
    string $rangoCategorias,
    array $categorias,
    array $series,
    array $rangosValores
): string {
    $tituloXml = '<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="es-CO" sz="1200" b="1"/><a:t>'
        . excelIndicadoresXml($titulo)
        . '</a:t></a:r></a:p></c:rich></c:tx><c:layout/></c:title>';
    $seriesXml = '';
    foreach ($series as $indice => $serie) {
        $categoriasCache = '';
        foreach ($categorias as $posicion => $categoria) {
            $categoriasCache .= '<c:pt idx="' . $posicion . '"><c:v>'
                . excelIndicadoresXml($categoria) . '</c:v></c:pt>';
        }
        $valoresCache = '';
        foreach ($serie['values'] as $posicion => $valor) {
            $valoresCache .= '<c:pt idx="' . $posicion . '"><c:v>'
                . (float) $valor . '</c:v></c:pt>';
        }
        $seriesXml .= '<c:ser><c:idx val="' . $indice . '"/><c:order val="' . $indice . '"/>'
            . '<c:tx><c:v>' . excelIndicadoresXml($serie['name']) . '</c:v></c:tx>'
            . '<c:spPr><a:solidFill><a:srgbClr val="' . $serie['color'] . '"/></a:solidFill></c:spPr>'
            . '<c:cat><c:strRef><c:f>\'' . excelIndicadoresXml($hoja) . '\'!'
            . excelIndicadoresXml($rangoCategorias)
            . '</c:f><c:strCache><c:ptCount val="' . count($categorias) . '"/>'
            . $categoriasCache . '</c:strCache></c:strRef></c:cat>'
            . '<c:val><c:numRef><c:f>\'' . excelIndicadoresXml($hoja) . '\'!'
            . excelIndicadoresXml($rangosValores[$indice] ?? '$B$2:$B$2')
            . '</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="'
            . count($serie['values']) . '"/>' . $valoresCache
            . '</c:numCache></c:numRef></c:val></c:ser>';
    }
    $grafico = '';
    if ($tipo === 'doughnut') {
        $grafico = '<c:doughnutChart><c:varyColors val="1"/>' . $seriesXml
            . '<c:holeSize val="58"/></c:doughnutChart>';
    } elseif ($tipo === 'line') {
        $grafico = '<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>'
            . $seriesXml . '<c:marker val="1"/><c:axId val="770001"/><c:axId val="770002"/></c:lineChart>'
            . '<c:catAx><c:axId val="770001"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:tickLblPos val="nextTo"/><c:crossAx val="770002"/><c:crosses val="autoZero"/></c:catAx>'
            . '<c:valAx><c:axId val="770002"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:numFmt formatCode="0" sourceLinked="0"/><c:tickLblPos val="nextTo"/><c:crossAx val="770001"/><c:crosses val="autoZero"/></c:valAx>';
    } else {
        $grafico = '<c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/>'
            . $seriesXml . '<c:gapWidth val="70"/><c:axId val="880001"/><c:axId val="880002"/></c:barChart>'
            . '<c:catAx><c:axId val="880001"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:tickLblPos val="nextTo"/><c:crossAx val="880002"/><c:crosses val="autoZero"/></c:catAx>'
            . '<c:valAx><c:axId val="880002"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:numFmt formatCode="0" sourceLinked="0"/><c:tickLblPos val="nextTo"/><c:crossAx val="880001"/><c:crosses val="autoZero"/></c:valAx>';
    }
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<c:date1904 val="0"/><c:lang val="es-CO"/><c:chart>' . $tituloXml
        . '<c:plotArea><c:layout/>' . $grafico . '</c:plotArea>'
        . '<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart></c:chartSpace>';
}

/** @param array<int,array{fromCol:int,fromRow:int,toCol:int,toRow:int}> $posiciones */
function excelIndicadoresDibujo(array $posiciones): string
{
    $anclas = '';
    foreach ($posiciones as $indice => $posicion) {
        $numero = $indice + 1;
        $anclas .= '<xdr:twoCellAnchor><xdr:from><xdr:col>' . $posicion['fromCol']
            . '</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>' . $posicion['fromRow']
            . '</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>'
            . $posicion['toCol'] . '</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>'
            . $posicion['toRow'] . '</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>'
            . '<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="' . $numero
            . '" name="Gráfico ' . $numero . '"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr>'
            . '<xdr:xfrm/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart">'
            . '<c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="rId'
            . $numero . '"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>';
    }
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        . $anclas . '</xdr:wsDr>';
}

$nombreAreaExcel = 'Todos los procesos';
foreach ($areasIndicador as $areaIndicador) {
    if ((int) $areaIndicador['id_catalogo'] === $idCatalogoIndicador) {
        $nombreAreaExcel = (string) $areaIndicador['nombre'];
        break;
    }
}
$nombreServicioExcel = 'Todos los servicios';
foreach ($serviciosSolucionFiltro as $servicioFiltro) {
    if ((int) $servicioFiltro['id_servicio'] === $idServicioSolucion) {
        $nombreServicioExcel = (string) $servicioFiltro['nombre'];
        break;
    }
}

$metricasDashboard = [
    ['label' => 'Tickets totales', 'value' => numeroIndicador($resumen['total']), 'note' => numeroIndicador($resumen['solicitantes']) . ' solicitantes'],
    ['label' => 'Casos del flujo', 'value' => numeroIndicador($resumenEtapas['etapas']), 'note' => 'Padres, hijos y descendientes'],
    ['label' => 'Derivaciones', 'value' => numeroIndicador($resumenEtapas['derivaciones']), 'note' => 'Casos de apoyo creados'],
    ['label' => 'En proceso', 'value' => numeroIndicador($resumen['en_proceso']), 'note' => 'Tickets actualmente activos'],
    ['label' => 'Tickets cerrados', 'value' => numeroIndicador($resumen['cerrados']), 'note' => 'Proceso finalizado'],
    ['label' => 'Cumplimiento SLA', 'value' => porcentajeIndicador($cumplimientoSla), 'note' => numeroIndicador($evaluadasSla) . ' etapas evaluadas'],
    ['label' => 'Fuera del SLA', 'value' => numeroIndicador($resumenEtapas['fuera_sla']), 'note' => 'Etapas incumplidas'],
    ['label' => 'Riesgo SLA', 'value' => numeroIndicador($casosRiesgoSla), 'note' => 'Casos próximos a vencer'],
    ['label' => 'Casos reabiertos', 'value' => numeroIndicador($resumenEtapas['casos_reabiertos']), 'note' => 'Una o más reaperturas'],
    ['label' => 'Pendientes encuesta', 'value' => numeroIndicador($resumen['pendiente_calificacion']), 'note' => 'Esperando calificación'],
    ['label' => 'Listos para cierre', 'value' => numeroIndicador($resumenEtapas['listos_cierre']), 'note' => 'Esperando decisión'],
    ['label' => 'SLA pausado', 'value' => numeroIndicador($resumenEtapas['pausadas']), 'note' => 'Esperando derivaciones'],
    ['label' => 'Calificación procesos', 'value' => $promedioCalificacionArea === null ? 'Sin datos' : calificacionEnteraIndicador($promedioCalificacionArea) . '/5', 'note' => 'Gestión percibida'],
    ['label' => 'Calificación tiempos', 'value' => $promedioCalificacionTiempo === null ? 'Sin datos' : calificacionEnteraIndicador($promedioCalificacionTiempo) . '/5', 'note' => 'Oportunidad percibida'],
    ['label' => 'Encuesta servicio', 'value' => $promedioEncuestaServicio === null ? 'Sin datos' : calificacionEnteraIndicador($promedioEncuestaServicio) . '/5', 'note' => numeroIndicador($resumenEncuestaServicio['calificaciones']) . ' respuestas'],
    ['label' => 'Evaluaciones internas', 'value' => $promedioEvaluacionInterna === null ? 'Sin datos' : calificacionEnteraIndicador($promedioEvaluacionInterna) . '/5', 'note' => numeroIndicador($resumenEvaluacionInterna['calificaciones']) . ' evaluaciones'],
    ['label' => 'Tiempo promedio proceso', 'value' => tiempoIndicador($resumenEtapas['promedio_etapa']), 'note' => 'Minutos hábiles'],
    ['label' => 'Ciclo promedio ticket', 'value' => tiempoIndicador($resumen['promedio_ciclo']), 'note' => 'Desde creación hasta cierre'],
];

$distribucionCalificaciones = [];
for ($estrella = 5; $estrella >= 1; $estrella--) {
    $distribucionCalificaciones[] = [
        'estrellas' => $estrella,
        'gestion_area' => (int) ($distribucionCalificacionArea[$estrella] ?? 0),
        'tiempo_respuesta' => (int) ($distribucionCalificacionTiempo[$estrella] ?? 0),
    ];
}
$comentariosSolucionesExcel = [];
foreach ($comentariosPorSolucion as $grupoComentarios) {
    foreach ($grupoComentarios as $comentario) {
        $comentariosSolucionesExcel[] = $comentario;
    }
}

$hojasDatos = [
    'Tendencia' => $tendenciaCompleta,
    'Estados' => $porEstado,
    'Clasificaciones' => $porClasificacion,
    'Urgencias' => $porUrgencia,
    'Tipos' => $porTipoCompleto,
    'Procesos' => $porProcesoServicio,
    'Gestores' => $porGestor,
    'Areas' => $porArea,
    'Servicios' => $porServicio,
    'Soluciones' => $porSolucionServicio,
    'Comentarios soluciones' => $comentariosSolucionesExcel,
    'Distribucion notas' => $distribucionCalificaciones,
    'Calificaciones' => $detalleCalificaciones,
    'Tickets' => $detalleTickets,
];

$graficos = [];
if ($porEstado) {
    $graficos[] = [
        'xml' => excelIndicadoresGrafico(
            'Tickets por estado',
            'doughnut',
            'Estados',
            '$A$2:$A$' . (count($porEstado) + 1),
            array_map(static fn (array $fila): string => etiquetaEstadoIndicador((string) $fila['nombre']), $porEstado),
            [[
                'name' => 'Tickets',
                'values' => array_map(static fn (array $fila): int => (int) $fila['total'], $porEstado),
                'color' => '0F6FEC',
            ]],
            ['$B$2:$B$' . (count($porEstado) + 1)]
        ),
        'posicion' => ['fromCol' => 0, 'fromRow' => 20, 'toCol' => 6, 'toRow' => 37],
    ];
}
if ($porClasificacion) {
    $graficos[] = [
        'xml' => excelIndicadoresGrafico(
            'Casos por clasificación',
            'column',
            'Clasificaciones',
            '$A$2:$A$' . (count($porClasificacion) + 1),
            array_map(static fn (array $fila): string => (string) $fila['nombre'], $porClasificacion),
            [[
                'name' => 'Casos',
                'values' => array_map(static fn (array $fila): int => (int) $fila['total'], $porClasificacion),
                'color' => '12A594',
            ]],
            ['$B$2:$B$' . (count($porClasificacion) + 1)]
        ),
        'posicion' => ['fromCol' => 6, 'fromRow' => 20, 'toCol' => 12, 'toRow' => 37],
    ];
}
if ($tendenciaCompleta) {
    $graficos[] = [
        'xml' => excelIndicadoresGrafico(
            'Evolución de tickets',
            'line',
            'Tendencia',
            '$B$2:$B$' . (count($tendenciaCompleta) + 1),
            array_map(static fn (array $fila): string => (string) $fila['etiqueta'], $tendenciaCompleta),
            [
                ['name' => 'Creados', 'values' => array_map(static fn (array $fila): int => (int) $fila['creados'], $tendenciaCompleta), 'color' => '0F6FEC'],
                ['name' => 'Finalizados', 'values' => array_map(static fn (array $fila): int => (int) $fila['finalizados'], $tendenciaCompleta), 'color' => '12A594'],
            ],
            [
                '$C$2:$C$' . (count($tendenciaCompleta) + 1),
                '$D$2:$D$' . (count($tendenciaCompleta) + 1),
            ]
        ),
        'posicion' => ['fromCol' => 0, 'fromRow' => 38, 'toCol' => 12, 'toRow' => 55],
    ];
}

$estilosXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="7">
 <font><sz val="10"/><color rgb="FF243B53"/><name val="Calibri"/></font>
 <font><b/><sz val="22"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
 <font><sz val="11"/><color rgb="FF6B7F93"/><name val="Calibri"/></font>
 <font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
 <font><b/><sz val="9"/><color rgb="FF526B82"/><name val="Calibri"/></font>
 <font><b/><sz val="17"/><color rgb="FF102A43"/><name val="Calibri"/></font>
 <font><sz val="8"/><color rgb="FF6B7F93"/><name val="Calibri"/></font>
</fonts>
<fills count="6">
 <fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
 <fill><patternFill patternType="solid"><fgColor rgb="FF102A43"/><bgColor indexed="64"/></patternFill></fill>
 <fill><patternFill patternType="solid"><fgColor rgb="FF0F6FEC"/><bgColor indexed="64"/></patternFill></fill>
 <fill><patternFill patternType="solid"><fgColor rgb="FFEAF4FF"/><bgColor indexed="64"/></patternFill></fill>
 <fill><patternFill patternType="solid"><fgColor rgb="FFF7FAFC"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFDCE6F0"/></left><right style="thin"><color rgb="FFDCE6F0"/></right><top style="thin"><color rgb="FFDCE6F0"/></top><bottom style="thin"><color rgb="FFDCE6F0"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="10">
 <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
 <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0"><alignment horizontal="left" vertical="center"/></xf>
 <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0"/>
 <xf numFmtId="0" fontId="3" fillId="3" borderId="1" xfId="0"><alignment vertical="center"/></xf>
 <xf numFmtId="0" fontId="4" fillId="4" borderId="1" xfId="0"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
 <xf numFmtId="0" fontId="5" fillId="4" borderId="1" xfId="0"><alignment horizontal="center" vertical="center"/></xf>
 <xf numFmtId="0" fontId="6" fillId="4" borderId="1" xfId="0"><alignment horizontal="center" vertical="top" wrapText="1"/></xf>
 <xf numFmtId="0" fontId="3" fillId="2" borderId="1" xfId="0"><alignment vertical="center" wrapText="1"/></xf>
 <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0"><alignment vertical="top" wrapText="1"/></xf>
 <xf numFmtId="4" fontId="0" fillId="0" borderId="1" xfId="0"><alignment vertical="top"/></xf>
</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>';

$nombresHojas = array_merge(['Dashboard'], array_keys($hojasDatos));
$hojasXml = [excelIndicadoresHojaDashboard(
    $metricasDashboard,
    $periodo,
    $nombreAreaExcel,
    $nombreServicioExcel,
    (bool) $graficos
)];
foreach ($hojasDatos as $nombreHoja => $filasHoja) {
    $hojasXml[] = excelIndicadoresHojaDatos(
        $filasHoja,
        'No hay datos para los filtros seleccionados.'
    );
}

$sheetsLibro = '';
$relsLibro = '';
$tiposHojas = '';
foreach ($nombresHojas as $indice => $nombreHoja) {
    $numero = $indice + 1;
    $sheetsLibro .= '<sheet name="' . excelIndicadoresXml(substr($nombreHoja, 0, 31))
        . '" sheetId="' . $numero . '" r:id="rId' . $numero . '"/>';
    $relsLibro .= '<Relationship Id="rId' . $numero
        . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet'
        . $numero . '.xml"/>';
    $tiposHojas .= '<Override PartName="/xl/worksheets/sheet' . $numero
        . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
}
$idEstilos = count($nombresHojas) + 1;
$relsLibro .= '<Relationship Id="rId' . $idEstilos
    . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
$libroXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView activeTab="0"/></bookViews><sheets>'
    . $sheetsLibro . '</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>';
$relacionesLibroXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    . $relsLibro . '</Relationships>';
$relacionesRaizXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';

$tiposGraficos = '';
if ($graficos) {
    $tiposGraficos .= '<Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/>';
    foreach ($graficos as $indice => $grafico) {
        $tiposGraficos .= '<Override PartName="/xl/charts/chart' . ($indice + 1)
            . '.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>';
    }
}
$tiposXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
    . $tiposHojas . $tiposGraficos . '</Types>';

$temporal = tempnam(sys_get_temp_dir(), 'dashboard_indicadores_');
if ($temporal === false) {
    http_response_code(500);
    exit('No fue posible crear el archivo temporal del dashboard.');
}
$zip = new ZipArchive();
if ($zip->open($temporal, ZipArchive::OVERWRITE) !== true) {
    @unlink($temporal);
    http_response_code(500);
    exit('No fue posible construir el archivo Excel.');
}
$zip->addFromString('[Content_Types].xml', $tiposXml);
$zip->addFromString('_rels/.rels', $relacionesRaizXml);
$zip->addFromString('xl/workbook.xml', $libroXml);
$zip->addFromString('xl/_rels/workbook.xml.rels', $relacionesLibroXml);
$zip->addFromString('xl/styles.xml', $estilosXml);
foreach ($hojasXml as $indice => $hojaXml) {
    $zip->addFromString('xl/worksheets/sheet' . ($indice + 1) . '.xml', $hojaXml);
}
if ($graficos) {
    $zip->addFromString(
        'xl/worksheets/_rels/sheet1.xml.rels',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>'
    );
    $posiciones = array_column($graficos, 'posicion');
    $zip->addFromString('xl/drawings/drawing1.xml', excelIndicadoresDibujo($posiciones));
    $relsDibujo = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
    foreach ($graficos as $indice => $grafico) {
        $numero = $indice + 1;
        $relsDibujo .= '<Relationship Id="rId' . $numero . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart' . $numero . '.xml"/>';
        $zip->addFromString('xl/charts/chart' . $numero . '.xml', $grafico['xml']);
    }
    $relsDibujo .= '</Relationships>';
    $zip->addFromString('xl/drawings/_rels/drawing1.xml.rels', $relsDibujo);
}
$zip->close();

$nombreArchivo = 'dashboard_indicadores_' . date('Y-m-d_His') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $nombreArchivo . '"');
header('Content-Length: ' . filesize($temporal));
header('Cache-Control: no-store, no-cache, must-revalidate');
readfile($temporal);
@unlink($temporal);
exit;
