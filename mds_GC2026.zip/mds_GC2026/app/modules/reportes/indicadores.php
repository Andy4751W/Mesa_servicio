<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/motorFlujos.php';

seguridadExigirRol([1]);
$idPaisOperacion = paisExigirContexto();
$filtroCasosPrueba = seguridadFiltroCasosOficiales('t');

/*
 * El tablero ejecuta varias consultas analíticas. Liberar cuanto antes el
 * bloqueo de la sesión evita que la navegación hacia otro módulo tenga que
 * esperar a que termine de construirse todo el reporte.
 */
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

function escaparIndicador($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function normalizarFechaIndicador($valor): string
{
    $valor = trim((string) $valor);

    if ($valor === '') {
        return '';
    }

    $fecha = DateTimeImmutable::createFromFormat('!Y-m-d', $valor);

    return $fecha && $fecha->format('Y-m-d') === $valor ? $valor : '';
}

function filasIndicador(mysqli $conn, string $sql): array
{
    $resultado = $conn->query($sql);

    if ($resultado === false) {
        throw new RuntimeException('No fue posible consultar los indicadores.');
    }

    return $resultado->fetch_all(MYSQLI_ASSOC);
}

function filaIndicador(mysqli $conn, string $sql): array
{
    return filasIndicador($conn, $sql)[0] ?? [];
}

function porcentajeIndicador($valor): string
{
    if ($valor === null || $valor === '') {
        return 'Sin datos';
    }

    return number_format((float) $valor, 1, ',', '.') . '%';
}

function numeroIndicador($valor, int $decimales = 0): string
{
    return number_format((float) ($valor ?? 0), $decimales, ',', '.');
}

function calificacionEnteraIndicador($valor): string
{
    if ($valor === null || $valor === '') {
        return 'Sin datos';
    }

    return (string) max(1, min(5, (int) round((float) $valor)));
}

function tiempoIndicador($minutos): string
{
    if ($minutos === null || $minutos === '') {
        return 'Sin datos';
    }

    $minutos = max(0, (int) round((float) $minutos));
    global $conn;
    $minutosDia = isset($conn) && $conn instanceof mysqli
        ? calendarioMinutosDiaSla($conn)
        : (defined('CALENDARIO_MINUTOS_DIA_SLA')
            ? max(1, (int) CALENDARIO_MINUTOS_DIA_SLA)
            : 600);
    $dias = intdiv($minutos, $minutosDia);
    $horas = intdiv($minutos % $minutosDia, 60);
    $resto = $minutos % 60;

    if ($dias > 0) {
        return $dias . ' d ' . $horas . ' h';
    }

    if ($horas > 0) {
        return $horas . ' h ' . $resto . ' min';
    }

    return $resto . ' min';
}

function tiempoCalendarioIndicador($minutos): string
{
    if ($minutos === null || $minutos === '') {
        return 'Sin datos';
    }

    $minutos = max(0, (int) round((float) $minutos));
    $dias = intdiv($minutos, 1440);
    $horas = intdiv($minutos % 1440, 60);
    $resto = $minutos % 60;

    if ($dias > 0) {
        return $dias . ' d ' . $horas . ' h';
    }

    if ($horas > 0) {
        return $horas . ' h ' . $resto . ' min';
    }

    return $resto . ' min';
}

function anchoIndicador($valor, float $maximo): string
{
    $numero = max(0, (float) ($valor ?? 0));

    if ($numero <= 0 || $maximo <= 0) {
        return '0';
    }

    return number_format(max(3, min(100, ($numero / $maximo) * 100)), 2, '.', '');
}

function etiquetaEstadoIndicador(string $estado): string
{
    return (fn ($__mesaMatchValue17) => (($__mesaMatchValue17 === ('en_proceso')) ? ('En proceso') : ((($__mesaMatchValue17 === ('pendiente_calificacion')) ? ('Pendiente de calificación') : ((($__mesaMatchValue17 === ('cerrado')) ? ('Cerrado') : ((($__mesaMatchValue17 === ('cancelado') || $__mesaMatchValue17 === ('cancelada')) ? ('Cancelado') : (ucfirst(str_replace('_', ' ', $estado)))))))))))($estado);
}

function claseEstadoIndicador(string $estado): string
{
    return (fn ($__mesaMatchValue18) => (($__mesaMatchValue18 === ('en_proceso')) ? ('blue') : ((($__mesaMatchValue18 === ('pendiente_calificacion')) ? ('amber') : ((($__mesaMatchValue18 === ('cerrado')) ? ('green') : ((($__mesaMatchValue18 === ('cancelado') || $__mesaMatchValue18 === ('cancelada')) ? ('red') : ('gray')))))))))($estado);
}

function claseUrgenciaIndicador(string $urgencia): string
{
    $urgencia = trim($urgencia);
    $valor = function_exists('mb_strtolower')
        ? mb_strtolower($urgencia, 'UTF-8')
        : strtolower($urgencia);
    if (in_array($valor, ['urgente', 'inmediato'], true)) {
        return 'red';
    }
    if (in_array($valor, ['alta', 'pronto'], true)) {
        return 'amber';
    }
    if (in_array($valor, ['moderada', 'media'], true)) {
        return 'blue';
    }
    if (in_array($valor, ['baja', 'más tarde', 'mas tarde'], true)) {
        return 'green';
    }

    return 'gray';
}

function porcentajeParteIndicador($parte, $total): float
{
    $totalNumero = (float) ($total ?? 0);

    if ($totalNumero <= 0) {
        return 0;
    }

    return round(100 * (float) ($parte ?? 0) / $totalNumero, 1);
}

function etiquetaTipoCalificacion(string $tipo): string
{
    return (fn ($__mesaMatchValue20) => (($__mesaMatchValue20 === ('encuesta_servicio')) ? ('Encuesta del servicio solicitado') : ((($__mesaMatchValue20 === ('evaluacion_derivacion')) ? ('Evaluación interna de derivación') : ((($__mesaMatchValue20 === ('evaluacion_caso')) ? ('Evaluación operativa del caso') : ('Evaluación histórica')))))))($tipo);
}

$desde = normalizarFechaIndicador($_GET['desde'] ?? '');
$hasta = normalizarFechaIndicador($_GET['hasta'] ?? '');
$modoImpresion = (string) ($_GET['imprimir'] ?? '') === '1';
$idCatalogoIndicador = filter_input(
    INPUT_GET,
    'id_catalogo_indicador',
    FILTER_VALIDATE_INT
) ?: 0;
$idServicioSolucion = filter_input(
    INPUT_GET,
    'id_servicio_solucion',
    FILTER_VALIDATE_INT
) ?: 0;

if ($desde !== '' && $hasta !== '' && $desde > $hasta) {
    [$desde, $hasta] = [$hasta, $desde];
}

$diasPeriodoTendencia = null;
if ($desde !== '' && $hasta !== '') {
    $inicioTendencia = new DateTimeImmutable($desde);
    $finTendencia = new DateTimeImmutable($hasta);
    $diasPeriodoTendencia = (int) $inicioTendencia->diff($finTendencia)->days + 1;
}

if ($diasPeriodoTendencia !== null && $diasPeriodoTendencia <= 62) {
    $configuracionTendencia = [
        'formato_clave' => '%Y-%m-%d',
        'formato_etiqueta' => '%d/%m/%Y',
        'nombre' => 'día',
        'descripcion' => 'Vista diaria definida por el periodo general',
    ];
} elseif ($diasPeriodoTendencia === null || $diasPeriodoTendencia <= 1095) {
    $configuracionTendencia = [
        'formato_clave' => '%Y-%m',
        'formato_etiqueta' => '%m/%Y',
        'nombre' => 'mes',
        'descripcion' => 'Vista mensual definida por el periodo general',
    ];
} else {
    $configuracionTendencia = [
        'formato_clave' => '%Y',
        'formato_etiqueta' => '%Y',
        'nombre' => 'año',
        'descripcion' => 'Vista anual definida por el periodo general',
    ];
}

$condiciones = [
    't.id_proceso IS NOT NULL',
    't.id_pais_operacion = ' . $idPaisOperacion,
];
if ($filtroCasosPrueba !== '') {
    $condiciones[] = 't.es_prueba = 0';
}

if ($desde !== '') {
    $condiciones[] = "t.fecha_creacion >= '{$desde} 00:00:00'";
}

if ($hasta !== '') {
    $condiciones[] = "t.fecha_creacion < DATE_ADD('{$hasta}', INTERVAL 1 DAY)";
}

$areasIndicador = [];
$resultadoAreasIndicador = $conn->query(
    "SELECT id_catalogo, nombre, estado
     FROM catalogos
     WHERE id_pais_operacion = {$idPaisOperacion}
     ORDER BY orden ASC, nombre ASC"
);

if ($resultadoAreasIndicador !== false) {
    $areasIndicador = $resultadoAreasIndicador->fetch_all(MYSQLI_ASSOC);
}

$idsAreasIndicador = array_map(
    static fn (array $area): int => (int) $area['id_catalogo'],
    $areasIndicador
);

if (
    $idCatalogoIndicador > 0
    && !in_array($idCatalogoIndicador, $idsAreasIndicador, true)
) {
    $idCatalogoIndicador = 0;
}

$serviciosSolucionFiltro = [];
$resultadoServiciosSolucion = $conn->query(
    "SELECT
        s.id_servicio,
        s.id_catalogo,
        s.estado,
        CONCAT(c.nombre, ' / ', s.nombre) AS nombre
     FROM servicios AS s
     INNER JOIN catalogos AS c
        ON c.id_catalogo = s.id_catalogo
       AND c.id_pais_operacion = s.id_pais_operacion
     WHERE s.id_pais_operacion = {$idPaisOperacion}
     ORDER BY c.orden ASC, c.nombre ASC, s.nombre ASC"
);

if ($resultadoServiciosSolucion !== false) {
    $serviciosSolucionFiltro = $resultadoServiciosSolucion->fetch_all(MYSQLI_ASSOC);
}

$idsServicioSolucion = array_map(
    static fn (array $servicio): int => (int) $servicio['id_servicio'],
    $serviciosSolucionFiltro
);

if (
    $idServicioSolucion > 0
    && !in_array($idServicioSolucion, $idsServicioSolucion, true)
) {
    $idServicioSolucion = 0;
}

$servicioSeleccionado = null;
foreach ($serviciosSolucionFiltro as $servicioFiltro) {
    if ((int) $servicioFiltro['id_servicio'] === $idServicioSolucion) {
        $servicioSeleccionado = $servicioFiltro;
        break;
    }
}
if (
    $servicioSeleccionado !== null
    && $idCatalogoIndicador > 0
    && (int) $servicioSeleccionado['id_catalogo'] !== $idCatalogoIndicador
) {
    $idServicioSolucion = 0;
}

$filtrosEtapa = [];
if ($idCatalogoIndicador > 0) {
    $filtrosEtapa[] = 'te_filtro.id_catalogo = ' . $idCatalogoIndicador;
}
if ($idServicioSolucion > 0) {
    $filtrosEtapa[] = 'te_filtro.id_servicio = ' . $idServicioSolucion;
}

$filtroSolucionServicio = '';
if ($idCatalogoIndicador > 0) {
    $filtroSolucionServicio .= ' AND te.id_catalogo = ' . $idCatalogoIndicador;
}
if ($idServicioSolucion > 0) {
    $filtroSolucionServicio .= ' AND te.id_servicio = ' . $idServicioSolucion;
}

$condicionesTendencia = $condiciones;
if ($filtrosEtapa !== []) {
    $condicionesTendencia[] = "EXISTS (
        SELECT 1
        FROM ticket_etapas AS te_filtro
        WHERE te_filtro.id_ticket = t.id_ticket
          AND " . implode(' AND ', $filtrosEtapa) . "
    )";
}
$whereTicketsTendencia = implode(' AND ', $condicionesTendencia);
$whereTickets = $whereTicketsTendencia;

$condicionesCierre = [
    't.id_proceso IS NOT NULL',
    't.id_pais_operacion = ' . $idPaisOperacion,
    't.fecha_finalizacion IS NOT NULL',
];
if ($filtroCasosPrueba !== '') {
    $condicionesCierre[] = 't.es_prueba = 0';
}
if ($desde !== '') {
    $condicionesCierre[] = "t.fecha_finalizacion >= '{$desde} 00:00:00'";
}
if ($hasta !== '') {
    $condicionesCierre[] = "t.fecha_finalizacion < DATE_ADD('{$hasta}', INTERVAL 1 DAY)";
}
if ($filtrosEtapa !== []) {
    $condicionesCierre[] = "EXISTS (
        SELECT 1
        FROM ticket_etapas AS te_filtro
        WHERE te_filtro.id_ticket = t.id_ticket
          AND " . implode(' AND ', $filtrosEtapa) . "
    )";
}
$whereCierres = implode(' AND ', $condicionesCierre);
$periodo = 'Toda la base histórica';

if ($desde !== '' || $hasta !== '') {
    $periodo = ($desde !== '' ? date('d/m/Y', strtotime($desde)) : 'Inicio')
        . ' — '
        . ($hasta !== '' ? date('d/m/Y', strtotime($hasta)) : 'Hoy');
}

$resumen = [
    'total' => 0,
    'en_proceso' => 0,
    'pendiente_calificacion' => 0,
    'cerrados' => 0,
    'solicitantes' => 0,
    'promedio_ciclo' => null,
];
$resumenEtapas = [
    'etapas' => 0,
    'completadas' => 0,
    'listos_cierre' => 0,
    'pausadas' => 0,
    'derivaciones' => 0,
    'casos_reabiertos' => 0,
    'fuera_sla' => 0,
    'dentro_sla' => 0,
    'evaluadas_sla' => 0,
    'promedio_etapa' => null,
];
$resumenCalificacion = [
    'promedio' => null,
    'promedio_area' => null,
    'promedio_tiempo' => null,
    'calificaciones' => 0,
];
$resumenEncuestaServicio = $resumenCalificacion;
$resumenEvaluacionInterna = $resumenCalificacion;
$resumenGestion = [
    'promedio_primera_respuesta' => null,
    'sin_primera_respuesta' => 0,
    'backlog_activo' => 0,
    'promedio_antiguedad_backlog' => null,
    'pendientes_calificacion_vencidos' => 0,
    'casos_con_derivacion' => 0,
    'promedio_derivaciones' => null,
    'casos_reabiertos' => 0,
    'resueltos_primer_contacto' => 0,
    'cerrados_periodo' => 0,
];
$casosRiesgoSla = 0;
$casosSlaVencidoAhora = 0;
$porEstado = [];
$porTipo = [];
$porTipoCompleto = [];
$porClasificacion = [];
$porProcesoServicio = [];
$porGestor = [];
$porArea = [];
$porServicio = [];
$porSolucionServicio = [];
$comentariosPorSolucion = [];
$tendencia = [];
$tendenciaCompleta = [];
$periodosCreadosRanking = [];
$porUrgencia = [];
$distribucionCalificacionArea = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
$distribucionCalificacionTiempo = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
$detalleTickets = [];
$detalleCalificaciones = [];
$errorDashboard = '';
$moduloDisponible = flujoModuloInstalado($conn)
    && flujoModuloSolucionesInstalado($conn)
    && flujoModuloAprobacionCasosInstalado($conn);

if ($moduloDisponible) {
    try {
        $resumen = array_merge($resumen, filaIndicador(
            $conn,
            "SELECT
                COUNT(*) AS total,
                SUM(t.estado_flujo = 'en_proceso') AS en_proceso,
                SUM(t.estado_flujo = 'pendiente_calificacion') AS pendiente_calificacion,
                SUM(t.estado_flujo = 'cerrado') AS cerrados,
                COUNT(DISTINCT t.id_usuario) AS solicitantes,
                AVG(CASE
                    WHEN t.fecha_finalizacion IS NOT NULL THEN
                        TIMESTAMPDIFF(MINUTE, t.fecha_creacion, t.fecha_finalizacion)
                    ELSE NULL
                END) AS promedio_ciclo
             FROM tickets AS t
             WHERE {$whereTickets}"
        ));

        $resumenEtapas = array_merge($resumenEtapas, filaIndicador(
            $conn,
            "SELECT
                COUNT(*) AS etapas,
                SUM(te.estado IN ('listo_cierre', 'completada')) AS completadas,
                SUM(te.estado = 'listo_cierre') AS listos_cierre,
                SUM(te.estado = 'pausada') AS pausadas,
                SUM(te.id_ticket_etapa_padre IS NOT NULL) AS derivaciones,
                SUM(te.cantidad_reaperturas > 0) AS casos_reabiertos,
                SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) = 'fuera_sla') AS fuera_sla,
                SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) = 'dentro_sla') AS dentro_sla,
                SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) IN ('dentro_sla', 'fuera_sla')) AS evaluadas_sla,
                AVG(CASE
                    WHEN te.estado IN ('listo_cierre', 'completada')
                    THEN COALESCE(te.minutos_hasta_listo, te.minutos_atencion)
                END) AS promedio_etapa
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             WHERE {$whereTickets}"
        ));

        $resumenGestion = array_merge($resumenGestion, filaIndicador(
            $conn,
            "SELECT
                AVG(CASE
                    WHEN primera_respuesta.respondido_en IS NOT NULL
                    THEN TIMESTAMPDIFF(MINUTE, t.fecha_creacion, primera_respuesta.respondido_en)
                END) AS promedio_primera_respuesta,
                SUM(primera_respuesta.respondido_en IS NULL) AS sin_primera_respuesta,
                SUM(t.estado_flujo NOT IN ('cerrado', 'cancelado', 'cancelada')) AS backlog_activo,
                AVG(CASE
                    WHEN t.estado_flujo NOT IN ('cerrado', 'cancelado', 'cancelada')
                    THEN TIMESTAMPDIFF(MINUTE, t.fecha_creacion, NOW())
                END) AS promedio_antiguedad_backlog,
                SUM(
                    t.estado_flujo = 'pendiente_calificacion'
                    AND t.esperando_solicitante_desde IS NOT NULL
                    AND t.esperando_solicitante_desde < DATE_SUB(NOW(), INTERVAL 24 HOUR)
                ) AS pendientes_calificacion_vencidos,
                SUM(COALESCE(ramas.total_derivaciones, 0) > 0) AS casos_con_derivacion,
                AVG(CASE
                    WHEN COALESCE(ramas.total_derivaciones, 0) > 0
                    THEN ramas.total_derivaciones
                END) AS promedio_derivaciones,
                SUM(COALESCE(ramas.total_reaperturas, 0) > 0) AS casos_reabiertos,
                SUM(
                    t.fecha_finalizacion IS NOT NULL
                    AND COALESCE(ramas.total_derivaciones, 0) = 0
                    AND COALESCE(ramas.total_reaperturas, 0) = 0
                ) AS resueltos_primer_contacto
             FROM tickets AS t
             LEFT JOIN (
                SELECT
                    sc.id_ticket,
                    MIN(sc.creado_en) AS respondido_en
                FROM solicitud_comunicaciones AS sc
                INNER JOIN tickets AS ticket_respuesta
                    ON ticket_respuesta.id_ticket = sc.id_ticket
                WHERE sc.tipo = 'publica'
                  AND sc.id_emisor IS NOT NULL
                  AND sc.id_emisor <> ticket_respuesta.id_usuario
                GROUP BY sc.id_ticket
             ) AS primera_respuesta ON primera_respuesta.id_ticket = t.id_ticket
             LEFT JOIN (
                SELECT
                    te_resumen.id_ticket,
                    SUM(te_resumen.id_ticket_etapa_padre IS NOT NULL) AS total_derivaciones,
                    SUM(te_resumen.cantidad_reaperturas) AS total_reaperturas
                FROM ticket_etapas AS te_resumen
                GROUP BY te_resumen.id_ticket
             ) AS ramas ON ramas.id_ticket = t.id_ticket
             WHERE {$whereTickets}"
        ));

        $resumenCierresPeriodo = filaIndicador(
            $conn,
            "SELECT COUNT(*) AS cerrados_periodo
             FROM tickets AS t
             WHERE {$whereCierres}"
        );
        $resumenGestion['cerrados_periodo'] = (int) ($resumenCierresPeriodo['cerrados_periodo'] ?? 0);

        $ticketsRiesgoSla = filasIndicador(
            $conn,
            "SELECT
                t.id_ticket,
                te.estado,
                te.sla_unidad,
                te.sla_minutos_total,
                te.sla_minutos_consumidos,
                te.fecha_activacion,
                te.fecha_ultima_reanudacion
             FROM tickets AS t
             INNER JOIN ticket_etapas AS te
                ON te.id_ticket_etapa = t.id_etapa_actual
             WHERE {$whereTickets}
               AND t.estado_flujo = 'en_proceso'
               AND te.estado IN ('pendiente', 'en_proceso', 'en_espera_solicitante')"
        );
        $idsRiesgoSla = [];
        $idsSlaVencido = [];
        foreach ($ticketsRiesgoSla as $ticketRiesgo) {
            $totalSla = max(0, (int) ($ticketRiesgo['sla_minutos_total'] ?? 0));
            if ($totalSla < 1) {
                continue;
            }

            $consumido = flujoMinutosConsumidosNodo($conn, $ticketRiesgo);
            $idTicketRiesgo = (int) $ticketRiesgo['id_ticket'];
            if ($consumido >= $totalSla) {
                $idsSlaVencido[$idTicketRiesgo] = true;
            } elseif (($consumido / $totalSla) >= 0.8) {
                $idsRiesgoSla[$idTicketRiesgo] = true;
            }
        }
        $casosRiesgoSla = count($idsRiesgoSla);
        $casosSlaVencidoAhora = count($idsSlaVencido);

        $resumenCalificacion = array_merge($resumenCalificacion, filaIndicador(
            $conn,
            "SELECT
                AVG(cal.calificacion) AS promedio,
                AVG(cal.calificacion_area) AS promedio_area,
                AVG(cal.calificacion_tiempo) AS promedio_tiempo,
                COUNT(*) AS calificaciones
             FROM solicitud_calificaciones AS cal
             INNER JOIN tickets AS t ON t.id_ticket = cal.id_ticket
             WHERE {$whereTickets}"
        ));

        $resumenEncuestaServicio = array_merge(
            $resumenEncuestaServicio,
            filaIndicador(
                $conn,
                "SELECT
                    AVG(cal.calificacion) AS promedio,
                    AVG(cal.calificacion_area) AS promedio_area,
                    AVG(cal.calificacion_tiempo) AS promedio_tiempo,
                    COUNT(*) AS calificaciones
                 FROM solicitud_calificaciones AS cal
                 INNER JOIN tickets AS t ON t.id_ticket = cal.id_ticket
                 WHERE {$whereTickets}
                   AND cal.tipo_calificacion = 'encuesta_servicio'"
            )
        );

        $resumenEvaluacionInterna = array_merge(
            $resumenEvaluacionInterna,
            filaIndicador(
                $conn,
                "SELECT
                    AVG(cal.calificacion) AS promedio,
                    AVG(cal.calificacion_area) AS promedio_area,
                    AVG(cal.calificacion_tiempo) AS promedio_tiempo,
                    COUNT(*) AS calificaciones
                 FROM solicitud_calificaciones AS cal
                 INNER JOIN tickets AS t ON t.id_ticket = cal.id_ticket
                 WHERE {$whereTickets}
                   AND cal.tipo_calificacion IN ('evaluacion_derivacion', 'evaluacion_caso')"
            )
        );

        $porEstado = filasIndicador(
            $conn,
            "SELECT t.estado_flujo AS nombre, COUNT(*) AS total
             FROM tickets AS t
             WHERE {$whereTickets}
             GROUP BY t.estado_flujo
             ORDER BY total DESC"
        );

        $ticketsTienenClasificacion = flujoColumnaExiste($conn, 'tickets', 'tipo_solicitud');
        $serviciosTienenClasificacion = flujoColumnaExiste($conn, 'servicios', 'tipo_solicitud');
        if ($serviciosTienenClasificacion && $ticketsTienenClasificacion) {
            /*
             * La clasificación guardada en el caso es la fuente de verdad porque
             * el administrador puede modificarla. El servicio queda como
             * respaldo para registros históricos sin clasificación.
             */
            $fuenteClasificacion = "COALESCE(
                NULLIF(TRIM(t.tipo_solicitud), ''),
                NULLIF(TRIM(s_clasificacion.tipo_solicitud), ''),
                ''
            )";
        } elseif ($serviciosTienenClasificacion) {
            $fuenteClasificacion = "COALESCE(NULLIF(TRIM(s_clasificacion.tipo_solicitud), ''), '')";
        } elseif ($ticketsTienenClasificacion) {
            $fuenteClasificacion = "COALESCE(NULLIF(TRIM(t.tipo_solicitud), ''), '')";
        } else {
            $fuenteClasificacion = "''";
        }
        $expresionClasificacion = "CASE
                WHEN LOWER(TRIM({$fuenteClasificacion})) IN ('incidente', 'incidentes') THEN 'incidente'
                WHEN LOWER(TRIM({$fuenteClasificacion})) IN ('requerimiento', 'requerimientos') THEN 'requerimiento'
                WHEN NULLIF(TRIM({$fuenteClasificacion}), '') IS NULL THEN 'Sin clasificación'
                ELSE LOWER(TRIM({$fuenteClasificacion}))
             END";
        $porClasificacion = filasIndicador(
            $conn,
            "SELECT {$expresionClasificacion} AS nombre, COUNT(*) AS total
             FROM tickets AS t
             LEFT JOIN servicios AS s_clasificacion
                ON s_clasificacion.id_servicio = t.id_servicio
             WHERE {$whereTickets}
             GROUP BY {$expresionClasificacion}
             ORDER BY total DESC, nombre ASC"
        );

        $porTipoCompleto = filasIndicador(
            $conn,
            "SELECT p.nombre, COUNT(*) AS total
             FROM tickets AS t
             INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
             WHERE {$whereTickets}
             GROUP BY p.id_proceso, p.nombre
             ORDER BY total DESC, p.nombre"
        );

        /*
         * Base operativa por proceso configurado en servicios.php.
         * Se parte del catálogo de servicios para conservar también los
         * procesos que todavía no tienen casos dentro del periodo elegido.
         */
        $porProcesoServicio = filasIndicador(
            $conn,
            "SELECT
                COALESCE(NULLIF(TRIM(s.proceso), ''), 'Sin proceso') AS proceso,
                GROUP_CONCAT(
                    DISTINCT COALESCE(
                        NULLIF(TRIM(gestor_configurado.nombre), ''),
                        'Sin gestor'
                    )
                    ORDER BY COALESCE(
                        NULLIF(TRIM(gestor_configurado.nombre), ''),
                        'Sin gestor'
                    )
                    SEPARATOR ', '
                ) AS gestores,
                COUNT(DISTINCT s.id_servicio) AS servicios_configurados,
                COUNT(DISTINCT CASE
                    WHEN s.estado = 'activo' THEN s.id_servicio
                END) AS servicios_activos,
                COUNT(DISTINCT CASE
                    WHEN t.id_ticket IS NOT NULL THEN t.id_ticket
                END) AS tickets,
                COUNT(DISTINCT CASE
                    WHEN t.id_ticket IS NOT NULL THEN te.id_ticket_etapa
                END) AS etapas,
                COUNT(DISTINCT CASE
                    WHEN t.id_ticket IS NOT NULL
                     AND te.estado IN ('listo_cierre', 'completada')
                    THEN te.id_ticket_etapa
                END) AS completadas,
                COUNT(DISTINCT CASE
                    WHEN t.id_ticket IS NOT NULL
                     AND te.estado IN ('pendiente', 'en_proceso', 'en_espera_solicitante')
                    THEN te.id_ticket_etapa
                END) AS activas,
                AVG(CASE
                    WHEN t.id_ticket IS NOT NULL
                     AND te.estado IN ('listo_cierre', 'completada')
                    THEN COALESCE(te.minutos_hasta_listo, te.minutos_atencion)
                END) AS promedio_minutos,
                ROUND(
                    100 * COUNT(DISTINCT CASE
                        WHEN t.id_ticket IS NOT NULL
                         AND COALESCE(te.resultado_sla_listo, te.resultado_sla) = 'dentro_sla'
                        THEN te.id_ticket_etapa
                    END) /
                    NULLIF(COUNT(DISTINCT CASE
                        WHEN t.id_ticket IS NOT NULL
                         AND COALESCE(te.resultado_sla_listo, te.resultado_sla)
                             IN ('dentro_sla', 'fuera_sla')
                        THEN te.id_ticket_etapa
                    END), 0),
                    1
                ) AS cumplimiento_sla,
                AVG(CASE WHEN t.id_ticket IS NOT NULL THEN cal.calificacion END) AS calificacion,
                COUNT(DISTINCT CASE
                    WHEN t.id_ticket IS NOT NULL THEN cal.id_calificacion
                END) AS evaluaciones
             FROM servicios AS s
             INNER JOIN catalogos AS catalogo
                ON catalogo.id_catalogo = s.id_catalogo
               AND catalogo.id_pais_operacion = {$idPaisOperacion}
             LEFT JOIN usuarios AS gestor_configurado
                ON gestor_configurado.id_usuario = s.id_gestor
             LEFT JOIN ticket_etapas AS te
                ON te.id_servicio = s.id_servicio
             LEFT JOIN tickets AS t
                ON t.id_ticket = te.id_ticket
               AND {$whereTickets}
             LEFT JOIN solicitud_calificaciones AS cal
                ON cal.id_ticket_etapa = te.id_ticket_etapa
               AND t.id_ticket IS NOT NULL
             WHERE s.id_pais_operacion = {$idPaisOperacion}
               " . ($idCatalogoIndicador > 0
                    ? " AND s.id_catalogo = {$idCatalogoIndicador}"
                    : '') . "
               " . ($idServicioSolucion > 0
                    ? " AND s.id_servicio = {$idServicioSolucion}"
                    : '') . "
             GROUP BY COALESCE(NULLIF(TRIM(s.proceso), ''), 'Sin proceso')
             ORDER BY
                tickets DESC,
                etapas DESC,
                proceso"
        );

        $porGestor = filasIndicador(
            $conn,
            "SELECT
                COALESCE(NULLIF(gestor.nombre, ''), NULLIF(te.gestor_nombre, ''), 'Sin asignar') AS nombre,
                COUNT(DISTINCT te.id_ticket) AS tickets,
                COUNT(*) AS etapas,
                SUM(te.estado IN ('listo_cierre', 'completada')) AS completadas,
                SUM(te.estado IN ('pendiente', 'en_proceso', 'en_espera_solicitante')) AS activas,
                AVG(CASE WHEN te.estado IN ('listo_cierre', 'completada') THEN COALESCE(te.minutos_hasta_listo, te.minutos_atencion) END) AS promedio_minutos,
                AVG(
                    CASE
                        WHEN primer_contacto.contacto_en IS NOT NULL
                        THEN TIMESTAMPDIFF(MINUTE, t.fecha_creacion, primer_contacto.contacto_en)
                    END
                ) AS promedio_primer_contacto,
                AVG(respuestas.minutos_respuesta) AS promedio_respuesta_mensajes,
                ROUND(
                    100 * SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) = 'dentro_sla') /
                    NULLIF(SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) IN ('dentro_sla', 'fuera_sla')), 0),
                    1
                ) AS cumplimiento_sla,
                AVG(cal.calificacion) AS calificacion,
                AVG(cal.calificacion_area) AS calificacion_area,
                AVG(cal.calificacion_tiempo) AS calificacion_tiempo,
                COUNT(cal.id_calificacion) AS encuestas
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN usuarios AS gestor ON gestor.id_usuario = te.id_gestor
             LEFT JOIN solicitud_calificaciones AS cal
                ON cal.id_ticket_etapa = te.id_ticket_etapa
                         LEFT JOIN (
                                SELECT
                                        sc.id_ticket,
                                        sc.id_ticket_etapa,
                                        MIN(sc.creado_en) AS contacto_en
                                FROM solicitud_comunicaciones AS sc
                                INNER JOIN ticket_etapas AS te_contacto
                                        ON te_contacto.id_ticket_etapa = sc.id_ticket_etapa
                                     AND te_contacto.id_ticket = sc.id_ticket
                                WHERE sc.tipo = 'publica'
                                    AND sc.id_emisor IS NOT NULL
                                    AND sc.id_emisor = te_contacto.id_gestor
                                GROUP BY sc.id_ticket, sc.id_ticket_etapa
                         ) AS primer_contacto
                                ON primer_contacto.id_ticket = te.id_ticket
                             AND primer_contacto.id_ticket_etapa = te.id_ticket_etapa
                         LEFT JOIN (
                                SELECT
                                        respuesta.id_ticket,
                                        respuesta.id_ticket_etapa,
                                    te_respuesta.id_gestor,
                                        AVG(
                                                TIMESTAMPDIFF(
                                                        MINUTE,
                                                        (
                                                                SELECT MAX(anterior.creado_en)
                                                                FROM solicitud_comunicaciones AS anterior
                                                                WHERE anterior.id_ticket = respuesta.id_ticket
                                                                    AND anterior.id_ticket_etapa = respuesta.id_ticket_etapa
                                                                    AND anterior.tipo = 'publica'
                                                                    AND anterior.id_emisor = ticket_respuesta.id_usuario
                                                                    AND anterior.creado_en < respuesta.creado_en
                                                        ),
                                                        respuesta.creado_en
                                                )
                                        ) AS minutos_respuesta
                                FROM solicitud_comunicaciones AS respuesta
                                INNER JOIN ticket_etapas AS te_respuesta
                                        ON te_respuesta.id_ticket_etapa = respuesta.id_ticket_etapa
                                     AND te_respuesta.id_ticket = respuesta.id_ticket
                                INNER JOIN tickets AS ticket_respuesta
                                        ON ticket_respuesta.id_ticket = respuesta.id_ticket
                                WHERE respuesta.tipo = 'publica'
                                    AND respuesta.id_emisor IS NOT NULL
                                    AND respuesta.id_emisor = te_respuesta.id_gestor
                                GROUP BY respuesta.id_ticket, respuesta.id_ticket_etapa, te_respuesta.id_gestor
                         ) AS respuestas
                                ON respuestas.id_ticket = te.id_ticket
                             AND respuestas.id_ticket_etapa = te.id_ticket_etapa
                             AND respuestas.id_gestor = te.id_gestor
             WHERE {$whereTickets}
             GROUP BY COALESCE(NULLIF(gestor.nombre, ''), NULLIF(te.gestor_nombre, ''), 'Sin asignar')
             ORDER BY completadas DESC, etapas DESC, nombre"
        );

        $porArea = filasIndicador(
            $conn,
            "SELECT
                te.catalogo_nombre AS nombre,
                COUNT(DISTINCT te.id_ticket) AS tickets,
                COUNT(*) AS etapas,
                SUM(te.estado IN ('listo_cierre', 'completada')) AS completadas,
                SUM(te.estado IN ('pendiente', 'en_proceso', 'en_espera_solicitante')) AS activas,
                AVG(CASE WHEN te.estado IN ('listo_cierre', 'completada') THEN COALESCE(te.minutos_hasta_listo, te.minutos_atencion) END) AS promedio_minutos,
                ROUND(
                    100 * SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) = 'dentro_sla') /
                    NULLIF(SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) IN ('dentro_sla', 'fuera_sla')), 0),
                    1
                ) AS cumplimiento_sla,
                AVG(cal.calificacion) AS calificacion,
                AVG(cal.calificacion_area) AS calificacion_area,
                AVG(cal.calificacion_tiempo) AS calificacion_tiempo,
                COUNT(cal.id_calificacion) AS encuestas
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN solicitud_calificaciones AS cal
                ON cal.id_ticket_etapa = te.id_ticket_etapa
             WHERE {$whereTickets}
             GROUP BY te.catalogo_nombre
             ORDER BY etapas DESC, te.catalogo_nombre"
        );

        $porServicio = filasIndicador(
            $conn,
            "SELECT
                CONCAT(te.catalogo_nombre, ' / ', te.servicio_nombre) AS nombre,
                COUNT(*) AS etapas,
                SUM(te.estado IN ('listo_cierre', 'completada')) AS completadas,
                AVG(CASE WHEN te.estado IN ('listo_cierre', 'completada') THEN COALESCE(te.minutos_hasta_listo, te.minutos_atencion) END) AS promedio_minutos,
                ROUND(
                    100 * SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) = 'dentro_sla') /
                    NULLIF(SUM(COALESCE(te.resultado_sla_listo, te.resultado_sla) IN ('dentro_sla', 'fuera_sla')), 0),
                    1
                ) AS cumplimiento_sla,
                AVG(cal.calificacion) AS calificacion,
                AVG(cal.calificacion_area) AS calificacion_area,
                AVG(cal.calificacion_tiempo) AS calificacion_tiempo,
                COUNT(cal.id_calificacion) AS encuestas
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN solicitud_calificaciones AS cal
                ON cal.id_ticket_etapa = te.id_ticket_etapa
             WHERE {$whereTickets}
             GROUP BY te.catalogo_nombre, te.servicio_nombre
             ORDER BY etapas DESC, nombre
             LIMIT 15"
        );

        $porSolucionServicio = filasIndicador(
            $conn,
            "SELECT
                te.id_servicio,
                CONCAT(te.catalogo_nombre, ' / ', te.servicio_nombre) AS servicio,
                COALESCE(
                    NULLIF(te.solucion_nombre, ''),
                    'Cierre anterior sin clasificación'
                ) AS solucion,
                COUNT(*) AS total,
                MAX(COALESCE(te.fecha_marcado_listo, te.fecha_finalizacion)) AS ultimo_uso
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             WHERE {$whereTickets}
               AND te.estado IN ('listo_cierre', 'completada')
               AND (
                    NULLIF(te.solucion_nombre, '') IS NOT NULL
                    OR NULLIF(te.comentario_cierre, '') IS NOT NULL
               )
               {$filtroSolucionServicio}
             GROUP BY
                te.id_servicio,
                te.catalogo_nombre,
                te.servicio_nombre,
                COALESCE(
                    NULLIF(te.solucion_nombre, ''),
                    'Cierre anterior sin clasificación'
                )
             ORDER BY servicio, total DESC, solucion"
        );

        $comentariosSoluciones = filasIndicador(
            $conn,
            "SELECT
                te.id_servicio,
                te.id_ticket,
                te.id_ticket_etapa,
                COALESCE(
                    NULLIF(te.solucion_nombre, ''),
                    'Cierre anterior sin clasificación'
                ) AS solucion,
                te.comentario_cierre AS comentario,
                COALESCE(
                    NULLIF(gestor.nombre, ''),
                    NULLIF(te.gestor_nombre, ''),
                    'Sin gestor registrado'
                ) AS gestor,
                COALESCE(te.fecha_marcado_listo, te.fecha_finalizacion) AS fecha_registro
             FROM ticket_etapas AS te
             INNER JOIN tickets AS t ON t.id_ticket = te.id_ticket
             LEFT JOIN usuarios AS gestor ON gestor.id_usuario = te.id_gestor
             WHERE {$whereTickets}
               AND te.estado IN ('listo_cierre', 'completada')
               AND NULLIF(TRIM(te.comentario_cierre), '') IS NOT NULL
               {$filtroSolucionServicio}
             ORDER BY
                te.id_servicio,
                solucion,
                fecha_registro DESC,
                te.id_ticket DESC"
        );

        foreach ($comentariosSoluciones as $comentarioSolucion) {
            $comentarioSolucion['codigo_caso'] = flujoCodigoCaso(
                $conn,
                (int) $comentarioSolucion['id_ticket'],
                (int) $comentarioSolucion['id_ticket_etapa']
            );
            $claveComentarios = (string) $comentarioSolucion['id_servicio']
                . '|'
                . (string) $comentarioSolucion['solucion'];
            $comentariosPorSolucion[$claveComentarios][] = $comentarioSolucion;
        }

        $tendenciaCompleta = filasIndicador(
            $conn,
            "SELECT
                DATE_FORMAT(t.fecha_creacion, '{$configuracionTendencia['formato_clave']}') AS clave,
                DATE_FORMAT(t.fecha_creacion, '{$configuracionTendencia['formato_etiqueta']}') AS etiqueta,
                COUNT(*) AS creados,
                SUM(t.fecha_finalizacion IS NOT NULL) AS finalizados
             FROM tickets AS t
             WHERE {$whereTicketsTendencia}
             GROUP BY clave, etiqueta
             ORDER BY clave"
        );
        $tendencia = $tendenciaCompleta;
        $periodosCreadosRanking = $tendenciaCompleta;
        usort(
            $periodosCreadosRanking,
            static fn (array $a, array $b): int => (int) $b['creados'] <=> (int) $a['creados']
        );
        $periodosCreadosRanking = array_slice($periodosCreadosRanking, 0, 10);

        $porUrgencia = filasIndicador(
            $conn,
            "SELECT t.urgencia AS nombre, COUNT(*) AS total
             FROM tickets AS t
             WHERE {$whereTickets}
             GROUP BY t.urgencia
             ORDER BY FIELD(
                LOWER(t.urgencia),
                'inmediato', 'urgente', 'pronto', 'alta',
                'moderada', 'media', 'más tarde', 'mas tarde', 'baja'
             )"
        );

        foreach (filasIndicador(
            $conn,
            "SELECT cal.calificacion_area AS calificacion, COUNT(*) AS total
             FROM solicitud_calificaciones AS cal
             INNER JOIN tickets AS t ON t.id_ticket = cal.id_ticket
             WHERE {$whereTickets}
               AND cal.calificacion_area IS NOT NULL
             GROUP BY cal.calificacion_area"
        ) as $fila) {
            $valor = (int) $fila['calificacion'];
            if (isset($distribucionCalificacionArea[$valor])) {
                $distribucionCalificacionArea[$valor] = (int) $fila['total'];
            }
        }

        foreach (filasIndicador(
            $conn,
            "SELECT cal.calificacion_tiempo AS calificacion, COUNT(*) AS total
             FROM solicitud_calificaciones AS cal
             INNER JOIN tickets AS t ON t.id_ticket = cal.id_ticket
             WHERE {$whereTickets}
               AND cal.calificacion_tiempo IS NOT NULL
             GROUP BY cal.calificacion_tiempo"
        ) as $fila) {
            $valor = (int) $fila['calificacion'];
            if (isset($distribucionCalificacionTiempo[$valor])) {
                $distribucionCalificacionTiempo[$valor] = (int) $fila['total'];
            }
        }

        $detalleTickets = filasIndicador(
            $conn,
            "SELECT
                t.id_ticket,
                p.nombre AS tipo_ticket,
                {$expresionClasificacion} AS clasificacion,
                COALESCE(solicitante.nombre, 'Usuario eliminado') AS solicitante,
                t.estado_flujo,
                t.fecha_creacion,
                COALESCE(te.catalogo_nombre, 'Sin etapa activa') AS area_actual,
                COALESCE(NULLIF(gestor.nombre, ''), NULLIF(te.gestor_nombre, ''), 'Sin gestor activo') AS gestor_actual,
                COALESCE(avance.total_etapas, 0) AS total_etapas,
                COALESCE(avance.completadas, 0) AS etapas_completadas,
                avance.cumplimiento_sla,
                cal.promedio_calificacion,
                cal.promedio_area,
                cal.promedio_tiempo
             FROM tickets AS t
             INNER JOIN procesos AS p ON p.id_proceso = t.id_proceso
             LEFT JOIN servicios AS s_clasificacion
                ON s_clasificacion.id_servicio = t.id_servicio
             LEFT JOIN usuarios AS solicitante ON solicitante.id_usuario = t.id_usuario
             LEFT JOIN ticket_etapas AS te ON te.id_ticket_etapa = t.id_etapa_actual
             LEFT JOIN usuarios AS gestor ON gestor.id_usuario = te.id_gestor
             LEFT JOIN (
                SELECT
                    id_ticket,
                    COUNT(*) AS total_etapas,
                    SUM(estado = 'completada') AS completadas,
                    ROUND(
                        100 * SUM(COALESCE(resultado_sla_listo, resultado_sla) = 'dentro_sla') /
                        NULLIF(SUM(COALESCE(resultado_sla_listo, resultado_sla) IN ('dentro_sla', 'fuera_sla')), 0),
                        1
                    ) AS cumplimiento_sla
                FROM ticket_etapas
                GROUP BY id_ticket
             ) AS avance ON avance.id_ticket = t.id_ticket
             LEFT JOIN (
                SELECT
                    id_ticket,
                    AVG(calificacion) AS promedio_calificacion,
                    AVG(calificacion_area) AS promedio_area,
                    AVG(calificacion_tiempo) AS promedio_tiempo
                FROM solicitud_calificaciones
                GROUP BY id_ticket
             ) AS cal ON cal.id_ticket = t.id_ticket
             WHERE {$whereTickets}
             ORDER BY t.actualizado_en DESC, t.id_ticket DESC"
        );

        $detalleCalificaciones = filasIndicador(
            $conn,
            "SELECT
                t.id_ticket,
                te.id_ticket_etapa,
                te.catalogo_nombre,
                te.servicio_nombre,
                COALESCE(NULLIF(gestor.nombre, ''), NULLIF(te.gestor_nombre, ''), 'Sin asignar') AS gestor,
                COALESCE(evaluador.nombre, 'Usuario eliminado') AS evaluador,
                te.sla_nombre,
                COALESCE(te.minutos_hasta_listo, te.minutos_atencion) AS minutos_atencion,
                COALESCE(te.resultado_sla_listo, te.resultado_sla) AS resultado_sla,
                cal.calificacion,
                cal.calificacion_area,
                cal.calificacion_tiempo,
                cal.tipo_calificacion,
                cal.comentario,
                cal.creado_en
             FROM solicitud_calificaciones AS cal
             INNER JOIN tickets AS t ON t.id_ticket = cal.id_ticket
             INNER JOIN ticket_etapas AS te
                ON te.id_ticket_etapa = cal.id_ticket_etapa
             LEFT JOIN usuarios AS gestor ON gestor.id_usuario = te.id_gestor
             LEFT JOIN usuarios AS evaluador
                ON evaluador.id_usuario = cal.id_solicitante
             WHERE {$whereTickets}
             ORDER BY cal.creado_en DESC, t.id_ticket DESC, te.orden"
        );

        foreach ($detalleCalificaciones as &$evaluacion) {
            $evaluacion['codigo_caso'] = flujoCodigoCaso(
                $conn,
                (int) $evaluacion['id_ticket'],
                (int) $evaluacion['id_ticket_etapa']
            );
        }
        unset($evaluacion);
    } catch (Throwable $e) {
        error_log('Indicadores: ' . $e->getMessage());
        $errorDashboard = 'No fue posible cargar todos los indicadores. Verifique la estructura del módulo de Tickets.';
    }
}

$totalesSolucionPorServicio = [];
foreach ($porSolucionServicio as $filaSolucion) {
    $claveServicio = (string) $filaSolucion['id_servicio'];
    $totalesSolucionPorServicio[$claveServicio] =
        ($totalesSolucionPorServicio[$claveServicio] ?? 0)
        + (int) $filaSolucion['total'];
}

foreach ($porSolucionServicio as &$filaSolucion) {
    $claveServicio = (string) $filaSolucion['id_servicio'];
    $filaSolucion['clave_comentarios'] = $claveServicio
        . '|'
        . (string) $filaSolucion['solucion'];
    $totalServicio = (int) ($totalesSolucionPorServicio[$claveServicio] ?? 0);
    $filaSolucion['porcentaje'] = $totalServicio > 0
        ? round(100 * (int) $filaSolucion['total'] / $totalServicio, 1)
        : 0;
}
unset($filaSolucion);

$totalTicketsGestion = max(0, (int) ($resumen['total'] ?? 0));
$cerradosCohorte = max(0, (int) ($resumen['cerrados'] ?? 0));
$respondidosGestion = max(
    0,
    $totalTicketsGestion - (int) ($resumenGestion['sin_primera_respuesta'] ?? 0)
);
$tasaPrimeraRespuesta = $totalTicketsGestion > 0
    ? round(100 * $respondidosGestion / $totalTicketsGestion, 1)
    : null;
$tasaResolucionPrimerContacto = $cerradosCohorte > 0
    ? round(100 * (int) ($resumenGestion['resueltos_primer_contacto'] ?? 0) / $cerradosCohorte, 1)
    : null;
$tasaReapertura = $totalTicketsGestion > 0
    ? round(100 * (int) ($resumenGestion['casos_reabiertos'] ?? 0) / $totalTicketsGestion, 1)
    : null;
$tasaDerivacion = $totalTicketsGestion > 0
    ? round(100 * (int) ($resumenGestion['casos_con_derivacion'] ?? 0) / $totalTicketsGestion, 1)
    : null;
$balancePeriodo = (int) ($resumenGestion['cerrados_periodo'] ?? 0) - $totalTicketsGestion;
$balancePeriodoTexto = ($balancePeriodo > 0 ? '+' : '') . numeroIndicador($balancePeriodo);
$balancePeriodoClase = $balancePeriodo >= 0 ? 'positive' : 'negative';

$evaluadasSla = (int) ($resumenEtapas['evaluadas_sla'] ?? 0);
$cumplimientoSla = $evaluadasSla > 0
    ? round(100 * (int) $resumenEtapas['dentro_sla'] / $evaluadasSla, 1)
    : null;
$promedioCalificacion = $resumenCalificacion['promedio'] !== null
    ? round((float) $resumenCalificacion['promedio'], 2)
    : null;
$promedioCalificacionArea = $resumenCalificacion['promedio_area'] !== null
    ? round((float) $resumenCalificacion['promedio_area'], 2)
    : null;
$promedioCalificacionTiempo = $resumenCalificacion['promedio_tiempo'] !== null
    ? round((float) $resumenCalificacion['promedio_tiempo'], 2)
    : null;
$promedioEncuestaServicio = $resumenEncuestaServicio['promedio'] !== null
    ? round((float) $resumenEncuestaServicio['promedio'], 2)
    : null;
$promedioEvaluacionInterna = $resumenEvaluacionInterna['promedio'] !== null
    ? round((float) $resumenEvaluacionInterna['promedio'], 2)
    : null;
$porcentajeCalificacionArea = $promedioCalificacionArea !== null
    ? min(100, max(0, $promedioCalificacionArea / 5 * 100))
    : 0;
$porcentajeCalificacionTiempo = $promedioCalificacionTiempo !== null
    ? min(100, max(0, $promedioCalificacionTiempo / 5 * 100))
    : 0;

/* La calificación de gestión del proceso (1 a 5) se normaliza a porcentaje. */
$calificacionesPorProceso = [];
foreach ($porArea as $filaProcesoCalificacion) {
    $valorCalificacion = $filaProcesoCalificacion['calificacion_area'] ?? null;
    $cumplimientoCalificacion = ($valorCalificacion === null || $valorCalificacion === '')
        ? null
        : round(min(5, max(0, (float) $valorCalificacion)) / 5 * 100, 1);
    $calificacionesPorProceso[] = [
        'nombre' => (string) ($filaProcesoCalificacion['nombre'] ?? 'Sin proceso'),
        'cumplimiento' => $cumplimientoCalificacion,
        'calificacion' => $valorCalificacion === null || $valorCalificacion === ''
            ? null
            : round((float) $valorCalificacion, 2),
        'evaluaciones' => (int) ($filaProcesoCalificacion['encuestas'] ?? 0),
    ];
}
usort($calificacionesPorProceso, static function (array $a, array $b): int {
    $cumplimientoA = $a['cumplimiento'] === null ? -1 : (float) $a['cumplimiento'];
    $cumplimientoB = $b['cumplimiento'] === null ? -1 : (float) $b['cumplimiento'];
    if ($cumplimientoA === $cumplimientoB) {
        return strnatcasecmp((string) $a['nombre'], (string) $b['nombre']);
    }
    return $cumplimientoB <=> $cumplimientoA;
});
$procesosCalificados = array_values(array_filter(
    $calificacionesPorProceso,
    static fn (array $fila): bool => $fila['cumplimiento'] !== null
));
$metaCalificacionProceso = 90.0;
$procesosCumplenCalificacion = count(array_filter(
    $procesosCalificados,
    static fn (array $fila): bool => (float) $fila['cumplimiento'] >= $metaCalificacionProceso
));
$procesosNoCumplenCalificacion = max(0, count($procesosCalificados) - $procesosCumplenCalificacion);
$promedioCumplimientoProcesos = $procesosCalificados
    ? round(array_sum(array_column($procesosCalificados, 'cumplimiento')) / count($procesosCalificados), 1)
    : null;
/*
 * Una dona con decenas de segmentos pierde legibilidad. Se conservan todos
 * los datos para el total, pero visualmente se muestran hasta diez porciones:
 * los nueve procesos con mayor demanda y el resto agrupado en "Otros".
 */
$cantidadTiposTotal = count($porTipoCompleto);
$cantidadTiposAgrupados = 0;
$porTipo = $porTipoCompleto;
if ($cantidadTiposTotal > 10) {
    $porTipo = array_slice($porTipoCompleto, 0, 9);
    $tiposRestantes = array_slice($porTipoCompleto, 9);
    $cantidadTiposAgrupados = count($tiposRestantes);
    $porTipo[] = [
        'nombre' => 'Otros servicios (' . $cantidadTiposAgrupados . ')',
        'total' => array_sum(array_map(
            static fn (array $fila): int => (int) $fila['total'],
            $tiposRestantes
        )),
        'es_otros' => 1,
    ];
}

$maxEstado = max(array_merge([0], array_map(static fn (array $fila): int => (int) $fila['total'], $porEstado)));
$maxTipo = max(array_merge([0], array_map(static fn (array $fila): int => (int) $fila['total'], $porTipo)));
$maxClasificacion = max(array_merge([0], array_map(static fn (array $fila): int => (int) $fila['total'], $porClasificacion)));
$maxGestor = max(array_merge([0], array_map(static fn (array $fila): int => (int) $fila['completadas'], $porGestor)));
$maxArea = max(array_merge([0], array_map(static fn (array $fila): int => (int) $fila['etapas'], $porArea)));
$maxGestorVolumen = max(array_merge([0], array_map(static fn (array $fila): int => max((int) $fila['etapas'], (int) $fila['completadas'], (int) $fila['activas']), $porGestor)));
$maxAreaVolumen = max(array_merge([0], array_map(static fn (array $fila): int => max((int) $fila['etapas'], (int) $fila['completadas'], (int) $fila['activas']), $porArea)));
$maxServicio = max(array_merge([0], array_map(static fn (array $fila): int => max((int) $fila['etapas'], (int) $fila['completadas']), $porServicio)));
$maxSolucion = max(array_merge([0], array_map(static fn (array $fila): int => (int) $fila['total'], $porSolucionServicio)));
$maxUrgencia = max(array_merge([0], array_map(static fn (array $fila): int => (int) $fila['total'], $porUrgencia)));
$maxCalificacionDimension = max(array_merge(
    [0],
    array_values($distribucionCalificacionArea),
    array_values($distribucionCalificacionTiempo)
));
$maxTendencia = max(array_merge(
    [0],
    array_map(
        static fn (array $fila): int => max((int) $fila['creados'], (int) $fila['finalizados']),
        $tendencia
    )
));
$maxPeriodosCreados = max(array_merge(
    [0],
    array_map(static fn (array $fila): int => (int) $fila['creados'], $periodosCreadosRanking)
));
$totalEstado = array_sum(array_map(static fn (array $fila): int => (int) $fila['total'], $porEstado));
$totalUrgencia = array_sum(array_map(static fn (array $fila): int => (int) $fila['total'], $porUrgencia));
$totalTipo = array_sum(array_map(static fn (array $fila): int => (int) $fila['total'], $porTipoCompleto));
$totalClasificacion = array_sum(array_map(static fn (array $fila): int => (int) $fila['total'], $porClasificacion));
$totalGestorAtendido = array_sum(array_map(static fn (array $fila): int => (int) $fila['completadas'], $porGestor));
$totalArea = array_sum(array_map(static fn (array $fila): int => (int) $fila['etapas'], $porArea));
$totalTendenciaCreados = array_sum(array_map(static fn (array $fila): int => (int) $fila['creados'], $tendenciaCompleta));
$totalTendenciaFinalizados = array_sum(array_map(static fn (array $fila): int => (int) $fila['finalizados'], $tendenciaCompleta));

/* Coordenadas normalizadas para la gráfica lineal de evolución. */
$tendenciaGraficaPuntos = [];
$tendenciaGraficaCreados = [];
$tendenciaGraficaFinalizados = [];
$tendenciaGraficaAncho = 1000;
$tendenciaGraficaBase = 174;
$tendenciaGraficaAlto = 146;
$tendenciaGraficaMargen = 18;
$cantidadPuntosTendencia = count($tendencia);

foreach ($tendencia as $indiceTendencia => $periodoTendencia) {
    $proporcionX = $cantidadPuntosTendencia > 1
        ? $indiceTendencia / ($cantidadPuntosTendencia - 1)
        : 0.5;
    $x = $tendenciaGraficaMargen
        + ($tendenciaGraficaAncho - (2 * $tendenciaGraficaMargen)) * $proporcionX;
    $creados = (int) ($periodoTendencia['creados'] ?? 0);
    $finalizados = (int) ($periodoTendencia['finalizados'] ?? 0);
    $yCreados = $maxTendencia > 0
        ? $tendenciaGraficaBase - ($tendenciaGraficaAlto * $creados / $maxTendencia)
        : $tendenciaGraficaBase;
    $yFinalizados = $maxTendencia > 0
        ? $tendenciaGraficaBase - ($tendenciaGraficaAlto * $finalizados / $maxTendencia)
        : $tendenciaGraficaBase;
    $tendenciaGraficaPuntos[] = [
        'x' => round($x, 2),
        'creados' => $creados,
        'finalizados' => $finalizados,
        'y_creados' => round($yCreados, 2),
        'y_finalizados' => round($yFinalizados, 2),
        'etiqueta' => (string) ($periodoTendencia['etiqueta'] ?? ''),
    ];
    $tendenciaGraficaCreados[] = round($x, 2) . ',' . round($yCreados, 2);
    $tendenciaGraficaFinalizados[] = round($x, 2) . ',' . round($yFinalizados, 2);
}
$tendenciaGraficaLineaCreados = implode(' ', $tendenciaGraficaCreados);
$tendenciaGraficaLineaFinalizados = implode(' ', $tendenciaGraficaFinalizados);
$tendenciaGraficaPrimero = $tendenciaGraficaPuntos[0] ?? null;
$tendenciaGraficaUltimo = $tendenciaGraficaPuntos[count($tendenciaGraficaPuntos) - 1] ?? null;
$tendenciaGraficaAreaCreados = $tendenciaGraficaLineaCreados !== ''
    ? $tendenciaGraficaLineaCreados . ' '
        . $tendenciaGraficaUltimo['x'] . ',' . $tendenciaGraficaBase . ' '
        . $tendenciaGraficaPrimero['x'] . ',' . $tendenciaGraficaBase
    : '';

/** Construye un gradiente de dona sin dependencias JavaScript externas. */
function gradienteDonaIndicador(array $valores, array $colores): string
{
    $total = array_sum(array_map('intval', $valores));
    if ($total <= 0) {
        return '#e8eef5 0 100%';
    }

    $segmentos = [];
    $inicio = 0.0;
    foreach (array_values($valores) as $indice => $valor) {
        $valor = max(0, (int) $valor);
        if ($valor === 0) {
            continue;
        }
        $fin = $inicio + (100 * $valor / $total);
        $color = $colores[$indice % count($colores)];
        $segmentos[] = $color . ' ' . number_format($inicio, 3, '.', '') . '% ' . number_format($fin, 3, '.', '') . '%';
        $inicio = $fin;
    }
    return implode(', ', $segmentos);
}

$coloresEstado = ['#1976d2','#12a594','#f2a51a','#e25353','#7656d8','#78909c','#26a69a','#5c6bc0'];
$coloresUrgencia = ['#e25353','#f2a51a','#2d8de0','#12a594','#7656d8','#78909c'];
$coloresTipo = ['#1976d2','#12a594','#f2a51a','#7656d8','#e25353','#26a69a','#5c6bc0','#ec6e9b','#78909c','#8d6e63'];
$coloresCalificacion = ['#12a594','#71b96b','#f2c94c','#f2994a','#e25353'];
$gradienteEstado = gradienteDonaIndicador(array_column($porEstado, 'total'), $coloresEstado);
$gradienteUrgencia = gradienteDonaIndicador(array_column($porUrgencia, 'total'), $coloresUrgencia);
$gradienteTipo = gradienteDonaIndicador(array_column($porTipo, 'total'), $coloresTipo);
$gradienteCalificacionArea = gradienteDonaIndicador(array_values(array_reverse($distribucionCalificacionArea, true)), $coloresCalificacion);
$gradienteCalificacionTiempo = gradienteDonaIndicador(array_values(array_reverse($distribucionCalificacionTiempo, true)), $coloresCalificacion);
$totalCalificacionArea = array_sum($distribucionCalificacionArea);
$totalCalificacionTiempo = array_sum($distribucionCalificacionTiempo);
$parametrosDashboardExcel = array_filter(
    [
        'desde' => $desde,
        'hasta' => $hasta,
        'id_catalogo_indicador' => $idCatalogoIndicador > 0 ? $idCatalogoIndicador : null,
        'id_servicio_solucion' => $idServicioSolucion > 0 ? $idServicioSolucion : null,
    ],
    static fn ($valor): bool => $valor !== null && $valor !== ''
);
$urlDashboardExcel = 'descargarIndicadoresExcel.php'
    . ($parametrosDashboardExcel
        ? '?' . http_build_query($parametrosDashboardExcel, '', '&', PHP_QUERY_RFC3986)
        : '');

/* El exportador Excel reutiliza exactamente las mismas consultas y métricas
   sin construir la interfaz HTML del panel. */
if (defined('MESA_INDICADORES_SOLO_DATOS')) {
    return;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indicadores | SMARTDESK</title>
    <style>
        :root{--primary:#0f6fec;--navy:#102a43;--text:#243b53;--muted:#6b7f93;--border:#dce6f0;--bg:#f3f6fb;--surface:#fff;--green:#0f8b72;--amber:#c77a08;--red:#c2413b;--purple:#7554d8}
        *{box-sizing:border-box}body{min-height:100vh;margin:0;color:var(--text);background:var(--bg);font:12px/1.4 Inter,"Segoe UI",Arial,sans-serif}.shell{width:min(1440px,calc(100% - 22px));margin:auto;padding:10px 0 28px}.topbar,.filter,.card,.kpi{border:1px solid var(--border);background:var(--surface);box-shadow:0 5px 18px rgba(16,42,67,.045)}.topbar{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:56px;padding:8px 12px 8px 15px;border-radius:12px}.title-wrap{display:flex;align-items:center;gap:10px}.mark{width:34px;height:34px;display:grid;place-items:center;border-radius:9px;color:#fff;background:linear-gradient(145deg,#0f79f1,#0b4fae);font-size:10px;font-weight:850}.topbar h1{margin:0;color:var(--navy);font-size:17px}.topbar p{margin:1px 0 0;color:var(--muted);font-size:10px}.actions{display:flex;gap:6px;flex-wrap:wrap}.btn,button{min-height:31px;display:inline-flex;align-items:center;justify-content:center;padding:6px 10px;border:1px solid #d8e5f2;border-radius:8px;color:#24577f;background:#f7fbff;text-decoration:none;font:inherit;font-weight:750;cursor:pointer}.btn.primary,button.primary{border-color:var(--primary);color:#fff;background:var(--primary)}.filter{display:flex;align-items:flex-end;gap:8px;margin-top:8px;padding:9px 12px;border-radius:11px}.filter-title{margin-right:auto}.filter-title strong{display:block;color:var(--navy);font-size:12px}.filter-title span{color:var(--muted);font-size:9.5px}.field label{display:block;margin-bottom:3px;color:#667d92;font-size:9px;font-weight:800;text-transform:uppercase}.field input,.field select{width:160px;height:31px;padding:5px 8px;border:1px solid #cfdae6;border-radius:7px;color:var(--text);background:#fff;font:inherit}.field select{width:270px}.alert{margin-top:8px;padding:10px 12px;border-radius:9px;color:#9b4c12;background:#fff5e9}.kpis{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:7px;margin-top:8px}.kpi{min-height:82px;padding:10px 11px;border-radius:11px}.kpi span{display:block;color:var(--muted);font-size:9.5px;font-weight:750}.kpi strong{display:block;margin-top:5px;color:var(--navy);font-size:20px;line-height:1}.kpi small{display:block;margin-top:5px;color:#8293a4;font-size:9px}.dashboard{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:8px;margin-top:8px}.card{grid-column:span 6;overflow:hidden;border-radius:11px}.card.wide{grid-column:span 12}.card.third{grid-column:span 4}.card-head{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:43px;padding:8px 11px;border-bottom:1px solid var(--border)}.card-head h2{margin:0;color:var(--navy);font-size:12.5px}.card-head span{color:var(--muted);font-size:9px}.card-body{padding:11px}.chart-list{display:grid;gap:8px}.chart-row{display:grid;grid-template-columns:minmax(105px,1.1fr) minmax(150px,2fr) auto;align-items:center;gap:8px}.chart-label{overflow:hidden;color:#405b73;font-size:10px;font-weight:650;text-overflow:ellipsis;white-space:nowrap}.track{height:8px;overflow:hidden;border-radius:999px;background:#edf2f7}.bar{height:100%;min-width:0;border-radius:inherit;background:linear-gradient(90deg,var(--primary),#43a0f2)}.bar.green{background:linear-gradient(90deg,#0f8b72,#38b99e)}.bar.purple{background:linear-gradient(90deg,#6b4fd3,#9b83ec)}.bar.amber{background:linear-gradient(90deg,#d18512,#f2b44c)}.chart-value{min-width:34px;text-align:right;color:var(--navy);font-size:9.5px;font-weight:800}.rings{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;align-items:center}.ring-wrap{text-align:center}.ring{--value:0;width:100px;height:100px;display:grid;place-items:center;margin:auto;border-radius:50%;background:conic-gradient(var(--green) calc(var(--value)*1%),#e8eef4 0)}.ring.rating{background:conic-gradient(var(--purple) calc(var(--value)*1%),#e8eef4 0)}.ring.time{background:conic-gradient(var(--amber) calc(var(--value)*1%),#e8eef4 0)}.ring::after{content:"";grid-area:1/1;width:70px;height:70px;border-radius:50%;background:#fff}.ring strong{z-index:1;grid-area:1/1;color:var(--navy);font-size:16px}.ring-wrap span{display:block;margin-top:7px;color:var(--muted);font-size:9.5px}.trend{display:flex;align-items:flex-end;gap:7px;height:175px;padding-top:10px;overflow-x:auto}.trend-item{min-width:55px;flex:1;text-align:center}.trend-bars{height:135px;display:flex;align-items:flex-end;justify-content:center;gap:3px;border-bottom:1px solid #dce5ee}.trend-bar{width:13px;min-height:0;border-radius:4px 4px 0 0;background:#2b86e5}.trend-bar.closed{background:#27a785}.trend-item small{display:block;margin-top:5px;color:#788b9d;font-size:9px}.legend{display:flex;gap:12px;color:var(--muted);font-size:9px}.legend i{display:inline-block;width:7px;height:7px;margin-right:4px;border-radius:2px;background:#2b86e5}.legend i.closed{background:#27a785}.table-wrap{max-width:100%;overflow:auto}.table-wrap.tall{max-height:480px}table{width:100%;border-collapse:collapse;min-width:820px}th{position:sticky;top:0;z-index:1;padding:7px 9px;text-align:left;color:#687e92;background:#f7f9fc;border-bottom:1px solid var(--border);font-size:9px;font-weight:850;text-transform:uppercase}td{padding:7px 9px;border-bottom:1px solid #edf2f6;color:#3d5a73;font-size:9.5px}tbody tr:hover{background:#f7fbff}.name{color:var(--navy);font-weight:750}.badge{display:inline-flex;padding:3px 6px;border-radius:999px;font-size:9px;font-weight:800;white-space:nowrap}.badge.blue{color:#1767b5;background:#eaf4ff}.badge.green{color:#087443;background:#eaf8f1}.badge.amber{color:#946000;background:#fff4d3}.badge.red{color:#a83b32;background:#fff0ee}.badge.gray{color:#647789;background:#eef2f6}.ticket{color:#0d62c7;font-weight:850;text-decoration:none}.stars{color:#d58b0a;font-weight:850}.progress{display:flex;align-items:center;gap:6px}.progress .track{width:70px;height:6px}.dimension-bars{display:grid;gap:3px;min-width:150px}.dimension-line{display:grid;grid-template-columns:42px 1fr 24px;gap:5px;align-items:center;font-size:9px}.dimension-line .area{color:var(--purple)}.dimension-line .time{color:var(--amber)}.comment-detail summary{cursor:pointer;color:#1767b5;font-size:9px;font-weight:750}.comment-detail p{max-width:340px;margin:5px 0 0;white-space:pre-wrap}.empty{padding:24px;text-align:center;color:var(--muted)}@media(max-width:1180px){.kpis{grid-template-columns:repeat(4,1fr)}.card.third{grid-column:span 6}}@media(max-width:760px){.shell{width:calc(100% - 12px);padding-top:6px}.topbar,.filter{align-items:flex-start;flex-direction:column}.actions{width:100%}.actions .btn{flex:1}.filter-title{margin:0}.filter{display:grid;grid-template-columns:1fr 1fr}.filter-title{grid-column:1/-1}.field input,.field select{width:100%}.kpis{grid-template-columns:repeat(2,1fr)}.card,.card.third{grid-column:span 12}.chart-row{grid-template-columns:100px minmax(100px,1fr) auto}.rings{grid-template-columns:1fr}.ring{width:105px;height:105px}.ring::after{width:73px;height:73px}}@media print{body{background:#fff}.shell{width:100%;padding:0}.actions,.filter{display:none}.topbar,.card,.kpi{box-shadow:none}.table-wrap.tall{max-height:none;overflow:visible}.card{break-inside:avoid}}
        /* Las visualizaciones se ordenan siempre en parejas en escritorio. */
        .card.third{grid-column:span 6}
        /* Presentación compacta para mostrar más indicadores sin perder legibilidad. */
        body{font-size:11.5px;line-height:1.35;background:linear-gradient(180deg,#eef4fb 0,#f6f8fb 260px,#f3f6fb 100%)}
        .shell{width:min(1580px,calc(100% - 16px));padding:8px 0 24px}
        .topbar{min-height:54px;padding:7px 11px;border-radius:11px;box-shadow:0 6px 18px rgba(16,42,67,.06)}
        .mark{width:34px;height:34px;border-radius:9px;font-size:10px;box-shadow:0 5px 12px rgba(15,111,236,.18)}
        .topbar h1{font-size:17px;letter-spacing:-.15px}.topbar p{margin-top:1px;font-size:9.5px}
        .btn,button{min-height:30px;padding:5px 10px;border-radius:7px;transition:border-color .2s ease,box-shadow .2s ease,transform .2s ease}
        .btn:hover,button:hover{border-color:#9fc6ee;box-shadow:0 4px 10px rgba(15,111,236,.1);transform:translateY(-1px)}
        .filter{gap:7px;margin-top:7px;padding:8px 11px;border-radius:10px;box-shadow:0 5px 15px rgba(16,42,67,.045);flex-wrap:wrap}
        .filter-title{flex:1 1 210px}.filter .field select{width:230px}
        .filter-title strong{font-size:11.5px}.filter-title span{font-size:9px}.field label{font-size:9px;letter-spacing:.25px}
        .field input,.field select{height:30px;padding:5px 8px;border-radius:7px}.field select{width:270px}
        .kpis{grid-template-columns:repeat(6,minmax(0,1fr));gap:6px;margin-top:7px}
        .kpi{position:relative;min-height:74px;padding:8px 10px 8px 13px;border-radius:10px;overflow:hidden;box-shadow:0 5px 16px rgba(16,42,67,.045)}
        .kpi::before{content:"";position:absolute;inset:0 auto 0 0;width:3px;background:linear-gradient(180deg,var(--primary),#52a5f7)}
        .kpi span{font-size:9px;text-transform:uppercase;letter-spacing:.2px}.kpi strong{margin-top:5px;font-size:20px;letter-spacing:-.25px}.kpi small{margin-top:5px;font-size:9px}
        .dashboard{gap:8px;margin-top:8px}.card{border-radius:11px;box-shadow:0 6px 18px rgba(16,42,67,.045)}
        .card-head{min-height:42px;padding:7px 10px;background:linear-gradient(180deg,#fff,#fbfdff)}
        .card-head h2{font-size:12px;letter-spacing:0}.card-head p{margin:2px 0 0;color:var(--muted);font-size:9px}.card-head>span{font-size:9px}
        .card-body{padding:10px}.chart-list{gap:5px}.chart-row{grid-template-columns:minmax(105px,1.15fr) minmax(140px,2fr) 56px;gap:8px;padding:6px 7px;border:1px solid #edf2f7;border-radius:8px;background:linear-gradient(90deg,#fff,#fbfdff)}
        .chart-label{font-size:9.3px}.track{height:6px;background:#eaf0f6;box-shadow:inset 0 1px 2px rgba(16,42,67,.05)}.bar{box-shadow:0 1px 3px rgba(15,111,236,.18)}.bar.blue{background:linear-gradient(90deg,#1676df,#52a5f7)}.bar.red{background:linear-gradient(90deg,#bf3d38,#ef716a)}.bar.gray{background:linear-gradient(90deg,#70869b,#a7b5c2)}
        .chart-meta{min-width:56px;text-align:right;line-height:1.05}.chart-meta strong{display:block;color:var(--navy);font-size:9.5px}.chart-meta small{display:block;margin-top:3px;color:#8495a6;font-size:9px}.chart-value{font-size:9px}
        .rings{gap:6px;align-items:stretch}.ring-wrap{display:flex;min-width:0;align-items:center;justify-content:center;flex-direction:column;padding:7px 4px;border:1px solid #e7edf4;border-radius:9px;background:linear-gradient(180deg,#fff,#f8fafc)}.ring{width:70px;height:70px;box-shadow:inset 0 0 0 1px rgba(16,42,67,.025)}.ring::after{width:51px;height:51px;box-shadow:0 0 0 1px #edf2f6}.ring strong{font-size:12px}.ring-wrap span{margin-top:5px;font-size:9px;font-weight:700}.ring-wrap small{display:block;margin-top:2px;color:#8a9aaa;font-size:9px}
        .trend-card .card-body{padding:8px 10px 9px}.legend{gap:6px}.legend span{display:inline-flex;align-items:center;gap:4px;padding:3px 6px;border:1px solid #e4ebf2;border-radius:999px;background:#fff}.legend i{margin:0}.legend b{color:var(--navy);font-size:9px}.trend-chart{display:grid;grid-template-columns:32px minmax(0,1fr);gap:8px;height:152px}.trend-axis{display:flex;flex-direction:column;justify-content:space-between;padding:4px 0 21px;text-align:right;color:#8192a3;font-size:9px}.trend-plot{position:relative;min-width:0;padding:3px 5px 0}.trend-grid{position:absolute;inset:3px 5px 21px;border-bottom:1px solid #cad6e2;background:repeating-linear-gradient(to bottom,transparent 0,transparent calc(33.333% - 1px),#e9eff5 calc(33.333% - 1px),#e9eff5 33.333%)}.trend-series{--months:1;position:relative;z-index:1;display:grid;grid-template-columns:repeat(var(--months),minmax(54px,1fr));align-items:end;height:146px;overflow-x:auto}.trend-series.single{width:min(280px,100%);margin:0 auto}.trend-item{min-width:54px;display:grid;grid-template-rows:124px 22px;text-align:center}.trend-bars{height:124px;display:flex;align-items:flex-end;justify-content:center;gap:7px;border:0}.trend-column{position:relative;width:clamp(15px,2vw,23px);height:var(--height);min-height:0;border-radius:5px 5px 2px 2px;background:linear-gradient(180deg,#3793ef,#176fce);box-shadow:0 4px 9px rgba(23,111,206,.2)}.trend-column.closed{background:linear-gradient(180deg,#35b99f,#10866f);box-shadow:0 4px 9px rgba(16,134,111,.18)}.trend-column.has-value{min-height:8px}.trend-value{position:absolute;bottom:calc(100% + 3px);left:50%;min-width:18px;padding:1px 3px;transform:translateX(-50%);border:1px solid #e3eaf1;border-radius:4px;color:#334e68;background:#fff;font-size:9px;font-weight:800;line-height:1.25;box-shadow:0 2px 5px rgba(16,42,67,.08)}.trend-item>small{align-self:end;margin:0;padding-top:5px;color:#6f8295;font-size:9px;font-weight:700}
        table{min-width:900px}th{padding:6px 8px;font-size:9px;letter-spacing:.2px}td{padding:6px 8px;font-size:9.2px;vertical-align:top}tbody tr:nth-child(even){background:#fbfdff}tbody tr:hover{background:#f1f7ff}
        .badge{padding:3px 6px;font-size:9px}.ticket{font-size:9.5px}.progress .track{width:76px;height:6px}
        .comment-detail summary{display:inline-flex;align-items:center;gap:5px;padding:4px 7px;border:1px solid #cfe1f5;border-radius:7px;color:#1767b5;background:#f5faff;font-size:9px;list-style:none}
        .comment-detail summary::-webkit-details-marker{display:none}.comment-detail summary::before{content:"+";display:grid;place-items:center;width:15px;height:15px;border-radius:50%;color:#fff;background:#2b86e5;font-size:11px;line-height:1}
        .comment-detail[open] summary::before{content:"−"}.comment-detail summary span{display:inline-grid;place-items:center;min-width:19px;height:19px;padding:0 5px;border-radius:999px;color:#fff;background:#2b86e5;font-size:9px}
        .solution-comments{min-width:165px}.solution-comment-list{display:grid;gap:6px;min-width:300px;max-width:480px;max-height:260px;margin-top:6px;padding:7px;overflow:auto;border:1px solid #dce8f4;border-radius:8px;background:#f7faff;box-shadow:0 6px 18px rgba(16,42,67,.07)}
        .solution-comment{padding:8px;border:1px solid #e1eaf3;border-radius:7px;background:#fff}.solution-comment-head{display:flex;align-items:center;justify-content:space-between;gap:10px}.solution-comment-head time{color:var(--muted);font-size:9px;white-space:nowrap}.solution-comment small{display:block;margin-top:2px;color:#6b7f93;font-size:9px}.solution-comment p{max-width:none;margin:5px 0 0;color:#334e68;font-size:9.5px;line-height:1.4;white-space:pre-wrap}.usage-count{display:inline-grid;place-items:center;min-width:26px;height:26px;padding:0 7px;border-radius:7px;color:#0b5fc0;background:#eaf4ff;font-weight:850}.solution-progress{min-width:135px}.muted-text{color:#8193a5;font-size:9px}.solutions-table{min-width:1080px}
        @media(max-width:1180px){.shell{width:calc(100% - 14px)}.kpis{grid-template-columns:repeat(4,minmax(0,1fr))}.card.third{grid-column:span 6}.solution-comment-list{min-width:270px}}
        @media(max-width:760px){body{font-size:11px}.shell{width:calc(100% - 10px);padding-top:5px}.topbar{padding:8px}.kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.kpi{min-height:70px;padding:8px 9px 8px 12px}.card-head{align-items:flex-start;flex-direction:column}.chart-row{grid-template-columns:95px minmax(90px,1fr) auto}.solution-comment-list{min-width:230px;max-width:270px}.field select{width:100%}}
        @media print{body{font-size:9px;background:#fff}.shell{width:100%;padding:0}.kpis{grid-template-columns:repeat(5,1fr)}.kpi{min-height:72px;padding:9px;box-shadow:none}.kpi strong{font-size:18px}.dashboard{gap:7px}.card-head{min-height:42px;padding:7px 9px}.card-body{padding:9px}th,td{padding:5px 6px}.comment-detail>summary{display:none}.comment-detail>.solution-comment-list,.comment-detail>p{display:block!important;max-height:none;box-shadow:none}.solution-comment-list{min-width:0}}

        /* Donas administrativas: composición clara sin librerías ni consultas adicionales. */
        .donut-layout{min-height:190px;display:grid;grid-template-columns:minmax(145px,42%) minmax(0,1fr);align-items:center;gap:13px;padding:12px}
        .donut-chart{--donut-gradient:#e8eef5 0 100%;position:relative;width:148px;aspect-ratio:1;display:grid;place-items:center;margin:auto;border-radius:50%;background:conic-gradient(var(--donut-gradient));box-shadow:0 8px 22px rgba(16,42,67,.11)}
        .donut-chart::before{content:"";position:absolute;width:61%;height:61%;border-radius:50%;background:#fff;box-shadow:inset 0 0 0 1px #e5edf5,0 2px 9px rgba(16,42,67,.07)}
        .donut-center{position:relative;z-index:1;display:grid;text-align:center}.donut-center strong{color:var(--navy);font-size:22px;line-height:1}.donut-center small{margin-top:5px;color:#71869a;font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.45px}
        .donut-legend{display:grid;gap:6px;align-content:center}.donut-item{display:grid;grid-template-columns:9px minmax(0,1fr) auto;align-items:center;gap:7px;min-height:27px;padding:5px 7px;border:1px solid #e8eef4;border-radius:7px;background:#fbfdff}.donut-dot{width:9px;height:9px;border-radius:50%;background:var(--slice-color)}.donut-label{overflow:hidden;color:#405b73;font-size:9.3px;font-weight:700;text-overflow:ellipsis;white-space:nowrap}.donut-value{text-align:right;color:var(--navy);font-size:9px}.donut-value strong{display:block;font-size:10px}.donut-value small{display:block;color:#8193a5;font-size:9px}
        .donut-card-wide .donut-layout{grid-template-columns:180px minmax(0,1fr)}.donut-card-wide .donut-legend{grid-template-columns:repeat(2,minmax(0,1fr))}.rating-donuts{min-height:190px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:10px}.rating-donut{display:grid;grid-template-columns:115px minmax(0,1fr);align-items:center;gap:8px;padding:8px;border:1px solid #e7edf4;border-radius:10px;background:linear-gradient(180deg,#fff,#f9fbfd)}.rating-donut .donut-chart{width:108px}.rating-donut .donut-center strong{font-size:17px}.rating-donut h3{grid-column:1/-1;margin:0;color:var(--navy);font-size:10.5px}.rating-donut .donut-item{min-height:22px;padding:3px 5px}.rating-donut .donut-label{font-size:9px}
        @media(max-width:1050px){.donut-layout,.donut-card-wide .donut-layout{grid-template-columns:145px minmax(0,1fr)}.donut-card-wide .donut-legend{grid-template-columns:1fr}.rating-donut{grid-template-columns:1fr}.rating-donut h3{text-align:center}}
        @media(max-width:760px){.donut-layout,.donut-card-wide .donut-layout{grid-template-columns:1fr}.donut-card-wide .donut-legend{grid-template-columns:1fr}.rating-donuts{grid-template-columns:1fr}.rating-donut{grid-template-columns:115px minmax(0,1fr)}}

        /* Resúmenes visuales alimentados por las mismas consultas de cada tabla. */
        .visual-card{grid-column:span 6}.visual-card .card-body{padding:9px 10px 10px}.visual-card .table-wrap{display:none;border-top:1px solid var(--border)}.visual-card.is-table-open .table-wrap{display:block}.visual-card.is-table-open .visual-summary{display:none}
        .visual-summary{min-height:238px}.visual-legend{display:flex;align-items:center;justify-content:flex-end;gap:10px;margin-bottom:7px;color:#6f8295;font-size:9px}.visual-legend span{display:inline-flex;align-items:center;gap:4px}.visual-legend i{width:8px;height:8px;border-radius:2px;background:#2b86e5}.visual-legend i.green{background:#21a585}.visual-legend i.amber{background:#e7a72f}.visual-legend i.gray{background:#9aaaba}
        .metric-chart{display:grid;gap:5px}.metric-row{width:100%;min-height:27px;display:grid;grid-template-columns:minmax(105px,31%) minmax(150px,1fr) 52px;align-items:center;gap:7px;padding:4px 6px;border:1px solid transparent;border-radius:7px;color:inherit;background:transparent;text-align:left;transform:none}
        .metric-row:hover,.metric-row:focus{border-color:#d8e7f5;background:#f7fbff;box-shadow:none;transform:none;outline:none}.metric-name{overflow:hidden;color:#334e68;font-size:9px;font-weight:750;text-overflow:ellipsis;white-space:nowrap}.metric-bars{display:grid;gap:3px}.metric-line{display:grid;grid-template-columns:1fr 25px;align-items:center;gap:5px}.metric-track{height:5px;overflow:hidden;border-radius:999px;background:#edf2f7}.metric-fill{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,#176fce,#52a5f7)}.metric-fill.green{background:linear-gradient(90deg,#10866f,#42bea6)}.metric-fill.amber{background:linear-gradient(90deg,#c77a08,#f2b94f)}.metric-fill.gray{background:linear-gradient(90deg,#758a9d,#b2bdc7)}.metric-line small{color:#657a8e;font-size:9px;text-align:right}.metric-score{display:grid;justify-items:end;gap:1px}.metric-score strong{color:#173f63;font-size:9px}.metric-score small{color:#7b8ea0;font-size:9px}
        .visual-empty{min-height:210px;display:grid;place-items:center;color:#7c90a3;font-size:9px}.table-mode-toggle{min-width:78px;min-height:27px;padding:4px 7px;border-color:#d5e3ef;color:#315f84;background:#fff;font-size:9px}.table-mode-toggle::before{content:"▦";font-size:11px}.visual-card.is-table-open .table-mode-toggle::before{content:"▥"}
        .chart-caption{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:7px;padding-top:6px;border-top:1px solid #edf2f6;color:#8192a3;font-size:9px}.chart-caption b{color:#46627b;font-weight:750}

        /* Navegación compacta: cada bloque puede contraerse y el detalle se consulta en un panel lateral. */
        .view-controls{display:flex;align-items:center;gap:5px;padding-left:5px;border-left:1px solid #dce6f0}
        .view-controls button{min-height:28px;padding:4px 8px;color:#365f82;background:#fff;font-size:9px}
        .card-head-main{min-width:0;flex:1}.card-head-actions{display:flex;align-items:center;justify-content:flex-end;gap:7px;margin-left:auto}
        .card-head-actions>.card-meta{max-width:420px;color:var(--muted);font-size:9px;text-align:right}
        .card-toggle{min-width:92px;min-height:27px;padding:4px 8px;border-color:#d4e2ef;color:#24577f;background:#f8fbff;font-size:9px;white-space:nowrap}
        .card-toggle::before{content:"−";display:grid;place-items:center;width:15px;height:15px;border-radius:5px;color:#fff;background:#5d7892;font-size:12px;line-height:1}
        .card.is-collapsed .card-toggle::before{content:"+";background:#1475d3}.card.is-collapsed .card-head{border-bottom-color:transparent}
        .card.is-collapsed>:not(.card-head){display:none}.card.is-collapsed{align-self:start}.card.is-collapsed .card-head{min-height:38px;background:#fff}
        .card.is-collapsed .card-head-main p{display:none}.card.is-collapsed .card-head-actions>.card-meta{display:none}
        .selectable-row{cursor:pointer;transition:background .16s ease,box-shadow .16s ease}.selectable-row:focus{position:relative;z-index:2;outline:2px solid #75afe9;outline-offset:-2px;background:#f1f7ff}
        .selectable-row td:first-child{position:relative;padding-right:27px}.selectable-row td:first-child::after{content:"›";position:absolute;top:50%;right:9px;display:grid;place-items:center;width:16px;height:16px;transform:translateY(-50%);border-radius:5px;color:#1767b5;background:#eaf4ff;font-size:16px;font-weight:800;line-height:1}
        .selectable-row:hover td:first-child::after{color:#fff;background:#1767b5}.row-hint{color:#71879b;font-size:9px}
        .drawer-backdrop{position:fixed;z-index:2147483645;inset:0;background:rgba(15,35,55,.28);backdrop-filter:blur(1px)}
        .detail-drawer{position:fixed;z-index:2147483646;top:0;right:0;width:min(540px,100vw);max-width:100%;height:100vh;display:flex;visibility:hidden;pointer-events:none;flex-direction:column;overflow:hidden;box-sizing:border-box;transform:translateX(102%);border-left:1px solid #cad8e6;background:#f5f8fc;box-shadow:-18px 0 45px rgba(16,42,67,.2);transition:transform .22s ease,visibility 0s linear .22s}
        .detail-drawer.is-open{visibility:visible;pointer-events:auto;transform:translateX(0);transition-delay:0s}.drawer-head{display:flex;align-items:flex-start;gap:12px;padding:16px 17px 13px;border-bottom:1px solid #dce6f0;background:#fff}
        .drawer-icon{flex:0 0 auto;width:34px;height:34px;display:grid;place-items:center;border-radius:9px;color:#fff;background:linear-gradient(145deg,#0f79f1,#0b4fae);font-size:12px;font-weight:850}
        .drawer-title{min-width:0;flex:1}.drawer-title span{display:block;color:#70859a;font-size:9px;font-weight:800;letter-spacing:.4px;text-transform:uppercase}.drawer-title h2{overflow:hidden;margin:2px 0 0;color:var(--navy);font-size:16px;line-height:1.25;text-overflow:ellipsis;white-space:nowrap}
        .drawer-close{flex:0 0 auto;width:31px;min-width:31px;height:31px;min-height:31px;padding:0;border-radius:50%;color:#49657d;background:#f3f7fb;font-size:17px}
        .drawer-body{min-width:0;flex:1;padding:13px 15px 20px;overflow-x:hidden;overflow-y:auto;overscroll-behavior:contain}.detail-grid{min-width:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.detail-item{min-width:0;padding:9px 10px;border:1px solid #e0e8f0;border-radius:8px;background:#fff}
        .detail-item span{display:block;margin-bottom:3px;color:#718599;font-size:9px;font-weight:800;letter-spacing:.25px;text-transform:uppercase}.detail-item strong{display:block;overflow-wrap:anywhere;color:#243b53;font-size:10px;line-height:1.35}.detail-item.full{grid-column:1/-1}
        .drawer-section{min-width:0;max-width:100%;box-sizing:border-box;margin-top:12px;padding:11px;overflow:hidden;border:1px solid #dde7f0;border-radius:10px;background:#fff}.drawer-section h3{margin:0 0 8px;overflow-wrap:anywhere;color:var(--navy);font-size:10px}.related-list{min-width:0;display:grid;grid-template-columns:minmax(0,1fr);gap:5px;margin:0;padding:0;list-style:none}.related-list li{min-width:0;max-width:100%}.related-row{width:100%;max-width:100%;min-width:0;min-height:34px;display:flex;align-items:center;justify-content:space-between;gap:8px;box-sizing:border-box;padding:7px 9px;overflow:hidden;border:1px solid #e4ebf2;border-radius:7px;color:#334e68;background:#f9fbfd;text-align:left;font-size:9px}.related-row:hover{border-color:#b8d3ed;background:#f1f7ff;transform:none}.related-row b{min-width:0;flex:1 1 auto;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.related-row span{max-width:34%;flex:0 1 auto;overflow:hidden;color:#6e8295;font-size:9px;text-overflow:ellipsis;white-space:nowrap}
        .drawer-search{width:100%;height:38px;margin-top:12px;padding:7px 11px;border:1px solid #cbd9e6;border-radius:8px;color:var(--text);background:#fff;font-size:11px;outline:none}.drawer-search:focus{border-color:var(--primary);box-shadow:0 0 0 3px color-mix(in srgb,var(--primary) 14%,transparent)}.type-list-summary{margin:8px 0 0;color:var(--muted);font-size:9px}.type-list-empty{padding:22px 8px;text-align:center;color:var(--muted);font-size:10px}
        .drawer-pagination{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:10px;padding-top:9px;border-top:1px solid #e4ebf2}.drawer-pagination button{min-width:72px;min-height:28px;padding:5px 8px;border:1px solid #cbd9e6;border-radius:7px;color:#315a7c;background:#f7fafc;font-size:9px;font-weight:800}.drawer-pagination button:hover:not(:disabled){border-color:#9fc5e6;background:#eef6fd}.drawer-pagination button:disabled{cursor:not-allowed;opacity:.48}.drawer-pagination span{color:#718599;font-size:9px;font-weight:800}
        .drawer-comments .solution-comment-list{min-width:0;max-width:none;max-height:min(380px,46vh);margin:0;padding:0 5px 0 0;overflow:auto;border:0;border-radius:0;background:transparent;box-shadow:none}.drawer-comments .solution-comment{padding:10px;border-color:var(--border);background:var(--surface)}.drawer-comments .solution-comment-head{align-items:flex-start}.drawer-comments .solution-comment-head .ticket{font-size:10px}.drawer-comments .solution-comment small{margin-top:4px;color:var(--muted);font-size:9px}.drawer-comments .solution-comment p{margin-top:7px;color:var(--text);font-size:10px;line-height:1.5}
        .drawer-empty{margin:0;color:#7d90a2;font-size:9px}.drawer-foot{display:flex;align-items:center;justify-content:flex-end;gap:7px;padding:10px 15px;border-top:1px solid #dce6f0;background:#fff}.drawer-foot .btn{min-height:29px;font-size:9px}.drawer-foot .ticket-action[hidden]{display:none}
        body.drawer-open{overflow:hidden}
        @media(max-width:900px){.view-controls{width:100%;justify-content:flex-end;padding:6px 0 0;border-top:1px solid #e4ebf2;border-left:0}.topbar{flex-wrap:wrap}.card-head-actions>.card-meta{display:none}.visual-card{grid-column:span 12}}
        @media(max-width:760px){.card-head{align-items:center;flex-direction:row}.card-head-main{overflow:hidden}.card-head-main h2{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.card-toggle{min-width:82px}.detail-drawer{width:100vw;border-left:0}.detail-grid{grid-template-columns:1fr}.detail-item.full{grid-column:auto}.drawer-head{padding:13px}.drawer-title h2{display:-webkit-box;overflow:hidden;text-overflow:clip;white-space:normal;-webkit-box-orient:vertical;-webkit-line-clamp:2}.drawer-body{padding:10px}.drawer-section{padding:9px}.related-row{align-items:flex-start;min-height:42px}.related-row b{display:-webkit-box;overflow:hidden;white-space:normal;overflow-wrap:anywhere;-webkit-box-orient:vertical;-webkit-line-clamp:2}.related-row span{max-width:30%;padding-top:1px}.drawer-pagination button{min-width:0;flex:1}.drawer-pagination span{flex:0 0 auto;text-align:center}.view-controls button{flex:1}.metric-row{grid-template-columns:minmax(88px,32%) minmax(105px,1fr) 43px}.visual-summary{min-height:215px}}
        @media print{.view-controls,.card-toggle,.drawer-backdrop,.detail-drawer{display:none!important}.card.is-collapsed>:not(.card-head){display:block!important}.card.is-collapsed .card-head{border-bottom-color:var(--border)}.selectable-row td:first-child::after{display:none}}

        /* Escala de lectura cómoda para el panel administrativo. */
        body{font-size:14px;line-height:1.45}
        .topbar h1{font-size:20px}.topbar p{font-size:12px}
        .btn,button{min-height:36px;font-size:12px}
        .filter-title strong{font-size:14px}.filter-title span{font-size:12px}.field label{font-size:11px}.field input,.field select{height:36px;font-size:12px}
        .kpis{grid-template-columns:repeat(5,minmax(0,1fr));gap:9px}.kpi{min-height:94px;padding:12px 13px 11px 16px}.kpi span{font-size:11px}.kpi strong{font-size:24px}.kpi small{font-size:10.5px}
        .card-head{min-height:52px;padding:10px 13px}.card-head h2{font-size:15px}.card-head p,.card-head>span,.card-meta{font-size:11px}
        .card-body{padding:13px}.card-toggle,.table-mode-toggle{min-height:32px;font-size:11px}
        .legend,.visual-legend{font-size:11px}.legend b{font-size:11px}.trend-axis,.trend-value,.trend-item>small{font-size:10px}
        .ring{width:88px;height:88px}.ring::after{width:63px;height:63px}.ring strong{font-size:15px}.ring-wrap span{font-size:11px}.ring-wrap small{font-size:10px}
        .donut-layout{min-height:230px}.donut-chart{width:170px}.donut-center strong{font-size:25px}.donut-center small{font-size:10px}.donut-item{min-height:34px;padding:7px 9px}.donut-label{font-size:12px}.donut-value strong{font-size:12px}.donut-value small{font-size:10px}
        .rating-donuts{min-height:230px}.rating-donut{grid-template-columns:135px minmax(0,1fr);padding:10px}.rating-donut .donut-chart{width:128px}.rating-donut .donut-center strong{font-size:20px}.rating-donut h3{font-size:13px}.rating-donut .donut-item{min-height:28px;padding:5px 7px}.rating-donut .donut-label{font-size:11px}
        .visual-summary{min-height:285px}.visual-legend{font-size:10.5px}.metric-row{min-height:36px;grid-template-columns:minmax(125px,31%) minmax(170px,1fr) 62px;padding:6px 8px}.metric-name{font-size:11.5px}.metric-line small{font-size:10px}.metric-score strong{font-size:12px}.metric-score small{font-size:9.5px}.chart-caption{font-size:10px}
        table{min-width:980px}th{padding:9px 10px;font-size:10.5px}td{padding:9px 10px;font-size:11.5px}.badge{font-size:10px}.ticket{font-size:11.5px}.muted-text{font-size:11px}
        @media(max-width:1280px){.kpis{grid-template-columns:repeat(4,minmax(0,1fr))}.card.third{grid-column:span 6}.donut-layout{grid-template-columns:175px minmax(0,1fr)}}
        @media(max-width:760px){body{font-size:13px}.kpis{grid-template-columns:repeat(2,minmax(0,1fr))}.card-head h2{font-size:14px}.donut-layout,.donut-card-wide .donut-layout{grid-template-columns:1fr}.rating-donut{grid-template-columns:128px minmax(0,1fr)}}

        /* Evolución temporal: lectura amplia y agrupación por día, mes o año. */
        .trend-card .card-head{align-items:center;flex-wrap:wrap;gap:10px}
        .trend-heading{min-width:190px;flex:1}.trend-heading h2{margin:0}.trend-heading p{margin:2px 0 0;color:var(--muted);font-size:10.5px}
        .trend-toolbar{display:flex;align-items:center;justify-content:flex-end;gap:9px;flex-wrap:wrap}
        .trend-auto-label{display:inline-flex;align-items:center;gap:6px;min-height:28px;padding:4px 9px;border:1px solid var(--border);border-radius:8px;color:var(--muted);background:var(--surface);font-size:10px;font-weight:750}
        .trend-auto-label::before{content:"";width:7px;height:7px;border-radius:50%;background:var(--primary);box-shadow:0 0 0 3px color-mix(in srgb,var(--primary) 15%,transparent)}
        .trend-card .legend{gap:5px}.trend-card .legend span{color:var(--text);background:var(--surface);border-color:var(--border)}
        .trend-card .card-body{padding:14px 15px 12px}
        .trend-chart{grid-template-columns:42px minmax(0,1fr);gap:11px;height:244px}
        .trend-axis{padding:8px 0 31px;color:var(--muted);font-size:10px;font-weight:700}
        .trend-plot{padding:7px 8px 0;border:1px solid var(--border);border-radius:9px;background:var(--surface)}
        .trend-grid{inset:7px 8px 31px;border-color:var(--border);background:repeating-linear-gradient(to bottom,transparent 0,transparent calc(25% - 1px),color-mix(in srgb,var(--border) 72%,transparent) calc(25% - 1px),color-mix(in srgb,var(--border) 72%,transparent) 25%)}
        .trend-series{--points:1;grid-template-columns:repeat(var(--points),minmax(70px,1fr));height:237px;padding:0 4px}
        .trend-series.single{width:min(340px,100%)}
        .trend-item{min-width:70px;grid-template-rows:198px 32px}
        .trend-bars{height:198px;gap:8px}
        .trend-column{width:clamp(18px,2.2vw,28px);border-radius:6px 6px 2px 2px}
        .trend-value{bottom:calc(100% + 5px);min-width:23px;padding:2px 5px;border-color:var(--border);color:var(--text);background:var(--surface);font-size:10px}
        .trend-item>small{padding-top:8px;color:var(--muted);font-size:10px;white-space:nowrap}
        .trend-note{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:9px;color:var(--muted);font-size:10px}
        .trend-note strong{color:var(--text)}
        .trend-line-plot{overflow:hidden}
        .trend-line-chart{display:block;width:100%;height:100%;min-height:210px;overflow:visible}
        .trend-line-grid line{fill:none;stroke:color-mix(in srgb,var(--border) 72%,transparent);stroke-width:1;vector-effect:non-scaling-stroke}
        .trend-line-area{fill:color-mix(in srgb,var(--primary) 16%,transparent);stroke:none}
        .trend-line-created,.trend-line-closed{fill:none;stroke-width:3;stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}
        .trend-line-created{stroke:#2b74ed}.trend-line-closed{stroke:#22a884}
        .trend-line-point{stroke:var(--surface);stroke-width:2;vector-effect:non-scaling-stroke}
        .trend-line-point.created{fill:#2b74ed}.trend-line-point.closed{fill:#22a884}
        .trend-line-label{fill:var(--muted);font-size:11px;font-weight:700;text-anchor:middle;dominant-baseline:auto}
        .created-ranking-card .card-body{padding:13px 15px 15px}.created-ranking{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 14px}.created-rank-item{display:grid;grid-template-columns:minmax(82px,118px) minmax(120px,1fr) 44px;align-items:center;gap:9px;min-height:42px;padding:7px 9px;border:1px solid var(--border);border-radius:9px;background:var(--surface)}
        .created-rank-position{display:flex;align-items:center;gap:7px;min-width:0;color:var(--text);font-size:10.5px;font-weight:800}.created-rank-position i{flex:0 0 auto;width:22px;height:22px;display:grid;place-items:center;border-radius:7px;color:#fff;background:var(--primary);font-size:9px;font-style:normal}.created-rank-position span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .created-rank-track{height:10px;overflow:hidden;border-radius:999px;background:color-mix(in srgb,var(--border) 72%,transparent)}.created-rank-fill{display:block;height:100%;min-width:4px;border-radius:inherit;background:linear-gradient(90deg,var(--primary),color-mix(in srgb,var(--primary) 55%,#55c4ff));box-shadow:0 2px 7px color-mix(in srgb,var(--primary) 25%,transparent)}
        .created-rank-total{text-align:right;color:var(--text);font-size:12px;font-weight:850}.created-ranking-note{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:10px;padding-top:9px;border-top:1px solid var(--border);color:var(--muted);font-size:10px}.created-ranking-note strong{color:var(--text)}
        .operational-summary{margin-top:9px;padding:13px;border:1px solid var(--border);border-radius:12px;background:var(--surface);box-shadow:0 6px 18px rgba(16,42,67,.045)}
        .operational-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:11px}.operational-head h2{margin:0;color:var(--navy);font-size:16px}.operational-head p{margin:3px 0 0;color:var(--muted);font-size:11px}.operational-head span{flex:0 0 auto;padding:5px 9px;border:1px solid var(--border);border-radius:999px;color:var(--muted);background:var(--surface);font-size:10px;font-weight:800}
        .operational-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px}.operational-kpi{position:relative;min-height:112px;padding:12px 13px 11px 16px;overflow:hidden;border:1px solid var(--border);border-radius:10px;background:var(--surface)}.operational-kpi::before{content:"";position:absolute;inset:0 auto 0 0;width:4px;background:var(--primary)}.operational-kpi.warning::before{background:var(--amber)}.operational-kpi.danger::before{background:var(--red)}.operational-kpi.success::before{background:var(--green)}.operational-kpi.purple::before{background:var(--purple)}
        .operational-kpi .kpi-label{display:block;color:var(--muted);font-size:10px;font-weight:850;letter-spacing:.25px;text-transform:uppercase}.operational-kpi strong{display:block;margin-top:7px;color:var(--navy);font-size:23px;line-height:1.05}.operational-kpi small{display:block;margin-top:7px;color:var(--muted);font-size:10px;line-height:1.35}.operational-kpi .kpi-context{margin-top:8px;padding-top:7px;border-top:1px solid var(--border);color:var(--text);font-size:10px;font-weight:750}.operational-kpi .kpi-context.positive{color:var(--green)}.operational-kpi .kpi-context.negative{color:var(--red)}
        .process-base-card .card-head{align-items:flex-start}.process-base-card .card-head>span{flex:0 0 auto;padding:4px 8px;border:1px solid var(--border);border-radius:999px;background:var(--surface);font-weight:800}.process-base-table{min-width:1380px}.process-base-table th:first-child,.process-base-table td:first-child{min-width:150px}.process-base-table th:nth-child(2),.process-base-table td:nth-child(2){min-width:220px;white-space:normal}.process-base-table td:not(:first-child):not(:nth-child(2)){white-space:nowrap}
        .classification-card .card-body{padding:13px}.classification-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:9px}.classification-option{position:relative;min-height:92px;display:grid;grid-template-columns:40px minmax(0,1fr) auto;align-items:center;gap:10px;padding:12px;overflow:hidden;border:1px solid var(--border);border-radius:10px;color:var(--text);background:var(--surface);text-align:left;box-shadow:none;transform:none}.classification-option:hover,.classification-option:focus-visible{border-color:color-mix(in srgb,var(--primary) 48%,var(--border));background:var(--soft);box-shadow:0 7px 18px color-mix(in srgb,var(--primary) 12%,transparent);transform:translateY(-1px);outline:none}.classification-icon{width:40px;height:40px;display:grid;place-items:center;border-radius:10px;color:#fff;background:linear-gradient(145deg,var(--primary),color-mix(in srgb,var(--primary) 62%,var(--accent)));font-size:15px;font-weight:900}.classification-copy{min-width:0}.classification-copy strong,.classification-copy small{display:block}.classification-copy strong{overflow:hidden;color:var(--navy);font-size:13px;text-overflow:ellipsis;white-space:nowrap}.classification-copy small{margin-top:3px;color:var(--muted);font-size:10px}.classification-count{text-align:right}.classification-count strong,.classification-count small{display:block}.classification-count strong{color:var(--navy);font-size:22px;line-height:1}.classification-count small{margin-top:4px;color:var(--muted);font-size:9px}.classification-progress{grid-column:2/-1;height:5px;overflow:hidden;border-radius:999px;background:color-mix(in srgb,var(--border) 72%,transparent)}.classification-progress span{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--primary),color-mix(in srgb,var(--primary) 55%,var(--accent)))}
        @media(max-width:900px){.created-ranking{grid-template-columns:1fr}}
        @media(max-width:1180px){.operational-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
        @media(max-width:760px){.trend-toolbar{width:100%;justify-content:space-between}.trend-card .card-body{padding:10px}.trend-chart{height:220px}.trend-series{height:213px;grid-template-columns:repeat(var(--points),minmax(62px,1fr))}.trend-item{min-width:62px;grid-template-rows:175px 31px}.trend-bars{height:175px}.trend-note,.created-ranking-note{align-items:flex-start;flex-direction:column}.created-ranking-card .card-body{padding:10px}.created-rank-item{grid-template-columns:92px minmax(90px,1fr) 36px}.operational-summary{padding:10px}.operational-head{flex-direction:column}.operational-kpis{grid-template-columns:1fr}.operational-kpi{min-height:100px}}
        @media(max-width:760px){.classification-grid{grid-template-columns:1fr}.classification-option{min-height:84px}}

        /* Reporte integral: salida multipágina, no captura del área visible. */
        .print-report-context{display:none}
        .print-window-toolbar{position:sticky;z-index:20;top:0;display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px;padding:9px 12px;border:1px solid #cbd9e6;border-radius:10px;background:#fff;box-shadow:0 6px 18px rgba(16,42,67,.08)}
        .print-window-toolbar p{margin:0;color:#526b82;font-size:11px}.print-window-toolbar div{display:flex;gap:7px}.print-mode{background:#fff}.print-mode .actions,.print-mode .filter{display:none}.print-mode .print-report-context{display:grid}
        @media print{
            @page{size:A4 landscape;margin:8mm}
            *,*::before,*::after{-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
            html,body{width:auto!important;min-width:0!important;height:auto!important;overflow:visible!important;background:#fff!important}
            body{font:8pt/1.28 Inter,"Segoe UI",Arial,sans-serif;color:#243b53}
            .shell{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
            .actions,.filter,.print-window-toolbar,.view-controls,.card-toggle,.table-mode-toggle,.drawer-backdrop,.detail-drawer{display:none!important}
            .topbar{min-height:0;margin:0 0 3mm;padding:3mm 4mm;border:1px solid #cbd9e6;border-radius:3mm;box-shadow:none!important}
            .topbar h1{font-size:16pt}.topbar p{font-size:8pt}.mark{width:9mm;height:9mm;font-size:7pt}
            .print-report-context{display:grid;grid-template-columns:1.4fr 1fr 1fr 1fr;gap:2mm;margin:0 0 3mm;padding:3mm;border:1px solid #dce6f0;border-radius:2.5mm;background:#f7faff}
            .print-context-title{grid-column:1/-1;display:flex;align-items:flex-end;justify-content:space-between;gap:4mm;padding-bottom:2mm;border-bottom:1px solid #dce6f0}
            .print-context-title h2{margin:0;color:#102a43;font-size:12pt}.print-context-title p{margin:0;color:#6b7f93;font-size:7pt}
            .print-context-item{min-width:0;padding:2mm;border-left:1mm solid #0f6fec;background:#fff}
            .print-context-item span{display:block;color:#6b7f93;font-size:6pt;font-weight:800;text-transform:uppercase}
            .print-context-item strong{display:block;margin-top:1mm;overflow-wrap:anywhere;color:#102a43;font-size:8pt}
            .alert{margin:0 0 3mm;box-shadow:none}
            .operational-summary{margin:0 0 3mm;padding:3mm;border-radius:2.5mm;box-shadow:none!important;break-inside:avoid-page}
            .operational-kpis{grid-template-columns:repeat(4,minmax(0,1fr));gap:2mm}.operational-kpi{min-height:24mm;padding:3mm;box-shadow:none!important}
            .kpis{grid-template-columns:repeat(6,minmax(0,1fr))!important;gap:2mm;margin:0 0 3mm}.kpi{min-height:19mm;padding:2.5mm;border-radius:2mm;box-shadow:none!important;break-inside:avoid-page}.kpi span{font-size:6.5pt}.kpi strong{font-size:14pt}.kpi small{font-size:6.5pt}
            .dashboard{display:grid!important;grid-template-columns:repeat(12,minmax(0,1fr))!important;gap:2.5mm;margin:0!important}
            .card,.card.third{grid-column:span 6!important;overflow:visible!important;border-radius:2.5mm;box-shadow:none!important;break-inside:avoid-page}
            .card.wide,.trend-card,.classification-card{grid-column:1/-1!important}
            .card.is-collapsed>:not(.card-head){display:block!important}.card.is-collapsed .card-head{border-bottom-color:#dce6f0!important}
            .card-head{min-height:10mm;padding:2.2mm 3mm;background:#f8fbff!important}.card-head h2{font-size:9pt}.card-head p,.card-head>span,.card-meta{font-size:6.5pt}.card-body{padding:2.5mm}
            .chart-row{break-inside:avoid}.trend-series{overflow:visible!important}.classification-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.classification-option{min-height:19mm;padding:2.5mm;box-shadow:none!important;break-inside:avoid}.classification-copy small{display:none}
            .donut-layout,.donut-card-wide .donut-layout{grid-template-columns:38mm minmax(0,1fr)!important;min-height:0}.donut-chart{width:34mm!important}.rating-donuts{min-height:0}.ring{width:20mm;height:20mm}.ring::after{width:14mm;height:14mm}
            .visual-card{grid-column:1/-1!important;break-before:page;break-inside:auto!important}.visual-card .visual-summary{display:block!important;min-height:0}.visual-card .table-wrap{display:block!important;margin-top:2mm;border-top:1px solid #dce6f0}
            .table-wrap,.table-wrap.tall{max-width:none!important;max-height:none!important;overflow:visible!important}
            table,.process-base-table{width:100%!important;min-width:0!important;table-layout:fixed;border-collapse:collapse}
            thead{display:table-header-group}tfoot{display:table-footer-group}tr{break-inside:avoid-page}th{position:static!important;padding:1.2mm 1mm;font-size:5.2pt;white-space:normal;overflow-wrap:anywhere;background:#eaf2fb!important}td{padding:1.2mm 1mm;font-size:5.5pt;white-space:normal!important;overflow-wrap:anywhere}.badge,.ticket{font-size:5.3pt}.progress .track{width:12mm}.selectable-row td:first-child{padding-right:1mm}.selectable-row td:first-child::after{display:none!important}
            .comment-detail>p{display:block!important;max-width:none}.comment-detail summary{display:none!important}
            a{color:inherit!important;text-decoration:none!important}.drawer-open{overflow:visible!important}
        }
    </style>
    <style id="admin-indicators-plain-headings">
        /* Las cabeceras de los indicadores forman parte de cada tarjeta; no
           deben aparecer como franjas azules independientes. */
        body.mesa-php-shell .dashboard>.card>.card-head{
            background:transparent!important;
            border-bottom-color:transparent!important;
        }
        .rating-process-card{grid-column:1/-1!important}
        .rating-process-card .card-head{align-items:flex-start}
        .rating-process-card .card-head-main{min-width:0}
        .rating-process-card .card-head-main p{max-width:760px;margin:3px 0 0;color:var(--muted);font-size:9.5px}
        .rating-process-summary{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin-bottom:9px}
        .rating-process-summary span{display:inline-flex;align-items:center;gap:5px;padding:4px 8px;border:1px solid #e1eaf3;border-radius:999px;color:#60778c;background:#f8fbff;font-size:9px}
        .rating-process-summary strong{color:var(--navy);font-size:11px}
        .rating-process-summary .good{border-color:#b9e2d5;color:#087443;background:#eefaf5}
        .rating-process-summary .bad{border-color:#f0c4c0;color:#a83b32;background:#fff3f1}
        .rating-process-chart{display:grid;gap:7px;max-height:430px;overflow:auto;padding:2px 4px 3px 1px}
        .rating-process-row{display:grid;grid-template-columns:minmax(150px,26%) minmax(180px,1fr) 92px;align-items:center;gap:10px;min-height:32px;padding:4px 7px;border:1px solid #edf2f7;border-radius:8px;background:linear-gradient(90deg,#fff,#fbfdff)}
        .rating-process-label{min-width:0;overflow:hidden;color:#294c69;font-size:10px;font-weight:750;text-overflow:ellipsis;white-space:nowrap}
        .rating-process-label small{display:block;margin-top:2px;color:#8a9aaa;font-size:8.5px;font-weight:500}
        .rating-process-track{height:13px;overflow:hidden;border-radius:999px;background:repeating-linear-gradient(90deg,#edf2f7 0,#edf2f7 calc(10% - 1px),#dfe8f1 10%)}
        .rating-process-fill{height:100%;min-width:0;border-radius:inherit;background:linear-gradient(90deg,#159b79,#48c793);box-shadow:0 1px 4px rgba(21,155,121,.2)}
        .rating-process-fill.warning{background:linear-gradient(90deg,#d58a12,#f4c45c);box-shadow:0 1px 4px rgba(213,138,18,.2)}
        .rating-process-fill.danger{background:linear-gradient(90deg,#c7463e,#f17a70);box-shadow:0 1px 4px rgba(199,70,62,.2)}
        .rating-process-fill.empty{background:#b9c7d4}
        .rating-process-value{text-align:right;color:var(--navy);font-size:11px;font-weight:850}
        .rating-process-value small{display:block;margin-top:2px;color:#8293a4;font-size:8.5px;font-weight:550}
        .rating-process-note{display:flex;justify-content:space-between;gap:10px;margin-top:8px;padding-top:7px;border-top:1px solid #edf2f6;color:#8192a3;font-size:9px}
        .rating-process-note strong{color:#46627b;font-weight:750}
        @media(max-width:760px){.rating-process-row{grid-template-columns:105px minmax(90px,1fr) 70px;gap:7px}.rating-process-label{font-size:9px}.rating-process-value{font-size:10px}.rating-process-note{align-items:flex-start;flex-direction:column}}
        @media print{.rating-process-card{break-inside:avoid-page}.rating-process-chart{max-height:none;overflow:visible}.rating-process-row{break-inside:avoid-page}.rating-process-note{font-size:6.5pt}}
    </style>
</head>
<body<?= $modoImpresion ? ' class="print-mode"' : '' ?>>
<main class="shell">
    <?php if ($modoImpresion): ?>
        <div class="print-window-toolbar">
            <p>Vista independiente del reporte completo. Puede imprimir nuevamente o cerrar esta pestaña.</p>
            <div><button id="printDedicatedAgain" type="button">Imprimir</button><button id="closePrintWindow" type="button">Cerrar</button></div>
        </div>
    <?php endif; ?>
    <header class="topbar">
        <div class="title-wrap"><div class="mark">BI</div><div><h1>Indicadores de Tickets</h1><p><?= escaparIndicador($periodo) ?> · actualizado <?= date('d/m/Y H:i') ?></p></div></div>
        <nav class="actions">
            <div class="view-controls" aria-label="Controles de visualización">
                <button id="collapseAllCards" type="button">Minimizar todo</button>
                <button id="expandAllCards" type="button">Maximizar todo</button>
            </div>
            <a class="btn" href="<?= escaparIndicador($urlDashboardExcel) ?>">Exportar dashboard Excel</a>
            <a class="btn primary" href="descargarSolicitudesExcel.php">Descargar base</a>
        </nav>
    </header>

    <section class="print-report-context" aria-hidden="<?= $modoImpresion ? 'false' : 'true' ?>">
        <div class="print-context-title">
            <h2>Reporte integral de indicadores</h2>
            <p>Dashboard completo preparado para impresión o exportación a PDF.</p>
        </div>
        <div class="print-context-item"><span>Periodo analizado</span><strong><?= escaparIndicador($periodo) ?></strong></div>
        <div class="print-context-item"><span>Proceso</span><strong id="printReportArea">Todos los procesos</strong></div>
        <div class="print-context-item"><span>Servicio</span><strong id="printReportService">Todos los servicios</strong></div>
        <div class="print-context-item"><span>Generado</span><strong><?= date('d/m/Y H:i') ?></strong></div>
    </section>

    <form class="filter" method="get">
        <div class="filter-title"><strong>Filtros de análisis</strong><span>Combine periodo, proceso y servicio. Sin selección se analiza toda la base histórica.</span></div>
        <div class="field"><label for="desde">Desde</label><input id="desde" type="date" name="desde" value="<?= escaparIndicador($desde) ?>"></div>
        <div class="field"><label for="hasta">Hasta</label><input id="hasta" type="date" name="hasta" value="<?= escaparIndicador($hasta) ?>"></div>
        <div class="field"><label for="id_catalogo_indicador">Proceso</label><select id="id_catalogo_indicador" name="id_catalogo_indicador"><option value="0">Todos los procesos</option><?php foreach ($areasIndicador as $areaIndicador): ?><option value="<?= (int) $areaIndicador['id_catalogo'] ?>" <?= (int) $areaIndicador['id_catalogo'] === $idCatalogoIndicador ? 'selected' : '' ?>><?= escaparIndicador($areaIndicador['nombre']) ?><?= ($areaIndicador['estado'] ?? '') !== 'activo' ? ' (inhabilitado)' : '' ?></option><?php endforeach; ?></select></div>
        <div class="field"><label for="id_servicio_solucion">Servicio</label><select id="id_servicio_solucion" name="id_servicio_solucion"><option value="0">Todos los servicios</option><?php foreach ($serviciosSolucionFiltro as $servicioFiltro): ?><option value="<?= (int) $servicioFiltro['id_servicio'] ?>" data-area="<?= (int) $servicioFiltro['id_catalogo'] ?>" <?= (int) $servicioFiltro['id_servicio'] === $idServicioSolucion ? 'selected' : '' ?>><?= escaparIndicador($servicioFiltro['nombre']) ?><?= ($servicioFiltro['estado'] ?? '') !== 'activo' ? ' (inhabilitado)' : '' ?></option><?php endforeach; ?></select></div>
        <button class="primary" type="submit">Aplicar</button><a class="btn" href="indicadores.php">Limpiar</a>
    </form>

    <?php if (!$moduloDisponible): ?><div class="alert">El módulo de Tickets todavía no está instalado por completo.</div><?php endif; ?>
    <?php if ($errorDashboard !== ''): ?><div class="alert"><?= escaparIndicador($errorDashboard) ?></div><?php endif; ?>

    <section class="operational-summary" aria-labelledby="operationalTitle">
        <div class="operational-head">
            <div><h2 id="operationalTitle">Indicadores operativos de gestión</h2><p>Señales para anticipar retrasos, controlar el backlog y evaluar la calidad de la atención.</p></div>
            <span>Responden al filtro general</span>
        </div>
        <div class="operational-kpis">
            <article class="operational-kpi">
                <span class="kpi-label">Primera respuesta</span>
                <strong><?= tiempoCalendarioIndicador($resumenGestion['promedio_primera_respuesta']) ?></strong>
                <small>Promedio desde la creación hasta la primera comunicación pública de un gestor.</small>
                <div class="kpi-context"><?= porcentajeIndicador($tasaPrimeraRespuesta) ?> de los casos ya recibieron respuesta</div>
            </article>
            <article class="operational-kpi <?= $casosSlaVencidoAhora > 0 ? 'danger' : ($casosRiesgoSla > 0 ? 'warning' : 'success') ?>">
                <span class="kpi-label">Riesgo de vencimiento SLA</span>
                <strong><?= numeroIndicador($casosRiesgoSla) ?></strong>
                <small>Casos activos que ya consumieron entre el 80 % y el 99,9 % del SLA hábil.</small>
                <div class="kpi-context"><?= numeroIndicador($casosSlaVencidoAhora) ?> vencidos · <?= numeroIndicador($resumenGestion['pendientes_calificacion_vencidos']) ?> pendientes de calificación por más de 24 h</div>
            </article>
            <article class="operational-kpi warning">
                <span class="kpi-label">Antigüedad del backlog</span>
                <strong><?= tiempoCalendarioIndicador($resumenGestion['promedio_antiguedad_backlog']) ?></strong>
                <small>Edad promedio de los casos que todavía no están cerrados ni cancelados.</small>
                <div class="kpi-context"><?= numeroIndicador($resumenGestion['backlog_activo']) ?> casos permanecen activos</div>
            </article>
            <article class="operational-kpi <?= $balancePeriodo >= 0 ? 'success' : 'danger' ?>">
                <span class="kpi-label">Balance entradas vs. cierres</span>
                <strong><?= escaparIndicador($balancePeriodoTexto) ?></strong>
                <small>Casos cerrados menos casos creados dentro del periodo seleccionado.</small>
                <div class="kpi-context <?= escaparIndicador($balancePeriodoClase) ?>"><?= numeroIndicador($totalTicketsGestion) ?> creados · <?= numeroIndicador($resumenGestion['cerrados_periodo']) ?> cerrados</div>
            </article>
            <article class="operational-kpi success">
                <span class="kpi-label">Resolución en primer contacto</span>
                <strong><?= porcentajeIndicador($tasaResolucionPrimerContacto) ?></strong>
                <small>Cerrados sin derivaciones y sin reaperturas frente a los casos cerrados del grupo analizado.</small>
                <div class="kpi-context"><?= numeroIndicador($resumenGestion['resueltos_primer_contacto']) ?> resoluciones directas</div>
            </article>
            <article class="operational-kpi <?= (float) ($tasaReapertura ?? 0) > 10 ? 'danger' : 'purple' ?>">
                <span class="kpi-label">Tasa de reapertura</span>
                <strong><?= porcentajeIndicador($tasaReapertura) ?></strong>
                <small>Casos que necesitaron una nueva gestión después de haber sido marcados como listos.</small>
                <div class="kpi-context"><?= numeroIndicador($resumenGestion['casos_reabiertos']) ?> casos reabiertos</div>
            </article>
            <article class="operational-kpi purple">
                <span class="kpi-label">Tasa de derivación</span>
                <strong><?= porcentajeIndicador($tasaDerivacion) ?></strong>
                <small>Casos que requirieron apoyo de otro proceso dentro del grupo analizado.</small>
                <div class="kpi-context"><?= numeroIndicador($resumenGestion['casos_con_derivacion']) ?> casos con derivaciones</div>
            </article>
            <article class="operational-kpi">
                <span class="kpi-label">Derivaciones por caso</span>
                <strong><?= $resumenGestion['promedio_derivaciones'] === null ? 'Sin datos' : numeroIndicador($resumenGestion['promedio_derivaciones'], 1) ?></strong>
                <small>Promedio calculado únicamente entre los casos que sí necesitaron apoyos.</small>
                <div class="kpi-context"><?= numeroIndicador($resumenEtapas['derivaciones']) ?> derivaciones registradas en total</div>
            </article>
        </div>
    </section>

    <section class="kpis" aria-label="Resumen general">
        <article class="kpi"><span>Tickets totales</span><strong><?= numeroIndicador($resumen['total']) ?></strong><small><?= numeroIndicador($resumen['solicitantes']) ?> solicitantes</small></article>
        <article class="kpi"><span>Casos del flujo</span><strong><?= numeroIndicador($resumenEtapas['etapas']) ?></strong><small>Padres, hijos y descendientes</small></article>
        <article class="kpi"><span>Derivaciones creadas</span><strong><?= numeroIndicador($resumenEtapas['derivaciones']) ?></strong><small>Casos hijos registrados</small></article>
        <article class="kpi"><span>En proceso</span><strong><?= numeroIndicador($resumen['en_proceso']) ?></strong><small>Actualmente activos</small></article>
        <article class="kpi"><span>Casos con SLA pausado</span><strong><?= numeroIndicador($resumenEtapas['pausadas']) ?></strong><small>Esperando el cierre de hijos</small></article>
        <article class="kpi"><span>Casos reabiertos</span><strong><?= numeroIndicador($resumenEtapas['casos_reabiertos']) ?></strong><small>Con una o más reaperturas</small></article>
        <article class="kpi"><span>Pendientes encuesta</span><strong><?= numeroIndicador($resumen['pendiente_calificacion']) ?></strong><small>Esperando calificación</small></article>
        <article class="kpi"><span>Listos pendientes de cierre</span><strong><?= numeroIndicador($resumenEtapas['listos_cierre']) ?></strong><small>Esperando decisión del creador</small></article>
        <article class="kpi"><span>Tickets cerrados</span><strong><?= numeroIndicador($resumen['cerrados']) ?></strong><small>Proceso finalizado</small></article>
        <article class="kpi"><span>Cumplimiento SLA</span><strong><?= porcentajeIndicador($cumplimientoSla) ?></strong><small><?= numeroIndicador($evaluadasSla) ?> etapas evaluadas</small></article>
        <article class="kpi"><span>Casos fuera del SLA</span><strong><?= numeroIndicador($resumenEtapas['fuera_sla']) ?></strong><small>Según el corte oficial en Listo</small></article>
        <article class="kpi"><span>Calificación general</span><strong><?= $promedioCalificacion === null ? 'Sin datos' : calificacionEnteraIndicador($promedioCalificacion) . '/5' ?></strong><small><?= numeroIndicador($resumenCalificacion['calificaciones']) ?> evaluaciones</small></article>
        <article class="kpi"><span>Calificación de procesos</span><strong><?= $promedioCalificacionArea === null ? 'Sin datos' : calificacionEnteraIndicador($promedioCalificacionArea) . '/5' ?></strong><small>Gestión percibida</small></article>
        <article class="kpi"><span>Calificación de tiempos</span><strong><?= $promedioCalificacionTiempo === null ? 'Sin datos' : calificacionEnteraIndicador($promedioCalificacionTiempo) . '/5' ?></strong><small>Oportunidad percibida</small></article>
        <article class="kpi"><span>Encuesta del servicio solicitado</span><strong><?= $promedioEncuestaServicio === null ? 'Sin datos' : calificacionEnteraIndicador($promedioEncuestaServicio) . '/5' ?></strong><small><?= numeroIndicador($resumenEncuestaServicio['calificaciones']) ?> encuestas únicas</small></article>
        <article class="kpi"><span>Evaluaciones internas</span><strong><?= $promedioEvaluacionInterna === null ? 'Sin datos' : calificacionEnteraIndicador($promedioEvaluacionInterna) . '/5' ?></strong><small><?= numeroIndicador($resumenEvaluacionInterna['calificaciones']) ?> casos y derivaciones</small></article>
        <article class="kpi"><span>Tiempo promedio por proceso</span><strong><?= tiempoIndicador($resumenEtapas['promedio_etapa']) ?></strong><small>Minutos hábiles de atención</small></article>
        <article class="kpi"><span>Ciclo promedio del ticket</span><strong><?= tiempoIndicador($resumen['promedio_ciclo']) ?></strong><small>Creación hasta cierre</small></article>
    </section>

    <section class="dashboard">
        <article class="card wide trend-card"><div class="card-head">
            <div class="trend-heading card-head-main"><h2>Evolución de tickets</h2><p>Compare los casos creados y finalizados agrupados por <?= escaparIndicador($configuracionTendencia['nombre']) ?>.</p></div>
            <div class="trend-toolbar">
                <span class="trend-auto-label">Agrupación automática por <?= escaparIndicador($configuracionTendencia['nombre']) ?></span>
                <div class="legend"><span><i></i>Creados <b><?= numeroIndicador($totalTendenciaCreados) ?></b></span><span><i class="closed"></i>Finalizados <b><?= numeroIndicador($totalTendenciaFinalizados) ?></b></span></div>
            </div>
        </div><div class="card-body">
            <?php if (!$tendencia): ?><div class="empty">No hay información para este periodo.</div><?php else: ?>
                <div class="trend-chart" role="img" aria-label="Comparativo lineal de tickets creados y finalizados por <?= escaparIndicador($configuracionTendencia['nombre']) ?>">
                    <div class="trend-axis"><span><?= numeroIndicador($maxTendencia) ?></span><span><?= numeroIndicador($maxTendencia * 2 / 3, $maxTendencia < 2 ? 1 : 0) ?></span><span><?= numeroIndicador($maxTendencia / 3, $maxTendencia < 2 ? 1 : 0) ?></span><span>0</span></div>
                    <div class="trend-plot trend-line-plot">
                        <svg class="trend-line-chart" viewBox="0 0 1000 220" preserveAspectRatio="none" aria-hidden="true">
                            <g class="trend-line-grid">
                                <line x1="18" y1="28" x2="982" y2="28" />
                                <line x1="18" y1="76" x2="982" y2="76" />
                                <line x1="18" y1="124" x2="982" y2="124" />
                                <line x1="18" y1="174" x2="982" y2="174" />
                            </g>
                            <?php if ($tendenciaGraficaAreaCreados !== ''): ?>
                                <polygon class="trend-line-area" points="<?= escaparIndicador($tendenciaGraficaAreaCreados) ?>" />
                                <polyline class="trend-line-created" points="<?= escaparIndicador($tendenciaGraficaLineaCreados) ?>" />
                                <polyline class="trend-line-closed" points="<?= escaparIndicador($tendenciaGraficaLineaFinalizados) ?>" />
                                <?php foreach ($tendenciaGraficaPuntos as $puntoTendencia): ?>
                                    <circle class="trend-line-point created" cx="<?= $puntoTendencia['x'] ?>" cy="<?= $puntoTendencia['y_creados'] ?>" r="4">
                                        <title><?= escaparIndicador($puntoTendencia['etiqueta']) ?>: <?= $puntoTendencia['creados'] ?> creados</title>
                                    </circle>
                                    <circle class="trend-line-point closed" cx="<?= $puntoTendencia['x'] ?>" cy="<?= $puntoTendencia['y_finalizados'] ?>" r="4">
                                        <title><?= escaparIndicador($puntoTendencia['etiqueta']) ?>: <?= $puntoTendencia['finalizados'] ?> finalizados</title>
                                    </circle>
                                    <text class="trend-line-label" x="<?= $puntoTendencia['x'] ?>" y="207"><?= escaparIndicador($puntoTendencia['etiqueta']) ?></text>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </svg>
                    </div>
                </div>
                <div class="trend-note"><span><strong><?= escaparIndicador($configuracionTendencia['descripcion']) ?>.</strong> La gráfica responde al rango y al servicio del filtro general.</span><span>Desplácese horizontalmente cuando existan más periodos.</span></div>
            <?php endif; ?>
        </div></article>

        <article class="card wide created-ranking-card">
            <div class="card-head">
                <div class="card-head-main"><h2>Periodos con más casos creados</h2><p>Identifique cuándo se registró la mayor cantidad de solicitudes dentro del filtro general.</p></div>
                <span class="card-meta">Ranking por <?= escaparIndicador($configuracionTendencia['nombre']) ?></span>
            </div>
            <div class="card-body">
                <?php if (!$periodosCreadosRanking): ?>
                    <div class="empty">No hay casos creados en el periodo seleccionado.</div>
                <?php else: ?>
                    <div class="created-ranking" role="list" aria-label="Periodos con mayor creación de casos">
                        <?php foreach ($periodosCreadosRanking as $indicePeriodo => $periodoCreado): ?>
                            <?php $cantidadCreada = (int) $periodoCreado['creados']; ?>
                            <div class="created-rank-item" role="listitem" title="<?= escaparIndicador($periodoCreado['etiqueta']) ?>: <?= $cantidadCreada ?> casos creados">
                                <div class="created-rank-position"><i><?= $indicePeriodo + 1 ?></i><span><?= escaparIndicador($periodoCreado['etiqueta']) ?></span></div>
                                <div class="created-rank-track" aria-hidden="true"><span class="created-rank-fill" style="width:<?= anchoIndicador($cantidadCreada, $maxPeriodosCreados) ?>%"></span></div>
                                <strong class="created-rank-total"><?= numeroIndicador($cantidadCreada) ?></strong>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="created-ranking-note"><span>Se muestran hasta <strong>10 periodos</strong> ordenados de mayor a menor.</span><span><?= escaparIndicador($configuracionTendencia['descripcion']) ?>.</span></div>
                <?php endif; ?>
            </div>
        </article>

        <article class="card wide classification-card" data-card-key="clasificaciones">
            <div class="card-head">
                <div class="card-head-main"><h2>Casos por clasificación</h2><p>Seleccione una clasificación para consultar únicamente los casos creados con ella.</p></div>
                <span><?= numeroIndicador($totalClasificacion) ?> casos clasificados</span>
            </div>
            <div class="card-body">
                <div class="classification-grid">
                    <?php foreach ($porClasificacion as $clasificacion): ?>
                        <?php $porcentajeClasificacion = porcentajeParteIndicador($clasificacion['total'], $totalClasificacion); ?>
                        <button class="classification-option" type="button" data-classification="<?= escaparIndicador($clasificacion['nombre']) ?>" aria-label="Ver casos clasificados como <?= escaparIndicador($clasificacion['nombre']) ?>">
                            <span class="classification-icon"><?= escaparIndicador(strtoupper(substr(trim((string) $clasificacion['nombre']), 0, 1))) ?></span>
                            <span class="classification-copy"><strong><?= escaparIndicador(ucfirst((string) $clasificacion['nombre'])) ?></strong><small>Ver los casos y abrir su detalle</small></span>
                            <span class="classification-count"><strong><?= numeroIndicador($clasificacion['total']) ?></strong><small><?= numeroIndicador($porcentajeClasificacion, 1) ?>%</small></span>
                            <span class="classification-progress"><span style="width:<?= anchoIndicador($clasificacion['total'], max(1, (float) $maxClasificacion)) ?>%"></span></span>
                        </button>
                    <?php endforeach; ?>
                    <?php if (!$porClasificacion): ?><div class="visual-empty">No hay casos para los filtros seleccionados.</div><?php endif; ?>
                </div>
            </div>
        </article>

        <article class="card third"><div class="card-head"><h2>Tickets por estado</h2><span>Distribución actual</span></div><div class="card-body donut-layout">
            <div class="donut-chart" style="--donut-gradient:<?= escaparIndicador($gradienteEstado) ?>"><span class="donut-center"><strong><?= numeroIndicador($totalEstado) ?></strong><small>Tickets</small></span></div>
            <div class="donut-legend"><?php foreach ($porEstado as $indice => $fila): ?><div class="donut-item" style="--slice-color:<?= $coloresEstado[$indice % count($coloresEstado)] ?>"><i class="donut-dot"></i><span class="donut-label"><?= escaparIndicador(etiquetaEstadoIndicador((string)$fila['nombre'])) ?></span><span class="donut-value"><strong><?= (int)$fila['total'] ?></strong><small><?= numeroIndicador(porcentajeParteIndicador($fila['total'], $totalEstado), 1) ?>%</small></span></div><?php endforeach; ?><?php if(!$porEstado): ?><div class="empty">Sin datos.</div><?php endif; ?></div>
        </div></article>

        <article class="card third"><div class="card-head"><h2>Cumplimiento y satisfacción</h2><span>Etapas evaluadas</span></div><div class="card-body rings">
            <div class="ring-wrap"><div class="ring" style="--value:<?= escaparIndicador((string)($cumplimientoSla ?? 0)) ?>"><strong><?= porcentajeIndicador($cumplimientoSla) ?></strong></div><span>Cumplimiento SLA</span><small><?= numeroIndicador($evaluadasSla) ?> etapas</small></div>
            <div class="ring-wrap"><div class="ring rating" style="--value:<?= escaparIndicador((string)$porcentajeCalificacionArea) ?>"><strong><?= $promedioCalificacionArea === null?'—':calificacionEnteraIndicador($promedioCalificacionArea) ?></strong></div><span>Gestión del proceso</span><small>Escala de 1 a 5</small></div>
            <div class="ring-wrap"><div class="ring time" style="--value:<?= escaparIndicador((string)$porcentajeCalificacionTiempo) ?>"><strong><?= $promedioCalificacionTiempo === null?'—':calificacionEnteraIndicador($promedioCalificacionTiempo) ?></strong></div><span>Tiempo de respuesta</span><small>Escala de 1 a 5</small></div>
        </div></article>

        <article class="card third"><div class="card-head"><h2>Tickets por urgencia</h2><span>Clasificación de entrada</span></div><div class="card-body donut-layout">
            <div class="donut-chart" style="--donut-gradient:<?= escaparIndicador($gradienteUrgencia) ?>"><span class="donut-center"><strong><?= numeroIndicador($totalUrgencia) ?></strong><small>Tickets</small></span></div>
            <div class="donut-legend"><?php foreach ($porUrgencia as $indice => $fila): ?><div class="donut-item" style="--slice-color:<?= $coloresUrgencia[$indice % count($coloresUrgencia)] ?>"><i class="donut-dot"></i><span class="donut-label"><?= escaparIndicador(ucfirst((string)$fila['nombre'])) ?></span><span class="donut-value"><strong><?= (int)$fila['total'] ?></strong><small><?= numeroIndicador(porcentajeParteIndicador($fila['total'], $totalUrgencia), 1) ?>%</small></span></div><?php endforeach; ?><?php if(!$porUrgencia): ?><div class="empty">Sin datos.</div><?php endif; ?></div>
        </div></article>

        <article class="card donut-card-wide"><div class="card-head"><h2>Tickets por tipo</h2><span><?= $cantidadTiposAgrupados > 0 ? 'Top 9 + ' . numeroIndicador($cantidadTiposAgrupados) . ' agrupados en Otros' : numeroIndicador($cantidadTiposTotal) . ' tipos con casos' ?></span><button id="showAllTicketTypes" class="btn" type="button">Ver todos</button></div><div class="card-body donut-layout">
            <div class="donut-chart" style="--donut-gradient:<?= escaparIndicador($gradienteTipo) ?>"><span class="donut-center"><strong><?= numeroIndicador($totalTipo) ?></strong><small>Tickets</small></span></div>
            <div class="donut-legend"><?php foreach ($porTipo as $indice => $fila): ?><div class="donut-item" style="--slice-color:<?= $coloresTipo[$indice % count($coloresTipo)] ?>"><i class="donut-dot"></i><span class="donut-label" title="<?= escaparIndicador($fila['nombre']) ?>"><?= escaparIndicador($fila['nombre']) ?></span><span class="donut-value"><strong><?= (int)$fila['total'] ?></strong><small><?= numeroIndicador(porcentajeParteIndicador($fila['total'], $totalTipo), 1) ?>%</small></span></div><?php endforeach; ?><?php if(!$porTipo): ?><div class="empty">Sin datos.</div><?php endif; ?></div>
        </div></article>

        <article class="card"><div class="card-head"><h2>Distribución de calificaciones</h2><span>Proceso frente a tiempo de respuesta</span></div><div class="card-body rating-donuts">
            <section class="rating-donut"><h3>Gestión del proceso</h3><div class="donut-chart" style="--donut-gradient:<?= escaparIndicador($gradienteCalificacionArea) ?>"><span class="donut-center"><strong><?= numeroIndicador($totalCalificacionArea) ?></strong><small>Respuestas</small></span></div><div class="donut-legend"><?php $indiceColor=0; for($estrella=5;$estrella>=1;$estrella--, $indiceColor++): ?><div class="donut-item" style="--slice-color:<?= $coloresCalificacion[$indiceColor] ?>"><i class="donut-dot"></i><span class="donut-label stars"><?= $estrella ?> ★</span><span class="donut-value"><strong><?= $distribucionCalificacionArea[$estrella] ?></strong><small><?= numeroIndicador(porcentajeParteIndicador($distribucionCalificacionArea[$estrella], $totalCalificacionArea), 1) ?>%</small></span></div><?php endfor; ?></div></section>
            <section class="rating-donut"><h3>Tiempo de respuesta</h3><div class="donut-chart" style="--donut-gradient:<?= escaparIndicador($gradienteCalificacionTiempo) ?>"><span class="donut-center"><strong><?= numeroIndicador($totalCalificacionTiempo) ?></strong><small>Respuestas</small></span></div><div class="donut-legend"><?php $indiceColor=0; for($estrella=5;$estrella>=1;$estrella--, $indiceColor++): ?><div class="donut-item" style="--slice-color:<?= $coloresCalificacion[$indiceColor] ?>"><i class="donut-dot"></i><span class="donut-label stars"><?= $estrella ?> ★</span><span class="donut-value"><strong><?= $distribucionCalificacionTiempo[$estrella] ?></strong><small><?= numeroIndicador(porcentajeParteIndicador($distribucionCalificacionTiempo[$estrella], $totalCalificacionTiempo), 1) ?>%</small></span></div><?php endfor; ?></div></section>
        </div></article>

        <article class="card wide rating-process-card" data-card-key="calificaciones-proceso">
            <div class="card-head">
                <div class="card-head-main">
                    <h2>Cumplimiento de calificaciones por proceso</h2>
                    <p>La calificación promedio de gestión se convierte a porcentaje sobre una escala máxima de 5 estrellas.</p>
                </div>
                <span>Meta <?= numeroIndicador($metaCalificacionProceso, 0) ?>%</span>
            </div>
            <div class="card-body">
                <div class="rating-process-summary">
                    <span><strong><?= numeroIndicador(count($procesosCalificados)) ?></strong> procesos evaluados</span>
                    <span class="good"><strong><?= numeroIndicador($procesosCumplenCalificacion) ?></strong> cumplen la meta</span>
                    <span class="bad"><strong><?= numeroIndicador($procesosNoCumplenCalificacion) ?></strong> por debajo de la meta</span>
                    <?php if ($promedioCumplimientoProcesos !== null): ?>
                        <span><strong><?= numeroIndicador($promedioCumplimientoProcesos, 1) ?>%</strong> promedio general</span>
                    <?php endif; ?>
                </div>
                <div class="rating-process-chart" role="img" aria-label="Cumplimiento de calificaciones por proceso">
                    <?php foreach ($calificacionesPorProceso as $filaCalificacionProceso): ?>
                        <?php
                        $valorBarra = $filaCalificacionProceso['cumplimiento'];
                        $claseBarra = $valorBarra === null
                            ? 'empty'
                            : ((float) $valorBarra >= $metaCalificacionProceso
                                ? 'good'
                                : ((float) $valorBarra >= 75 ? 'warning' : 'danger'));
                        ?>
                        <div class="rating-process-row" title="<?= escaparIndicador($filaCalificacionProceso['nombre']) ?>">
                            <span class="rating-process-label">
                                <?= escaparIndicador($filaCalificacionProceso['nombre']) ?>
                                <small><?= numeroIndicador($filaCalificacionProceso['evaluaciones']) ?> evaluaciones</small>
                            </span>
                            <span class="rating-process-track">
                                <span class="rating-process-fill <?= $claseBarra ?>" style="width:<?= escaparIndicador((string) ($valorBarra ?? 0)) ?>%"></span>
                            </span>
                            <span class="rating-process-value">
                                <?= $valorBarra === null ? 'Sin datos' : numeroIndicador($valorBarra, 1) . '%' ?>
                                <small><?= $filaCalificacionProceso['calificacion'] === null ? '—' : numeroIndicador($filaCalificacionProceso['calificacion'], 2) . ' / 5' ?></small>
                            </span>
                        </div>
                    <?php endforeach; ?>
                    <?php if (!$calificacionesPorProceso): ?>
                        <div class="empty">No hay procesos con casos para los filtros seleccionados.</div>
                    <?php endif; ?>
                </div>
                <div class="rating-process-note">
                    <span><strong>Lectura:</strong> 5/5 equivale a 100%; la meta visual es <?= numeroIndicador($metaCalificacionProceso, 0) ?>%.</span>
                    <span>Los procesos sin evaluaciones se muestran como “Sin datos”.</span>
                </div>
            </div>
        </article>

        <article class="card wide process-base-card" data-card-key="procesos-servicio">
            <div class="card-head">
                <div class="card-head-main">
                    <h2>Base de indicadores por proceso operativo</h2>
                    <p>Relaciona el proceso y el gestor definidos en cada servicio con los resultados del periodo seleccionado.</p>
                </div>
                <span><?= numeroIndicador(count($porProcesoServicio)) ?> procesos configurados</span>
            </div>
            <div class="table-wrap">
                <table class="process-base-table">
                    <thead>
                        <tr>
                            <th>Proceso</th>
                            <th>Gestor(es) responsable(s)</th>
                            <th>Servicios configurados</th>
                            <th>Servicios activos</th>
                            <th>Tickets</th>
                            <th>Casos asignados</th>
                            <th>Atendidos</th>
                            <th>Activos</th>
                            <th>Tiempo hasta Listo</th>
                            <th>Cumplimiento SLA</th>
                            <th>Calificación general</th>
                            <th>Evaluaciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($porProcesoServicio as $filaProceso): ?>
                            <tr>
                                <td class="name"><?= escaparIndicador($filaProceso['proceso']) ?></td>
                                <td><?= escaparIndicador($filaProceso['gestores']) ?></td>
                                <td><?= numeroIndicador($filaProceso['servicios_configurados']) ?></td>
                                <td><?= numeroIndicador($filaProceso['servicios_activos']) ?></td>
                                <td><?= numeroIndicador($filaProceso['tickets']) ?></td>
                                <td><?= numeroIndicador($filaProceso['etapas']) ?></td>
                                <td><?= numeroIndicador($filaProceso['completadas']) ?></td>
                                <td>
                                    <span class="badge <?= (int) $filaProceso['activas'] > 0 ? 'amber' : 'green' ?>">
                                        <?= numeroIndicador($filaProceso['activas']) ?>
                                    </span>
                                </td>
                                <td><?= escaparIndicador(tiempoIndicador($filaProceso['promedio_minutos'])) ?></td>
                                <td>
                                    <span class="badge <?= $filaProceso['cumplimiento_sla'] === null ? 'gray' : ((float) $filaProceso['cumplimiento_sla'] >= 90 ? 'green' : ((float) $filaProceso['cumplimiento_sla'] >= 75 ? 'amber' : 'red')) ?>">
                                        <?= escaparIndicador(porcentajeIndicador($filaProceso['cumplimiento_sla'])) ?>
                                    </span>
                                </td>
                                <td class="stars">
                                    <?= $filaProceso['calificacion'] === null
                                        ? 'Sin datos'
                                        : calificacionEnteraIndicador($filaProceso['calificacion']) . ' ★' ?>
                                </td>
                                <td><?= numeroIndicador($filaProceso['evaluaciones']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (!$porProcesoServicio): ?>
                            <tr><td colspan="12" class="empty">Todavía no hay procesos configurados en los servicios.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>

        <article class="card visual-card" data-card-key="gestores">
            <div class="card-head">
                <div class="card-head-main"><h2>Desempeño detallado por gestor</h2><p>Asignados, atendidos, activos y cumplimiento.</p></div>
                <button class="table-mode-toggle" type="button">Ver tabla</button>
            </div>
            <div class="card-body visual-summary">
                <div class="visual-legend"><span><i></i>Asignados</span><span><i class="green"></i>Atendidos</span><span><i class="amber"></i>Activos</span></div>
                <div class="metric-chart">
                    <?php foreach (array_slice($porGestor, 0, 8) as $fila): ?>
                        <button class="metric-row detail-trigger" type="button" data-detail-kind="gestor" data-detail-title="Gestor: <?= escaparIndicador($fila['nombre']) ?>" data-detail-first-contact="<?= escaparIndicador(tiempoCalendarioIndicador($fila['promedio_primer_contacto'])) ?>" data-detail-message-response="<?= escaparIndicador(tiempoCalendarioIndicador($fila['promedio_respuesta_mensajes'])) ?>">
                            <span class="metric-name" title="<?= escaparIndicador($fila['nombre']) ?>"><?= escaparIndicador($fila['nombre']) ?></span>
                            <span class="metric-bars">
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill" style="width:<?= anchoIndicador($fila['etapas'], $maxGestorVolumen) ?>%"></span></span><small><?= (int) $fila['etapas'] ?></small></span>
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill green" style="width:<?= anchoIndicador($fila['completadas'], $maxGestorVolumen) ?>%"></span></span><small><?= (int) $fila['completadas'] ?></small></span>
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill amber" style="width:<?= anchoIndicador($fila['activas'], $maxGestorVolumen) ?>%"></span></span><small><?= (int) $fila['activas'] ?></small></span>
                            </span>
                            <span class="metric-score"><strong><?= porcentajeIndicador($fila['cumplimiento_sla']) ?></strong><small>SLA</small></span>
                        </button>
                    <?php endforeach; ?>
                    <?php if (!$porGestor): ?><div class="visual-empty">Sin datos de gestores.</div><?php endif; ?>
                </div>
                <div class="chart-caption"><span>Top 8 por volumen del periodo</span><b>Selecciona un gestor para ver sus métricas</b></div>
            </div>
            <div class="table-wrap"><table><thead><tr><th>Gestor</th><th>Tickets</th><th>Casos asignados</th><th>Atendidos</th><th>Activos</th><th>Tiempo hasta Listo</th><th>Cumplimiento SLA</th><th>Gestión del proceso</th><th>Tiempo de respuesta</th><th>General</th><th>Evaluaciones</th></tr></thead><tbody>
                <?php foreach($porGestor as $fila): ?><tr class="selectable-row" data-detail-kind="gestor" data-detail-title="Gestor: <?= escaparIndicador($fila['nombre']) ?>" data-detail-first-contact="<?= escaparIndicador(tiempoCalendarioIndicador($fila['promedio_primer_contacto'])) ?>" data-detail-message-response="<?= escaparIndicador(tiempoCalendarioIndicador($fila['promedio_respuesta_mensajes'])) ?>"><td class="name"><?= escaparIndicador($fila['nombre']) ?></td><td><?= numeroIndicador($fila['tickets']) ?></td><td><?= numeroIndicador($fila['etapas']) ?></td><td><?= numeroIndicador($fila['completadas']) ?></td><td><?= numeroIndicador($fila['activas']) ?></td><td><?= escaparIndicador(tiempoIndicador($fila['promedio_minutos'])) ?></td><td><?= escaparIndicador(porcentajeIndicador($fila['cumplimiento_sla'])) ?></td><td class="stars"><?= $fila['calificacion_area']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion_area']).' ★' ?></td><td class="stars"><?= $fila['calificacion_tiempo']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion_tiempo']).' ★' ?></td><td class="stars"><?= $fila['calificacion']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion']).' ★' ?></td><td><?= numeroIndicador($fila['encuestas']) ?></td></tr><?php endforeach; ?>
                <?php if(!$porGestor): ?><tr><td colspan="11" class="empty">Sin datos de gestores.</td></tr><?php endif; ?>
            </tbody></table></div>
        </article>

        <article class="card visual-card" data-card-key="areas">
            <div class="card-head">
                <div class="card-head-main"><h2>Desempeño por proceso</h2><p>Casos recibidos, atendidos, activos y SLA.</p></div>
                <button class="table-mode-toggle" type="button">Ver tabla</button>
            </div>
            <div class="card-body visual-summary">
                <div class="visual-legend"><span><i></i>Recibidos</span><span><i class="green"></i>Atendidos</span><span><i class="amber"></i>Activos</span></div>
                <div class="metric-chart">
                    <?php foreach (array_slice($porArea, 0, 8) as $fila): ?>
                        <button class="metric-row detail-trigger" type="button" data-detail-kind="area" data-detail-title="Proceso: <?= escaparIndicador($fila['nombre']) ?>" data-area="<?= escaparIndicador($fila['nombre']) ?>">
                            <span class="metric-name" title="<?= escaparIndicador($fila['nombre']) ?>"><?= escaparIndicador($fila['nombre']) ?></span>
                            <span class="metric-bars">
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill" style="width:<?= anchoIndicador($fila['etapas'], $maxAreaVolumen) ?>%"></span></span><small><?= (int) $fila['etapas'] ?></small></span>
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill green" style="width:<?= anchoIndicador($fila['completadas'], $maxAreaVolumen) ?>%"></span></span><small><?= (int) $fila['completadas'] ?></small></span>
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill amber" style="width:<?= anchoIndicador($fila['activas'], $maxAreaVolumen) ?>%"></span></span><small><?= (int) $fila['activas'] ?></small></span>
                            </span>
                            <span class="metric-score"><strong><?= porcentajeIndicador($fila['cumplimiento_sla']) ?></strong><small>SLA</small></span>
                        </button>
                    <?php endforeach; ?>
                    <?php if (!$porArea): ?><div class="visual-empty">Sin datos de procesos.</div><?php endif; ?>
                </div>
                <div class="chart-caption"><span>Top 8 por casos recibidos</span><b>Selecciona un proceso para ver servicios y tickets</b></div>
            </div>
            <div class="table-wrap"><table><thead><tr><th>Proceso</th><th>Tickets</th><th>Casos recibidos</th><th>Atendidos</th><th>Activos</th><th>Tiempo hasta Listo</th><th>Cumplimiento SLA</th><th>Gestión del proceso</th><th>Tiempo de respuesta</th><th>General</th><th>Evaluaciones</th></tr></thead><tbody>
                <?php foreach($porArea as $fila): ?><tr class="selectable-row" data-detail-kind="area" data-detail-title="Proceso: <?= escaparIndicador($fila['nombre']) ?>" data-area="<?= escaparIndicador($fila['nombre']) ?>"><td class="name"><?= escaparIndicador($fila['nombre']) ?></td><td><?= numeroIndicador($fila['tickets']) ?></td><td><?= numeroIndicador($fila['etapas']) ?></td><td><?= numeroIndicador($fila['completadas']) ?></td><td><?= numeroIndicador($fila['activas']) ?></td><td><?= escaparIndicador(tiempoIndicador($fila['promedio_minutos'])) ?></td><td><?= escaparIndicador(porcentajeIndicador($fila['cumplimiento_sla'])) ?></td><td class="stars"><?= $fila['calificacion_area']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion_area']).' ★' ?></td><td class="stars"><?= $fila['calificacion_tiempo']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion_tiempo']).' ★' ?></td><td class="stars"><?= $fila['calificacion']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion']).' ★' ?></td><td><?= numeroIndicador($fila['encuestas']) ?></td></tr><?php endforeach; ?>
                <?php if(!$porArea): ?><tr><td colspan="11" class="empty">Sin datos de procesos.</td></tr><?php endif; ?>
            </tbody></table></div>
        </article>

        <article class="card visual-card" data-card-key="servicios">
            <div class="card-head">
                <div class="card-head-main"><h2>Servicios con mayor volumen</h2><p>Comparativo de casos y atenciones por servicio.</p></div>
                <button class="table-mode-toggle" type="button">Ver tabla</button>
            </div>
            <div class="card-body visual-summary">
                <div class="visual-legend"><span><i></i>Casos</span><span><i class="green"></i>Atendidos</span></div>
                <div class="metric-chart">
                    <?php foreach (array_slice($porServicio, 0, 8) as $fila): ?>
                        <?php $partesServicio = explode(' / ', (string) $fila['nombre'], 2); $areaServicio = $partesServicio[0] ?? ''; ?>
                        <button class="metric-row detail-trigger" type="button" data-detail-kind="servicio" data-detail-title="Servicio: <?= escaparIndicador($fila['nombre']) ?>" data-area="<?= escaparIndicador($areaServicio) ?>">
                            <span class="metric-name" title="<?= escaparIndicador($fila['nombre']) ?>"><?= escaparIndicador($fila['nombre']) ?></span>
                            <span class="metric-bars">
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill" style="width:<?= anchoIndicador($fila['etapas'], $maxServicio) ?>%"></span></span><small><?= (int) $fila['etapas'] ?></small></span>
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill green" style="width:<?= anchoIndicador($fila['completadas'], $maxServicio) ?>%"></span></span><small><?= (int) $fila['completadas'] ?></small></span>
                            </span>
                            <span class="metric-score"><strong><?= porcentajeIndicador($fila['cumplimiento_sla']) ?></strong><small>SLA</small></span>
                        </button>
                    <?php endforeach; ?>
                    <?php if (!$porServicio): ?><div class="visual-empty">Sin datos de servicios.</div><?php endif; ?>
                </div>
                <div class="chart-caption"><span>Top 8 por volumen del periodo</span><b>Selecciona un servicio para ver el detalle</b></div>
            </div>
            <div class="table-wrap"><table><thead><tr><th>Proceso / servicio</th><th>Casos</th><th>Atendidos</th><th>Tiempo hasta Listo</th><th>Cumplimiento SLA</th><th>Gestión del proceso</th><th>Tiempo de respuesta</th><th>General</th><th>Evaluaciones</th></tr></thead><tbody>
                <?php foreach($porServicio as $fila): ?><?php $partesServicio = explode(' / ', (string) $fila['nombre'], 2); $areaServicio = $partesServicio[0] ?? ''; ?><tr class="selectable-row" data-detail-kind="servicio" data-detail-title="Servicio: <?= escaparIndicador($fila['nombre']) ?>" data-area="<?= escaparIndicador($areaServicio) ?>"><td class="name"><?= escaparIndicador($fila['nombre']) ?></td><td><?= numeroIndicador($fila['etapas']) ?></td><td><?= numeroIndicador($fila['completadas']) ?></td><td><?= escaparIndicador(tiempoIndicador($fila['promedio_minutos'])) ?></td><td><?= escaparIndicador(porcentajeIndicador($fila['cumplimiento_sla'])) ?></td><td class="stars"><?= $fila['calificacion_area']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion_area']).' ★' ?></td><td class="stars"><?= $fila['calificacion_tiempo']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion_tiempo']).' ★' ?></td><td class="stars"><?= $fila['calificacion']===null?'Sin datos':calificacionEnteraIndicador($fila['calificacion']).' ★' ?></td><td><?= numeroIndicador($fila['encuestas']) ?></td></tr><?php endforeach; ?>
                <?php if(!$porServicio): ?><tr><td colspan="9" class="empty">Sin datos de servicios.</td></tr><?php endif; ?>
            </tbody></table></div>
        </article>

        <article class="card visual-card" data-card-key="calificaciones">
            <div class="card-head">
                <div class="card-head-main"><h2>Calificaciones recientes por caso</h2><p>Comparativo entre gestión del proceso y tiempo de respuesta.</p></div>
                <button class="table-mode-toggle" type="button">Ver tabla</button>
            </div>
            <div class="card-body visual-summary">
                <div class="visual-legend"><span><i></i>Gestión del proceso</span><span><i class="amber"></i>Tiempo</span></div>
                <div class="metric-chart">
                    <?php foreach (array_slice($detalleCalificaciones, 0, 8) as $evaluacion): ?>
                        <button class="metric-row detail-trigger" type="button" data-detail-kind="calificacion" data-detail-title="Caso <?= escaparIndicador($evaluacion['codigo_caso']) ?> · Ticket #<?= (int) $evaluacion['id_ticket'] ?>" data-ticket-id="<?= (int) $evaluacion['id_ticket'] ?>" data-ticket-url="solicitudes.php?id_ticket=<?= (int) $evaluacion['id_ticket'] ?>&amp;id_nodo=<?= (int) $evaluacion['id_ticket_etapa'] ?>" data-area="<?= escaparIndicador($evaluacion['catalogo_nombre']) ?>">
                            <span class="metric-name" title="<?= escaparIndicador($evaluacion['catalogo_nombre'].' / '.$evaluacion['servicio_nombre']) ?>">Caso <?= escaparIndicador($evaluacion['codigo_caso']) ?></span>
                            <span class="metric-bars">
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill" style="width:<?= anchoIndicador($evaluacion['calificacion_area'], 5) ?>%"></span></span><small><?= numeroIndicador($evaluacion['calificacion_area'], 0) ?>★</small></span>
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill amber" style="width:<?= anchoIndicador($evaluacion['calificacion_tiempo'], 5) ?>%"></span></span><small><?= numeroIndicador($evaluacion['calificacion_tiempo'], 0) ?>★</small></span>
                            </span>
                            <span class="metric-score"><strong><?= numeroIndicador($evaluacion['calificacion'], 1) ?> ★</strong><small>General</small></span>
                        </button>
                    <?php endforeach; ?>
                    <?php if (!$detalleCalificaciones): ?><div class="visual-empty">Sin calificaciones en el periodo.</div><?php endif; ?>
                </div>
                <div class="chart-caption"><span>Últimas 8 evaluaciones</span><b>Selecciona un caso para revisar la evaluación</b></div>
            </div>
            <div class="table-wrap tall"><table><thead><tr><th>Ticket</th><th>Caso</th><th>Tipo</th><th>Evaluador</th><th>Proceso / servicio</th><th>Gestor asignado</th><th>Tiempo hasta Listo</th><th>Resultado SLA</th><th>Gestión del proceso</th><th>Tiempo de respuesta</th><th>General</th><th>Comentario</th><th>Fecha</th></tr></thead><tbody>
                <?php foreach($detalleCalificaciones as $evaluacion): ?><tr class="selectable-row" data-detail-kind="calificacion" data-detail-title="Caso <?= escaparIndicador($evaluacion['codigo_caso']) ?> · Ticket #<?= (int)$evaluacion['id_ticket'] ?>" data-ticket-id="<?= (int)$evaluacion['id_ticket'] ?>" data-ticket-url="solicitudes.php?id_ticket=<?= (int)$evaluacion['id_ticket'] ?>&amp;id_nodo=<?= (int)$evaluacion['id_ticket_etapa'] ?>" data-area="<?= escaparIndicador($evaluacion['catalogo_nombre']) ?>"><td><a class="ticket" href="solicitudes.php?id_ticket=<?= (int)$evaluacion['id_ticket'] ?>&id_nodo=<?= (int)$evaluacion['id_ticket_etapa'] ?>">#<?= (int)$evaluacion['id_ticket'] ?></a></td><td class="name"><?= escaparIndicador($evaluacion['codigo_caso']) ?></td><td><span class="badge blue"><?= escaparIndicador(etiquetaTipoCalificacion((string)$evaluacion['tipo_calificacion'])) ?></span></td><td><?= escaparIndicador($evaluacion['evaluador']) ?></td><td><?= escaparIndicador($evaluacion['catalogo_nombre'].' / '.$evaluacion['servicio_nombre']) ?></td><td><?= escaparIndicador($evaluacion['gestor']) ?></td><td><?= escaparIndicador(tiempoIndicador($evaluacion['minutos_atencion'])) ?></td><td><span class="badge <?= $evaluacion['resultado_sla']==='dentro_sla'?'green':($evaluacion['resultado_sla']==='fuera_sla'?'red':'gray') ?>"><?= escaparIndicador(etiquetaEstadoIndicador((string)$evaluacion['resultado_sla'])) ?></span></td><td class="stars"><?= numeroIndicador($evaluacion['calificacion_area'],0) ?> ★</td><td class="stars"><?= numeroIndicador($evaluacion['calificacion_tiempo'],0) ?> ★</td><td class="stars"><?= numeroIndicador($evaluacion['calificacion'],0) ?> ★</td><td><?php if(trim((string)$evaluacion['comentario'])!==''): ?><details class="comment-detail"><summary>Ver comentario</summary><p><?= escaparIndicador($evaluacion['comentario']) ?></p></details><?php else: ?>Sin comentario<?php endif; ?></td><td><?= escaparIndicador(date('d/m/Y H:i',strtotime((string)$evaluacion['creado_en']))) ?></td></tr><?php endforeach; ?>
                <?php if(!$detalleCalificaciones): ?><tr><td colspan="13" class="empty">Todavía no hay calificaciones detalladas en el periodo.</td></tr><?php endif; ?>
            </tbody></table></div>
        </article>

        <article class="card visual-card solutions-card" data-card-key="soluciones">
            <div class="card-head">
                <div class="card-head-main">
                    <h2>Soluciones más utilizadas por servicio</h2>
                    <p>Frecuencia, participación y observaciones registradas por los gestores.</p>
                </div>
                <button class="table-mode-toggle" type="button">Ver tabla</button>
            </div>
            <div class="card-body visual-summary">
                <div class="visual-legend"><span><i class="green"></i>Usos</span><span><i class="amber"></i>Participación</span></div>
                <div class="metric-chart">
                    <?php foreach (array_slice($porSolucionServicio, 0, 8) as $fila): ?>
                        <?php $partesSolucion = explode(' / ', (string) $fila['servicio'], 2); $areaSolucion = $partesSolucion[0] ?? ''; ?>
                        <button class="metric-row detail-trigger" type="button" data-detail-kind="solucion" data-detail-title="Solución: <?= escaparIndicador($fila['solucion'].' · '.$fila['servicio']) ?>" data-area="<?= escaparIndicador($areaSolucion) ?>">
                            <span class="metric-name" title="<?= escaparIndicador($fila['servicio'].' · '.$fila['solucion']) ?>"><?= escaparIndicador($fila['solucion']) ?></span>
                            <span class="metric-bars">
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill green" style="width:<?= anchoIndicador($fila['total'], $maxSolucion) ?>%"></span></span><small><?= (int) $fila['total'] ?></small></span>
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill amber" style="width:<?= anchoIndicador($fila['porcentaje'], 100) ?>%"></span></span><small><?= numeroIndicador($fila['porcentaje'], 0) ?>%</small></span>
                            </span>
                            <span class="metric-score"><strong><?= escaparIndicador($fila['ultimo_uso'] ? date('d/m', strtotime((string) $fila['ultimo_uso'])) : '—') ?></strong><small>Último uso</small></span>
                        </button>
                    <?php endforeach; ?>
                    <?php if (!$porSolucionServicio): ?><div class="visual-empty">Sin soluciones registradas en el periodo.</div><?php endif; ?>
                </div>
                <div class="chart-caption"><span><?= $idServicioSolucion > 0 ? 'Servicio seleccionado en el filtro' : ($idCatalogoIndicador > 0 ? 'Servicios del proceso seleccionado' : 'Comparativo de todos los servicios') ?></span><b>Selecciona una solución para ver sus datos</b></div>
            </div>
            <div class="table-wrap">
                <table class="solutions-table">
                    <thead>
                        <tr>
                            <th>Proceso / servicio</th>
                            <th>Solución seleccionada</th>
                            <th>Usos</th>
                            <th>Participación dentro del servicio</th>
                            <th>Comentarios</th>
                            <th>Último uso</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($porSolucionServicio as $fila): ?>
                            <?php
                                $comentariosSolucion = $comentariosPorSolucion[
                                    (string) $fila['clave_comentarios']
                                ] ?? [];
                            ?>
                            <?php $partesSolucion = explode(' / ', (string) $fila['servicio'], 2); $areaSolucion = $partesSolucion[0] ?? ''; ?>
                            <tr class="selectable-row" data-detail-kind="solucion" data-detail-title="Solución: <?= escaparIndicador($fila['solucion'].' · '.$fila['servicio']) ?>" data-area="<?= escaparIndicador($areaSolucion) ?>">
                                <td class="name"><?= escaparIndicador($fila['servicio']) ?></td>
                                <td><?= escaparIndicador($fila['solucion']) ?></td>
                                <td><span class="usage-count"><?= numeroIndicador($fila['total']) ?></span></td>
                                <td>
                                    <div class="progress solution-progress">
                                        <span class="track"><span class="bar green" style="width:<?= anchoIndicador($fila['porcentaje'], 100) ?>%"></span></span>
                                        <strong><?= porcentajeIndicador($fila['porcentaje']) ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($comentariosSolucion): ?>
                                        <details class="comment-detail solution-comments">
                                            <summary>Ver comentarios <span><?= count($comentariosSolucion) ?></span></summary>
                                            <div class="solution-comment-list">
                                                <?php foreach ($comentariosSolucion as $comentarioSolucion): ?>
                                                    <article class="solution-comment">
                                                        <div class="solution-comment-head">
                                                            <a class="ticket" href="solicitudes.php?id_ticket=<?= (int) $comentarioSolucion['id_ticket'] ?>&id_nodo=<?= (int) $comentarioSolucion['id_ticket_etapa'] ?>">
                                                                Caso <?= escaparIndicador($comentarioSolucion['codigo_caso']) ?>
                                                            </a>
                                                            <time><?= escaparIndicador($comentarioSolucion['fecha_registro'] ? date('d/m/Y H:i', strtotime((string) $comentarioSolucion['fecha_registro'])) : 'Sin fecha') ?></time>
                                                        </div>
                                                        <small>Gestor: <?= escaparIndicador($comentarioSolucion['gestor']) ?></small>
                                                        <p><?= escaparIndicador($comentarioSolucion['comentario']) ?></p>
                                                    </article>
                                                <?php endforeach; ?>
                                            </div>
                                        </details>
                                    <?php else: ?>
                                        <span class="muted-text">Sin observación</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= escaparIndicador($fila['ultimo_uso'] ? date('d/m/Y H:i', strtotime((string) $fila['ultimo_uso'])) : 'Sin datos') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (!$porSolucionServicio): ?>
                            <tr><td colspan="6" class="empty">No hay casos con solución en el servicio y periodo seleccionados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </article>

        <article class="card visual-card" data-card-key="tickets">
            <div class="card-head">
                <div class="card-head-main"><h2>Detalle general de tickets</h2><p><?= numeroIndicador(count($detalleTickets)) ?> registros en el periodo.</p></div>
                <button class="table-mode-toggle" type="button">Ver tabla</button>
            </div>
            <div class="card-body visual-summary">
                <div class="visual-legend"><span><i class="green"></i>Progreso</span><span><i></i>Cumplimiento SLA</span></div>
                <div class="metric-chart">
                    <?php foreach (array_slice($detalleTickets, 0, 8) as $ticket): ?>
                        <?php $totalEtapas = max(1, (int) $ticket['total_etapas']); $avance = 100 * (int) $ticket['etapas_completadas'] / $totalEtapas; ?>
                        <button class="metric-row detail-trigger" type="button" data-detail-kind="ticket" data-detail-title="Ticket #<?= (int) $ticket['id_ticket'] ?>" data-ticket-id="<?= (int) $ticket['id_ticket'] ?>" data-ticket-url="solicitudes.php?id_ticket=<?= (int) $ticket['id_ticket'] ?>" data-area="<?= escaparIndicador($ticket['area_actual']) ?>" data-classification="<?= escaparIndicador($ticket['clasificacion']) ?>" data-ticket-type="<?= escaparIndicador($ticket['tipo_ticket']) ?>">
                            <span class="metric-name" title="<?= escaparIndicador($ticket['tipo_ticket']) ?>">#<?= (int) $ticket['id_ticket'] ?> · <?= escaparIndicador($ticket['tipo_ticket']) ?></span>
                            <span class="metric-bars">
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill green" style="width:<?= anchoIndicador($avance, 100) ?>%"></span></span><small><?= (int) round($avance) ?>%</small></span>
                                <span class="metric-line"><span class="metric-track"><span class="metric-fill" style="width:<?= anchoIndicador($ticket['cumplimiento_sla'], 100) ?>%"></span></span><small><?= numeroIndicador($ticket['cumplimiento_sla'] ?? 0, 0) ?>%</small></span>
                            </span>
                            <span class="metric-score"><strong><?= escaparIndicador(etiquetaEstadoIndicador((string) $ticket['estado_flujo'])) ?></strong><small><?= escaparIndicador($ticket['area_actual']) ?></small></span>
                        </button>
                    <?php endforeach; ?>
                    <?php if (!$detalleTickets): ?><div class="visual-empty">No hay tickets en el periodo.</div><?php endif; ?>
                </div>
                <div class="chart-caption"><span>Últimos 8 tickets actualizados</span><b>Selecciona un ticket para ver todos sus datos</b></div>
            </div>
            <div class="table-wrap tall"><table><thead><tr><th>Ticket</th><th>Tipo</th><th>Clasificación</th><th>Solicitante</th><th>Estado</th><th>Proceso actual</th><th>Gestor actual</th><th>Progreso</th><th>SLA acumulado</th><th>Gestión del proceso</th><th>Tiempo de respuesta</th><th>General</th><th>Creación</th></tr></thead><tbody>
                <?php foreach($detalleTickets as $ticket): ?><?php $totalEtapas=max(1,(int)$ticket['total_etapas']);$avance=100*(int)$ticket['etapas_completadas']/$totalEtapas; ?><tr class="selectable-row" data-detail-kind="ticket" data-detail-title="Ticket #<?= (int)$ticket['id_ticket'] ?>" data-ticket-id="<?= (int)$ticket['id_ticket'] ?>" data-ticket-url="solicitudes.php?id_ticket=<?= (int)$ticket['id_ticket'] ?>" data-area="<?= escaparIndicador($ticket['area_actual']) ?>" data-classification="<?= escaparIndicador($ticket['clasificacion']) ?>"><td><a class="ticket" href="solicitudes.php?id_ticket=<?= (int)$ticket['id_ticket'] ?>">#<?= (int)$ticket['id_ticket'] ?></a></td><td class="name"><?= escaparIndicador($ticket['tipo_ticket']) ?></td><td><span class="badge blue"><?= escaparIndicador(ucfirst((string)$ticket['clasificacion'])) ?></span></td><td><?= escaparIndicador($ticket['solicitante']) ?></td><td><span class="badge <?= escaparIndicador(claseEstadoIndicador((string)$ticket['estado_flujo'])) ?>"><?= escaparIndicador(etiquetaEstadoIndicador((string)$ticket['estado_flujo'])) ?></span></td><td><?= escaparIndicador($ticket['area_actual']) ?></td><td><?= escaparIndicador($ticket['gestor_actual']) ?></td><td><div class="progress"><span class="track"><span class="bar green" style="width:<?= anchoIndicador($avance,100) ?>%"></span></span><span><?= (int)$ticket['etapas_completadas'] ?>/<?= (int)$ticket['total_etapas'] ?></span></div></td><td><?= escaparIndicador(porcentajeIndicador($ticket['cumplimiento_sla'])) ?></td><td class="stars"><?= $ticket['promedio_area']===null?'—':calificacionEnteraIndicador($ticket['promedio_area']).' ★' ?></td><td class="stars"><?= $ticket['promedio_tiempo']===null?'—':calificacionEnteraIndicador($ticket['promedio_tiempo']).' ★' ?></td><td class="stars"><?= $ticket['promedio_calificacion']===null?'—':calificacionEnteraIndicador($ticket['promedio_calificacion']).' ★' ?></td><td><?= escaparIndicador(date('d/m/Y H:i',strtotime((string)$ticket['fecha_creacion']))) ?></td></tr><?php endforeach; ?>
                <?php if(!$detalleTickets): ?><tr><td colspan="13" class="empty">No hay tickets para el periodo seleccionado.</td></tr><?php endif; ?>
            </tbody></table></div>
        </article>
    </section>
</main>

<div id="drawerBackdrop" class="drawer-backdrop" hidden></div>
<aside id="detailDrawer" class="detail-drawer" aria-hidden="true" aria-labelledby="drawerTitle" inert>
    <header class="drawer-head">
        <div class="drawer-icon">BI</div>
        <div class="drawer-title"><span id="drawerKind">Detalle del indicador</span><h2 id="drawerTitle">Información seleccionada</h2></div>
        <button id="drawerClose" class="drawer-close" type="button" aria-label="Cerrar detalle">×</button>
    </header>
    <div id="drawerBody" class="drawer-body"></div>
    <footer class="drawer-foot">
        <a id="drawerTicketLink" class="btn primary ticket-action" href="#" hidden>Abrir ticket completo</a>
        <button id="drawerCloseBottom" type="button">Cerrar</button>
    </footer>
</aside>

<script>
(function () {
    'use strict';

    var areaFilter = document.getElementById('id_catalogo_indicador');
    var serviceFilter = document.getElementById('id_servicio_solucion');
    var cards = Array.prototype.slice.call(document.querySelectorAll('.dashboard > .card'));
    var collapseAll = document.getElementById('collapseAllCards');
    var expandAll = document.getElementById('expandAllCards');
    var printFullReport = document.getElementById('printFullReport');
    var printReportArea = document.getElementById('printReportArea');
    var printReportService = document.getElementById('printReportService');
    var printDedicatedAgain = document.getElementById('printDedicatedAgain');
    var closePrintWindow = document.getElementById('closePrintWindow');
    var dedicatedPrintMode = <?= $modoImpresion ? 'true' : 'false' ?>;
    var originalDocumentTitle = document.title;
    var drawer = document.getElementById('detailDrawer');
    var backdrop = document.getElementById('drawerBackdrop');
    var drawerTitle = document.getElementById('drawerTitle');
    var drawerKind = document.getElementById('drawerKind');
    var drawerBody = document.getElementById('drawerBody');
    var drawerTicketLink = document.getElementById('drawerTicketLink');
    var allTicketTypes = <?= json_encode(
        array_map(
            static fn (array $fila): array => [
                'nombre' => (string) $fila['nombre'],
                'total' => (int) $fila['total'],
            ],
            $porTipoCompleto
        ),
        JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
        | JSON_HEX_TAG
        | JSON_HEX_AMP
        | JSON_HEX_APOS
        | JSON_HEX_QUOT
        | JSON_INVALID_UTF8_SUBSTITUTE
    ) ?>;
    var totalTicketTypesCases = <?= (int) $totalTipo ?>;
    var storagePrefix = 'mesa-indicadores-card:';

    function filterServicesByArea() {
        if (!areaFilter || !serviceFilter) return;
        var selectedArea = areaFilter.value;
        var selectedOption = serviceFilter.options[serviceFilter.selectedIndex];

        Array.prototype.forEach.call(serviceFilter.options, function (option, index) {
            if (index === 0) return;
            var visible = selectedArea === '0' || option.dataset.area === selectedArea;
            option.hidden = !visible;
            option.disabled = !visible;
        });

        if (selectedOption && selectedOption.disabled) {
            serviceFilter.value = '0';
        }
    }

    if (areaFilter && serviceFilter) {
        areaFilter.addEventListener('change', filterServicesByArea);
        filterServicesByArea();
    }

    function slug(text) {
        return String(text || 'seccion')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '');
    }

    function storeCard(card, collapsed) {
        try {
            window.localStorage.setItem(storagePrefix + card.dataset.cardKey, collapsed ? '1' : '0');
        } catch (error) {
            /* La interfaz sigue funcionando aunque el navegador bloquee almacenamiento local. */
        }
    }

    function savedCardState(card) {
        try {
            return window.localStorage.getItem(storagePrefix + card.dataset.cardKey);
        } catch (error) {
            return null;
        }
    }

    function setCardCollapsed(card, collapsed, persist) {
        var toggle = card.querySelector(':scope > .card-head .card-toggle');
        card.classList.toggle('is-collapsed', collapsed);
        if (toggle) {
            toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
            toggle.lastChild.nodeValue = collapsed ? ' Maximizar' : ' Minimizar';
        }
        if (persist !== false) {
            storeCard(card, collapsed);
        }
    }

    cards.forEach(function (card, index) {
        var head = card.querySelector(':scope > .card-head');
        if (!head) return;

        var heading = head.querySelector('h2');
        card.dataset.cardKey = card.dataset.cardKey || slug(heading ? heading.textContent : 'seccion-' + index);

        var main = head.querySelector(':scope > .card-head-main');
        if (!main) {
            main = document.createElement('div');
            main.className = 'card-head-main';
            if (heading) main.appendChild(heading);
            head.insertBefore(main, head.firstChild);
        }

        var actions = document.createElement('div');
        actions.className = 'card-head-actions';
        Array.prototype.slice.call(head.children).forEach(function (child) {
            if (child === main || child === actions) return;
            if (child.matches('span') && !child.classList.contains('card-meta')) {
                child.classList.add('card-meta');
            }
            actions.appendChild(child);
        });

        var toggle = document.createElement('button');
        toggle.className = 'card-toggle';
        toggle.type = 'button';
        toggle.appendChild(document.createTextNode(' Minimizar'));
        toggle.addEventListener('click', function () {
            setCardCollapsed(card, !card.classList.contains('is-collapsed'));
        });
        actions.appendChild(toggle);
        head.appendChild(actions);

        var saved = savedCardState(card);
        setCardCollapsed(card, saved === '1', false);
    });

    document.querySelectorAll('.table-mode-toggle').forEach(function (button) {
        button.addEventListener('click', function () {
            var card = button.closest('.visual-card');
            var tableOpen = card.classList.toggle('is-table-open');
            button.lastChild.nodeValue = tableOpen ? ' Ver gráfico' : ' Ver tabla';
            button.setAttribute('aria-pressed', tableOpen ? 'true' : 'false');
        });
    });

    if (collapseAll) {
        collapseAll.addEventListener('click', function () {
            cards.forEach(function (card) { setCardCollapsed(card, true); });
        });
    }

    if (expandAll) {
        expandAll.addEventListener('click', function () {
            cards.forEach(function (card) { setCardCollapsed(card, false); });
        });
    }

    function selectedFilterText(select, fallback) {
        if (!select || select.selectedIndex < 0) return fallback;
        var option = select.options[select.selectedIndex];
        return option ? option.textContent.trim() : fallback;
    }

    function prepareFullReport() {
        if (printReportArea) {
            printReportArea.textContent = selectedFilterText(areaFilter, 'Todos los procesos');
        }
        if (printReportService) {
            printReportService.textContent = selectedFilterText(serviceFilter, 'Todos los servicios');
        }
        document.body.classList.add('printing-full-report');
        document.title = 'Reporte integral de indicadores - SMARTDESK';
    }

    function restoreAfterPrint() {
        if (!dedicatedPrintMode) {
            document.body.classList.remove('printing-full-report');
        }
        document.title = originalDocumentTitle;
    }

    if (printFullReport) {
        printFullReport.addEventListener('click', function () {
            var printUrl = new URL(window.location.href);
            printUrl.searchParams.set('imprimir', '1');
            var printWindow = window.open(printUrl.toString(), '_blank');
            if (printWindow) {
                printWindow.opener = null;
            } else {
                window.alert('El navegador bloqueó la ventana del reporte. Permita las ventanas emergentes para imprimirlo completo.');
            }
        });
    }
    if (printDedicatedAgain) {
        printDedicatedAgain.addEventListener('click', function () {
            prepareFullReport();
            window.setTimeout(function () { window.print(); }, 0);
        });
    }
    if (closePrintWindow) {
        closePrintWindow.addEventListener('click', function () { window.close(); });
    }
    window.addEventListener('beforeprint', prepareFullReport);
    window.addEventListener('afterprint', restoreAfterPrint);
    if (dedicatedPrintMode) {
        prepareFullReport();
        window.setTimeout(function () { window.print(); }, 500);
    }

    function createDetailItem(label, value) {
        var item = document.createElement('div');
        item.className = 'detail-item' + (String(value).length > 75 ? ' full' : '');
        var labelNode = document.createElement('span');
        var valueNode = document.createElement('strong');
        labelNode.textContent = label || 'Dato';
        valueNode.textContent = value || 'Sin datos';
        item.appendChild(labelNode);
        item.appendChild(valueNode);
        return item;
    }

    function rowValues(row) {
        var table = row.closest('table');
        var headers = table ? Array.prototype.slice.call(table.querySelectorAll('thead th')) : [];
        return Array.prototype.slice.call(row.cells || []).map(function (cell, index) {
            var comentarios = cell.querySelectorAll('.solution-comment');
            return {
                label: headers[index] ? headers[index].textContent.trim() : 'Dato ' + (index + 1),
                value: comentarios.length
                    ? comentarios.length + (comentarios.length === 1 ? ' comentario registrado' : ' comentarios registrados')
                    : cell.textContent.replace(/\s+/g, ' ').trim()
            };
        });
    }

    function solutionCommentsSection(row) {
        var source = row.querySelector('.solution-comment-list');
        if (!source) return null;
        var section = document.createElement('section');
        var heading = document.createElement('h3');
        var comments = source.querySelectorAll('.solution-comment').length;
        section.className = 'drawer-section drawer-comments';
        heading.textContent = comments === 1
            ? 'Comentario registrado'
            : 'Comentarios registrados (' + comments + ')';
        section.appendChild(heading);
        section.appendChild(source.cloneNode(true));
        return section;
    }

    function kindLabel(kind) {
        var labels = {
            area: 'Detalle del proceso',
            servicio: 'Detalle del servicio',
            gestor: 'Detalle del gestor',
            ticket: 'Detalle del ticket',
            tipo: 'Tickets por tipo',
            clasificacion: 'Casos por clasificación',
            calificacion: 'Detalle de la evaluación',
            solucion: 'Detalle de la solución'
        };
        return labels[kind] || 'Detalle del indicador';
    }

    function relatedSection(title, rows, labelBuilder, paginated) {
        if (!rows.length) return null;
        var section = document.createElement('section');
        section.className = 'drawer-section';
        var heading = document.createElement('h3');
        var list = document.createElement('ul');
        var pageSize = paginated ? 10 : rows.length;
        var currentPage = 1;
        var totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
        heading.textContent = title + ' (' + rows.length + ')';
        list.className = 'related-list';
        function renderRows() {
            list.textContent = '';
            var inicio = paginated ? (currentPage - 1) * pageSize : 0;
            var fin = paginated ? inicio + pageSize : rows.length;
            rows.slice(inicio, fin).forEach(function (row) {
                var item = document.createElement('li');
                var button = document.createElement('button');
                var main = document.createElement('b');
                var meta = document.createElement('span');
                var detalle = labelBuilder(row);
                button.type = 'button';
                button.className = 'related-row';
                main.textContent = detalle.main;
                meta.textContent = detalle.meta;
                button.appendChild(main);
                button.appendChild(meta);
                button.addEventListener('click', function () { openRowDetail(row); });
                item.appendChild(button);
                list.appendChild(item);
            });
        }

        section.appendChild(heading);
        section.appendChild(list);
        if (paginated && totalPages > 1) {
            var pagination = document.createElement('div');
            var previous = document.createElement('button');
            var pageLabel = document.createElement('span');
            var next = document.createElement('button');
            pagination.className = 'drawer-pagination';
            previous.type = 'button';
            previous.textContent = 'Anterior';
            next.type = 'button';
            next.textContent = 'Siguiente';
            pageLabel.setAttribute('aria-live', 'polite');

            function updatePagination() {
                var firstVisible = ((currentPage - 1) * pageSize) + 1;
                var lastVisible = Math.min(currentPage * pageSize, rows.length);
                pageLabel.textContent = 'Página ' + currentPage + ' de ' + totalPages
                    + ' · ' + firstVisible + '-' + lastVisible + ' de ' + rows.length;
                previous.disabled = currentPage === 1;
                next.disabled = currentPage === totalPages;
            }

            previous.addEventListener('click', function () {
                if (currentPage > 1) {
                    currentPage -= 1;
                    renderRows();
                    updatePagination();
                }
            });
            next.addEventListener('click', function () {
                if (currentPage < totalPages) {
                    currentPage += 1;
                    renderRows();
                    updatePagination();
                }
            });
            pagination.appendChild(previous);
            pagination.appendChild(pageLabel);
            pagination.appendChild(next);
            section.appendChild(pagination);
            updatePagination();
        }
        renderRows();
        return section;
    }

    function showDrawer(kind, title, ticketUrl) {
        drawerKind.textContent = kindLabel(kind);
        drawerTitle.textContent = title;
        if (ticketUrl) {
            drawerTicketLink.href = ticketUrl;
            drawerTicketLink.hidden = false;
        } else {
            drawerTicketLink.hidden = true;
        }

        backdrop.hidden = false;
        drawer.classList.add('is-open');
        drawer.setAttribute('aria-hidden', 'false');
        drawer.removeAttribute('inert');
        document.body.classList.add('drawer-open');
        document.getElementById('drawerClose').focus();
    }

    function classificationKey(value) {
        return String(value || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .trim()
            .toLocaleLowerCase('es');
    }

    function openTicketTypeDetail(typeName) {
        var targetKey = classificationKey(typeName);
        var tickets = Array.prototype.slice.call(
            document.querySelectorAll('tr.selectable-row[data-detail-kind="ticket"]')
        ).filter(function (row) {
            return classificationKey(row.cells[1] ? row.cells[1].textContent : '') === targetKey;
        });
        var summary = document.createElement('div');
        summary.className = 'detail-grid';
        summary.appendChild(createDetailItem('Tipo de ticket', typeName));
        summary.appendChild(createDetailItem('Casos encontrados', String(tickets.length)));
        drawerBody.textContent = '';
        drawerBody.appendChild(summary);

        var ticketSection = relatedSection(
            'Casos de este tipo',
            tickets,
            function (row) {
                return {
                    main: row.dataset.detailTitle,
                    meta: row.cells[4].textContent.trim()
                };
            },
            true
        );
        if (ticketSection) {
            drawerBody.appendChild(ticketSection);
        } else {
            var empty = document.createElement('p');
            empty.className = 'type-list-empty';
            empty.textContent = 'No hay casos de este tipo dentro de los filtros actuales.';
            drawerBody.appendChild(empty);
        }
        showDrawer('tipo', typeName, '');
    }

    function openAllTicketTypes() {
        var pageSize = 10;
        var currentPage = 1;
        var filteredTypes = allTicketTypes.slice();
        var summary = document.createElement('div');
        var search = document.createElement('input');
        var section = document.createElement('section');
        var heading = document.createElement('h3');
        var resultLabel = document.createElement('p');
        var list = document.createElement('ul');
        var pagination = document.createElement('div');
        var previous = document.createElement('button');
        var pageLabel = document.createElement('span');
        var next = document.createElement('button');

        summary.className = 'detail-grid';
        summary.appendChild(createDetailItem('Tipos con casos', String(allTicketTypes.length)));
        summary.appendChild(createDetailItem('Tickets incluidos', String(totalTicketTypesCases)));
        search.className = 'drawer-search';
        search.type = 'search';
        search.placeholder = 'Buscar servicio o tipo de ticket…';
        search.setAttribute('aria-label', 'Buscar tipo de ticket');
        section.className = 'drawer-section';
        heading.textContent = 'Listado completo';
        resultLabel.className = 'type-list-summary';
        list.className = 'related-list';
        pagination.className = 'drawer-pagination';
        previous.type = 'button';
        previous.textContent = 'Anterior';
        next.type = 'button';
        next.textContent = 'Siguiente';
        pagination.appendChild(previous);
        pagination.appendChild(pageLabel);
        pagination.appendChild(next);
        section.appendChild(heading);
        section.appendChild(resultLabel);
        section.appendChild(list);
        section.appendChild(pagination);
        drawerBody.textContent = '';
        drawerBody.appendChild(summary);
        drawerBody.appendChild(search);
        drawerBody.appendChild(section);

        function renderTypes() {
            var totalPages = Math.max(1, Math.ceil(filteredTypes.length / pageSize));
            if (currentPage > totalPages) currentPage = totalPages;
            var start = (currentPage - 1) * pageSize;
            list.textContent = '';
            filteredTypes.slice(start, start + pageSize).forEach(function (type) {
                var item = document.createElement('li');
                var button = document.createElement('button');
                var name = document.createElement('b');
                var meta = document.createElement('span');
                var percentage = totalTicketTypesCases > 0
                    ? (100 * Number(type.total || 0) / totalTicketTypesCases).toFixed(1).replace('.', ',')
                    : '0,0';
                button.type = 'button';
                button.className = 'related-row';
                name.textContent = type.nombre;
                meta.textContent = type.total + ' casos · ' + percentage + '%';
                button.appendChild(name);
                button.appendChild(meta);
                button.addEventListener('click', function () {
                    openTicketTypeDetail(type.nombre);
                });
                item.appendChild(button);
                list.appendChild(item);
            });
            if (!filteredTypes.length) {
                var emptyItem = document.createElement('li');
                emptyItem.className = 'type-list-empty';
                emptyItem.textContent = 'No se encontraron coincidencias.';
                list.appendChild(emptyItem);
            }
            resultLabel.textContent = filteredTypes.length + (filteredTypes.length === 1 ? ' resultado' : ' resultados');
            pageLabel.textContent = 'Página ' + currentPage + ' de ' + totalPages;
            previous.disabled = currentPage === 1;
            next.disabled = currentPage === totalPages;
            pagination.hidden = totalPages <= 1;
        }

        search.addEventListener('input', function () {
            var query = classificationKey(search.value);
            filteredTypes = allTicketTypes.filter(function (type) {
                return classificationKey(type.nombre).includes(query);
            });
            currentPage = 1;
            renderTypes();
        });
        previous.addEventListener('click', function () {
            if (currentPage > 1) {
                currentPage -= 1;
                renderTypes();
            }
        });
        next.addEventListener('click', function () {
            var totalPages = Math.max(1, Math.ceil(filteredTypes.length / pageSize));
            if (currentPage < totalPages) {
                currentPage += 1;
                renderTypes();
            }
        });
        renderTypes();
        showDrawer('tipo', 'Todos los tipos de ticket', '');
        window.setTimeout(function () { search.focus(); }, 0);
    }

    function openClassificationDetail(button) {
        var classification = button.dataset.classification || 'Sin clasificación';
        var targetKey = classificationKey(classification);
        var tickets = Array.prototype.slice.call(
            document.querySelectorAll('tr.selectable-row[data-detail-kind="ticket"]')
        ).filter(function (row) {
            return classificationKey(row.dataset.classification) === targetKey;
        });
        var summary = document.createElement('div');
        summary.className = 'detail-grid';
        summary.appendChild(createDetailItem('Clasificación', classification));
        summary.appendChild(createDetailItem('Casos encontrados', String(tickets.length)));
        drawerBody.textContent = '';
        drawerBody.appendChild(summary);

        var ticketSection = relatedSection(
            'Casos creados como ' + classification,
            tickets,
            function (row) {
                return {
                    main: row.dataset.detailTitle + ' · ' + row.cells[1].textContent.trim(),
                    meta: row.cells[4].textContent.trim()
                };
            },
            true
        );
        if (ticketSection) {
            drawerBody.appendChild(ticketSection);
        }
        showDrawer('clasificacion', 'Clasificación: ' + classification, '');
    }

    function openRowDetail(row) {
        var kind = row.dataset.detailKind || 'indicador';
        var title = row.dataset.detailTitle || 'Información seleccionada';
        var grid = document.createElement('div');
        var area = row.dataset.area || '';
        grid.className = 'detail-grid';
        drawerBody.textContent = '';

        rowValues(row).forEach(function (detail) {
            grid.appendChild(createDetailItem(detail.label, detail.value));
            if (kind === 'gestor' && detail.label === 'Tiempo hasta Listo') {
                grid.appendChild(createDetailItem('Tiempo promedio de primer contacto', row.dataset.detailFirstContact));
                grid.appendChild(createDetailItem('Tiempo promedio de respuesta de mensajes', row.dataset.detailMessageResponse));
            }
        });
        drawerBody.appendChild(grid);

        if (kind === 'solucion') {
            var commentsSection = solutionCommentsSection(row);
            if (commentsSection) drawerBody.appendChild(commentsSection);
        }

        if (kind === 'area' && area) {
            var services = Array.prototype.slice.call(document.querySelectorAll('tr.selectable-row[data-detail-kind="servicio"]')).filter(function (candidate) {
                return candidate.dataset.area === area;
            });
            var tickets = Array.prototype.slice.call(document.querySelectorAll('tr.selectable-row[data-detail-kind="ticket"]')).filter(function (candidate) {
                return candidate.dataset.area === area;
            });
            var serviceSection = relatedSection('Servicios del proceso', services, function (candidate) {
                return {main: candidate.cells[0].textContent.trim(), meta: candidate.cells[1].textContent.trim() + ' casos'};
            }, true);
            var ticketSection = relatedSection('Tickets actualmente en el proceso', tickets, function (candidate) {
                return {main: candidate.dataset.detailTitle, meta: candidate.cells[4].textContent.trim()};
            });
            if (serviceSection) drawerBody.appendChild(serviceSection);
            if (ticketSection) drawerBody.appendChild(ticketSection);
        }

        if ((kind === 'servicio' || kind === 'solucion') && area) {
            var areaTickets = Array.prototype.slice.call(document.querySelectorAll('tr.selectable-row[data-detail-kind="ticket"]')).filter(function (candidate) {
                return candidate.dataset.area === area;
            });
            var relatedTickets = relatedSection('Tickets actuales del proceso relacionado', areaTickets, function (candidate) {
                return {main: candidate.dataset.detailTitle, meta: candidate.cells[4].textContent.trim()};
            });
            if (relatedTickets) drawerBody.appendChild(relatedTickets);
        }

        showDrawer(kind, title, row.dataset.ticketUrl || '');
    }

    function closeDrawer() {
        drawer.classList.remove('is-open');
        drawer.setAttribute('aria-hidden', 'true');
        drawer.setAttribute('inert', '');
        document.body.classList.remove('drawer-open');
        window.setTimeout(function () { backdrop.hidden = true; }, 220);
    }

    document.querySelectorAll('tr.selectable-row').forEach(function (row) {
        row.tabIndex = 0;
        row.setAttribute('role', 'button');
        row.setAttribute('aria-label', 'Ver ' + (row.dataset.detailTitle || 'detalle'));
        row.addEventListener('click', function (event) {
            if (event.target.closest('a, button, summary, details, input, select, textarea')) return;
            openRowDetail(row);
        });
        row.addEventListener('keydown', function (event) {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                openRowDetail(row);
            }
        });
    });

    document.querySelectorAll('.detail-trigger').forEach(function (trigger) {
        trigger.addEventListener('click', function () {
            var match = Array.prototype.slice.call(document.querySelectorAll('tr.selectable-row')).find(function (row) {
                return row.dataset.detailKind === trigger.dataset.detailKind
                    && row.dataset.detailTitle === trigger.dataset.detailTitle;
            });
            if (match) openRowDetail(match);
        });
    });

    document.querySelectorAll('.classification-option').forEach(function (button) {
        button.addEventListener('click', function () {
            openClassificationDetail(button);
        });
    });

    var showAllTicketTypes = document.getElementById('showAllTicketTypes');
    if (showAllTicketTypes) {
        showAllTicketTypes.addEventListener('click', openAllTicketTypes);
    }

    document.getElementById('drawerClose').addEventListener('click', closeDrawer);
    document.getElementById('drawerCloseBottom').addEventListener('click', closeDrawer);
    backdrop.addEventListener('click', closeDrawer);
    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && drawer.classList.contains('is-open')) closeDrawer();
    });
}());
</script>
<script src="assets/js/controlSesion.js" defer></script>
</body>
</html>
