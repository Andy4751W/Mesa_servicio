<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';

/*
 * El registro público fue retirado. Solo el administrador puede crear
 * cuentas de Administrador o Gestor desde el módulo Usuarios.
 */
seguridadExigirRol([1]);

header('Location: crearUsuarios.php', true, 303);
exit;
