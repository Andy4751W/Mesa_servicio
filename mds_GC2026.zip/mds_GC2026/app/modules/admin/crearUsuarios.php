<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/ubicacion.php';
require_once APP_ROOT . '/core/fuentePersonal.php';
seguridadExigirRol([1]);
$idPaisOperacion = paisExigirContexto();
$nombrePaisOperacion = paisContextoNombre();
$codigoPaisOperacion = paisContextoCodigo();
$opcionesUbicacion = ubicacionListarOpciones($conn, $idPaisOperacion);

function escaparUsuario($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function valorCsvUsuario($valor): string
{
    $texto = (string) $valor;

    return preg_match('/^[=+\-@]/', $texto) === 1 ? "'" . $texto : $texto;
}

function volverUsuarios(string $mensaje): void
{
    header(
        'Location: crearUsuarios.php?msg=' . rawurlencode($mensaje),
        true,
        303
    );
    exit;
}

$mensajes = [
    'creado' => ['ok', 'El usuario fue creado correctamente.'],
    'actualizado' => ['ok', 'El estado del usuario fue actualizado.'],
    'desbloqueado' => ['ok', 'El usuario fue desbloqueado. Ya puede intentar iniciar sesión nuevamente.'],
    'permiso_actualizado' => ['ok', 'El permiso de consulta global fue actualizado.'],
    'datos_incompletos' => ['error', 'Complete todos los campos obligatorios.'],
    'correo_invalido' => ['error', 'El correo electrónico no es válido.'],
    'password_invalido' => ['error', 'La contraseña debe tener mínimo 8 caracteres, una letra mayúscula y un número.'],
    'password_no_coincide' => ['error', 'La contraseña y su confirmación no coinciden.'],
    'rol_invalido' => ['error', 'Seleccione un rol válido.'],
    'ubicacion_invalida' => ['error', 'Seleccione el país, el departamento y la ciudad en el orden indicado.'],
    'duplicado' => ['error', 'La cédula o el correo ya pertenecen a otro usuario.'],
    'personal_no_activo' => ['error', 'La cédula está registrada como retirada o inactiva en Uniclass.'],
    'autoproteccion' => ['error', 'No puede inhabilitar su propia cuenta.'],
    'solicitud_invalida' => ['error', 'La solicitud no es válida. Actualice la página.'],
    'error' => ['error', 'No fue posible completar la operación.'],
];

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    seguridadExigirOrigenPost();
    seguridadExigirCsrfPost();
    $accion = (string) ($_POST['accion'] ?? '');

    if ($accion === 'buscar_personal') {
        header('Content-Type: application/json; charset=utf-8');
        $cedula = seguridadTexto($_POST['cedula'] ?? '', 30);

        try {
            $estadoPersonal = null;
            $personal = fuentePersonalBuscar($cedula, $estadoPersonal);
            echo json_encode(
                [
                    'ok' => true,
                    'data' => $personal,
                    'estado' => $estadoPersonal === 'R' ? 'retirado' : null,
                ],
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
            );
        } catch (Throwable $e) {
            error_log('No fue posible consultar personal externo: ' . $e->getMessage());
            http_response_code(503);
            echo json_encode(['ok' => false, 'error' => 'consulta_no_disponible']);
        }
        exit;
    }

    if ($accion === 'crear') {
        $cedula = seguridadTexto($_POST['cedula'] ?? '', 30);
        $nombre = seguridadTexto($_POST['nombre'] ?? '', 160);
        $proceso = seguridadTexto($_POST['proceso'] ?? '', 120);
        $cu1 = seguridadTexto($_POST['cu1'] ?? '', 120);
        $cu3 = seguridadTexto($_POST['cu3'] ?? '', 120);
        $email = strtolower(seguridadTexto($_POST['email'] ?? '', 190));
        $descripcion = seguridadTexto($_POST['descripcion_cu1'] ?? '', 500);
        $empresa = seguridadTexto($_POST['empresa'] ?? '', 160);
        $ciudad = seguridadTexto($_POST['ciudad'] ?? '', 160);
        $passwordPlano = (string) ($_POST['password'] ?? '');
        $confirmacionPassword = (string) ($_POST['password_confirmation'] ?? '');
        $rol = filter_input(INPUT_POST, 'id_rol', FILTER_VALIDATE_INT) ?: 0;
        $permisoConsultaGlobal = !empty($_POST['puede_consultar_global']) ? 1 : 0;

        try {
            $estadoPersonal = null;
            fuentePersonalBuscar($cedula, $estadoPersonal);
            if ($estadoPersonal !== null && $estadoPersonal !== 'A') {
                volverUsuarios('personal_no_activo');
            }
        } catch (Throwable $e) {
            error_log('No fue posible validar personal externo al crear usuario: ' . $e->getMessage());
            // Uniclass funciona como fuente de autocompletado. Si no está
            // disponible, el administrador puede continuar con los datos
            // diligenciados manualmente.
        }

        if (
            $cedula === ''
            || $nombre === ''
            || $proceso === ''
            || $cu1 === ''
            || $cu3 === ''
            || $email === ''
            || $descripcion === ''
            || $empresa === ''
        ) {
            volverUsuarios('datos_incompletos');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            volverUsuarios('correo_invalido');
        }

        if (!in_array($rol, [1, 2, 3], true)) {
            volverUsuarios('rol_invalido');
        }

        if (!seguridadPasswordValida($passwordPlano)) {
            volverUsuarios('password_invalido');
        }

        if (!hash_equals($passwordPlano, $confirmacionPassword)) {
            volverUsuarios('password_no_coincide');
        }

        try {
            $password = password_hash($passwordPlano, PASSWORD_DEFAULT);
            $stmt = $conn->prepare(
                "INSERT INTO usuarios
                    (
                        cedula,
                        nombre,
                        proceso,
                        cu1,
                        cu3,
                        email,
                        descripcion_cu1,
                        ciudad,
                        empresa,
                        password,
                        id_rol,
                        puede_consultar_global,
                        id_pais_operacion,
                        estado
                    )
                 VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'activo'
                 )"
            );
            $stmt->bind_param(
                'ssssssssssiii',
                $cedula,
                $nombre,
                $proceso,
                $cu1,
                $cu3,
                $email,
                $descripcion,
                $ciudad,
                $empresa,
                $password,
                $rol,
                $permisoConsultaGlobal,
                $idPaisOperacion
            );
            $stmt->execute();
            $stmt->close();
            volverUsuarios('creado');
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() === 1062) {
                volverUsuarios('duplicado');
            }

            error_log('No fue posible crear el usuario: ' . $e->getMessage());
            volverUsuarios('error');
        } catch (Throwable $e) {
            error_log('No fue posible crear el usuario: ' . $e->getMessage());
            volverUsuarios('error');
        }
    }

    if ($accion === 'estado') {
        $idUsuario = filter_input(
            INPUT_POST,
            'id_usuario',
            FILTER_VALIDATE_INT
        ) ?: 0;
        $estado = (string) ($_POST['estado'] ?? '');

        if ($idUsuario < 1 || !in_array($estado, ['activo', 'inhabilitado'], true)) {
            volverUsuarios('solicitud_invalida');
        }

        if (
            $idUsuario === (int) $_SESSION['usuario_id']
            && $estado !== 'activo'
        ) {
            volverUsuarios('autoproteccion');
        }

        try {
            $stmt = $conn->prepare(
                "UPDATE usuarios
                 SET estado = ?
                 WHERE id_usuario = ?
                   AND (id_rol = 1 OR id_pais_operacion = ?)"
            );
            $stmt->bind_param('sii', $estado, $idUsuario, $idPaisOperacion);
            $stmt->execute();
            $stmt->close();
            volverUsuarios('actualizado');
        } catch (Throwable $e) {
            error_log('No fue posible actualizar el usuario: ' . $e->getMessage());
            volverUsuarios('error');
        }
    }

    if ($accion === 'desbloquear_login') {
        $idUsuario = filter_input(
            INPUT_POST,
            'id_usuario',
            FILTER_VALIDATE_INT
        ) ?: 0;

        if ($idUsuario < 1) {
            volverUsuarios('solicitud_invalida');
        }

        try {
            $stmt = $conn->prepare(
                "SELECT email
                 FROM usuarios
                 WHERE id_usuario = ?
                   AND (id_rol = 1 OR id_pais_operacion = ?)
                 LIMIT 1"
            );
            $stmt->bind_param('ii', $idUsuario, $idPaisOperacion);
            $stmt->execute();
            $usuarioBloqueado = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$usuarioBloqueado || trim((string) ($usuarioBloqueado['email'] ?? '')) === '') {
                volverUsuarios('solicitud_invalida');
            }

            $clave = seguridadClaveIntentoLogin((string) $usuarioBloqueado['email']);
            $stmt = $conn->prepare(
                'DELETE FROM seguridad_intentos_login WHERE clave = ?'
            );
            $stmt->bind_param('s', $clave);
            $stmt->execute();
            $stmt->close();
            volverUsuarios('desbloqueado');
        } catch (Throwable $e) {
            error_log('No fue posible desbloquear los intentos de acceso: ' . $e->getMessage());
            volverUsuarios('error');
        }
    }

    if ($accion === 'permiso_consulta_global') {
        $idUsuario = filter_input(
            INPUT_POST,
            'id_usuario',
            FILTER_VALIDATE_INT
        ) ?: 0;
        $habilitado = !empty($_POST['habilitado']) ? 1 : 0;

        if ($idUsuario < 1) {
            volverUsuarios('solicitud_invalida');
        }

        try {
            $stmt = $conn->prepare(
                "UPDATE usuarios
                 SET puede_consultar_global = ?
                 WHERE id_usuario = ?
                   AND (id_rol = 1 OR id_pais_operacion = ?)"
            );
            $stmt->bind_param('iii', $habilitado, $idUsuario, $idPaisOperacion);
            $stmt->execute();
            $stmt->close();
            volverUsuarios('permiso_actualizado');
        } catch (Throwable $e) {
            error_log('No fue posible actualizar el permiso de consulta global: ' . $e->getMessage());
            volverUsuarios('error');
        }
    }

    volverUsuarios('solicitud_invalida');
}

$usuarios = [];
$resultadoUsuarios = $conn->query(
    "SELECT
        u.id_usuario,
        u.cedula,
        u.nombre,
        u.email,
        u.proceso,
        u.cu1,
        u.descripcion_cu1,
        u.cu3,
        CASE WHEN u.id_rol = 1 THEN 'No aplica' ELSE COALESCE(ciudad.nombre, NULLIF(u.ciudad, ''), 'Sin asignar') END AS ciudad,
        CASE WHEN u.id_rol = 1 THEN 'No aplica' ELSE COALESCE(departamento.nombre, 'Sin asignar') END AS departamento,
        CASE WHEN u.id_rol = 1 THEN 'Todos los países' ELSE COALESCE(pais.nombre, 'Sin asignar') END AS pais,
        u.empresa,
        u.id_rol,
        u.puede_consultar_global,
        u.id_pais_operacion,
        u.estado,
        COALESCE(r.nombre_rol, 'Sin rol') AS rol,
        CASE WHEN u.id_rol = 1 THEN 'Todos los países' ELSE po.nombre END AS pais_operacion
     FROM usuarios AS u
     LEFT JOIN roles AS r ON r.id_rol = u.id_rol
     LEFT JOIN paises_operacion AS po
        ON po.id_pais_operacion = u.id_pais_operacion
     LEFT JOIN configuraciones_servicio AS pais
        ON pais.id_opcion = u.id_pais AND pais.tipo = 'pais'
     LEFT JOIN configuraciones_servicio AS departamento
        ON departamento.id_opcion = u.id_departamento AND departamento.tipo = 'departamento'
     LEFT JOIN configuraciones_servicio AS ciudad
        ON ciudad.id_opcion = u.id_ciudad AND ciudad.tipo = 'ciudad'
     WHERE u.id_rol = 1 OR u.id_pais_operacion = {$idPaisOperacion}
     ORDER BY
        u.estado = 'activo' DESC,
        CASE
            WHEN u.id_rol = 2 THEN 0
            WHEN u.id_rol = 3 THEN 1
            ELSE 2
        END,
        LOWER(TRIM(u.nombre)) ASC,
        u.id_usuario ASC"
);

if ($resultadoUsuarios !== false) {
    $usuarios = $resultadoUsuarios->fetch_all(MYSQLI_ASSOC);
}

$intentosLoginPorClave = [];
try {
    $resultadoIntentosLogin = $conn->query(
        'SELECT clave, intentos, ultimo_intento, bloqueado_hasta FROM seguridad_intentos_login'
    );
    if ($resultadoIntentosLogin !== false) {
        while ($filaIntento = $resultadoIntentosLogin->fetch_assoc()) {
            $intentosLoginPorClave[(string) $filaIntento['clave']] = $filaIntento;
        }
    }
} catch (Throwable $e) {
    error_log('No fue posible consultar los bloqueos de acceso: ' . $e->getMessage());
}

foreach ($usuarios as &$usuario) {
    $claveUsuario = seguridadClaveIntentoLogin((string) ($usuario['email'] ?? ''));
    $filaIntento = $intentosLoginPorClave[$claveUsuario] ?? null;
    $bloqueadoHasta = $filaIntento['bloqueado_hasta'] ?? null;
    $ultimoIntento = $filaIntento['ultimo_intento'] ?? null;
    $ultimoIntentoUnix = $ultimoIntento ? strtotime((string) $ultimoIntento) : 0;
    $usuario['login_intentos'] = (int) ($filaIntento['intentos'] ?? 0);
    $usuario['login_bloqueado'] = $bloqueadoHasta !== null
        && trim((string) $bloqueadoHasta) !== ''
        && $ultimoIntentoUnix > 0
        && $ultimoIntentoUnix + SEGURIDAD_BLOQUEO_LOGIN_SEGUNDOS > time();
}
unset($usuario);

if (($_GET['export'] ?? '') === 'csv') {
    $nombreArchivo = sprintf(
        'usuarios_%s_%s.csv',
        strtolower($codigoPaisOperacion),
        date('Y-m-d')
    );

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $nombreArchivo . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');

    $salida = fopen('php://output', 'wb');

    if ($salida === false) {
        http_response_code(500);
        exit('No fue posible generar la descarga.');
    }

    fwrite($salida, "\xEF\xBB\xBF");
    fputcsv(
        $salida,
        [
            'ID',
            'Cédula',
            'Nombre completo',
            'Correo',
            'Rol',
            'Proceso',
            'CU1',
            'Descripción CU1',
            'CU3',
            'Empresa',
            'País',
            'Departamento',
            'Ciudad',
            'Operación',
            'Estado',
        ],
        ';',
        '"',
        '\\'
    );

    foreach ($usuarios as $usuario) {
        fputcsv(
            $salida,
            array_map(
                'valorCsvUsuario',
                [
                    $usuario['id_usuario'],
                    $usuario['cedula'],
                    $usuario['nombre'],
                    $usuario['email'],
                    $usuario['rol'],
                    $usuario['proceso'],
                    $usuario['cu1'],
                    $usuario['descripcion_cu1'],
                    $usuario['cu3'],
                    $usuario['empresa'],
                    $usuario['pais'],
                    $usuario['departamento'],
                    $usuario['ciudad'],
                    $usuario['pais_operacion'],
                    $usuario['estado'],
                ]
            ),
            ';',
            '"',
            '\\'
        );
    }

    fclose($salida);
    exit;
}

$mensajeActual = (string) ($_GET['msg'] ?? '');
$mensaje = $mensajes[$mensajeActual] ?? null;
$abrirModalPorError = in_array(
    $mensajeActual,
    [
        'datos_incompletos',
        'correo_invalido',
        'password_invalido',
        'rol_invalido',
        'ubicacion_invalida',
        'duplicado',
        'error',
    ],
    true
);
$totalUsuarios = count($usuarios);
$usuariosActivos = count(array_filter(
    $usuarios,
    static fn (array $usuario): bool => ($usuario['estado'] ?? '') === 'activo'
));
$usuariosInhabilitados = $totalUsuarios - $usuariosActivos;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Usuarios | SMARTDESK</title>
    <style>
        :root {
            --primary: <?= $codigoPaisOperacion === 'PE' ? '#f47c20' : '#0f6fec' ?>;
            --primary-dark: <?= $codigoPaisOperacion === 'PE' ? '#155b89' : '#0b4fae' ?>;
            --primary-soft: <?= $codigoPaisOperacion === 'PE' ? '#fff4e8' : '#eaf2fd' ?>;
            --primary-rgb: <?= $codigoPaisOperacion === 'PE' ? '244,124,32' : '15,111,236' ?>;
            --navy: #102a43;
            --text: #243b53;
            --muted: #526d82;
            --border: #dfe7f1;
            --bg: #f3f6fb;
            --danger: #b42318;
            --success: #087443;
        }
        * { box-sizing: border-box; }
        [hidden] { display: none !important; }
        body {
            margin: 0;
            color: var(--text);
            background: var(--bg);
            font: 12px/1.45 Inter, "Segoe UI", Arial, sans-serif;
        }
        button, input, select, textarea { font: inherit; }
        body.modal-open { overflow: hidden; }
        .shell { width: min(1260px, calc(100% - 24px)); margin: 12px auto 30px; }
        .top {
            min-height: 58px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            margin-bottom: 10px;
            padding: 10px 13px;
            border: 1px solid var(--border);
            border-radius: 13px;
            background: #fff;
            box-shadow: 0 7px 22px rgba(16,42,67,.05);
        }
        .top h1 { margin: 0; color: var(--navy); font-size: 18px; line-height: 1.2; }
        .top p { margin: 2px 0 0; color: var(--muted); font-size: 10px; }
        .top-actions, .row-actions, .modal-actions { display: flex; align-items: center; gap: 7px; }
        .button {
            min-height: 34px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 7px 11px;
            border: 1px solid transparent;
            border-radius: 8px;
            color: #fff;
            background: var(--primary);
            text-decoration: none;
            font-weight: 800;
            cursor: pointer;
        }
        .button:hover { background: var(--primary-dark); }
        .button.soft { border-color: var(--border); color: #315b7d; background: #f8fbff; }
        .button.soft:hover { color: var(--primary); background: var(--primary-soft); }
        .button.secondary { color: var(--primary-dark); background: var(--primary-soft); }
        .button.danger { color: var(--danger); background: #fff0f1; }
        .button.mini { min-height: 29px; padding: 5px 8px; font-size: 10px; }
        .user-edit-button {
            width: 34px;
            height: 34px;
            display: inline-grid;
            place-items: center;
            padding: 0;
            border: 1px solid var(--primary);
            border-radius: 8px;
            color: var(--primary-dark);
            background: var(--primary-soft);
            text-decoration: none;
        }
        .user-edit-button:hover { color: #fff; background: var(--primary); }
        .user-edit-button svg { width: 16px; height: 16px; fill: none; stroke: currentColor; stroke-width: 2.2; stroke-linecap: round; stroke-linejoin: round; }
        .card {
            overflow: hidden;
            border: 1px solid var(--border);
            border-radius: 14px;
            background: #fff;
            box-shadow: 0 8px 26px rgba(16,42,67,.055);
        }
        .card-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 12px 14px;
            border-bottom: 1px solid var(--border);
        }
        .card-head h2 { margin: 0; color: var(--navy); font-size: 15px; }
        .card-head p { margin: 2px 0 0; color: var(--muted); font-size: 9px; }
        .user-counters { flex: 0 0 auto; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .user-counter { display: inline-flex; align-items: center; gap: 5px; padding: 5px 9px; border: 1px solid var(--mesa-theme-border,var(--border)); border-radius: 999px; color: var(--mesa-theme-muted,var(--muted)); background: var(--mesa-theme-surface,#fff); font-size: 9px; font-weight: 750; white-space: nowrap; }
        .user-counter strong { color: var(--mesa-theme-heading,var(--navy)); font-size: 11px; line-height: 1; }
        .user-counter.active { border-color: color-mix(in srgb,var(--success) 24%,var(--mesa-theme-border,var(--border))); color: var(--success); background: color-mix(in srgb,var(--success) 8%,var(--mesa-theme-surface,#fff)); }
        .user-counter.inactive { border-color: color-mix(in srgb,var(--danger) 20%,var(--mesa-theme-border,var(--border))); color: var(--danger); background: color-mix(in srgb,var(--danger) 7%,var(--mesa-theme-surface,#fff)); }
        .filters {
            display: grid;
            grid-template-columns: minmax(260px,1fr) 170px 150px auto;
            gap: 8px;
            padding: 10px 14px;
            border-bottom: 1px solid var(--border);
            background: #fbfdff;
        }
        .control { position: relative; }
        .control input, .control select {
            width: 100%;
            min-height: 36px;
            padding: 7px 10px;
            outline: none;
            border: 1px solid #ccd9e6;
            border-radius: 8px;
            color: var(--text);
            background: #fff;
        }
        .control input:focus, .control select:focus,
        .field input:focus, .field select:focus, .field textarea:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(var(--primary-rgb),.11);
        }
        .table-scroll-superior {
            width: 100%;
            height: 12px;
            overflow-x: auto;
            overflow-y: hidden;
            margin-bottom: 5px;
            border-radius: 999px;
            scrollbar-color: var(--primary) #edf3f9;
            scrollbar-width: thin;
        }
        .table-scroll-superior > div { height: 1px; }
        .table-scroll-superior::-webkit-scrollbar { height: 9px; }
        .table-scroll-superior::-webkit-scrollbar-track { border-radius: 999px; background: #edf3f9; }
        .table-scroll-superior::-webkit-scrollbar-thumb { border: 2px solid #edf3f9; border-radius: 999px; background: var(--primary); }
        .table-wrap { overflow: auto; scrollbar-width: none; }
        .table-wrap::-webkit-scrollbar { display: none; }
        table { width: 100%; min-width: 1180px; border-collapse: collapse; }
        th, td { padding: 9px 10px; border-bottom: 1px solid #e8eef5; text-align: left; vertical-align: middle; }
        th { color: #526d82; background: #f7f9fc; font-size: 9px; letter-spacing: .035em; text-transform: uppercase; }
        tbody tr:hover { background: #fbfdff; }
        tbody tr:last-child td { border-bottom: 0; }
        td strong { color: var(--navy); font-size: 11px; }
        td small { color: var(--muted); font-size: 9px; }
        .badge { display: inline-flex; padding: 3px 7px; border-radius: 999px; font-size: 9px; font-weight: 800; text-transform: capitalize; }
        .badge.active { color: var(--success); background: #eaf8ef; }
        .badge.off { color: var(--danger); background: #fff0f1; }
        .row-actions { flex-wrap: wrap; }
        .row-actions form { margin: 0; }
        .empty-filter { padding: 24px; color: var(--muted); text-align: center; }
        .alert { margin-bottom: 10px; padding: 9px 12px; border-radius: 9px; font-weight: 700; }
        .alert.ok { color: var(--success); background: #eaf8ef; }
        .alert.error { color: var(--danger); background: #fff0f1; }
        .modal {
            position: fixed;
            /* Debe quedar por encima de la barra corporativa compartida. */
            z-index: 2147483500;
            inset: 0;
            display: grid;
            place-items: center;
            padding: 12px;
            background: rgba(8,25,43,.58);
            opacity: 0;
            transition: opacity .16s ease;
        }
        .modal.open { opacity: 1; }
        .modal-card {
            width: min(760px,100%);
            max-height: calc(100vh - 24px);
            overflow: hidden;
            border-radius: 15px;
            background: #fff;
            box-shadow: 0 28px 80px rgba(0,0,0,.28);
            transform: translateY(8px) scale(.985);
            transition: transform .16s ease;
        }
        .modal.open .modal-card { transform: translateY(0) scale(1); }
        .modal-head {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 14px;
            padding: 12px 15px;
            border-bottom: 1px solid var(--border);
        }
        .modal-head h2 { margin: 0; color: var(--navy); font-size: 16px; }
        .modal-head p { margin: 2px 0 0; color: var(--muted); font-size: 9px; }
        .modal-close {
            width: 31px;
            height: 31px;
            border: 0;
            border-radius: 8px;
            color: #526d82;
            background: #eef3f8;
            font-size: 20px;
            line-height: 1;
            cursor: pointer;
        }
        .modal-body { max-height: calc(100vh - 92px); overflow-y: auto; padding: 13px 15px 15px; }
        .grid { display: grid; grid-template-columns: repeat(3,minmax(0,1fr)); gap: 9px; }
        .field { display: grid; gap: 4px; }
        .field.wide { grid-column: span 2; }
        .field.full { grid-column: 1/-1; }
        .field label { color: #315b7d; font-size: 10px; font-weight: 800; }
        .field small.lookup-warning { color: var(--danger); font-weight: 800; }
        .field input, .field select, .field textarea {
            width: 100%;
            min-height: 36px;
            padding: 7px 9px;
            outline: none;
            border: 1px solid #cdd9e7;
            border-radius: 8px;
            color: var(--text);
            background: #fff;
        }
        .field input:disabled, .field select:disabled, .field textarea:disabled {
            cursor: not-allowed;
        }
        .field textarea { min-height: 56px; resize: vertical; }
        .modal-actions { justify-content: flex-end; margin-top: 11px; }
        @media (max-width: 850px) {
            .filters { grid-template-columns: 1fr 1fr; }
            .filters .search-control { grid-column: 1/-1; }
        }
        @media (max-width: 650px) {
            .shell { width: calc(100% - 14px); margin-top: 7px; }
            .top, .card-head { align-items: flex-start; flex-direction: column; }
            .top-actions { width: 100%; flex-wrap: wrap; }
            .top-actions .button { flex: 1; }
            .filters, .grid { grid-template-columns: 1fr; }
            .filters .search-control, .field.wide, .field.full { grid-column: auto; }
            .filters .button { width: 100%; }
        }
        .user-row td:last-child{text-align:center}.user-status-form{display:flex;justify-content:center;margin:0}.user-status-switch{position:relative;width:64px;height:30px;padding:0;border:0;border-radius:99px;color:#fff;cursor:pointer;font-size:9px;font-weight:900;transition:.18s}.user-status-switch.is-on{background:#159447}.user-status-switch.is-off{background:#d9363e}.user-status-switch:disabled{cursor:not-allowed;opacity:.65}.user-switch-thumb{position:absolute;top:4px;left:4px;width:22px;height:22px;border-radius:50%;background:#fff;box-shadow:0 2px 5px rgba(0,0,0,.28);transition:.18s}.user-status-switch.is-on .user-switch-thumb{transform:translateX(34px)}.user-switch-text{position:absolute;top:8px}.user-status-switch.is-on .user-switch-text{left:10px}.user-status-switch.is-off .user-switch-text{right:9px}.user-permission-form{display:flex;justify-content:center;margin:0}.user-permission-switch{position:relative;width:54px;height:28px;padding:0;border:0;border-radius:99px;color:#fff;cursor:pointer;font-size:8px;font-weight:900;transition:.18s}.user-permission-switch.is-on{background:#126c9b}.user-permission-switch.is-off{background:#9aaabd}.user-permission-switch .user-switch-thumb{position:absolute;top:4px;left:4px;width:20px;height:20px;border-radius:50%;background:#fff;box-shadow:0 2px 5px rgba(0,0,0,.25);transition:.18s}.user-permission-switch.is-on .user-switch-thumb{transform:translateX(26px)}.user-permission-switch .user-switch-text{position:absolute;top:8px}.user-permission-switch.is-on .user-switch-text{left:8px}.user-permission-switch.is-off .user-switch-text{right:8px}.permission-check{display:flex;align-items:flex-start;gap:10px;padding:11px 13px;border:1px solid var(--border);border-radius:10px;color:var(--navy);background:var(--primary-soft);cursor:pointer}.permission-check input{width:17px;height:17px;margin:1px 0 0;accent-color:var(--primary)}.permission-check strong,.permission-check small{display:block}.permission-check small{margin-top:3px;color:var(--muted);font-size:10px}

        /* La administración conserva una escala legible en cualquier resolución. */
        :root {
            --users-body-size: clamp(13px, .78rem + .25vw, 16px);
            --users-secondary-size: clamp(12px, .7rem + .2vw, 14px);
            --users-title-size: clamp(20px, 1.08rem + .48vw, 26px);
        }
        body { font-size: var(--users-body-size); }
        .top h1 { font-size: var(--users-title-size); }
        .top p,
        .card-head p { font-size: var(--users-secondary-size); line-height: 1.45; }
        .button { min-height: 42px; padding: 9px 13px; font-size: var(--users-secondary-size); }
        .card-head h2 { font-size: clamp(17px, .96rem + .32vw, 21px); }
        .user-counter { padding: 7px 10px; font-size: var(--users-secondary-size); }
        .user-counter strong { font-size: var(--users-body-size); }
        .control input,
        .control select { min-height: 44px; padding: 9px 11px; font-size: var(--users-body-size); }
        th { padding: 12px 11px; font-size: var(--users-secondary-size); }
        td { padding: 13px 11px; font-size: var(--users-body-size); line-height: 1.4; }
        td strong { font-size: var(--users-body-size); }
        td small { font-size: var(--users-secondary-size); }
        .badge { padding: 4px 8px; font-size: var(--users-secondary-size); }
        .user-edit-button { width: 40px; height: 40px; }
        .user-edit-button svg { width: 18px; height: 18px; }
        .user-status-switch { width: 72px; height: 34px; font-size: 11px; }
        .user-switch-thumb { top: 5px; left: 5px; width: 24px; height: 24px; }
        .user-status-switch.is-on .user-switch-thumb { transform: translateX(38px); }
        .user-switch-text { top: 9px; }
        .user-status-switch.is-on .user-switch-text { left: 11px; }
        .user-status-switch.is-off .user-switch-text { right: 10px; }
        .login-lock-cell { min-width: 150px; text-align: center; }
        .login-lock-form { display: inline-flex; align-items: center; justify-content: center; margin: 0; }
        .login-unlock-button { color: #9a3412; border-color: #fdba74; background: #fff7ed; }
        .login-unlock-button:hover { color: #fff; border-color: #ea580c; background: #ea580c; }
        .login-lock-note { display: block; margin-top: 3px; color: #b45309; font-size: 9px; font-weight: 800; }
        .login-available { color: var(--success); font-size: 10px; font-weight: 750; }
        .empty-filter { padding: 30px; font-size: var(--users-body-size); }
        .modal-head h2 { font-size: clamp(18px, 1rem + .35vw, 22px); }
        .modal-head p,
        .field label,
        .field input,
        .field select,
        .field textarea { font-size: var(--users-secondary-size); }
        .field input,
        .field select,
        .field textarea { min-height: 42px; }
        .field textarea { min-height: 76px; }
        @media (max-width: 650px) {
            .top h1 { font-size: 20px; }
            .card-head h2 { font-size: 18px; }
            .top-actions .button { min-height: 44px; }
            th, td { padding-right: 12px; padding-left: 12px; }
        }
    </style>
</head>
<body>
<main class="shell">
    <header class="top">
        <div>
            <h1>Administración de usuarios · <?= escaparUsuario($nombrePaisOperacion) ?></h1>
            <p>Gestione los agentes vinculados a esta operación.</p>
        </div>
        <div class="top-actions">
            <a class="button soft" href="panelAdmin.php">← Volver al panel</a>
            <a class="button soft" href="crearUsuarios.php?export=csv">↓ Descargar base</a>
            <button class="button" id="openUserModal" type="button">＋ Crear usuario</button>
        </div>
    </header>

    <?php if ($mensaje): ?>
        <div class="alert <?= escaparUsuario($mensaje[0]) ?>"><?= escaparUsuario($mensaje[1]) ?></div>
    <?php endif; ?>

    <section class="card">
        <div class="card-head">
            <div>
                <h2>Usuarios registrados</h2>
                <p>Busque por nombre, cédula, correo, proceso, empresa o ciudad.</p>
            </div>
            <div class="user-counters" aria-label="Resumen de usuarios">
                <span class="user-counter"><strong id="userTotalCount"><?= $totalUsuarios ?></strong> Total</span>
                <span class="user-counter active"><strong id="userActiveCount"><?= $usuariosActivos ?></strong> Activos</span>
                <span class="user-counter inactive"><strong id="userInactiveCount"><?= $usuariosInhabilitados ?></strong> Inhabilitados</span>
            </div>
        </div>
        <div class="filters" aria-label="Filtros de usuarios">
            <div class="control search-control">
                <input id="userSearch" type="search" placeholder="Buscar agente..." autocomplete="off">
            </div>
            <div class="control">
                <select id="roleFilter" aria-label="Filtrar por rol">
                    <option value="">Todos los roles</option>
                    <option value="1">Administrador</option>
                    <option value="2">Gestor</option>
                    <option value="3">Solicitante</option>
                </select>
            </div>
            <div class="control">
                <select id="statusFilter" aria-label="Filtrar por estado">
                    <option value="">Todos los estados</option>
                    <option value="activo">Activos</option>
                    <option value="inhabilitado">Inhabilitados</option>
                </select>
            </div>
            <button class="button soft" id="clearFilters" type="button">Limpiar filtros</button>
        </div>
        <div class="table-scroll-superior" id="usersScrollSuperior" aria-label="Desplazamiento horizontal de usuarios" tabindex="0"><div></div></div>
        <div class="table-wrap" id="usersTableWrap">
            <table>
                <thead><tr><th>Usuario</th><th>Nombre</th><th>Cédula</th><th>Proceso</th><th>CU3</th><th>Rol</th><th>Consulta global</th><th>Editar</th><th>Habilitar / inhabilitar</th><th>Acceso</th></tr></thead>
                <tbody id="usersTableBody">
                <?php foreach ($usuarios as $usuario): ?>
                    <tr
                        class="user-row"
                        data-role="<?= (int) $usuario['id_rol'] ?>"
                        data-status="<?= escaparUsuario($usuario['estado']) ?>"
                        data-search="<?= escaparUsuario(implode(' ', [
                            $usuario['nombre'],
                            $usuario['email'],
                            $usuario['cedula'],
                            $usuario['proceso'],
                            $usuario['empresa'],
                            $usuario['pais'],
                            $usuario['departamento'],
                            $usuario['ciudad'],
                            $usuario['rol'],
                        ])) ?>"
                    >
                        <td><?= escaparUsuario($usuario['email']) ?></td>
                        <td><strong><?= escaparUsuario($usuario['nombre']) ?></strong></td>
                        <td><?= escaparUsuario($usuario['cedula']) ?></td>
                        <td><?= escaparUsuario($usuario['proceso']) ?></td>
                        <td><?= escaparUsuario($usuario['cu3']) ?></td>
                        <td><?= escaparUsuario($usuario['rol']) ?></td>
                        <td>
                            <form class="user-permission-form" method="post" onsubmit="return confirm('¿Confirma el cambio del permiso de consulta global?')">
                                <input type="hidden" name="csrf_token" value="<?= escaparUsuario(seguridadTokenCsrf()) ?>">
                                <input type="hidden" name="accion" value="permiso_consulta_global">
                                <input type="hidden" name="id_usuario" value="<?= (int) $usuario['id_usuario'] ?>">
                                <input type="hidden" name="habilitado" value="<?= !empty($usuario['puede_consultar_global']) ? '0' : '1' ?>">
                                <button class="user-permission-switch <?= !empty($usuario['puede_consultar_global']) ? 'is-on' : 'is-off' ?>" type="submit" role="switch" aria-checked="<?= !empty($usuario['puede_consultar_global']) ? 'true' : 'false' ?>" title="<?= !empty($usuario['puede_consultar_global']) ? 'Quitar consulta global' : 'Dar consulta global' ?>"><span class="user-switch-text"><?= !empty($usuario['puede_consultar_global']) ? 'SÍ' : 'NO' ?></span><span class="user-switch-thumb"></span></button>
                            </form>
                        </td>
                        <td><a class="user-edit-button" href="editarUsuario.php?id=<?= (int) $usuario['id_usuario'] ?>" title="Editar" aria-label="Editar usuario"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg></a></td>
                        <td>
                            <?php if ((int) $usuario['id_usuario'] !== (int) $_SESSION['usuario_id']): ?>
                                <form class="user-status-form" method="post" onsubmit="return confirm('¿Confirma el cambio de estado de este usuario?')">
                                    <input type="hidden" name="csrf_token" value="<?= escaparUsuario(seguridadTokenCsrf()) ?>">
                                    <input type="hidden" name="accion" value="estado">
                                    <input type="hidden" name="id_usuario" value="<?= (int) $usuario['id_usuario'] ?>">
                                    <input type="hidden" name="estado" value="<?= $usuario['estado'] === 'activo' ? 'inhabilitado' : 'activo' ?>">
                                    <button class="user-status-switch <?= $usuario['estado'] === 'activo' ? 'is-on' : 'is-off' ?>" type="submit" role="switch" aria-checked="<?= $usuario['estado'] === 'activo' ? 'true' : 'false' ?>" title="<?= $usuario['estado'] === 'activo' ? 'Habilitado: pulse para inhabilitar' : 'Inhabilitado: pulse para habilitar' ?>"><span class="user-switch-text"><?= $usuario['estado'] === 'activo' ? 'ON' : 'OFF' ?></span><span class="user-switch-thumb"></span></button>
                                </form>
                            <?php else: ?>
                                <button class="user-status-switch is-on" type="button" role="switch" aria-checked="true" title="No puede inhabilitar su propia cuenta" disabled><span class="user-switch-text">ON</span><span class="user-switch-thumb"></span></button>
                            <?php endif; ?>
                        </td>
                        <td class="login-lock-cell">
                            <?php if (!empty($usuario['login_bloqueado'])): ?>
                                <form class="login-lock-form" method="post" onsubmit="return confirm('¿Confirma el desbloqueo de este usuario?')">
                                    <input type="hidden" name="csrf_token" value="<?= escaparUsuario(seguridadTokenCsrf()) ?>">
                                    <input type="hidden" name="accion" value="desbloquear_login">
                                    <input type="hidden" name="id_usuario" value="<?= (int) $usuario['id_usuario'] ?>">
                                    <button class="button mini login-unlock-button" type="submit" title="Desbloquear usuario">Desbloquear</button>
                                </form>
                                <span class="login-lock-note">Bloqueado · <?= (int) $usuario['login_intentos'] ?>/5</span>
                            <?php else: ?>
                                <span class="login-available">Disponible</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                    <tr id="noFilterResults" hidden>
                        <td class="empty-filter" colspan="10">No hay usuarios que coincidan con los filtros.</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>
</main>
<div
    class="modal"
    id="userModal"
    role="dialog"
    aria-modal="true"
    aria-labelledby="userModalTitle"
    hidden
>
    <div class="modal-card">
        <div class="modal-head">
            <div>
                <h2 id="userModalTitle">Crear usuario · <?= escaparUsuario($nombrePaisOperacion) ?></h2>
                <p>El usuario quedará vinculado a la operación seleccionada.</p>
            </div>
            <button class="modal-close" type="button" data-close-modal aria-label="Cerrar">×</button>
        </div>
        <div class="modal-body">
            <form id="createUserForm" method="post" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= escaparUsuario(seguridadTokenCsrf()) ?>">
                <input type="hidden" name="accion" value="crear">
                <div class="grid">
                    <div class="field"><label for="cedula">Cédula</label><input id="cedula" name="cedula" maxlength="30" required><small id="cedulaLookupMessage" role="status" aria-live="polite"></small></div>
                    <div class="field wide"><label for="nombre">Nombre completo</label><input id="nombre" name="nombre" maxlength="160" required></div>
                    <div class="field"><label for="proceso">Proceso</label><input id="proceso" name="proceso" maxlength="120" required></div>
                    <div class="field"><label for="cu1">CU1</label><input id="cu1" name="cu1" maxlength="120" required></div>
                    <div class="field"><label for="cu3">CU3</label><input id="cu3" name="cu3" maxlength="120" required></div>
                    <div class="field wide"><label for="email">Correo</label><input id="email" type="email" name="email" maxlength="190" required></div>
                    <div class="field wide"><label for="empresa">Empresa</label><input id="empresa" name="empresa" maxlength="160" required></div>
                    <div class="field"><label for="pais">País</label><input id="pais" name="pais" maxlength="160"></div>
                    <div class="field"><label for="departamento">Departamento</label><input id="departamento" name="departamento" maxlength="160"></div>
                    <div class="field"><label for="ciudad">Ciudad</label><input id="ciudad" name="ciudad" maxlength="160"></div>
                    <div class="field"><label for="id_rol">Rol</label><select id="id_rol" name="id_rol" required><option value="3">Solicitante</option><option value="2">Gestor</option><option value="1">Administrador</option></select></div>
                    <div class="field full permission-field">
                        <label class="permission-check"><input type="checkbox" name="puede_consultar_global" value="1"><span><strong>Consulta global (solo lectura)</strong><small>Permite consultar administración, gestión y métricas. El portal solicitante conserva sus acciones normales.</small></span></label>
                    </div>
                    <div class="field full"><label for="descripcion_cu1">Descripción CU1</label><textarea id="descripcion_cu1" name="descripcion_cu1" maxlength="500" required></textarea></div>
                    <div class="field full">
                        <label for="password">Contraseña inicial</label>
                        <input
                            id="password"
                            type="password"
                            name="password"
                            minlength="8"
                            maxlength="128"
                            pattern="(?=.*[A-ZÁÉÍÓÚÜÑ])(?=.*[0-9]).{8,128}"
                            title="Use mínimo 8 caracteres, una letra mayúscula y un número."
                            autocomplete="new-password"
                            required
                        >
                        <small>Mínimo 8 caracteres, una letra mayúscula y un número.</small>
                    </div>
                    <div class="field full">
                        <label for="password_confirmation">Confirmar contraseña</label>
                        <input
                            id="password_confirmation"
                            type="password"
                            name="password_confirmation"
                            minlength="8"
                            maxlength="128"
                            autocomplete="new-password"
                            required
                        >
                    </div>
                </div>
                <div class="modal-actions">
                    <button class="button soft" type="button" data-close-modal>Cancelar</button>
                    <button class="button" type="submit">Crear usuario</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
(() => {
    'use strict';

    const modal = document.getElementById('userModal');
    const openButton = document.getElementById('openUserModal');
    const createUserForm = document.getElementById('createUserForm');
    const firstInput = document.getElementById('cedula');
    const lookupMessage = document.getElementById('cedulaLookupMessage');
    const passwordInput = document.getElementById('password');
    const passwordConfirmationInput = document.getElementById('password_confirmation');
    const searchInput = document.getElementById('userSearch');
    const roleFilter = document.getElementById('roleFilter');
    const statusFilter = document.getElementById('statusFilter');
    const clearFilters = document.getElementById('clearFilters');
    const totalCount = document.getElementById('userTotalCount');
    const activeCount = document.getElementById('userActiveCount');
    const inactiveCount = document.getElementById('userInactiveCount');
    const noResults = document.getElementById('noFilterResults');
    const rows = Array.from(document.querySelectorAll('.user-row'));
    const sourceFields = {
        nombre: document.getElementById('nombre'),
        proceso: document.getElementById('proceso'),
        cu1: document.getElementById('cu1'),
        cu3: document.getElementById('cu3'),
        email: document.getElementById('email'),
        empresa: document.getElementById('empresa'),
        pais: document.getElementById('pais'),
        departamento: document.getElementById('departamento'),
        ciudad: document.getElementById('ciudad'),
        descripcion_cu1: document.getElementById('descripcion_cu1')
    };
    let lookupTimer = 0;
    let lookupRequest = 0;
    let closeTimer = 0;
    let lastLookupCedula = '';
    let lastRetiredAlertCedula = '';

    const normalize = (value) => String(value || '')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase()
        .trim();

    const updateUserCounters = () => {
        const activeUsers = rows.filter((row) => row.dataset.status === 'activo').length;
        totalCount.textContent = String(rows.length);
        activeCount.textContent = String(activeUsers);
        inactiveCount.textContent = String(rows.length - activeUsers);
    };

    const openModal = () => {
        window.clearTimeout(closeTimer);
        modal.hidden = false;
        document.body.classList.add('modal-open');
        requestAnimationFrame(() => modal.classList.add('open'));
        window.setTimeout(() => firstInput.focus(), 90);
    };

    const closeModal = () => {
        modal.classList.remove('open');
        document.body.classList.remove('modal-open');
        closeTimer = window.setTimeout(() => { modal.hidden = true; }, 170);
    };

    const filterUsers = () => {
        const term = normalize(searchInput.value);
        const role = roleFilter.value;
        const status = statusFilter.value;
        let visible = 0;

        rows.forEach((row) => {
            const matchesText = term === '' || normalize(row.dataset.search).includes(term);
            const matchesRole = role === '' || row.dataset.role === role;
            const matchesStatus = status === '' || row.dataset.status === status;
            const show = matchesText && matchesRole && matchesStatus;
            row.hidden = !show;
            if (show) visible += 1;
        });

        noResults.hidden = visible !== 0;
    };

    const linkUsersHorizontalScroll = () => {
        const scrollSuperior = document.getElementById('usersScrollSuperior');
        const tableWrap = document.getElementById('usersTableWrap');
        const table = tableWrap?.querySelector('table');
        if (!scrollSuperior || !tableWrap || !table) return;

        const resizeScroll = () => {
            scrollSuperior.firstElementChild.style.width = `${table.scrollWidth}px`;
            scrollSuperior.hidden = table.scrollWidth <= tableWrap.clientWidth;
        };

        resizeScroll();
        if (scrollSuperior.dataset.ready === '1') return;
        scrollSuperior.dataset.ready = '1';
        let syncing = false;
        scrollSuperior.addEventListener('scroll', () => {
            if (syncing) return;
            syncing = true;
            tableWrap.scrollLeft = scrollSuperior.scrollLeft;
            syncing = false;
        });
        tableWrap.addEventListener('scroll', () => {
            if (syncing) return;
            syncing = true;
            scrollSuperior.scrollLeft = tableWrap.scrollLeft;
            syncing = false;
        });
        window.addEventListener('resize', resizeScroll);
    };



    const disableAutoFilledFields = () => {
        Object.values(sourceFields).forEach((control) => {
            control.readOnly = true;
        });
    };

    const enableAutoFilledFields = () => {
        Object.values(sourceFields).forEach((control) => {
            control.readOnly = false;
        });
    };

    const enableManualEntry = (cedula, message) => {
        enableAutoFilledFields();
        lastLookupCedula = cedula;
        lookupMessage.textContent = message;
        lookupMessage.className = 'lookup-warning';
    };

    const clearAutoFilledData = () => {
        Object.values(sourceFields).forEach((control) => {
            control.value = '';
            control.readOnly = false;
        });
        lastLookupCedula = '';
        lookupMessage.textContent = '';
        lookupMessage.className = '';
    };

    const inferirPaisDesdeUbicacion = (departamento, ciudad) => {
        const dept = normalize(departamento || '');
        const city = normalize(ciudad || '');

        if (dept.includes('cundinamarca') || city.includes('bogota') || city.includes('bogotá')) {
            return 'Colombia';
        }

        if (dept.includes('lima') || city.includes('lima')) {
            return 'Perú';
        }

        if (dept.includes('antioquia') || city.includes('medellin') || city.includes('medellín')) {
            return 'Colombia';
        }

        if (dept.includes('callao') || city.includes('arequipa') || city.includes('trujillo')) {
            return 'Perú';
        }

        return 'Colombia';
    };

    const fillFromSource = (data) => {
        Object.entries(sourceFields).forEach(([key, control]) => {
            if (key === 'pais') {
                const valorPais = data.pais || data.pais_nombre || inferirPaisDesdeUbicacion(data.departamento, data.ciudad);
                if (valorPais) control.value = valorPais;
                return;
            }

            if (data[key]) control.value = data[key];
        });
        lastLookupCedula = firstInput.value.trim();
        disableAutoFilledFields();
    };

    const lookupPersonal = async () => {
        const cedula = firstInput.value.trim();
        if (cedula.length < 5) {
            clearAutoFilledData();
            return;
        }
        const requestId = ++lookupRequest;
        const body = new URLSearchParams({
            accion: 'buscar_personal',
            cedula,
            csrf_token: document.querySelector('#createUserForm [name="csrf_token"]').value
        });
        try {
            const response = await fetch('crearUsuarios.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body
            });
            const result = await response.json();
            if (requestId !== lookupRequest) return;
            const cedulaActual = firstInput.value.trim();
            if (result.estado === 'retirado' && normalize(cedulaActual) === normalize(cedula)) {
                clearAutoFilledData();
                lookupMessage.textContent = 'Esta cédula se encuentra en estado retirado en Uniclass';
                lookupMessage.className = 'lookup-warning';
                if (lastRetiredAlertCedula !== normalize(cedula)) {
                    window.alert('Esta cédula se encuentra en estado retirado en Uniclass');
                    lastRetiredAlertCedula = normalize(cedula);
                }
                return;
            }
            if (cedulaActual.length < 5) {
                clearAutoFilledData();
                return;
            }
            if (normalize(cedulaActual) !== normalize(cedula)) {
                clearAutoFilledData();
                return;
            }
            if (!result.ok) {
                enableManualEntry(
                    cedulaActual,
                    'No fue posible consultar Uniclass. Puede completar los datos manualmente.'
                );
                return;
            }
            if (!result.data) {
                enableManualEntry(
                    cedulaActual,
                    'La cédula no está registrada en Uniclass. Complete los datos manualmente.'
                );
                return;
            }
            fillFromSource(result.data);
        } catch (error) {
            const cedulaActual = firstInput.value.trim();
            if (cedulaActual.length < 5 || normalize(cedulaActual) !== normalize(cedula)) {
                clearAutoFilledData();
                return;
            }
            enableManualEntry(
                cedulaActual,
                'No fue posible consultar Uniclass. Puede completar los datos manualmente.'
            );
        }
    };

    firstInput.addEventListener('input', () => {
        const cedulaActual = firstInput.value.trim();
        if (cedulaActual === '') {
            clearAutoFilledData();
            window.clearTimeout(lookupTimer);
            return;
        }
        if (cedulaActual.length < 5) {
            clearAutoFilledData();
            window.clearTimeout(lookupTimer);
            return;
        }
        if (lastLookupCedula && normalize(cedulaActual) !== normalize(lastLookupCedula)) {
            clearAutoFilledData();
        }
        window.clearTimeout(lookupTimer);
        lookupTimer = window.setTimeout(lookupPersonal, 350);
    });



    openButton.addEventListener('click', openModal);
    modal.querySelectorAll('[data-close-modal]').forEach((button) => {
        button.addEventListener('click', closeModal);
    });
    modal.addEventListener('click', (event) => {
        if (event.target === modal) closeModal();
    });
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !modal.hidden) closeModal();
    });
    [searchInput, roleFilter, statusFilter].forEach((control) => {
        control.addEventListener('input', filterUsers);
        control.addEventListener('change', filterUsers);
    });
    clearFilters.addEventListener('click', () => {
        searchInput.value = '';
        roleFilter.value = '';
        statusFilter.value = '';
        filterUsers();
        searchInput.focus();
    });
    createUserForm.addEventListener('submit', (event) => {
        if (passwordInput.value !== passwordConfirmationInput.value) {
            event.preventDefault();
            passwordConfirmationInput.setCustomValidity('Las contraseñas no coinciden.');
            passwordConfirmationInput.reportValidity();
            passwordConfirmationInput.focus();
            return;
        }
        passwordConfirmationInput.setCustomValidity('');
    });
    passwordConfirmationInput.addEventListener('input', () => {
        passwordConfirmationInput.setCustomValidity(
            passwordInput.value === passwordConfirmationInput.value
                ? ''
                : 'Las contraseñas no coinciden.'
        );
    });
    document.addEventListener('mesa:state-changed', updateUserCounters);
    updateUserCounters();
    filterUsers();
    linkUsersHorizontalScroll();

    <?php if ($abrirModalPorError): ?>
    openModal();
    <?php endif; ?>
})();
</script>
<script src="assets/js/controlSesion.js" defer></script>
</body>
</html>
