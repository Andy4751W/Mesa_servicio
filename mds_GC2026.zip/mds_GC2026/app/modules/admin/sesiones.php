<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/temasInterfaz.php';
seguridadExigirRol([1, 2]);

$sesionesCodigoPais = strtoupper(trim((string) ($_SESSION['pais_operacion_codigo'] ?? 'CO')));
$sesionesTemaClave = temaInterfazUsuario(
  $conn,
  (int) ($_SESSION['usuario_id'] ?? 0),
  $sesionesCodigoPais
);
$sesionesPaleta = temaInterfazResolver($sesionesTemaClave, $sesionesCodigoPais);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Centro de control | Mesa de Servicio</title>
  <style>
    :root{--blue:#0f6fec;--navy:#0d427b;--ink:#102b49;--muted:#64748b;--line:#d8e4ef;--bg:#eef4f9;--green:#118957;--green-bg:#e7f8ef;--red:#c62828;--red-bg:#ffebee}
    *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 Inter,"Segoe UI",Arial,sans-serif}.control-page{width:min(1500px,100%);margin:auto;padding:24px}.control-hero{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:21px 24px;border-radius:18px;color:#fff;background:linear-gradient(120deg,#0a3769,#0f579c);box-shadow:0 14px 35px rgba(13,66,123,.18)}.title-wrap{display:flex;align-items:center;gap:14px}.control-icon{width:48px;height:48px;display:grid;place-items:center;border-radius:14px;background:#1684f5;font-size:12px;font-weight:950}.control-hero h1{margin:0;font-size:27px;letter-spacing:-.02em}.control-hero p{margin:3px 0 0;color:#d7eaff;font-size:12px}.live{display:inline-flex;align-items:center;gap:8px;padding:9px 13px;border:1px solid rgba(255,255,255,.24);border-radius:999px;background:rgba(255,255,255,.12);font-size:11px;font-weight:850}.live::before{width:9px;height:9px;border-radius:50%;background:#32df8c;box-shadow:0 0 0 5px rgba(50,223,140,.15);content:""}.live.error::before{background:#ff6363}.summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:14px 0}.summary article{padding:15px 18px;border:1px solid var(--line);border-radius:14px;background:#fff}.summary strong{display:block;font-size:25px}.summary span{color:var(--muted);font-size:11px;font-weight:700}.summary .online strong{color:var(--green)}.summary .offline strong{color:var(--red)}.filters{display:flex;align-items:end;gap:12px;margin:0 0 12px;padding:13px 15px;border:1px solid var(--line);border-radius:14px;background:#fff}.filter-field{display:grid;gap:5px;min-width:190px}.filter-field label{color:#46617b;font-size:9px;font-weight:900;letter-spacing:.05em;text-transform:uppercase}.filter-field select{height:39px;padding:0 36px 0 11px;border:1px solid #cbdbea;border-radius:10px;color:var(--ink);background:#f8fbfe;font:700 11px Inter,"Segoe UI",Arial,sans-serif}.filter-note{margin-left:auto;color:var(--muted);font-size:10px}.table-card{overflow:hidden;border:1px solid var(--line);border-radius:16px;background:#fff;box-shadow:0 10px 30px rgba(16,43,73,.05)}.table-caption{display:flex;align-items:center;justify-content:space-between;padding:13px 15px;border-bottom:1px solid #e8eef4}.table-caption strong{font-size:13px}.table-caption span{color:var(--muted);font-size:10px}.table-scroll{max-height:calc(100vh - 455px);min-height:245px;overflow:auto}table{width:100%;min-width:1230px;border-collapse:collapse}th,td{padding:12px 13px;border-bottom:1px solid #e8eef4;text-align:left;vertical-align:middle}th{position:sticky;z-index:1;top:0;color:#46617b;background:#f5f9fc;font-size:10px;letter-spacing:.04em;text-transform:uppercase}td{font-size:12px}tbody tr{cursor:pointer;transition:.15s}tbody tr:hover,tbody tr.selected{background:#edf6ff}.person strong,.device strong{display:block}.person small,.device small,.date small{display:block;margin-top:2px;color:var(--muted)}.status,.country{display:inline-flex;align-items:center;gap:7px;padding:7px 10px;border-radius:999px;font-size:10px;font-weight:900}.status::before{width:8px;height:8px;border-radius:50%;content:""}.status.online{color:var(--green);background:var(--green-bg)}.status.online::before{background:#18aa6a;box-shadow:0 0 0 4px rgba(24,170,106,.13)}.status.offline{color:var(--red);background:var(--red-bg)}.status.offline::before{background:#df3b3b}.country{color:#095ba8;background:#e8f3ff;white-space:nowrap}.ip{font-family:Consolas,monospace;font-size:11px}.empty{padding:50px 20px;text-align:center;color:var(--muted)}.note{margin:11px 3px 0;color:var(--muted);font-size:10px}.drawer-backdrop{position:fixed;z-index:2147483000;inset:0;background:rgba(8,30,52,.35);opacity:0;pointer-events:none;transition:.2s}.drawer-backdrop.open{opacity:1;pointer-events:auto}.drawer{position:absolute;top:0;right:0;width:min(560px,94vw);height:100%;display:flex;flex-direction:column;background:#f4f8fc;box-shadow:-20px 0 50px rgba(8,30,52,.25);transform:translateX(100%);transition:.24s ease}.open .drawer{transform:translateX(0)}.drawer-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;padding:21px;border-bottom:1px solid var(--line);background:#fff}.drawer-head h2{margin:0;font-size:21px}.drawer-head p{margin:3px 0 0;color:var(--muted);font-size:11px}.drawer-close{width:36px;height:36px;border:1px solid var(--line);border-radius:10px;background:#fff;color:var(--ink);font-size:20px;cursor:pointer}.session-facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:14px}.fact{padding:11px;border:1px solid var(--line);border-radius:11px;background:#fff}.fact span{display:block;color:var(--muted);font-size:9px;font-weight:800;text-transform:uppercase}.fact strong{display:block;margin-top:3px;font-size:11px;overflow-wrap:anywhere}.audit-title{display:flex;align-items:center;justify-content:space-between;padding:4px 17px 10px}.audit-title strong{font-size:13px}.audit-title span{color:var(--muted);font-size:10px}.audit-list{flex:1;overflow:auto;padding:0 14px 20px}.audit-item{position:relative;margin:0 0 9px;padding:13px 13px 13px 17px;border:1px solid var(--line);border-radius:12px;background:#fff}.audit-item::before{position:absolute;top:14px;bottom:14px;left:0;width:4px;border-radius:0 4px 4px 0;background:var(--blue);content:""}.audit-item header{display:flex;justify-content:space-between;gap:12px}.audit-item h3{margin:0;font-size:12px}.audit-item time{color:var(--muted);font-size:9px;white-space:nowrap}.audit-item p{margin:7px 0 0;color:#3e5870;font-size:10px;overflow-wrap:anywhere}.audit-meta{display:flex;gap:10px;margin-top:8px;color:var(--muted);font-size:9px}.audit-empty{padding:35px 18px;text-align:center;color:var(--muted);font-size:11px}@media(max-width:760px){.control-page{padding:12px}.control-hero{align-items:flex-start;padding:17px}.control-hero h1{font-size:21px}.control-icon{display:none}.live{padding:7px 9px}.summary{grid-template-columns:1fr;gap:7px}.summary article{padding:11px 14px}.filters{align-items:stretch;flex-direction:column}.filter-field{min-width:0}.filter-note{margin-left:0}.table-scroll{max-height:none}.drawer{width:100vw}.session-facts{grid-template-columns:1fr}}
    .drawer-backdrop{position:relative!important;inset:auto!important;z-index:auto!important;display:block!important;margin-top:14px;background:transparent!important;opacity:1!important;pointer-events:auto!important;}
    .drawer{position:relative!important;right:auto!important;bottom:auto!important;width:100%!important;max-width:none!important;max-height:none!important;transform:none!important;border:1px solid var(--line)!important;border-radius:14px!important;background:var(--surface,#fff)!important;color:var(--ink)!important;box-shadow:0 8px 24px rgba(16,42,67,.08)!important;overflow:hidden!important;}
    .drawer-close{display:none!important}
    .session-facts{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px!important;padding:14px!important;background:var(--surface-soft,#f7f9fc)!important;}
    .fact{min-width:0;padding:10px 12px;border:1px solid var(--line);border-radius:10px;background:var(--surface,#fff);}
    .audit-list{max-height:420px!important;overflow:auto!important;padding:12px!important;background:var(--background,var(--bg))!important;}
    @media(max-width:900px){.session-facts{grid-template-columns:repeat(2,minmax(0,1fr))!important}.table-scroll{overflow-x:auto!important}}
    @media(max-width:560px){.session-facts{grid-template-columns:1fr!important}.control-page{padding:14px!important}.control-hero{align-items:flex-start!important;flex-direction:column!important}.filters{align-items:stretch!important;flex-direction:column!important}.filter-field{min-width:0!important}.table-card{overflow:hidden!important}.table-scroll table{min-width:920px!important}}
    :root{
      color-scheme:<?= htmlspecialchars($sesionesPaleta['scheme'], ENT_QUOTES, 'UTF-8') ?>;
      --surface:<?= htmlspecialchars($sesionesPaleta['surface'], ENT_QUOTES, 'UTF-8') ?>;
      --surface-soft:<?= htmlspecialchars($sesionesPaleta['soft'], ENT_QUOTES, 'UTF-8') ?>;
      --background:<?= htmlspecialchars($sesionesPaleta['background'], ENT_QUOTES, 'UTF-8') ?>;
      --ink:<?= htmlspecialchars($sesionesPaleta['text'], ENT_QUOTES, 'UTF-8') ?>;
      --ink-strong:<?= htmlspecialchars($sesionesPaleta['heading'], ENT_QUOTES, 'UTF-8') ?>;
      --muted:<?= htmlspecialchars($sesionesPaleta['muted'], ENT_QUOTES, 'UTF-8') ?>;
      --line:<?= htmlspecialchars($sesionesPaleta['border'], ENT_QUOTES, 'UTF-8') ?>;
      --blue:<?= htmlspecialchars($sesionesPaleta['primary'], ENT_QUOTES, 'UTF-8') ?>;
    }
    body{background:var(--background)!important;color:var(--ink)!important}
    .summary article,.filters,.table-card,.drawer,.fact,.audit-item{border-color:var(--line)!important;background:var(--surface)!important;color:var(--ink)!important}
    .table-caption,.drawer-head,.audit-title{border-color:var(--line)!important;background:var(--surface-soft)!important;color:var(--ink-strong)!important}
    .table-scroll,.audit-list{background:var(--background)!important}
    th{color:var(--ink-strong)!important;background:var(--surface-soft)!important;border-color:var(--line)!important}
    td{color:var(--ink)!important;border-color:var(--line)!important}
    .fact span,.audit-meta,.drawer-head p,.table-caption span,.note{color:var(--muted)!important}
    .audit-item h3,.fact strong{color:var(--ink-strong)!important}
    .control-hero h1,.control-hero p{color:#fff!important}
    .control-page{max-width:1500px;padding:14px 24px 20px}
    .control-hero{min-height:60px;padding:10px 14px;border:1px solid var(--line);border-radius:10px;background:var(--surface-soft);box-shadow:none}
    .control-icon{width:34px;height:34px;border:1px solid var(--line);border-radius:8px;background:var(--surface);color:var(--blue);box-shadow:none}
    .control-hero h1{font-size:23px;letter-spacing:-.02em}
    .panel-actions{display:flex;justify-content:flex-end;gap:6px;margin:7px 0 0}
    .summary{gap:8px;margin:8px 0}
    .summary article{min-height:52px;padding:7px 12px;border-radius:9px;box-shadow:none}
    .summary strong{font-size:19px}
    .summary strong{color:var(--ink-strong)}
    .filters{min-height:52px;gap:8px;margin-bottom:8px;padding:8px 10px;border-radius:9px;box-shadow:none}
    .filter-field{min-width:165px;gap:3px}
    .filter-field select{height:32px}
    .filter-search{display:flex;align-items:end;min-width:220px;flex:1}
    .filter-search input{width:100%;height:32px;padding:0 10px;border:1px solid #c7d7e6;border-radius:8px;color:var(--ink);background:#f9fbfd;font:700 11px Inter,"Segoe UI",Arial,sans-serif}
    .filter-actions{display:flex;align-items:end;gap:6px}
    .filter-actions button,.panel-toggle{height:30px;padding:0 10px;border:1px solid var(--line);border-radius:7px;color:var(--blue);background:var(--surface);font:800 11px Inter,"Segoe UI",Arial,sans-serif;cursor:pointer}
    .filter-actions button:hover,.panel-toggle:hover{background:var(--surface-soft)}
    .filter-field select{background:#f9fbfd;border-color:#c7d7e6}
    .table-card{border:1px solid var(--line);border-radius:10px;background:var(--surface);box-shadow:none;overflow:hidden}
    .table-caption{min-height:38px;padding:9px 12px}
    .table-scroll{max-height:min(440px,calc(100vh - 285px));min-height:0;background:var(--surface)!important;overflow:auto}
    table{min-width:1080px}
    th,td{padding:8px 10px!important}
    thead th{font-size:9px;letter-spacing:.045em}
    tbody td{font-size:11px}
    tbody tr:hover{background:var(--surface-soft)!important}
    tbody tr.selected{background:var(--surface-soft)!important}
    .note{margin:10px 2px 0}
    .drawer-backdrop[aria-hidden="true"]{display:none!important}
    .drawer{margin-top:8px!important;box-shadow:none!important}
    .drawer-head{padding:10px 13px!important}
    .session-facts{gap:7px!important;padding:9px!important}
    .fact{padding:7px 9px}
    .audit-title{padding:9px 13px!important}
    .audit-list{max-height:260px!important;padding:9px!important}
    .audit-item{padding:9px 11px!important;box-shadow:none}
    .audit-item p{margin:4px 0!important}
    .control-hero h1{color:var(--ink-strong)!important;-webkit-text-fill-color:var(--ink-strong)!important}
    .control-hero p{color:var(--muted)!important;-webkit-text-fill-color:var(--muted)!important}
    .panel-hidden{display:none!important}
    .control-hero,.summary,.panel-actions{display:none!important}
    .control-page{padding-top:10px}
    .filters{margin-top:0}
    .filter-note{display:none}
    .table-caption{display:flex;align-items:center;gap:10px}
    .table-caption strong{font-size:13px}
    .table-caption span{margin-left:auto}
    .country{display:inline;color:inherit;background:transparent;padding:0;border:0;border-radius:0;font-weight:600}
    tbody tr[data-session-id]{cursor:pointer}
    .table-scroll{max-height:min(580px,calc(100vh - 195px))}
    @media(max-width:700px){.table-caption{align-items:flex-start;flex-wrap:wrap}.table-caption span{width:100%;margin-left:0}.table-scroll{max-height:calc(100vh - 245px)}}
    @media(max-width:700px){.control-page{padding:10px}.control-hero{padding:11px}.control-hero h1{font-size:20px}.summary{grid-template-columns:1fr 1fr}.filters{align-items:stretch;flex-wrap:wrap}.filter-field,.filter-search{min-width:calc(50% - 5px)}.filter-actions{width:100%}.filter-actions button{flex:1}.table-scroll{max-height:calc(100vh - 245px)}}
  </style>
</head>
<body>
<main class="control-page" id="sessions-control-page">
  <section class="control-hero">
    <div class="title-wrap"><span class="control-icon" aria-hidden="true">CC</span><div><h1>Centro de control</h1><p>Sesiones y modificaciones de la Mesa de Servicio en tiempo real.</p></div></div>
    <span class="live" id="sessions-live">Conectando…</span>
  </section>
  <div class="panel-actions"><button class="panel-toggle" type="button" data-panel="sessions-summary" aria-expanded="true">Ocultar indicadores</button><button class="panel-toggle" type="button" data-panel="sessions-filters" aria-expanded="true">Ocultar filtros</button></div>
  <section class="summary" id="sessions-summary" aria-label="Resumen de sesiones">
    <article class="online"><strong id="sessions-active">—</strong><span>Activas en este momento</span></article>
    <article class="offline"><strong id="sessions-closed">—</strong><span>Cerradas o sin actividad</span></article>
    <article><strong id="sessions-total">—</strong><span>Sesiones mostradas con filtros</span></article>
  </section>
  <section class="filters" id="sessions-filters" aria-label="Filtros de sesiones">
    <div class="filter-field"><label for="sessions-status-filter">Estado</label><select id="sessions-status-filter"><option value="active" selected>Activas</option><option value="recent">Actividad reciente</option><option value="closed">Cerradas</option><option value="all">Todas</option></select></div>
    <div class="filter-field"><label for="sessions-country-filter">Operación</label><select id="sessions-country-filter"><option value="all" selected>Todas las operaciones</option><option value="CO">Solo Colombia</option><option value="PE">Solo Perú</option><option value="BOTH">Colombia y Perú</option><option value="NONE">Sin operación registrada</option></select></div>
    <div class="filter-search"><input id="sessions-search" type="search" placeholder="Buscar usuario, IP o dispositivo" aria-label="Buscar usuario, IP o dispositivo"></div>
    <div class="filter-actions"><button type="button" id="sessions-refresh">Actualizar</button></div>
    <span class="filter-note">Actualización automática cada 3 segundos.</span>
  </section>
  <section class="table-card">
    <div class="table-caption"><strong>Sesiones</strong><span id="sessions-visible-label">Seleccione una sesión para consultar sus modificaciones</span></div>
    <div class="table-scroll"><table><thead><tr><th>Estado</th><th>Usuario</th><th>Operación</th><th>Dirección IP</th><th>Última actividad</th></tr></thead><tbody id="sessions-body"><tr><td colspan="5" class="empty">Cargando sesiones…</td></tr></tbody></table></div>
  </section>
  <p class="note">Los estados se actualizan cada 3 segundos. Al cerrar el navegador sin usar “Cerrar sesión”, el acceso cambia a cerrado después de aproximadamente 90 segundos.</p>
</main>

<div class="drawer-backdrop" id="session-drawer" aria-hidden="true">
  <aside class="drawer" role="region" aria-labelledby="session-drawer-title">
    <div class="drawer-head"><h2 id="session-drawer-title">Modificaciones realizadas</h2><span id="audit-count">0 registros</span></div>
    <div class="audit-list" id="audit-list"><div class="audit-empty">Seleccione una sesión.</div></div>
  </aside>
</div>

<script>
(function(){
  'use strict';
  if(window.__mesaSesionesMonitorStop){window.__mesaSesionesMonitorStop()}
  var root=document.getElementById('sessions-control-page');
  if(!root){return}
  var body=document.getElementById('sessions-body');
  var live=document.getElementById('sessions-live');
  var drawer=document.getElementById('session-drawer');
  var auditList=document.getElementById('audit-list');
  var auditCount=document.getElementById('audit-count');
  var statusFilter=document.getElementById('sessions-status-filter');
  var countryFilter=document.getElementById('sessions-country-filter');
  var searchInput=document.getElementById('sessions-search');
  var refreshButton=document.getElementById('sessions-refresh');
  var panelToggles=document.querySelectorAll('.panel-toggle[data-panel]');
  var visibleLabel=document.getElementById('sessions-visible-label');
  var selected=0,timer=0,busy=false,stopped=false,lastSessions=[];

  function esc(value){return String(value==null?'':value).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]})}
  function date(value){var s=String(value||'');if(!s){return 'Sin registro'}var p=s.split(' '),d=(p[0]||'').split('-');return d.length===3?d[2]+'/'+d[1]+'/'+d[0]+' '+(p[1]||''):s}
  function reason(value){var m={cerrada:'Cierre voluntario',inactividad:'Inactividad',tiempo_maximo:'Tiempo máximo',sesion_expirada:'Sesión expirada',sesion_reemplazada:'Reemplazada por otro acceso',reemplazada:'Reemplazada por otro acceso',pestana_cerrada:'Otra pestaña tomó la sesión',sesion_inhabilitada:'Usuario inhabilitado',credenciales:'Credenciales inválidas',rol:'Rol inválido',sistema:'Error del sistema'};return m[value]||'Sin actividad reciente'}
  function sessionById(id){return lastSessions.find(function(s){return Number(s.id_sesion)===Number(id)})||null}

  function filteredSessions(){
    var status=statusFilter.value,country=countryFilter.value,query=searchInput.value.trim().toLowerCase();
    return lastSessions.filter(function(s){
      var active=Number(s.activa)===1,codes=String(s.pais_codigos||'').split(',').filter(Boolean);
      if(status==='active'&&!active){return false}if(status==='closed'&&active){return false}
      if(status==='recent'&&(!s.ultima_actividad_en||new Date(String(s.ultima_actividad_en).replace(' ','T')).getTime()<Date.now()-900000)){return false}
      if(country==='CO'&&!(codes.length===1&&codes[0]==='CO')){return false}
      if(country==='PE'&&!(codes.length===1&&codes[0]==='PE')){return false}
      if(country==='BOTH'&&!(codes.indexOf('CO')!==-1&&codes.indexOf('PE')!==-1)){return false}
      if(country==='NONE'&&codes.length!==0){return false}
      if(query&&[s.nombre,s.email,s.direccion_ip,s.tipo_dispositivo,s.sistema_operativo,s.navegador,s.paises].join(' ').toLowerCase().indexOf(query)===-1){return false}
      return true;
    });
  }

  function applyFilters(){var items=filteredSessions(),active=items.filter(function(s){return Number(s.activa)===1}).length;document.getElementById('sessions-total').textContent=items.length;visibleLabel.textContent=items.length+' registros · '+active+' activas · Seleccione una sesión para consultar su actividad';renderTable(items)}

  function renderTable(items){
    if(!items.length){body.innerHTML='<tr><td colspan="5" class="empty">No hay sesiones que coincidan con los filtros seleccionados.</td></tr>';return}
    body.innerHTML=items.map(function(s){var active=Number(s.activa)===1,id=Number(s.id_sesion);return '<tr tabindex="0" data-session-id="'+id+'" class="'+(id===selected?'selected':'')+'"><td><span class="status '+(active?'online':'offline')+'">'+(active?'Activo':'Cerrado')+'</span></td><td class="person"><strong>'+esc(s.nombre)+'</strong><small>'+esc(s.email)+'</small></td><td class="operation">'+esc(s.paises)+'</td><td class="ip">'+esc(s.direccion_ip)+'</td><td class="date"><strong>'+date(s.ultima_actividad_en)+'</strong><small>'+(active?'Actividad vigente':esc(reason(s.motivo_cierre)))+'</small></td></tr>'}).join('');
  }

  function renderAudit(items){
    auditCount.textContent=items.length+' registro'+(items.length===1?'':'s');
    if(!items.length){auditList.innerHTML='<div class="audit-empty">Esta sesión todavía no tiene modificaciones registradas.</div>';return}
    auditList.innerHTML=items.map(function(a){return '<article class="audit-item"><header><h3>'+esc(a.modulo)+' · '+esc(a.accion)+'</h3><time>'+date(a.fecha_hora)+'</time></header><p>'+esc(a.detalle)+'</p><div class="audit-meta"><span>IP: '+esc(a.direccion_ip)+'</span><span>Respuesta: '+esc(a.estado_http)+'</span></div></article>'}).join('');
  }

  function openSession(id){selected=Number(id)||0;drawer.classList.add('open');drawer.setAttribute('aria-hidden','false');applyFilters();refresh()}
  function closeDrawer(){drawer.classList.remove('open');drawer.setAttribute('aria-hidden','true');selected=0;applyFilters()}

  function togglePanel(button){
    var panel=document.getElementById(button.getAttribute('data-panel'));
    if(!panel){return}
    var hidden=panel.classList.toggle('panel-hidden');
    button.setAttribute('aria-expanded',hidden?'false':'true');
    button.textContent=(hidden?'Mostrar ':'Ocultar ')+(panel.id==='sessions-summary'?'indicadores':'filtros');
  }

  async function refresh(){
    if(stopped||busy){return}if(!document.getElementById('sessions-control-page')){stop();return}busy=true;
    try{
      var url='sesionesApi.php?_='+(Date.now())+(selected?'&id_sesion='+encodeURIComponent(selected):'');
      var response=await fetch(url,{credentials:'same-origin',cache:'no-store',headers:{'X-Requested-With':'XMLHttpRequest'}});
      if(!response.ok){throw new Error('HTTP '+response.status)}
      var data=await response.json();if(!data.ok){throw new Error('Respuesta inválida')}
      lastSessions=Array.isArray(data.sesiones)?data.sesiones:[];
      document.getElementById('sessions-active').textContent=data.resumen.activas;
      document.getElementById('sessions-closed').textContent=data.resumen.cerradas;
      applyFilters();
      if(selected){renderAudit(Array.isArray(data.auditoria)?data.auditoria:[])}
      live.classList.remove('error');live.textContent='En vivo · '+date(data.generado_en).split(' ')[1];
    }catch(error){live.classList.add('error');live.textContent='Reconectando…'}finally{busy=false;if(!stopped){clearTimeout(timer);timer=setTimeout(refresh,3000)}}
  }

  function closeOnEscape(e){if(e.key==='Escape'&&drawer.classList.contains('open')){closeDrawer()}}
  function stop(){stopped=true;clearTimeout(timer);document.removeEventListener('keydown',closeOnEscape)}
  window.__mesaSesionesMonitorStop=stop;
  body.addEventListener('click',function(e){var row=e.target.closest('tr[data-session-id]');if(row){openSession(row.getAttribute('data-session-id'))}});
  body.addEventListener('keydown',function(e){if((e.key==='Enter'||e.key===' ')&&e.target.matches('tr[data-session-id]')){e.preventDefault();openSession(e.target.getAttribute('data-session-id'))}});
  searchInput.addEventListener('input',function(){selected=0;drawer.classList.remove('open');drawer.setAttribute('aria-hidden','true');applyFilters()});
  statusFilter.addEventListener('change',function(){selected=0;drawer.classList.remove('open');drawer.setAttribute('aria-hidden','true');applyFilters()});
  countryFilter.addEventListener('change',function(){selected=0;drawer.classList.remove('open');drawer.setAttribute('aria-hidden','true');applyFilters()});
  refreshButton.addEventListener('click',refresh);
  panelToggles.forEach(function(button){button.addEventListener('click',function(){togglePanel(button)})});
  document.addEventListener('keydown',closeOnEscape);
  refresh();
})();
</script>
</body>
</html>
