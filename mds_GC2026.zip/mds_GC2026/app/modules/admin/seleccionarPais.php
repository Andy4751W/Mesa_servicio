<?php
declare(strict_types=1);

define('MESA_PERMITE_SIN_PAIS', true);

require_once APP_ROOT . '/security/validarSesion.php';

seguridadExigirRol([1]);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $idPais = filter_input(
        INPUT_POST,
        'id_pais_operacion',
        FILTER_VALIDATE_INT
    ) ?: 0;

    $pais = paisBuscarOperacion($conn, $idPais);

    if (!$pais) {
        header(
            'Location: seleccionarPais.php?error=operacion_invalida',
            true,
            303
        );
        exit;
    }

    paisGuardarContexto($pais);
    $_SESSION['ultima_interaccion'] = time();

    header('Location: panelAdmin.php', true, 303);
    exit;
}

paisLimpiarContexto();

$paises = paisOperacionesActivas($conn);

$nombre = htmlspecialchars(
    (string) ($_SESSION['usuario'] ?? 'Administrador'),
    ENT_QUOTES,
    'UTF-8'
);

$error = (string) ($_GET['error'] ?? '');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Seleccionar operación | Mesa de Servicio</title>
    <meta name="theme-color" content="#081528">

    <style>
        * { box-sizing: border-box; }

        :root {
            color-scheme: dark;
            --ink: #eef6ff;
            --ink-strong: #ffffff;
            --muted: #b7c8dc;
            --line: rgba(255,255,255,.12);
        }

        html, body {
            min-height: 100%;
        }

        html body[data-mesa-selector-pais] {
            min-height: 100vh !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow-x: hidden;
            color: var(--ink);
            background:
                radial-gradient(circle at 10% 16%, rgba(0,132,255,.27), transparent 28%),
                radial-gradient(circle at 88% 18%, rgba(162,61,255,.21), transparent 25%),
                radial-gradient(circle at 82% 82%, rgba(240,45,88,.23), transparent 27%),
                linear-gradient(135deg, #071323 0%, #0b1f3b 31%, #121a3d 58%, #2b1031 100%) !important;
            font: 14px/1.5 Inter, "Segoe UI", Arial, sans-serif;
            transition: background .45s ease;
        }

        body[data-mesa-selector-pais] #svc-sidebar,
        body[data-mesa-selector-pais] #svc-topbar,
        body[data-mesa-selector-pais] #svc-account-menu,
        body[data-mesa-selector-pais] #svc-profile-modal,
        body[data-mesa-selector-pais] #svc-sidebar-floating,
        body[data-mesa-selector-pais] #svc-country-context,
        body[data-mesa-selector-pais] #mesa-php-sidebar,
        body[data-mesa-selector-pais] #mesa-php-topbar,
        body[data-mesa-selector-pais] #mesa-php-floating,
        body[data-mesa-selector-pais] #mesa-php-country,
        body[data-mesa-selector-pais] #mesa-php-profile-modal,
        body[data-mesa-selector-pais] #gc-global-sidebar,
        body[data-mesa-selector-pais] #gc-global-top,
        body[data-mesa-selector-pais] #gc-account-menu,
        body[data-mesa-selector-pais] #gc-profile-modal,
        body[data-mesa-selector-pais] #gc-sidebar-floating {
            display: none !important;
        }

        body.dynamic-blue {
            background:
                radial-gradient(circle at 12% 20%, rgba(0,144,255,.36), transparent 30%),
                radial-gradient(circle at 76% 14%, rgba(92,84,255,.17), transparent 22%),
                linear-gradient(135deg, #061428 0%, #082042 34%, #0b2f5d 65%, #101a39 100%) !important;
        }

        body.dynamic-red {
            background:
                radial-gradient(circle at 86% 18%, rgba(255,72,108,.34), transparent 30%),
                radial-gradient(circle at 20% 80%, rgba(136,73,255,.14), transparent 24%),
                linear-gradient(135deg, #0a1428 0%, #1a1735 34%, #351327 66%, #541526 100%) !important;
        }

        .ambient {
            position: fixed;
            inset: 0;
            overflow: hidden;
            pointer-events: none;
            z-index: 0;
        }

        .ambient::before {
            content: "";
            position: absolute;
            inset: 0;
            opacity: .11;
            background-image:
                linear-gradient(rgba(255,255,255,.11) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,.11) 1px, transparent 1px);
            background-size: 44px 44px;
            mask-image: linear-gradient(to bottom, rgba(0,0,0,.95), rgba(0,0,0,.48) 72%, transparent);
        }

        .ambient::after {
            content: "";
            position: absolute;
            inset: -15%;
            filter: blur(42px);
            opacity: .76;
            background:
                radial-gradient(circle at 15% 24%, rgba(0,132,255,.22), transparent 23%),
                radial-gradient(circle at 82% 20%, rgba(220,45,80,.18), transparent 24%),
                radial-gradient(circle at 65% 78%, rgba(143,84,255,.18), transparent 21%);
            animation: hazeMove 18s ease-in-out infinite alternate;
        }

        .orb,
        .aurora,
        .shape,
        .particle {
            position: absolute;
            pointer-events: none;
            transform: translate3d(0,0,0);
        }

        .orb {
            border-radius: 50%;
            filter: blur(18px);
            opacity: .8;
            animation: floatOrb 16s ease-in-out infinite alternate;
        }

        .orb.one {
            width: 460px;
            height: 460px;
            left: -135px;
            top: -120px;
            background: radial-gradient(circle, rgba(0,140,255,.29), rgba(0,140,255,0) 72%);
        }

        .orb.two {
            width: 520px;
            height: 520px;
            right: -180px;
            bottom: -220px;
            background: radial-gradient(circle, rgba(255,52,90,.24), rgba(255,52,90,0) 72%);
            animation-duration: 20s;
        }

        .orb.three {
            width: 290px;
            height: 290px;
            left: 42%;
            top: 18%;
            background: radial-gradient(circle, rgba(126,84,255,.20), rgba(126,84,255,0) 72%);
            animation-duration: 18s;
            opacity: .56;
        }

        .aurora {
            filter: blur(30px);
            opacity: .53;
            mix-blend-mode: screen;
            animation: auroraMove 22s ease-in-out infinite alternate;
        }

        .aurora.a1 {
            width: 40vw;
            height: 16vh;
            left: -4vw;
            top: 17vh;
            border-radius: 999px;
            background: linear-gradient(90deg, rgba(0,159,255,0), rgba(0,159,255,.33), rgba(110,84,255,0));
        }

        .aurora.a2 {
            width: 36vw;
            height: 16vh;
            right: -4vw;
            top: 12vh;
            border-radius: 999px;
            background: linear-gradient(90deg, rgba(255,60,94,0), rgba(255,60,94,.30), rgba(255,130,73,0));
            animation-duration: 26s;
        }

        .aurora.a3 {
            width: 30vw;
            height: 13vh;
            left: 36vw;
            bottom: 10vh;
            border-radius: 999px;
            background: linear-gradient(90deg, rgba(110,84,255,0), rgba(110,84,255,.24), rgba(0,210,255,0));
            animation-duration: 28s;
        }

        .shape {
            opacity: .28;
            animation: drift 20s ease-in-out infinite;
        }

        .shape.s1 {
            width: 74px;
            height: 74px;
            top: 16%;
            left: 8%;
            border: 1px solid rgba(107,179,255,.22);
            border-radius: 20px;
        }

        .shape.s2 {
            width: 94px;
            height: 94px;
            right: 9%;
            top: 23%;
            border: 1px solid rgba(255,98,124,.18);
            clip-path: polygon(50% 0%,100% 50%,50% 100%,0% 50%);
        }

        .shape.s3 {
            width: 14px;
            height: 14px;
            left: 46%;
            bottom: 18%;
            border-radius: 50%;
            background: rgba(0,183,255,.26);
        }

        .shape.s4 {
            width: 62px;
            height: 62px;
            right: 28%;
            bottom: 20%;
            border: 1px dashed rgba(255,110,136,.22);
            border-radius: 50%;
        }

        .particle {
            width: 4px;
            height: 4px;
            border-radius: 50%;
            opacity: .6;
            box-shadow: 0 0 10px currentColor;
            animation: particleRise linear infinite;
        }

        .particle.p1 { left: 8%; bottom: 8%; color:#4bb5ff; animation-duration:11s; animation-delay:-2s; }
        .particle.p2 { left:22%; bottom:4%; color:#69d1ff; animation-duration:13s; animation-delay:-5s; }
        .particle.p3 { left:56%; bottom:6%; color:#8e79ff; animation-duration:15s; animation-delay:-3s; }
        .particle.p4 { left:72%; bottom:8%; color:#ff6a8a; animation-duration:12s; animation-delay:-6s; }
        .particle.p5 { left:88%; bottom:4%; color:#ff8c6b; animation-duration:14s; animation-delay:-4s; }

        @keyframes floatOrb {
            from { transform: translate(-12px,-8px) scale(1); }
            to   { transform: translate(22px,18px) scale(1.08); }
        }

        @keyframes drift {
            0%   { transform: translateY(0) rotate(0deg); }
            50%  { transform: translateY(-14px) rotate(8deg); }
            100% { transform: translateY(10px) rotate(-8deg); }
        }

        @keyframes hazeMove {
            from { transform: translate3d(-2%,-1%,0) scale(1); }
            to   { transform: translate3d(2%,1.5%,0) scale(1.08); }
        }

        @keyframes auroraMove {
            from { transform: translate3d(0,0,0) rotate(-8deg) scale(1); }
            to   { transform: translate3d(2vw,-1vh,0) rotate(8deg) scale(1.08); }
        }

        @keyframes particleRise {
            0%   { transform: translateY(0) scale(.8); opacity:0; }
            15%  { opacity:.7; }
            70%  { opacity:.4; }
            100% { transform: translateY(-80vh) scale(1.3); opacity:0; }
        }

        .page {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: clamp(18px, 3vh, 42px) clamp(12px, 3vw, 48px) 32px;
        }

        .shell {
            width: min(1480px, 100%);
            animation: shellIn .6s cubic-bezier(.2,.8,.2,1) both;
        }

        @keyframes shellIn {
            from { opacity:0; transform:translateY(16px) scale(.985); }
            to   { opacity:1; transform:none; }
        }

        .utility-bar {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:16px;
            margin-bottom:18px;
        }

        .session-chip {
            display:inline-flex;
            align-items:center;
            gap:10px;
            min-height:42px;
            padding:8px 15px 8px 9px;
            border:1px solid rgba(255,255,255,.12);
            border-radius:999px;
            color:#dceafa;
            background:rgba(255,255,255,.08);
            box-shadow:0 10px 24px rgba(0,0,0,.14);
            backdrop-filter:blur(16px);
            font-size:12px;
            font-weight:700;
        }

        .session-dot {
            width:28px;
            height:28px;
            display:grid;
            place-items:center;
            border-radius:50%;
            color:#fff;
            background:linear-gradient(135deg,#1f85ff,#5facff);
            box-shadow:0 8px 18px rgba(31,133,255,.30);
        }

        .session-dot svg { width:14px; height:14px; }

        .logout {
            display:inline-flex;
            min-height:42px;
            align-items:center;
            justify-content:center;
            gap:8px;
            padding:9px 15px;
            border:1px solid rgba(255,255,255,.12);
            border-radius:14px;
            color:#ffe0e4;
            background:rgba(255,255,255,.08);
            box-shadow:0 10px 24px rgba(0,0,0,.14);
            backdrop-filter:blur(16px);
            text-decoration:none;
            font-size:13px;
            font-weight:800;
            transition:.2s ease;
        }

        .logout svg {
            width:16px;
            height:16px;
            transition:transform .18s ease;
        }

        .logout:hover {
            transform:translateY(-2px);
            background:rgba(255,255,255,.12);
            border-color:rgba(255,255,255,.20);
        }

        .logout:hover svg { transform:translateX(2px); }

        .hero {
            max-width:860px;
            margin:0 auto 22px;
            text-align:center;
        }

        .eyebrow {
            display:inline-flex;
            align-items:center;
            gap:8px;
            margin:0 0 7px;
            color:#c3d6ea;
            font-size:10px;
            font-weight:900;
            letter-spacing:.16em;
            text-transform:uppercase;
        }

        .eyebrow::before,
        .eyebrow::after {
            content:"";
            width:26px;
            height:1px;
            background:linear-gradient(90deg,transparent,rgba(203,223,244,.45));
        }

        .eyebrow::after {
            background:linear-gradient(90deg,rgba(203,223,244,.45),transparent);
        }

        h1 {
            margin:0;
            color:var(--ink-strong);
            font-size:clamp(31px,3.8vw,54px);
            line-height:1.02;
            letter-spacing:-.05em;
            font-weight:900;
            text-shadow:0 10px 28px rgba(0,0,0,.26);
        }

        .hero-accent {
            position:relative;
            display:inline-block;
            isolation:isolate;
        }

        .hero-accent::after {
            content:"";
            position:absolute;
            left:4%;
            right:4%;
            bottom:.08em;
            height:.24em;
            border-radius:999px;
            background:linear-gradient(90deg,rgba(21,130,255,.30),rgba(255,56,93,.24));
            z-index:-1;
            transform:skewX(-10deg);
        }

        .intro {
            max-width:760px;
            margin:9px auto 0;
            color:var(--muted);
            font-size:13px;
        }

        .alert {
            max-width:760px;
            margin:0 auto 14px;
            padding:10px 14px;
            border:1px solid rgba(255,255,255,.12);
            border-radius:14px;
            color:#ffe7eb;
            background:rgba(210,52,64,.16);
            text-align:center;
            font-size:12px;
            backdrop-filter:blur(12px);
        }

        .grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:clamp(14px, 1.6vw, 28px);
            perspective:1200px;
        }

        .country {
            --rx:0deg;
            --ry:0deg;
            --mx:50%;
            --my:50%;

            position:relative;
            overflow:hidden;
            min-height:352px;
            padding:1px;
            border-radius:28px;
            background:
                linear-gradient(
                    145deg,
                    color-mix(in srgb,var(--country) 58%,rgba(255,255,255,.10)),
                    rgba(255,255,255,.03) 45%,
                    color-mix(in srgb,var(--country) 48%,rgba(255,255,255,.08))
                );
            box-shadow:
                0 28px 64px rgba(0,0,0,.22),
                0 4px 14px rgba(0,0,0,.08);
            transform:rotateX(var(--rx)) rotateY(var(--ry));
            transform-style:preserve-3d;
            transition:transform .22s ease,box-shadow .25s ease,filter .25s ease;
            animation:cardIn .66s cubic-bezier(.2,.8,.2,1) both;
        }

        .country:nth-child(1) { animation-delay:.08s; }
        .country:nth-child(2) { animation-delay:.16s; }

        @keyframes cardIn {
            from { opacity:0; transform:translateY(22px) scale(.976); }
            to   { opacity:1; transform:translateY(0) scale(1); }
        }

        .country:hover {
            box-shadow:
                0 34px 80px color-mix(in srgb,var(--country) 18%,rgba(0,0,0,.30)),
                0 10px 20px rgba(0,0,0,.10);
            filter:saturate(1.08);
        }

        .country-inner {
            position:relative;
            min-height:350px;
            height:100%;
            overflow:hidden;
            display:flex;
            flex-direction:column;
            padding:24px;
            border-radius:27px;
            background:
                linear-gradient(160deg,rgba(10,20,38,.90),rgba(17,27,51,.84));
            backdrop-filter:blur(18px);
        }

        .country-inner::before {
            content:"";
            position:absolute;
            inset:0;
            pointer-events:none;
            background:
                radial-gradient(240px circle at 78% 14%,color-mix(in srgb,var(--country) 18%,transparent),transparent 68%),
                radial-gradient(280px circle at var(--mx) var(--my),color-mix(in srgb,var(--country) 10%,transparent),transparent 70%);
        }

        .country-inner::after {
            content:"";
            position:absolute;
            inset:0;
            pointer-events:none;
            background:
                linear-gradient(180deg,rgba(255,255,255,.05),transparent 30%),
                linear-gradient(135deg,rgba(255,255,255,.02),transparent 45%);
        }

        .country-glow {
            position:absolute;
            width:220px;
            height:220px;
            top:-90px;
            right:-70px;
            border-radius:50%;
            background:radial-gradient(circle,color-mix(in srgb,var(--country) 30%,transparent),transparent 72%);
            transition:transform .45s cubic-bezier(.2,.8,.2,1);
            pointer-events:none;
        }

        .country-ring {
            position:absolute;
            right:-72px;
            bottom:-92px;
            width:220px;
            height:220px;
            border:28px solid color-mix(in srgb,var(--country) 16%,transparent);
            border-radius:50%;
            transition:transform .45s cubic-bezier(.2,.8,.2,1),border-color .25s ease;
            pointer-events:none;
        }

        .country-lines {
            position:absolute;
            left:-10px;
            bottom:22px;
            width:160px;
            height:100px;
            opacity:.13;
            pointer-events:none;
            background:
                repeating-linear-gradient(
                    135deg,
                    color-mix(in srgb,var(--country) 46%,transparent) 0 2px,
                    transparent 2px 10px
                );
            mask-image:linear-gradient(90deg,rgba(0,0,0,.9),transparent 95%);
            transform:rotate(-10deg);
        }

        .country:hover .country-glow {
            transform:scale(1.16) translate(-8px,8px);
        }

        .country:hover .country-ring {
            transform:translate(-12px,-10px) scale(1.05);
            border-color:color-mix(in srgb,var(--country) 20%,transparent);
        }

        .card-topline {
            position:absolute;
            top:0;
            left:22px;
            right:22px;
            height:3px;
            border-radius:0 0 999px 999px;
            background:linear-gradient(90deg,transparent,color-mix(in srgb,var(--country) 88%,#fff),transparent);
            opacity:.96;
        }

        .region-pill {
            position:relative;
            z-index:2;
            display:inline-flex;
            align-items:center;
            gap:7px;
            margin-bottom:18px;
            padding:6px 11px;
            border:1px solid color-mix(in srgb,var(--country) 24%,rgba(255,255,255,.22));
            border-radius:999px;
            color:#f0f6ff;
            background:rgba(255,255,255,.08);
            font-size:10px;
            font-weight:900;
            letter-spacing:.08em;
            text-transform:uppercase;
            width:fit-content;
            backdrop-filter:blur(10px);
        }

        .region-pill::before {
            content:"";
            width:7px;
            height:7px;
            border-radius:50%;
            background:var(--country);
            box-shadow:0 0 0 5px color-mix(in srgb,var(--country) 10%,transparent);
        }

        .country-head {
            position:relative;
            z-index:2;
            display:flex;
            align-items:center;
            gap:22px;
            min-height:82px;
            margin-bottom:18px;
        }

        /*
         * El logo ya NO va dentro de un cuadro.
         * Se respeta la proporción original de cada imagen.
         */
        .company-logo {
            flex:0 0 148px;
            width:148px;
            min-width:148px;
            height:78px;
            display:flex;
            align-items:center;
            justify-content:flex-start;
            padding:0;
            border:0;
            border-radius:0;
            background:transparent;
            box-shadow:none;
            overflow:visible;
        }

        .company-logo img {
            display:block;
            width:auto;
            height:auto;
            max-width:100%;
            max-height:76px;
            object-fit:contain;
            object-position:left center;
            filter:drop-shadow(0 9px 16px rgba(0,0,0,.18));
            transform-origin:left center;
            transition:transform .28s cubic-bezier(.2,.8,.2,1),filter .28s ease;
        }

        /* El logo de Conectar es más vertical. */
        .company-logo.logo-co img {
            max-width:106px;
            max-height:76px;
        }

        /* El logo de Telecomunicaciones es horizontal. */
        .company-logo.logo-pe img {
            max-width:148px;
            max-height:60px;
        }

        .country:hover .company-logo img {
            transform:translateY(-2px) scale(1.04);
            filter:drop-shadow(0 13px 22px color-mix(in srgb,var(--country) 18%,rgba(0,0,0,.24)));
        }

        .country-title {
            min-width:0;
        }

        .country-title small {
            display:block;
            margin-bottom:5px;
            color:#8da9c5;
            font-size:10px;
            font-weight:850;
            letter-spacing:.10em;
            text-transform:uppercase;
        }

        .country h2 {
            margin:0;
            color:#f4f9ff;
            font-size:clamp(22px,2.1vw,27px);
            line-height:1.05;
            letter-spacing:-.035em;
            font-weight:900;
            overflow-wrap:anywhere;
            text-shadow:0 8px 20px rgba(0,0,0,.18);
        }

        .country-copy {
            position:relative;
            z-index:2;
            min-height:62px;
            margin:0 0 18px;
            color:#b7c8db;
            font-size:13px;
            line-height:1.55;
        }

        .country-copy strong {
            color:#fff;
            font-weight:800;
        }

        .country-meta {
            position:relative;
            z-index:2;
            display:flex;
            gap:10px;
            flex-wrap:wrap;
            margin-bottom:18px;
        }

        .meta-badge {
            display:inline-flex;
            align-items:center;
            gap:7px;
            padding:8px 11px;
            border:1px solid rgba(255,255,255,.10);
            border-radius:999px;
            background:rgba(255,255,255,.08);
            color:#d6e4f3;
            font-size:11px;
            font-weight:700;
            backdrop-filter:blur(8px);
        }

        .meta-badge .dot {
            width:6px;
            height:6px;
            border-radius:50%;
            background:var(--country);
            box-shadow:0 0 8px var(--country);
        }

        .country form {
            position:relative;
            z-index:3;
            margin-top:auto;
        }

        .country button {
            position:relative;
            overflow:hidden;
            width:100%;
            min-height:50px;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:10px;
            border:0;
            border-radius:14px;
            color:#fff;
            background:
                linear-gradient(
                    135deg,
                    color-mix(in srgb,var(--country) 92%,#fff 8%),
                    color-mix(in srgb,var(--country) 84%,#000 16%)
                );
            box-shadow:
                0 14px 26px color-mix(in srgb,var(--country) 24%,transparent),
                inset 0 1px 0 rgba(255,255,255,.20);
            font:inherit;
            font-size:14px;
            font-weight:900;
            cursor:pointer;
            transition:.18s ease;
        }

        .country button::before {
            content:"";
            position:absolute;
            inset:-2px auto -2px -44%;
            width:36%;
            opacity:0;
            transform:skewX(-20deg);
            background:linear-gradient(90deg,transparent,rgba(255,255,255,.36),transparent);
            transition:left .55s ease,opacity .2s ease;
        }

        .country button:hover::before {
            left:112%;
            opacity:1;
        }

        .country button:hover {
            transform:translateY(-2px);
            filter:brightness(1.03) saturate(1.06);
            box-shadow:
                0 18px 34px color-mix(in srgb,var(--country) 30%,transparent),
                inset 0 1px 0 rgba(255,255,255,.26);
        }

        .country button:active {
            transform:translateY(0) scale(.992);
        }

        .country button svg {
            width:17px;
            height:17px;
            transition:transform .18s ease;
        }

        .country button:hover svg {
            transform:translateX(3px);
        }

        .country button.is-loading {
            pointer-events:none;
            filter:saturate(.78);
        }

        .country button.is-loading svg {
            display:none;
        }

        .spinner {
            display:none;
            width:16px;
            height:16px;
            border:2px solid rgba(255,255,255,.38);
            border-top-color:#fff;
            border-radius:50%;
            animation:spin .7s linear infinite;
        }

        .country button.is-loading .spinner {
            display:inline-block;
        }

        @keyframes spin {
            to { transform:rotate(360deg); }
        }

        .country button:focus-visible,
        .logout:focus-visible {
            outline:3px solid rgba(111,179,255,.30);
            outline-offset:3px;
        }

        .empty {
            padding:32px;
            border:1px solid var(--line);
            border-radius:22px;
            background:rgba(255,255,255,.08);
            box-shadow:0 18px 40px rgba(0,0,0,.14);
            text-align:center;
            color:#dbe9f6;
            backdrop-filter:blur(16px);
        }

        .footer-note {
            margin-top:14px;
            text-align:center;
            color:#bfd0e2;
            font-size:11px;
        }

        .footer-note strong {
            color:#f0f6ff;
        }

        @media (max-width: 900px) {
            .grid {
                grid-template-columns:1fr;
            }

            .country,
            .country-inner {
                min-height:0;
            }
        }

        @media (min-width: 1400px) {
            .utility-bar {
                margin-bottom:24px;
            }

            .hero {
                margin-bottom:28px;
            }

            .country {
                min-height:380px;
            }
        }

        @media (max-width: 640px) {
            .page {
                padding:18px 12px 22px;
            }

            .utility-bar {
                flex-direction:column;
                align-items:stretch;
                gap:10px;
                margin-bottom:14px;
            }

            .logout {
                justify-content:center;
            }

            .hero {
                margin-bottom:16px;
            }

            h1 {
                font-size:34px;
            }

            .intro {
                font-size:13px;
            }

            .country-head {
                align-items:flex-start;
                flex-direction:column;
                gap:12px;
            }

            .company-logo {
                flex-basis:auto;
                width:150px;
                min-width:0;
                height:68px;
            }

            .company-logo.logo-co img {
                max-width:96px;
                max-height:68px;
            }

            .company-logo.logo-pe img {
                max-width:150px;
                max-height:56px;
            }

            .country h2 {
                font-size:25px;
            }

            .country-copy {
                min-height:0;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration:.001ms !important;
                animation-iteration-count:1 !important;
                transition-duration:.001ms !important;
                scroll-behavior:auto !important;
            }

            .country {
                transform:none !important;
            }
        }
    </style>
</head>
<body data-mesa-selector-pais="1">

<div class="ambient" aria-hidden="true">
    <span class="orb one"></span>
    <span class="orb two"></span>
    <span class="orb three"></span>

    <span class="aurora a1"></span>
    <span class="aurora a2"></span>
    <span class="aurora a3"></span>

    <span class="shape s1"></span>
    <span class="shape s2"></span>
    <span class="shape s3"></span>
    <span class="shape s4"></span>

    <span class="particle p1"></span>
    <span class="particle p2"></span>
    <span class="particle p3"></span>
    <span class="particle p4"></span>
    <span class="particle p5"></span>
</div>

<div class="page">
    <main class="shell">

        <div class="utility-bar">
            <div class="session-chip" title="Sesión activa">
                <span class="session-dot" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none">
                        <path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm7 8a7 7 0 0 0-14 0"
                              stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </span>
                <span>Sesión de <strong><?= $nombre ?></strong></span>
            </div>

            <a class="logout" href="logout.php">
                <span>Cerrar sesión</span>
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M10 17l5-5-5-5M15 12H3M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4"
                          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </a>
        </div>

        <header class="hero">
            <p class="eyebrow">Mesa de servicio</p>
            <h1>Seleccione su <span class="hero-accent">operación</span></h1>
            <p class="intro">
                Elija el entorno donde desea trabajar. Cada operación conserva de forma independiente
                sus usuarios, datos y configuración.
            </p>
        </header>

        <?php if ($error !== ''): ?>
            <div class="alert" role="alert">
                No fue posible seleccionar esa operación. Intente nuevamente.
            </div>
        <?php endif; ?>

        <?php if (!$paises): ?>
            <div class="empty">
                No hay operaciones activas disponibles en este momento.
            </div>
        <?php else: ?>
            <section class="grid" aria-label="Operaciones disponibles">
                <?php foreach ($paises as $pais): ?>
                    <?php
                    $rawColor = (string) ($pais['color_primario'] ?? '#0f6fec');
                    $safeColor = preg_match('/^#[0-9a-fA-F]{6}$/', $rawColor)
                        ? $rawColor
                        : '#0f6fec';

                    $color = htmlspecialchars($safeColor, ENT_QUOTES, 'UTF-8');
                    $codigo = strtoupper((string) ($pais['codigo'] ?? ''));

                    $logo = (fn ($__mesaMatchValue13) => (($__mesaMatchValue13 === ('CO')) ? ('assets/img/logo-conectar.png') : ((($__mesaMatchValue13 === ('PE')) ? ('assets/img/logo-telecomunicaciones.png') : ('')))))($codigo);

                    $region = (fn ($__mesaMatchValue14) => (($__mesaMatchValue14 === ('CO')) ? ('Colombia') : ((($__mesaMatchValue14 === ('PE')) ? ('Perú') : ('Operación')))))($codigo);

                    $nombreOperacion = htmlspecialchars(
                        (string) $pais['nombre'],
                        ENT_QUOTES,
                        'UTF-8'
                    );
                    ?>

                    <article
                        class="country"
                        style="--country: <?= $color ?>;"
                        data-tilt-card
                        data-theme="<?= $codigo === 'CO' ? 'blue' : ($codigo === 'PE' ? 'red' : '') ?>"
                    >
                        <div class="country-inner">
                            <span class="country-glow" aria-hidden="true"></span>
                            <span class="country-ring" aria-hidden="true"></span>
                            <span class="country-lines" aria-hidden="true"></span>
                            <span class="card-topline" aria-hidden="true"></span>

                            <div class="region-pill">
                                <?= htmlspecialchars($region, ENT_QUOTES, 'UTF-8') ?>
                            </div>

                            <div class="country-head">
                                <?php if ($logo !== ''): ?>
                                    <div class="company-logo <?= $codigo === 'CO' ? 'logo-co' : ($codigo === 'PE' ? 'logo-pe' : '') ?>">
                                        <img
                                            src="<?= htmlspecialchars($logo, ENT_QUOTES, 'UTF-8') ?>"
                                            alt="Logo <?= $nombreOperacion ?>"
                                            loading="eager"
                                            decoding="async"
                                        >
                                    </div>
                                <?php endif; ?>

                                <div class="country-title">
                                    <small>Operación empresarial</small>
                                    <h2><?= $nombreOperacion ?></h2>
                                </div>
                            </div>

                            <p class="country-copy">
                                Acceda al entorno administrativo de <strong><?= $nombreOperacion ?></strong>
                                y trabaje exclusivamente con la información asociada a esta operación.
                            </p>

                            <div class="country-meta">
                                <span class="meta-badge">
                                    <span class="dot"></span>
                                    Entorno independiente
                                </span>

                                <span class="meta-badge">
                                    <span class="dot"></span>
                                    Acceso seguro
                                </span>
                            </div>

                            <form method="post" data-operation-form>
                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= htmlspecialchars(
                                        seguridadTokenCsrf(),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                >

                                <input
                                    type="hidden"
                                    name="id_pais_operacion"
                                    value="<?= (int) $pais['id_pais_operacion'] ?>"
                                >

                                <button type="submit">
                                    <span class="spinner" aria-hidden="true"></span>
                                    <span class="button-label">Ingresar a <?= $nombreOperacion ?></span>
                                    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                                        <path d="M5 12h14M13 6l6 6-6 6"
                                              stroke="currentColor"
                                              stroke-width="2"
                                              stroke-linecap="round"
                                              stroke-linejoin="round"/>
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </article>
                <?php endforeach; ?>
            </section>
        <?php endif; ?>

        <p class="footer-note">
            <strong>Mesa de Servicio</strong> · Entorno administrativo seguro
        </p>

    </main>
</div>

<script>
    window.__MESA_SELECTOR_PAIS__ = true;

    (() => {
        const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        const cards = document.querySelectorAll('[data-tilt-card]');
        const body = document.body;

        if (!reduceMotion) {
            cards.forEach((card) => {
                const maxTilt = 4;

                card.addEventListener('pointermove', (event) => {
                    if (event.pointerType === 'touch') return;

                    const rect = card.getBoundingClientRect();
                    const x = event.clientX - rect.left;
                    const y = event.clientY - rect.top;

                    const px = x / rect.width;
                    const py = y / rect.height;

                    const rotateY = (px - .5) * (maxTilt * 2);
                    const rotateX = (.5 - py) * (maxTilt * 2);

                    card.style.setProperty('--rx', `${rotateX.toFixed(2)}deg`);
                    card.style.setProperty('--ry', `${rotateY.toFixed(2)}deg`);
                    card.style.setProperty('--mx', `${(px * 100).toFixed(1)}%`);
                    card.style.setProperty('--my', `${(py * 100).toFixed(1)}%`);
                });

                card.addEventListener('pointerenter', () => {
                    const theme = card.dataset.theme || '';
                    body.classList.remove('dynamic-blue', 'dynamic-red');

                    if (theme === 'blue') {
                        body.classList.add('dynamic-blue');
                    } else if (theme === 'red') {
                        body.classList.add('dynamic-red');
                    }
                });

                card.addEventListener('pointerleave', () => {
                    card.style.setProperty('--rx', '0deg');
                    card.style.setProperty('--ry', '0deg');
                    card.style.setProperty('--mx', '50%');
                    card.style.setProperty('--my', '50%');
                    body.classList.remove('dynamic-blue', 'dynamic-red');
                });
            });
        }

        document.querySelectorAll('[data-operation-form]').forEach((form) => {
            form.addEventListener('submit', () => {
                const button = form.querySelector('button[type="submit"]');
                const label = button?.querySelector('.button-label');

                if (!button) return;

                button.classList.add('is-loading');
                button.setAttribute('aria-busy', 'true');

                if (label) {
                    label.textContent = 'Ingresando...';
                }
            });
        });
    })();
</script>


</body>
</html>
