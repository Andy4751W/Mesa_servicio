<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/calendarioLaboral.php';

seguridadExigirRol([1]);
$idPaisOperacion = paisExigirContexto();
$nombrePaisOperacion = paisContextoNombre();
$codigoPaisOperacion = paisContextoCodigo();
calendarioAsegurarTablaHorarios($conn);

function escaparHorario($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

function redirigirHorarios(string $mensaje): void
{
    header('Location: horarios.php?msg=' . rawurlencode($mensaje), true, 303);
    exit;
}

$diasSemana = [
    1 => 'Lunes',
    2 => 'Martes',
    3 => 'Miércoles',
    4 => 'Jueves',
    5 => 'Viernes',
    6 => 'Sábado',
    7 => 'Domingo',
];
$horaPredeterminada = calendarioHorariosPredeterminados();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    seguridadExigirOrigenPost();
    seguridadExigirCsrfPost();
    $accion = (string) ($_POST['accion'] ?? '');

    if ($accion !== 'guardar_horario') {
        redirigirHorarios('solicitud_invalida');
    }

    $horarios = [];
    $hayDiaActivo = false;
    $horaValida = static fn (string $hora): bool => preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $hora) === 1;

    for ($dia = 1; $dia <= 7; $dia++) {
        $activo = isset($_POST['activo_' . $dia]) ? 1 : 0;
        $inicio = trim((string) ($_POST['inicio_' . $dia] ?? ''));
        $fin = trim((string) ($_POST['fin_' . $dia] ?? ''));

        if ($activo === 1) {
            $hayDiaActivo = true;
            if (!$horaValida($inicio) || !$horaValida($fin) || $fin <= $inicio) {
                redirigirHorarios('horario_invalido');
            }
        } else {
            $inicio = $horaValida($inicio) ? $inicio : $horaPredeterminada[$dia]['inicio'];
            $fin = $horaValida($fin) ? $fin : $horaPredeterminada[$dia]['fin'];
        }

        $horarios[$dia] = [$activo, $inicio, $fin];
    }

    if (!$hayDiaActivo) {
        redirigirHorarios('sin_dias_activos');
    }

    try {
        $stmt = $conn->prepare(
            "INSERT INTO horarios_laborales_sla
                (id_pais_operacion, dia_semana, activo, hora_inicio, hora_fin, actualizado_por)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                activo = VALUES(activo),
                hora_inicio = VALUES(hora_inicio),
                hora_fin = VALUES(hora_fin),
                actualizado_por = VALUES(actualizado_por),
                actualizado_en = CURRENT_TIMESTAMP"
        );
        $idUsuario = (int) ($_SESSION['usuario_id'] ?? 0);
        foreach ($horarios as $dia => [$activo, $inicio, $fin]) {
            $stmt->bind_param(
                'iiissi',
                $idPaisOperacion,
                $dia,
                $activo,
                $inicio,
                $fin,
                $idUsuario
            );
            $stmt->execute();
        }
        $stmt->close();
        redirigirHorarios('guardado');
    } catch (Throwable $e) {
        error_log('No fue posible guardar el horario laboral SLA: ' . $e->getMessage());
        redirigirHorarios('error');
    }
}

$horarios = calendarioHorariosLaborales($conn);
$mensajeActual = (string) ($_GET['msg'] ?? '');
$mensajes = [
    'guardado' => ['ok', 'El horario laboral fue guardado para esta operación.'],
    'horario_invalido' => ['error', 'Revise las horas: deben estar en formato HH:MM y la hora final debe ser posterior.'],
    'sin_dias_activos' => ['error', 'Active al menos un día laboral para que el SLA pueda avanzar.'],
    'solicitud_invalida' => ['error', 'La solicitud no es válida. Actualice la página e inténtelo nuevamente.'],
    'error' => ['error', 'No fue posible guardar el horario laboral.'],
];
$mensaje = $mensajes[$mensajeActual] ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Horarios laborales | SMARTDESK</title>
    <style>
        :root{--primary:<?= $codigoPaisOperacion === 'PE' ? '#e87516' : '#1769d2' ?>;--primary-dark:<?= $codigoPaisOperacion === 'PE' ? '#8d3e08' : '#0b4fae' ?>;--ink:#153452;--muted:#617891;--line:#d8e4ef;--surface:#fff;--soft:#f3f8fd;--ok:#087443;--danger:#b42318}*{box-sizing:border-box}body{margin:0;color:var(--ink);background:#eef4f9;font:14px/1.5 Inter,"Segoe UI",Arial,sans-serif}.page{width:min(980px,calc(100% - 28px));margin:26px auto 48px}.hero{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:19px 22px;border:1px solid #b8cbd8;border-radius:16px;color:#fff;background:linear-gradient(120deg,#0d527d,#3d6876);box-shadow:0 10px 28px rgba(18,56,94,.12)}.hero h1{margin:0;color:#fff;font-size:24px;line-height:1.2}.hero p{margin:4px 0 0;color:#f4fbff;font-size:12px}.hero-badge{display:inline-flex;align-items:center;min-height:34px;padding:8px 13px;border:1px solid rgba(255,255,255,.7);border-radius:999px;color:var(--primary-dark)!important;background:#fff!important;box-shadow:0 3px 10px rgba(8,42,64,.12);font-size:11px;font-weight:850;white-space:nowrap}.card{margin-top:16px;padding:18px;border:1px solid var(--line);border-radius:16px;background:#fff!important;box-shadow:0 12px 30px rgba(18,56,94,.08)}.card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:12px}.card-head h2{margin:0;font-size:18px}.card-head p{margin:4px 0 0;color:var(--muted);font-size:11px}.alert{margin:0 0 13px;padding:10px 12px;border:1px solid;border-radius:9px;font-size:12px;font-weight:700}.alert.ok{color:var(--ok);border-color:#a8dcc1;background:#effaf4}.alert.error{color:var(--danger);border-color:#edb8b8;background:#fff3f3}.schedule{width:100%;border-collapse:collapse}.schedule th,.schedule td{padding:11px 10px;border-bottom:1px solid #e7eef5;text-align:left;vertical-align:middle}.schedule th{color:#5c7288;font-size:10px;letter-spacing:.08em;text-transform:uppercase}.schedule td:first-child{font-weight:750}.schedule input[type=time]{width:100%;min-height:38px;padding:0 10px;border:1px solid #cbdbea;border-radius:8px;color:var(--ink);background:#fff;font:inherit}.schedule input[type=time]:disabled{color:#8999a9;background:#edf1f4;cursor:not-allowed}.day-toggle{display:inline-flex;align-items:center;gap:8px;color:var(--ink);font-size:12px;font-weight:700}.day-toggle input{width:17px;height:17px;accent-color:var(--primary)}.actions{display:flex;justify-content:flex-end;gap:8px;margin-top:15px}.button{min-height:39px;padding:8px 14px;border:1px solid var(--primary);border-radius:8px;color:#fff;background:var(--primary);font-weight:800;cursor:pointer}.button:hover{background:var(--primary-dark)}.note{margin:12px 0 0;color:var(--muted);font-size:11px}.empty-warning{padding:12px;border:1px dashed #edb8b8;border-radius:9px;color:#9f2e2e;background:#fff7f7;font-size:11px}@media(max-width:650px){.page{width:min(100% - 18px,520px);margin:13px auto 28px}.hero{align-items:flex-start;flex-direction:column;padding:16px}.hero h1{font-size:21px}.hero-badge{width:100%;justify-content:center;white-space:normal}.card{padding:12px;overflow:auto}.schedule{min-width:620px}.card-head{display:block}.actions{justify-content:stretch}.button{width:100%}}
    </style>
</head>
<body>
<main class="page">
    <header class="hero">
        <div><h1>Horarios de atención</h1><p>Configure los días y horas que consumen tiempo de SLA para <?= escaparHorario($nombrePaisOperacion) ?>.</p></div>
        <span class="hero-badge">Calendario <?= escaparHorario($nombrePaisOperacion) ?></span>
    </header>
    <section class="card">
        <div class="card-head"><div><h2>Jornada laboral</h2><p>Los días desactivados y los feriados activos no cuentan en el cálculo del SLA.</p></div></div>
        <?php if ($mensaje): ?><div class="alert <?= escaparHorario($mensaje[0]) ?>"><?= escaparHorario($mensaje[1]) ?></div><?php endif; ?>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= escaparHorario(seguridadTokenCsrf()) ?>">
            <input type="hidden" name="accion" value="guardar_horario">
            <table class="schedule">
                <thead><tr><th>Día</th><th>Laboral</th><th>Hora inicio</th><th>Hora fin</th></tr></thead>
                <tbody>
                <?php foreach ($diasSemana as $numeroDia => $nombreDia): $horario = $horarios[$numeroDia] ?? $horaPredeterminada[$numeroDia]; ?>
                    <tr>
                        <td><?= escaparHorario($nombreDia) ?></td>
                        <td><label class="day-toggle"><input type="checkbox" name="activo_<?= $numeroDia ?>" value="1" <?= $horario['activo'] ? 'checked' : '' ?> data-day-toggle="<?= $numeroDia ?>"><span>Activo</span></label></td>
                        <td><input type="time" name="inicio_<?= $numeroDia ?>" value="<?= escaparHorario($horario['inicio']) ?>" data-day-start="<?= $numeroDia ?>" <?= $horario['activo'] ? '' : 'disabled' ?>></td>
                        <td><input type="time" name="fin_<?= $numeroDia ?>" value="<?= escaparHorario($horario['fin']) ?>" data-day-end="<?= $numeroDia ?>" <?= $horario['activo'] ? '' : 'disabled' ?>></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p class="note">Ejemplo: puede habilitar el sábado o ampliar la jornada hasta las 18:00 para esta operación sin afectar a los demás países.</p>
            <div class="actions"><button class="button" type="submit">Guardar horario</button></div>
        </form>
    </section>
</main>
<script>
document.querySelectorAll('[data-day-toggle]').forEach(function (checkbox) {
    checkbox.addEventListener('change', function () {
        var dia = checkbox.dataset.dayToggle;
        document.querySelectorAll('[data-day-start="' + dia + '"],[data-day-end="' + dia + '"]').forEach(function (campo) {
            campo.disabled = !checkbox.checked;
        });
    });
});
</script>
<style id="horarios-contrast-fix">
body.mesa-php-shell .page .hero-badge,
.page .hero-badge {
    color: #153452 !important;
    background: #ffffff !important;
    border-color: #ffffff !important;
    opacity: 1 !important;
    text-shadow: none !important;
}
body.mesa-php-shell .page .card,
.page .card {
    background: #ffffff !important;
}
body.mesa-php-shell .page .card-head,
.page .card-head {
    background: #ffffff !important;
    border-color: transparent !important;
}
body.mesa-php-shell .page .card-head h2,
body.mesa-php-shell .page .card-head p,
.page .card-head h2,
.page .card-head p {
    opacity: 1 !important;
}
</style>
</body>
</html>
