<?php
declare(strict_types=1);

// La imagen del administrador debe poder mostrarse en el selector nacional,
// antes de que se elija Conectar o Telecomunicaciones.
if (!defined('MESA_PERMITE_SIN_PAIS')) {
    define('MESA_PERMITE_SIN_PAIS', true);
}

require_once APP_ROOT . '/security/validarSesion.php';
require_once APP_ROOT . '/core/perfil.php';

seguridadExigirRol([1, 2, 3]);

$rolSesion = (int) ($_SESSION['rol'] ?? 0);
$idUsuarioSesion = (int) ($_SESSION['usuario_id'] ?? 0);

if ($rolSesion !== 1) {
    paisExigirContexto();
}

/*
 * Sin parámetro se conserva el comportamiento original y se muestra la
 * imagen del usuario autenticado.
 *
 * El parámetro "usuario" se usa en las conversaciones para mostrar la
 * imagen del autor de cada mensaje. Por seguridad, solo se permite acceder
 * a perfiles pertenecientes a la misma operación seleccionada.
 */
$idUsuarioSolicitado = filter_input(
    INPUT_GET,
    'usuario',
    FILTER_VALIDATE_INT
) ?: $idUsuarioSesion;

if ($idUsuarioSolicitado < 1) {
    http_response_code(404);
    exit;
}

$nombrePerfil = (string) ($_SESSION['usuario'] ?? 'Usuario');
$idPaisPerfil = paisContextoId();

if ($idUsuarioSolicitado !== $idUsuarioSesion) {
    $idPaisContexto = paisContextoId();

    if ($idPaisContexto < 1) {
        http_response_code(403);
        exit;
    }

    $stmt = $conn->prepare(
        "SELECT id_usuario, nombre, id_pais_operacion
         FROM usuarios
         WHERE id_usuario = ?
         LIMIT 1"
    );
    $stmt->bind_param('i', $idUsuarioSolicitado);
    $stmt->execute();
    $usuarioPerfil = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$usuarioPerfil) {
        http_response_code(404);
        exit;
    }

    if ((int) ($usuarioPerfil['id_pais_operacion'] ?? 0) !== $idPaisContexto) {
        http_response_code(403);
        exit;
    }

    $nombrePerfil = trim((string) ($usuarioPerfil['nombre'] ?? 'Usuario'));
    $idPaisPerfil = (int) ($usuarioPerfil['id_pais_operacion'] ?? 0);
}

/* No mantener bloqueada la sesión durante la lectura desde Microsoft Graph. */
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$imagen = perfilImagenActual($conn, $idUsuarioSolicitado);
$contenidoRemoto = null;

if ($imagen !== null) {
    $etagBase = hash(
        'sha256',
        (string) $imagen['ruta'] . '|'
        . (string) ($imagen['etag'] ?? '') . '|'
        . (string) ($imagen['sha256'] ?? '') . '|'
        . (string) $imagen['modificado'] . '|'
        . (string) $imagen['tamano']
    );
    $etag = '"' . $etagBase . '"';
    $cachePerfil = trim((string) ($_GET['v'] ?? '')) !== ''
        ? 'private, max-age=31536000, immutable'
        : 'private, max-age=300, must-revalidate';

    if (hash_equals($etag, trim((string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? '')))) {
        header('Cache-Control: ' . $cachePerfil);
        header('ETag: ' . $etag);
        http_response_code(304);
        exit;
    }
}

if ($imagen !== null && almacenamientoEsReferenciaGraph((string) $imagen['ruta'])) {
    try {
        $lecturaRemota = almacenamientoLeerGraph((string) $imagen['ruta']);
        $contenidoRemoto = $lecturaRemota['bytes'];
        $imagen['tamano'] = $lecturaRemota['tamano'];
    } catch (Throwable $e) {
        error_log('Perfil: imagen remota temporalmente no disponible.');
        $imagen = null;
    }
}

if ($imagen === null) {
    $iniciales = htmlspecialchars(
        perfilIniciales($nombrePerfil),
        ENT_QUOTES | ENT_XML1,
        'UTF-8'
    );

    $color = '#1167d8';
    $operacion = $idPaisPerfil > 0
        ? paisBuscarOperacion($conn, $idPaisPerfil)
        : null;

    if (paisContextoCodigo() === 'PE') {
        $color = '#f47c20';
    } elseif ($operacion && trim((string) ($operacion['color_primario'] ?? '')) !== '') {
        $color = (string) $operacion['color_primario'];
    }

    if (preg_match('/^#[0-9A-Fa-f]{6}$/', $color) !== 1) {
        $color = '#1167d8';
    }

    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 240 240">'
        . '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="'
        . htmlspecialchars($color, ENT_QUOTES | ENT_XML1, 'UTF-8')
        . '"/><stop offset="1" stop-color="#102a43"/></linearGradient></defs>'
        . '<rect width="240" height="240" rx="120" fill="url(#g)"/>'
        . '<text x="120" y="139" text-anchor="middle" fill="#fff" font-family="Segoe UI,Arial,sans-serif" font-size="72" font-weight="800">'
        . $iniciales . '</text></svg>';

    header('Content-Type: image/svg+xml; charset=UTF-8');
    header('Content-Length: ' . strlen($svg));
    header('Content-Disposition: inline; filename="perfil.svg"');
    header('Cache-Control: private, max-age=120, must-revalidate');
    header('X-Content-Type-Options: nosniff');
    echo $svg;
    exit;
}

header('Content-Type: ' . $imagen['mime']);
header('Content-Length: ' . $imagen['tamano']);
header('Content-Disposition: inline; filename="perfil"');
header('Cache-Control: ' . $cachePerfil);
header('ETag: ' . $etag);
header('X-Content-Type-Options: nosniff');
if (is_string($contenidoRemoto)) {
    echo $contenidoRemoto;
} else {
    readfile($imagen['ruta']);
}
exit;
