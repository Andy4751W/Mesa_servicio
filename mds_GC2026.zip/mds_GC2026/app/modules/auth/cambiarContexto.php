<?php
declare(strict_types=1);

/*
 * Un gestor puede trabajar temporalmente como solicitante sin modificar su
 * rol persistido en la tabla usuarios. El contexto queda limitado a la sesión
 * actual y se valida nuevamente en cada solicitud.
 */
require_once dirname(__DIR__, 2) . '/security/validarSesion.php';

if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Método no permitido.');
}

$rolBase = (int) ($_SESSION['rol_base'] ?? 0);
$esConsultaGlobal = !empty($_SESSION['permiso_consulta_global']);
if ($rolBase !== 2 && !$esConsultaGlobal) {
    http_response_code(403);
    exit('Este cambio de contexto no está disponible para este usuario.');
}

$contexto = strtolower(trim((string) ($_POST['contexto'] ?? '')));
if ($esConsultaGlobal && $contexto === 'administrador') {
    $_SESSION['rol_contexto'] = 'administrador';
    $_SESSION['rol'] = 1;
    $destino = 'panelAdmin.php';
} elseif ($esConsultaGlobal && $contexto === 'gestor') {
    $_SESSION['rol_contexto'] = 'gestor';
    $_SESSION['rol'] = 2;
    $destino = 'panelGestor.php';
} elseif ($contexto === 'solicitante') {
    $_SESSION['rol_contexto'] = 'solicitante';
    $_SESSION['rol'] = 3;
    $destino = 'panelSolicitante.php?vista=tickets';
} elseif ($contexto === 'gestor') {
    unset($_SESSION['rol_contexto']);
    $_SESSION['rol'] = 2;
    $destino = 'panelGestor.php';
} else {
    http_response_code(422);
    exit('Contexto no válido.');
}

session_write_close();
header('Location: ' . $destino, true, 303);
exit;
