<?php
declare(strict_types=1);

require_once APP_ROOT . '/security/seguridad.php';

seguridadAplicarCabeceras(true);
seguridadIniciarSesion();

require_once APP_ROOT . '/config/conexion.php';
require_once APP_ROOT . '/core/recuperacionPassword.php';

function escaparRecuperacion($valor): string
{
    return htmlspecialchars(
        (string) $valor,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function redirigirRecuperacion(string $paso, string $estado = ''): void
{
    $paso = in_array($paso, ['correo', 'codigo'], true) ? $paso : 'correo';
    $url = 'recuperarPassword.php?paso=' . rawurlencode($paso);

    if ($estado !== '') {
        $url .= '&estado=' . rawurlencode($estado);
    }

    header('Location: ' . $url, true, 303);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    seguridadExigirOrigenPost();
    seguridadExigirCsrfPost();
    $accion = (string) ($_POST['accion'] ?? '');

    if ($accion === 'reiniciar') {
        unset(
            $_SESSION['recuperacion_email'],
            $_SESSION['recuperacion_solicitada_en']
        );
        redirigirRecuperacion('correo');
    }

    if ($accion === 'solicitar') {
        $correo = strtolower(seguridadTexto($_POST['email'] ?? '', 190));

        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            redirigirRecuperacion('correo', 'correo_invalido');
        }

        try {
            recuperacionSolicitarCodigo($conn, $correo);
        } catch (Throwable $e) {
            error_log(
                'No fue posible iniciar la recuperación de contraseña: '
                . $e->getMessage()
            );
            redirigirRecuperacion('correo', 'servicio_no_disponible');
        }

        $_SESSION['recuperacion_email'] = $correo;
        $_SESSION['recuperacion_solicitada_en'] = time();
        redirigirRecuperacion('codigo', 'codigo_enviado');
    }

    if ($accion === 'cambiar') {
        $correo = strtolower(trim((string) (
            $_SESSION['recuperacion_email'] ?? ''
        )));
        $codigoEntrada = (string) ($_POST['codigo'] ?? '');
        $codigo = strlen($codigoEntrada) <= 32
            ? preg_replace('/\D+/', '', $codigoEntrada)
            : '';
        $passwordNueva = (string) ($_POST['password_nueva'] ?? '');
        $passwordConfirmacion = (string) (
            $_POST['password_confirmacion'] ?? ''
        );

        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            redirigirRecuperacion('correo', 'sesion_vencida');
        }

        if (!is_string($codigo) || strlen($codigo) !== 6) {
            redirigirRecuperacion('codigo', 'codigo_invalido');
        }

        if (!seguridadPasswordValida($passwordNueva)) {
            redirigirRecuperacion('codigo', 'password_invalido');
        }

        if (!hash_equals($passwordNueva, $passwordConfirmacion)) {
            redirigirRecuperacion('codigo', 'password_no_coincide');
        }

        try {
            $resultado = recuperacionCambiarPassword(
                $conn,
                $correo,
                $codigo,
                $passwordNueva
            );
        } catch (Throwable $e) {
            error_log(
                'No fue posible completar la recuperación de contraseña: '
                . $e->getMessage()
            );
            redirigirRecuperacion('codigo', 'servicio_no_disponible');
        }

        if ($resultado === 'password_repetido') {
            redirigirRecuperacion('codigo', 'password_repetido');
        }

        if ($resultado !== 'ok') {
            redirigirRecuperacion('codigo', 'codigo_invalido');
        }

        unset(
            $_SESSION['recuperacion_email'],
            $_SESSION['recuperacion_solicitada_en']
        );
        session_regenerate_id(true);
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['mesa_login_recuperacion'] = 'ok';
        header('Location: ' . mesaUrlInicio(), true, 303);
        exit;
    }

    redirigirRecuperacion('correo', 'solicitud_invalida');
}

$paso = (string) ($_GET['paso'] ?? 'correo');
$correoSesion = strtolower(trim((string) (
    $_SESSION['recuperacion_email'] ?? ''
)));

if ($paso === 'codigo' && !filter_var($correoSesion, FILTER_VALIDATE_EMAIL)) {
    $paso = 'correo';
}

$estados = [
    'correo_invalido' => ['error', 'Ingrese un correo electrónico válido.'],
    'servicio_no_disponible' => [
        'error',
        'El servicio de recuperación no está disponible temporalmente. Intente más tarde.'
    ],
    'sesion_vencida' => [
        'error',
        'La solicitud venció. Ingrese nuevamente su correo electrónico.'
    ],
    'solicitud_invalida' => [
        'error',
        'La solicitud no es válida. Actualice la página e inténtelo nuevamente.'
    ],
    'codigo_enviado' => [
        'ok',
        'Si el correo pertenece a una cuenta activa, recibirá un código en los próximos minutos.'
    ],
    'codigo_invalido' => [
        'error',
        'El código es incorrecto, venció o alcanzó el límite de intentos. Puede solicitar uno nuevo.'
    ],
    'password_invalido' => [
        'error',
        'La nueva contraseña debe tener mínimo 8 caracteres, una mayúscula y un número.'
    ],
    'password_no_coincide' => [
        'error',
        'La nueva contraseña y su confirmación no coinciden.'
    ],
    'password_repetido' => [
        'error',
        'La nueva contraseña debe ser diferente de la contraseña actual.'
    ],
];
$estado = (string) ($_GET['estado'] ?? '');
$mensaje = $estados[$estado] ?? null;
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#050201">
  <title>Recuperar contraseña | Mesa de Servicio</title>
  <style>
    :root{color-scheme:dark;--primary:#ff7a12;--primary-bright:#ffc15a;--orange-deep:#db3f05;--gold:#ffd47a;--text:#fffaf2;--muted:#d8c9b8;--line:rgba(255,190,106,.26);--danger:#ffd4d4;--danger-bg:rgba(129,22,33,.40);--danger-border:rgba(255,133,147,.55);--success:#c7ffe1;--success-bg:rgba(6,98,72,.38);--success-border:rgba(84,238,174,.48)}
    *{box-sizing:border-box}
    html,body{min-height:100%;margin:0}
    body{min-height:100vh;min-height:100dvh;display:grid;place-items:center;padding:28px;overflow-x:hidden;color:var(--text);font-family:Inter,"Segoe UI",Arial,Helvetica,sans-serif;background:radial-gradient(circle at 50% 10%,rgba(255,118,0,.13),transparent 28%),radial-gradient(circle at 16% 84%,rgba(218,58,0,.06),transparent 27%),radial-gradient(circle at 84% 76%,rgba(255,132,0,.05),transparent 25%),linear-gradient(145deg,#030201 0%,#080301 46%,#020100 100%)}
    button,input{font:inherit}
    .page-shell{width:min(500px,100%);display:flex;flex-direction:column;align-items:center;gap:15px;animation:page-in .5s cubic-bezier(.2,.8,.2,1) both}
    .company-logo{width:150px;height:78px;display:flex;align-items:center;justify-content:center}
    .company-logo img{display:block;width:auto;height:auto;max-width:150px;max-height:78px;object-fit:contain;filter:drop-shadow(0 10px 20px rgba(255,105,0,.13))}
    .card{position:relative;isolation:isolate;width:100%;overflow:hidden;border:1px solid rgba(255,190,106,.28);border-radius:24px;background:linear-gradient(145deg,rgba(24,11,2,.88),rgba(4,2,0,.95));box-shadow:0 32px 90px rgba(0,0,0,.52),inset 0 1px 0 rgba(255,255,255,.08),0 0 55px rgba(255,112,18,.08)}
    .card::before{position:absolute;inset:0 12% auto;height:2px;content:"";background:linear-gradient(90deg,transparent,var(--orange-deep),var(--primary),var(--gold),transparent);box-shadow:0 0 24px rgba(255,133,31,.52)}
    .card::after{position:absolute;z-index:-1;right:-120px;bottom:-155px;width:285px;height:285px;border:34px solid rgba(255,121,18,.035);border-radius:50%;content:"";pointer-events:none}
    .content{position:relative;z-index:1;padding:27px 32px 30px}
    .panel-top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:20px}
    .back{width:fit-content;min-height:30px;display:inline-flex;align-items:center;gap:7px;color:#f1e3d2;font-size:13px;font-weight:700;text-decoration:none;transition:color .2s ease,transform .2s ease}
    .back:hover{color:var(--primary-bright);transform:translateX(-2px)}
    .back svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-linecap:round;stroke-linejoin:round;stroke-width:2}
    .step{display:inline-flex;align-items:center;gap:7px;color:#f4c990;font-size:10px;font-weight:850;letter-spacing:.06em;text-transform:uppercase}
    .step::before{width:7px;height:7px;border-radius:50%;background:var(--primary);box-shadow:0 0 0 4px rgba(255,122,18,.12),0 0 14px rgba(255,122,18,.65);content:""}
    .heading{margin-bottom:21px;text-align:center}
    .heading h1{margin:0 0 8px;color:#fff;font-size:clamp(28px,5vw,34px);line-height:1.16;letter-spacing:-.035em;text-shadow:0 3px 18px rgba(255,121,18,.18)}
    .intro{max-width:390px;margin:0 auto;color:var(--muted);font-size:14px;line-height:1.6}
    .alert{display:flex;align-items:flex-start;gap:10px;margin:0 0 15px;padding:12px 14px;border:1px solid;border-radius:11px;font-size:13px;font-weight:650;line-height:1.45}
    .alert::before{width:20px;height:20px;display:grid;place-items:center;flex:0 0 auto;border-radius:50%;color:#fff;font-size:12px;font-weight:900}
    .alert.error{border-color:var(--danger-border);color:var(--danger);background:var(--danger-bg)}.alert.error::before{content:"!";background:#e84855}
    .alert.ok{border-color:var(--success-border);color:var(--success);background:var(--success-bg)}.alert.ok::before{content:"✓";background:#16bd7d}
    .masked{display:flex;align-items:center;gap:10px;margin:0 0 17px;padding:11px 13px;border:1px solid rgba(255,190,106,.20);border-radius:11px;color:#f8dbc0;background:rgba(255,122,18,.08);font-size:13px;overflow-wrap:anywhere}
    .masked svg{width:18px;height:18px;flex:0 0 auto;fill:none;stroke:var(--primary-bright);stroke-linecap:round;stroke-linejoin:round;stroke-width:1.8}
    .field{margin-bottom:17px}.field label{display:block;margin-bottom:8px;color:#edf6ff;font-size:13px;font-weight:760}
    .input-wrap{position:relative}.input-icon{position:absolute;top:50%;left:15px;width:19px;height:19px;pointer-events:none;transform:translateY(-50%);fill:none;stroke:#c8b49d;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.8;transition:stroke .2s ease,filter .2s ease}
    .input-wrap input{width:100%;height:47px;padding:0 46px;outline:none;border:1px solid var(--line);border-radius:12px;color:#fff;caret-color:var(--primary-bright);background:rgba(7,3,0,.50);box-shadow:inset 0 1px 0 rgba(255,255,255,.035);transition:border-color .2s ease,box-shadow .2s ease,background .2s ease}
    .input-wrap input::placeholder{color:#a9957e;opacity:1}.input-wrap input:hover{border-color:rgba(255,199,128,.44);background:rgba(14,6,1,.56)}.input-wrap input:focus{border-color:var(--primary-bright);background:rgba(17,7,1,.65);box-shadow:0 0 0 4px rgba(255,122,18,.14),0 0 24px rgba(255,122,18,.13)}.input-wrap:focus-within .input-icon{stroke:var(--primary-bright);filter:drop-shadow(0 0 6px rgba(255,193,90,.58))}
    .input-wrap input.code{padding-right:15px;text-align:center;font-size:23px;font-weight:850;letter-spacing:9px;font-variant-numeric:tabular-nums}
    .password-toggle{position:absolute;top:50%;right:8px;width:35px;height:35px;display:grid;place-items:center;padding:0;transform:translateY(-50%);border:0;border-radius:9px;color:#c8b49d;background:transparent;cursor:pointer}.password-toggle:hover{color:var(--primary-bright);background:rgba(255,122,18,.12)}.password-toggle svg{width:19px;height:19px;fill:none;stroke:currentColor;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.9}
    .hint{margin:6px 0 0;color:#b7a48f;font-size:11px;line-height:1.45}
    .button{position:relative;width:100%;min-height:47px;display:inline-flex;align-items:center;justify-content:center;gap:9px;overflow:hidden;margin-top:3px;padding:12px 20px;border:1px solid rgba(255,206,126,.50);border-radius:12px;color:#fff;background:linear-gradient(125deg,rgba(255,157,34,.97),rgba(255,103,13,.96) 54%,rgba(193,48,4,.96));box-shadow:0 12px 30px rgba(255,91,7,.30),inset 0 1px 0 rgba(255,255,255,.22);cursor:pointer;font-weight:820;transition:transform .2s ease,box-shadow .2s ease,filter .2s ease}
    .button::before{position:absolute;inset:0;content:"";background:linear-gradient(105deg,transparent 30%,rgba(255,255,255,.24) 48%,transparent 66%);transform:translateX(-115%);transition:transform .55s ease}.button:hover{transform:translateY(-2px);filter:brightness(1.08);box-shadow:0 16px 38px rgba(255,91,7,.38),0 0 28px rgba(255,180,52,.18)}.button:hover::before{transform:translateX(115%)}.button:disabled{cursor:wait;opacity:.72;transform:none}.button svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-linecap:round;stroke-linejoin:round;stroke-width:2}
    .actions{display:flex;justify-content:center;margin-top:16px}.secondary{width:auto;min-height:30px;padding:0;border:0;color:var(--primary-bright);background:transparent;cursor:pointer;font:inherit;font-size:13px;font-weight:750}.secondary:hover{color:#ffe0a0;text-decoration:underline}
    .privacy-note{display:flex;align-items:center;justify-content:center;gap:7px;margin:17px 0 0;color:#ad9a84;font-size:10px;text-align:center}.privacy-note svg{width:13px;height:13px;flex:0 0 auto;fill:none;stroke:currentColor;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.8}
    :is(.back,.password-toggle,.button,.secondary):focus-visible{outline:3px solid rgba(255,193,90,.32);outline-offset:3px}
    @keyframes page-in{from{opacity:0;transform:translateY(14px) scale(.985)}to{opacity:1;transform:none}}
    @media(max-width:540px){body{padding:14px;overflow-y:auto}.page-shell{gap:11px}.company-logo{width:130px;height:66px}.company-logo img{max-width:130px;max-height:66px}.card{border-radius:19px}.content{padding:24px 23px 27px}.panel-top{margin-bottom:18px}.heading h1{font-size:28px}}
    @media(max-width:370px){body{padding:7px}.card{border-radius:16px}.content{padding:20px 17px 23px}.step{display:none}}
    @media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
  </style>
  <style>
    :root{color-scheme:light;--primary:#0754ad;--primary-bright:#0754ad;--text:#18345b;--muted:#657a98;--line:#d7e1ef;--danger:#9e2430;--danger-bg:#fff1f2;--danger-border:#efb7bd;--success:#176441;--success-bg:#eefbf4;--success-border:#a9dec4}
    html,body{min-height:100%;margin:0}
    body{min-height:100vh;min-height:100dvh;display:grid;place-items:center;padding:18px;overflow-x:hidden;color:var(--text);font-family:Inter,"Segoe UI",Arial,Helvetica,sans-serif;background:radial-gradient(circle,rgba(18,91,178,.28) 1.5px,transparent 1.7px) 25px 68px/15px 15px no-repeat,radial-gradient(circle,rgba(18,91,178,.28) 1.5px,transparent 1.7px) calc(100% - 70px) 51%/15px 15px no-repeat,linear-gradient(145deg,#f8fbff 0%,#edf4ff 52%,#e7f1ff 100%)}
    body::before,body::after{position:fixed;z-index:-2;right:-12vw;bottom:-21vh;width:115vw;height:53vh;border-radius:50% 48% 0 0/48% 38% 0 0;content:"";pointer-events:none;transform:rotate(-8deg);transform-origin:center}
    body::before{right:-14vw;bottom:-25vh;width:120vw;height:62vh;background:linear-gradient(110deg,rgba(47,125,221,.80),rgba(2,74,163,.95))}
    body::after{right:29vw;bottom:-36vh;width:110vw;height:69vh;background:linear-gradient(110deg,rgba(157,200,255,.78),rgba(53,133,228,.68));transform:rotate(8deg)}
    .page-shell{position:relative;width:min(440px,100%);display:block;animation:page-in .45s ease both}
    .page-shell::before,.page-shell::after{position:fixed;z-index:-1;bottom:-31vh;width:76vw;height:55vh;border-radius:50% 50% 0 0;content:"";pointer-events:none}
    .page-shell::before{left:-24vw;background:rgba(191,218,253,.72);transform:rotate(13deg)}
    .page-shell::after{right:-34vw;background:rgba(5,78,171,.52);transform:rotate(-11deg)}
    .company-logo{display:none}
    .card{position:relative;width:100%;overflow:hidden;border:1px solid rgba(255,255,255,.92);border-radius:27px;background:rgba(255,255,255,.97);box-shadow:0 28px 75px rgba(19,65,123,.20),0 3px 12px rgba(28,72,128,.08);backdrop-filter:blur(7px)}
    .card::before,.card::after{display:none}
    .content{position:relative;padding:24px 42px 22px}
    .recovery-brand{display:flex;flex-direction:column;align-items:center;margin-bottom:13px;text-align:center}
    .recovery-brand-mark{width:62px;height:53px;display:block}
    .recovery-brand-mark img{width:100%;height:100%;display:block;object-fit:contain;filter:brightness(.93) saturate(1.18)}
    .recovery-brand-name{margin:0;color:#3f506d;font-size:24px;font-weight:850;line-height:1;letter-spacing:-.03em}
    .panel-top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:14px}
    .back{min-height:28px;display:inline-flex;align-items:center;gap:6px;color:#0753a7;font-size:12px;font-weight:700;text-decoration:none}
    .back:hover{color:#023e80;transform:translateX(-2px)}
    .step{display:inline-flex;align-items:center;gap:6px;color:#0753a7;font-size:10px;font-weight:850;letter-spacing:.05em;text-transform:uppercase}
    .step::before{width:7px;height:7px;border-radius:50%;background:#1b72cf;box-shadow:0 0 0 4px rgba(27,114,207,.12);content:""}
    .heading{margin-bottom:16px;text-align:center}
    .heading h1{margin:0 0 7px;color:#0754ad;font-size:26px;line-height:1.15;letter-spacing:-.03em;text-shadow:none}
    .intro{max-width:390px;margin:0 auto;color:#395372;font-size:12px;line-height:1.5}
    .alert{display:flex;align-items:flex-start;gap:9px;margin:0 0 13px;padding:10px 12px;border:1px solid;border-radius:9px;font-size:12px;font-weight:650;line-height:1.4}
    .alert.error{border-color:var(--danger-border);color:var(--danger);background:var(--danger-bg)}
    .alert.ok{border-color:var(--success-border);color:var(--success);background:var(--success-bg)}
    .masked{display:flex;align-items:center;gap:9px;margin:0 0 13px;padding:10px 12px;border:1px solid #cfe0f4;border-radius:9px;color:#244d79;background:#eef6ff;font-size:12px;overflow-wrap:anywhere}
    .masked svg{width:17px;height:17px;stroke:#0754ad}
    .field{margin-bottom:14px}.field label{display:block;margin-bottom:6px;color:#274566;font-size:12px;font-weight:750}
    .input-wrap{position:relative}.input-icon{position:absolute;top:50%;left:15px;width:18px;height:18px;pointer-events:none;transform:translateY(-50%);fill:none;stroke:#58739a;stroke-linecap:round;stroke-linejoin:round;stroke-width:1.9;filter:none}
    .input-wrap input{width:100%;height:47px;padding:0 46px;outline:none;border:1px solid #d7e1ef;border-radius:9px;color:#18345b;caret-color:#0754ad;background:#fff;box-shadow:0 2px 8px rgba(26,72,127,.035);transition:border-color .18s ease,box-shadow .18s ease}
    .input-wrap input::placeholder{color:#8a9db8;opacity:1}.input-wrap input:hover{border-color:#b8cbe2;background:#fff}.input-wrap input:focus{border-color:#5b96d7;background:#fff;box-shadow:0 0 0 4px rgba(24,102,190,.11)}.input-wrap:focus-within .input-icon{stroke:#0754ad;filter:none}
    .input-wrap input.code{padding-right:15px;color:#18345b;text-align:center;font-size:22px;font-weight:850;letter-spacing:8px}
    .password-toggle{right:8px;width:36px;height:36px;border-radius:8px;color:#58739a;background:transparent}.password-toggle:hover{color:#0754ad;background:#edf5ff}
    .hint{margin:5px 0 0;color:#657a98;font-size:10px;line-height:1.35}
    .button{width:100%;min-height:47px;display:inline-flex;align-items:center;justify-content:center;gap:9px;overflow:hidden;margin-top:2px;padding:12px 20px;border:0;border-radius:9px;color:#fff;background:linear-gradient(110deg,#1668c5,#064a9e);box-shadow:0 9px 20px rgba(7,79,165,.22),inset 0 1px 0 rgba(255,255,255,.18);cursor:pointer;font-weight:780;transition:transform .18s ease,box-shadow .18s ease,filter .18s ease}
    .button::before{display:none}.button:hover{transform:translateY(-1px);filter:brightness(1.05);box-shadow:0 12px 24px rgba(7,79,165,.29)}
    .actions{display:flex;justify-content:center;margin-top:12px}.secondary{min-height:28px;color:#0753a7;font-size:12px;font-weight:700}.secondary:hover{color:#023e80}
    .privacy-note{display:flex;align-items:center;justify-content:center;gap:6px;margin:14px -42px -22px;padding:14px 20px;color:#536984;background:#f7f9fc;font-size:10px;text-align:center}.privacy-note svg{width:13px;height:13px}
    :is(.back,.password-toggle,.button,.secondary):focus-visible{outline:3px solid rgba(18,103,196,.22);outline-offset:3px}
    @media(min-width:1600px){.page-shell{width:440px}}
    @media(max-height:760px) and (min-width:541px){body{padding:7px}.content{padding:17px 38px 16px}.recovery-brand{margin-bottom:9px}.recovery-brand-mark{width:52px;height:43px}.recovery-brand-name{font-size:21px}.panel-top{margin-bottom:9px}.heading{margin-bottom:11px}.heading h1{font-size:23px}.field{margin-bottom:10px}.input-wrap input{height:43px}.button{min-height:44px}.privacy-note{margin:11px -38px -16px;padding:10px 18px}}
    @media(max-width:540px){body{padding:12px;overflow-y:auto}.card{border-radius:21px}.content{padding:22px 23px 19px}.privacy-note{margin:14px -23px -19px}.recovery-brand-mark{width:56px;height:47px}.recovery-brand-name{font-size:22px}.heading h1{font-size:23px}}
    @media(max-width:370px){body{padding:7px}.card{border-radius:17px}.content{padding:19px 17px 17px}.privacy-note{margin:13px -17px -17px}.step{display:none}}
  </style>
</head>
<body>
  <div class="page-shell">
    <div class="company-logo">
      <img src="assets/img/logo-conectar.png" alt="Logo Conectar">
    </div>
    <main class="card">
      <section class="content" aria-labelledby="recovery-title">
        <div class="recovery-brand" aria-label="Conectar">
          <span class="recovery-brand-mark" aria-hidden="true">
            <img src="assets/img/logo-conectar.png" alt="">
          </span>
          <p class="recovery-brand-name">Conectar</p>
        </div>
        <div class="panel-top">
          <a class="back" href="<?= escaparRecuperacion(mesaUrlInicio()) ?>">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"/></svg>
            Volver al ingreso
          </a>
          <span class="step"><?= $paso === 'codigo' ? 'Paso 2 de 2' : 'Paso 1 de 2' ?></span>
        </div>

        <div class="heading">
          <h1 id="recovery-title"><?= $paso === 'codigo' ? 'Verifique su identidad' : 'Recuperar contraseña' ?></h1>
          <p class="intro"><?= $paso === 'codigo' ? 'Revise su correo y establezca una nueva contraseña.' : 'Ingrese el correo registrado en la plataforma. Si la cuenta está activa, enviaremos un código temporal.' ?></p>
        </div>

      <?php if ($paso === 'codigo'): ?>
        <p class="masked">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/><path d="m22 7-10 6L2 7"/></svg>
          Código enviado a <?= escaparRecuperacion(recuperacionEnmascararCorreo($correoSesion)) ?>
        </p>
      <?php endif; ?>

      <?php if (is_array($mensaje)): ?>
        <div class="alert <?= escaparRecuperacion($mensaje[0]) ?>" role="alert">
          <?= escaparRecuperacion($mensaje[1]) ?>
        </div>
      <?php endif; ?>

      <?php if ($paso === 'codigo'): ?>
        <form method="post" autocomplete="off" data-submit-form>
          <input type="hidden" name="csrf_token" value="<?= escaparRecuperacion(seguridadTokenCsrf()) ?>">
          <input type="hidden" name="accion" value="cambiar">
          <div class="field">
            <label for="codigo">Código de 6 dígitos</label>
            <div class="input-wrap">
              <svg class="input-icon" viewBox="0 0 24 24" aria-hidden="true"><rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
              <input class="code" id="codigo" name="codigo" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" placeholder="000000" required autofocus>
            </div>
            <p class="hint">Vence en <?= RECUPERACION_VIGENCIA_MINUTOS ?> minutos y admite máximo <?= RECUPERACION_MAX_INTENTOS_CODIGO ?> intentos.</p>
          </div>
          <div class="field">
            <label for="password_nueva">Nueva contraseña</label>
            <div class="input-wrap">
              <svg class="input-icon" viewBox="0 0 24 24" aria-hidden="true"><rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
              <input id="password_nueva" type="password" name="password_nueva" autocomplete="new-password" minlength="8" maxlength="128" placeholder="Cree una contraseña segura" required>
              <button class="password-toggle" type="button" data-password-toggle="password_nueva" aria-label="Mostrar nueva contraseña" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg></button>
            </div>
            <p class="hint">Mínimo 8 caracteres, una mayúscula y un número.</p>
          </div>
          <div class="field">
            <label for="password_confirmacion">Confirmar contraseña</label>
            <div class="input-wrap">
              <svg class="input-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 11a8 8 0 1 1-4.6-7.2"/><path d="m16 5 2 2 4-4"/></svg>
              <input id="password_confirmacion" type="password" name="password_confirmacion" autocomplete="new-password" minlength="8" maxlength="128" placeholder="Repita la contraseña" required>
              <button class="password-toggle" type="button" data-password-toggle="password_confirmacion" aria-label="Mostrar confirmación de contraseña" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg></button>
            </div>
          </div>
          <button class="button" type="submit"><span>Cambiar contraseña</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
        </form>
        <form class="actions" method="post">
          <input type="hidden" name="csrf_token" value="<?= escaparRecuperacion(seguridadTokenCsrf()) ?>">
          <input type="hidden" name="accion" value="reiniciar">
          <button class="secondary" type="submit">Solicitar un código nuevo</button>
        </form>
      <?php else: ?>
        <form method="post" autocomplete="on" data-submit-form>
          <input type="hidden" name="csrf_token" value="<?= escaparRecuperacion(seguridadTokenCsrf()) ?>">
          <input type="hidden" name="accion" value="solicitar">
          <div class="field">
            <label for="email">Correo electrónico</label>
            <div class="input-wrap">
              <svg class="input-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/><path d="m22 7-10 6L2 7"/></svg>
              <input id="email" type="email" name="email" maxlength="190" autocomplete="email" autocapitalize="none" spellcheck="false" placeholder="nombre@empresa.com" required autofocus>
            </div>
          </div>
          <button class="button" type="submit"><span>Enviar código</span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
        </form>
      <?php endif; ?>

        <p class="privacy-note">
          <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
          Proceso protegido. El código es temporal y solo puede utilizarse una vez.
        </p>
      </section>
    </main>
  </div>
  <script>
    document.querySelectorAll('[data-submit-form]').forEach(function (form) {
      form.addEventListener('submit', function () {
        const button = form.querySelector('button[type="submit"]');
        if (button) {
          button.disabled = true;
          const label = button.querySelector('span');
          if (label) label.textContent = 'Procesando...';
        }
      });
    });
    document.querySelectorAll('[data-password-toggle]').forEach(function (button) {
      button.addEventListener('click', function () {
        const input = document.getElementById(button.dataset.passwordToggle || '');
        if (!input) return;
        const visible = input.type === 'text';
        input.type = visible ? 'password' : 'text';
        button.setAttribute('aria-pressed', visible ? 'false' : 'true');
        button.setAttribute('aria-label', visible ? 'Mostrar contraseña' : 'Ocultar contraseña');
      });
    });
  </script>
</body>
</html>
