<?php
declare(strict_types=1);

/**
 * Punto de arranque único de la aplicación.
 *
 * Todos los controladores públicos cargan este archivo antes de ejecutar el
 * módulo correspondiente. Así las rutas internas no dependen de la carpeta
 * desde la que se invoque cada PHP.
 */

if (!defined('PROJECT_ROOT')) {
    define('PROJECT_ROOT', dirname(__DIR__));
}

if (!defined('APP_ROOT')) {
    define('APP_ROOT', __DIR__);
}

if (!defined('PUBLIC_ROOT')) {
    define('PUBLIC_ROOT', PROJECT_ROOT . DIRECTORY_SEPARATOR . 'public');
}

/**
 * Devuelve la raiz publica de la instalacion, con barra final.
 * Funciona tanto desde el index principal como desde los controladores que
 * Apache resuelve internamente dentro de public/.
 */
function mesaUrlInicio(array $parametros = []): string
{
    $script = str_replace(
        '\\',
        '/',
        (string) ($_SERVER['SCRIPT_NAME'] ?? '')
    );
    $posicionPublic = strpos($script, '/public/');

    if ($posicionPublic !== false) {
        $base = substr($script, 0, $posicionPublic + 1);
    } else {
        $directorio = str_replace('\\', '/', dirname($script));
        $base = ($directorio === '/' || $directorio === '.')
            ? '/'
            : rtrim($directorio, '/') . '/';
    }

    if ($parametros === []) {
        return $base;
    }

    return $base . '?' . http_build_query(
        $parametros,
        '',
        '&',
        PHP_QUERY_RFC3986
    );
}

date_default_timezone_set('America/Bogota');

require_once APP_ROOT . '/core/compatibilidadPhp74.php';
require_once APP_ROOT . '/core/matrizPrioridad.php';
