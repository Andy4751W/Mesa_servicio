/* Configuración de jornada SLA por país y día de la semana. */
CREATE TABLE IF NOT EXISTS horarios_laborales_sla (
    id_horario INT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_pais_operacion INT NOT NULL,
    dia_semana TINYINT UNSIGNED NOT NULL,
    activo TINYINT(1) NOT NULL DEFAULT 0,
    hora_inicio TIME NULL,
    hora_fin TIME NULL,
    actualizado_por INT NULL,
    actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_horario),
    UNIQUE KEY uq_horario_pais_dia (id_pais_operacion, dia_semana),
    KEY idx_horario_pais (id_pais_operacion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
