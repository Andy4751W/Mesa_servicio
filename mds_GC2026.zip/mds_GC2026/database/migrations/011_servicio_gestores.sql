-- Fase 1: gestores habilitados por servicio.
--
-- `servicios.id_gestor` se conserva como el gestor predeterminado para
-- asignación inicial. Esta tabla amplía la capacidad a varios gestores sin
-- alterar tickets, etapas ni flujos históricos.

CREATE TABLE IF NOT EXISTS servicio_gestores (
    id_servicio_gestor BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_servicio INT NOT NULL,
    id_usuario INT NOT NULL,
    estado ENUM('activo', 'inhabilitado') NOT NULL DEFAULT 'activo',
    fecha_asignacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_usuario_asigno INT NULL,
    actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_servicio_gestor),
    UNIQUE KEY uq_servicio_gestores_servicio_usuario (id_servicio, id_usuario),
    KEY idx_servicio_gestores_usuario_estado (id_usuario, estado),
    KEY idx_servicio_gestores_servicio_estado (id_servicio, estado),
    KEY idx_servicio_gestores_asignador (id_usuario_asigno),
    CONSTRAINT fk_servicio_gestores_servicio
        FOREIGN KEY (id_servicio) REFERENCES servicios (id_servicio),
    CONSTRAINT fk_servicio_gestores_usuario
        FOREIGN KEY (id_usuario) REFERENCES usuarios (id_usuario),
    CONSTRAINT fk_servicio_gestores_asignador
        FOREIGN KEY (id_usuario_asigno) REFERENCES usuarios (id_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Migra el gestor predeterminado actual como primer gestor habilitado.
-- Es idempotente y no altera la columna servicios.id_gestor.
INSERT INTO servicio_gestores (
    id_servicio,
    id_usuario,
    estado,
    fecha_asignacion,
    id_usuario_asigno
)
SELECT
    s.id_servicio,
    s.id_gestor,
    'activo',
    NOW(),
    NULL
FROM servicios AS s
INNER JOIN usuarios AS u
    ON u.id_usuario = s.id_gestor
WHERE s.id_gestor IS NOT NULL
ON DUPLICATE KEY UPDATE
    estado = 'activo',
    actualizado_en = CURRENT_TIMESTAMP;

-- Validaciones posteriores a la migración (solo lectura):
-- 1) SELECT COUNT(*) FROM servicios s
--    LEFT JOIN servicio_gestores sg
--      ON sg.id_servicio = s.id_servicio
--     AND sg.id_usuario = s.id_gestor
--     AND sg.estado = 'activo'
--    WHERE s.id_gestor IS NOT NULL AND sg.id_servicio IS NULL;
-- 2) SELECT s.id_servicio, s.nombre
--    FROM servicios s
--    LEFT JOIN servicio_gestores sg ON sg.id_servicio = s.id_servicio
--    WHERE s.estado = 'activo'
--    GROUP BY s.id_servicio, s.nombre
--    HAVING SUM(sg.estado = 'activo') = 0;
