-- Estructura para la nomenclatura área.proceso.servicio del catálogo V9.
-- Los datos se cargarán mediante la migración controlada generada desde el
-- archivo oficial "Catalogo servicios Mesa de ayuda V.9 Jhonny.xlsx".

ALTER TABLE catalogos
    ADD COLUMN codigo_area VARCHAR(12) NULL AFTER id_catalogo,
    ADD UNIQUE KEY uq_catalogos_codigo_area (codigo_area);

ALTER TABLE catalogo_procesos_servicio
    ADD COLUMN id_catalogo INT NULL AFTER id_proceso_catalogo,
    ADD COLUMN codigo_proceso VARCHAR(20) NULL AFTER id_catalogo,
    ADD KEY idx_catalogo_procesos_area_codigo (id_catalogo, codigo_proceso),
    ADD CONSTRAINT fk_catalogo_procesos_area
        FOREIGN KEY (id_catalogo) REFERENCES catalogos (id_catalogo);

ALTER TABLE servicios
    ADD COLUMN codigo_servicio VARCHAR(32) NULL AFTER id_servicio,
    ADD COLUMN orden_catalogo SMALLINT UNSIGNED NULL AFTER codigo_servicio,
    ADD KEY idx_servicios_codigo_catalogo (codigo_servicio);
