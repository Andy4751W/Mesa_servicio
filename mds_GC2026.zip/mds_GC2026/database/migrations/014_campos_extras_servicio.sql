-- Campos adicionales obligatorios configurables por servicio.
-- La aplicación también crea estas tablas de forma idempotente al detectar
-- una instalación existente, para no interrumpir la operación.
CREATE TABLE IF NOT EXISTS servicio_campos_extra (
    id_campo_extra BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_servicio INT NOT NULL,
    etiqueta VARCHAR(255) NOT NULL,
    orden SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    obligatorio TINYINT(1) NOT NULL DEFAULT 1,
    estado ENUM('activo','eliminado') NOT NULL DEFAULT 'activo',
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_campo_extra),
    KEY idx_campos_extra_servicio_estado (id_servicio, estado, orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ticket_campos_extra (
    id_valor BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_ticket INT NOT NULL,
    id_ticket_etapa BIGINT UNSIGNED NOT NULL,
    id_campo_extra BIGINT UNSIGNED NOT NULL,
    etiqueta VARCHAR(255) NOT NULL,
    valor TEXT NOT NULL,
    id_usuario INT NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_valor),
    UNIQUE KEY uq_ticket_campo_extra (id_ticket_etapa, id_campo_extra),
    KEY idx_ticket_campos_extra_ticket (id_ticket, id_ticket_etapa)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
