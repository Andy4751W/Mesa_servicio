/*
 * Permiso adicional de consulta global.
 *
 * No cambia el rol base del usuario. Permite consultar las vistas de
 * administración y gestión en modo lectura, conservando el comportamiento
 * normal del portal solicitante para quien tenga ese rol.
 */
ALTER TABLE usuarios
    ADD COLUMN puede_consultar_global TINYINT(1) NOT NULL DEFAULT 0
    AFTER id_rol;

CREATE INDEX idx_usuarios_consulta_global
    ON usuarios (puede_consultar_global, estado, id_pais_operacion);
