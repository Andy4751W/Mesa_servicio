-- Catálogo corporativo de procesos usado por la administración de servicios.
-- Se mantiene separado de `procesos`, que representa flujos horizontales.

CREATE TABLE IF NOT EXISTS catalogo_procesos_servicio (
    id_proceso_catalogo INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(160) NOT NULL,
    estado ENUM('activo', 'inhabilitado') NOT NULL DEFAULT 'activo',
    orden SMALLINT UNSIGNED NOT NULL,
    creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_proceso_catalogo),
    UNIQUE KEY uq_catalogo_procesos_servicio_nombre (nombre),
    KEY idx_catalogo_procesos_servicio_estado_orden (estado, orden)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO catalogo_procesos_servicio (nombre, estado, orden) VALUES
    ('Adquisiciones', 'activo', 10),
    ('Aliados', 'activo', 20),
    ('Atracción de Talentos', 'activo', 30),
    ('Cadena de Abastecimiento - Movilidad', 'activo', 40),
    ('Calidad', 'activo', 50),
    ('Contabilidad', 'activo', 60),
    ('Control Interno', 'activo', 70),
    ('Controller', 'activo', 80),
    ('DBM', 'activo', 90),
    ('Diseño', 'activo', 100),
    ('Facturación', 'activo', 110),
    ('Formación', 'activo', 120),
    ('HeadCount', 'activo', 130),
    ('Herramientas y Recursos Propios', 'activo', 140),
    ('Infraestructura', 'activo', 150),
    ('Jurídica', 'activo', 160),
    ('Logistica', 'activo', 170),
    ('Planeación Estrategica', 'activo', 180),
    ('PMO', 'activo', 190),
    ('Seguridad', 'activo', 200),
    ('Talento Humano', 'activo', 210),
    ('Tesorería', 'activo', 220),
    ('TICs', 'activo', 230)
ON DUPLICATE KEY UPDATE
    estado = VALUES(estado),
    orden = VALUES(orden);

ALTER TABLE servicios
    ADD COLUMN id_proceso_catalogo INT NULL AFTER id_proceso,
    ADD KEY idx_servicios_proceso_catalogo (id_proceso_catalogo),
    ADD CONSTRAINT fk_servicios_proceso_catalogo
        FOREIGN KEY (id_proceso_catalogo)
        REFERENCES catalogo_procesos_servicio (id_proceso_catalogo);
