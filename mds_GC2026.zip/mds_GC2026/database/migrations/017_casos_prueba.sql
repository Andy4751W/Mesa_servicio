/* Aisla los casos creados desde el usuario de pruebas de la operación oficial. */
ALTER TABLE tickets
    ADD COLUMN es_prueba TINYINT(1) NOT NULL DEFAULT 0
        AFTER id_pais_operacion;

ALTER TABLE tickets
    ADD KEY idx_tickets_prueba_pais_usuario
        (es_prueba, id_pais_operacion, id_usuario);
