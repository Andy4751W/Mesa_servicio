<?php
declare(strict_types=1);

/*
 * Importa la columna CAMPOS EXTRAS del catálogo V9. El Excel se trata como
 * fuente de datos, no como instrucciones ejecutables.
 * Uso: php importar_campos_extras_xlsx.php "ruta/al/catalogo.xlsx"
 */
define('PROJECT_ROOT', dirname(__DIR__, 2));
define('APP_ROOT', PROJECT_ROOT . '/app');
require APP_ROOT . '/config/conexion.php';
require APP_ROOT . '/core/camposExtras.php';

$ruta = $argv[1] ?? '';
if ($ruta === '' || !is_file($ruta)) {
    fwrite(STDERR, "Indique la ruta del archivo XLSX.\n");
    exit(2);
}
if (!class_exists('ZipArchive')) {
    fwrite(STDERR, "PHP debe tener habilitada la extensión ZipArchive.\n");
    exit(2);
}

$zip = new ZipArchive();
if ($zip->open($ruta) !== true) {
    throw new RuntimeException('No fue posible abrir el archivo XLSX.');
}
$xml = static function (string $nombre) use ($zip): SimpleXMLElement {
    $contenido = $zip->getFromName($nombre);
    if ($contenido === false) {
        throw new RuntimeException('Falta el recurso ' . $nombre . ' en el XLSX.');
    }
    return new SimpleXMLElement($contenido);
};
$nsMain = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
$nsRel = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
$shared = [];
if ($zip->locateName('xl/sharedStrings.xml') !== false) {
    $ss = $xml('xl/sharedStrings.xml');
    foreach ($ss->si as $item) {
        $texto = '';
        foreach ($item->xpath('.//*[local-name()="t"]') ?: [] as $parte) {
            $texto .= (string) $parte;
        }
        $shared[] = $texto;
    }
}
$workbook = $xml('xl/workbook.xml');
$relaciones = $xml('xl/_rels/workbook.xml.rels');
$hojaId = '';
foreach ($workbook->sheets->sheet as $hoja) {
    if ((string) $hoja['name'] === 'Portafolio General') {
        $hojaId = (string) $hoja->attributes($nsRel)['id'];
        break;
    }
}
if ($hojaId === '') {
    throw new RuntimeException('No existe la hoja Portafolio General.');
}
$destino = '';
foreach ($relaciones->Relationship as $relacion) {
    if ((string) $relacion['Id'] === $hojaId) {
        $destino = 'xl/' . ltrim((string) $relacion['Target'], '/');
        break;
    }
}
$hoja = $xml($destino);
$valorCelda = static function (SimpleXMLElement $celda) use ($shared): string {
    $valor = (string) ($celda->v ?? '');
    if ((string) $celda['t'] === 's' && $valor !== '') {
        return (string) ($shared[(int) $valor] ?? '');
    }
    if ((string) $celda['t'] === 'inlineStr') {
        $partes = $celda->xpath('.//*[local-name()="t"]') ?: [];
        return implode('', array_map(static fn ($parte): string => (string) $parte, $partes));
    }
    return $valor;
};
$partirCampos = static function (string $texto): array {
    $texto = trim((string) preg_replace('/\s+/u', ' ', str_replace(["\r\n", "\r", "\n"], ',', $texto)));
    if ($texto === '' || preg_match('/^no requiere$/i', $texto)) return [];
    $trozos = preg_split('/\s*,\s*|\s*;\s*/u', $texto) ?: [];
    $salida = [];
    foreach ($trozos as $trozo) {
        $trozo = trim((string) preg_replace('/^\s*\d+\s*[.)-]\s*/u', '', $trozo));
        if ($trozo !== '') $salida[] = $trozo;
    }
    return array_values(array_unique($salida));
};

camposExtrasPrepararEsquema($conn);
$pais = 0;
$resultadoPais = $conn->query("SELECT id_pais_operacion FROM paises WHERE estado = 'activo' ORDER BY id_pais_operacion LIMIT 1");
if ($resultadoPais && ($filaPais = $resultadoPais->fetch_assoc())) $pais = (int) $filaPais['id_pais_operacion'];
if ($pais < 1) throw new RuntimeException('No hay país de operación activo.');
$stmtServicio = $conn->prepare('SELECT id_servicio FROM servicios WHERE id_pais_operacion = ? AND estado <> \'eliminado\' AND nombre = ? LIMIT 1');
$procesadas = 0;
$noEncontradas = [];
foreach ($hoja->sheetData->row as $fila) {
    if ((int) $fila['r'] === 1) continue;
    $servicio = '';
    $extra = '';
    foreach ($fila->c as $celda) {
        $ref = (string) $celda['r'];
        $valor = $valorCelda($celda);
        if (preg_match('/^E\d+$/', $ref)) $servicio = trim($valor);
        if (preg_match('/^P\d+$/', $ref)) $extra = trim($valor);
    }
    $campos = $partirCampos($extra);
    if ($servicio === '' || !$campos) continue;
    $stmtServicio->bind_param('is', $pais, $servicio);
    $stmtServicio->execute();
    $filaServicio = $stmtServicio->get_result()->fetch_assoc();
    if (!$filaServicio) { $noEncontradas[$servicio] = true; continue; }
    camposExtrasGuardarServicio($conn, (int) $filaServicio['id_servicio'], $campos);
    $procesadas++;
}
$stmtServicio->close();
$zip->close();
echo "Filas con campos extras procesadas: {$procesadas}\n";
if ($noEncontradas) {
    echo "Servicios no encontrados: " . implode(' | ', array_keys($noEncontradas)) . "\n";
}
