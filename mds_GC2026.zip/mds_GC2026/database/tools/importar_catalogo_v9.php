<?php

declare(strict_types=1);

/**
 * Importa el catálogo oficial V.9 sin eliminar servicios históricos.
 *
 * Uso (desde la raíz del proyecto):
 *   C:\xampp\php\php.exe database/tools/importar_catalogo_v9.php "C:\ruta\Catalogo servicios Mesa de ayuda V.9 Jhonny.xlsx"
 *
 * El archivo debe ejecutarse después de las migraciones 012 y 013. El código
 * resultante se forma por orden: área.proceso.servicio. La excepción solicitada
 * para Compra de Tiquetes es 1.1.19.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Este importador solo se ejecuta por consola.');
}

$archivo = $argv[1] ?? '';
$usarJsonEntrada = $archivo === '--json';
if (!$usarJsonEntrada && ($archivo === '' || !is_file($archivo))) {
    fwrite(STDERR, "Indique la ruta del Excel V.9 o use --json enviando las filas por entrada estándar.\n");
    exit(1);
}
if (!$usarJsonEntrada && !class_exists('ZipArchive')) {
    fwrite(STDERR, "La extensión ZipArchive es necesaria para leer el Excel. Use --json en este entorno.\n");
    exit(1);
}

define('PROJECT_ROOT', dirname(__DIR__, 2));
define('APP_ROOT', PROJECT_ROOT . '/app');
require APP_ROOT . '/config/conexion.php';

/** @var mysqli $conn */
global $conn;

function normalizarCatalogo(string $valor): string
{
    $valor = trim(str_replace('_x000D_', ' ', $valor));
    $valor = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $valor) ?: $valor;
    $valor = strtolower($valor);
    return (string) preg_replace('/[^a-z0-9]+/', '', $valor);
}

function claveAreaExcel(string $valor): string
{
    return normalizarCatalogo((string) preg_replace('/^\s*\d+(?:\.\d+)?\s*/', '', $valor));
}

function textoExcel(ZipArchive $zip, string $entrada): string
{
    $texto = $zip->getFromName($entrada);
    if ($texto === false) {
        throw new RuntimeException('No se encontró ' . $entrada . ' dentro del Excel.');
    }
    return $texto;
}

/** @return array<int, string> */
function leerSharedStrings(ZipArchive $zip): array
{
    $xml = new DOMDocument();
    $xml->loadXML(textoExcel($zip, 'xl/sharedStrings.xml'));
    $resultado = [];
    foreach ($xml->getElementsByTagName('si') as $item) {
        $resultado[] = $item->textContent;
    }
    return $resultado;
}

/** @return array<int, array<string, string>> */
function leerPortafolio(ZipArchive $zip): array
{
    $strings = leerSharedStrings($zip);
    $xml = new DOMDocument();
    $xml->loadXML(textoExcel($zip, 'xl/worksheets/sheet2.xml'));
    $filas = [];

    foreach ($xml->getElementsByTagName('row') as $filaXml) {
        $numero = (int) $filaXml->getAttribute('r');
        if ($numero < 2) {
            continue;
        }
        $fila = ['fila' => (string) $numero];
        foreach ($filaXml->getElementsByTagName('c') as $celda) {
            $referencia = $celda->getAttribute('r');
            preg_match('/^[A-Z]+/', $referencia, $coincidencia);
            $columna = $coincidencia[0] ?? '';
            if ($columna === '') {
                continue;
            }
            $valor = '';
            $nodosValor = $celda->getElementsByTagName('v');
            if ($nodosValor->length > 0) {
                $valor = $nodosValor->item(0)->textContent;
                if ($celda->getAttribute('t') === 's') {
                    $valor = $strings[(int) $valor] ?? '';
                }
            } elseif ($celda->getAttribute('t') === 'inlineStr') {
                $valor = $celda->textContent;
            }
            $fila[$columna] = trim($valor);
        }
        if (($fila['C'] ?? '') !== '' && ($fila['D'] ?? '') !== '' && ($fila['E'] ?? '') !== '') {
            $filas[] = $fila;
        }
    }
    return $filas;
}

function descripcionServicio(array $fila): string
{
    $definicion = trim((string) ($fila['F'] ?? ''));
    $solicitud = trim((string) ($fila['G'] ?? ''));
    $sla = trim((string) ($fila['H'] ?? ''));
    return "Descripción:\n" . $definicion
        . "\n\nSolicitud:\n" . $solicitud
        . ($sla !== '' ? "\n\n" . $sla : '');
}

function parametros(mysqli_stmt $sentencia, string $tipos, array $valores): void
{
    $referencias = [$tipos];
    foreach ($valores as $indice => $valor) {
        $referencias[] = &$valores[$indice];
    }
    $sentencia->bind_param(...$referencias);
}

function buscarSla(mysqli $conn, int $pais, string $texto): ?int
{
    static $cache = [];
    $claveCache = $pais . '|' . normalizarCatalogo($texto);
    if (array_key_exists($claveCache, $cache)) {
        return $cache[$claveCache];
    }
    if (!preg_match('/(\d+)\s*(minutos?|horas?|d[ií]as?)/iu', $texto, $coincidencia)) {
        $cache[$claveCache] = null;
        return null;
    }
    $cantidad = (int) $coincidencia[1];
    $unidadBase = normalizarCatalogo($coincidencia[2]);
    $unidad = str_starts_with($unidadBase, 'minuto') ? 'minutos'
        : (str_starts_with($unidadBase, 'hora') ? 'horas' : 'dias');
    $consulta = $conn->prepare(
        'SELECT id_sla FROM sla WHERE id_pais_operacion = ? AND tiempo_respuesta = ? AND unidad = ? LIMIT 1'
    );
    $consulta->bind_param('iis', $pais, $cantidad, $unidad);
    $consulta->execute();
    $resultado = $consulta->get_result()->fetch_assoc();
    if ($resultado) {
        return $cache[$claveCache] = (int) $resultado['id_sla'];
    }
    $nombre = 'SLA ' . $cantidad . ' ' . $unidad;
    $insertar = $conn->prepare(
        "INSERT INTO sla (id_pais_operacion, nombre, tiempo_respuesta, unidad, estado, creado_en) VALUES (?, ?, ?, ?, 'activo', NOW())"
    );
    $insertar->bind_param('isis', $pais, $nombre, $cantidad, $unidad);
    $insertar->execute();
    return $cache[$claveCache] = (int) $conn->insert_id;
}

/** Ejecuta el lote sin hacer un viaje de red por cada actualización. */
function ejecutarLote(mysqli $conn, array $sentencias): void
{
    if ($sentencias === []) {
        return;
    }
    if (!$conn->multi_query(implode(';', $sentencias))) {
        throw new RuntimeException($conn->error);
    }
    do {
        if ($resultado = $conn->store_result()) {
            $resultado->free();
        }
    } while ($conn->more_results() && $conn->next_result());
    if ($conn->errno !== 0) {
        throw new RuntimeException($conn->error);
    }
}

$ordenAreas = [
    'administracion' => [1, 'Administración'],
    'cadenadeabastecimiento' => [2, 'Cadena de Abastecimiento'],
    'contabilidad' => [3, 'Contabilidad'],
    'juridica' => [4, 'Jurídica'],
    'talentohumano' => [5, 'Talento Humano'],
    'tesoreria' => [6, 'Tesorería'],
    'tics' => [7, 'TICs'],
    'calidadyplaneacionestrategica' => [8, 'Calidad y Planeación Estratégica'],
    'controlinterno' => [9, 'Control Interno'],
    'controller' => [10, 'Controller'],
];

$filas = [];
if ($usarJsonEntrada) {
    $filas = json_decode((string) stream_get_contents(STDIN), true, 512, JSON_THROW_ON_ERROR);
} else {
    $zip = new ZipArchive();
    if ($zip->open($archivo) !== true) {
        throw new RuntimeException('No fue posible abrir el Excel oficial.');
    }
    $filas = leerPortafolio($zip);
    $zip->close();
}
if (count($filas) !== 211) {
    throw new RuntimeException('El Excel no contiene las 211 filas esperadas del Portafolio General.');
}

try {
    $conn->begin_transaction();
    $pais = 1;
    $catalogos = [];
    $todosCatalogos = [];
    $resultadoCatalogos = $conn->query(
        'SELECT c.id_catalogo, c.nombre, COUNT(s.id_servicio) AS total_servicios '
        . 'FROM catalogos c LEFT JOIN servicios s ON s.id_catalogo = c.id_catalogo '
        . 'GROUP BY c.id_catalogo, c.nombre ORDER BY total_servicios DESC, c.id_catalogo ASC'
    );
    while ($registro = $resultadoCatalogos->fetch_assoc()) {
        $todosCatalogos[] = (int) $registro['id_catalogo'];
        $claveCatalogo = normalizarCatalogo($registro['nombre']);
        if (!isset($catalogos[$claveCatalogo])) {
            $catalogos[$claveCatalogo] = (int) $registro['id_catalogo'];
        }
    }
    $areasUsadas = [];
    foreach ($ordenAreas as $clave => [$orden, $nombre]) {
        $id = $catalogos[$clave] ?? null;
        if ($id === null) {
            $agregar = $conn->prepare(
                "INSERT INTO catalogos (codigo_area, id_pais_operacion, nombre, descripcion, estado, orden, creado_en) VALUES (?, ?, ?, NULL, 'activo', ?, NOW())"
            );
            $codigo = (string) $orden;
            $agregar->bind_param('sisi', $codigo, $pais, $nombre, $orden);
            $agregar->execute();
            $id = (int) $conn->insert_id;
        } else {
            $actualizar = $conn->prepare(
                "UPDATE catalogos SET codigo_area = ?, nombre = ?, estado = 'activo', orden = ? WHERE id_catalogo = ?"
            );
            $codigo = (string) $orden;
            $actualizar->bind_param('ssii', $codigo, $nombre, $orden, $id);
            $actualizar->execute();
        }
        $areasUsadas[$id] = true;
        $ordenAreas[$clave][] = $id;
    }

    $procesos = [];
    $consultaProcesos = $conn->query('SELECT id_proceso_catalogo, nombre FROM catalogo_procesos_servicio');
    while ($registro = $consultaProcesos->fetch_assoc()) {
        $procesos[normalizarCatalogo($registro['nombre'])] = (int) $registro['id_proceso_catalogo'];
    }
    $procesosPorArea = [];
    $procesosUsados = [];
    foreach ($filas as $fila) {
        $claveArea = claveAreaExcel($fila['C']);
        if (!isset($ordenAreas[$claveArea])) {
            throw new RuntimeException('Área no reconocida en fila ' . $fila['fila'] . ': ' . $fila['C']);
        }
        $idArea = (int) $ordenAreas[$claveArea][2];
        $claveProceso = normalizarCatalogo($fila['D']);
        if (!isset($procesosPorArea[$idArea])) {
            $procesosPorArea[$idArea] = [];
        }
        if (!isset($procesosPorArea[$idArea][$claveProceso])) {
            $ordenProceso = count($procesosPorArea[$idArea]) + 1;
            $idProceso = $procesos[$claveProceso] ?? null;
            $codigoProceso = $ordenAreas[$claveArea][0] . '.' . $ordenProceso;
            if ($idProceso === null) {
                $insertarProceso = $conn->prepare(
                    "INSERT INTO catalogo_procesos_servicio (id_catalogo, codigo_proceso, nombre, estado, orden, creado_en) VALUES (?, ?, ?, 'activo', ?, NOW())"
                );
                $insertarProceso->bind_param('issi', $idArea, $codigoProceso, $fila['D'], $ordenProceso);
                $insertarProceso->execute();
                $idProceso = (int) $conn->insert_id;
            } else {
                $actualizarProceso = $conn->prepare(
                    "UPDATE catalogo_procesos_servicio SET id_catalogo = ?, codigo_proceso = ?, nombre = ?, estado = 'activo', orden = ? WHERE id_proceso_catalogo = ?"
                );
                $actualizarProceso->bind_param('issii', $idArea, $codigoProceso, $fila['D'], $ordenProceso, $idProceso);
                $actualizarProceso->execute();
            }
            $procesosPorArea[$idArea][$claveProceso] = ['id' => $idProceso, 'orden' => $ordenProceso];
            $procesosUsados[$idProceso] = true;
        }
    }

    $servicios = [];
    $consultaServicios = $conn->query('SELECT id_servicio, id_catalogo, nombre, id_sla, id_gestor FROM servicios');
    while ($registro = $consultaServicios->fetch_assoc()) {
        $clave = (int) $registro['id_catalogo'] . ':' . normalizarCatalogo($registro['nombre']);
        $servicios[$clave][] = $registro;
    }
    $equivalencias = [
        'mantenimientodesistemasdeseguridadelectronicax000dcorrectivosemergencias' => 'mantenimientodesistemasdeseguridadelectronicacorrectivosemergencias',
        'cambiosdeherramineta' => 'cambiosdeherramienta',
        'pruebasdeconocimiemto' => 'pruebasdeconocimiento',
        'ajustesdeproducciondelosdiferentescliente' => 'ajustesdeproducciondelosdiferentesclientes',
    ];
    $usuarios = [];
    $consultaUsuarios = $conn->query("SELECT id_usuario, nombre FROM usuarios WHERE estado = 'activo'");
    while ($registro = $consultaUsuarios->fetch_assoc()) {
        $usuarios[normalizarCatalogo($registro['nombre'])] = (int) $registro['id_usuario'];
    }
    $serviciosUsados = [];
    $usosServicios = [];
    $gestoresReparados = [];
    $actualizacionesServicios = [];
    $insertados = 0;
    foreach ($filas as $fila) {
        $claveArea = claveAreaExcel($fila['C']);
        $idArea = (int) $ordenAreas[$claveArea][2];
        $areaOrden = (int) $ordenAreas[$claveArea][0];
        $claveProceso = normalizarCatalogo($fila['D']);
        $proceso = $procesosPorArea[$idArea][$claveProceso];
        $claveNombre = normalizarCatalogo($fila['E']);
        $claveBusqueda = $equivalencias[$claveNombre] ?? $claveNombre;
        $claveServicio = $idArea . ':' . $claveNombre;
        // En la primera carga se usa la equivalencia para corregir una diferencia
        // ortográfica previa; en cargas posteriores prevalece el nombre oficial.
        if (!isset($servicios[$claveServicio])) {
            $claveServicio = $idArea . ':' . $claveBusqueda;
        }
        $ordenServicio = 1;
        foreach ($filas as $previa) {
            if ((int) $previa['fila'] >= (int) $fila['fila']) {
                break;
            }
            if (claveAreaExcel($previa['C']) === $claveArea && normalizarCatalogo($previa['D']) === $claveProceso) {
                ++$ordenServicio;
            }
        }
        // Regla operativa definida por el catálogo: este servicio se identifica como 1.1.19.
        if ($claveNombre === 'compradetiquetes') {
            $ordenServicio = 19;
        }
        $codigo = $areaOrden . '.' . $proceso['orden'] . '.' . $ordenServicio;
        $idSla = buscarSla($conn, $pais, $fila['H'] ?? '');
        $tipo = ucfirst(strtolower(trim((string) ($fila['I'] ?? 'Requerimiento'))));
        $urgencia = max(0, (int) ($fila['K'] ?? 0));
        $impacto = max(0, (int) ($fila['L'] ?? 0));
        $prioridad = max($urgencia, $impacto);
        $descripcion = descripcionServicio($fila);
        $indiceCoincidencia = $usosServicios[$claveServicio] ?? 0;
        $existente = $servicios[$claveServicio][$indiceCoincidencia] ?? null;
        $usosServicios[$claveServicio] = $indiceCoincidencia + 1;
        // El Excel contiene una fila literal duplicada para el mismo servicio.
        // La restricción única catálogo/nombre evita inventar un segundo nombre;
        // se conserva el registro oficial existente.
        if ($existente === null && isset($servicios[$claveServicio][0])) {
            $existente = $servicios[$claveServicio][0];
        }
        if ($idSla === null && $existente !== null) {
            // Algunos registros del Excel solo dicen "SLA 10"; se conserva su SLA ya configurado.
            $idSla = (int) $existente['id_sla'];
        }
        $gestorRespaldo = 0;
        if ($existente !== null && (int) ($existente['id_gestor'] ?? 0) < 1) {
            $buscarGestorProceso = $conn->prepare(
                "SELECT s.id_gestor
                 FROM servicios s
                 INNER JOIN usuarios u ON u.id_usuario = s.id_gestor
                 WHERE s.id_catalogo = ?
                   AND s.id_proceso_catalogo = ?
                   AND s.id_servicio <> ?
                   AND s.id_gestor IS NOT NULL
                   AND u.id_rol = 2
                   AND u.estado = 'activo'
                 ORDER BY s.orden_catalogo, s.id_servicio
                 LIMIT 1"
            );
            $idExistente = (int) $existente['id_servicio'];
            $buscarGestorProceso->bind_param('iii', $idArea, $proceso['id'], $idExistente);
            $buscarGestorProceso->execute();
            $gestorProceso = $buscarGestorProceso->get_result()->fetch_assoc();
            $gestorRespaldo = (int) ($gestorProceso['id_gestor'] ?? 0);
        }
        if ($existente === null) {
            $idGestor = null;
            foreach (preg_split('/[-\n,]+/', (string) ($fila['O'] ?? '')) as $responsable) {
                $claveResponsable = normalizarCatalogo($responsable);
                if (isset($usuarios[$claveResponsable])) {
                    $idGestor = $usuarios[$claveResponsable];
                    break;
                }
            }
            if ($idGestor === null && isset($servicios[$claveServicio][0]['id_gestor'])) {
                $idGestor = (int) $servicios[$claveServicio][0]['id_gestor'];
            }
            $insertarServicio = $conn->prepare(
                "INSERT INTO servicios (codigo_servicio, orden_catalogo, id_pais_operacion, id_catalogo, id_proceso_catalogo, id_sla, id_gestor, nombre, descripcion, tipo_solicitud, estado, prioridad_valor, urgencia_valor, impacto_valor, creado_en) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'activo', ?, ?, ?, NOW())"
            );
            $insertarServicio->bind_param('siiiiiisssiii', $codigo, $ordenServicio, $pais, $idArea, $proceso['id'], $idSla, $idGestor, $fila['E'], $descripcion, $tipo, $prioridad, $urgencia, $impacto);
            $insertarServicio->execute();
            $existente = ['id_servicio' => (int) $conn->insert_id, 'id_gestor' => $idGestor];
            ++$insertados;
            if ($idGestor !== null) {
                $desactivar = $conn->prepare("UPDATE servicio_gestores SET estado = 'inhabilitado' WHERE id_servicio = ?");
                $desactivar->bind_param('i', $existente['id_servicio']);
                $desactivar->execute();
                $asignar = $conn->prepare("INSERT INTO servicio_gestores (id_servicio, id_usuario, estado, fecha_asignacion) VALUES (?, ?, 'activo', NOW()) ON DUPLICATE KEY UPDATE estado = 'activo', actualizado_en = CURRENT_TIMESTAMP");
                $asignar->bind_param('ii', $existente['id_servicio'], $idGestor);
                $asignar->execute();
            }
        }
        if ($existente === null) {
            throw new RuntimeException('No se encontró el servicio de la fila ' . $fila['fila'] . ': ' . $fila['E']);
        }
        if ($idSla === null) {
            throw new RuntimeException('SLA inválido en fila ' . $fila['fila']);
        }
        $idServicio = (int) $existente['id_servicio'];
        $escapar = static fn (string $valor): string => "'" . $conn->real_escape_string($valor) . "'";
        $actualizacionesServicios[] = 'UPDATE servicios SET '
            . 'codigo_servicio = ' . $escapar($codigo)
            . ', orden_catalogo = ' . $ordenServicio
            . ', id_catalogo = ' . $idArea
            . ', id_proceso_catalogo = ' . (int) $proceso['id']
            . ', id_sla = ' . $idSla
            . ($gestorRespaldo > 0 ? ', id_gestor = ' . $gestorRespaldo : '')
            . ', nombre = ' . $escapar((string) $fila['E'])
            . ', descripcion = ' . $escapar($descripcion)
            . ', tipo_solicitud = ' . $escapar($tipo)
            . ", estado = 'activo'"
            . ', prioridad_valor = ' . $prioridad
            . ', urgencia_valor = ' . $urgencia
            . ', impacto_valor = ' . $impacto
            . ' WHERE id_servicio = ' . $idServicio;
        $serviciosUsados[$idServicio] = true;
        if ($gestorRespaldo > 0) {
            $gestoresReparados[$idServicio] = $gestorRespaldo;
        }
    }

    ejecutarLote($conn, $actualizacionesServicios);
    foreach ($gestoresReparados as $idServicio => $idGestor) {
        $desactivar = $conn->prepare("UPDATE servicio_gestores SET estado = 'inhabilitado' WHERE id_servicio = ?");
        $desactivar->bind_param('i', $idServicio);
        $desactivar->execute();
        $asignar = $conn->prepare(
            "INSERT INTO servicio_gestores (id_servicio, id_usuario, estado, fecha_asignacion)
             VALUES (?, ?, 'activo', NOW())
             ON DUPLICATE KEY UPDATE estado = 'activo', actualizado_en = CURRENT_TIMESTAMP"
        );
        $asignar->bind_param('ii', $idServicio, $idGestor);
        $asignar->execute();
    }

    foreach ($todosCatalogos as $idCatalogo) {
        if (!isset($areasUsadas[$idCatalogo])) {
            $conn->query("UPDATE catalogos SET estado = 'inhabilitado' WHERE id_catalogo = " . (int) $idCatalogo);
        }
    }
    foreach ($procesos as $clave => $idProceso) {
        if (!isset($procesosUsados[$idProceso])) {
            $conn->query("UPDATE catalogo_procesos_servicio SET estado = 'inhabilitado' WHERE id_proceso_catalogo = " . (int) $idProceso);
        }
    }
    $consultaIds = $conn->query('SELECT id_servicio FROM servicios');
    while ($registro = $consultaIds->fetch_assoc()) {
        $idServicio = (int) $registro['id_servicio'];
        if (!isset($serviciosUsados[$idServicio])) {
            $conn->query("UPDATE servicios SET estado = 'inhabilitado' WHERE id_servicio = " . $idServicio);
        }
    }
    $conn->commit();
    echo 'Importación V.9 terminada: ' . count($serviciosUsados) . ' servicios oficiales únicos; '
        . $insertados . " creados; los registros previos no oficiales quedaron inhabilitados.\n";
} catch (Throwable $error) {
    $conn->rollback();
    fwrite(STDERR, 'Importación cancelada: ' . $error->getMessage() . "\n");
    exit(1);
}
