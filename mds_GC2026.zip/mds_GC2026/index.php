<?php
declare(strict_types=1);

$metodo = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

if ($metodo === 'POST') {
    require_once __DIR__ . '/app/bootstrap.php';
    require APP_ROOT . '/modules/auth/login.php';
    return;
}

if (!in_array($metodo, ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD, POST');
    http_response_code(405);
    exit('Metodo no permitido.');
}

require_once __DIR__ . '/app/bootstrap.php';
require_once APP_ROOT . '/security/seguridad.php';

seguridadAplicarCabeceras(true);
seguridadIniciarSesion();

header('Content-Type: text/html; charset=UTF-8');

if ($metodo === 'HEAD') {
    exit;
}

/* El login se carga como contenido del marco, nunca como URL principal. */
if ((string) ($_GET['vista'] ?? '') === 'acceso') {
    readfile(PUBLIC_ROOT . '/login.html');
    exit;
}

/*
 * Si un cierre de sesion redirige dentro del marco, se actualiza la ventana
 * principal sin crear un marco dentro de otro.
 */
if (strtolower((string) ($_SERVER['HTTP_SEC_FETCH_DEST'] ?? '')) === 'iframe') {
    $inicioJson = json_encode(
        mesaUrlInicio(),
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );
    ?>
<!doctype html>
<html lang="es"><head><meta charset="utf-8"><title>SMARTDESK</title></head>
<body><script>window.top.location.replace(<?= $inicioJson ?>);</script></body></html>
<?php
    exit;
}

$rol = (int) ($_SESSION['rol'] ?? 0);
$autenticado = !empty($_SESSION['usuario_id']) && in_array($rol, [1, 2, 3], true);
$pantallasPermitidas = [
    'apariencia.php', 'catalogos.php', 'checklists.php', 'chat.php',
    'configuraciones.php',
    'crearUsuarios.php', 'crearticket.php', 'diagnostico_relaciones.php',
    'editarUsuario.php', 'editarcatalogos.php', 'feriados.php', 'horarios.php',
    'flujoTicket.php', 'indicadores.php', 'mensajes.php', 'panelAdmin.php',
    'panelGestor.php', 'panelSolicitante.php', 'perfil.php', 'prioridades.php',
    'procesos.php', 'Registro.php',
    'seleccionarPais.php', 'servicios.php', 'sesiones.php', 'sla.php', 'solicitudes.php',
    'soluciones.php', 'verificarActualizacionSolicitudes.php',
    'verificarCalendarioSla.php', 'verificarFlujos.php',
];

if ((string) ($_GET['_mesa_action'] ?? '') === 'record_screen') {
    $solicitudInterna = strtolower((string) (
        $_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''
    )) === 'xmlhttprequest';
    $pantallaRegistrada = basename((string) ($_GET['screen'] ?? ''));

    if (!$autenticado || !$solicitudInterna) {
        http_response_code(403);
        exit;
    }
    if (in_array($pantallaRegistrada, $pantallasPermitidas, true)) {
        $_SESSION['mesa_ultima_pantalla'] = $pantallaRegistrada;
    }
    http_response_code(204);
    exit;
}

if ($autenticado) {
    $pantalla = basename((string) ($_SESSION['mesa_ultima_pantalla'] ?? ''));

    if (!in_array($pantalla, $pantallasPermitidas, true)) {
        if ($rol === 1) {
            $pantalla = ((int) ($_SESSION['pais_operacion_id'] ?? 0) > 0)
                ? 'panelAdmin.php'
                : 'seleccionarPais.php';
        } elseif ($rol === 2) {
            $pantalla = 'panelGestor.php';
        } else {
            $pantalla = 'panelSolicitante.php';
        }
    }

    $src = $pantalla;
    if ($pantalla === 'panelSolicitante.php') {
        $src .= '?vista=tickets';
    }
} else {
    $pantallaPublica = (string) ($_SESSION['mesa_pantalla_publica'] ?? '');
    unset($_SESSION['mesa_pantalla_publica']);

    if ($pantallaPublica === 'recuperarPassword.php') {
        $src = 'recuperarPassword.php';
    } else {
        $parametrosAcceso = ['vista' => 'acceso'];
        $error = (string) ($_SESSION['mesa_login_error'] ?? '');
        $estado = (string) ($_SESSION['mesa_login_estado'] ?? '');
        $recuperacion = (string) (
            $_SESSION['mesa_login_recuperacion'] ?? ''
        );
        $intentosLogin = (int) ($_SESSION['mesa_login_intentos'] ?? 0);
        unset(
            $_SESSION['mesa_login_error'],
            $_SESSION['mesa_login_estado'],
            $_SESSION['mesa_login_recuperacion'],
            $_SESSION['mesa_login_intentos']
        );

        if ($error !== '') {
            $parametrosAcceso['error'] = $error;
        }
        if ($estado !== '') {
            $parametrosAcceso['sesion'] = $estado;
        }
        if ($recuperacion !== '') {
            $parametrosAcceso['recuperacion'] = $recuperacion;
        }
        if ($intentosLogin > 0) {
            $parametrosAcceso['intentos'] = min($intentosLogin, 5);
        }

        $src = './?' . http_build_query(
            $parametrosAcceso,
            '',
            '&',
            PHP_QUERY_RFC3986
        );
    }
}

$srcJson = json_encode(
    $src,
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);
$inicioJson = json_encode(
    mesaUrlInicio(),
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);
$pantallasPermitidasJson = json_encode(
  array_values($pantallasPermitidas),
  JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#eef5ff">
  <title>SMARTDESK | Conectar</title>
  <style>
    html,body{width:100%;height:100%;margin:0;overflow:hidden;background:#f3f6fb}
    body{position:relative}
    body.is-navigating{cursor:progress}
    .mesa-app-frame{
      position:absolute;inset:0;width:100%;height:100%;border:0;
      z-index:0;background:#f3f6fb;opacity:0;pointer-events:none;
      transition:opacity 90ms ease-out
    }
    .mesa-app-frame.is-active{z-index:2;opacity:1;pointer-events:auto}
    .mesa-app-frame.is-leaving{z-index:1;opacity:1;pointer-events:none}
  </style>
  <script>
    (function(){
      if(window.top!==window.self){
        window.top.location.replace(<?= $inicioJson ?>);
        return;
      }
      if(window.location.search||window.location.hash){
        history.replaceState(history.state,document.title,<?= $inicioJson ?>);
      }
    }());
  </script>
</head>
<body>
  <script>
    (function(){
      var basePath=<?= $inicioJson ?>;
      var baseUrl=new URL(basePath,window.location.href).href;
      var serverInitialUrl=<?= $srcJson ?>;
      var allowedScreens=<?= $pantallasPermitidasJson ?>;
      var authenticated=<?= $autenticado ? 'true' : 'false' ?>;
      window.MESA_NAVIGATION_VERSION='2026-09-30.2-background-image-cache';
      document.documentElement.dataset.mesaNavigationVersion=
        window.MESA_NAVIGATION_VERSION;
      var storedInitialUrl='';
      try{
        if(authenticated){
          var storedCandidates=[
            window.history.state&&window.history.state.mesaRoute,
            window.sessionStorage.getItem('MESA_CURRENT_ROUTE')
          ];
          for(var storedIndex=0;storedIndex<storedCandidates.length;storedIndex+=1){
            var storedCandidate=storedCandidates[storedIndex]||'';
            if(!storedCandidate){continue}
            var storedCandidateUrl=new URL(storedCandidate,baseUrl);
            if(storedCandidateUrl.searchParams.get('vista')==='acceso'){
              continue;
            }
            var storedScreen=(storedCandidateUrl.pathname.split('/').pop()||'').toLowerCase();
            if(allowedScreens.map(function(screen){return screen.toLowerCase()}).indexOf(storedScreen)===-1){
              continue;
            }
            storedInitialUrl=storedCandidate;
            break;
          }
          if(!storedInitialUrl){
            window.sessionStorage.removeItem('MESA_CURRENT_ROUTE');
          }
        }else{
          window.sessionStorage.removeItem('MESA_CURRENT_ROUTE');
        }
      }catch(error){}
      var initialUrl=storedInitialUrl||serverInitialUrl;

      /* El portal mantiene la ventana principal. Cada respuesta se prepara en
         un marco aislado y se muestra apenas termina de construir su HTML. */

      function startMesaShellV3(startUrl){
        var shellFrame=document.createElement('iframe');
        var activeRoute='';
        var loadingRoute='';
        var requestSequence=0;
        var renderFrame=null;
        var pendingRender=null;
        var shellDocumentCache=new Map();
        var shellDocumentCacheTtl=15000;
        var shellHistoryIndex=0;
        var restoredShellIndex=Number(window.history.state&&window.history.state.mesaIndex);
        if(Number.isFinite(restoredShellIndex)&&restoredShellIndex>=0){
          shellHistoryIndex=restoredShellIndex;
        }

        function shellAbsolute(route){
          try{return new URL(route,baseUrl)}catch(error){return null}
        }

        function shellNormalize(route){
          var routeUrl=shellAbsolute(route);
          if(!routeUrl||routeUrl.origin!==window.location.origin){return ''}
          routeUrl.searchParams.delete('_mesa_prefetch');
          return routeUrl.pathname+routeUrl.search+routeUrl.hash;
        }

        function shellRequestDocument(url,options,allowCache){
          var key=shellNormalize(url);
          var now=Date.now();
          var cached=allowCache&&key?shellDocumentCache.get(key):null;
          if(cached&&now-cached.created<shellDocumentCacheTtl){
            return cached.promise;
          }
          if(cached){shellDocumentCache.delete(key)}

          var promise=window.fetch(url,options).then(function(response){
            if(!response.ok){throw new Error('HTTP '+response.status)}
            return response.text().then(function(html){
              return {html:html,url:response.url||url};
            });
          });

          if(allowCache&&key){
            var entry={created:now,promise:promise};
            shellDocumentCache.set(key,entry);
            promise.catch(function(){
              if(shellDocumentCache.get(key)===entry){shellDocumentCache.delete(key)}
            });
          }
          return promise;
        }

        function shellRemember(route){
          var internalRoute=shellNormalize(route);
          if(!internalRoute){return ''}
          if(!authenticated){return internalRoute}
          try{window.sessionStorage.setItem('MESA_CURRENT_ROUTE',internalRoute)}
          catch(error){}
          return internalRoute;
        }

        function shellCommit(route){
          /* La ruta se conserva en sessionStorage. Evitar una petición PHP
             adicional por clic impide bloquear la sesión al navegar rápido. */
        }

        function shellRecord(route,mode){
          var internalRoute=shellNormalize(route);
          if(!internalRoute){return ''}
          if(mode==='replace'){
            window.history.replaceState({
              mesaRoute:internalRoute,
              mesaIndex:shellHistoryIndex
            },'',baseUrl);
          }else{
            shellHistoryIndex+=1;
            window.history.pushState({
              mesaRoute:internalRoute,
              mesaIndex:shellHistoryIndex
            },'',baseUrl);
          }
          shellRemember(internalRoute);
          shellCommit(internalRoute);
          return internalRoute;
        }

        function shellRecordEmbeddedRoute(route){
          var internalRoute=shellNormalize(route);
          if(!internalRoute){return}
          shellRecord(internalRoute,'push');
        }

        function shellEscapeAttribute(value){
          return String(value)
            .replace(/&/g,'&amp;')
            .replace(/"/g,'&quot;')
            .replace(/</g,'&lt;');
        }

        function shellPrepareHtml(html,url){
          var baseTag='<base href="'+shellEscapeAttribute(url)+'">';
          /*
           * document.write() conserva inicialmente la URL about:blank del
           * iframe. Las vistas que consultan window.location necesitan ver la
           * ruta real del módulo. replaceState solo actualiza esa URL interna:
           * no crea un paso adicional en el historial.
          */
          var routeBootstrap='<script>try{history.replaceState({mesaEmbedded:true},"",'
            +JSON.stringify(url)+')}catch(error){}<'+'/script>';
          if(/<head(?:\s[^>]*)?>/i.test(html)){
            return html.replace(/<head(\s[^>]*)?>/i,function(match){
              return match+baseTag+routeBootstrap;
            });
          }
          return '<!doctype html><html><head>'+baseTag+routeBootstrap+'</head><body>'+html+'</body></html>';
        }

        function shellWrite(html,url,onLoad){
          // Un iframe nuevo evita reescribir repetidamente el mismo documento.
          // document.open() elimina listeners y Edge falla al repetir write().
          var nextFrame=document.createElement('iframe');
          nextFrame.name='mesaFrame'+requestSequence;
          nextFrame.title='SMARTDESK';
          nextFrame.className='mesa-app-frame';
          nextFrame.setAttribute('allow','clipboard-write');
          renderFrame=nextFrame;
          function activateFrame(){
            if(renderFrame!==nextFrame){return}
            if(pendingRender){
              renderFrame=null;
              nextFrame.remove();
              shellStopLoading();
              return;
            }
            renderFrame=null;
            var oldFrame=shellFrame;
            shellFrame=nextFrame;
            nextFrame.classList.add('is-active');
            oldFrame.classList.remove('is-active');
            try{shellBindNavigation()}
            catch(error){console.error('No fue posible enlazar la navegación.',error)}
            finally{
              oldFrame.remove();
              onLoad();
            }
          }
          document.body.appendChild(nextFrame);
          var doc=nextFrame.contentWindow.document;
          doc.open();
          doc.addEventListener('DOMContentLoaded',activateFrame,{once:true});
          doc.write(shellPrepareHtml(html,url));
          doc.close();
        }

        function shellStopLoading(){
          loadingRoute='';
          document.body.classList.remove('is-navigating');
          if(pendingRender){
            var next=pendingRender;
            pendingRender=null;
            shellRender(next.url,next.historyMode,next.requestOptions);
          }
        }

        function shellQueueNavigation(url,historyMode){
          shellRender(url,historyMode);
        }

        function shellRender(url,historyMode,requestOptions){
          var target=shellAbsolute(url);
          if(!target||target.origin!==window.location.origin){return}
          var targetRoute=shellNormalize(target.href);
          if(loadingRoute){
            // PHP puede seguir ejecutando una petición aunque fetch se aborte.
            // Conservar únicamente el destino final evita saturar el servidor.
            pendingRender=targetRoute===loadingRoute&&!requestOptions
              ? null
              : {url:url,historyMode:historyMode,requestOptions:requestOptions};
            return;
          }
          if(historyMode==='push'&&targetRoute===activeRoute){
            return;
          }
          requestSequence+=1;
          var thisRequest=requestSequence;
          loadingRoute=targetRoute;
          document.body.classList.add('is-navigating');

          var options={
            method:'GET',
            credentials:'same-origin',
            cache:'no-store',
            redirect:'follow',
            headers:{'X-Requested-With':'MesaNavigation'}
          };
          if(requestOptions){
            Object.keys(requestOptions).forEach(function(key){
              options[key]=requestOptions[key];
            });
          }
          var isCacheable=String(options.method||'GET').toUpperCase()==='GET'&&!options.body;
          if(!isCacheable){shellDocumentCache.clear()}

          shellRequestDocument(target.href,options,isCacheable).then(function(result){
            if(thisRequest!==requestSequence){return}
            if(pendingRender){shellStopLoading();return}
            var finalRoute=shellNormalize(result.url)||targetRoute;
            shellWrite(result.html,result.url||target.href,function(){
              if(thisRequest!==requestSequence){return}
              if(historyMode==='deferred'||historyMode==='push'){
                shellRecord(finalRoute,'push');
              }else{
                shellRemember(finalRoute);
                shellCommit(finalRoute);
              }
              activeRoute=finalRoute;
              shellStopLoading();
            });
          }).catch(function(error){
            if(thisRequest!==requestSequence){return}
            if(renderFrame){var failedFrame=renderFrame;renderFrame=null;failedFrame.remove()}
            shellStopLoading();
            if(error&&error.name==='AbortError'){return}
            if(window.console&&console.error){
              console.error('No fue posible abrir el módulo.',error);
            }
          });
        }

        function shellIsDownload(url,element){
          if(element&&element.hasAttribute&&element.hasAttribute('download')){
            return true;
          }
          return /\/(?:descargar|imagenCatalogo|imagenPerfil)[^/]*\.php$/i.test(url.pathname)
            || /\.(?:pdf|xlsx?|csv|zip|rar|docx?|pptx?)$/i.test(url.pathname);
        }

        function shellAppendSubmitter(data,submitter){
          if(submitter&&submitter.name&&!data.has(submitter.name)){
            data.append(submitter.name,submitter.value||'');
          }
        }

        function shellBindNavigation(){
          var doc;
          try{doc=shellFrame.contentDocument}catch(error){return}
          if(!doc||!doc.documentElement){return}
          if(doc.documentElement.dataset.mesaNavigationBound){return}
          doc.documentElement.dataset.mesaNavigationBound='1';

          // Oculta las rutas físicas .php en la barra de estado del navegador.
          // La navegación real continúa usando data-mesa-route para el router interno.
          Array.prototype.forEach.call(doc.querySelectorAll('a[href]'), function(link){
            var original=link.getAttribute('href');
            if(!original || original.charAt(0)==='#' || /^javascript:/i.test(original)){return;}
            if(!link.getAttribute('data-mesa-route')){
              link.setAttribute('data-mesa-route', original);
            }
            try {
              var visible=new URL(original, baseUrl);
              if(shellIsDownload(visible,link)){return}
              if(visible.pathname.match(/\.php$/i)){
                link.setAttribute('href', visible.pathname.replace(/\.php$/i,'') + visible.search + visible.hash);
              }
            } catch(error) {}
          });

          doc.addEventListener('click',function(event){
            if(event.defaultPrevented||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey){
              return;
            }
            var link=event.target.closest?event.target.closest('a[href]'):null;
            if(!link){return}
            var targetName=(link.getAttribute('target')||'').toLowerCase();
            if(targetName&&targetName!=='_self'){return}
            var url;
            try{url=new URL(link.getAttribute('data-mesa-route')||link.href,baseUrl)}catch(error){return}
            if(url.origin!==window.location.origin||shellIsDownload(url,link)){return}
            if(url.protocol!=='http:'&&url.protocol!=='https:'){return}

            event.preventDefault();
            if(/\/logout\.php$/i.test(url.pathname)){
              window.fetch(url.href,{credentials:'same-origin',cache:'no-store'})
                .finally(function(){window.location.replace(baseUrl)});
              return;
            }

            var current=shellAbsolute(activeRoute);
            if(current&&url.pathname===current.pathname&&url.search===current.search&&url.hash){
              var anchor=doc.getElementById(url.hash.slice(1));
              if(anchor&&anchor.scrollIntoView){anchor.scrollIntoView()}
              return;
            }
            shellQueueNavigation(url.href,'push');
          });

          doc.addEventListener('submit',function(event){
            if(event.defaultPrevented||!authenticated){return}
            var form=event.target;
            if(!form||String(form.method||'get').toLowerCase()==='dialog'){return}
            var targetName=(form.getAttribute('target')||'').toLowerCase();
            if(targetName==='_top'||targetName==='_parent'||targetName==='_blank'){return}

            var rawAction=form.getAttribute('action');
            var action=shellAbsolute(rawAction&&rawAction.trim()?form.action:activeRoute);
            if(!action||action.origin!==window.location.origin||shellIsDownload(action,form)){return}

            event.preventDefault();
            var method=String(form.method||'get').toUpperCase();
            var data=new FormData(form);
            shellAppendSubmitter(data,event.submitter);
            if(method==='GET'){
              action.search='';
              data.forEach(function(value,key){
                if(typeof value==='string'){action.searchParams.append(key,value)}
              });
              shellRender(action.href,'push');
              return;
            }
            shellRender(action.href,'deferred',{method:method,body:data});
          });
        }

        window.addEventListener('popstate',function(event){
          var state=event.state||{};
          var route=shellNormalize(state.mesaRoute||'');
          if(!route){return}
          var restoredIndex=Number(state.mesaIndex);
          if(Number.isFinite(restoredIndex)&&restoredIndex>=0){
            shellHistoryIndex=restoredIndex;
          }
          shellRemember(route);
          shellRender(route,'none');
        });

        window.addEventListener('message',function(event){
          if(event.origin!==window.location.origin||!event.data){
            return;
          }
          if(event.source!==shellFrame.contentWindow){return}
          if(event.data.tipo==='mesa-navegar'){
            shellQueueNavigation(event.data.url,'push');
          }else if(event.data.tipo==='mesa-historial'){
            shellRecord(event.data.url,event.data.replace?'replace':'push');
          }
        });

        activeRoute=shellNormalize(startUrl)||shellNormalize(serverInitialUrl);
        window.history.replaceState({
          mesaRoute:activeRoute,
          mesaIndex:shellHistoryIndex
        },'',baseUrl);
        shellRemember(activeRoute);

        shellFrame.name='mesaFrame';
        shellFrame.title='SMARTDESK';
        shellFrame.className='mesa-app-frame is-active';
        shellFrame.setAttribute('allow','clipboard-write');
        document.body.appendChild(shellFrame);
        activeRoute='';
        shellRender(startUrl,'initial');
      }

      /*
       * La navegación principal usa el iframe nativo definido debajo. El
       * navegador puede procesar la respuesta mientras llega y comenzar a
       * cargar sus recursos sin esperar a convertir todo el HTML en texto.
       * startMesaShellV3 se conserva temporalmente como referencia, pero no se
       * inicia porque serializaba las vistas y retenía documentos completos.
       */

      var activeFrame=null;
      var pendingFrame=null;
      var pendingTarget='';
      var pendingHistory='none';
      var pendingGuard=0;
      var frameSequence=0;
      var lastRecordedRoute='';
      var historyIndex=0;
      var mesaImagePrefetches=new Map();
      var mesaImagePrefetchGeneration=0;

      function cancelFrameImagePrefetches(){
        mesaImagePrefetchGeneration+=1;
        mesaImagePrefetches.forEach(function(imagen){
          try{
            if(imagen&&!imagen.complete){imagen.src='';}
          }catch(error){}
        });
        mesaImagePrefetches.clear();
      }

      /*
       * Las imágenes de procesos viven en Graph detrás de imagenCatalogo.php.
       * Se solicitan desde la ventana principal, fuera del iframe que cambia de
       * módulo, para que la descarga continúe aunque el usuario navegue antes
       * de que termine. Las URLs versionadas quedan en la caché del navegador.
       * La cola es deliberadamente escalonada para no saturar la conexión al
       * abrir una vista con muchos procesos.
       */
      function prefetchFrameImages(frame){
        var imagenes=[];
        try{
          imagenes=Array.prototype.map.call(
            frame.contentDocument.querySelectorAll('img[src*="imagenCatalogo.php"]'),
            function(imagen){return imagen.currentSrc||imagen.src||''}
          );
        }catch(error){return}

        var cola=imagenes.slice(0,20).filter(function(url){
          return url&&!mesaImagePrefetches.has(url);
        });
        if(!cola.length){return}

        var generacion=mesaImagePrefetchGeneration;
        var iniciarCola=function(){
          if(generacion!==mesaImagePrefetchGeneration){return}
          var indice=0;
          var siguiente=function(){
            if(generacion!==mesaImagePrefetchGeneration||indice>=cola.length){return}
            var url=cola[indice++];
            if(!url||mesaImagePrefetches.has(url)){
              siguiente();
              return;
            }
            var imagen=new Image();
            imagen.decoding='async';
            try{imagen.fetchPriority='low'}catch(error){}
            mesaImagePrefetches.set(url,imagen);
            var retirar=function(){
              window.setTimeout(function(){mesaImagePrefetches.delete(url)},1000);
            };
            imagen.onload=retirar;
            imagen.onerror=retirar;
            imagen.src=url;
            window.setTimeout(siguiente,180);
          };
          siguiente();
        };

        if('requestIdleCallback' in window){
          window.requestIdleCallback(iniciarCola,{timeout:1200});
        }else{
          window.setTimeout(iniciarCola,300);
        }
      }
      var prefetchablePages=[
        'apariencia.php','catalogos.php','checklists.php','chat.php',
        'configuraciones.php','crearusuarios.php','crearticket.php',
        'diagnostico_relaciones.php','editarusuario.php','editarcatalogos.php',
        'feriados.php','horarios.php','flujoticket.php','indicadores.php','mensajes.php',
        'paneladmin.php','panelgestor.php','panelsolicitante.php','perfil.php',
        'prioridades.php','procesos.php','registro.php','servicios.php','sla.php',
        'solicitudes.php','soluciones.php','verificaractualizacionsolicitudes.php',
        'verificarcalendariosla.php','verificarflujos.php'
      ];
      var initialRouteUrl;
      try{initialRouteUrl=new URL(initialUrl,baseUrl)}catch(error){initialRouteUrl=null}
      var initialPage=initialRouteUrl?(initialRouteUrl.pathname.split('/').pop()||'').toLowerCase():'';
      if(!initialRouteUrl||initialRouteUrl.origin!==window.location.origin||prefetchablePages.indexOf(initialPage)===-1){
        initialUrl=serverInitialUrl;
      }
      lastRecordedRoute=normalizeRoute(initialUrl);
      var restoredIndex=Number(window.history.state&&window.history.state.mesaIndex);
      if(Number.isFinite(restoredIndex)&&restoredIndex>=0){historyIndex=restoredIndex}

      function createFrame(isActive){
        var frame=document.createElement('iframe');
        frameSequence+=1;
        frame.name='mesaFrame'+frameSequence;
        frame.title='SMARTDESK';
        frame.className='mesa-app-frame'+(isActive?' is-active':'');
        frame.setAttribute('allow','clipboard-write');
        frame.addEventListener('load',function(){frameLoaded(frame)});
        document.body.appendChild(frame);
        return frame;
      }

      function loadFrame(frame,url){
        try{frame.contentWindow.location.replace(url)}
        catch(error){frame.src=url}
        if(frame===pendingFrame){watchFrameDocument(frame)}
      }

      /* Activa el módulo cuando su DOM está listo; las imágenes continúan
         cargando detrás y quedan en la caché HTTP del navegador. */
      function clearFrameDocumentWatch(frame){
        if(frame&&frame.__mesaReadyTimer){
          window.clearTimeout(frame.__mesaReadyTimer);
          frame.__mesaReadyTimer=0;
        }
      }

      function watchFrameDocument(frame){
        clearFrameDocumentWatch(frame);
        function revisar(){
          if(frame!==pendingFrame){
            clearFrameDocumentWatch(frame);
            return;
          }
          var listo=false;
          try{
            var documento=frame.contentDocument;
            var ubicacion=frame.contentWindow.location.href;
            listo=ubicacion&&ubicacion!=='about:blank'
              &&documento&&documento.documentElement&&documento.body
              &&documento.readyState!=='loading';
          }catch(error){}
          if(listo){
            frame.__mesaReadyTimer=0;
            window.requestAnimationFrame(function(){
              if(frame===pendingFrame){activateLoadedFrame(frame)}
            });
            return;
          }
          frame.__mesaReadyTimer=window.setTimeout(revisar,25);
        }
        revisar();
      }

      function routeFromFrame(frame){
        try{
          var url=new URL(frame.contentWindow.location.href);
          if(url.origin!==window.location.origin){return initialUrl}
          return url.pathname+url.search+url.hash;
        }catch(error){return initialUrl}
      }

      function isDownload(url,element){
        if(element&&element.hasAttribute&&element.hasAttribute('download')){
          return true;
        }
        return /\/(?:descargar|imagenCatalogo|imagenPerfil)[^/]*\.php$/i.test(url.pathname)
          || /\.(?:pdf|xlsx?|csv|zip|rar|docx?|pptx?)$/i.test(url.pathname);
      }

      function cancelPendingNavigation(){
        window.clearTimeout(pendingGuard);
        if(pendingFrame&&pendingFrame!==activeFrame){
          clearFrameDocumentWatch(pendingFrame);
          pendingFrame.remove();
        }
        pendingFrame=null;
        pendingTarget='';
        pendingHistory='none';
        document.body.classList.remove('is-navigating');
      }

      function navigate(url,historyMode){
        var target,current;
        try{target=new URL(url,activeFrame.contentWindow.location.href)}
        catch(error){return}
        if(target.origin!==window.location.origin){return}
        try{current=new URL(activeFrame.contentWindow.location.href)}
        catch(error){current=null}
        if(current&&target.href===current.href){return}
        if(pendingFrame&&pendingTarget===target.href){return}

        /* Si el usuario cambia nuevamente de módulo antes de que termine la
           respuesta anterior, se cancela el iframe oculto y se conserva la
           pantalla visible. Así el último clic nunca queda ignorado detrás de
           una carga lenta. */
        if(pendingFrame){cancelPendingNavigation()}

        cancelPendingNavigation();
        cancelFrameImagePrefetches();
        /* El módulo visible se conserva mientras el siguiente documento carga
           en un iframe oculto. Así el navegador nunca muestra about:blank ni
           el fondo blanco entre dos pantallas. */
        if(historyMode==='push'){
          lastRecordedRoute=recordParentHistory(target.href,'push')||lastRecordedRoute;
          pendingHistory='committed';
        }else{
          pendingHistory='none';
        }

        pendingTarget=target.href;
        pendingFrame=createFrame(false);
        document.body.classList.add('is-navigating');
        pendingGuard=window.setTimeout(cancelPendingNavigation,12000);
        try{
          activeFrame.contentWindow.dispatchEvent(new Event('mesa:flujo:dispose'));
        }catch(error){}
        loadFrame(pendingFrame,target.href);
      }

      function commitRoute(route){
        /*
         * public/_entry.php registra la pantalla al atender el GET real del
         * iframe. Repetirlo desde aquí generaba una segunda petición por cada
         * cambio de módulo y podía competir por la misma sesión PHP.
         */
      }

      function normalizeRoute(route){
        var routeUrl;
        try{routeUrl=new URL(route,baseUrl)}
        catch(error){return ''}
        if(routeUrl.origin!==window.location.origin){return ''}
        routeUrl.searchParams.delete('_mesa_prefetch');
        return routeUrl.pathname+routeUrl.search+routeUrl.hash;
      }

      function rememberRoute(route){
        var internalRoute=normalizeRoute(route);
        if(!internalRoute){return ''}
        try{window.sessionStorage.setItem('MESA_CURRENT_ROUTE',internalRoute)}
        catch(error){}
        return internalRoute;
      }

      function recordParentHistory(route,mode){
        var internalRoute=normalizeRoute(route);
        if(!internalRoute){return ''}
        if(mode==='replace'){
          window.history.replaceState({mesaRoute:internalRoute,mesaIndex:historyIndex},'',baseUrl);
        }else{
          historyIndex+=1;
          window.history.pushState({mesaRoute:internalRoute,mesaIndex:historyIndex},'',baseUrl);
        }
        lastRecordedRoute=rememberRoute(internalRoute)||lastRecordedRoute;
        commitRoute(internalRoute);
        return internalRoute;
      }

      function bindNavigation(frame){
        var doc;
        try{doc=frame.contentDocument}catch(error){return}
        if(!doc||!doc.documentElement){return}
        if(doc.documentElement.dataset.mesaNavigationBound){return}
        doc.documentElement.dataset.mesaNavigationBound='1';

          // Oculta las rutas físicas .php en la barra de estado del navegador.
          // La navegación real continúa usando data-mesa-route para el router interno.
          Array.prototype.forEach.call(doc.querySelectorAll('a[href]'), function(link){
            var original=link.getAttribute('href');
            if(!original || original.charAt(0)==='#' || /^javascript:/i.test(original)){return;}
            if(!link.getAttribute('data-mesa-route')){
              link.setAttribute('data-mesa-route', original);
            }
            try {
              var visible=new URL(original, frame.contentWindow.location.href);
              if(isDownload(visible,link)){return}
              if(visible.pathname.match(/\.php$/i)){
                link.setAttribute('href', visible.pathname.replace(/\.php$/i,'') + visible.search + visible.hash);
              }
            } catch(error) {}
          });

        doc.addEventListener('click',function(event){
          if(event.defaultPrevented||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey){
            return;
          }
          var link=event.target.closest?event.target.closest('a[href]'):null;
          if(!link){return}
          var targetName=(link.getAttribute('target')||'').toLowerCase();
          if(targetName&&targetName!=='_self'){return}

          var url;
          try{
            url=new URL(
              link.getAttribute('data-mesa-route')||link.href,
              frame.contentWindow.location.href
            )
          }
          catch(error){return}
          if(url.origin!==window.location.origin||isDownload(url,link)){return}
          if(url.protocol!=='http:'&&url.protocol!=='https:'){return}
          if(url.href===frame.contentWindow.location.href){
            event.preventDefault();
            return;
          }
          if(url.pathname===frame.contentWindow.location.pathname&&url.search===frame.contentWindow.location.search&&url.hash){
            event.preventDefault();
            try{
              frame.contentWindow.history.replaceState(
                frame.contentWindow.history.state,'',url.href
              );
              frame.contentDocument.getElementById(url.hash.slice(1))?.scrollIntoView();
            }catch(error){}
            return;
          }

          event.preventDefault();
          navigate(url.href,'push');
        });

        doc.addEventListener('submit',function(event){
          if(event.defaultPrevented){return}
          var form=event.target;
          if(!form||String(form.method||'get').toLowerCase()==='dialog'){return}
          var targetName=(form.getAttribute('target')||'').toLowerCase();
          if(targetName==='_top'||targetName==='_parent'||targetName==='_blank'){
            return;
          }

          var action;
          try{action=new URL(form.action||frame.contentWindow.location.href)}
          catch(error){return}
          if(action.origin!==window.location.origin||isDownload(action,form)){return}

          var hadTarget=form.hasAttribute('target');
          var oldTarget=form.getAttribute('target');
          cancelPendingNavigation();
          cancelFrameImagePrefetches();
          var destination=createFrame(false);
          pendingFrame=destination;
          pendingTarget='';
          pendingHistory='deferred';
          document.body.classList.add('is-navigating');
          pendingGuard=window.setTimeout(cancelPendingNavigation,12000);
          try{
            frame.contentWindow.dispatchEvent(new Event('mesa:flujo:dispose'));
          }catch(error){}
          form.setAttribute('target',destination.name);
          watchFrameDocument(destination);
          window.setTimeout(function(){
            if(hadTarget){form.setAttribute('target',oldTarget||'')}
            else{form.removeAttribute('target')}
          },0);
        });
      }

      function activateLoadedFrame(frame){
        var previous=activeFrame;
        window.clearTimeout(pendingGuard);
        clearFrameDocumentWatch(frame);
        frame.classList.add('is-active');
        if(previous&&previous!==frame){
          previous.classList.remove('is-active');
          previous.classList.add('is-leaving');
        }
        activeFrame=frame;
        pendingFrame=null;
        pendingTarget='';
        document.body.classList.remove('is-navigating');

        var route=routeFromFrame(activeFrame);
        if(pendingHistory==='deferred'){
          lastRecordedRoute=recordParentHistory(route,'push')||lastRecordedRoute;
        }else if(pendingHistory==='committed'){
          var loadedRoute=normalizeRoute(route);
          if(loadedRoute&&loadedRoute!==lastRecordedRoute){
            lastRecordedRoute=recordParentHistory(loadedRoute,'replace')||lastRecordedRoute;
          }else{
            rememberRoute(lastRecordedRoute);
          }
        }else{
          lastRecordedRoute=rememberRoute(route)||lastRecordedRoute;
          commitRoute(lastRecordedRoute);
        }
        pendingHistory='none';
        try{bindNavigation(activeFrame)}
        catch(error){
          if(window.console&&console.error){console.error('No fue posible enlazar la navegación del módulo.',error)}
        }
        window.setTimeout(function(){prefetchFrameImages(frame)},0);
        if(previous&&previous!==activeFrame){
          window.setTimeout(function(){previous.remove()},130);
        }
      }

      function frameLoaded(frame){
        if(frame===pendingFrame){
          var loadedUrl='';
          try{loadedUrl=frame.contentWindow.location.href}catch(error){}
          if(!loadedUrl||loadedUrl==='about:blank'){return}
          var reveal=function(){
            window.requestAnimationFrame(function(){
              if(frame===pendingFrame){activateLoadedFrame(frame)}
            });
          };
          try{frame.contentWindow.requestAnimationFrame(reveal)}
          catch(error){reveal()}
          return;
        }
        if(frame===activeFrame){
          bindNavigation(frame);
        }
      }

      window.addEventListener('popstate',function(event){
        var state=event.state||{};
        var route=normalizeRoute(state.mesaRoute||'');
        if(route){
          var restoredIndex=Number(state.mesaIndex);
          if(Number.isFinite(restoredIndex)&&restoredIndex>=0){historyIndex=restoredIndex}
          lastRecordedRoute=rememberRoute(route)||lastRecordedRoute;
          navigate(route,'none');
        }
      });

      window.addEventListener('message',function(event){
        if(event.origin!==window.location.origin||!event.data){
          return;
        }
        if(!activeFrame||event.source!==activeFrame.contentWindow){return}
        if(event.data.tipo==='mesa-navegar'){
          navigate(event.data.url,'push');
        }else if(event.data.tipo==='mesa-historial'){
          recordParentHistory(
            event.data.url,
            event.data.replace?'replace':'push'
          );
        }
      });

      window.history.replaceState({
        mesaRoute:lastRecordedRoute,
        mesaIndex:historyIndex
      },'',baseUrl);
      rememberRoute(lastRecordedRoute);
      activeFrame=createFrame(true);
      loadFrame(activeFrame,initialUrl);

    }());
  </script>
  <?php if ($autenticado): ?>
  <script src="assets/js/controlSesion.js?v=2026-09-08.10" defer></script>
  <?php endif; ?>
</body>
</html>
