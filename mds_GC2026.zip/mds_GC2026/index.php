<?php
declare(strict_types=1);

$metodo = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

if ($metodo === 'POST') {
    require_once __DIR__ . '/app/bootstrap.php';
    require APP_ROOT . '/modules/auth/login.php';
    return;
}

if (!in_array($metodo, ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD, POST');
    http_response_code(405);
    exit('Metodo no permitido.');
}

require_once __DIR__ . '/app/bootstrap.php';
require_once APP_ROOT . '/security/seguridad.php';

seguridadAplicarCabeceras(true);
seguridadIniciarSesion();

header('Content-Type: text/html; charset=UTF-8');

if ($metodo === 'HEAD') {
    exit;
}

/* El login se carga como contenido del marco, nunca como URL principal. */
if ((string) ($_GET['vista'] ?? '') === 'acceso') {
    readfile(PUBLIC_ROOT . '/login.html');
    exit;
}

/*
 * Si un cierre de sesion redirige dentro del marco, se actualiza la ventana
 * principal sin crear un marco dentro de otro.
 */
if (strtolower((string) ($_SERVER['HTTP_SEC_FETCH_DEST'] ?? '')) === 'iframe') {
    $inicioJson = json_encode(
        mesaUrlInicio(),
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );
    ?>
<!doctype html>
<html lang="es"><head><meta charset="utf-8"><title>Mesa de Servicio</title></head>
<body><script>window.top.location.replace(<?= $inicioJson ?>);</script></body></html>
<?php
    exit;
}

$rol = (int) ($_SESSION['rol'] ?? 0);
$autenticado = !empty($_SESSION['usuario_id']) && in_array($rol, [1, 2, 3], true);
$pantallasPermitidas = [
    'apariencia.php', 'catalogos.php', 'checklists.php', 'chat.php',
    'configuraciones.php',
    'crearUsuarios.php', 'crearticket.php', 'diagnostico_relaciones.php',
    'editarUsuario.php', 'editarcatalogos.php', 'feriados.php',
    'flujoTicket.php', 'indicadores.php', 'mensajes.php', 'panelAdmin.php',
    'panelGestor.php', 'panelSolicitante.php', 'perfil.php', 'prioridades.php',
    'procesos.php', 'Registro.php',
    'seleccionarPais.php', 'servicios.php', 'sla.php', 'solicitudes.php',
    'soluciones.php', 'verificarActualizacionSolicitudes.php',
    'verificarCalendarioSla.php', 'verificarFlujos.php',
];

if ((string) ($_GET['_mesa_action'] ?? '') === 'record_screen') {
    $solicitudInterna = strtolower((string) (
        $_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''
    )) === 'xmlhttprequest';
    $pantallaRegistrada = basename((string) ($_GET['screen'] ?? ''));

    if (!$autenticado || !$solicitudInterna) {
        http_response_code(403);
        exit;
    }
    if (in_array($pantallaRegistrada, $pantallasPermitidas, true)) {
        $_SESSION['mesa_ultima_pantalla'] = $pantallaRegistrada;
    }
    http_response_code(204);
    exit;
}

if ($autenticado) {
    $pantalla = basename((string) ($_SESSION['mesa_ultima_pantalla'] ?? ''));

    if (!in_array($pantalla, $pantallasPermitidas, true)) {
        if ($rol === 1) {
            $pantalla = ((int) ($_SESSION['pais_operacion_id'] ?? 0) > 0)
                ? 'panelAdmin.php'
                : 'seleccionarPais.php';
        } elseif ($rol === 2) {
            $pantalla = 'panelGestor.php';
        } else {
            $pantalla = 'panelSolicitante.php';
        }
    }

    $src = $pantalla;
    if ($pantalla === 'panelSolicitante.php') {
        $src .= '?vista=tickets';
    }
} else {
    $pantallaPublica = (string) ($_SESSION['mesa_pantalla_publica'] ?? '');
    unset($_SESSION['mesa_pantalla_publica']);

    if ($pantallaPublica === 'recuperarPassword.php') {
        $src = 'recuperarPassword.php';
    } else {
        $parametrosAcceso = ['vista' => 'acceso'];
        $error = (string) ($_SESSION['mesa_login_error'] ?? '');
        $estado = (string) ($_SESSION['mesa_login_estado'] ?? '');
        $recuperacion = (string) (
            $_SESSION['mesa_login_recuperacion'] ?? ''
        );
        unset(
            $_SESSION['mesa_login_error'],
            $_SESSION['mesa_login_estado'],
            $_SESSION['mesa_login_recuperacion']
        );

        if ($error !== '') {
            $parametrosAcceso['error'] = $error;
        }
        if ($estado !== '') {
            $parametrosAcceso['sesion'] = $estado;
        }
        if ($recuperacion !== '') {
            $parametrosAcceso['recuperacion'] = $recuperacion;
        }

        $src = './?' . http_build_query(
            $parametrosAcceso,
            '',
            '&',
            PHP_QUERY_RFC3986
        );
    }
}

$srcJson = json_encode(
    $src,
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);
$inicioJson = json_encode(
    mesaUrlInicio(),
    JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#eef5ff">
  <title>Mesa de Servicio | Conectar</title>
  <style>
    html,body{width:100%;height:100%;margin:0;overflow:hidden;background:#f3f6fb}
    body{position:relative}
    body.is-navigating{cursor:progress}
    .mesa-app-frame{
      position:absolute;inset:0;width:100%;height:100%;border:0;
      z-index:0;background:#f3f6fb;opacity:0;pointer-events:none
    }
    .mesa-app-frame.is-active{z-index:1;opacity:1;pointer-events:auto}
  </style>
  <script>
    (function(){
      if(window.top!==window.self){
        window.top.location.replace(<?= $inicioJson ?>);
        return;
      }
      if(window.location.search||window.location.hash){
        history.replaceState(history.state,document.title,<?= $inicioJson ?>);
      }
    }());
  </script>
</head>
<body>
  <script>
    (function(){
      var basePath=<?= $inicioJson ?>;
      var baseUrl=new URL(basePath,window.location.href).href;
      var serverInitialUrl=<?= $srcJson ?>;
      var authenticated=<?= $autenticado ? 'true' : 'false' ?>;
      window.MESA_NAVIGATION_VERSION='2026-09-01.9-login-route-history';
      document.documentElement.dataset.mesaNavigationVersion=
        window.MESA_NAVIGATION_VERSION;
      var storedInitialUrl='';
      try{
        if(authenticated){
          var storedCandidates=[
            window.history.state&&window.history.state.mesaRoute,
            window.sessionStorage.getItem('MESA_CURRENT_ROUTE')
          ];
          for(var storedIndex=0;storedIndex<storedCandidates.length;storedIndex+=1){
            var storedCandidate=storedCandidates[storedIndex]||'';
            if(!storedCandidate){continue}
            var storedCandidateUrl=new URL(storedCandidate,baseUrl);
            if(storedCandidateUrl.searchParams.get('vista')==='acceso'){
              continue;
            }
            storedInitialUrl=storedCandidate;
            break;
          }
          if(!storedInitialUrl){
            window.sessionStorage.removeItem('MESA_CURRENT_ROUTE');
          }
        }else{
          window.sessionStorage.removeItem('MESA_CURRENT_ROUTE');
        }
      }catch(error){}
      var initialUrl=storedInitialUrl||serverInitialUrl;

      /*
       * Navegador interno v3.
       *
       * El contenido de los módulos se obtiene con fetch y se escribe dentro
       * de un único iframe estable. De esta forma el iframe no crea entradas
       * propias en el historial conjunto del navegador: Atrás y Adelante
       * recorren exclusivamente los estados registrados por la ventana padre.
       */
      /* La navegación v3 queda desactivada por incompatibilidad del servidor. */

      function startMesaShellV3(startUrl){
        var shellFrame=document.createElement('iframe');
        var activeRoute='';
        var loadingRoute='';
        var requestSequence=0;
        var activeController=null;
        var shellHistoryIndex=0;
        var restoredShellIndex=Number(window.history.state&&window.history.state.mesaIndex);
        if(Number.isFinite(restoredShellIndex)&&restoredShellIndex>=0){
          shellHistoryIndex=restoredShellIndex;
        }

        function shellAbsolute(route){
          try{return new URL(route,baseUrl)}catch(error){return null}
        }

        function shellNormalize(route){
          var routeUrl=shellAbsolute(route);
          if(!routeUrl||routeUrl.origin!==window.location.origin){return ''}
          routeUrl.searchParams.delete('_mesa_prefetch');
          return routeUrl.pathname+routeUrl.search+routeUrl.hash;
        }

        function shellRemember(route){
          var internalRoute=shellNormalize(route);
          if(!internalRoute){return ''}
          if(!authenticated){return internalRoute}
          try{window.sessionStorage.setItem('MESA_CURRENT_ROUTE',internalRoute)}
          catch(error){}
          return internalRoute;
        }

        function shellCommit(route){
          var routeUrl=shellAbsolute(route);
          if(!routeUrl){return}
          var screen=routeUrl.pathname.split('/').pop()||'';
          if(!screen){return}
          var endpoint=new URL(baseUrl);
          endpoint.searchParams.set('_mesa_action','record_screen');
          endpoint.searchParams.set('screen',screen);
          window.fetch(endpoint.href,{
            method:'GET',credentials:'same-origin',cache:'no-store',
            keepalive:true,
            headers:{'X-Requested-With':'XMLHttpRequest'}
          }).catch(function(){});
        }

        function shellRecord(route,mode){
          var internalRoute=shellNormalize(route);
          if(!internalRoute){return ''}
          if(mode==='replace'){
            window.history.replaceState({
              mesaRoute:internalRoute,
              mesaIndex:shellHistoryIndex
            },'',baseUrl);
          }else{
            shellHistoryIndex+=1;
            window.history.pushState({
              mesaRoute:internalRoute,
              mesaIndex:shellHistoryIndex
            },'',baseUrl);
          }
          shellRemember(internalRoute);
          shellCommit(internalRoute);
          return internalRoute;
        }

        function shellRecordEmbeddedRoute(route){
          var internalRoute=shellNormalize(route);
          if(!internalRoute){return}
          shellRecord(internalRoute,'push');
        }

        function shellEscapeAttribute(value){
          return String(value)
            .replace(/&/g,'&amp;')
            .replace(/"/g,'&quot;')
            .replace(/</g,'&lt;');
        }

        function shellPrepareHtml(html,url){
          var baseTag='<base href="'+shellEscapeAttribute(url)+'">';
          /*
           * document.write() conserva inicialmente la URL about:blank del
           * iframe. Las vistas que consultan window.location necesitan ver la
           * ruta real del módulo. replaceState solo actualiza esa URL interna:
           * no crea un paso adicional en el historial.
          */
          var routeBootstrap='<script>try{history.replaceState({mesaEmbedded:true},"",'
            +JSON.stringify(url)+')}catch(error){}<'+'/script>';
          if(/<head(?:\s[^>]*)?>/i.test(html)){
            return html.replace(/<head(\s[^>]*)?>/i,function(match){
              return match+baseTag+routeBootstrap;
            });
          }
          return '<!doctype html><html><head>'+baseTag+routeBootstrap+'</head><body>'+html+'</body></html>';
        }

        function shellWrite(html,url){
          var doc=shellFrame.contentWindow.document;
          doc.open();
          doc.write(shellPrepareHtml(html,url));
          doc.close();
          window.setTimeout(function(){shellBindNavigation()},0);
        }

        function shellStopLoading(){
          loadingRoute='';
          document.body.classList.remove('is-navigating');
        }

        function shellRender(url,historyMode,requestOptions){
          var target=shellAbsolute(url);
          if(!target||target.origin!==window.location.origin){return}
          var targetRoute=shellNormalize(target.href);
          if(historyMode==='push'&&targetRoute===activeRoute){return}
          if(loadingRoute===targetRoute){return}

          if(activeController&&activeController.abort){activeController.abort()}
          activeController=window.AbortController?new AbortController():null;
          requestSequence+=1;
          var thisRequest=requestSequence;
          loadingRoute=targetRoute;
          document.body.classList.add('is-navigating');

          var options={
            method:'GET',
            credentials:'same-origin',
            cache:'no-store',
            redirect:'follow',
            headers:{'X-Requested-With':'MesaNavigation'}
          };
          if(requestOptions){
            Object.keys(requestOptions).forEach(function(key){
              options[key]=requestOptions[key];
            });
          }
          if(activeController){options.signal=activeController.signal}

          window.fetch(target.href,options).then(function(response){
            if(!response.ok){throw new Error('HTTP '+response.status)}
            return response.text().then(function(html){
              return {html:html,url:response.url||target.href};
            });
          }).then(function(result){
            if(thisRequest!==requestSequence){return}
            var finalRoute=shellNormalize(result.url)||targetRoute;
            if(historyMode==='deferred'||historyMode==='push'){
              shellRecord(finalRoute,'push');
            }else{
              shellRemember(finalRoute);
              shellCommit(finalRoute);
            }
            activeRoute=finalRoute;
            shellWrite(result.html,result.url||target.href);
            shellStopLoading();
          }).catch(function(error){
            if(thisRequest!==requestSequence){return}
            shellStopLoading();
            if(error&&error.name==='AbortError'){return}
            if(window.console&&console.error){
              console.error('No fue posible abrir el módulo.',error);
            }
          });
        }

        function shellIsDownload(url,element){
          if(element&&element.hasAttribute&&element.hasAttribute('download')){
            return true;
          }
          return /\/(?:descargar|imagenCatalogo|imagenPerfil)[^/]*\.php$/i.test(url.pathname)
            || /\.(?:pdf|xlsx?|csv|zip|rar|docx?|pptx?)$/i.test(url.pathname);
        }

        function shellMaskLinks(doc){
          if(!doc||!doc.querySelectorAll){return}
          doc.querySelectorAll('a[href]').forEach(function(link){
            var rawRoute=link.getAttribute('data-mesa-route')||link.getAttribute('href');
            if(!rawRoute||rawRoute.charAt(0)==='#'||/^\s*(?:javascript:|mailto:|tel:)/i.test(rawRoute)){return}
            var url;
            try{url=new URL(rawRoute,baseUrl)}catch(error){return}
            if(url.origin!==window.location.origin||url.protocol!=='http:'&&url.protocol!=='https:'){return}
            link.setAttribute('data-mesa-route',url.href);
            link.setAttribute('href',baseUrl);
          });
        }

        function shellAppendSubmitter(data,submitter){
          if(submitter&&submitter.name&&!data.has(submitter.name)){
            data.append(submitter.name,submitter.value||'');
          }
        }

        function shellBindNavigation(){
          var doc;
          try{doc=shellFrame.contentDocument}catch(error){return}
          if(!doc||!doc.documentElement){return}
          if(doc.documentElement.dataset.mesaNavigationBound){return}
          doc.documentElement.dataset.mesaNavigationBound='1';
          shellMaskLinks(doc);
          if(window.MutationObserver){
            new MutationObserver(function(){shellMaskLinks(doc)}).observe(doc.body||doc.documentElement,{childList:true,subtree:true});
          }

          doc.addEventListener('click',function(event){
            if(event.defaultPrevented||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey){
              return;
            }
            var link=event.target.closest?event.target.closest('a[href]'):null;
            if(!link){return}
            var targetName=(link.getAttribute('target')||'').toLowerCase();
            if(targetName&&targetName!=='_self'){return}
            var url;
            try{url=new URL(link.getAttribute('data-mesa-route')||link.href,baseUrl)}catch(error){return}
            if(url.origin!==window.location.origin||shellIsDownload(url,link)){return}
            if(url.protocol!=='http:'&&url.protocol!=='https:'){return}

            event.preventDefault();
            if(/\/logout\.php$/i.test(url.pathname)){
              window.fetch(url.href,{credentials:'same-origin',cache:'no-store'})
                .finally(function(){window.location.replace(baseUrl)});
              return;
            }

            var current=shellAbsolute(activeRoute);
            if(current&&url.pathname===current.pathname&&url.search===current.search&&url.hash){
              var anchor=doc.getElementById(url.hash.slice(1));
              if(anchor&&anchor.scrollIntoView){anchor.scrollIntoView()}
              return;
            }
            shellRender(url.href,'push');
          });

          doc.addEventListener('submit',function(event){
            if(event.defaultPrevented||!authenticated){return}
            var form=event.target;
            if(!form||String(form.method||'get').toLowerCase()==='dialog'){return}
            var targetName=(form.getAttribute('target')||'').toLowerCase();
            if(targetName==='_top'||targetName==='_parent'||targetName==='_blank'){return}

            var rawAction=form.getAttribute('action');
            var action=shellAbsolute(rawAction&&rawAction.trim()?form.action:activeRoute);
            if(!action||action.origin!==window.location.origin||shellIsDownload(action,form)){return}

            event.preventDefault();
            var method=String(form.method||'get').toUpperCase();
            var data=new FormData(form);
            shellAppendSubmitter(data,event.submitter);
            if(method==='GET'){
              action.search='';
              data.forEach(function(value,key){
                if(typeof value==='string'){action.searchParams.append(key,value)}
              });
              shellRender(action.href,'push');
              return;
            }
            shellRender(action.href,'deferred',{method:method,body:data});
          });
        }

        window.addEventListener('popstate',function(event){
          var state=event.state||{};
          var route=shellNormalize(state.mesaRoute||'');
          if(!route){return}
          var restoredIndex=Number(state.mesaIndex);
          if(Number.isFinite(restoredIndex)&&restoredIndex>=0){
            shellHistoryIndex=restoredIndex;
          }
          shellRemember(route);
          shellRender(route,'none');
        });

        window.addEventListener('message',function(event){
          if(event.origin!==window.location.origin||!event.data){
            return;
          }
          if(event.source!==shellFrame.contentWindow){return}
          if(event.data.tipo==='mesa-navegar'){
            shellRender(event.data.url,'push');
          }else if(event.data.tipo==='mesa-historial'){
            shellRecord(event.data.url,event.data.replace?'replace':'push');
          }
        });

        activeRoute=shellNormalize(startUrl)||shellNormalize(serverInitialUrl);
        window.history.replaceState({
          mesaRoute:activeRoute,
          mesaIndex:shellHistoryIndex
        },'',baseUrl);
        shellRemember(activeRoute);

        shellFrame.name='mesaFrame';
        shellFrame.title='Mesa de Servicio';
        shellFrame.className='mesa-app-frame is-active';
        shellFrame.setAttribute('allow','clipboard-write');
        document.body.appendChild(shellFrame);
        activeRoute='';
        shellRender(startUrl,'initial');
      }

      /*
       * Navegación principal sin recargas del iframe. El bloque antiguo se
       * conserva debajo únicamente como respaldo de código, pero no se inicia.
       */
      startMesaShellV3(initialUrl);
      return;

      var activeFrame=null;
      var pendingFrame=null;
      var pendingTarget='';
      var pendingHistory='none';
      var pendingGuard=0;
      var frameSequence=0;
      var lastRecordedRoute='';
      var historyIndex=0;
      var prefetchablePages=[
        'apariencia.php','catalogos.php','checklists.php','chat.php',
        'configuraciones.php','crearusuarios.php','crearticket.php',
        'diagnostico_relaciones.php','editarusuario.php','editarcatalogos.php',
        'feriados.php','flujoticket.php','indicadores.php','mensajes.php',
        'paneladmin.php','panelgestor.php','panelsolicitante.php','perfil.php',
        'prioridades.php','procesos.php','registro.php','servicios.php','sla.php',
        'solicitudes.php','soluciones.php','verificaractualizacionsolicitudes.php',
        'verificarcalendariosla.php','verificarflujos.php'
      ];
      var initialRouteUrl;
      try{initialRouteUrl=new URL(initialUrl,baseUrl)}catch(error){initialRouteUrl=null}
      var initialPage=initialRouteUrl?(initialRouteUrl.pathname.split('/').pop()||'').toLowerCase():'';
      if(!initialRouteUrl||initialRouteUrl.origin!==window.location.origin||prefetchablePages.indexOf(initialPage)===-1){
        initialUrl=serverInitialUrl;
      }
      lastRecordedRoute=normalizeRoute(initialUrl);
      var restoredIndex=Number(window.history.state&&window.history.state.mesaIndex);
      if(Number.isFinite(restoredIndex)&&restoredIndex>=0){historyIndex=restoredIndex}

      function createFrame(isActive){
        var frame=document.createElement('iframe');
        frameSequence+=1;
        frame.name='mesaFrame'+frameSequence;
        frame.title='Mesa de Servicio';
        frame.className='mesa-app-frame'+(isActive?' is-active':'');
        frame.setAttribute('allow','clipboard-write');
        frame.addEventListener('load',function(){frameLoaded(frame)});
        document.body.appendChild(frame);
        return frame;
      }

      function loadFrame(frame,url){
        try{frame.contentWindow.location.replace(url)}
        catch(error){frame.src=url}
      }

      function routeFromFrame(frame){
        try{
          var url=new URL(frame.contentWindow.location.href);
          if(url.origin!==window.location.origin){return initialUrl}
          return url.pathname+url.search+url.hash;
        }catch(error){return initialUrl}
      }

      function isDownload(url,element){
        if(element&&element.hasAttribute&&element.hasAttribute('download')){
          return true;
        }
        return /\/(?:descargar|imagenCatalogo|imagenPerfil)[^/]*\.php$/i.test(url.pathname)
          || /\.(?:pdf|xlsx?|csv|zip|rar|docx?|pptx?)$/i.test(url.pathname);
      }

      function cancelPendingNavigation(){
        window.clearTimeout(pendingGuard);
        if(pendingFrame&&pendingFrame!==activeFrame){pendingFrame.remove()}
        pendingFrame=null;
        pendingTarget='';
        pendingHistory='none';
        document.body.classList.remove('is-navigating');
      }

      function navigate(url,historyMode){
        var target,current;
        try{target=new URL(url,activeFrame.contentWindow.location.href)}
        catch(error){return}
        if(target.origin!==window.location.origin){return}
        try{current=new URL(activeFrame.contentWindow.location.href)}
        catch(error){current=null}
        if(current&&target.href===current.href){return}
        if(pendingFrame&&pendingTarget===target.href){return}

        cancelPendingNavigation();
        /*
         * Los módulos GET reutilizan un único iframe. Crear y eliminar un
         * iframe por cada clic añade recorridos internos al historial conjunto
         * del navegador, aunque la barra conserve la URL enmascarada.
         *
         * Primero se guarda el estado del padre y después location.replace()
         * cambia el documento del mismo iframe. De este modo cada módulo tiene
         * una sola entrada y un push nuevo elimina correctamente el recorrido
         * de Adelante después de haber usado Atrás.
         */
        if(historyMode==='push'){
          lastRecordedRoute=recordParentHistory(target.href,'push')||lastRecordedRoute;
          pendingHistory='committed';
        }else{
          pendingHistory='none';
        }

        pendingTarget=target.href;
        pendingFrame=activeFrame;
        document.body.classList.add('is-navigating');
        pendingGuard=window.setTimeout(cancelPendingNavigation,12000);
        loadFrame(pendingFrame,target.href);
      }

      function commitRoute(route){
        var routeUrl;
        try{routeUrl=new URL(route,window.location.origin)}
        catch(error){return}
        var screen=routeUrl.pathname.split('/').pop()||'';
        if(!screen){return}
        var endpoint=new URL(baseUrl);
        endpoint.searchParams.set('_mesa_action','record_screen');
        endpoint.searchParams.set('screen',screen);
        window.fetch(endpoint.href,{
          method:'GET',credentials:'same-origin',cache:'no-store',
          keepalive:true,
          headers:{'X-Requested-With':'XMLHttpRequest'}
        }).catch(function(){});
      }

      function normalizeRoute(route){
        var routeUrl;
        try{routeUrl=new URL(route,baseUrl)}
        catch(error){return ''}
        if(routeUrl.origin!==window.location.origin){return ''}
        routeUrl.searchParams.delete('_mesa_prefetch');
        return routeUrl.pathname+routeUrl.search+routeUrl.hash;
      }

      function rememberRoute(route){
        var internalRoute=normalizeRoute(route);
        if(!internalRoute){return ''}
        try{window.sessionStorage.setItem('MESA_CURRENT_ROUTE',internalRoute)}
        catch(error){}
        return internalRoute;
      }

      function recordParentHistory(route,mode){
        var internalRoute=normalizeRoute(route);
        if(!internalRoute){return ''}
        if(mode==='replace'){
          window.history.replaceState({mesaRoute:internalRoute,mesaIndex:historyIndex},'',baseUrl);
        }else{
          historyIndex+=1;
          window.history.pushState({mesaRoute:internalRoute,mesaIndex:historyIndex},'',baseUrl);
        }
        lastRecordedRoute=rememberRoute(internalRoute)||lastRecordedRoute;
        commitRoute(internalRoute);
        return internalRoute;
      }

      function bindNavigation(frame){
        var doc;
        try{doc=frame.contentDocument}catch(error){return}
        if(!doc||!doc.documentElement){return}
        if(doc.documentElement.dataset.mesaNavigationBound){return}
        doc.documentElement.dataset.mesaNavigationBound='1';

        doc.addEventListener('click',function(event){
          if(event.defaultPrevented||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey){
            return;
          }
          var link=event.target.closest?event.target.closest('a[href]'):null;
          if(!link){return}
          var targetName=(link.getAttribute('target')||'').toLowerCase();
          if(targetName&&targetName!=='_self'){return}

          var url;
          try{url=new URL(link.href,frame.contentWindow.location.href)}
          catch(error){return}
          if(url.origin!==window.location.origin||isDownload(url,link)){return}
          if(url.protocol!=='http:'&&url.protocol!=='https:'){return}
          if(url.href===frame.contentWindow.location.href){
            event.preventDefault();
            return;
          }
          if(url.pathname===frame.contentWindow.location.pathname&&url.search===frame.contentWindow.location.search&&url.hash){
            event.preventDefault();
            try{
              frame.contentWindow.history.replaceState(
                frame.contentWindow.history.state,'',url.href
              );
              frame.contentDocument.getElementById(url.hash.slice(1))?.scrollIntoView();
            }catch(error){}
            return;
          }

          event.preventDefault();
          navigate(url.href,'push');
        });

        doc.addEventListener('submit',function(event){
          if(event.defaultPrevented){return}
          var form=event.target;
          if(!form||String(form.method||'get').toLowerCase()==='dialog'){return}
          var targetName=(form.getAttribute('target')||'').toLowerCase();
          if(targetName==='_top'||targetName==='_parent'||targetName==='_blank'){
            return;
          }

          var action;
          try{action=new URL(form.action||frame.contentWindow.location.href)}
          catch(error){return}
          if(action.origin!==window.location.origin||isDownload(action,form)){return}

          var hadTarget=form.hasAttribute('target');
          var oldTarget=form.getAttribute('target');
          cancelPendingNavigation();
          var destination=createFrame(false);
          pendingFrame=destination;
          pendingTarget='';
          pendingHistory='deferred';
          document.body.classList.add('is-navigating');
          pendingGuard=window.setTimeout(cancelPendingNavigation,12000);
          form.setAttribute('target',destination.name);
          window.setTimeout(function(){
            if(hadTarget){form.setAttribute('target',oldTarget||'')}
            else{form.removeAttribute('target')}
          },0);
        });
      }

      function activateLoadedFrame(frame){
        var previous=activeFrame;
        window.clearTimeout(pendingGuard);
        frame.classList.add('is-active');
        if(previous&&previous!==frame){previous.classList.remove('is-active')}
        activeFrame=frame;
        pendingFrame=null;
        pendingTarget='';
        document.body.classList.remove('is-navigating');

        var route=routeFromFrame(activeFrame);
        if(pendingHistory==='deferred'){
          lastRecordedRoute=recordParentHistory(route,'push')||lastRecordedRoute;
        }else if(pendingHistory==='committed'){
          var loadedRoute=normalizeRoute(route);
          if(loadedRoute&&loadedRoute!==lastRecordedRoute){
            lastRecordedRoute=recordParentHistory(loadedRoute,'replace')||lastRecordedRoute;
          }else{
            rememberRoute(lastRecordedRoute);
          }
        }else{
          lastRecordedRoute=rememberRoute(route)||lastRecordedRoute;
          commitRoute(lastRecordedRoute);
        }
        pendingHistory='none';
        try{bindNavigation(activeFrame)}
        catch(error){
          if(window.console&&console.error){console.error('No fue posible enlazar la navegación del módulo.',error)}
        }
        if(previous&&previous!==activeFrame){previous.remove()}
      }

      function frameLoaded(frame){
        if(frame===pendingFrame){
          var loadedUrl='';
          try{loadedUrl=frame.contentWindow.location.href}catch(error){}
          if(!loadedUrl||loadedUrl==='about:blank'){return}
          window.requestAnimationFrame(function(){
            if(frame===pendingFrame){activateLoadedFrame(frame)}
          });
          return;
        }
        if(frame===activeFrame){
          bindNavigation(frame);
        }
      }

      window.addEventListener('popstate',function(event){
        var state=event.state||{};
        var route=normalizeRoute(state.mesaRoute||'');
        if(route){
          var restoredIndex=Number(state.mesaIndex);
          if(Number.isFinite(restoredIndex)&&restoredIndex>=0){historyIndex=restoredIndex}
          lastRecordedRoute=rememberRoute(route)||lastRecordedRoute;
          navigate(route,'none');
        }
      });

      window.addEventListener('message',function(event){
        if(event.origin!==window.location.origin||!event.data||event.data.tipo!=='mesa-navegar'){
          return;
        }
        if(!activeFrame||event.source!==activeFrame.contentWindow){return}
        navigate(event.data.url,'push');
      });

      window.history.replaceState({
        mesaRoute:lastRecordedRoute,
        mesaIndex:historyIndex
      },'',baseUrl);
      rememberRoute(lastRecordedRoute);
      activeFrame=createFrame(true);
      loadFrame(activeFrame,initialUrl);

    }());
  </script>
</body>
</html>
